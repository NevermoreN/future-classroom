# Independent R77 AsyncWait driver: preparation only

The sole Windows operator runs this in fresh Desktop Windows PowerShell 5.1 x64:

```
& <root>\Driver.ps1 -Execute -Root <root> -ConfigSha256 <config-sha256> -ManifestSha256 <inputs-sha256>
```

Without `-Execute`, it only describes the interface and does not inspect files,
compile, connect, query Windows or create state. Actual PS parsing, Framework
compilation, COM building and installation remain **NOT_RUN** at this freeze.
There is no local `pwsh`/PS5.1 parser, so local source checks are not an AST claim.

Root transport creates the protected current-user-owned directory
`%TEMP%\FutureClassroom-r77-async-chainer-<nonce>` with only user/SYSTEM full-control
ACEs, inheritance disabled, and `.owner` containing the exact LF-terminated marker
`future-classroom-owned-r77-async-chainer-fixture/v1`.

It uploads the original `Program.cs`, `New-AsyncChainerFixture.ps1`,
`ProcessObserver.cs`, `Driver.ps1`, and `config.json`. `inputs.json` has `files`
containing exactly these five `{path,bytes,sha256}` records, with direct leaf
paths. Config contains schemaVersion1, sourceGit
`8931fabc0520ac659f9c019f9790e4d4f81ff9a7`, nonce32 lowercase hex,
expectedUserSid, three distinct uppercase braced productCode/upgradeCode/componentId,
registryKey `Software\FutureClassroomTest\Round77-<nonce>`, rootName,
wholeSeconds120/clientMaximumSeconds30/asyncSeconds10/readySeconds2, and `sources`
with the source leaf byte/SHA records. No production product/family GUID is accepted.

The one 120-second clock includes compiling the x86 GUI fixture, loading the
original observer and native query/client instrumentation (at most the first
30 seconds), closed COM authoring/readback, the original client (at most30s),
draining original captured processes, and necessary formal cleanup. Program's
ten-second Async and two-second Ready clocks are untouched. No renewed native
120-second product deadline, process termination, shared-service wait/kill,
production gate/Pending/Run/trust write, cache removal or registry hand deletion
exists here. TEMP/TMP are redirected only to protected `compiler-temp` for csc
and Add-Type, then restored before MSI. Root later inventories/downloads/cleans
only the owned scratch; the driver does not delete its reports or source.

Before the client starts, the factory must return its actual closed ten-table
and exact Binary readback success. Product/current-user/machine-context and
related enumeration, component state, and the exact HKCU32 nonce key must be
known absent. Actual MSI processes use fixed System32 `msiexec.exe`, quiet mode,
no restart, explicit DisableShutdown and verbose original log. Native
CreateProcess gives the original process object; thread/process closes are
checked once, actual Wait/exit integers are recorded. No exit is guessed from
an MSI Action Return value.

The original observer starts before the client. Each Snapshot is retained in
`observer-original.jsonl`. Only an independently held original process fact
matching identity PID, creation, whole compiled fixture image SHA/bytes and SID
allows copying the complete original identity bytes via create-new atomic
publication to `.async-original-captured`/`.ready-original-captured`. These files
are fixture barriers, not production authority. Metadata/role UNKNOWN remains
supplemental; capture/hash/token/wait/close failures remain errors. All captured
controls must physically return with actual exit integers and checked close
before any cleanup attempt.

`driver-result.json` records every stage's original byte SHA and parsed facts.
`PROBE_SUPPORTED` requires the complete START/READY/CHAINER_ENTER/Join0/
EndRollback0/event checked-close/original guardian exit0/ASYNC_DONE chain, both
independent original Async/Ready exit0 and checked-close facts, all captured
controls returned0, and final exact product/component/related/registry absence.
The actual MSI client integer is retained even for intentional rollback and is
never rewritten. Missing success stages after valid START/READY can be
`PROBE_REJECTED` with successful negative-evidence capture; startup/instrument
failure is `PROBE_INCONCLUSIVE_INSTRUMENT_OR_STARTUP`. Neither is a product PASS.

If the original client and captured controls returned and the exact synthetic
product is singly registered with its exact marker, a necessary formal `/x`
may run under the same original outer clock. The frozen factory's
`NOT Installed` conditions skip Async/Ready/guardian on `/x`. Unknown or foreign
state is retained FAIL. Original nonzero fixture exit is valid negative evidence
and is kept; no requirement fabricates exit0 merely to classify cleanup safety.

Frozen dependencies are Program d9730f47e761ebfbd72921c5faab72cb314e34eb31ad609649ec6808f0be631f,
factory82266a2dcc9d791e72476d3cdd3c0b470e912deacfc0a3907a332ec713f5d5c8,
and observerae5ad0205854e0f2e731394e6f72a0f2481818da1efabf88abeccd716a256b31.
Root's actual parser/compiler/COM/runtime results decide the next step.
