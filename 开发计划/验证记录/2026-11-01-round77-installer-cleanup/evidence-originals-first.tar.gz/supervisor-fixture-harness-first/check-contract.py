#!/usr/bin/env python3
"""Finite source/model checks; does not parse PowerShell or execute Windows."""
import hashlib,json
from pathlib import Path
p=Path(__file__).parent
s=(p/'Driver.ps1').read_text()
checks={}
def check(name,value):
    assert value,name
    checks[name]=True
check('inert_default_before_clock',s.index('if(-not $Execute)')<s.index('$clock='))
check('original_whole120_and_client30','wholeSeconds=120;clientMaximumSeconds=30;supervisorSeconds=10;childSeconds=10;ackSeconds=2' in s)
check('only_supervisor_external_ack',"foreach($role in @('supervisor'))" in s and "foreach($role in @('guardian-child'))" not in s)
check('no_driver_child_ack_publication',s.count("'.supervisor-child-original-captured'")==2 and "Read-Bounded '.supervisor-child-original-captured'" in s)
check('held_original_supervisor_identity','ORIGINAL_QUERY_SYNC_HANDLE_EXACT_IMAGE_BYTES_USER' in s and 'ACTUAL_ORIGINAL_GET_EXIT_CODE' in s and 'CHECKED_CLOSE_SUCCESS' in s)
check('unchanged_observer_source',hashlib.sha256((p.parent/'observer-source-first/ProcessObserver.cs').read_bytes()).hexdigest()=='ae5ad0205854e0f2e731394e6f72a0f2481818da1efabf88abeccd716a256b31')
check('strict_source_manifest','CLOSED_FIVE_INPUTS' in s and 'EXACT_FOUR_SOURCE_PINS' in s and 'CONFIG_SOURCE_SHA:' in s)
check('original_children_return_not_pid_absence','$parsed.CHILD_EXIT_RETURN.actualExitCode-eq 0' in s and '$parsed.CHILD_PROCESS_CLOSED.checkedClose-eq $true' in s)
check('actual_join_end_required','$parsed.JOIN_RETURN.returnCode-eq 0' in s and '$parsed.END_RETURN.returnCode-eq 0' in s and "decision-ceq 'ROLLBACK'" in s)
check('negative_distinct',"classification='NEGATIVE_ACTUAL_CHILD_JOIN_RETURN'" in s and 'NOT_FUNCTION_SUPPORT' in s)
check('rollback_absence_before_formal_cleanup','$result.after.knownAbsent-and $result.finalAbsence.knownAbsent' in s)
check('client_integer_not_forced_zero',"'ACTUAL_CSC_FAILED'" in s and '$client.ActualExitCode-eq 0' not in s)
check('finally_only_formal_uninstall',"'/x '+$config.productCode" in s and 'FORMAL_X_NOT_AUTHORIZED_UNKNOWN_OR_FOREIGN_STATE' in s)
check('no_kill_or_registry_cache_deletion',all(x not in s.lower() for x in ('stop-process','taskkill','terminateprocess','remove-item','deletevalue','deletesubkey')))
check('all_expected_stage_names',all(x in s for x in ('CREATE_PROCESS_RETURN','CHILD_THREAD_CLOSED','CHILD_ENTER','JOIN_RETURN','END_ENTER','END_RETURN','CHANGE_EVENT_CLOSED','GUARDIAN_CHILD_DONE','CHILD_EXIT_RETURN','CHILD_PROCESS_CLOSED','SUPERVISOR_DONE')))
check('factory_exact_hash',hashlib.sha256((p.parent/'supervisor-fixture-authoring-first/New-SupervisorChainerFixture.ps1').read_bytes()).hexdigest()=='32d8f64698d6854461a9a751eb8b688dc496c172f43e3a894621e125832d0a53')
# These explicit model examples explain classification, not actual PS execution.
def classify(*,captured=True,held=True,source=True,join=0,end=0,child=0,closed=True,after_absent=True,final_absent=True,stages=True,ack=True):
    if captured and held and source and join==0 and end==0 and child==0 and closed and after_absent and final_absent and stages and ack:return 'FUNCTION_SUPPORT'
    if captured and source and join!=0 and final_absent and ack:return 'NEGATIVE_JOIN_RESULT'
    return 'INCONCLUSIVE'
check('model_positive',classify()=='FUNCTION_SUPPORT')
for name,kw in [('capture_only',dict(stages=False)),('child_close_unknown',dict(closed=False)),('held_identity_unknown',dict(held=False)),('end_nonzero',dict(end=1603)),('child_exit_nonzero',dict(child=1603)),('only_formal_cleanup_absent',dict(after_absent=False)),('final_absence_unknown',dict(final_absent=False)),('ack_missing',dict(ack=False)),('child_source_mismatch',dict(source=False))]:
    check('model_'+name,classify(**kw)=='INCONCLUSIVE')
check('model_actual_join_negative',classify(join=1603,end=1603,child=1603,stages=False)=='NEGATIVE_JOIN_RESULT')
print(json.dumps({'status':'PASS_FINITE_SOURCE_AND_DECISION_MODEL_ONLY','checks':checks,'checkCount':len(checks),'powershellParse':'NOT_RUN','csharpCompile':'NOT_RUN','windowsRuntime':'NOT_RUN'},sort_keys=True,indent=2))
