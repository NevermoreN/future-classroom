"""Pack completed R77 text originals; never clean sources or contact Windows."""
from pathlib import Path
import argparse, ast, base64, hashlib, io, json, re, tarfile

E=Path('/tmp/fc-round77-installer-cleanup')
ROOT=Path('/workspace/共享/Eliora/未来教室计划')
DEST=ROOT/'开发计划/验证记录/2026-11-01-round77-installer-cleanup'
def sha(b):return hashlib.sha256(b).hexdigest()
def fact(p,b):return dict(path=str(p),bytes=len(b),sha256=sha(b))
def views(b):
    if b.startswith((b'\xff\xfe',b'\xfe\xff')):return [b.decode('utf-16')]
    try:s=b.decode('utf-8-sig')
    except UnicodeDecodeError:s=b.decode('cp936')
    assert '\x00' not in s,'UNRECOGNIZED_BINARY'
    return [s]
SECRET=re.compile(r'(?:gh[pousr]_[A-Za-z0-9]{25,}|github_pat_[A-Za-z0-9_]{35,}|sk-proj-[A-Za-z0-9_-]{30,}|-----BEGIN (?:OPENSSH|RSA|EC) PRIVATE KEY-----\s+[A-Za-z0-9+/]{30,})')
def scan(b):
    texts=views(b)
    for text in list(texts):
        for token in re.findall(r'[A-Za-z0-9+/]{80,}={0,2}',text):
            if len(token)>4*1024*1024:continue
            try:data=base64.b64decode(token,validate=True)
            except ValueError:continue
            if data.startswith((b'MZ',b'PK\x03\x04',b'\xd0\xcf\x11\xe0')):raise AssertionError('ENCODED_BINARY_REQUIRES_EXPLICIT_IDENTITY_EXCLUSION')
            for encoding in ('utf-8','utf-16-le'):
                try:decoded=data.decode(encoding)
                except UnicodeError:continue
                if '\x00' not in decoded:texts.append(decoded)
    for text in texts:assert not SECRET.search(text),'CREDENTIAL_PATTERN'
    return len(texts)
def inventory():
    files=[];excluded=[];pruned=[]
    for p in sorted(E.iterdir()):
        if p.name=='target':
            assert p.is_dir() and not p.is_symlink();pruned.append(dict(path='target',reason='Generated Cargo check/release compilation tree; no original text evidence. Selected PE identities retained in build report.'));continue
        candidates=[p] if p.is_file() else sorted(p.rglob('*'))
        for f in candidates:
            assert not f.is_symlink(),'SYMLINK_NOT_ALLOWED'
            if f.is_dir():continue
            assert f.is_file();rel=f.relative_to(E).as_posix();b=f.read_bytes()
            if f.suffix.lower() in ('.exe','.msi','.dll','.pdb','.pyc'):
                excluded.append(dict(path=rel,bytes=len(b),sha256=sha(b),reason='Generated synthetic/build binary; identity only.'));continue
            scan(b);files.append(dict(path=rel,bytes=len(b),sha256=sha(b)))
    return files,excluded,pruned
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');a=p.parse_args()
    if not a.execute:print(json.dumps(dict(status='PREPARED_NOT_RUN',windows='NOT_CONNECTED',sourceDeletion=False)));return 0
    assert (E/'.owner').read_bytes()==b'future-classroom-owned-r77-installer-cleanup/v1\n'
    assert not DEST.exists();DEST.mkdir()
    files,excluded,pruned=inventory();archive=DEST/'evidence-originals-first.tar.gz'
    with tarfile.open(archive,'w:gz',compresslevel=9) as t:
        for f in files:
            b=(E/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
            i=tarfile.TarInfo(f['path']);i.size=len(b);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(b))
    nested=0
    with tarfile.open(archive,'r:gz') as t:
        members=t.getmembers();assert len(members)==len(files)
        for m,f in zip(members,files):
            assert m.name==f['path'] and m.isfile();b=t.extractfile(m).read();assert len(b)==f['bytes'] and sha(b)==f['sha256'];nested+=scan(b)
    assert inventory()==(files,excluded,pruned),'SOURCE_MEMBERSHIP_OR_BYTES_CHANGED'
    promoted=[]
    names=['async-fixture-runtime-first/report.json','async-fixture-runtime-second/report.json','supervisor-fixture-runtime-first/report.json','root-supervisor-fixture-cleanup-first.json','native-supervisor-actual-review-first/review-first.json','native-production-source-review-first/review-first.json','native-build-first/report.json','root-native-build-first-terminal-qualification.json','native-build-second/report.json','native-build-capture-third/report.json','native-build-fourth/report.json','windows-native-full-first.json','windows-native-full-second.json','windows-readonly-final-first.json','unwind-linker-diagnostic-first/terminal-qualification-first.json']
    for name in names:
        source=E/name
        if not source.exists():continue
        b=source.read_bytes();scan(b);target=DEST/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b);promoted.append(dict(source=name,path=name,bytes=len(b),sha256=sha(b)))
    b=archive.read_bytes();index=dict(schemaVersion=1,status='PASS_ARCHIVED_BYTES_NOT_NEW_RUNTIME',sourceRoot=str(E),archive=fact(archive,b),originals=files,excludedBinaries=excluded,prunedGeneratedTrees=pruned,promoted=promoted,originalCount=len(files),originalBytes=sum(f['bytes'] for f in files),sourceDeletion=False)
    indexPath=DEST/'archive-index-first.json';indexPath.write_text(json.dumps(index,indent=2)+'\n')
    verify=dict(status='PASS',members=len(files),originalBytes=index['originalBytes'],archiveBytes=len(b),archiveSha256=sha(b),indexSha256=sha(indexPath.read_bytes()),decodedTextViewsScanned=nested,credentialsFound=False,sourceDeletion=False,windowsContacted=False)
    (DEST/'archive-verification-first.json').write_text(json.dumps(verify,indent=2)+'\n');print(json.dumps(verify));return 0
if __name__=='__main__':raise SystemExit(main())
