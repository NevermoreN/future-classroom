// TEST-ONLY READ-ONLY INSTRUMENT. No process suspend/terminate, writes, hooks,
// transaction calls, authority packets, or production role invocation.
// Add-Type -ReferencedAssemblies System.Management then invoke from root's bounded
// orchestrator BEFORE the one reviewed msiexec client is launched. No standalone main.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Management;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

public sealed class FcR76ProcessObserver {
    [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint a,bool inherit,uint pid);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetProcessTimes(IntPtr h,out long c,out long x,out long k,out long u);
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool QueryFullProcessImageName(IntPtr h,uint f,StringBuilder p,ref uint n);
    [DllImport("kernel32.dll",SetLastError=true)] static extern uint WaitForSingleObject(IntPtr h,uint ms);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetExitCodeProcess(IntPtr h,out uint code);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool CloseHandle(IntPtr h);
    [DllImport("advapi32.dll",SetLastError=true)] static extern bool OpenProcessToken(IntPtr h,uint access,out IntPtr token);
    [DllImport("advapi32.dll",SetLastError=true)] static extern bool GetTokenInformation(IntPtr t,int kind,IntPtr b,uint n,out uint needed);
    [DllImport("shell32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr CommandLineToArgvW(string s,out int n);
    [DllImport("kernel32.dll")] static extern IntPtr LocalFree(IntPtr h);
    const uint Access=0x101000; // PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE
    public sealed class Fact {
        public string CaptureSource,IdentityStatus,Image,Sha256,Sid,Role,CommandStatus,ParentLink;
        public uint Pid,ParentPid; public long CreationFiletime,ParentCreationFiletime;
        public string ParentImage,ParentSid,WaitStatus,ExitStatus,CloseStatus;
        public uint? ActualWait,ActualExitCode; public string[] ExactCandidateArgv;
        internal IntPtr Held;
    }
    public sealed class Report {
        public string Scope="ORIGINAL_HELD_PROCESS_FACTS_NOT_PRODUCT_SETTLEMENT";
        public bool WmiStarted,MissesPossible=true,Closed;
        public string[] Errors; public Fact[] Processes;
    }
    readonly object sync=new object(), lifetime=new object();int activeCaptures;readonly List<Fact> facts=new List<Fact>();readonly List<string> errors=new List<string>();
    readonly string expectedHash,user,fixedFile,installer;readonly int expectedBytes;
    readonly long startFiletime;readonly Stopwatch clock=Stopwatch.StartNew();readonly int limitMs;
    ManagementEventWatcher watcher;Timer timer;bool closed,stopping,wmiStarted,closeFault;int polling;
    static void Need(bool v,string s) { if(!v) throw new InvalidOperationException(s); }
    static Exception Error(string s) { return new Win32Exception(Marshal.GetLastWin32Error(),s); }
    static string Hex(byte[] b) { return BitConverter.ToString(b).Replace("-","").ToLowerInvariant(); }
    void RecordError(string s) { if(errors.Count<64) errors.Add(s); }
    void Close(ref IntPtr h,string stage) {
        if(h==IntPtr.Zero)return;IntPtr original=h;h=IntPtr.Zero;
        if(!CloseHandle(original)) { closeFault=true;throw Error(stage+":unknown_close_never_retry"); }
    }
    static long Creation(IntPtr h) { long c,x,k,u;if(!GetProcessTimes(h,out c,out x,out k,out u))throw Error("creation");return c; }
    static string Image(IntPtr h) {
        StringBuilder b=new StringBuilder(32768);uint n=32768;
        if(!QueryFullProcessImageName(h,0,b,ref n))throw Error("image");return b.ToString();
    }
    string Sid(IntPtr h) {
        IntPtr t=IntPtr.Zero,b=IntPtr.Zero;
        try {
            if(!OpenProcessToken(h,8,out t))throw Error("token_query");uint n;
            GetTokenInformation(t,1,IntPtr.Zero,0,out n);int e=Marshal.GetLastWin32Error();
            Need(e==122&&n>=IntPtr.Size&&n<=4096,"bounded_token_user");b=Marshal.AllocHGlobal((int)n);
            if(!GetTokenInformation(t,1,b,n,out n))throw Error("token_user");
            return new SecurityIdentifier(Marshal.ReadIntPtr(b)).Value;
        } finally { if(b!=IntPtr.Zero)Marshal.FreeHGlobal(b);Close(ref t,"token"); }
    }
    string Hash(string image) {
        // Does not block MSI image retirement: all normal sharing allowed; exact
        // bytes are compared to the final read-back embedded helper overlay image.
        using(FileStream f=new FileStream(image,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete)) {
            Need(f.Length==expectedBytes,"candidate_image_length");
            using(SHA256 s=SHA256.Create())return Hex(s.ComputeHash(f));
        }
    }
    string[] Argv(string command) {
        int n;IntPtr b=CommandLineToArgvW(command,out n);if(b==IntPtr.Zero)throw Error("argv");
        try { Need(n>=1&&n<=4,"bounded_helper_argv");string[] r=new string[n];
            for(int j=0;j<n;j++) { r[j]=Marshal.PtrToStringUni(Marshal.ReadIntPtr(b,j*IntPtr.Size));Need(r[j]!=null&&r[j].Length<=32768,"bounded_arg"); }return r;
        } finally { if(LocalFree(b)!=IntPtr.Zero) { closeFault=true;throw new InvalidOperationException("argv_LocalFree_unknown"); } }
    }
    // WMI CommandLine is read only AFTER OS handle/image/hash/token checks. The
    // WMI CreationDate is matched to that original handle (microsecond precision).
    static ManagementObjectCollection GetRows(ManagementObjectSearcher q) { q.Options.Timeout=TimeSpan.FromSeconds(2);return q.Get(); }
    void Command(Fact f) {
        f.CommandStatus="UNKNOWN_NO_ORIGINAL_WMI_INSTANCE";f.Role="UNKNOWN";
        using(ManagementObjectSearcher q=new ManagementObjectSearcher("SELECT ProcessId,ParentProcessId,CreationDate,CommandLine FROM Win32_Process WHERE ProcessId="+f.Pid.ToString(CultureInfo.InvariantCulture)))
        using(ManagementObjectCollection rows=GetRows(q)) {
            foreach(ManagementObject m in rows) using(m) {
                string d=m["CreationDate"] as string, cmd=m["CommandLine"] as string;
                if(d==null||cmd==null)continue;long c=ManagementDateTimeConverter.ToDateTime(d).ToUniversalTime().ToFileTimeUtc();
                if(Math.Abs(c-f.CreationFiletime)>9)continue;
                Need(cmd.Length<=32768,"bounded_original_command");string[] a=Argv(cmd);
                Need(String.Equals(a[0],f.Image,StringComparison.OrdinalIgnoreCase),"original_argv0_image");
                f.ParentPid=Convert.ToUInt32(m["ParentProcessId"],CultureInfo.InvariantCulture);
                string role="UNKNOWN";uint txn;
                if(a.Length==3&&a[1]=="begin"&&String.Equals(a[2],fixedFile,StringComparison.OrdinalIgnoreCase))role="begin";
                else if(a.Length==2&&(a[1]=="broker"||a[1]=="commit"||a[1]=="rollback"))role=a[1];
                else if(a.Length==3&&a[2]=="guardian"&&UInt32.TryParse(a[1],NumberStyles.None,CultureInfo.InvariantCulture,out txn)&&txn!=0)role="guardian";
                f.Role=role;f.ExactCandidateArgv=a;f.CommandStatus="EXACT_CREATION_MATCHED_WMI_FACT_ONLY";break;
            }
        }
    }
    void Parent(Fact f) {
        f.ParentLink="UNKNOWN";
        if(f.ParentPid==0)return;
        foreach(Fact old in facts) if(old.Pid==f.ParentPid&&old.CreationFiletime<=f.CreationFiletime&&old.Role=="begin"&&f.Role=="broker") {
            if(old.Held==IntPtr.Zero)continue;long c,x,k,u;uint w=WaitForSingleObject(old.Held,0);
            if(!GetProcessTimes(old.Held,out c,out x,out k,out u) || c!=old.CreationFiletime || (w!=0&&w!=258) || (w==0&&x<f.CreationFiletime))continue;
            f.ParentCreationFiletime=old.CreationFiletime;f.ParentImage=old.Image;f.ParentSid=old.Sid;f.ParentLink="HELD_ORIGINAL_BEGIN_INSTANCE";return;
        }
        IntPtr h=OpenProcess(Access,false,f.ParentPid);if(h==IntPtr.Zero)return;
        try {
            long c=Creation(h);string image=Image(h),sid=Sid(h);
            Need(c<=f.CreationFiletime,"parent_born_after_child");
            string win=Environment.GetFolderPath(Environment.SpecialFolder.Windows);
            bool engine=String.Equals(image,Path.Combine(win,@"System32\msiexec.exe"),StringComparison.OrdinalIgnoreCase)||String.Equals(image,Path.Combine(win,@"SysWOW64\msiexec.exe"),StringComparison.OrdinalIgnoreCase);
            if((f.Role=="begin"||f.Role=="guardian"||f.Role=="commit"||f.Role=="rollback")&&engine&&(sid==user||sid=="S-1-5-18")) {
                f.ParentCreationFiletime=c;f.ParentImage=image;f.ParentSid=sid;f.ParentLink="ORIGINAL_ENGINE_INSTANCE_FACT_NOT_SESSION_ID";
            }
        } finally { Close(ref h,"parent_query"); }
    }
    void Capture(uint pid,string source) {
        // Called immediately from ProcessStartTrace callback; original OpenProcess
        // occurs before slow hash/WMI work. Shared service is never a candidate.
        lock(lifetime) { if(stopping||closed)return;activeCaptures++; }
        IntPtr h=IntPtr.Zero;
        try {
            h=OpenProcess(Access,false,pid);if(h==IntPtr.Zero)return;
            lock(sync) {
                if(closed||stopping||clock.ElapsedMilliseconds>limitMs||closeFault)return;
                long c=Creation(h);if(c<startFiletime)return;
                foreach(Fact old in facts)if(old.Pid==pid&&old.CreationFiletime==c)return;
                string image=Image(h);
                if(!String.Equals(Path.GetDirectoryName(image),installer,StringComparison.OrdinalIgnoreCase)||!Regex.IsMatch(Path.GetFileName(image),@"\AMSI[0-9a-f]{1,8}\.tmp\z",RegexOptions.IgnoreCase|RegexOptions.CultureInvariant))return;
                string hash=Hash(image);if(hash!=expectedHash)return;
                string sid=Sid(h);if(sid!=user)return;
                Need(facts.Count<32,"bounded_original_candidate_count");
                Fact f=new Fact();f.Pid=pid;f.CreationFiletime=c;f.Image=image;f.Sha256=hash;f.Sid=sid;f.CaptureSource=source;f.IdentityStatus="ORIGINAL_QUERY_SYNC_HANDLE_EXACT_IMAGE_BYTES_USER";
                f.Held=h;h=IntPtr.Zero;facts.Add(f);
                try { Command(f);Parent(f); } catch(Exception e) { RecordError("candidate_metadata:"+pid+":"+e.GetType().Name+":"+e.Message); }
            }
        } catch(Exception e) { lock(sync)RecordError("capture:"+pid+":"+e.GetType().Name+":"+e.Message); }
        finally { try { try { Close(ref h,"uncaptured_original"); } catch(Exception e) { lock(sync)RecordError(e.Message); } } finally { lock(lifetime) { activeCaptures--;Monitor.PulseAll(lifetime); } } }
    }
    void Poll(object ignored) {
        if(closed||stopping||clock.ElapsedMilliseconds>limitMs||Interlocked.Exchange(ref polling,1)!=0)return;
        try {
            // Names only, then original-handle image/hash/token filtering; no foreign CLI.
            Process[] ps=Process.GetProcesses();
            foreach(Process p in ps) using(p) {
                try { if(Regex.IsMatch(p.ProcessName,@"\AMSI[0-9a-f]{1,8}(?:\.tmp)?\z",RegexOptions.IgnoreCase|RegexOptions.CultureInvariant))Capture((uint)p.Id,"10MS_NAME_POLL"); }
                catch(Exception e) { lock(sync)RecordError("poll_candidate:"+e.GetType().Name); }
            }
        } catch(Exception e) { lock(sync)RecordError("poll_enumeration:"+e.GetType().Name); }
        finally { Interlocked.Exchange(ref polling,0); }
    }
    public FcR76ProcessObserver(string embeddedImageSha256,int embeddedImageBytes,string expectedUserSid,int phaseMaximumMs) {
        Need(Regex.IsMatch(embeddedImageSha256??"",@"\A[0-9a-f]{64}\z")&&embeddedImageBytes>0&&embeddedImageBytes<=40*1024*1024,"explicit_actual_overlay_identity");
        Need(phaseMaximumMs>0&&phaseMaximumMs<=150000,"phase_original_finite_budget");
        using(WindowsIdentity own=WindowsIdentity.GetCurrent())Need(own.User.Value==expectedUserSid,"observer_original_user");
        expectedHash=embeddedImageSha256;expectedBytes=embeddedImageBytes;user=expectedUserSid;limitMs=phaseMaximumMs;startFiletime=DateTime.UtcNow.ToFileTimeUtc();
        installer=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),"Installer");
        fixedFile=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),@"Programs\FutureClassroom\fc-bootstrap.exe");
        watcher=new ManagementEventWatcher(new WqlEventQuery("SELECT * FROM Win32_ProcessStartTrace WHERE ProcessName LIKE 'MSI%.tmp'"));
        watcher.EventArrived+=delegate(object sender,EventArrivedEventArgs e) {
            try { Capture(Convert.ToUInt32(e.NewEvent["ProcessID"],CultureInfo.InvariantCulture),"PROCESS_START_TRACE"); }
            catch(Exception x) { lock(sync)RecordError("wmi_callback:"+x.GetType().Name); }
        };
        try { watcher.Start();wmiStarted=true;timer=new Timer(Poll,null,0,10); }
        catch { watcher.Dispose();throw; } // caller MUST abort before msiexec if setup fails
    }
    void Refresh(Fact f) {
        if(f.Held==IntPtr.Zero)return;
        uint w=WaitForSingleObject(f.Held,0);f.ActualWait=w;
        if(w==0) {
            uint exit;if(!GetExitCodeProcess(f.Held,out exit)) { f.ExitStatus="UNKNOWN_GET_EXIT_ERROR_"+Marshal.GetLastWin32Error();return; }
            f.WaitStatus="ORIGINAL_OBJECT_SIGNALED";f.ActualExitCode=exit;f.ExitStatus="ACTUAL_ORIGINAL_GET_EXIT_CODE";
        } else { f.WaitStatus=w==258?"ORIGINAL_OBJECT_STILL_RUNNING":"UNKNOWN_WAIT_ERROR_"+Marshal.GetLastWin32Error();f.ExitStatus="UNKNOWN"; }
    }
    public Report Snapshot() { lock(sync) {
        foreach(Fact f in facts)Refresh(f);
        Report r=new Report();r.WmiStarted=wmiStarted;r.Closed=closed;r.Errors=errors.ToArray();r.Processes=facts.ToArray();return r;
    } }
    public Report FinishAndClose() {
        lock(lifetime)stopping=true;
        if(timer!=null) { timer.Change(Timeout.Infinite,Timeout.Infinite);timer.Dispose();timer=null; }
        // Stop watcher before taking sync, so a callback cannot deadlock Stop.
        try { if(watcher!=null) { watcher.Stop();watcher.Dispose();watcher=null; } }
        catch(Exception e) { lock(sync)RecordError("watcher_stop:"+e.GetType().Name); }
        lock(lifetime) {
            while(activeCaptures!=0) {
                int remaining=limitMs-(int)clock.ElapsedMilliseconds;
                if(remaining<=0)throw new InvalidOperationException("UNKNOWN_CALLBACKS_NOT_DRAINED_RETAIN_HELD_HANDLES");
                Monitor.Wait(lifetime,Math.Min(remaining,5000));
            }
        }
        lock(sync) {
            if(!closed)foreach(Fact f in facts) { Refresh(f);try { Close(ref f.Held,"original_process");f.CloseStatus="CHECKED_CLOSE_SUCCESS"; }catch(Exception e) { f.CloseStatus="UNKNOWN_CLOSE_NOT_RETRIED";RecordError(e.Message); } }
            closed=true;Report r=new Report();r.WmiStarted=wmiStarted;r.Closed=closed;r.Errors=errors.ToArray();r.Processes=facts.ToArray();return r;
        }
    }
}
