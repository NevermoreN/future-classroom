# R77 supervisor/real-child Join fixture authoring

Preparation only; actual PS5.1 parsing, COM build, installation and child Join are NOT_RUN.

Run only through Root's owned Windows transport:

```
& <root>\New-SupervisorChainerFixture.ps1 -Execute -HelperExe <root>\helper.exe -MsiPath <root>\fixture.msi -Root <root> -ProductCode <uppercase-braced-guid> -UpgradeCode <distinct-uppercase-braced-guid> -ComponentId <third-distinct-uppercase-braced-guid> -Nonce <32lowerhex>
```

Root is `FutureClassroom-r77-supervisor-chainer-<nonce>` with current-user owner,
protected user+SYSTEM FullControl DACL and `.owner` exact LF-terminated
`future-classroom-owned-r77-supervisor-chainer-fixture/v1`. No reparse ancestor,
production GUID, existing output MSI, helper outside root or non-GUI/x86 helper is accepted.

Only ten closed tables exist: Property, Directory, Component, Feature,
FeatureComponents, Registry, Media, InstallExecuteSequence, Binary,
MsiEmbeddedChainer. There is no CustomAction table, AsyncBegin/Ready action,
Type130, File payload, Upgrade effects or production lifecycle resource.
Media retains all six standard columns and exactly DiskId1/LastSequence0 with
no cabinet. The only effect is HKCU32
`Software\FutureClassroomTest\Round77Supervisor-<nonce>`, Marker DWORD1,
through one RegistryKeyPath4 component and one feature. MsiEmbeddedChainer has
one Type2 row, Binary `SupervisorFixture`, condition `NOT Installed`, and
command `supervisor "<root>" <nonce>`; the engine supplies the actual transaction
before it. On necessary formal /x this condition skips the chainer.

All columns and all nonbinary rows are exported from the reopened read-only
actual COM database and compared against closed authoring; Binary byteBSTR
readback is compared byte-for-byte to original helper, summary remains Intel
MSI500 limited-user, helper source must stay unchanged. Success status remains
`PASS_ACTUAL_COM_BUILT_AND_EXACT_READBACK_FIXTURE_ONLY_NOT_INSTALLED` with
actual helper/MSI facts, tables, columns, summary, product/upgrade/component,
root/nonce/currentUserSid and marker. This is static build success only.

The native MSI APIs must be called by the original spawned guardian-child,
not a supervisor/sentinel substitute. The source-bound supervisor holds the
CreateProcess process object, validates child identity and exact known argv,
waits actual child exit0, and checked-closes before returning. Whether that
child can own this MSI transaction is still an empirical unknown. Preserve
real Join/End/exit integers, all negative evidence, and exact cleanup.
