"""R77 bounded root-only synthetic AsyncWait/embedded-chainer experiment transport.
Default never connects. No remote deletion, product action, process kill or SSH revocation.
"""
from pathlib import Path
import argparse,base64,hashlib,json,re,shutil,subprocess,time,uuid
E=Path('/tmp/fc-round77-installer-cleanup');D=Path(__file__).resolve().parent
HOST='elior@192.168.10.212';KEY='/config/.local/share/future-classroom-test-access/win11-192.168.10.212';SID='S-1-5-21-3896111207-1867804362-1971593122-1001'
BASE='8931fabc0520ac659f9c019f9790e4d4f81ff9a7'
BOOT="[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()))"
COMMON=r'''$ErrorActionPreference='Stop';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Fact($p){$a=[IO.File]::GetAttributes($p);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0 -or ($a-band[IO.FileAttributes]::Directory)-ne0){throw 'REGULAR_NO_REPARSE'};$f=[IO.FileInfo]::new($p);return @{bytes=[long]$f.Length;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function CheckRoot {
 if($c.root-cne(Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) ('Temp\FutureClassroom-r77-async-chainer-'+$c.nonce)) -or $c.nonce-cnotmatch'^[0-9a-f]{32}$'){throw 'EXACT_NONCE_ROOT'}
 $a=[IO.File]::GetAttributes($c.root);if(($a-band[IO.FileAttributes]::Directory)-eq0 -or ($a-band[IO.FileAttributes]::ReparsePoint)-ne0){throw 'ROOT_DIRECTORY_NO_REPARSE'}
 if([IO.File]::ReadAllText((Join-Path $c.root '.owner'))-cne"future-classroom-owned-r77-async-chainer-fixture/v1`n"){throw 'EXACT_OWNER_MARKER'}
 $acl=[IO.Directory]::GetAccessControl($c.root);$rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));if(-not$acl.AreAccessRulesProtected -or $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-cne$c.sid -or $rules.Count-ne2 -or @($rules|Where-Object{$_.IdentityReference.Value-notin@($c.sid,'S-1-5-18') -or $_.AccessControlType-ne'Allow' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count){throw 'PROTECTED_CURRENT_USER_SYSTEM_DACL'}
}
function Inventory {
 CheckRoot;$files=@();$dirs=@();$q=[Collections.Generic.Queue[string]]::new();$q.Enqueue($c.root)
 while($q.Count){$d=$q.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($d)){$a=[IO.File]::GetAttributes($p);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0){throw 'INVENTORY_NO_REPARSE'};$rel=$p.Substring($c.root.Length+1).Replace('\','/');if(($a-band[IO.FileAttributes]::Directory)-ne0){$dirs+=$rel;$q.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256}};if($files.Count-gt128 -or $dirs.Count-gt32){throw 'INVENTORY_BOUND'}}}
 return @{files=$files;directories=$dirs}
}
'''
CREATE=r'''if($PSVersionTable.PSVersion.Major-ne5 -or [IntPtr]::Size-ne8){throw 'PS51_X64_REQUIRED'};$w=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$w.User;if($sid.Value-cne$c.sid){throw 'EXACT_SID'}}finally{$w.Dispose()}
$expected=Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) ('Temp\FutureClassroom-r77-async-chainer-'+$c.nonce);if($expected-cne$c.root -or $c.nonce-cnotmatch'^[0-9a-f]{32}$'){throw 'EXACT_NEW_NONCE_ROOT'}
$cursor=[IO.Path]::GetDirectoryName($expected);while($cursor){$a=[IO.File]::GetAttributes($cursor);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0 -or ($a-band[IO.FileAttributes]::Directory)-eq0){throw 'ANCESTOR_NO_REPARSE'};$cursor=[IO.Path]::GetDirectoryName($cursor)}
try{[void][IO.File]::GetAttributes($expected);throw 'ROOT_ALREADY_EXISTS'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
[void][IO.Directory]::CreateDirectory($expected);$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false);foreach($s in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($s,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))};[IO.Directory]::SetAccessControl($expected,$acl)
$f=[IO.File]::Open((Join-Path $expected '.owner'),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$b=[Text.UTF8Encoding]::new($false).GetBytes("future-classroom-owned-r77-async-chainer-fixture/v1`n");$f.Write($b,0,$b.Length);$f.Flush($true)}finally{$f.Dispose()};CheckRoot
@{status='CREATED_NEW_PROTECTED_NONCE_FIXTURE_ROOT';root=$expected;sid=$c.sid;nonce=$c.nonce;os=(Get-CimInstance Win32_OperatingSystem|Select-Object Caption,Version,BuildNumber,OSArchitecture)}|ConvertTo-Json -Depth 4 -Compress
'''
def need(v,c):
 if not v:raise AssertionError(c)
def sha(b):return hashlib.sha256(b).hexdigest()
def fact(p):
 p=Path(p);need(p.resolve().is_relative_to(E) and p.is_file() and not p.is_symlink(),'OWNED_REGULAR_LOCAL_INPUT');b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def remote(script,c):
 feed=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+COMMON+script).encode();cmd=['ssh','-i',KEY,'-o','BatchMode=yes','-o','ConnectTimeout=8',HOST,'powershell.exe','-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-EncodedCommand',base64.b64encode(BOOT.encode('utf-16-le')).decode()];return cmd,feed
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true')
 for x in ('program-sha256','factory-sha256','driver-sha256'):p.add_argument('--'+x)
 a=p.parse_args()
 if not a.execute:print(json.dumps(dict(status='PREPARED_NOT_RUN',windows='NOT_CONNECTED',scope='No remote scratch cleanup; root reviews actual originals before separate exact cleanup')));return 0
 need((E/'.owner').read_bytes()==b'future-classroom-owned-r77-installer-cleanup/v1\n','EXACT_E_OWNER')
 sources=[(E/'async-fixture-program-first/Program.cs',a.program_sha256),(E/'async-fixture-authoring-second/New-AsyncChainerFixture.ps1',a.factory_sha256),(E/'async-fixture-harness-second/Driver.ps1',a.driver_sha256),(E/'observer-source-first/ProcessObserver.cs','ae5ad0205854e0f2e731394e6f72a0f2481818da1efabf88abeccd716a256b31')]
 facts=[]
 for path,digest in sources:need(re.fullmatch('[0-9a-f]{64}',digest or '') and fact(path)['sha256']==digest,'EXPLICIT_FROZEN_INPUT_SHA');facts.append(fact(path))
 out=E/'async-fixture-runtime-second';need(not out.exists(),'FRESH_LOCAL_OUTPUT');out.mkdir();(out/'.owner').write_text('future-classroom-owned-r77-async-fixture-runtime/v1\n');up=out/'upload';up.mkdir()
 nonce=uuid.uuid4().hex;root=r'C:\Users\Elior\AppData\Local\Temp\FutureClassroom-r77-async-chainer-'+nonce
 cfg=dict(schemaVersion=1,sourceGit=BASE,nonce=nonce,expectedUserSid=SID,productCode='{'+str(uuid.uuid4()).upper()+'}',upgradeCode='{'+str(uuid.uuid4()).upper()+'}',componentId='{'+str(uuid.uuid4()).upper()+'}',registryKey='Software\\FutureClassroomTest\\Round77-'+nonce,rootName=root.split('\\')[-1],wholeSeconds=120,clientMaximumSeconds=30,asyncSeconds=10,readySeconds=2,sources=[dict(path=x.name,bytes=f['bytes'],sha256=f['sha256']) for (x,_),f in zip(sources,facts)])
 for path,_ in sources:shutil.copyfile(path,up/path.name)
 config=up/'config.json';config.write_text(json.dumps(cfg,indent=2)+'\n');members=[]
 for path in sorted(up.iterdir()):f=fact(path);members.append(dict(path=path.name,bytes=f['bytes'],sha256=f['sha256']))
 manifest=up/'inputs.json';manifest.write_text(json.dumps(dict(files=members),indent=2)+'\n');c=dict(root=root,nonce=nonce,sid=SID,configSha=fact(config)['sha256'],manifestSha=fact(manifest)['sha256'])
 report=out/'report.json';v=dict(status='RUNNING',scope='Independent .NET x86 registry-only MSI fixture on current authorized Win11; no product helper or school data run.',sourceInputs=facts,config=cfg,remote=c,operations=[],scratchCleanup='NOT_PERFORMED_ROOT_REVIEWS_ORIGINALS_FIRST');started=time.monotonic();created=False;returned=False
 def save():report.write_text(json.dumps(v,indent=2)+'\n')
 def call(name,cmd,feed=None,limit=20):
  remaining=300-(time.monotonic()-started);need(remaining>0,'OUTER_ORIGINAL_300S_EXHAUSTED');beg=time.monotonic();proc=subprocess.Popen(cmd,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE);timed=False
  try:stdout,stderr=proc.communicate(feed,timeout=min(limit,remaining))
  except subprocess.TimeoutExpired:timed=True;proc.kill();stdout,stderr=proc.communicate()
  row=dict(name=name,command=cmd,pid=proc.pid,actualExit=True,exitCode=proc.returncode,reaped=True,timedOut=timed,elapsedSeconds=time.monotonic()-beg)
  for label,data in [('stdout',stdout),('stderr',stderr)]+([('stdin',feed)] if feed is not None else []):path=out/(name+'.'+label+'.log');path.write_bytes(data);row[label]=fact(path)
  v['operations'].append(row);save();return proc.returncode,stdout,not timed
 save()
 try:
  cmd,feed=remote(CREATE,c);code,stdout,natural=call('01-new-protected-root',cmd,feed);need(natural and code==0,'CREATE_ACTUAL_EXIT0');before=json.loads(stdout);need(before['root']==root and before['sid']==SID and before['nonce']==nonce,'EXACT_NEW_ROOT');v['beforeCreate']=before;created=True
  cmd=['scp','-q','-i',KEY,'-o','BatchMode=yes','-o','ConnectTimeout=8',*[str(x) for x in sorted(up.iterdir())],HOST+':'+root.replace('\\','/')+'/'];code,_,natural=call('02-upload-frozen-source-config',cmd,limit=60);need(natural and code==0,'UPLOAD_ACTUAL_EXIT0')
  script="CheckRoot;$global:LASTEXITCODE=0;& (Join-Path $c.root 'Driver.ps1') -Execute -Root $c.root -ConfigSha256 $c.configSha -ManifestSha256 $c.manifestSha;exit $LASTEXITCODE"
  cmd,feed=remote(script,c);code,stdout,natural=call('03-original-fixture-driver',cmd,feed,140);returned=natural;v['driverActualExit']=code;need(natural and code in (0,1),'DRIVER_RETURN_UNKNOWN_RETAIN');v['driverResult']=json.loads(stdout);v['status']='EVIDENCE_COLLECTED_AWAIT_ROOT_REVIEW'
 except Exception as error:v.update(status='FAIL_TRANSPORT_OR_DRIVER_CAPTURE',errorType=type(error).__name__,reason=str(error) if isinstance(error,AssertionError) else 'TRANSPORT_OR_CAPTURE_ERROR')
 finally:
  if created and returned:
   try:
    cmd,feed=remote('Inventory|ConvertTo-Json -Depth 10 -Compress',c);code,stdout,natural=call('90-post-parent-inventory',cmd,feed);need(natural and code==0,'INVENTORY_ACTUAL_EXIT0');inventory=json.loads(stdout);v['remoteInventory']=inventory
    for row in inventory['files']:need(re.fullmatch('[0-9a-f]{64}',row['sha256']) and type(row['bytes']) is int and row['bytes']>=0 and all(x not in ('','.','..') for x in row['path'].split('/')) and '\\' not in row['path'] and ':' not in row['path'],'SAFE_EXACT_INVENTORY')
    local=out/'download';local.mkdir();cmd=['scp','-q','-r','-i',KEY,'-o','BatchMode=yes','-o','ConnectTimeout=8',HOST+':'+root.replace('\\','/'),str(local)+'/'];code,_,natural=call('91-download-all-originals',cmd,limit=30);need(natural and code==0,'DOWNLOAD_ACTUAL_EXIT0');download=local/cfg['rootName'];actual={};dirs=set()
    for path in download.rglob('*'):
     need(not path.is_symlink(),'DOWNLOAD_NO_SYMLINK');rel=path.relative_to(download).as_posix()
     if path.is_dir():dirs.add(rel)
     else:f=fact(path);actual[rel]=dict(path=rel,bytes=f['bytes'],sha256=f['sha256'])
    need(actual=={x['path']:x for x in inventory['files']} and dirs==set(inventory['directories']),'DOWNLOAD_EXACT_EACH_BYTE_AND_MEMBERSHIP')
    for x in members+[dict(path='inputs.json',bytes=fact(manifest)['bytes'],sha256=fact(manifest)['sha256'])]:need(actual[x['path']]==x,'UPLOADED_INPUT_UNCHANGED')
    v['downloadVerified']=True
   except Exception as error:v.update(status='FAIL_ORIGINAL_DOWNLOAD_OR_MEMBERSHIP',captureErrorType=type(error).__name__,captureErrorCode=str(error) if isinstance(error,AssertionError) else 'CAPTURE_ERROR')
  elif created:v['remoteDriverState']='UNKNOWN_RETAIN_ALL_NO_FOLLOWUP_QUERY'
  v['sourceUnchanged']=facts==[fact(x) for x,_ in sources];v['elapsedSeconds']=time.monotonic()-started;save()
 print(json.dumps(dict(status=v['status'],report=fact(report),scratchCleanup=v['scratchCleanup'])));return 0 if v['status']=='EVIDENCE_COLLECTED_AWAIT_ROOT_REVIEW' and v.get('downloadVerified') and v['sourceUnchanged'] else 1
if __name__=='__main__':raise SystemExit(main())
