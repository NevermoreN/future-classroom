fn main() { std::panic::set_hook(Box::new(|_| {})); let outcome = std::panic::catch_unwind(|| panic!("owned synthetic unwind diagnostic")); std::process::exit(if outcome.is_err() {0} else {41}); }
