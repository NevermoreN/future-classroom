from pathlib import Path
import runpy,json,subprocess,hashlib,time
E=Path('/tmp/fc-round77-installer-cleanup');D=E/'unwind-linker-diagnostic-first';v=json.loads((D/'windows-first.json').read_text());c=v['remote'];m=runpy.run_path(str(E/'supervisor-transport-preparation-second/run-fixture-second.py'));m['remote'].__globals__['COMMON']=m['COMMON'].replace('supervisor-chainer','unwind');O=D/'cleanup-first.json';assert not O.exists();r={'status':'RUNNING','operations':[]}
def call(name,cmd,feed=None):
 t=time.monotonic();p=subprocess.run(cmd,input=feed,capture_output=True,timeout=30);row={'name':name,'actualExit':True,'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-t,'command':cmd}
 for lab,b in [('stdout',p.stdout),('stderr',p.stderr)]+([('stdin',feed)] if feed else []):
  f=D/(name+'.'+lab+'.log');f.write_bytes(b);row[lab]={'path':str(f),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 r['operations'].append(row);O.write_text(json.dumps(r,indent=2)+'\n');assert p.returncode==0,(name,p.stderr.decode(errors='replace'));return p.stdout
cmd,feed=m['remote']("CheckRoot;$live=@(Get-CimInstance Win32_Process|Where-Object{$_.ExecutablePath -and $_.ExecutablePath.StartsWith($c.root+'\\',[StringComparison]::OrdinalIgnoreCase)});if($live.Count){throw 'OWN_DIAGNOSTIC_STILL_LIVE'};Inventory|ConvertTo-Json -Depth 8 -Compress",c);inv=json.loads(call('05-exact-inventory',cmd,feed));r['inventory']=inv
local=D/'download';local.mkdir();cmd=['scp','-q','-r','-i',m['KEY'],'-o','BatchMode=yes','-o','ConnectTimeout=8',m['HOST']+':'+c['root'].replace('\\','/'),str(local)+'/'];call('06-all-originals',cmd);root=local/Path(c['root'].replace('\\','/')).name;actual={}
for p in root.rglob('*'):
 assert not p.is_symlink()
 if p.is_file():
  b=p.read_bytes();actual[p.relative_to(root).as_posix()]={'path':p.relative_to(root).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert actual=={f['path']:f for f in inv['files']};r['downloadVerified']=True;c['inventory']=inv
script=r'''CheckRoot;$live=@(Get-CimInstance Win32_Process|Where-Object{$_.ExecutablePath -and $_.ExecutablePath.StartsWith($c.root+'\',[StringComparison]::OrdinalIgnoreCase)});if($live.Count){throw 'OWN_DIAGNOSTIC_STILL_LIVE'};$now=Inventory;if($now.files.Count-ne$c.inventory.files.Count-or$now.directories.Count-ne$c.inventory.directories.Count){throw 'MEMBERSHIP_CHANGED'};foreach($f in $now.files){$old=@($c.inventory.files|Where-Object{$_.path-ceq$f.path});if($old.Count-ne1-or$old[0].bytes-ne$f.bytes-or$old[0].sha256-cne$f.sha256){throw 'BYTES_CHANGED'}};foreach($d in $now.directories){if($d-cnotin$c.inventory.directories){throw 'DIR_CHANGED'}};foreach($f in $c.inventory.files){[IO.File]::Delete((Join-Path $c.root ($f.path.Replace('/','\'))))};foreach($d in @($c.inventory.directories|Sort-Object Length -Descending)){[IO.Directory]::Delete((Join-Path $c.root ($d.Replace('/','\'))),$false)};[IO.Directory]::Delete($c.root,$false);if([IO.Directory]::Exists($c.root)){throw 'ROOT_REMAINS'};@{status='PASS_EXACT_OWN_DIAGNOSTIC_SCRATCH_REMOVED';files=$c.inventory.files.Count;rootAbsent=$true;processesBeforeCleanup=0;msiOrServiceActivity=$false}|ConvertTo-Json -Compress'''
cmd,feed=m['remote'](script,c);r['actual']=json.loads(call('07-exact-remove',cmd,feed));r['status']='PASS';O.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r['actual']))
