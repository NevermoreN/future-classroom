from pathlib import Path
import json,hashlib,runpy,re,subprocess,time,uuid
E=Path('/tmp/fc-round77-installer-cleanup');D=E/'unwind-linker-diagnostic-first';O=D/'windows-first.json';assert not O.exists()
m=runpy.run_path(str(E/'supervisor-transport-preparation-second/run-fixture-second.py'));g=m['remote'].__globals__;g['COMMON']=m['COMMON'].replace('supervisor-chainer','unwind');create=m['CREATE'].replace('supervisor-chainer','unwind')
nonce=uuid.uuid4().hex;c={'nonce':nonce,'sid':m['SID'],'root':r'C:\Users\Elior\AppData\Local\Temp\FutureClassroom-r77-unwind-'+nonce}
def sha(b):return hashlib.sha256(b).hexdigest()
v={'status':'RUNNING','scope':'Two same-source minimal panic/catch_unwind CUI programs; no product MSI, app or registry activity.','remote':c,'operations':[]}
def call(name,cmd,feed=None,timeout=30):
 t=time.monotonic();p=subprocess.run(cmd,input=feed,capture_output=True,timeout=timeout);r={'name':name,'command':cmd,'actualExit':True,'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-t}
 for label,b in [('stdout',p.stdout),('stderr',p.stderr)]+([('stdin',feed)] if feed else []):
  f=D/(name+'.'+label+'.log');f.write_bytes(b);r[label]={'path':str(f),'bytes':len(b),'sha256':sha(b)}
 v['operations'].append(r);O.write_text(json.dumps(v,indent=2)+'\n');assert p.returncode==0,(name,p.stderr.decode(errors='replace'));return p.stdout
cmd,feed=m['remote'](create,c);v['created']=json.loads(call('01-create',cmd,feed))
inputs=[]
for name in ['gcc','lld']:
 f=D/(name+'.exe');b=f.read_bytes();inputs.append({'name':name,'bytes':len(b),'sha256':sha(b)})
cmd=['scp','-q','-i',m['KEY'],'-o','BatchMode=yes','-o','ConnectTimeout=8',str(D/'gcc.exe'),str(D/'lld.exe'),m['HOST']+':'+c['root'].replace('\\','/')+'/'];call('02-upload',cmd)
source=(E/'supervisor-fixture-harness-first/Driver.ps1').read_text();native=re.search(r"\$nativeSource=@'\n(.*?)\n'@",source,re.S).group(1)
script="CheckRoot;$t=$env:TEMP;$u=$env:TMP;$r=[ordered]@{status='FAIL';results=@()};try{$tmp=Join-Path $c.root 'compiler-temp';[IO.Directory]::CreateDirectory($tmp)|Out-Null;$env:TEMP=$tmp;$env:TMP=$tmp;Add-Type -TypeDefinition @'\n"+native+"\n'@\n$inputs='"+json.dumps(inputs,separators=(',',':'))+"'|ConvertFrom-Json;foreach($f in $inputs){$path=Join-Path $c.root ($f.name+'.exe');$actual=Fact $path;if($actual.bytes-ne$f.bytes-or$actual.sha256-cne$f.sha256){throw 'EXACT_COMPILED_INPUT'};$p=[FcR77FixtureNative]::Start($path,'');if(-not$p.ThreadCloseSuccess-or$p.CreationFiletime-le0){throw 'ORIGINAL_LAUNCH_UNKNOWN'};$clock=[Diagnostics.Stopwatch]::StartNew();do{$p.Refresh();if($p.ActualWait-eq0){break};if($clock.ElapsedMilliseconds-ge5000){throw 'ORIGINAL_DIAGNOSTIC_PROCESS_NOT_RETURNED'};Start-Sleep -Milliseconds 10}while($true);$p.CloseReturned();$r.results+=@{name=$f.name;actual=$p;image=$actual}};$r.status='PASS_ACTUAL_FINITE_PROCESS_RESULTS_CAPTURED'}catch{$r.error=$_.Exception.Message}finally{$env:TEMP=$t;$env:TMP=$u};$r|ConvertTo-Json -Depth 12 -Compress;if($r.status-cne'PASS_ACTUAL_FINITE_PROCESS_RESULTS_CAPTURED'){exit 1}"
cmd,feed=m['remote'](script,c);v['actual']=json.loads(call('03-native-original-process-run',cmd,feed));assert all(r['actual']['ActualWait']==0 and r['actual']['ProcessCloseSuccess'] for r in v['actual']['results'])
cmd,feed=m['remote']('Inventory|ConvertTo-Json -Depth 8 -Compress',c);v['inventory']=json.loads(call('04-inventory',cmd,feed));v['status']='PASS_FINITE_DIAGNOSTIC_RESULTS_NOT_PRODUCT_FIX';O.write_text(json.dumps(v,indent=2)+'\n');print(json.dumps({'status':v['status'],'results':[(r['name'],r['actual']['ActualExitCode']) for r in v['actual']['results']],'root':c['root']}))
