from pathlib import Path
import runpy,json,subprocess,time,hashlib
E=Path('/tmp/fc-round77-installer-cleanup');D=E/'unwind-linker-diagnostic-first';v=json.loads((D/'windows-first.json').read_text());m=runpy.run_path(str(E/'supervisor-transport-preparation-second/run-fixture-second.py'));m['remote'].__globals__['COMMON']=m['COMMON'].replace('supervisor-chainer','unwind');c=v['remote'];c['imageSha']=hashlib.sha256((D/'lld.exe').read_bytes()).hexdigest()
script=r'''CheckRoot
$old=$env:TEMP;$old2=$env:TMP;$env:TEMP=Join-Path $c.root 'compiler-temp';$env:TMP=$env:TEMP
try{Add-Type -TypeDefinition @'
using System;using System.ComponentModel;using System.Runtime.InteropServices;using System.Text;using System.Security.Principal;
public static class FcOwnedDiagnosticStop {
[DllImport("kernel32.dll",SetLastError=true)]static extern IntPtr OpenProcess(uint a,bool i,uint p);
[DllImport("kernel32.dll",SetLastError=true)]static extern bool CloseHandle(IntPtr h);
[DllImport("kernel32.dll",SetLastError=true)]static extern bool GetProcessTimes(IntPtr h,out long c,out long e,out long k,out long u);
[DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]static extern bool QueryFullProcessImageName(IntPtr h,uint f,StringBuilder b,ref uint n);
[DllImport("advapi32.dll",SetLastError=true)]static extern bool OpenProcessToken(IntPtr p,uint a,out IntPtr t);
[DllImport("kernel32.dll",SetLastError=true)]static extern bool TerminateProcess(IntPtr h,uint e);
[DllImport("kernel32.dll",SetLastError=true)]static extern uint WaitForSingleObject(IntPtr h,uint m);
[DllImport("kernel32.dll",SetLastError=true)]static extern bool GetExitCodeProcess(IntPtr h,out uint e);
public sealed class Fact{public uint Pid,Wait,Exit;public long Creation;public string Image,Sid;public bool Terminated,TokenClose,ProcessClose;}
static void Need(bool b,string s){if(!b)throw new InvalidOperationException(s);}
public static Fact Stop(uint pid,string path,string sid){IntPtr h=OpenProcess(0x00101001,false,pid);Need(h!=IntPtr.Zero,"OpenOwnedDiagnostic");var f=new Fact{Pid=pid};IntPtr t=IntPtr.Zero;try{long e,k,u;Need(GetProcessTimes(h,out f.Creation,out e,out k,out u),"times");var b=new StringBuilder(32768);uint n=32768;Need(QueryFullProcessImageName(h,0,b,ref n),"image");f.Image=b.ToString();Need(String.Equals(f.Image,path,StringComparison.OrdinalIgnoreCase),"exact_owned_path");Need(OpenProcessToken(h,8,out t),"token");using(var w=new WindowsIdentity(t)){f.Sid=w.User.Value;}f.TokenClose=CloseHandle(t);t=IntPtr.Zero;Need(f.TokenClose&&f.Sid==sid,"exact_sid_close");f.Wait=WaitForSingleObject(h,0);if(f.Wait==258){Need(TerminateProcess(h,1977),"terminate_only_owned_expired_diagnostic");f.Terminated=true;f.Wait=WaitForSingleObject(h,5000);}Need(f.Wait==0&&GetExitCodeProcess(h,out f.Exit),"original_return");}finally{if(t!=IntPtr.Zero)Need(CloseHandle(t),"unknown_token_close");f.ProcessClose=CloseHandle(h);Need(f.ProcessClose,"unknown_process_close");}return f;}
}
'@
$path=Join-Path $c.root 'lld.exe';if((Fact $path).sha256-cne$c.imageSha){throw 'ORIGINAL_DIAGNOSTIC_IMAGE_SHA'};$p=@(Get-CimInstance Win32_Process|Where-Object{$_.ExecutablePath-ieq$path});if($p.Count-gt1){throw 'NONUNIQUE_DIAGNOSTIC_PROCESS'};$stops=@();foreach($x in $p){$stops+=[FcOwnedDiagnosticStop]::Stop([uint32]$x.ProcessId,$path,$c.sid)};@{status='PASS_OWN_EXPIRED_DIAGNOSTIC_RETIREMENT_NOT_NATURAL_SUCCESS';results=$stops;originalNaturalExit='UNKNOWN_AFTER_FIRST_5S';scope='Only source-hash/SID/path-bound nonce diagnostic executable; no MSI/service/other process termination'}|ConvertTo-Json -Depth 8 -Compress
}finally{$env:TEMP=$old;$env:TMP=$old2}'''
cmd,feed=m['remote'](script,c);t=time.monotonic();p=subprocess.run(cmd,input=feed,capture_output=True,timeout=30);o={'actualExit':True,'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-t,'command':cmd}
for lab,b in [('stdin',feed),('stdout',p.stdout),('stderr',p.stderr)]:
 f=D/('stop-owned-lld-first.'+lab+'.log');f.write_bytes(b);o[lab]={'path':str(f),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
if p.returncode==0:o['actual']=json.loads(p.stdout)
(D/'stop-owned-lld-first.json').write_text(json.dumps(o,indent=2)+'\n');print(p.stdout.decode());print(p.stderr.decode() if p.returncode else '');raise SystemExit(p.returncode)
