"""Source/model checks only; not PowerShell parsing, COM or installation."""
from pathlib import Path
import re,json
s=Path(__file__).with_name('New-AsyncChainerFixture.ps1').read_text();checks=[]
def ck(name,v):
 if not v:raise AssertionError(name)
 checks.append(name)
tables=re.findall(r"'CREATE TABLE `([^`]+)`",s)
expected={'Property','Directory','Component','Feature','FeatureComponents','Registry','InstallExecuteSequence','CustomAction','Binary','MsiEmbeddedChainer'}
ck('closed-exact-ten-ddl-tables',len(tables)==10 and set(tables)==expected)
ck('no-effects-other-than-synthetic-registry','File' not in tables and all(x not in tables for x in ('ServiceInstall','ServiceControl','Environment','RemoveRegistry','RemoveFile','Shortcut')))
ck('type130-asyncwait-no-ignore',"Add 'CustomAction' @('AsyncBegin',[int]130" in s)
ck('type2-ready-synchronous',"Add 'CustomAction' @('Ready',[int]2" in s)
ck('fresh-only-two-actions',"if($a[0]-in@('AsyncBegin','Ready')){'NOT Installed'}" in s)
ck('fresh-only-chainer',"Add 'MsiEmbeddedChainer' @('FixtureGuardian','NOT Installed'" in s)
ck('owner-ready-before-initialize',s.index("@('AsyncBegin',1498)")<s.index("@('Ready',1499)")<s.index("@('InstallInitialize',1500)"))
ck('one-marker-currentuser-reg32',"Add 'Registry' @('FixtureMarker',[int]1,$key,'Marker','#1','FixtureComponent')" in s and "Add 'Component' @('FixtureComponent',$ComponentId,'TARGETDIR',[int]4" in s)
ck('nonce-owned-synthetic-key',"$key='Software\\FutureClassroomTest\\Round77-'+$Nonce" in s)
ck('no-install-run-call',all(x not in s for x in ('InstallProduct','ConfigureProduct','Start-Process','CreateProcess','MsiJoinTransaction','MsiEndTransaction','Remove-Item','Set-ItemProperty','Stop-Service')))
ck('factory-default-inert',s.index('if(-not $Execute)')<s.index('Get-FileHash'))
ck('new-exclusive-msi-path',"Need (-not(Test-Path -LiteralPath $MsiPath))" in s and "'OpenDatabase' @($MsiPath,[int]3)" in s)
ck('readback-reopened-readonly',"'OpenDatabase' @($MsiPath,[int]0)" in s)
ck('stream-insert-parameterized',"'INSERT INTO `Binary` (`Name`,`Data`) VALUES (?,?)'" in s and "'SetStream' @([int]2,$HelperExe)" in s)
ck('raw-stream-byte-bstr-format1',"'ReadStream' @([int]2,[int]8192,[int]1)" in s and "'EXACT_BINARY_BYTE_READBACK'" in s)
ck('actual-full-row-comparison',"Same-Rows $rows $expected[$t].ToArray() $t" in s and "'EXACT_ALL_TEN_TABLES'" in s)
ck('explicit-column-metadata-export',"'SELECT `Table`,`Number`,`Name`,`Type` FROM `_Columns`'" in s)
ck('summary-intel-limited',"@(7,'Intel;1033')" in s and "@(14,[int]500)" in s and "@(15,[int]8)" in s)
ck('gui2-x86-helper',"'X86_GUI2_FIXTURE_ONLY'" in s and "[int]$off+92)-eq2" in s)
ck('all-com-capabilities-final-release','finally{Close-Com $summary;Close-Com $script:db;Close-Com $script:installer}' in s)
# Narrow temporal contract: no return-0 assumption for a Windows transaction.
ck('no-runtime-pass-claim-in-preparation',"'PASS_ACTUAL_COM_BUILT_AND_EXACT_READBACK_FIXTURE_ONLY_NOT_INSTALLED'" in s)
print(json.dumps({'status':'PASS_21_PURE_SOURCE_CONTRACTS_ONLY','count':len(checks),'checks':checks,'powershellParse':'NOT_RUN','comBuild':'NOT_RUN','windows':'NOT_RUN','installation':'NOT_RUN'},indent=2))
