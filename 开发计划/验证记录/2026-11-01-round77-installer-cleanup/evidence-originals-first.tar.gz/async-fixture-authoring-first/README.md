# R77 independent async-wait/chainer MSI factory

Prepared source only. No Windows, COM database build, helper execution, install, registry mutation or main edit was performed. Python source-policy models are not a PowerShell parser or MSI runtime simulator. Root alone performs actual compilation, PS5.1 parse, factory execution/static review and later installation.

```powershell
# Fresh x64 desktop PowerShell5.1, root-owned protected nonce scratch:
& '<uploaded>\New-AsyncChainerFixture.ps1' -Execute -HelperExe '<Root>\fixture-helper.exe' -MsiPath '<Root>\fixture.msi' -Root '<Root>' -ProductCode '{UPPERCASE-TEST-GUID}' -UpgradeCode '{DISTINCT-UPPERCASE-TEST-GUID}' -ComponentId '{DISTINCT-UPPERCASE-TEST-GUID}' -Nonce '<32lowerhex>'
# Without -Execute it returns PREPARED_FIXTURE_FACTORY_NOT_RUN before IO/COM.
```

Root must already exist as `FutureClassroom-r77-async-chainer-<nonce>`, marker bytes `future-classroom-owned-r77-async-chainer-fixture/v1\n`, protected owner-current-user+SYSTEM-only FullControl ACL, without reparse ancestors. Helper and new MSI must be direct children; GUI2 PE32 machine x86 helper is bounded4MiB and rehashed before/after. Three distinct canonical braced test GUIDs must not equal the production family or known product. No production manifest, gate/Pending, Run, ProgramData or school file is used.

Factory uses only `WindowsInstaller.Installer.OpenDatabase(path,3)` for new database creation, parameterized SQL with original CreateRecord/SetStream, SummaryInformation, Commit, then closes and reopens read-only mode0. It writes only the new MSI; structured actual query/readback report goes to stdout for the root wrapper to retain. No Linux tools or native Add-Type inspector are required. Binary readback uses `Record.ReadStream(field2,8192,msiReadStreamBytes=1)` byte-per-character BSTR chunks and compares complete bytes to the original helper in memory; only SHA/size is output, no binary Base64 is emitted.

The closed10 tables are Property, Directory, Component, Feature, FeatureComponents, Registry, InstallExecuteSequence, CustomAction, Binary and MsiEmbeddedChainer. All actual table names/column metadata and all non-Binary rows are queried after commit and matched against the authored rows. Exactly one Binary stream is read back. Summary is Intel;1033, minimum Installer500, WordCount8 limited per-user, no ALLUSERS property. No File, service, environment, RemoveFile, Run or arbitrary side-effect table is authored.

Actual fixed roles:

| Entry | Type / sequence | Command | Condition |
|---|---|---|---|
| AsyncBegin | 130 /1498 after InstallValidate | `async "<Root>" <nonce>` | `NOT Installed` |
| Ready | 2 /1499 before InstallInitialize1500 | `ready "<Root>" <nonce>` | `NOT Installed` |
| FixtureGuardian | MsiEmbeddedChainer2 | engine-prepended transaction, then `guardian "<Root>" <nonce>` | `NOT Installed` |

Only registry effect is HKCU32 `Software\FutureClassroomTest\Round77-<nonce>` / Marker DWORD1, one Component(attr4 RegistryKeyPath), one Feature. Standard registry/component/product transactional rows allow the independent guardian to request actual rollback. Necessary formal `/x` fallback skips all3 fixture helper roles because `Installed` is true; no production condition/gate is changed. Whether the real async-wait is drained before/after chainer entry is intentionally unknown and must be measured. Do not assume client exit0 or rollback from action Return1: retain actual API returns/processes/timing and read whole synthetic after-state independently.

Actual factory success output status is `PASS_ACTUAL_COM_BUILT_AND_EXACT_READBACK_FIXTURE_ONLY_NOT_INSTALLED`, with `tables`, `columnMetadata`, `summary`, `factorySource`, `repositoryBase` (base only, fixture uncommitted), `helper`, `msi`, `root`, `nonce`, `currentUserSid`, `productCode`, `upgradeCode`, `componentId`, `marker`. Factory failure is nonzero with retained partial MSI and error. Root must review this actual report and pinned Binary bytes before `/i`, record precise before/after registration/marker absence and original process return, and verify all exact extracted temporary images disappear automatically. No manual system-cache deletion may be used as a passing result. This factory has no product-state query or cleanup function; the separate root-owned driver provides those facts. Forward `$LASTEXITCODE` from the original helper/factory process explicitly when using the SSH ScriptBlock bootstrap.

Primary references checked for the design: [MSI asynchronous return options](https://learn.microsoft.com/en-us/windows/win32/msi/custom-action-return-processing-options), [embedded chainer table](https://learn.microsoft.com/en-us/windows/win32/msi/msiembeddedchainer-table), [parameterized Binary insertion](https://learn.microsoft.com/en-us/windows/win32/msi/adding-binary-data-to-a-table-using-sql), [raw Record.ReadStream](https://learn.microsoft.com/en-us/windows/win32/msi/record-readstream), [MSI SQL example and LOCALIZABLE order](https://learn.microsoft.com/en-us/windows/win32/msi/examples-of-database-queries-using-sql-and-script), [limited per-user WordCount8](https://learn.microsoft.com/en-us/windows/win32/msi/word-count-summary). They do not state the required async-wait-versus-chainer scheduling guarantee; actual finite fixture evidence is required before selecting the product fix.
