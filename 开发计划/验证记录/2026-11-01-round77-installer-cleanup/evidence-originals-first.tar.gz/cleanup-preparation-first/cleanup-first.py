"""Retire only completed, committed R77 originals and its owned Cargo target."""
from pathlib import Path
import argparse, hashlib, json, os, re, stat, subprocess, tarfile
ROOT=Path('/workspace/共享/Eliora/未来教室计划');E=Path('/tmp/fc-round77-installer-cleanup')
DEST=ROOT/'开发计划/验证记录/2026-11-01-round77-installer-cleanup'
KEY=Path('/config/.local/share/future-classroom-test-access/win11-192.168.10.212')
def sha(b):return hashlib.sha256(b).hexdigest()
def need(ok,message):
    if not ok:raise AssertionError(message)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def committed(commit,paths):
    names=sorted(set(paths));requests=b''.join((commit+':'+p+'\n').encode() for p in names)
    p=subprocess.run(['git','cat-file','--batch'],cwd=ROOT,input=requests,capture_output=True,check=True)
    data=p.stdout;at=0;rows=[]
    for name in names:
        end=data.index(b'\n',at);header=data[at:end].split();need(len(header)==3 and header[1]==b'blob','GIT_BLOB_MISSING:'+name);size=int(header[2]);at=end+1;b=data[at:at+size];at+=size;need(data[at:at+1]==b'\n','GIT_BATCH_BOUNDARY');at+=1
        f=ROOT/name;actual=f.read_bytes();need(actual==b,'COMMITTED_BYTES_DIFFER:'+name);rows.append(dict(path=name,bytes=len(b),sha256=sha(b)))
    need(at==len(data),'GIT_BATCH_EXTRA');return rows
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--source-commit');a=p.parse_args()
    if not a.execute:print(json.dumps(dict(status='PREPARED_NOT_RUN',windows='NOT_CONTACTED',sourceDeletion=False)));return 0
    need(bool(re.fullmatch('[0-9a-f]{40}',a.source_commit or '')),'EXPLICIT_COMMIT')
    output=DEST/'local-cleanup-first.json';need(not output.exists(),'NEW_RESULT_ONLY');r=dict(status='RUNNING',sourceCommit=a.source_commit,windowsContacted=False,privateKeyContentsRead=False,removedFiles=0,removedLogicalBytes=0,removedSymlinks=0,removedDirectories=0)
    with output.open('x') as report:
        try:
            need(not E.is_symlink() and E.resolve()==E,'EXACT_OWNED_ROOT');need((E/'.owner').read_bytes()==b'future-classroom-owned-r77-installer-cleanup/v1\n','EXACT_OWNER')
            need(git('rev-parse','HEAD').decode().strip()==a.source_commit,'EXACT_SOURCE_HEAD')
            build=json.loads((E/'native-build-fourth/report.json').read_bytes());need(build['status']=='PASS_COMPILE_ONLY_NOT_RUNTIME' and build['sourceUnchanged'],'FINAL_BUILD_REQUIRED')
            runtime=json.loads((E/'windows-native-full-second.json').read_bytes());need(runtime['status']==runtime['cleanup']=='PASS','FINAL_RUNTIME_AND_CLEANUP_REQUIRED')
            audit=json.loads((E/'windows-readonly-final-first.json').read_bytes());need(audit['status']=='PASS' and not any(audit[k] for k in ('scratchDirectories','ownedProcesses','ownedTasks')),'FINAL_READONLY_REQUIRED')
            key_mode=stat.S_IMODE(KEY.stat().st_mode);need(key_mode==0o600,'PRIVATE_KEY_MODE');r['persistentPrivateKeyMode']=oct(key_mode)
            changed=git('diff-tree','--no-commit-id','--name-only','-z','-r',a.source_commit).decode().split('\0');paths=[n for n in changed if n]+[f['path'] for f in build['inputsAfter']]
            r['committedBytes']=committed(a.source_commit,paths)
            for f in build['inputsAfter']:
                b=(ROOT/f['path']).read_bytes();need(len(b)==f['bytes'] and sha(b)==f['sha256'],'COMPILED_SOURCE_CHANGED:'+f['path'])
            index=json.loads((DEST/'archive-index-first.json').read_bytes());archive=DEST/'evidence-originals-first.tar.gz';ab=archive.read_bytes();need(len(ab)==index['archive']['bytes'] and sha(ab)==index['archive']['sha256'],'ARCHIVE_IDENTITY')
            originals={f['path']:f for f in index['originals']};excluded={f['path']:f for f in index['excludedBinaries']}
            with tarfile.open(archive,'r:gz') as t:
                members=t.getmembers();need(len(members)==len(originals),'ARCHIVE_MEMBERSHIP')
                for m in members:
                    need(m.isfile() and m.name in originals,'ARCHIVE_SAFE_MEMBER');f=originals[m.name];b=t.extractfile(m).read();need(len(b)==f['bytes'] and sha(b)==f['sha256'],'ARCHIVE_MEMBER_BYTES');need((E/m.name).read_bytes()==b,'SOURCE_ORIGINAL_CHANGED:'+m.name)
            for name,f in excluded.items():
                b=(E/name).read_bytes();need(len(b)==f['bytes'] and sha(b)==f['sha256'],'EXCLUDED_BINARY_CHANGED:'+name)
            for f in build['artifacts']:
                path=Path(f['path']);need(path.is_relative_to(E/'target') and not path.is_symlink(),'EXACT_FINAL_PE');b=path.read_bytes();need(len(b)==f['bytes'] and sha(b)==f['sha256'],'FINAL_PE_CHANGED')
            allowed={os.getpid()};cursor=os.getpid()
            while cursor>1:
                fields=Path('/proc',str(cursor),'stat').read_text().rsplit(')',1)[1].split();cursor=int(fields[1]);allowed.add(cursor)
            hits=[]
            for process in Path('/proc').iterdir():
                if not process.name.isdigit() or int(process.name) in allowed:continue
                try:cmd=(process/'cmdline').read_bytes()
                except (FileNotFoundError,ProcessLookupError,PermissionError):continue
                if str(E).encode() in cmd:hits.append(int(process.name))
            need(not hits,'OWNED_ROOT_STILL_REFERENCED_BY_LIVE_PROCESS');r['processCheck']=dict(readableProcScope=True,matchingOtherProcesses=hits,ownControllerAndAncestorsExcluded=sorted(allowed))
            found=set();files=[];directories=[];links=[]
            for base,dirs,names in os.walk(E,topdown=True,followlinks=False):
                for n in list(dirs):
                    f=Path(base,n)
                    if f.is_symlink():links.append(f);dirs.remove(n)
                    else:directories.append(f)
                for n in names:
                    f=Path(base,n);st=f.lstat()
                    if stat.S_ISLNK(st.st_mode):links.append(f);continue
                    need(stat.S_ISREG(st.st_mode),'NONREGULAR_SOURCE');files.append((f,st.st_size));rel=f.relative_to(E).as_posix()
                    if not rel.startswith('target/'):found.add(rel)
            need(found==set(originals)|set(excluded),'EXACT_NON_TARGET_SOURCE_MEMBERSHIP')
            r['archiveReplayedOriginals']=len(originals);r['excludedBinaryIdentitiesChecked']=len(excluded);r['finalPeIdentitiesChecked']=len(build['artifacts'])
            for f,size in files:
                if f==E/'.owner':continue
                f.unlink();r['removedFiles']+=1;r['removedLogicalBytes']+=size
            for f in links:f.unlink();r['removedSymlinks']+=1
            for d in sorted(directories,key=lambda x:len(x.parts),reverse=True):d.rmdir();r['removedDirectories']+=1
            marker=E/'.owner';size=marker.stat().st_size;marker.unlink();r['removedFiles']+=1;r['removedLogicalBytes']+=size;E.rmdir();r['removedDirectories']+=1;need(not E.exists(),'ROOT_NOT_ABSENT')
            r.update(status='PASS',rootKnownAbsent=True,physicalBytesFreed='NOT_MEASURED',preserved='Main target/global caches, three intended development ZIPs, persistent SSH service/public authorization and external private key. No Windows operation or user process termination.')
        except Exception as error:r.update(status='FAIL_RETAIN_REMAINING_ORIGINALS',errorType=type(error).__name__,error=str(error))
        report.write(json.dumps(r,indent=2)+'\n')
    print(json.dumps({k:r.get(k) for k in ('status','removedFiles','removedLogicalBytes','removedSymlinks','rootKnownAbsent','error')}));return 0 if r['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
