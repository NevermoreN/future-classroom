"""Bounded GNU development build. Default does not compile or connect to Windows."""
from pathlib import Path
import argparse, hashlib, json, os, signal, subprocess, time

ROOT = Path('/workspace/共享/Eliora/未来教室计划')
E = Path('/tmp/fc-round77-installer-cleanup')

def sha(b): return hashlib.sha256(b).hexdigest()
def run_read(cmd): return subprocess.check_output(cmd, cwd=ROOT)
def sources():
    paths = set(run_read(['git','ls-files','-z']).decode().split('\0'))
    paths |= {str(p.relative_to(ROOT)) for p in (ROOT/'crates').rglob('*') if p.is_file()}
    names = sorted(n for n in paths if n and (n in ('Cargo.toml','Cargo.lock','rust-toolchain.toml','scripts/link-win7-gnu.sh') or n.startswith(('.cargo/','crates/'))))
    result=[]
    for n in names:
        p=ROOT/n
        if not p.is_file(): raise AssertionError('SOURCE_NOT_REGULAR:'+n)
        if p.is_symlink(): raise AssertionError('SOURCE_SYMLINK:'+n)
        b=p.read_bytes(); result.append(dict(path=n,bytes=len(b),sha256=sha(b)))
    return result

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');a=p.parse_args()
    if not a.execute:
        print(json.dumps(dict(status='PREPARED_NOT_RUN',windows='NOT_CONNECTED',commandBudgetSeconds=900)));return 0
    assert (E/'.owner').read_bytes()==b'future-classroom-owned-r77-installer-cleanup/v1\n'
    d=E/'native-build-fourth';assert not d.exists();d.mkdir()
    report=d/'report.json';before=sources()
    v=dict(status='RUNNING',scope='Linux GNU Windows development compilation, not actual MSI or Win7/10 runtime',sourceGit=run_read(['git','rev-parse','HEAD']).decode().strip(),inputsBefore=before,operations=[])
    (d/'source.diff').write_bytes(run_read(['git','diff','--','crates','scripts/package-msi-candidate.py','scripts/check-msi-candidate.py','packaging/MSI-CANDIDATE.md']))
    env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(E/'target'),CARGO_INCREMENTAL='0')
    env.pop('CARGO_TARGET_I686_PC_WINDOWS_GNU_LINKER',None)
    v['childEnvironmentOverrides']={k:env[k] for k in ('CARGO_TARGET_DIR','CARGO_INCREMENTAL')}
    v['linkerQualification']='Use unchanged repository i686-pc-windows-gnu default GCC linker, matching prior successful R75 baseline. Earlier Win7-only wrapper override and original runtime FAIL are retained separately.'
    v['priorStrictSourceCheck']='native-build-second/report.json: actual clippy exit0 on exact same frozen source; linking environment changes only. No lint or assertion relaxed.'
    commands=[('tests',['cargo','test','--workspace','--all-targets','--target','i686-pc-windows-gnu','--release','--no-run','--locked','--offline','-j2','--message-format=json']),('normal',['cargo','build','--workspace','--bins','--target','i686-pc-windows-gnu','--release','--locked','--offline','-j2','--message-format=json'])]
    def save(): report.write_text(json.dumps(v,indent=2)+'\n')
    save()
    try:
        for name,cmd in commands:
            out=d/(name+'.stdout.log');err=d/(name+'.stderr.log');t=time.monotonic()
            with out.open('xb') as so,err.open('xb') as se:
                proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=so,stderr=se,start_new_session=True)
                row=dict(name=name,command=cmd,pid=proc.pid,budgetSeconds=900,timedOut=False,ownedProcessGroupTerminated=False)
                try: code=proc.wait(timeout=900)
                except subprocess.TimeoutExpired:
                    row['timedOut']=True;row['ownedProcessGroupTerminated']=True;os.killpg(proc.pid,signal.SIGTERM)
                    try: code=proc.wait(timeout=10)
                    except subprocess.TimeoutExpired: os.killpg(proc.pid,signal.SIGKILL);code=proc.wait(timeout=10)
            row.update(actualExit=True,exitCode=code,reaped=True,elapsedSeconds=time.monotonic()-t)
            for k,f in [('stdout',out),('stderr',err)]:
                b=f.read_bytes();row[k]=dict(path=str(f),bytes=len(b),sha256=sha(b))
            v['operations'].append(row);save()
            if row['timedOut'] or code: raise AssertionError('ACTUAL_COMMAND_FAILED:'+name)
        artifacts=[]
        for role in ('tests','normal'):
            for line in (d/(role+'.stdout.log')).read_bytes().splitlines():
                m=json.loads(line)
                if m.get('reason')=='compiler-artifact' and m.get('executable') and m['profile']['test'] is (role=='tests'):
                    f=Path(m['executable']);assert f.is_relative_to(E/'target') and f.is_file() and not f.is_symlink()
                    b=f.read_bytes();artifacts.append(dict(role=role,path=str(f),bytes=len(b),sha256=sha(b),target=m['target'],packageId=m['package_id'],profileTest=m['profile']['test']))
        assert len([x for x in artifacts if x['role']=='tests'])==22
        assert sorted(x['target']['name'] for x in artifacts if x['role']=='normal')==['fc-bootstrap','fc-installer-lifecycle']
        v['artifacts']=artifacts;v['status']='PASS_COMPILE_ONLY_NOT_RUNTIME'
    except Exception as error:
        v.update(status='FAIL_ACTUAL_BUILD_OR_CAPTURE',errorType=type(error).__name__,error=str(error))
    finally:
        v['inputsAfter']=sources();v['sourceUnchanged']=before==v['inputsAfter']
        if not v['sourceUnchanged']:v['status']='FAIL_SOURCE_CHANGED_DURING_BUILD'
        save()
    print(json.dumps(dict(status=v['status'],report=str(report),sourceUnchanged=v['sourceUnchanged'])));return 0 if v['status'].startswith('PASS') else 1

if __name__=='__main__':raise SystemExit(main())
