from pathlib import Path
import runpy,json,hashlib,subprocess,re,time
E=Path('/tmp/fc-round77-installer-cleanup');m=runpy.run_path(str(E/'transport-preparation-second/run-fixture-second.py'));report=E/'root-first-fixture-cleanup.json';assert not report.exists()
v=json.loads((E/'async-fixture-runtime-first/report.json').read_bytes());r=v['driverResult'];assert v['downloadVerified'] and v['sourceUnchanged'] and r['finalAbsence']['knownAbsent'] and r['capturedPhysicalReturned'] and r['client']['ActualWait']==0 and r['client']['ProcessCloseSuccess']
for f in r['observer']['Processes']:assert f['ActualWait']==0 and f['CloseStatus']=='CHECKED_CLOSE_SUCCESS' and f['ExitStatus']=='ACTUAL_ORIGINAL_GET_EXIT_CODE'
local=E/'async-fixture-runtime-first/download'/v['config']['rootName'];inv=v['remoteInventory']
for row in inv['files']:
 b=(local/row['path']).read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
log=(local/'install-msi.log').read_bytes().decode('utf-16');paths={x['Image'] for x in r['observer']['Processes']}|set(re.findall(r'C:\\Windows\\Installer\\[A-Za-z0-9]+\.msi',log,re.I))
c=dict(v['remote']);c.update(config=v['config'],inventory=inv,cachePaths=sorted(paths))
script=r'''CheckRoot
$i=$null;$ps=$null;$related=$null;$base=$null;$key=$null
try{$i=New-Object -ComObject WindowsInstaller.Installer;$ps=$i.GetType().InvokeMember('ProductsEx',[Reflection.BindingFlags]::GetProperty,$null,$i,@($c.config.productCode,'',7));$n=$ps.GetType().InvokeMember('Count',[Reflection.BindingFlags]::GetProperty,$null,$ps,@());$state=$i.GetType().InvokeMember('ProductState',[Reflection.BindingFlags]::GetProperty,$null,$i,@($c.config.productCode));$related=$i.GetType().InvokeMember('RelatedProducts',[Reflection.BindingFlags]::GetProperty,$null,$i,@($c.config.upgradeCode));$rn=$related.GetType().InvokeMember('Count',[Reflection.BindingFlags]::GetProperty,$null,$related,@());if($n-ne0-or$state-ne-1-or$rn-ne0){throw 'OWN_FIXTURE_REGISTRATION_NOT_ABSENT'}
$base=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry32);$key=$base.OpenSubKey($c.config.registryKey,$false);if($null-ne$key){throw 'OWN_FIXTURE_MARKER_NOT_ABSENT'}
$ancestors=@();foreach($name in @('Software\FutureClassroomTest')){$a=$null;try{$a=$base.OpenSubKey($name,$false);$ancestors+=@{key=$name;knownAbsent=($null-eq$a);valueCount=$(if($a){$a.ValueCount}else{$null});subKeyCount=$(if($a){$a.SubKeyCount}else{$null});mutations=$false}}finally{if($a){$a.Dispose()}}}
}finally{foreach($o in @($related,$ps,$i)){if($null-ne$o){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($o)}};foreach($k in @($key,$base)){if($null-ne$k){$k.Dispose()}}}
$cache=@();foreach($path in $c.cachePaths){try{$a=[IO.File]::GetAttributes($path);throw 'ORIGINAL_INSTALLER_TEMP_STILL_PRESENT'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}};$cache+=@{path=$path;knownAbsent=$true;mutations=$false}}
$now=Inventory;if($now.files.Count-ne$c.inventory.files.Count-or$now.directories.Count-ne$c.inventory.directories.Count){throw 'MEMBERSHIP_CHANGED'};foreach($f in $now.files){$old=@($c.inventory.files|Where-Object{$_.path-ceq$f.path});if($old.Count-ne1-or$old[0].bytes-ne$f.bytes-or$old[0].sha256-cne$f.sha256){throw 'ORIGINAL_BYTES_CHANGED'}};foreach($d in $now.directories){if($d-cnotin$c.inventory.directories){throw 'DIRECTORY_CHANGED'}}
foreach($f in $c.inventory.files){[IO.File]::Delete((Join-Path $c.root ($f.path.Replace('/','\'))))};foreach($d in @($c.inventory.directories|Sort-Object Length -Descending)){[IO.Directory]::Delete((Join-Path $c.root ($d.Replace('/','\'))),$false)};[IO.Directory]::Delete($c.root,$false)
try{[void][IO.File]::GetAttributes($c.root);throw 'ROOT_PRESENT'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
@{status='PASS_FIRST_FIXTURE_ABSENT_EXACT_SCRATCH_REMOVED';productState=$state;productCount=$n;relatedCount=$rn;markerKnownAbsent=$true;cacheOriginalPaths=$cache;ancestorReadOnly=$ancestors;filesRemoved=$c.inventory.files.Count;rootKnownAbsent=$true;registryMutation=$false;cacheManualDelete=$false;serviceKill=$false}|ConvertTo-Json -Depth 8 -Compress'''
cmd,feed=m['remote'](script,c);start=time.monotonic();p=subprocess.run(cmd,input=feed,capture_output=True,timeout=30);out=dict(actualExit=True,exitCode=p.returncode,reaped=True,elapsedSeconds=time.monotonic()-start,command=cmd,stdin=dict(bytes=len(feed),sha256=hashlib.sha256(feed).hexdigest()))
for label,data in [('stdout',p.stdout),('stderr',p.stderr)]:
 path=E/('root-first-fixture-cleanup.'+label+'.log');path.write_bytes(data);out[label]=dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
if p.returncode==0:out['actual']=json.loads(p.stdout);out['status']='PASS'
else:out['status']='FAIL_RETAINED'
report.write_text(json.dumps(out,indent=2)+'\n');print(p.stdout.decode());print(p.stderr.decode() if p.returncode else '');raise SystemExit(p.returncode)
