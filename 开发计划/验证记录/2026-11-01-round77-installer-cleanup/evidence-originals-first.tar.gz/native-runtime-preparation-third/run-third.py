"""Run the verified GNU tests and hidden public desktop flow on authorized Win11."""
from pathlib import Path
import argparse, hashlib, json, runpy, struct, subprocess, time
ROOT=Path('/workspace/共享/Eliora/未来教室计划');E=Path('/tmp/fc-round77-installer-cleanup')
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');a=p.parse_args()
    if not a.execute:print(json.dumps(dict(status='PREPARED_NOT_RUN',windows='NOT_CONNECTED')));return 0
    assert (E/'.owner').read_bytes()==b'future-classroom-owned-r77-installer-cleanup/v1\n'
    build=json.loads((E/'native-build-capture-third/report.json').read_bytes());assert build['status']=='PASS_COMPILE_ONLY_NOT_RUNTIME' and build['sourceUnchanged']
    for f in build['inputsAfter']:
        b=(ROOT/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
    pe=[]
    for f in build['artifacts']:
        b=Path(f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
        offset=struct.unpack_from('<I',b,60)[0];assert b[:2]==b'MZ' and b[offset:offset+4]==b'PE\0\0'
        machine=struct.unpack_from('<H',b,offset+4)[0];subsystem=struct.unpack_from('<H',b,offset+24+68)[0]
        assert machine==332 and subsystem==(3 if f['role']=='tests' else 2)
        pe.append(dict(path=f['path'],sha256=f['sha256'],machine=machine,subsystem=subsystem))
    assert len(pe)==24
    review=json.loads((E/'native-production-source-review-first/review-first.json').read_bytes())
    assert review.get('status','').startswith('PASS'),'INDEPENDENT_SOURCE_REVIEW_NOT_PASS'
    report=E/'windows-native-full-first.json';assert not report.exists()
    exe=next(f['path'] for f in build['artifacts'] if f['role']=='normal' and f['target']['name']=='fc-bootstrap')
    cmd=['python3',str(ROOT/'scripts/windows-probe.py'),'--host','elior@192.168.10.212','--identity','/config/.local/share/future-classroom-test-access/win11-192.168.10.212','--exe',exe,'--test-metadata',str(E/'native-build-second/tests.stdout.log'),'--test-timeout-seconds','900','--native-seconds','2','--public-desktop','--report',str(report)]
    op=E/'windows-native-full-operation-first.json';assert not op.exists();t=time.monotonic();proc=subprocess.Popen(cmd,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    v=dict(status='RUNNING',command=cmd,pid=proc.pid,pe=pe,scope='GNU x86 development tests and hidden native public workflow only; normal installer helper identity checked, not executed by this runner.')
    op.write_text(json.dumps(v,indent=2)+'\n')
    stdout,stderr=proc.communicate();v.update(actualExit=True,exitCode=proc.returncode,reaped=True,elapsedSeconds=time.monotonic()-t)
    for label,b in [('stdout',stdout),('stderr',stderr)]:
        path=E/('windows-native-full-operation-first.'+label+'.log');path.write_bytes(b);v[label]=dict(path=str(path),bytes=len(b),sha256=sha(b))
    v['status']='PASS' if proc.returncode==0 else 'FAIL_ACTUAL_RUN';op.write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(dict(status=v['status'],exitCode=proc.returncode,report=str(report))));return proc.returncode
if __name__=='__main__':raise SystemExit(main())
