using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

internal static class Program
{
    const string Marker = "future-classroom-owned-r77-async-chainer-fixture/v1\n";
    const uint SyncQuery = 0x00101000, Timeout = 258;
    static readonly long Began = Stopwatch.GetTimestamp();
    static readonly Encoding Utf8 = new UTF8Encoding(false, true);
    static readonly List<IntPtr> Handles = new List<IntPtr>();
    static string Root, Nonce, Role;
    static Fact Self;
    static Timer Watchdog;
    static int Finished;
    static bool CloseFailed;
    static long Deadline;

    [DllImport("kernel32.dll", SetLastError=true)] static extern IntPtr GetCurrentProcess();
    [DllImport("kernel32.dll")] static extern uint GetCurrentProcessId();
    [DllImport("kernel32.dll", SetLastError=true)] static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
    [DllImport("kernel32.dll", SetLastError=true)] static extern uint GetProcessId(IntPtr process);
    [DllImport("kernel32.dll", SetLastError=true)] static extern bool GetProcessTimes(IntPtr p, out long creation, out long exit, out long kernel, out long user);
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, ExactSpelling=true, SetLastError=true)] static extern bool QueryFullProcessImageNameW(IntPtr p, uint flags, StringBuilder name, ref uint size);
    [DllImport("kernel32.dll", SetLastError=true)] static extern uint WaitForSingleObject(IntPtr h, uint milliseconds);
    [DllImport("kernel32.dll", SetLastError=true)] static extern bool GetExitCodeProcess(IntPtr h, out uint code);
    [DllImport("kernel32.dll", SetLastError=true)] static extern bool CloseHandle(IntPtr h);
    [DllImport("advapi32.dll", SetLastError=true)] static extern bool OpenProcessToken(IntPtr p, uint access, out IntPtr token);
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, ExactSpelling=true, SetLastError=true)] static extern IntPtr CreateFileW(string path, uint access, uint share, IntPtr security, uint disposition, uint flags, IntPtr template);
    [StructLayout(LayoutKind.Sequential, Pack=4)] struct FileInfo { internal uint Attributes; internal long Creation, Access, Write; internal uint Volume, SizeHigh, SizeLow, Links, IndexHigh, IndexLow; }
    [DllImport("kernel32.dll", SetLastError=true)] static extern bool GetFileInformationByHandle(IntPtr h, out FileInfo info);
    [DllImport("msi.dll", ExactSpelling=true)] static extern uint MsiJoinTransaction(uint transaction, uint attributes, out IntPtr changed);
    [DllImport("msi.dll", ExactSpelling=true)] static extern uint MsiEndTransaction(uint state);

    sealed class Fact
    {
        internal uint Pid;
        internal long Creation;
        internal string Image, Sha, Sid;
    }
    static void Need(bool ok, string reason) { if (!ok) throw new InvalidOperationException(reason); }
    static void Win(bool ok, string operation) { if (!ok) throw new Win32Exception(Marshal.GetLastWin32Error(), operation); }
    static IntPtr Track(IntPtr h) { Need(h != IntPtr.Zero && h != new IntPtr(-1), "INVALID_HANDLE"); Handles.Add(h); return h; }
    static void Close(IntPtr h)
    {
        Need(Handles.Remove(h), "HANDLE_NOT_OWNED");
        if (!CloseHandle(h)) { CloseFailed = true; throw new Win32Exception(Marshal.GetLastWin32Error(), "CloseHandle"); }
    }
    static string Q(string s)
    {
        StringBuilder b = new StringBuilder("\"");
        foreach (char c in s) { if (c == '"' || c == '\\') b.Append('\\').Append(c); else if (c < 32) b.Append("\\u").Append(((int)c).ToString("x4")); else b.Append(c); }
        return b.Append('"').ToString();
    }
    static string N(long n) { return n.ToString(CultureInfo.InvariantCulture); }
    static string Sha(string path)
    {
        using (FileStream f = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read | FileShare.Delete))
        using (SHA256 s = SHA256.Create()) return BitConverter.ToString(s.ComputeHash(f)).Replace("-", "").ToLowerInvariant();
    }
    static Fact Inspect(IntPtr h)
    {
        Fact f = new Fact(); f.Pid = GetProcessId(h); Need(f.Pid != 0, "GetProcessId");
        long exit, kernel, user; Win(GetProcessTimes(h, out f.Creation, out exit, out kernel, out user), "GetProcessTimes");
        StringBuilder path = new StringBuilder(32768); uint length = (uint)path.Capacity;
        Win(QueryFullProcessImageNameW(h, 0, path, ref length), "QueryFullProcessImageNameW");
        f.Image = path.ToString(); Need(Path.IsPathRooted(f.Image) && length > 0, "IMAGE_PATH"); f.Sha = Sha(f.Image);
        IntPtr token; Win(OpenProcessToken(h, 8, out token), "OpenProcessToken"); Track(token);
        try { using (WindowsIdentity identity = new WindowsIdentity(token)) { f.Sid = identity.User.Value; } } finally { Close(token); }
        return f;
    }
    static string Identity(string role, Fact f, string extra)
    {
        return "{\"schemaVersion\":1,\"role\":" + Q(role) + ",\"nonce\":" + Q(Nonce) + ",\"pid\":" + N(f.Pid) + ",\"creationFiletime\":" + N(f.Creation) + ",\"imagePath\":" + Q(f.Image) + ",\"imageSha256\":" + Q(f.Sha) + ",\"sid\":" + Q(f.Sid) + ",\"pointerBytes\":4" + extra + "}\n";
    }
    static byte[] Publish(string leaf, string text)
    {
        byte[] bytes = Utf8.GetBytes(text); PublishBytes(leaf, bytes); return bytes;
    }
    static void PublishBytes(string leaf, byte[] bytes)
    {
        Need(leaf.IndexOfAny(new char[] {'\\','/'}) < 0, "LEAF");
        string final = Path.Combine(Root, leaf), pending = final + ".pending-" + Role;
        using (FileStream f = new FileStream(pending, FileMode.CreateNew, FileAccess.Write, FileShare.None)) { f.Write(bytes, 0, bytes.Length); f.Flush(true); }
        File.Move(pending, final);
    }
    static byte[] Read(string leaf)
    {
        string path = Path.Combine(Root, leaf); Need((File.GetAttributes(path) & FileAttributes.ReparsePoint) == 0, "FILE_REPARSE");
        using (FileStream f = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
        { FileInfo info; Win(GetFileInformationByHandle(f.SafeFileHandle.DangerousGetHandle(), out info), "GetFileInformationByHandle(file)"); Need((info.Attributes & 0x410)==0 && info.Links==1,"FILE_REPARSE_OR_HARDLINK"); Need(f.Length > 0 && f.Length <= 16384, "FILE_SIZE"); byte[] b = new byte[(int)f.Length]; int n = 0; while (n < b.Length) { int r = f.Read(b, n, b.Length-n); Need(r > 0, "SHORT_READ"); n += r; } return b; }
    }
    static bool Equal(byte[] a, byte[] b) { if (a.Length != b.Length) return false; for (int i=0;i<a.Length;i++) if (a[i]!=b[i]) return false; return true; }
    static long Number(string text, string key)
    {
        MatchCollection m = Regex.Matches(text, "\"" + key + "\":([0-9]+)(?=[,}])", RegexOptions.CultureInvariant);
        long n; Need(m.Count == 1 && Int64.TryParse(m[0].Groups[1].Value, NumberStyles.None, CultureInfo.InvariantCulture, out n), "NUMERIC_FIELD_"+key);
        return Int64.Parse(m[0].Groups[1].Value, CultureInfo.InvariantCulture);
    }
    static void Before(long deadline) { Need(Stopwatch.GetTimestamp() < deadline, "DEADLINE"); }
    static byte[] Await(string leaf, long deadline)
    {
        for (;;) { Before(deadline); if (File.Exists(Path.Combine(Root, leaf))) return Read(leaf); Thread.Sleep(5); }
    }
    static void Ack(string identityLeaf, string ackLeaf, long deadline)
    {
        byte[] own = Publish(identityLeaf, Identity(Role, Self, ""));
        Need(Equal(own, Await(ackLeaf, deadline)), "ORIGINAL_CAPTURE_ACK_BYTES");
    }
    static void ValidateRoot()
    {
        Need(Path.IsPathRooted(Root) && Path.GetFullPath(Root) == Root && Path.GetFileName(Root) == "FutureClassroom-r77-async-chainer-" + Nonce, "ROOT_PATH");
        DirectoryInfo d = new DirectoryInfo(Root);
        while (d != null)
        {
            Need((d.Attributes & FileAttributes.ReparsePoint) == 0, "DIRECTORY_REPARSE");
            IntPtr directory = Track(CreateFileW(d.FullName, 0x80, 3, IntPtr.Zero, 3, 0x02200000, IntPtr.Zero));
            FileInfo information; Win(GetFileInformationByHandle(directory, out information), "GetFileInformationByHandle(directory)");
            Need((information.Attributes & 0x410) == 0x10, "PINNED_DIRECTORY_REPARSE"); d = d.Parent;
        }
        DirectorySecurity acl = Directory.GetAccessControl(Root, AccessControlSections.Owner | AccessControlSections.Access);
        string sid; using (WindowsIdentity current = WindowsIdentity.GetCurrent()) { sid = current.User.Value; }
        Need(acl.GetOwner(typeof(SecurityIdentifier)).Value == sid && acl.AreAccessRulesProtected, "ROOT_OWNER_ACL");
        bool user = false, system = false;
        foreach (FileSystemAccessRule rule in acl.GetAccessRules(true, true, typeof(SecurityIdentifier)))
        {
            string who = rule.IdentityReference.Value;
            Need(rule.AccessControlType == AccessControlType.Allow && (who == sid || who == "S-1-5-18"), "ROOT_DACL_PRINCIPAL");
            Need((rule.FileSystemRights & FileSystemRights.FullControl) == FileSystemRights.FullControl, "ROOT_DACL_RIGHTS");
            if (who == sid) user = true; if (who == "S-1-5-18") system = true;
        }
        Need(user && system && Utf8.GetString(Read(".owner")) == Marker, "ROOT_MARKER");
        Self = Inspect(GetCurrentProcess()); Need(Self.Sid == sid, "CURRENT_SID");
    }
    static void Fail(Exception error)
    {
        try { if (Root != null && Self != null) Publish("FAIL-"+Role+".json", Identity(Role, Self, ",\"status\":\"FAIL\",\"reason\":"+Q(error.Message)+",\"hresult\":"+N(error.HResult)+",\"elapsedMilliseconds\":"+N((Stopwatch.GetTimestamp()-Began)*1000/Stopwatch.Frequency))); } catch { }
    }
    static void Arm(int seconds)
    {
        Deadline = checked(Began + Stopwatch.Frequency * seconds); Before(Deadline);
        long left = (Deadline - Stopwatch.GetTimestamp()) * 1000 / Stopwatch.Frequency;
        Watchdog = new Timer(delegate { if (Interlocked.Exchange(ref Finished, 1) == 0) { Fail(new TimeoutException("ORIGINAL_PROCESS_BUDGET")); Environment.Exit(1603); } }, null, Math.Max(1, left), System.Threading.Timeout.Infinite);
    }
    static void StartCheck(string text)
    {
        Need(text.IndexOf("\"nonce\":"+Q(Nonce)+",", StringComparison.Ordinal)>=0 && text.IndexOf("\"imageSha256\":"+Q(Self.Sha)+",", StringComparison.Ordinal)>=0 && text.IndexOf("\"sid\":"+Q(Self.Sid)+",", StringComparison.Ordinal)>=0, "START_IDENTITY");
        long start = Number(text,"startedTimestamp"), end = Number(text,"deadlineTimestamp"), frequency=Number(text,"stopwatchFrequency");
        Need(frequency == Stopwatch.Frequency && end-start == frequency*10 && start <= Stopwatch.GetTimestamp(), "START_CLOCK"); Before(end);
    }
    static void Async()
    {
        Ack("async-identity.json", ".async-original-captured", Math.Min(Deadline, Began+Stopwatch.Frequency*2));
        Publish("START.json", Identity(Role, Self, ",\"startedTimestamp\":"+N(Began)+",\"deadlineTimestamp\":"+N(Deadline)+",\"stopwatchFrequency\":"+N(Stopwatch.Frequency)));
        byte[] entry = Await("CHAINER_ENTER.json", Deadline); string text = Utf8.GetString(entry);
        long pid = Number(text,"pid"), creation=Number(text,"creationFiletime"), txn=Number(text,"transaction");
        Need(pid>0 && pid<=UInt32.MaxValue && txn>0 && txn<=UInt32.MaxValue, "GUARDIAN_SELECTOR");
        IntPtr guardian = Track(OpenProcess(SyncQuery, false, (uint)pid));
        Fact fact = Inspect(guardian);
        Need(fact.Pid==(uint)pid && fact.Creation==creation && fact.Sid==Self.Sid && fact.Sha==Self.Sha, "GUARDIAN_ORIGINAL_IDENTITY");
        Need(WaitForSingleObject(guardian,0)==Timeout, "GUARDIAN_NOT_LIVE");
        Need(Equal(entry, Utf8.GetBytes(Identity("guardian", fact, ",\"transaction\":"+N(txn)))), "GUARDIAN_ENTRY_EXACT");
        PublishBytes(".guardian-original-captured", entry);
        for (;;) { Before(Deadline); uint wait=WaitForSingleObject(guardian,10); if(wait==0)break; Need(wait==Timeout,"GUARDIAN_WAIT"); }
        uint exit; Win(GetExitCodeProcess(guardian,out exit),"GetExitCodeProcess"); Need(exit==0,"GUARDIAN_ACTUAL_EXIT_NONZERO"); Close(guardian);
        Publish("GUARDIAN_EXIT_OBSERVED.json",Identity(Role,Self,",\"guardianPid\":"+N(fact.Pid)+",\"guardianCreationFiletime\":"+N(fact.Creation)+",\"guardianImageSha256\":"+Q(fact.Sha)+",\"actualExitCode\":0,\"originalHandleClosed\":true"));
        Before(Deadline); Publish("ASYNC_DONE.json",Identity(Role,Self,",\"status\":\"PASS_ORIGINAL_GUARDIAN_EXIT0_AND_CLOSE\""));
    }
    static void Ready()
    {
        Ack("ready-identity.json", ".ready-original-captured", Deadline);
        StartCheck(Utf8.GetString(Await("START.json",Deadline))); Before(Deadline);
        Publish("READY.json",Identity(Role,Self,",\"status\":\"READY\""));
    }
    static void Guardian(uint txn)
    {
        string start=Utf8.GetString(Read("START.json")); StartCheck(start); long end=Number(start,"deadlineTimestamp");
        byte[] entry=Publish("CHAINER_ENTER.json",Identity(Role,Self,",\"transaction\":"+N(txn)));
        Need(Equal(entry,Await(".guardian-original-captured",end)),"ASYNC_ORIGINAL_CAPTURE_ACK_BYTES");
        IntPtr changed; uint joined=MsiJoinTransaction(txn,0,out changed);
        if(changed!=IntPtr.Zero && changed!=new IntPtr(-1))Track(changed);
        Publish("JOIN_RETURN.json",Identity(Role,Self,",\"transaction\":"+N(txn)+",\"returnCode\":"+N(joined)+",\"changeEventReturned\":"+((changed!=IntPtr.Zero && changed!=new IntPtr(-1))?"true":"false")));
        Need(joined==0 && changed!=IntPtr.Zero && changed!=new IntPtr(-1),"MsiJoinTransaction");
        Publish("END_ENTER.json",Identity(Role,Self,",\"transaction\":"+N(txn)+",\"decision\":\"ROLLBACK\""));
        uint ended=MsiEndTransaction(0);
        Publish("END_RETURN.json",Identity(Role,Self,",\"transaction\":"+N(txn)+",\"returnCode\":"+N(ended)));
        Close(changed); Publish("CHANGE_EVENT_CLOSED.json",Identity(Role,Self,",\"transaction\":"+N(txn)+",\"checkedClose\":true")); Need(ended==0,"MsiEndTransaction");
    }
    static int Main(string[] args)
    {
        int result=1603;
        try
        {
            Need(IntPtr.Size==4,"X86_REQUIRED");
            uint txn=0;
            if(args.Length==3 && (args[0]=="async" || args[0]=="ready")) { Role=args[0];Root=args[1];Nonce=args[2]; }
            else { Need(args.Length==4 && args[1]=="guardian" && UInt32.TryParse(args[0],NumberStyles.None,CultureInfo.InvariantCulture,out txn) && txn>0,"ARGV"); Role="guardian";Root=args[2];Nonce=args[3]; }
            Need(Regex.IsMatch(Nonce,"\\A[0-9a-f]{32}\\z",RegexOptions.CultureInvariant),"NONCE");
            if(Role=="async")Arm(10);else if(Role=="ready")Arm(2); ValidateRoot();
            if(Role=="async")Async();else if(Role=="ready")Ready();else Guardian(txn);
            result=0;
        }
        catch(Exception error) { Fail(error); }
        finally
        {
            while(Handles.Count>0) { IntPtr h=Handles[Handles.Count-1]; try { Close(h); } catch(Exception e) { Fail(e); result=1603; } }
            if(CloseFailed)result=1603;
            if(Watchdog!=null) { if(result==0 && Stopwatch.GetTimestamp()>=Deadline) { Fail(new TimeoutException("ORIGINAL_PROCESS_BUDGET"));result=1603; } Interlocked.Exchange(ref Finished,1);Watchdog.Dispose(); }
        }
        return result;
    }
}
