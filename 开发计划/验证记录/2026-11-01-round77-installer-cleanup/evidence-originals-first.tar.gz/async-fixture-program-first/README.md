# R77 standalone async/chainer fixture (preparation only)

`Program.cs` is a single .NET Framework C# source; it has not been compiled or run. It is a test-only GUI EXE, never a product helper. No registry, production gate, Pending, Run, installation files, tasks or foreground operations occur in this source.

Compile on the authorized Windows host, using its fixed Framework compiler:

```
C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe /nologo /target:winexe /platform:x86 /optimize+ /warnaserror+ /out:<owned-exe> <Program.cs>
```

Only the default Framework references are required. Runtime argv is exactly:

- `async <root> <nonce>`
- `ready <root> <nonce>`
- `<decimal-MSI-transaction> guardian <root> <nonce>`

The third form preserves the engine's automatic transaction prefix. The factory owns its separate synthetic registry component; this program never touches it.

Root must first create `FutureClassroom-r77-async-chainer-<32-lowercase-hex-nonce>`, with current-user owner, protected DACL granting only that SID and SYSTEM FullControl, and `.owner` exact UTF-8 bytes `future-classroom-owned-r77-async-chainer-fixture/v1\n` (actual LF). No ancestor/root may be a reparse point. Existing directory handles are pinned without DELETE sharing until process return; published/read files must be non-reparse, singly linked files.

## Observation handshake

All JSON is UTF-8 without BOM, one canonical object followed by LF. Common identity fields, in order: `schemaVersion:1, role, nonce, pid, creationFiletime, imagePath, imageSha256, sid, pointerBytes:4`. PID/creation/image path/SHA/SID are read from the original OS process. Creation is the 64-bit Windows FILETIME integer. No decimal number is serialized as a string.

Async first publishes `async-identity.json`; Ready first publishes `ready-identity.json`. Root must use its independent watcher to capture the actual original process object and match PID, creation, full image SHA/size and SID. Only then copy the identity file's exact bytes into `.async-original-captured` or `.ready-original-captured`. Acknowledgments must be create-new atomic publications: create-new sibling, write all bytes, Flush(true), close, then File.Move to final without overwrite. These acknowledgments only schedule this fixture; their presence is not independent OS evidence.

Async's Root ACK wait is at most two seconds and part of its original ten-second clock. Ready has one original two-second clock including Root ACK and waiting for START. The time origin is the static process entry timestamp, before root validation. A watchdog exits 1603 on budget expiry; OS scheduling remains an empirical limit rather than a hard realtime claim.

## Logs and guardian handshake

Each publication uses a role-specific create-new pending sibling, flushed/closed then atomically moved to its final leaf. No existing final leaf is overwritten.

| Leaf | Added fields / meaning |
| --- | --- |
| `START.json` | async identity; startedTimestamp, deadlineTimestamp, stopwatchFrequency; original ten-second clock |
| `READY.json` | ready identity; status READY; only after original START and Root ACK |
| `CHAINER_ENTER.json` | guardian identity; transaction |
| `JOIN_RETURN.json` | guardian identity; transaction, returnCode, changeEventReturned |
| `END_ENTER.json` | guardian identity; transaction, decision ROLLBACK |
| `END_RETURN.json` | guardian identity; transaction, actual returnCode, recorded immediately after native return |
| `CHANGE_EVENT_CLOSED.json` | guardian identity; transaction, checkedClose true |
| `GUARDIAN_EXIT_OBSERVED.json` | async identity; guardianPid, guardianCreationFiletime, guardianImageSha256, actualExitCode 0, originalHandleClosed true |
| `ASYNC_DONE.json` | async identity; status PASS_ORIGINAL_GUARDIAN_EXIT0_AND_CLOSE |
| `FAIL-<role>.json` | actual role identity when available; status FAIL, reason, hresult, elapsedMilliseconds |

After CHAINER_ENTER, guardian waits for `.guardian-original-captured` containing its exact ENTER bytes. Only async writes this ACK, after opening the original guardian with QUERY_LIMITED_INFORMATION|SYNCHRONIZE, checking PID + creation, actual current SID, exact fixture image SHA, canonical ENTER bytes and still-live state. Paths may differ because MSI extracts Binary EXEs under different names. Async retains that original handle, calls WaitForSingleObject, checks actual exit 0, and checked-closes that same handle before writing GUARDIAN_EXIT_OBSERVED and ASYNC_DONE. END_RETURN is never its completion authority.

Guardian calls the real MsiJoinTransaction(transaction,0), requires return 0 and a returned change-owner event, records actual EndRollback with MsiEndTransaction(0), checked-closes the event, and returns 0 only if all succeeded. Native API calls are not killed or wrapped in a renewing timeout; if rollback blocks, async still fails at its original ten-second deadline and root retains the parent's unknown state under its separate thirty-second experiment. This fixture is intended to measure that interaction, not assume success.

Root must retain raw client/MSI logs, identity/ACK/stage files and independent original process-handle observations. Program logs alone cannot establish parent/chainer ownership, MSI rollback completion, product absence or cleanup. A missing stage, nonzero exit, timeout, API error or checked-close failure remains failure.
