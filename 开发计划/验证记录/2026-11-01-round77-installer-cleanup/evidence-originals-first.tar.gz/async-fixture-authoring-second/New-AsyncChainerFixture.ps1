param([switch]$Execute,[string]$HelperExe,[string]$MsiPath,[string]$Root,[string]$ProductCode,[string]$UpgradeCode,[string]$ComponentId,[string]$Nonce)
# Independent synthetic fixture authoring only. Never install or run the helper.
if(-not $Execute){@{status='PREPARED_FIXTURE_FACTORY_NOT_RUN';windows='NOT_RUN';installation='NOT_RUN'}|ConvertTo-Json -Compress;return}
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
function Need([bool]$v,[string]$c){if(-not$v){throw $c}}
function Method($o,[string]$n,[object[]]$a=@()){return $o.GetType().InvokeMember($n,[Reflection.BindingFlags]::InvokeMethod,$null,$o,$a)}
function Get($o,[string]$n,[object[]]$a=@()){return $o.GetType().InvokeMember($n,[Reflection.BindingFlags]::GetProperty,$null,$o,$a)}
function Put($o,[string]$n,[object[]]$a){[void]$o.GetType().InvokeMember($n,[Reflection.BindingFlags]::SetProperty,$null,$o,$a)}
function Close-Com($o){if($null-ne$o){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($o)}}
function Quote([string]$v){Need (-not$v.Contains('"') -and -not$v.EndsWith('\') -and -not$v.Contains("`r") -and -not$v.Contains("`n")) 'EXACT_ARGUMENT_ENCODING';return '"'+$v+'"'}
function FileFact([string]$p){$a=[IO.File]::GetAttributes($p);Need (-not($a-band[IO.FileAttributes]::Directory) -and -not($a-band[IO.FileAttributes]::ReparsePoint)) 'REGULAR_FILE_NO_REPARSE';return @{path=$p;bytes=[long]([IO.FileInfo]::new($p).Length);sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function Sql([string]$sql){$v=$null;try{$v=Method $script:db 'OpenView' @($sql);[void](Method $v 'Execute')}finally{if($null-ne$v){[void](Method $v 'Close');Close-Com $v}}}
function Insert([string]$table,[string[]]$columns,[object[]]$values){
 Need ($columns.Count-eq$values.Count) 'INSERT_FIELD_COUNT';$v=$null;$rec=$null
 try{
  $sql='INSERT INTO `'+$table+'` (`'+($columns-join'`,`')+'`) VALUES ('+((@('?')*$columns.Count)-join',')+')'
  $v=Method $script:db 'OpenView' @($sql);$rec=Method $script:installer 'CreateRecord' @([int]$values.Count)
  for($i=0;$i-lt$values.Count;$i++){if($null-eq$values[$i]){continue};if($values[$i]-is[int]){Put $rec 'IntegerData' @([int]($i+1),[int]$values[$i])}else{Put $rec 'StringData' @([int]($i+1),[string]$values[$i])}}
  [void](Method $v 'Execute' @($rec))
 }finally{Close-Com $rec;if($null-ne$v){[void](Method $v 'Close');Close-Com $v}}
}
function Query([string]$sql,[string[]]$columns){
 $v=$null;$rec=$null;$rows=[Collections.Generic.List[object]]::new()
 try{$v=Method $script:db 'OpenView' @($sql);[void](Method $v 'Execute');while($true){$rec=Method $v 'Fetch';if($null-eq$rec){break};$row=[ordered]@{};for($i=0;$i-lt$columns.Count;$i++){$row[$columns[$i]]=[string](Get $rec 'StringData' @([int]($i+1)))};$rows.Add($row);Close-Com $rec;$rec=$null}}finally{Close-Com $rec;if($null-ne$v){[void](Method $v 'Close');Close-Com $v}}
 return ,($rows.ToArray())
}
function Same-Rows($actual,$expected,[string]$name){
 $a=@($actual|ForEach-Object{$_|ConvertTo-Json -Compress}|Sort-Object);$b=@($expected|ForEach-Object{$_|ConvertTo-Json -Compress}|Sort-Object)
 Need ($a.Count-eq$b.Count -and [string]::Join("`n",$a)-ceq[string]::Join("`n",$b)) ('EXACT_ACTUAL_ROWS_'+$name)
}
$r=[ordered]@{status='FAIL_FIXTURE_BUILD';scope='Independent registry-only Type130/Ready/embedded-chainer timing fixture; not product MSI';installation='NOT_RUN';normalProduct='NOT_RUN';factoryWrites='Only new MSI database in existing owned root';tables=[ordered]@{}}
$script:installer=$null;$script:db=$null;$summary=$null;$created=$false
try{
 Need ($PSVersionTable.PSVersion.Major-eq5 -and $PSVersionTable.PSVersion.Minor-eq1 -and [Environment]::Is64BitProcess) 'FRESH_DESKTOP_PS51_X64'
 Need ($Nonce-cmatch'^[0-9a-f]{32}$' -and $Root-ceq[IO.Path]::GetFullPath($Root) -and [IO.Path]::GetFileName($Root)-ceq('FutureClassroom-r77-async-chainer-'+$Nonce)) 'EXACT_NONCE_ROOT'
 $cursor=$Root;while($cursor){$a=[IO.File]::GetAttributes($cursor);Need (($a-band[IO.FileAttributes]::Directory)-ne0 -and ($a-band[IO.FileAttributes]::ReparsePoint)-eq0) 'REAL_ROOT_ANCESTOR';$cursor=[IO.Path]::GetDirectoryName($cursor)}
 [void](FileFact (Join-Path $Root '.owner'));Need ([IO.File]::ReadAllText((Join-Path $Root '.owner'))-ceq"future-classroom-owned-r77-async-chainer-fixture/v1`n") 'EXACT_FIXTURE_OWNER_MARKER'
 $who=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$who.User.Value}finally{$who.Dispose()}
 $acl=[IO.Directory]::GetAccessControl($Root);Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq$sid) 'PROTECTED_CURRENT_USER_OWNER'
 $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($rules.Count-eq2 -and @($rules|Where-Object{$_.IdentityReference.Value-notin@($sid,'S-1-5-18') -or $_.AccessControlType-ne'Allow' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count-eq0) 'ONLY_CURRENT_USER_SYSTEM_DACL'
 Need ($HelperExe-ceq[IO.Path]::GetFullPath($HelperExe) -and [IO.Path]::GetDirectoryName($HelperExe)-ceq$Root -and $MsiPath-ceq[IO.Path]::GetFullPath($MsiPath) -and [IO.Path]::GetDirectoryName($MsiPath)-ceq$Root -and [IO.Path]::GetExtension($MsiPath)-ceq'.msi' -and $HelperExe-cne$MsiPath) 'DIRECT_CHILD_HELPER_AND_NEW_MSI'
 Need (-not(Test-Path -LiteralPath $MsiPath)) 'MSI_CREATE_NEW_ONLY'
 foreach($g in @($ProductCode,$UpgradeCode,$ComponentId)){Need ($g-cmatch'^\{[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\}$' -and $g-cnotin@('{99378807-098D-5F04-8D4D-F181DFA218D5}','{9E50831D-7811-5039-8BC3-4934647448D8}')) 'SYNTHETIC_CANONICAL_GUIDS_ONLY'}
 Need ($ProductCode-cne$UpgradeCode -and $ProductCode-cne$ComponentId -and $UpgradeCode-cne$ComponentId) 'DISTINCT_FIXTURE_GUIDS'
 $r['factorySource']=FileFact $PSCommandPath;$r['repositoryBase']='8931fabc0520ac659f9c019f9790e4d4f81ff9a7';$r['fixtureSourceCommitted']=$false
 $helperBefore=FileFact $HelperExe;Need ($helperBefore.bytes-ge256 -and $helperBefore.bytes-le4194304) 'BOUNDED_GUI_FIXTURE_IMAGE'
 $bytes=[IO.File]::ReadAllBytes($HelperExe);Need ($bytes[0]-eq77 -and $bytes[1]-eq90) 'PE_MZ';$off=[BitConverter]::ToUInt32($bytes,60);Need ($off-ge64 -and $off-le($bytes.Length-100) -and [BitConverter]::ToUInt32($bytes,[int]$off)-eq17744 -and [BitConverter]::ToUInt16($bytes,[int]$off+4)-eq332 -and [BitConverter]::ToUInt16($bytes,[int]$off+24)-eq267 -and [BitConverter]::ToUInt16($bytes,[int]$off+92)-eq2) 'X86_GUI2_FIXTURE_ONLY'
 $quoted=Quote $Root;$key='Software\FutureClassroomTest\Round77-'+$Nonce;$packageCode=[Guid]::NewGuid().ToString('B').ToUpperInvariant()
 $properties=[ordered]@{ProductCode=$ProductCode;UpgradeCode=$UpgradeCode;ProductName=('FutureClassroom R77 AsyncChainer '+$Nonce);ProductVersion='1.0.0';ProductLanguage='1033';Manufacturer='FutureClassroom-Test';MSIINSTALLPERUSER='1';MSIRESTARTMANAGERCONTROL='DisableShutdown';REBOOT='ReallySuppress'}
 $schemas=[ordered]@{
  Media=@('DiskId','LastSequence','DiskPrompt','Cabinet','VolumeLabel','Source');
  Property=@('Property','Value');Directory=@('Directory','Directory_Parent','DefaultDir');Component=@('Component','ComponentId','Directory_','Attributes','Condition','KeyPath');Feature=@('Feature','Feature_Parent','Title','Description','Display','Level','Directory_','Attributes');FeatureComponents=@('Feature_','Component_');Registry=@('Registry','Root','Key','Name','Value','Component_');InstallExecuteSequence=@('Action','Condition','Sequence');CustomAction=@('Action','Type','Source','Target');Binary=@('Name','Data');MsiEmbeddedChainer=@('MsiEmbeddedChainer','Condition','CommandLine','Source','Type')}
 $ddl=@(
  'CREATE TABLE `Media` (`DiskId` SHORT NOT NULL, `LastSequence` LONG NOT NULL, `DiskPrompt` CHAR(64) LOCALIZABLE, `Cabinet` CHAR(255), `VolumeLabel` CHAR(32), `Source` CHAR(72) PRIMARY KEY `DiskId`)',
  'CREATE TABLE `Property` (`Property` CHAR(72) NOT NULL, `Value` CHAR(0) NOT NULL LOCALIZABLE PRIMARY KEY `Property`)',
  'CREATE TABLE `Directory` (`Directory` CHAR(72) NOT NULL, `Directory_Parent` CHAR(72), `DefaultDir` CHAR(255) NOT NULL LOCALIZABLE PRIMARY KEY `Directory`)',
  'CREATE TABLE `Component` (`Component` CHAR(72) NOT NULL, `ComponentId` CHAR(38), `Directory_` CHAR(72) NOT NULL, `Attributes` SHORT NOT NULL, `Condition` CHAR(255), `KeyPath` CHAR(72) PRIMARY KEY `Component`)',
  'CREATE TABLE `Feature` (`Feature` CHAR(38) NOT NULL, `Feature_Parent` CHAR(38), `Title` CHAR(64) LOCALIZABLE, `Description` CHAR(255) LOCALIZABLE, `Display` SHORT, `Level` SHORT NOT NULL, `Directory_` CHAR(72), `Attributes` SHORT NOT NULL PRIMARY KEY `Feature`)',
  'CREATE TABLE `FeatureComponents` (`Feature_` CHAR(38) NOT NULL, `Component_` CHAR(72) NOT NULL PRIMARY KEY `Feature_`, `Component_`)',
  'CREATE TABLE `Registry` (`Registry` CHAR(72) NOT NULL, `Root` SHORT NOT NULL, `Key` CHAR(255) NOT NULL LOCALIZABLE, `Name` CHAR(255) LOCALIZABLE, `Value` CHAR(0) LOCALIZABLE, `Component_` CHAR(72) NOT NULL PRIMARY KEY `Registry`)',
  'CREATE TABLE `InstallExecuteSequence` (`Action` CHAR(72) NOT NULL, `Condition` CHAR(255), `Sequence` SHORT PRIMARY KEY `Action`)',
  'CREATE TABLE `CustomAction` (`Action` CHAR(72) NOT NULL, `Type` SHORT NOT NULL, `Source` CHAR(72), `Target` CHAR(255) PRIMARY KEY `Action`)',
  'CREATE TABLE `Binary` (`Name` CHAR(72) NOT NULL, `Data` OBJECT NOT NULL PRIMARY KEY `Name`)',
  'CREATE TABLE `MsiEmbeddedChainer` (`MsiEmbeddedChainer` CHAR(72) NOT NULL, `Condition` CHAR(255), `CommandLine` CHAR(255), `Source` CHAR(72) NOT NULL, `Type` SHORT NOT NULL PRIMARY KEY `MsiEmbeddedChainer`)')
 $expected=[ordered]@{};foreach($t in $schemas.Keys){$expected[$t]=[Collections.Generic.List[object]]::new()}
 function Add([string]$table,[object[]]$values){Insert $table $schemas[$table] $values;$row=[ordered]@{};for($i=0;$i-lt$values.Count;$i++){$row[$schemas[$table][$i]]=$(if($null-eq$values[$i]){''}else{[string]$values[$i]})};$expected[$table].Add($row)}
 $script:installer=New-Object -ComObject WindowsInstaller.Installer;$script:db=Method $script:installer 'OpenDatabase' @($MsiPath,[int]3);$created=$true
 foreach($sql in $ddl){Sql $sql}
 foreach($name in $properties.Keys){Add 'Property' @($name,$properties[$name])}
 Add 'Media' @([int]1,[int]0,$null,$null,$null,$null)
 Add 'Directory' @('TARGETDIR',$null,'SourceDir')
 Add 'Component' @('FixtureComponent',$ComponentId,'TARGETDIR',[int]4,$null,'FixtureMarker')
 Add 'Feature' @('FixtureFeature',$null,'R77 synthetic registry fixture',$null,[int]0,[int]1,$null,[int]0)
 Add 'FeatureComponents' @('FixtureFeature','FixtureComponent')
 Add 'Registry' @('FixtureMarker',[int]1,$key,'Marker','#1','FixtureComponent')
 $sequence=@(@('CostInitialize',800),@('FileCost',900),@('CostFinalize',1000),@('InstallValidate',1400),@('AsyncBegin',1498),@('Ready',1499),@('InstallInitialize',1500),@('ProcessComponents',1600),@('UnpublishFeatures',1800),@('RemoveRegistryValues',2600),@('WriteRegistryValues',5000),@('RegisterUser',6000),@('RegisterProduct',6100),@('PublishFeatures',6300),@('PublishProduct',6400),@('InstallExecute',6500),@('InstallFinalize',6600))
 foreach($a in $sequence){Add 'InstallExecuteSequence' @($a[0],$(if($a[0]-in@('AsyncBegin','Ready')){'NOT Installed'}else{$null}),[int]$a[1])}
 Add 'CustomAction' @('AsyncBegin',[int]130,'AsyncFixture',('async '+$quoted+' '+$Nonce))
 Add 'CustomAction' @('Ready',[int]2,'AsyncFixture',('ready '+$quoted+' '+$Nonce))
 Add 'MsiEmbeddedChainer' @('FixtureGuardian','NOT Installed',('guardian '+$quoted+' '+$Nonce),'AsyncFixture',[int]2)
 $v=$null;$rec=$null;try{$v=Method $script:db 'OpenView' @('INSERT INTO `Binary` (`Name`,`Data`) VALUES (?,?)');$rec=Method $script:installer 'CreateRecord' @([int]2);Put $rec 'StringData' @([int]1,'AsyncFixture');[void](Method $rec 'SetStream' @([int]2,$HelperExe));[void](Method $v 'Execute' @($rec))}finally{Close-Com $rec;if($null-ne$v){[void](Method $v 'Close');Close-Com $v}}
 $summary=Get $script:db 'SummaryInformation' @([int]20)
 foreach($p in @(@(1,[int]1252),@(2,'R77 synthetic async/chainer timing'),@(3,'Registry-only independent fixture'),@(4,'FutureClassroom-Test'),@(7,'Intel;1033'),@(9,$packageCode),@(14,[int]500),@(15,[int]8),@(18,'R77 COM fixture factory'),@(19,[int]2))){Put $summary 'Property' @([int]$p[0],$p[1])}
 [void](Method $summary 'Persist');Close-Com $summary;$summary=$null;[void](Method $script:db 'Commit');Close-Com $script:db;$script:db=$null
 $script:db=Method $script:installer 'OpenDatabase' @($MsiPath,[int]0)
 $tables=Query 'SELECT `Name` FROM `_Tables`' @('Name');$actualNames=@($tables|ForEach-Object{$_.Name}|Sort-Object);$expectedNames=@($schemas.Keys|Sort-Object);Need ([string]::Join('|',$actualNames)-ceq[string]::Join('|',$expectedNames)) 'EXACT_ALL_ELEVEN_TABLES'
 $columns=Query 'SELECT `Table`,`Number`,`Name`,`Type` FROM `_Columns`' @('Table','Number','Name','Type');$r['columnMetadata']=$columns
 foreach($t in $schemas.Keys){$actualColumns=@($columns|Where-Object{$_.Table-ceq$t}|Sort-Object {[int]$_.Number}|ForEach-Object{$_.Name});Need ([string]::Join('|',$actualColumns)-ceq[string]::Join('|',$schemas[$t])) 'EXACT_ACTUAL_COLUMN_NAMES_ORDER'}
 foreach($t in $schemas.Keys){if($t-ceq'Binary'){continue};$rows=Query ('SELECT `'+($schemas[$t]-join'`,`')+'` FROM `'+$t+'`') $schemas[$t];Same-Rows $rows $expected[$t].ToArray() $t;$r.tables[$t]=$rows}
 $v=$null;$rec=$null;$extra=$null;$stream=[IO.MemoryStream]::new()
 try{
  $v=Method $script:db 'OpenView' @('SELECT `Name`,`Data` FROM `Binary`');[void](Method $v 'Execute');$rec=Method $v 'Fetch';Need ($null-ne$rec -and (Get $rec 'StringData' @([int]1))-ceq'AsyncFixture') 'ONE_BINARY_STREAM'
  while($true){$chunk=[string](Method $rec 'ReadStream' @([int]2,[int]8192,[int]1));if($chunk.Length-eq0){break};foreach($ch in $chunk.ToCharArray()){Need ([int]$ch-le255) 'MSI_RAW_BYTE_BSTR';$stream.WriteByte([byte]$ch)};Need ($stream.Length-le4194304) 'BINARY_READBACK_BOUND'}
  $extra=Method $v 'Fetch';Need ($null-eq$extra) 'NO_EXTRA_BINARY_ROWS';$readback=$stream.ToArray();Need ($readback.Length-eq$bytes.Length -and [Convert]::ToBase64String($readback)-ceq[Convert]::ToBase64String($bytes)) 'EXACT_BINARY_BYTE_READBACK'
  $h=[Security.Cryptography.SHA256]::Create();try{$r.tables['Binary']=@(@{Name='AsyncFixture';bytes=$readback.Length;sha256=([BitConverter]::ToString($h.ComputeHash($readback))).Replace('-','').ToLowerInvariant()})}finally{$h.Dispose()}
 }finally{$stream.Dispose();Close-Com $extra;Close-Com $rec;if($null-ne$v){[void](Method $v 'Close');Close-Com $v}}
 $summary=Get $script:db 'SummaryInformation' @([int]0);$r['summary']=[ordered]@{};foreach($i in @(1,2,3,4,7,9,14,15,18,19)){$r.summary[[string]$i]=Get $summary 'Property' @([int]$i)};Need ($r.summary['7']-ceq'Intel;1033' -and $r.summary['14']-eq500 -and $r.summary['15']-eq8 -and $r.summary['9']-ceq$packageCode) 'ACTUAL_INTEL_LIMITED_SUMMARY';Close-Com $summary;$summary=$null;Close-Com $script:db;$script:db=$null
 $helperAfter=FileFact $HelperExe;Need ($helperBefore.bytes-eq$helperAfter.bytes -and $helperBefore.sha256-ceq$helperAfter.sha256 -and $r.tables.Binary[0].sha256-ceq$helperBefore.sha256) 'HELPER_SOURCE_UNCHANGED'
 $r['helper']=$helperAfter;$r['msi']=FileFact $MsiPath;$r['root']=$Root;$r['nonce']=$Nonce;$r['currentUserSid']=$sid;$r['productCode']=$ProductCode;$r['upgradeCode']=$UpgradeCode;$r['componentId']=$ComponentId;$r['marker']=@{view='HKCU32';key=$key;name='Marker';value=1};$r.status='PASS_ACTUAL_COM_BUILT_AND_EXACT_READBACK_FIXTURE_ONLY_NOT_INSTALLED'
}catch{$r['errorType']=$_.Exception.GetType().FullName;$r['error']=[string]$_;$r['createdMsiRetained']=$created}
finally{Close-Com $summary;Close-Com $script:db;Close-Com $script:installer}
$r|ConvertTo-Json -Depth 14 -Compress
if($r.status-cne'PASS_ACTUAL_COM_BUILT_AND_EXACT_READBACK_FIXTURE_ONLY_NOT_INSTALLED'){exit 1};exit 0
