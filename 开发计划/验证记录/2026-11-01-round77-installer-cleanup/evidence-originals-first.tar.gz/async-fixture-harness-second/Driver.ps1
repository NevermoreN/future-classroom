[CmdletBinding()]
param([switch]$Execute,[string]$Root,[string]$ConfigSha256,[string]$ManifestSha256)
$ErrorActionPreference='Stop'
if(-not $Execute){@{status='PREPARED_NOT_EXECUTED';required=@('-Execute','-Root','-ConfigSha256','-ManifestSha256');wholeSeconds=120;clientMaximumSeconds=30;asyncSeconds=10;readySeconds=2}|ConvertTo-Json -Compress;return}
$clock=[Diagnostics.Stopwatch]::StartNew()
$originalTemp=$env:TEMP;$originalTmp=$env:TMP
$result=[ordered]@{status='FAIL_RETAIN_UNKNOWN_ORIGINALS';sourceGit='8931fabc0520ac659f9c019f9790e4d4f81ff9a7';scope='Independent synthetic registry-only MSI AsyncWait ordering; not Rust product validation';wholeSeconds=120;clientMaximumSeconds=30;asyncSeconds=10;readySeconds=2;nativeProductBudgetChanged=$false;errors=@();classification='UNKNOWN';operations=@();acks=@();mutations=@('owned fixture files','nonce fixture MSI install/necessary formal uninstall');sharedServiceKill=$false;manualRegistryOrCacheDelete=$false}
$observer=$null;$client=$null;$uninstall=$null;$writer=$null;$config=$null;$nativeReady=$false;$sourceValidated=$false;$clientStarted=$false;$physicalReturned=$false;$rootReady=$false
function Need([bool]$Condition,[string]$Stage){if(-not $Condition){throw $Stage}}
function Elapsed {return [int]$clock.ElapsedMilliseconds}
function Budget([int]$Deadline=120000){Need ((Elapsed)-lt $Deadline) 'FIXTURE_ORIGINAL_DEADLINE_EXPIRED'}
function Hash([string]$Path){return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Write-NewJson([string]$Name,$Object){
 $p=Join-Path $Root $Name;Need (-not [IO.File]::Exists($p)) ('REPORT_ALREADY_EXISTS:'+ $Name)
 $bytes=[Text.UTF8Encoding]::new($false).GetBytes(($Object|ConvertTo-Json -Depth 32 -Compress))
 $s=[IO.FileStream]::new($p,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
 try{$s.Write($bytes,0,$bytes.Length);$s.Flush($true)}finally{$s.Dispose()}
}
function Read-Bounded([string]$Name,[int]$Maximum=16384){
 $p=Join-Path $Root $Name;if(-not [IO.File]::Exists($p)){return $null}
 Need (([IO.File]::GetAttributes($p)-band [IO.FileAttributes]::ReparsePoint)-eq 0) ('REPORT_REPARSE:'+ $Name)
 $b=[IO.File]::ReadAllBytes($p);Need ($b.Length-gt 0 -and $b.Length-le $Maximum) ('REPORT_BOUNDED:'+ $Name)
 return ,$b
}
function Observe-And-Acknowledge {
 Budget
 $snapshot=$observer.Snapshot();$line=$snapshot|ConvertTo-Json -Depth 12 -Compress;$writer.WriteLine($line);$writer.Flush()
 foreach($role in @('async','ready')){
  $ack='.'+$role+'-original-captured';if([IO.File]::Exists((Join-Path $Root $ack))){continue}
  $bytes=Read-Bounded ($role+'-identity.json');if($null-eq $bytes){continue}
  $id=[Text.UTF8Encoding]::new($false,$true).GetString($bytes)|ConvertFrom-Json
  Need ($id.schemaVersion-eq 1 -and $id.role-ceq $role -and $id.nonce-ceq $config.nonce) ('IDENTITY_CLOSED_ROLE_NONCE:'+ $role)
  Need ($id.sid-ceq $config.expectedUserSid -and $id.imageSha256-ceq $result.compiledHelper.sha256 -and $id.pointerBytes-eq 4) ('IDENTITY_SID_IMAGE_BITS:'+ $role)
  Need ([uint64]$id.pid-gt 0 -and [uint64]$id.creationFiletime-gt 0) ('IDENTITY_PID_CREATION:'+ $role)
  $facts=@($snapshot.Processes|Where-Object{$_.Pid-eq [uint32]$id.pid -and $_.CreationFiletime-eq [long]$id.creationFiletime -and $_.IdentityStatus-ceq 'ORIGINAL_QUERY_SYNC_HANDLE_EXACT_IMAGE_BYTES_USER' -and $_.Sha256-ceq $id.imageSha256 -and $_.Sid-ceq $id.sid -and [String]::Equals($_.Image,$id.imagePath,[StringComparison]::OrdinalIgnoreCase)})
  Need ($facts.Count-le 1) ('NONUNIQUE_HELD_IDENTITY:'+ $role)
  if($facts.Count-eq 1){
   # Identity JSON is NOT authority. Only the actual independently held process
   # object permits echoing these exact original bytes to the fixture barrier.
   $temp=Join-Path $Root ('.'+$role+'-ack-publishing');$dest=Join-Path $Root $ack
   $s=[IO.FileStream]::new($temp,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
   try{$s.Write($bytes,0,$bytes.Length);$s.Flush($true)}finally{$s.Dispose()}
   [IO.File]::Move($temp,$dest)
   $result.acks+=@{role=$role;pid=$id.pid;creationFiletime=$id.creationFiletime;originalIdentityBytes=$bytes.Length;identitySha256=Hash (Join-Path $Root ($role+'-identity.json'));ackSha256=Hash $dest;originalFact=$facts[0]}
  }
 }
 return $snapshot
}
function Physical-Returned($Report){
 if($null-eq $Report -or -not $Report.Closed){return $false}
 foreach($f in @($Report.Processes)){
  if($f.IdentityStatus-cne 'ORIGINAL_QUERY_SYNC_HANDLE_EXACT_IMAGE_BYTES_USER' -or $f.ActualWait-ne 0 -or $f.ExitStatus-cne 'ACTUAL_ORIGINAL_GET_EXIT_CODE' -or $f.CloseStatus-cne 'CHECKED_CLOSE_SUCCESS'){return $false}
 }
 # Nonzero actual exit is negative evidence, not a reason to fabricate a live
 # owner or skip safe cleanup. Metadata failures remain supplemental UNKNOWN.
 foreach($e in @($Report.Errors)){if(-not $e.StartsWith('candidate_metadata:')-or $e.Contains('unknown_close_never_retry')-or $e.Contains('argv_LocalFree_unknown')){return $false}}
 return $true
}
$nativeSource=@'
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;
public static class FcR77FixtureNative {
 [DllImport("msi.dll",CharSet=CharSet.Unicode)] static extern uint MsiEnumProductsEx(string product,string sid,uint context,uint index,StringBuilder p,out uint actual,StringBuilder user,ref uint n);
 [DllImport("msi.dll",CharSet=CharSet.Unicode)] static extern uint MsiEnumRelatedProducts(string upgrade,uint reserved,uint index,StringBuilder product);
 [DllImport("msi.dll",CharSet=CharSet.Unicode)] static extern int MsiQueryProductState(string product);
 public sealed class Product {public string ProductCode,UserSid;public uint Context;}
 [DllImport("msi.dll",CharSet=CharSet.Unicode)] static extern int MsiGetComponentPathEx(string product,string component,string sid,uint context,StringBuilder path,ref uint n);
 public sealed class State {public Product[] Products;public string[] Related;public int ProductState,ComponentState;public string ComponentPath;public bool KnownAbsent;public bool OwnSingleRegistration;}
 public static State Query(string product,string upgrade,string component,string sid){
  var products=new List<Product>();var related=new List<string>();
  foreach(uint context in new uint[]{3,4})for(uint i=0;i<16;i++){
   StringBuilder p=new StringBuilder(39),user=new StringBuilder(256);uint n=256,actual;
   uint code=MsiEnumProductsEx(product,context==4?null:sid,context,i,p,out actual,user,ref n);
   if(code==259)break;if(code!=0)throw new Win32Exception((int)code,"MsiEnumProductsEx");
   if(i==15||n>=256)throw new InvalidOperationException("bounded_product_registration");
   products.Add(new Product{ProductCode=p.ToString(),UserSid=user.ToString(),Context=actual});
  }
  for(uint i=0;i<16;i++){var p=new StringBuilder(39);uint code=MsiEnumRelatedProducts(upgrade,0,i,p);if(code==259)break;if(code!=0)throw new Win32Exception((int)code,"MsiEnumRelatedProducts");if(i==15)throw new InvalidOperationException("bounded_related");related.Add(p.ToString());}
  int state=MsiQueryProductState(product);var path=new StringBuilder(1024);uint chars=1024;int componentState=MsiGetComponentPathEx(product,component,sid,2,path,ref chars);if(componentState==3&&chars>=1024)throw new InvalidOperationException("bounded_component_path");bool own=products.Count==1&&products[0].Context==2&&products[0].ProductCode==product&&products[0].UserSid==sid&&related.Count==1&&related[0]==product&&componentState==3;
  return new State{Products=products.ToArray(),Related=related.ToArray(),ProductState=state,ComponentState=componentState,ComponentPath=path.ToString(),KnownAbsent=products.Count==0&&related.Count==0&&state==-1&&componentState==-1,OwnSingleRegistration=own};
 }
 [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)] struct Startup {public uint Size;public string Reserved,Desktop,Title;public uint X,Y,XSize,YSize,XChars,YChars,Fill,Flags;public ushort Show,ReservedSize;public IntPtr ReservedBytes,Input,Output,Error;}
 [StructLayout(LayoutKind.Sequential)] struct Pi {public IntPtr Process,Thread;public uint Pid,Tid;}
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool CreateProcess(string image,StringBuilder cmd,IntPtr pa,IntPtr ta,bool inherit,uint flags,IntPtr env,string cwd,ref Startup si,out Pi pi);
 [DllImport("kernel32.dll",SetLastError=true)] static extern uint WaitForSingleObject(IntPtr h,uint ms);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetExitCodeProcess(IntPtr h,out uint code);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetProcessTimes(IntPtr h,out long c,out long e,out long k,out long u);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool CloseHandle(IntPtr h);
 public sealed class Client {
  public uint Pid;public long CreationFiletime;public string Image,Arguments;public uint? ActualWait,ActualExitCode;public bool ThreadCloseSuccess,ProcessCloseAttempted,ProcessCloseSuccess;public int LastError;internal IntPtr Held;
  public void Refresh(){if(Held==IntPtr.Zero)return;uint w=WaitForSingleObject(Held,0);ActualWait=w;if(w==0){uint code;if(!GetExitCodeProcess(Held,out code)){LastError=Marshal.GetLastWin32Error();throw new Win32Exception(LastError,"GetExitCodeProcess");}ActualExitCode=code;}else if(w!=258){LastError=Marshal.GetLastWin32Error();throw new Win32Exception(LastError,"WaitForSingleObject");}}
  public void CloseReturned(){Refresh();if(ActualWait!=0)throw new InvalidOperationException("live_or_unknown_client_retained");IntPtr original=Held;Held=IntPtr.Zero;ProcessCloseAttempted=true;ProcessCloseSuccess=CloseHandle(original);if(!ProcessCloseSuccess){LastError=Marshal.GetLastWin32Error();throw new Win32Exception(LastError,"unknown_close_never_retry");}}
 }
 public static Client Start(string image,string args){var si=new Startup();si.Size=(uint)Marshal.SizeOf(typeof(Startup));si.Flags=1;si.Show=0;Pi pi;var c=new Client();if(!CreateProcess(image,new StringBuilder("\""+image+"\" "+args),IntPtr.Zero,IntPtr.Zero,false,0x08000000,IntPtr.Zero,null,ref si,out pi))throw new Win32Exception(Marshal.GetLastWin32Error(),"CreateProcess");c.Held=pi.Process;c.Pid=pi.Pid;c.Image=image;c.Arguments=args;c.ThreadCloseSuccess=CloseHandle(pi.Thread);if(!c.ThreadCloseSuccess)c.LastError=Marshal.GetLastWin32Error();long born,e,k,u;if(GetProcessTimes(c.Held,out born,out e,out k,out u))c.CreationFiletime=born;else c.LastError=Marshal.GetLastWin32Error();return c;}
}
'@
function Fixture-State {
 $state=[FcR77FixtureNative]::Query($config.productCode,$config.upgradeCode,$config.componentId,$config.expectedUserSid)
 $b=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry32);$key=$null
 try{$key=$b.OpenSubKey($config.registryKey,$false);$markerAbsent=$null-eq $key;if($key){$names=@($key.GetValueNames());$subkeys=$key.SubKeyCount;$kind=if($names-contains 'Marker'){$key.GetValueKind('Marker').ToString()}else{$null};$value=$key.GetValue('Marker',$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)}else{$names=@();$subkeys=0;$kind=$null;$value=$null}
 }finally{if($key){$key.Dispose()};$b.Dispose()}
 return @{registration=$state;registryKey=$config.registryKey;registry32KnownAbsent=$markerAbsent;markerNames=$names;subKeyCount=$subkeys;markerKind=$kind;markerValue=$value;knownAbsent=($state.KnownAbsent-and $markerAbsent);ownMarkerExact=($state.OwnSingleRegistration-and -not $markerAbsent-and $names.Count-eq 1-and $names[0]-ceq 'Marker'-and $subkeys-eq 0-and $kind-ceq 'DWord'-and $value-eq 1)}
}
function Assess-Stages {
 $stages=[ordered]@{};$parsed=@{}
 foreach($name in @('async-identity','ready-identity','START','READY','CHAINER_ENTER','JOIN_RETURN','END_ENTER','END_RETURN','CHANGE_EVENT_CLOSED','GUARDIAN_EXIT_OBSERVED','ASYNC_DONE','FAIL-async','FAIL-ready','FAIL-guardian')){
  $bytes=Read-Bounded ($name+'.json');if($null-eq $bytes){continue};$o=[Text.UTF8Encoding]::new($false,$true).GetString($bytes)|ConvertFrom-Json
  Need ($o.schemaVersion-eq 1-and $o.nonce-ceq $config.nonce-and $o.sid-ceq $config.expectedUserSid-and $o.imageSha256-ceq $result.compiledHelper.sha256-and $o.pointerBytes-eq 4) ('SOURCE_BOUND_STAGE_IDENTITY:'+ $name)
  $role=if($name-in @('START','GUARDIAN_EXIT_OBSERVED','ASYNC_DONE','async-identity','FAIL-async')){'async'}elseif($name-in @('READY','ready-identity','FAIL-ready')){'ready'}else{'guardian'}
  Need ($o.role-ceq $role) ('CLOSED_STAGE_ROLE:'+ $name)
  $parsed[$name]=$o;$stages[$name]=@{path=$name+'.json';bytes=$bytes.Length;sha256=Hash (Join-Path $Root ($name+'.json'));actual=$o}
 }
 $result.stages=$stages;$result.clientIntegerPolicy='Actual MSI client integer retained; intentional EndRollback may produce nonzero client. No ActionReturn or JSON flag substitutes for actual OS exit.'
 $required=@('START','READY','CHAINER_ENTER','JOIN_RETURN','END_ENTER','END_RETURN','CHANGE_EVENT_CLOSED','GUARDIAN_EXIT_OBSERVED','ASYNC_DONE');$missing=@($required|Where-Object{-not $parsed.ContainsKey($_)});$result.missingStages=$missing
 $acks=@($result.acks|ForEach-Object{$_.role}|Sort-Object -Unique)
 $identityReturned=$true;foreach($role in @('async','ready')){
  $key=$role+'-identity';if(-not $parsed.ContainsKey($key)){$identityReturned=$false;continue};$id=$parsed[$key]
  $facts=@($result.observer.Processes|Where-Object{$_.Pid-eq $id.pid-and $_.CreationFiletime-eq $id.creationFiletime-and $_.ActualWait-eq 0-and $_.ActualExitCode-eq 0-and $_.CloseStatus-ceq 'CHECKED_CLOSE_SUCCESS'})
  if($facts.Count-ne 1){$identityReturned=$false}
 }
 $supported=$false
 if($missing.Count-eq 0-and $acks.Count-eq 2-and $identityReturned-and $physicalReturned-and $result.finalAbsence.knownAbsent-and @($result.observer.Processes|Where-Object{$_.ActualExitCode-ne 0}).Count-eq 0){
  $enter=$parsed.CHAINER_ENTER;$join=$parsed.JOIN_RETURN;$end=$parsed.END_RETURN;$observed=$parsed.GUARDIAN_EXIT_OBSERVED
  $sameGuardian=$true;foreach($name in @('JOIN_RETURN','END_ENTER','END_RETURN','CHANGE_EVENT_CLOSED')){$g=$parsed[$name];if($g.role-cne 'guardian'-or $g.pid-ne $enter.pid-or $g.creationFiletime-ne $enter.creationFiletime-or $g.transaction-ne $enter.transaction){$sameGuardian=$false}}
  $sameAsync=$true;foreach($name in @('START','GUARDIAN_EXIT_OBSERVED','ASYNC_DONE')){if($parsed[$name].pid-ne $parsed['async-identity'].pid-or $parsed[$name].creationFiletime-ne $parsed['async-identity'].creationFiletime){$sameAsync=$false}}
  $supported=$sameGuardian-and $sameAsync-and $parsed.READY.pid-eq $parsed['ready-identity'].pid-and $parsed.READY.creationFiletime-eq $parsed['ready-identity'].creationFiletime-and $enter.transaction-gt 0-and $join.returnCode-eq 0-and $join.changeEventReturned-and $end.returnCode-eq 0-and $parsed.END_ENTER.decision-ceq 'ROLLBACK'-and $parsed.CHANGE_EVENT_CLOSED.checkedClose-and $observed.guardianPid-eq $enter.pid-and $observed.guardianCreationFiletime-eq $enter.creationFiletime-and $observed.guardianImageSha256-ceq $enter.imageSha256-and $observed.actualExitCode-eq 0-and $observed.originalHandleClosed-and $parsed.ASYNC_DONE.status-ceq 'PASS_ORIGINAL_GUARDIAN_EXIT0_AND_CLOSE'
 }
 if($supported){$result.classification='PROBE_SUPPORTED';$result.status='PASS_FINITE_SYNTHETIC_ASYNC_CHAINER_ORDER_ONLY'}
 elseif($acks.Count-eq 2-and $parsed.ContainsKey('START')-and $parsed.ContainsKey('READY')-and $physicalReturned){$result.classification='PROBE_REJECTED';$result.status='PASS_NEGATIVE_EVIDENCE_CAPTURED_ACTUAL_RESULTS_NOT_ORDER_SUPPORT';$result.rejection='Complete source-bound success chain not observed. Inspect original API integers, missing stages and actual async exit; no unsupported causal guess.'}
 else{$result.classification='PROBE_INCONCLUSIVE_INSTRUMENT_OR_STARTUP';$result.status='FAIL_NO_COMPLETE_STARTUP_OR_ORIGINAL_CAPTURE_PROOF'}
}
try {
 Need ($Root-and $Root-notmatch '["\r\n]' -and [IO.Path]::IsPathRooted($Root)) 'EXPLICIT_SAFE_ROOT'
 Need ($ConfigSha256-cmatch '\A[0-9a-f]{64}\z' -and $ManifestSha256-cmatch '\A[0-9a-f]{64}\z') 'EXPLICIT_INPUT_PINS'
 $Root=[IO.Path]::GetFullPath($Root).TrimEnd('\');Need ([IO.Directory]::Exists($Root)) 'PRECREATED_PROTECTED_ROOT_REQUIRED'
 Need (([IO.File]::GetAttributes($Root)-band [IO.FileAttributes]::ReparsePoint)-eq 0) 'ROOT_REPARSE'
 $configPath=Join-Path $Root 'config.json';$manifestPath=Join-Path $Root 'inputs.json';Need ((Hash $configPath)-ceq $ConfigSha256-and (Hash $manifestPath)-ceq $ManifestSha256) 'CONFIG_MANIFEST_PIN'
 $config=Get-Content -LiteralPath $configPath -Raw|ConvertFrom-Json;$manifest=Get-Content -LiteralPath $manifestPath -Raw|ConvertFrom-Json
 Need ($config.schemaVersion-eq 1-and $config.sourceGit-ceq $result.sourceGit-and $config.nonce-cmatch '\A[0-9a-f]{32}\z') 'CLOSED_SOURCE_CONFIG'
 Need ($config.wholeSeconds-eq 120-and $config.clientMaximumSeconds-eq 30-and $config.asyncSeconds-eq 10-and $config.readySeconds-eq 2) 'ORIGINAL_FIXTURE_BUDGETS'
 $sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value;Need ($sid-ceq $config.expectedUserSid) 'ACTUAL_USER_SID'
 $leaf='FutureClassroom-r77-async-chainer-'+$config.nonce;Need ([IO.Path]::GetFileName($Root)-ceq $leaf-and $config.rootName-ceq $leaf-and [IO.Path]::GetDirectoryName($Root)-ieq [IO.Path]::GetTempPath().TrimEnd('\')) 'EXACT_NONCE_TEMP_ROOT'
 Need ([IO.File]::ReadAllText((Join-Path $Root '.owner'))-ceq "future-classroom-owned-r77-async-chainer-fixture/v1`n") 'EXACT_OWNER_MARKER'
 $acl=Get-Acl -LiteralPath $Root;Need ($acl.AreAccessRulesProtected-and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq $sid) 'EXACT_ROOT_OWNER_PROTECTED'
 $aces=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($aces.Count-eq 2) 'EXACT_ROOT_TWO_ACES'
 foreach($a in $aces){Need ($a.IdentityReference.Value-in @($sid,'S-1-5-18')-and $a.AccessControlType-eq [Security.AccessControl.AccessControlType]::Allow-and $a.FileSystemRights-eq [Security.AccessControl.FileSystemRights]::FullControl-and -not $a.IsInherited) 'EXACT_ROOT_ALLOWED_FULL_CONTROL'}
 Need (@($aces|ForEach-Object{$_.IdentityReference.Value}|Sort-Object -Unique).Count-eq 2) 'ROOT_DISTINCT_USER_SYSTEM'
 Need ($config.registryKey-ceq ('Software\FutureClassroomTest\Round77-'+$config.nonce)) 'CLOSED_NONCE_REGISTRY_KEY'
 foreach($g in @($config.productCode,$config.upgradeCode,$config.componentId)){Need ($g-cmatch '\A\{[0-9A-F]{8}(-[0-9A-F]{4}){3}-[0-9A-F]{12}\}\z'-and $g-notin @('{9E50831D-7811-5039-8BC3-4934647448D8}','{99378807-098D-5F04-8D4D-F181DFA218D5}')) 'SYNTHETIC_GUID_NOT_PRODUCTION'}
 Need (@($config.productCode,$config.upgradeCode,$config.componentId|Sort-Object -Unique).Count-eq 3) 'DISTINCT_SYNTHETIC_GUIDS'
 $allowed=@('Program.cs','New-AsyncChainerFixture.ps1','ProcessObserver.cs','Driver.ps1','config.json');Need (@($manifest.files).Count-eq 5) 'CLOSED_FIVE_INPUTS'
 foreach($f in $manifest.files){Need ($f.path-in $allowed-and $f.sha256-cmatch '\A[0-9a-f]{64}\z') 'CLOSED_MANIFEST_MEMBER';$fp=Join-Path $Root $f.path;Need ((Get-Item -LiteralPath $fp).Length-eq $f.bytes-and (Hash $fp)-ceq $f.sha256) ('ORIGINAL_MEMBER_SHA:'+ $f.path)}
 Need (@($manifest.files|ForEach-Object{$_.path}|Sort-Object -Unique).Count-eq 5) 'UNIQUE_FIVE_INPUTS'
 foreach($f in @($config.sources)){Need ($f.path-in $allowed-and $f.path-ne 'config.json') 'CLOSED_SOURCE_MEMBER';$fp=Join-Path $Root $f.path;Need ((Get-Item -LiteralPath $fp).Length-eq $f.bytes-and (Hash $fp)-ceq $f.sha256) ('CONFIG_SOURCE_SHA:'+ $f.path)}
 Need ((Hash (Join-Path $Root 'ProcessObserver.cs'))-ceq 'ae5ad0205854e0f2e731394e6f72a0f2481818da1efabf88abeccd716a256b31') 'FROZEN_OBSERVER_SOURCE'
 $sourceValidated=$true;$rootReady=$true;$result.configSha256=$ConfigSha256;$result.manifestSha256=$ManifestSha256;$result.nonce=$config.nonce
 $compilerRoot=Join-Path $Root 'compiler-temp';Need (-not [IO.Directory]::Exists($compilerRoot)) 'FRESH_COMPILER_TEMP'
 $security=[Security.AccessControl.DirectorySecurity]::new();$security.SetOwner([Security.Principal.SecurityIdentifier]::new($sid));$security.SetAccessRuleProtection($true,$false)
 foreach($owner in @($sid,'S-1-5-18')){$security.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new([Security.Principal.SecurityIdentifier]::new($owner),[Security.AccessControl.FileSystemRights]::FullControl,[Security.AccessControl.InheritanceFlags]'ContainerInherit,ObjectInherit',[Security.AccessControl.PropagationFlags]::None,[Security.AccessControl.AccessControlType]::Allow))}
 [IO.Directory]::CreateDirectory($compilerRoot,$security)|Out-Null;$env:TEMP=$compilerRoot;$env:TMP=$compilerRoot
 $compileStart=Elapsed;$compileDeadline=[Math]::Min(30000,120000);$csc=Join-Path ([Environment]::GetFolderPath('Windows')) 'Microsoft.NET\Framework\v4.0.30319\csc.exe';$exe=Join-Path $Root 'helper.exe'
 Need (-not [IO.File]::Exists($exe)) 'CREATE_NEW_HELPER_ONLY'
 $compileArgs=@('/nologo','/target:winexe','/platform:x86','/optimize+','/warnaserror+',('/out:'+$exe),(Join-Path $Root 'Program.cs'))
 $cp=[Diagnostics.Process]::new();$cp.StartInfo.FileName=$csc;$cp.StartInfo.Arguments=($compileArgs|ForEach-Object{'"'+$_+'"'})-join ' ';$cp.StartInfo.UseShellExecute=$false;$cp.StartInfo.CreateNoWindow=$true;$cp.StartInfo.RedirectStandardOutput=$true;$cp.StartInfo.RedirectStandardError=$true
 Need ($cp.Start()) 'CSC_START';$result.compile=@{image=$csc;compilerSha256=Hash $csc;arguments=$compileArgs;pid=$cp.Id;actualExit=$false;status='UNKNOWN_UNTIL_ORIGINAL_EXIT'};$co=$cp.StandardOutput.ReadToEndAsync();$ce=$cp.StandardError.ReadToEndAsync();Need ($cp.WaitForExit([Math]::Max(1,$compileDeadline-(Elapsed)))) 'CSC_UNKNOWN_LIVE_NOT_KILLED';Need ($co.Wait(1000)-and $ce.Wait(1000)) 'CSC_PIPES_UNKNOWN';[IO.File]::WriteAllText((Join-Path $Root 'csc.stdout.log'),$co.Result);[IO.File]::WriteAllText((Join-Path $Root 'csc.stderr.log'),$ce.Result)
 $result.compile=@{image=$csc;compilerSha256=Hash $csc;arguments=$compileArgs;exitCode=$cp.ExitCode;actualExit=$true;elapsedMilliseconds=(Elapsed)-$compileStart};$cp.Dispose();Need ($result.compile.exitCode-eq 0) 'ACTUAL_CSC_FAILED'
 Add-Type -LiteralPath (Join-Path $Root 'ProcessObserver.cs') -ReferencedAssemblies @('System.dll','System.Core.dll','System.Management.dll','System.Security.dll')
 Add-Type -TypeDefinition $nativeSource
 Budget $compileDeadline;$nativeReady=$true;$result.compiledHelper=@{path=$exe;bytes=(Get-Item -LiteralPath $exe).Length;sha256=Hash $exe;platform='x86';subsystem='GUI_REQUIRED_BY_FACTORY_AND_ROOT'}
 $result.before=Fixture-State;Need ($result.before.knownAbsent) 'FIXTURE_BASELINE_NOT_KNOWN_ABSENT'
 $factoryStart=Elapsed;$factoryRaw=@(& (Join-Path $Root 'New-AsyncChainerFixture.ps1') -Execute -HelperExe $exe -MsiPath (Join-Path $Root 'fixture.msi') -Root $Root -ProductCode $config.productCode -UpgradeCode $config.upgradeCode -ComponentId $config.componentId -Nonce $config.nonce)
 [IO.File]::WriteAllText((Join-Path $Root 'factory.stdout.log'),($factoryRaw-join "`r`n"));$factory=($factoryRaw-join "`n")|ConvertFrom-Json
 Need ($factory.status-ceq 'PASS_ACTUAL_COM_BUILT_AND_EXACT_READBACK_FIXTURE_ONLY_NOT_INSTALLED') 'FACTORY_EXACT_TABLE_BINARY_READBACK_REQUIRED';$result.factory=$factory;$result.operations+=@{name='factory-build-exact-check';actualReturn=$true;elapsedMilliseconds=(Elapsed)-$factoryStart};Budget
 $env:TEMP=$originalTemp;$env:TMP=$originalTmp
 $observer=[FcR76ProcessObserver]::new($result.compiledHelper.sha256,[int]$result.compiledHelper.bytes,$sid,90000)
 $writer=[IO.StreamWriter]::new((Join-Path $Root 'observer-original.jsonl'),$false,[Text.UTF8Encoding]::new($false))
 $msiexec=Join-Path ([Environment]::GetFolderPath('Windows')) 'System32\msiexec.exe';$msi=Join-Path $Root 'fixture.msi';$log=Join-Path $Root 'install-msi.log'
 $args='/i "'+$msi+'" /qn /norestart REBOOT=ReallySuppress MSIRESTARTMANAGERCONTROL=DisableShutdown /L*vx "'+$log+'"'
 $client=[FcR77FixtureNative]::Start($msiexec,$args);$result.client=$client;$clientStarted=$true;Need ($client.ThreadCloseSuccess-and $client.CreationFiletime-gt 0) 'ORIGINAL_CLIENT_IDENTITY_OR_THREAD_CLOSE_UNKNOWN';$clientDeadline=[Math]::Min(120000,(Elapsed)+30000)
 do{$null=Observe-And-Acknowledge;$client.Refresh();if($client.ActualWait-eq 0){break};Budget $clientDeadline;Start-Sleep -Milliseconds 10}while($true)
 $client.CloseReturned();$result.client=$client
 # A bounded observer drain records actual nonzero fixture returns as facts.
 do{$s=Observe-And-Acknowledge;$live=@($s.Processes|Where-Object{$_.ActualWait-ne 0});if($live.Count-eq 0){break};Budget $clientDeadline;Start-Sleep -Milliseconds 10}while($true)
 $result.observer=$observer.FinishAndClose();$observer=$null;$physicalReturned=Physical-Returned $result.observer;$result.capturedPhysicalReturned=$physicalReturned
 Need $physicalReturned 'CAPTURED_PHYSICAL_RETURN_UNKNOWN';$result.after=Fixture-State
 $result.classification='PROBE_REJECTED_OR_INCOMPLETE';$result.status='PASS_NEGATIVE_EVIDENCE_CAPTURED_ACTUAL_RESULTS_NOT_ORDER_SUPPORT'
}catch{
 $result.errors+=@{type=$_.Exception.GetType().FullName;message=$_.Exception.Message;hresult=$_.Exception.HResult;elapsedMilliseconds=Elapsed}
}finally{
 if($writer){$writer.Flush();$writer.Dispose();$writer=$null}
 if($observer){try{$result.observer=$observer.FinishAndClose();$physicalReturned=Physical-Returned $result.observer;$result.capturedPhysicalReturned=$physicalReturned}catch{$result.errors+=@{stage='OBSERVER_FINAL';message=$_.Exception.Message}}}
 if($client-and -not $client.ProcessCloseAttempted){try{$client.Refresh();if($client.ActualWait-eq 0){$client.CloseReturned()};$result.client=$client}catch{$result.errors+=@{stage='CLIENT_FINAL';message=$_.Exception.Message}}}
 if($nativeReady-and $sourceValidated){
  try{
   $state=Fixture-State;$result.finallyBeforeCleanup=$state
   if(-not $state.knownAbsent){
    Need ($clientStarted-and $null-ne $client-and $client.ProcessCloseSuccess-and $physicalReturned-and $state.ownMarkerExact) 'FORMAL_X_NOT_AUTHORIZED_UNKNOWN_OR_FOREIGN_STATE'
    Budget;$args='/x '+$config.productCode+' /qn /norestart REBOOT=ReallySuppress MSIRESTARTMANAGERCONTROL=DisableShutdown /L*vx "'+(Join-Path $Root 'cleanup-msi.log')+'"'
    $uninstall=[FcR77FixtureNative]::Start((Join-Path ([Environment]::GetFolderPath('Windows')) 'System32\msiexec.exe'),$args);$result.formalUninstall=$uninstall;Need ($uninstall.ThreadCloseSuccess-and $uninstall.CreationFiletime-gt 0) 'UNINSTALL_IDENTITY_OR_THREAD_CLOSE_UNKNOWN';$deadline=[Math]::Min(120000,(Elapsed)+30000)
    do{$uninstall.Refresh();if($uninstall.ActualWait-eq 0){break};Budget $deadline;Start-Sleep -Milliseconds 10}while($true)
    $uninstall.CloseReturned();$result.formalUninstall=$uninstall;Need ($uninstall.ActualExitCode-eq 0) 'FORMAL_X_ACTUAL_NONZERO'
   }
   $result.finalAbsence=Fixture-State;Need ($result.finalAbsence.knownAbsent) 'FINAL_FIXTURE_PRODUCT_RELATED_MARKER_NOT_ABSENT'
  }catch{$result.errors+=@{stage='EXACT_FORMAL_CLEANUP';message=$_.Exception.Message}}
 }
 $env:TEMP=$originalTemp;$env:TMP=$originalTmp
 if($rootReady){
  if($result.compiledHelper-and $result.observer-and $result.finalAbsence){try{Assess-Stages}catch{$result.errors+=@{stage='SOURCE_BOUND_SEMANTIC_ASSESSMENT';message=$_.Exception.Message}}}
  $result.elapsedWholeMilliseconds=Elapsed;$result.originalBudgetExceeded=(Elapsed)-ge 120000
  if($result.errors.Count-gt 0-or $result.originalBudgetExceeded){$result.status='FAIL_RETAIN_ACTUAL_ERRORS_OR_BUDGET_UNKNOWN'}
  Write-NewJson 'driver-result.json' $result
 }
}
$result|ConvertTo-Json -Depth 32 -Compress
if($result.errors.Count-gt 0-or $result.originalBudgetExceeded-or $result.status-cnotlike 'PASS*'){exit 1}
