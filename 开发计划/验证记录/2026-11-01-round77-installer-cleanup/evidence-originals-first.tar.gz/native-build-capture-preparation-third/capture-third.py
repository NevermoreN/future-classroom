"""Correctly collect profile.test artifacts from completed original Cargo logs."""
from pathlib import Path
import argparse, hashlib, json, struct
ROOT=Path('/workspace/共享/Eliora/未来教室计划');E=Path('/tmp/fc-round77-installer-cleanup')
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');a=p.parse_args()
    if not a.execute:print(json.dumps(dict(status='PREPARED_NOT_RUN',windows='NOT_CONNECTED',compileCommands=0)));return 0
    parent=E/'native-build-second/report.json';raw=parent.read_bytes();old=json.loads(raw)
    assert old['status']=='FAIL_ACTUAL_BUILD_OR_CAPTURE' and old['errorType']=='AssertionError' and old['sourceUnchanged']
    assert [o['name'] for o in old['operations']]==['clippy','tests','normal']
    assert all(o['exitCode']==0 and o['actualExit'] and o['reaped'] and not o['timedOut'] for o in old['operations'])
    for o in old['operations']:
        for k in ('stdout','stderr'):
            f=o[k];b=Path(f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
    assert old['inputsBefore']==old['inputsAfter']
    for f in old['inputsAfter']:
        b=(ROOT/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
    artifacts=[];non_test_messages=[];test_keys=set();normal_keys=set()
    for role in ('tests','normal'):
        messages=[json.loads(line) for line in (E/('native-build-second/'+role+'.stdout.log')).read_bytes().splitlines()]
        finished=[m for m in messages if m.get('reason')=='build-finished'];assert len(finished)==1 and finished[0]['success'] is True and messages[-1]==finished[0]
        for m in messages:
            if m.get('reason')!='compiler-artifact' or not m.get('executable'):continue
            if role=='tests' and m['profile']['test'] is not True:
                non_test_messages.append(dict(target=m['target'],path=m['executable'],profile=m['profile'],qualification='Normal bin emitted by cargo test for integration harnesses; excluded from test count.'));continue
            assert m['profile']['test'] is (role=='tests')
            f=Path(m['executable']);assert f.is_relative_to(E/'target') and f.is_file() and not f.is_symlink()
            src=Path(m['target']['src_path']);assert src.is_relative_to(ROOT/'crates')
            b=f.read_bytes();off=struct.unpack_from('<I',b,60)[0];assert b[:2]==b'MZ' and b[off:off+4]==b'PE\0\0' and struct.unpack_from('<H',b,off+4)[0]==332
            subsystem=struct.unpack_from('<H',b,off+24+68)[0];assert subsystem==(3 if role=='tests' else 2)
            key=(m['package_id'],m['target']['name'],str(src),tuple(m['target']['kind']))
            keys=test_keys if role=='tests' else normal_keys;assert key not in keys;keys.add(key)
            artifacts.append(dict(role=role,path=str(f),bytes=len(b),sha256=sha(b),target=m['target'],packageId=m['package_id'],profileTest=m['profile']['test'],subsystem=subsystem))
    assert len(test_keys)==22 and len(normal_keys)==2
    assert sorted(f['target']['name'] for f in artifacts if f['role']=='normal')==['fc-bootstrap','fc-installer-lifecycle']
    d=E/'native-build-capture-third';assert not d.exists();d.mkdir()
    v=dict(old,status='PASS_COMPILE_ONLY_NOT_RUNTIME',sourceGitQualification='Original sourceGit is the unchanged Git base; actual modified compilation inputs are the full before/after manifests and frozen source snapshots, not a claim that the base contains new code.',artifacts=artifacts)
    v.pop('error',None);v.pop('errorType',None)
    v.update(parentOriginal=dict(path=str(parent),bytes=len(raw),sha256=sha(raw),status=old['status'],retainedUnchanged=True),captureCorrection='Original collector counted all executable messages from cargo test, including profile.test=false integration dependencies. This read-only capture selects exactly profile.test=true for tests, keeps separate normal GUI compilation, and rereads every original command/source/artifact. No compile, Windows call or original report rewrite.',excludedNonTestMessages=non_test_messages)
    (d/'report.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(dict(status=v['status'],testExecutables=len(test_keys),normalExecutables=len(normal_keys),excludedNonTestMessages=len(non_test_messages),compileCommands=0,windows='NOT_CONNECTED')));return 0
if __name__=='__main__':raise SystemExit(main())
