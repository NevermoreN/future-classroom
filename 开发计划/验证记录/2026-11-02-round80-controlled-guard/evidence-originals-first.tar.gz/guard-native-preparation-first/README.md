默认运行只输出 NOT_RUN。此版本固定 guard-build-third/report.json 与 guard-inputs-third.json 的精确 SHA，核 sourceBase b7e4c938ab8ff391e2ad6c1d681e074881118c0a、459 编译输入、10 件 dirty 文件和 2 件 Python 输入。

仅 root 执行：

    python3 /tmp/fc-round80-controlled-repair/guard-native-preparation-first/run-native.py --execute

root 先对 boot/create/run/delete.ps1 做真实 Windows AST 检查。controlled6 和完整 lifecycle60 两个范围分别保留150/300秒，整体600秒、外层900秒；60已包含6。完整原父对象 Wait/GetExit/checkedClose、继承子输出作用域资格、全量下载字节校验和精确自有 scratch 清理沿用旧控制器。

这是 legacy 与 guard 组件回归；cfg(test) Begin/End 观察为合成，实际生产 Begin-owner/Type1 桥 NOT_EXERCISED。Win7/Win10 NOT_RUN。本准备未执行 Windows、SSH 或 Cargo。
