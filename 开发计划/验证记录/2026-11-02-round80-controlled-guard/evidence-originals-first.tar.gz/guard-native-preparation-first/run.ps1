$ErrorActionPreference='Stop';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function RootPath {return Join-Path ([IO.Path]::GetFullPath($env:TEMP)) ('FutureClassroom-r80-guard-native-'+$c.nonce)}
function Fact($p){$a=[IO.File]::GetAttributes($p);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0 -or ($a-band[IO.FileAttributes]::Directory)-ne0){throw 'REGULAR_NO_REPARSE'};return @{bytes=[long]([IO.FileInfo]::new($p).Length);sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function CheckRoot($root){if($root-cne$c.root -or [IO.Path]::GetFileName($root)-cne('FutureClassroom-r80-guard-native-'+$c.nonce)){throw 'EXACT_ROOT'};$a=[IO.File]::GetAttributes($root);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0){throw 'ROOT_REPARSE'};if([IO.File]::ReadAllText((Join-Path $root '.owner'))-cne"future-classroom-owned-r80-guard-native-runtime/v1`n"){throw 'OWNER_MARKER'};$acl=[IO.Directory]::GetAccessControl($root);if(-not$acl.AreAccessRulesProtected -or $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-cne$c.sid){throw 'EXACT_PROTECTED_OWNER'};$rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));if($rules.Count-ne2 -or @($rules|Where-Object{$_.IdentityReference.Value-notin@($c.sid,'S-1-5-18') -or $_.AccessControlType-ne'Allow' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count){throw 'ONLY_USER_SYSTEM_DACL'}}
function Inventory($root){CheckRoot $root;$files=@();$dirs=@();$q=[Collections.Generic.Queue[string]]::new();$q.Enqueue($root);while($q.Count){$dir=$q.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){$a=[IO.File]::GetAttributes($p);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0){throw 'INVENTORY_REPARSE'};$rel=$p.Substring($root.Length+1).Replace('\','/');if(($a-band[IO.FileAttributes]::Directory)-ne0){$dirs+=$rel;$q.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256}};if($files.Count-gt128 -or $dirs.Count-gt16){throw 'INVENTORY_BOUND'}}};return @{files=$files;directories=$dirs}}

CheckRoot $c.root;$root=$c.root
foreach($x in $c.inputs){$f=Fact (Join-Path $root $x.name);if($f.bytes-ne$x.bytes-or$f.sha256-cne$x.sha256){throw 'INPUT_BYTES'}}
$oldTemp=$env:TEMP;$oldTmp=$env:TMP;$clock=[Diagnostics.Stopwatch]::StartNew();$capture=$null;$p=$null;$returned=$true
$r=@{status='FAIL_RETAIN';cases=@();originalWholeSeconds=600;captureSourceOnlyProcessMethods=$true;controlledNativeReturns='CFG_TEST_SYNTHETIC_BEGIN_END_OBSERVATIONS_ONLY';productionMsiAdapter='NOT_EXERCISED';newGuardTests='PURE_CONTRACT_BRIDGE_AND_PRESENT_INTENT_ONLY';cleanup='ROOT_DOWNLOAD_THEN_EXACT_DELETE_REQUIRED'}
try{
 $env:TEMP=Join-Path $root 'compiler-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP)
 try{Add-Type -Path (Join-Path $root 'Capture.cs') -ErrorAction Stop}finally{$env:TEMP=$oldTemp;$env:TMP=$oldTmp}
 $capture=[Fc79Capture]::new();$exe=Join-Path $root 'candidate-tests.exe'
 $env:TEMP=Join-Path $root 'test-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP)
 foreach($s in @(@{name='controlled';filter='installer_lifecycle::tests::controlled_';seconds=150},@{name='lifecycle';filter='installer_lifecycle::';seconds=300})){
  if($clock.ElapsedMilliseconds-ge600000){throw 'WHOLE_BUDGET'}
  $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$exe;$info.Arguments=$s.filter+' --test-threads=1 --nocapture';$info.WorkingDirectory=$root;$info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
  $p=[Diagnostics.Process]::new();$p.StartInfo=$info;$case=@{name=$s.name;argv=$info.Arguments;originalSeconds=$s.seconds;actualExit=$false;exitCode=$null};$r.cases+=,$case
  $case.startedWholeMilliseconds=$clock.ElapsedMilliseconds;$case.originalDeadlineWholeMilliseconds=[Math]::Min(600000,$case.startedWholeMilliseconds+$s.seconds*1000)
  if(-not$p.Start()){throw 'START'};$returned=$false;$case.pid=$p.Id;$case.creation=$p.StartTime.ToUniversalTime().ToFileTimeUtc()
  $stdout=$p.StandardOutput.ReadToEndAsync();$stderr=$p.StandardError.ReadToEndAsync()
  $case.original=$capture.HoldStartedClient($p.Handle,[uint32]$p.Id,[long]$case.creation,$exe,$c.exeSha,$c.sid)
  $left=[int]($case.originalDeadlineWholeMilliseconds-$clock.ElapsedMilliseconds)
  if($left-le0-or-not$p.WaitForExit($left)){throw 'ORIGINAL_TEST_PARENT_UNKNOWN_RETAIN_NO_KILL'}
  $returned=$true;$p.Refresh();$case.actualExit=$true;$case.exitCode=$p.ExitCode
  if(-not[Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($stdout,$stderr),[int][Math]::Max(0,$case.originalDeadlineWholeMilliseconds-$clock.ElapsedMilliseconds))){throw 'ORIGINAL_PIPES_UNKNOWN'}
  $case.stdout=$stdout.Result;$case.stderr=$stderr.Result;[void]$capture.Snapshot()
  if($case.original.Wait-ne0-or-not$case.original.ExitKnown-or$case.original.ExitCode-ne$case.exitCode){throw 'ORIGINAL_TEST_RETURN_MISMATCH'}
  $case.endedWholeMilliseconds=$clock.ElapsedMilliseconds
  $p.Dispose();$p=$null;if($case.exitCode-ne0){throw 'NATIVE_TEST_FAILURE'}
  if($case.endedWholeMilliseconds-gt$case.originalDeadlineWholeMilliseconds){throw 'ORIGINAL_TEST_DEADLINE_EXCEEDED'}
 }
 $r.status='PASS_GUARD_COMPONENTS_AND_FULL_LIFECYCLE_NATIVE_TESTS_WIN11_ONLY'
}catch{$r.error=$_.Exception.Message}finally{
 $env:TEMP=$oldTemp;$env:TMP=$oldTmp
 if($null-ne$p-and$returned){$p.Dispose()}
 if($null-ne$capture){try{$r.originalObjects=@($capture.FinishAndClose())}catch{$r.status='FAIL_RETAIN';$r.closeError=$_.Exception.Message}}
 $r.originalParentReturned=$returned;$r.elapsedMilliseconds=$clock.ElapsedMilliseconds
 if($clock.ElapsedMilliseconds-ge600000){$r.status='FAIL_RETAIN';$r.budgetExceeded=$true}
 [IO.File]::WriteAllText((Join-Path $root 'native-result.json'),($r|ConvertTo-Json -Depth 30),[Text.UTF8Encoding]::new($false))
}
$r|ConvertTo-Json -Depth 30 -Compress
if($r.status-cne'PASS_GUARD_COMPONENTS_AND_FULL_LIFECYCLE_NATIVE_TESTS_WIN11_ONLY'){exit 1}
