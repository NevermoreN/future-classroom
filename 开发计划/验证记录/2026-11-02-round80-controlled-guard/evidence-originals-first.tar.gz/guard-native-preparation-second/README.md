默认只输出 NOT_RUN。仅 root 在真实 PS AST 检查后执行以下命令，并提供最终构建报告和编译输入清单的精确 SHA：

    python3 /tmp/fc-round80-controlled-repair/guard-native-preparation-second/run-native.py --execute --producer /tmp/fc-round80-controlled-repair/guard-build-FOURTH/report.json --producer-sha256 EXACT_SHA --inventory /tmp/fc-round80-controlled-repair/guard-inputs-FOURTH.json --inventory-sha256 EXACT_SHA

严格绑定 sourceBase b7e4c938ab8ff391e2ad6c1d681e074881118c0a、459 编译输入、10 件 dirty 文件、2 件 Python 输入、root 实际 GNU test --no-run 报告唯一 fc_windows 测试 EXE（<=64MiB）及其 compiler-artifact。controlled6 与完整 lifecycle60 分别保留150/300秒，整体600秒、外层900秒；60已包含6。完整原对象 Wait/GetExit/checkedClose、继承子输出资格、完整下载字节核对和精确 scratch 清理保留。

这是组件回归；cfg(test) Begin/End 为合成观察，实际生产 Begin-owner/Type1 桥 NOT_EXERCISED。Win7/Win10 NOT_RUN。未执行 Windows、SSH 或 Cargo。first 冻结原件保留。
