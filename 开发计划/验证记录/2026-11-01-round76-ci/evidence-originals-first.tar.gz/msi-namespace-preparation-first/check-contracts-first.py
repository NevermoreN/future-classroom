"""Pure staging contracts, no artifact/ZIP read or staging execution."""
from pathlib import Path
import ast,copy,hashlib,json,runpy,subprocess
D=Path(__file__).parent;M=runpy.run_path(str(D/'stage-original-namespace-first.py'));checks=[]
def check(name,condition):assert condition,name;checks.append(name)
def reject(name,fn):
 try:fn()
 except (AssertionError,KeyError):checks.append(name)
 else:raise AssertionError('accepted '+name)
for p in D.glob('*.py'):ast.parse(p.read_bytes())
check('Python_AST',True)
inner='packages/explicit-model-original.zip';names=[*M['BASE'],inner];rows=[dict(path=name,bytes=7,sha256=hashlib.sha256(name.encode()).hexdigest()) for name in names]
a=dict(schema='future-classroom.ci-independent-artifact/v2',status='PASS_STATIC_ONLY_RUNTIME_NOT_RUN',sourceSha=M['SOURCE'],baseline='Win7',runId=M['RUN'],artifactIntegrity='PASS_WHOLE_ZIP_CRC_AND_COMPLETE_PRODUCER_LEDGER',helperUnchanged=True,members=rows)
for key,target in [('normalExecutable','fc-bootstrap'),('lifecycleExecutable','fc-installer-lifecycle')]:
 name='product/fc-bootstrap/'+target+'.exe';row=next(r for r in rows if r['path']==name)
 a[key]=dict(producer=dict(role='product',package='fc-bootstrap',target=target,relative_path=name,cargo_profile_test=False,pe_subsystem=2,pe_subsystem_version='6.1',bytes=row['bytes'],sha256=row['sha256']))
ledger=[r for r in rows if r['path']!='artifact-sha256.json'];p=M['plan'](a,ledger,inner)
check('ten_explicit_original_relative_names',len(p)==10 and all(x['artifactMember']==x['namespacePath'] for x in p))
check('explicit_raw_programs_storage_mapping',all(x['auditorStoragePath']==('programs/' if x['artifactMember'].endswith('.exe') else 'raw/')+x['artifactMember'] for x in p))
for label,key,value in [('modern','baseline','Modern'),('wrong-source','sourceSha','0'*40),('running','status','RUNNING'),('wrong-run','runId',1)]:
 c=copy.deepcopy(a);c[key]=value;reject('reject_'+label,lambda:M['plan'](c,ledger,inner))
c=copy.deepcopy(a);c['lifecycleExecutable']['producer']['cargo_profile_test']=True
reject('reject_test_helper',lambda:M['plan'](c,ledger,inner))
c=copy.deepcopy(a);c['normalExecutable']['producer']['pe_subsystem']=3
reject('reject_console_product',lambda:M['plan'](c,ledger,inner))
c=copy.deepcopy(ledger);c[0]['sha256']='0'*64
reject('reject_producer_member_hash_mismatch',lambda:M['plan'](a,c,inner))
c=copy.deepcopy(a);c['members'].append(c['members'][0])
reject('reject_duplicate_member',lambda:M['plan'](c,ledger,inner))
for name in ('../escape.zip','/absolute.zip','packages\\alias.zip','packages/C:alias.zip','packages//alias.zip'):
 reject('reject_unsafe_inner_'+name,lambda:M['plan'](a,ledger,name))
source=(D/'stage-original-namespace-first.py').read_text();check('no_ZIP_unpack_process_network_or_Cargo_APIs',all(x not in source for x in ('import zipfile','import subprocess','import urllib','extractall','os.system')))
cmd=['python3','-B',str(D/'stage-original-namespace-first.py')]
for name in ('accepted-static-report','artifact-root','official-zip','output-dir','report'):cmd+=['--'+name,str(D/('MODEL-NOT-PROVIDED-'+name))]
for name in ('accepted-static-report-sha256','official-zip-sha256','build-result-sha256'):cmd+=['--'+name,'a'*64]
cmd+=['--input-member',inner]
with (D/'default.stdout.log').open('xb') as o,(D/'default.stderr.log').open('xb') as e:
 child=subprocess.Popen(cmd,stdout=o,stderr=e);code=child.wait(timeout=15)
check('actual_default_not_read_inputs_or_stage',code==0 and json.loads((D/'default.stdout.log').read_bytes())['status']=='PREPARED_NAMESPACE_ONLY_NOT_RUN')
result=dict(status='PASS_AST_AND_PURE_DEFAULT_ONLY_NOT_STAGED',checks=checks,count=len(checks),syntheticQualification='All member SHA/bytes/producer rows above are policy models only, not actual accepted CI artifacts.',defaultCommand=cmd,pid=child.pid,actualExit=True,exitCode=code,namespaceStaged=False,zipUnpacked=False,windowsExecuted=False)
(D/'contracts-first.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],count=len(checks))))
