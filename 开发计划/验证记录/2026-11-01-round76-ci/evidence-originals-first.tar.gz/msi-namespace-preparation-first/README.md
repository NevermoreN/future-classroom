Namespace preparation only. No accepted Win7 artifact or ZIP was read, unpacked or staged here. The real intended run is41315385139/source3bad94949012e840cd1dda6a73a0ea1ddb067697, baseline Win7. Tools/package controller remain unchanged.

The actual R76 verifier `ui-preparation-first/verify-ci-artifact-dual-gui-first.py` lines341–360 preserve the original ZIP member name below `programs/` for .exe and below `raw/` for every other original member. B4 expects result.json, source inventories, compiler logs and original product files below one CI root. This helper restores only the required declared subset. It does not flatten basenames or rename member paths.

| Original CI member / destination | Existing auditor storage source |
|---|---|
| artifact-sha256.json | raw/artifact-sha256.json |
| result.json | raw/result.json |
| input-sha256.json | raw/input-sha256.json |
| input-sha256-after.json | raw/input-sha256-after.json |
| executables.json | raw/executables.json |
| logs/product-compile.stdout.log | raw/logs/product-compile.stdout.log |
| logs/lifecycle-compile.stdout.log | raw/logs/lifecycle-compile.stdout.log |
| product/fc-bootstrap/fc-bootstrap.exe | programs/product/fc-bootstrap/fc-bootstrap.exe |
| product/fc-bootstrap/fc-installer-lifecycle.exe | programs/product/fc-bootstrap/fc-installer-lifecycle.exe |
| ROOT_EXPLICIT_ORIGINAL_INNER_ZIP_MEMBER | raw/ROOT_EXPLICIT_ORIGINAL_INNER_ZIP_MEMBER |

The last member must be the exact original inner development/probe ZIP path reported by the accepted artifact ledger. Root supplies it explicitly; no filename search chooses it. Nested path components remain intact. It is copied as opaque bytes and is not opened or unzipped by this helper.

Execution requires the actual accepted static report schema future-classroom.ci-independent-artifact/v2/status PASS_STATIC_ONLY_RUNTIME_NOT_RUN, actual source/run/Win7 baseline and normal GUI2/profile.test=false rows; report SHA; full official outer ZIP SHA/bytes bound to report.zip; original result SHA; original artifact-sha256.json bound to accepted members; complete accepted member-set equality with the original producer ledger plus its own artifact-sha256 member; and identical sizes/SHA for every selected original input. All originals are rechecked after copy. Original result must independently retain COMPILE_CHECKS_PASSED_RUNTIME_NOT_RUN/source+dispatch3bad/Win7/i686-win7-windows-msvc. No state87, baseline, producer row, source newline or compiler log is normalized around a failure.

Only a fresh child directory of this preparation root can receive output. Each mapping is recorded as artifactMember/auditorStoragePath/namespacePath/bytes/SHA. The only extra namespace file is an explicit owned .owner marker, which is not presented as an original artifact member. The resulting ten-member namespace is sufficient input to the already-frozen B4 package controller; it is expressly not a full original artifact extraction or an independent compiler provenance proof. Accepted artifact evidence remains authoritative.

Root's future command, after the actual Win7 static gate and exact original ZIP are available:

```sh
python3 -B /tmp/fc-round76-ci-evidence/msi-namespace-preparation-first/stage-original-namespace-first.py --accepted-static-report ACTUAL_R76_WIN7_V2_REPORT --accepted-static-report-sha256 ACTUAL64 --artifact-root ACTUAL_R76_AUDITOR_OUTPUT_WITH_RAW_AND_PROGRAMS --official-zip ACTUAL_R76_ORIGINAL_OFFICIAL_ZIP --official-zip-sha256 ACTUAL64 --build-result-sha256 ACTUAL_RESULT64 --input-member ACTUAL_ORIGINAL_INNER_ZIP_RELATIVE_NAME --output-dir /tmp/fc-round76-ci-evidence/msi-namespace-preparation-first/original-ci-namespace-first --report /tmp/fc-round76-ci-evidence/msi-namespace-preparation-first/staging-operation-first.json --execute
```

Default omitting --execute returns PREPARED_NAMESPACE_ONLY_NOT_RUN before reading any provided path or making files. Only AST, 18 pure policy/default cases have run. Synthetic member SHA/bytes in those checks are labelled models, not accepted source/artifact facts. No network, credential, signed URL, subprocess, Cargo, Windows or MSI operation exists in the stager. Any identity, path or copy failure retains the new partial output and fixed error facts; no source cleanup or fallback occurs.
