"""Explicit minimal original CI namespace staging; default never opens inputs.
Copies accepted auditor raw/<member> or programs/<member> to identical <member>.
Never opens/unpacks ZIPs, changes originals or fabricates a compiler producer.
"""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, re, stat, sys
sys.dont_write_bytecode=True
R=Path('/tmp/fc-round76-ci-evidence');D=R/'msi-namespace-preparation-first'
SOURCE='3bad94949012e840cd1dda6a73a0ea1ddb067697';RUN=41315385139
BASE=('artifact-sha256.json','result.json','input-sha256.json','input-sha256-after.json','executables.json','logs/product-compile.stdout.log','logs/lifecycle-compile.stdout.log','product/fc-bootstrap/fc-bootstrap.exe','product/fc-bootstrap/fc-installer-lifecycle.exe')

def need(value,code):
    if not value:raise AssertionError(code)
def relative(name):
    need(isinstance(name,str) and '\\' not in name and ':' not in name and '\x00' not in name,'MEMBER_CHARACTER')
    p=PurePosixPath(name);need(name==p.as_posix() and not p.is_absolute() and all(part not in ('','.','..') for part in name.split('/')),'MEMBER_PATH')
    need(p.suffix.lower() not in {'.key','.pfx','.p12'},'NO_PRIVATE_MEMBER');return name

def owned(path):
    p=Path(path);need(p.is_absolute() and p.resolve().is_relative_to(R) and not any(q.is_symlink() for q in [p,*p.parents] if q==R or R in q.parents),'EXACT_OWNED_PATH');return p

def fact(path,limit=512*1024*1024):
    need(stat.S_ISREG(path.lstat().st_mode) and path.stat().st_size<=limit,'REGULAR_BOUNDED_FILE')
    hashed=hashlib.sha256();size=0
    with path.open('rb') as stream:
        while chunk:=stream.read(256*1024):hashed.update(chunk);size+=len(chunk)
    return dict(path=str(path),bytes=size,sha256=hashed.hexdigest())
def read_json(path,digest):
    f=fact(path,16*1024*1024);need(re.fullmatch('[0-9a-f]{64}',digest) and f['sha256']==digest,'EXACT_JSON_SHA');return json.loads(path.read_bytes()),f

def unique(rows):
    result={};folded=set();need(isinstance(rows,list) and 0<len(rows)<=10000,'BOUNDED_MEMBER_LEDGER')
    for row in rows:
        name=relative(row['path']);need(name.casefold() not in folded,'DUPLICATE_OR_CASE_ALIAS');folded.add(name.casefold())
        need(type(row['bytes']) is int and 0<=row['bytes']<=128*1024*1024 and re.fullmatch('[0-9a-f]{64}',row['sha256']),'MEMBER_BYTES_SHA');result[name]=row
    return result

def plan(accepted,producer,input_member):
    need(accepted.get('schema')=='future-classroom.ci-independent-artifact/v2' and accepted.get('status')=='PASS_STATIC_ONLY_RUNTIME_NOT_RUN','ACTUAL_STATIC_PASS_V2')
    need(accepted.get('sourceSha')==SOURCE and accepted.get('baseline')=='Win7' and accepted.get('runId')==RUN,'ACTUAL_SAME_SOURCE_WIN7_RUN')
    need(accepted.get('artifactIntegrity')=='PASS_WHOLE_ZIP_CRC_AND_COMPLETE_PRODUCER_LEDGER' and accepted.get('helperUnchanged') is True,'ACCEPTED_COMPLETE_ORIGINAL_ARTIFACT')
    members=unique(accepted['members']);ledger=unique(producer)
    need(set(members)==set(ledger)|{'artifact-sha256.json'},'COMPLETE_ACCEPTED_PRODUCER_LEDGER_SET')
    for name,row in ledger.items():need(all(row[k]==members[name][k] for k in ('bytes','sha256')),'PRODUCER_ACCEPTED_MEMBER_IDENTITY')
    input_member=relative(input_member);need(input_member.endswith('.zip') and input_member not in BASE,'EXPLICIT_INNER_ZIP_MEMBER')
    for key,target in [('normalExecutable','fc-bootstrap'),('lifecycleExecutable','fc-installer-lifecycle')]:
        row=accepted[key]['producer'];name='product/fc-bootstrap/'+target+'.exe'
        need(row['role']=='product' and row['package']=='fc-bootstrap' and row['target']==target and row['relative_path']==name and row['cargo_profile_test'] is False and row['pe_subsystem']==2 and row['pe_subsystem_version']=='6.1','ORIGINAL_NORMAL_GUI2_NOT_TEST_CLONE')
        need(all(row[k]==members[name][k] for k in ('bytes','sha256')),'NORMAL_MEMBER_IDENTITY')
    result=[]
    for name in [*BASE,input_member]:
        row=members[name];prefix='programs' if name.lower().endswith('.exe') else 'raw'
        result.append(dict(artifactMember=name,auditorStoragePath=prefix+'/'+name,namespacePath=name,bytes=row['bytes'],sha256=row['sha256']))
    return result

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('accepted-static-report','artifact-root','official-zip','output-dir','report'):parser.add_argument('--'+name,type=Path,required=True)
    for name in ('accepted-static-report-sha256','official-zip-sha256','build-result-sha256','input-member'):parser.add_argument('--'+name,required=True)
    parser.add_argument('--execute',action='store_true');a=parser.parse_args()
    if not a.execute:
        print(json.dumps(dict(status='PREPARED_NAMESPACE_ONLY_NOT_RUN',sourceSha=SOURCE,runId=RUN,baseline='Win7',memberCount=10,unzipPerformed=False,originalsModified=False)));return 0
    need((R/'.owner').read_bytes()==b'future-classroom-owned-r76-ci-evidence/v1\n' and (D/'.owner').read_bytes()==b'future-classroom-owned-r76-msi-namespace-preparation/v1\n','EXACT_OWNERS')
    out=owned(a.output_dir);report=owned(a.report);need(out.parent==D and not out.exists() and report.parent==D and not report.exists(),'NEW_OWNED_OUTPUT_AND_REPORT')
    result=dict(status='NOT_RUN_BLOCKED',sourceSha=SOURCE,runId=RUN,baseline='Win7',unzipPerformed=False,originalsModified=False,msiBuilt=False,windowsExecuted=False)
    try:
        accepted,af=read_json(owned(a.accepted_static_report),a.accepted_static_report_sha256)
        root=owned(a.artifact_root);need(root.is_dir(),'AUDITOR_OUTPUT_DIRECTORY')
        zipfact=fact(owned(a.official_zip));need(re.fullmatch('[0-9a-f]{64}',a.official_zip_sha256) and zipfact['sha256']==a.official_zip_sha256 and all(zipfact[k]==accepted['zip'][k] for k in ('bytes','sha256')),'EXACT_ACCEPTED_OFFICIAL_ZIP_BYTES_NO_UNPACK')
        member_rows=unique(accepted['members']);lf=member_rows['artifact-sha256.json'];ledger_path=owned(root/'raw/artifact-sha256.json');ledger_fact=fact(ledger_path,16*1024*1024)
        need(all(ledger_fact[k]==lf[k] for k in ('bytes','sha256')),'EXACT_ACCEPTED_ORIGINAL_PRODUCER_LEDGER')
        records=plan(accepted,json.loads(ledger_path.read_bytes()),a.input_member)
        result_member=member_rows['result.json'];need(result_member['sha256']==a.build_result_sha256,'EXPLICIT_ORIGINAL_RESULT_SHA')
        for row in records:
            src=owned(root/row['auditorStoragePath']);actual=fact(src);need(all(actual[k]==row[k] for k in ('bytes','sha256')),'ORIGINAL_AUDITOR_STORAGE_BYTES')
        original=json.loads((root/'raw/result.json').read_bytes());need(original['status']=='COMPILE_CHECKS_PASSED_RUNTIME_NOT_RUN' and original['source_sha']==original['dispatch_source_sha']==SOURCE and original['baseline']=='Win7' and original['target']=='i686-win7-windows-msvc','ORIGINAL_WIN7_RESULT_NOT_RELABELED')
        out.mkdir();(out/'.owner').write_bytes(b'future-classroom-owned-r76-original-ci-namespace/v1\n')
        for row in records:
            source=owned(root/row['auditorStoragePath']);dest=owned(out/row['namespacePath']);dest.parent.mkdir(parents=True,exist_ok=True)
            with source.open('rb') as src,dest.open('xb') as dst:
                while chunk:=src.read(256*1024):dst.write(chunk)
            need(all(fact(dest)[k]==row[k] for k in ('bytes','sha256')) and all(fact(source)[k]==row[k] for k in ('bytes','sha256')),'COPIED_BYTES_REOPEN_AND_ORIGINAL_UNCHANGED')
        need({p.relative_to(out).as_posix() for p in out.rglob('*') if p.is_file()}=={row['namespacePath'] for row in records}|{'.owner'},'MINIMAL_NAMESPACE_MEMBERS_EXACT')
        result.update(status='PASS_EXACT_MINIMAL_ORIGINAL_NAMESPACE_ONLY_NOT_MSI',acceptedStaticReport=af,officialZip=zipfact,producerLedger=ledger_fact,buildEvidence=str(out),inputZip=str(out/a.input_member),lifecycleHelper=str(out/'product/fc-bootstrap/fc-installer-lifecycle.exe'),buildResultSha256=a.build_result_sha256,mappings=records,qualification='Ten required original members copied byte-for-byte under original CI relative names. This is a declared minimal namespace, not a complete re-extraction of the artifact or compiler provenance by itself.')
    except Exception as error:result.update(status='FAIL_RETAIN_PARTIAL_NAMESPACE' if out.exists() else 'NOT_RUN_BLOCKED',errorType=type(error).__name__,reasonCode=str(error) if isinstance(error,AssertionError) else 'ORIGINAL_MEMBER_INPUT_ERROR')
    with report.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(dict(status=result['status'],report=str(report),msiBuilt=False)));return 0 if result['status'].startswith('PASS_') else 1
if __name__=='__main__':raise SystemExit(main())
