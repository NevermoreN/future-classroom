R76 product-state instrument third preparation: NOT COMPILED / NOT RUN.
Only change from second: remove illegal ExactSpelling named property from FindData StructLayout attribute.
ExactSpelling remains only on the 11 DllImport declarations. All 3 StructLayout and 2 MarshalAs declarations reviewed;
CharSet.Unicode belongs on FindData and SizeConst260/14 remains on ByValTStr fields. SafeRegistryHandle signature
from second remains; the sole RegistryKey.Handle is still passed to that exact native SafeRegistryHandle parameter
inside the original RegistryKey using lifetime. SafeFileHandle output/input and nonowning stream view unchanged.
PS file is byte-identical, same Measure-FcProductState API and PSScriptRoot-relative C# source lookup.
The erroneous StructLayout property was introduced by an overly broad first-version attribute text replacement;
first/second actual Windows compile failures remain original. No compiler or PowerShell AST validation was performed
for third. Root must actually compile third; declaration review does not establish compilation or runtime success.
No Windows/network/Cargo/MSI/product/main or prior-source changes occurred. Existing read-only scope, unknown/failure
classification, all owner/authority limitations and caller-owned compiler TEMP/TMP requirements remain unchanged.
