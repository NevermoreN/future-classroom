R76 independent dual-artifact static audit preparation — NOT RUN

Exact source: 3bad94949012e840cd1dda6a73a0ea1ddb067697
Original single run modern: 41315306076; Win7: 41315385139; run_attempt must be exactly 1.
The auditor is byte-identical to R74 actual third mixed-slash-fixed checker (SHA4047bc6598059bd99a0aaf266c670b14983263a1a7909c4a0e19c9fc8c3b9622).
No generic product role: only fc-bootstrap and fc-installer-lifecycle normal GUI, exact Cargo profile.test=false,
same source/package/version/command/producer ledger, and dynamic metadata-derived complete test targets.
Current CI expects 22 test CUI plus 2 normal GUI; auditor derives counts from original Cargo metadata/commands,
not historical R74 totals. Original Win7 6.01 subsystem and CRT/import/flags/budget checks are unchanged.
Source partition LF/CRLF match and exact cargoLine producer associations are unchanged.
Historical Git metadata identities remain separate from actual nonhistorical checkout SHA256 evidence.
Mixed-slash executable must literally occur in raw filenames, with absolute/owned-target/release guards preserved.

Use ci-inputs-first.py as the entrypoint, never invoke the internal auditor before this terminal/download gate.
python3 /tmp/fc-round76-ci-evidence/ui-preparation-first/ci-inputs-first.py \
 --source-sha 3bad94949012e840cd1dda6a73a0ea1ddb067697 --baseline <modern|win7> \
 --run-id <exact corresponding above> --job-id <actual> --artifact-id <actual> \
 --zip <absolute owned original ZIP> --zip-bytes <actual> --zip-sha256 <actual64hex> \
 --run-metadata <actual terminal API wrapper> --job-metadata <actual terminal jobs API wrapper> \
 --artifact-metadata <actual official artifact API wrapper> \
 --download-receipt <actual successful download receipt> --download-receipt-sha256 <actual64hex> \
 --download-operation <actual terminal parent operation> --download-operation-sha256 <actual64hex> \
 --output-dir /tmp/fc-round76-ci-evidence/ui-preparation-first/<baseline>-artifact-original \
 --static-audit /tmp/fc-round76-ci-evidence/ui-preparation-first/<baseline>-independent-first.json \
 --static-operation /tmp/fc-round76-ci-evidence/ui-preparation-first/<baseline>-static-operation-first.json

Without --execute-static, only the prepared static command is printed after verified terminal inputs.
Missing/incomplete/RUNNING official or download inputs yield WAIT without opening/parsing the ZIP or creating reports.
Failed official CI/download candidates are rejected; do not run any failed target executable.
Add --execute-static only after all original IDs/size/SHA/source/official status and actual download parent are known.
Download parent requires actualExit true/exitCode0 and absolute raw stdout/stderr paths and exact bytes/SHA.
Static auditor only runs local objdump/git reads; no target executable, Rust helper, Windows, Cargo, network or dispatch.
Successful output is strictly PASS_STATIC_ONLY_RUNTIME_NOT_RUN, never Windows/Win7OS/Win10OS/MSI acceptance.
No artifact IDs, job IDs, ZIP hashes, sizes or metadata finality were guessed during preparation.
The old runtime_inputs function was intentionally removed from this static-only entrypoint; root retains the normal
Rust helper without executing it and will handle any later runtime owner separately.
