# Concrete test instruments: not executed or compiled yet

`GateRetirement.cs` and `ProcessObserver.cs` are .NET Framework-compatible C# library
sources for root's future reviewed PS runner. They are test instruments, with no
Main, product helper replacement, DLL/session bridge or production role. This
preparation has not compiled Add-Type or contacted Windows. C# compilation and
actual OS behavior remain NOT_RUN. Do not infer success from host lexical checks.

## Observer integration API

Root compiles ProcessObserver.cs using Add-Type with `System.Management` referenced.
Before each sole quiet MSI client, construct:

```text
$o = New-Object FcR76ProcessObserver(actualFullOverlaySHA, actualFullOverlayBytes,
                                    expectedCurrentUserSID, remainingPhaseMs)
```

The constructor starts a Win32_ProcessStartTrace WMI callback filtered to MSI*.tmp,
and a non-overlapping 10ms name-only poll. `remainingPhaseMs` is capped at150000
and must fit the original whole600s/cleanup180s clock; no new clock can enlarge
native120s. Constructor failure means do not launch this phase. Root owns and
holds its direct msiexec client separately. There is no PID/role JSON input.
The immediately opened candidate handles request only 0x101000 limitedquery/sync.
For each newly created original process, the instrument checks OS image in the
fixed Windows/Installer directory, MSI hex temporary basename, complete final
Binary-overlay byte length/SHA, and actual user token SID before reading any CLI.
No foreign CLI is read. Overlay SHA is from actual MSI Binary readback, not only
the unoverlaid normal EXE SHA. File hashing permits normal read/write/delete
sharing and does not hold engine temp files alive across a phase.

`$o.Snapshot()` returns a Report and performs only Wait(original,0) and actual
GetExitCodeProcess on already held original objects. Root serializes each report
immediately (Facts refer to the live instrument records). Loop only while the
remaining original phase/whole deadline permits; require actual original wait0,
exit0, parent linkage and later checked-close, not only a no-longer-present PID.
`finally { $last = $o.FinishAndClose() }` stops polling/watcher, drains in-flight
captures inside the remaining constructor deadline and checked-closes each held
original handle exactly once. If capture cannot drain by its original deadline,
it throws UNKNOWN and retains original handles; no retry/zero exit is fabricated.
A close failure is recorded UNKNOWN, never retried. Instrument errors/unknowns
prevent declaring a complete observation PASS. No method waits for engine death,
suspends/terminates any process, calls MSI transaction APIs, or mutates product
state. SCM service classification stays in root's runner and is separate.

Original WMI CreationDate must match the OS-held process creation within its
microsecond precision (9 FILETIME ticks); only then is its bounded CommandLine
parsed by CommandLineToArgvW. Closed role shapes are begin+fixed OSKnownFolder
mainfile, broker, commit, rollback, or nonzero-u32+guardian. Unreadable/missed WMI
metadata leaves role UNKNOWN while preserving the original held helper facts.
A broker's ParentLink is HELD_ORIGINAL_BEGIN_INSTANCE only when its parent PID matches an already held Begin instance born
before it. Begin/guardian parent facts independently query the original engine
instance, image System32/SysWOW64 msiexec, and token user/System. This is an
engine-instance fact, never an MSI session identifier or permission to join.
If Begin was missed, broker parent-link remains UNKNOWN rather than guessed.
The existing product uses its own actual native capability/Join/End/effects
protocol; instrumentation grants none of those permissions.

## Explicit engine evidence is a separate channel

The unchanged closed table has synchronous FcBeginGate Type2 (no async or ignore
return), source FcLifecycleHelper and fixed begin command; the chainer row is
FcLifecycleGuardian, source same Binary, Type2, command guardian. Root retains
raw verbose bytes with their actual encoding/chunk boundaries. An original
unique FcBeginGate Action start/ended Return value1 plus the matching actual
EXE invocation record and closed synchronous non-ignore table can be reviewed
as engine-reported successful action completion, not OS GetExitCodeProcess.
Action selection/skip, scheduling, package MSI exit0 and generic Return value1
alone cannot supply that evidence. Preserve actual engine strings/indices and
scope before deriving any parser acceptance; no synthetic engine proof is
provided by these instruments.

The archived R75 independent chainer verbose original contains Searching and
Scheduled to run after install, but no identifiable chainer-process exit0 field.
That raw original is not evidence of such a field. If actual product logs likewise
lack an explicit chainer result, original guardian exit remains UNKNOWN unless
captured by held process. Broker has no MSI Action row: neither Begin Return1
nor any engine summary can automatically stand in for original broker exit.
There is no WMI reliability guarantee; missed fast helpers are finite UNKNOWN,
never an excuse to block MSI indefinitely, add a barrier, or change the product.

## Exact post-test gate retirement API

This cleanup is permitted only because BEFORE proved the entire fixed
coordination namespace absent. It is not production recovery. After fresh
success, independent exact effects/registration proof, original helpers returned
and Pending known absent:

```text
$snapshot = [FcR76GateRetirement]::Capture(expectedCurrentUserSID)
$snapshot.Facts()  # serialize this identity/DACL record before the next mutation
```

Capture pins every original ancestor without DELETE sharing, rejects reparse
points, opens existing fixed directory, enumerates its HELD directory via
FileIdBothDirectoryInfo and requires exactly gate.lock. It exclusively queries
the zero-length single-link gate. It checks root/gate owner=currentUser, protected
DACL exactly user+SYSTEM FILE_ALL_ACCESS (directory OI|CI; file no inheritance).
It records volume/fileID/creation and semantic owner+DACL, then checked-closes
all handles before reapply. The Snapshot remains an opaque same-process object;
untrusted/deserialized JSON cannot construct it. It is not an owner lease.

Only after successful formal /x, product/all applicable contexts/family/component
registrations/manifest tree/marker leaf absent, original Begin/broker/guardian
returned, Run untouched, Pending absent and no unknown test owner, root may call:

```text
[FcR76GateRetirement]::Retire($snapshot)
```

Retire is single-use and does not accept caller booleans as fake settlement.
Root must verify those prerequisites from original evidence; this cleanup class
cannot authenticate MSI settlement. It pins the same ancestor path, opens original
root OPEN_EXISTING DELETE/query/list/readcontrol without delete sharing, compares
identity/DACL, requires exact gate-only held membership, then opens gate
OPEN_EXISTING DELETE/query/readcontrol share0. After original identity/DACL and
single-link/empty checks, it uses FileDispositionInfo with one-byte BOOLEAN true,
checked-closes that original gate once, re-enumerates the held root empty, sets
FileDispositionInfo on that same directory handle, then checked-closes it and
all ancestors. Root separately requires known absence of both paths and exact
owned scratch cleanup. It does not recursively remove anything, reopen an unknown
replacement for deletion, clear Pending, touch registry/cache/Run, kill a service,
or call the production broker. Sharing denial, unknown close, changed identity,
new member, reparse, effects/owner ambiguity or inability to delete the empty
original directory retains FAIL. There is no claim against arbitrary same-user
malicious concurrent namespace races. Unknown disposition/close is never retried.

## Current concrete remaining dependencies

1. Actual accepted same3bad Win7-target MSVC normal images/full ZIP/result and
   root-validated final original product MSI/closed table/Binary/payload report.
2. Root phase orchestrator binding those exact inputs to before/effect/API/log
   checks, original clock and two instruments, followed by actual compilation.
3. CRLF provenance: current prepare-production-msi.py binds the Linux LF
   packager SHA. A report produced from a same3bad exact-inventory CRLF worktree
   will intentionally need a separately reviewed explicit packager/inventory
   input variant; do not relabel its actual SHA as the LF file SHA. This initial
   preparation does not claim that later variant is implemented or tested.
4. Actual Windows compile/readonly-preflight/process-capture/retirement behavior
   remain NOT_RUN. Current authorized administrator Win11 only; no normal Rust
   helper execution, product MSI maintenance, standard user, Win7/Win10 or Seewo
   evidence is invented by preparation.
