#!/usr/bin/env python3
"""Synthetic outer-admission boundary checks, never an actual PE/MSI/runtime PASS."""
import ast,copy,hashlib,json,re,runpy,struct,subprocess,sys
from pathlib import Path
D=Path(__file__).resolve().parent
m=runpy.run_path(str(D/'prepare-production-msi.py'))
normal=bytearray(256);normal[:2]=b'MZ';struct.pack_into('<I',normal,60,64)
normal[64:68]=b'PE\0\0';struct.pack_into('<H',normal,68,0x14c)
struct.pack_into('<H',normal,88,0x10b);struct.pack_into('<HH',normal,136,6,1);struct.pack_into('<H',normal,156,2)
normal=bytes(normal);embedded=normal+b'synthetic-non-manifest';msi=b'synthetic-not-real-msi'
sha=lambda b:hashlib.sha256(b).hexdigest()
r={'status':'PASS','target':m['TARGET'],'installation':'NOT_RUN','readiness':'NOT_GRANTED','candidate_status':'NOT_VALIDATED',
 'script_sha256':'b'*64,'normal_helper_provenance':{'source_sha':m['SOURCE'],'profile_test':False,'normal_helper_sha256':sha(normal)},
 'payload_extraction':'EXACT_BYTES_MATCH','msi_lifecycle_binary_readback':'EXACT_NORMAL_PREFIX_AND_CLOSED_OVERLAY_BYTES_MATCH',
 'msi':{'size':len(msi),'sha256':sha(msi)},'lifecycle_binary':{'bytes':len(embedded),'sha256':sha(embedded),'normal_prefix_bytes':len(normal),'normal_prefix_sha256':sha(normal)},
 'authoring':{'upgrade_code':m['FAMILY'],'product_code':'{01234567-89AB-CDEF-0123-456789ABCDEF}'},'payloads':[{'path':'fc-bootstrap.exe'}]}
rows=[]
def trial(name,mutate,expected_reject):
 q=copy.deepcopy(r);mutate(q)
 try:m['admit'](q,normal,msi,embedded,'b'*64);rejected=False
 except (ValueError,KeyError):rejected=True
 if rejected!=expected_reject:raise AssertionError(name)
 rows.append({'case':name,'result':'PASS_SYNTHETIC_BOUNDARY','rejected':rejected})
trial('synthetic outer byte-binding only, not full parser',lambda q:None,False)
trial('modern target cannot replace Win7 source artifact',lambda q:q.update(target='i686-pc-windows-msvc'),True)
trial('test harness cannot replace normal helper',lambda q:q['normal_helper_provenance'].update(profile_test=True),True)
trial('different source cannot be relabeled',lambda q:q['normal_helper_provenance'].update(source_sha='0'*40),True)
trial('changed final MSI bytes fail',lambda q:q['msi'].update(sha256='0'*64),True)
trial('changed complete embedded helper bytes fail',lambda q:q['lifecycle_binary'].update(sha256='0'*64),True)
trial('changed actual packager SHA fails rather than CRLF relabel',lambda q:q.update(script_sha256='c'*64),True)
for offset,value,name in [(156,3,'CUI cannot replace GUI normal'),(136,6,'6.0 subsystem cannot replace Win7 6.1')]:
 b=bytearray(normal)
 if offset==136:struct.pack_into('<HH',b,136,value,0)
 else:struct.pack_into('<H',b,offset,value)
 try:m['pe_gui_win7'](b);raise AssertionError(name)
 except ValueError:rows.append({'case':name,'result':'PASS_SYNTHETIC_BOUNDARY','rejected':True})
commands=m['command_plan']('{01234567-89AB-CDEF-0123-456789ABCDEF}',r'C:\x\candidate.msi',r'C:\x')
assert all('/qn' in a and '/norestart' in a for a in commands.values())
assert commands['formalUninstall'][:2]==['/x','{01234567-89AB-CDEF-0123-456789ABCDEF}']
assert commands['healthyReapply'].count('REINSTALL=ALL')==1 and commands['healthyReapply'].count('REINSTALLMODE=amus')==1
rows.append({'case':'quiet fixed healthy-reapply/formal-x argv shapes','result':'PASS_PURE_ARGV_ONLY'})
for name in ['prepare-production-msi.py',Path(__file__).name]:
 p=D/name;ast.parse(p.read_text(),filename=p.name)
# Structural text check only. This is explicitly NOT a C# parser/compiler or OS test.
lexical=[]
for p in [D/'GateRetirement.cs',D/'ProcessObserver.cs']:
 s=re.sub(r'@"(?:[^"]|"")*"|"(?:\\.|[^"\\])*"|//[^\n]*|/\*.*?\*/', '',p.read_text(),flags=re.S)
 stack=[];pairs={')':'(',']':'[','}':'{'}
 for c in s:
  if c in '([{':stack.append(c)
  elif c in ')]}':
   assert stack and stack.pop()==pairs[c],p.name
 assert not stack,p.name
 lexical.append({'path':p.name,'balancedDelimiters':True,'csharpCompiler':'NOT_RUN'})
print(json.dumps({'status':'PASS_PURE_PREPARATION_ONLY','cases':rows,'pythonAst':'PASS','csharpTextOnly':lexical,
 'fullOverlayParserWithActualArtifacts':'NOT_RUN','windows':'NOT_RUN','network':'NOT_RUN','cargo':'NOT_RUN'},indent=2))
