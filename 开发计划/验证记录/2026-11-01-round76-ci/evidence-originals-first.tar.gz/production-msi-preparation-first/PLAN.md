# R76 production MSI: bounded preparation, no execution

Source: `3bad94949012e840cd1dda6a73a0ea1ddb067697`. B4 packager admits only
`i686-win7-windows-msvc` with its original Win7-baseline CI result. Modern CI
success cannot be relabeled as this input. The future app and helper must be
same-source ordinary GUI images with Cargo profile.test=false; full accepted
ZIP/Web manifest, ledgers and raw result remain required. Targeting Win7 and
executing on the current authorized administrator account's Win11 are distinct
facts; no standard-user/no-elevation, Win7 OS, Win10 or Seewo claim follows.

No fresh MSVC binary/product MSI exists at preparation time. This directory
therefore contains a candidate-binding CLI, a read-only before-check script and
a finite run plan, rather than a pretend complete executable controller. None
has an execute switch or runs a helper, MSI, network command, app, audio, task,
service control, foreground UI, listener, school-data path or real Run mutation.

## Concrete preparation CLI

`python3 -B prepare-production-msi.py --describe` states pending artifacts.
When root has accepted actual output from the unchanged packager, use:

```text
python3 -B prepare-production-msi.py
 --packaging-report <absoluteR76/package/report.json>
 --packaging-report-sha256 <actualSHA>
 --normal-helper <absoluteR76/acceptedCI/product/.../fc-installer-lifecycle.exe>
 --normal-helper-sha256 <actualSHA>
 --runtime-nonce <32lowerhex> --expected-user-sid <actualUserSID>
 --output-dir <newAbsoluteR76Directory>
```

It binds actual normal PE prefix, complete embedded overlay, deterministic
Product/Component IDs, all exact payload bytes, report and final MSI identities.
It requires the packager's actual static/Binary/payload extraction PASS while
retaining candidate/readiness/runtime NOT_VALIDATED/NOT_GRANTED/NOT_RUN. It
never creates an MSI or contacts Windows. A new candidate-inputs.json includes
phase argv templates and six hundred seconds for this **new whole experiment**.
No current nonexistent artifact SHA or success record is invented.

## Required before checks

Root sends `ReadOnlyPreflight.ps1` with the exact hashed config through the R75
archived short UTF8-stdin bootstrap. It only queries current-user/machine COM
registration and exact paths/keys, returns its original JSON on stdout and
creates nothing. Resolve LocalAppData through the OS Known Folder; never use a
caller-selected product path. Require known absence of all of:

* LocalAppData/Programs/FutureClassroom (any object, alias/reparse or unknown refuses).
* LocalAppData/FutureClassroom-Installer-99378807-098D-5F04-8D4D-F181DFA218D5.
* Exact ProductCode in contexts7 (current-user per-user plus machine), ProductState=-1,
  and zero RelatedProducts for the fixed family. Other users are outside this test.
* Entire HKCU32 Software/FutureClassroom/Installer/Components key.
* Fixed HKCU32 Run value FutureClassroom, of any type/contents. Its contents are
  not retained and no other startup configuration is dumped.

Any preexisting/unknown state stops before product mutation. No original school
ProgramData object is opened, initialized or cleaned by MSI or this plan. Root
also records its normal final read-only SSH/Run/foreground and exact test scratch
baseline. Host app is never launched, including through shell associations.
The product's own Begin independently revalidates actual fixed target, actual
SID/product/context/family/Run/effects under its original gate; preflight JSON
does not grant native authority.

## One experiment clock and phase order

Proposed whole-test budget600 seconds, with180 seconds kept for finally/cleanup;
each MSI-client wait maximum150 seconds and shortened to remaining original
time. This is a new three-phase test envelope, **not** an increase or renewal
of the native broker's original120-second deadline. No retries, transforms,
public authentication flags or skipped hooks. If remaining time cannot cover
the next action and reserved cleanup, do not begin that action.

1. Root admits the real final MSI SHA, closed-table/extraction/Binary report and
   actual same-source normal helper/Cargo ledger. Retain original source/normal
   helper/full overlaid helper/manifest/MSI identities. Create only one fresh
   nonce-owned temporary runtime root, explicit owner=currentUser and protected
   user+SYSTEM-only DACL. Upload only the admitted MSI/config/instrumentation.
2. Start bounded **external read-only process observation** before `/i`: root
   holds original msiexec client object; candidate helper identities must be
   captured from actual process objects (PID+creation, exact full overlaid-image
   SHA, own user SID, parent identity). The normal helper prints no pre-join JSON,
   and broker is not a named MSI CustomAction. A temporary process-start watcher
   plus narrowly filtered/polled MSI extracted-image candidates is a possible
   implementation; it must retain live original Begin/broker/guardian query+sync
   handles before they disappear, then Stop/Dispose watcher and all controls.
   Merely seeing a PID/CLI/known same image or service PID never supplies authority.
   Do not add a production bypass or use C#/libtest/GNU in place of the real helper.
3. Quiet fresh `/i <sameMSI> /qn /norestart REBOOT=ReallySuppress
   MSIRESTARTMANAGERCONTROL=DisableShutdown /L*vx <fresh.log>`.
   Preserve integer client/Begin/guardian/broker exits separately. Require exact
   installed manifest file set/hash/size, no extra directories/files/reparse or
   hard links; exact HKCU32 component marker GUID set/DWORD1 and actual native
   MsiGetComponentPathEx context2 stateLOCAL/path `01:\Software\FutureClassroom\Installer\Components\<GUID>`;
   one exact ProductCode/version/current user SID/unmanaged context, one related
   product, Run value still absent. Query canonical API values with NULL meaning
   absent pointer where required; do not substitute empty SID strings blindly
   into native MsiGetComponentPathEx. Component API buffers/returns are bounded.
4. After all original owner processes have returned and Pending is absent,
   healthy same-manifest reapply using the **same** MSI:
   `/i <sameMSI> /qn /norestart REINSTALL=ALL REINSTALLMODE=amus
   REBOOT=ReallySuppress MSIRESTARTMANAGERCONTROL=DisableShutdown /L*vx <repair.log>`.
   Repeat complete exact payload/registration/marker/Run/process/Pending proof.
   REINSTALL intent is not authority; native SameManifest tag5 derives it from
   healthy actual facts. Do not damage/delete a file to pretend missing-file
   repair is supported. Reapplication of a healthy manifest is this case only.
5. Formal `/x <exactProductCode>` quiet with the same shutdown/reboot flags and
   original uninstall log. Require actual terminal return, original helper and
   broker return, absent Product/context/related/component registrations, entire
   fixed program tree and marker leaf key absent; Run unchanged/absent. Observe
   leftover empty registry ancestors separately, without guessing their removal.
6. Finally and on any error, requery exact state first. Only if this run proved
   BEFORE absence and owns the just-installed exact product, original owner is
   known returned, Pending absent and the original healthy manifest is known may
   one necessary formal `/x` run. Unknown/live owner or Pending is retained FAIL;
   do not force/unblock it with another owner, blind journal/cache/registry/file
   deletion, service kill or a modified MSI. Log skipped cleanup and exact reason.

## Owner/Pending and logging qualification

The helper opens the original engine with limited query+synchronize. N3 allows
its exact parent SID to be currentUser or LocalSystem; helper/pipe/effects SID
stays currentUser. Verify current SCM msiserver Name/PID+creation/OS msiexec image
and LocalSystem ownership as in archived R75 runtime. A shared service may start
after an empty baseline and is not test-owned; never wait/kill/require it absent.
Other new processes remain UNCLASSIFIED, never assumed owned by basename alone.

Keep root's raw MSI logs, exact controller script/command/input hashes and raw
captured process facts. Derive entry roles only within exact helper process and
parent/image capability evidence, not from a packet PID or arbitrary command.
The product helper has no raw Join/End diagnostic output; a source-bound successful
guardian exit supports its existing checked code path, not a separately sampled
integer API result. The R75 C# Join0/EndRollback0 does not substitute for it.
Broker exit0, aftereffect proof and Pending absence remain separate necessary
observations; MSIclient exit0 or an engine advisory notification alone is insufficient.

`pending.v1` is CREATE_NEW with share0; a live owner's contents/operation nonce
may be intentionally unreadable. Do not weaken sharing or require a fabricated
wire receipt to inspect it. Record actual path presence/known sharing denial
when observable; after the held original broker returns require known absence
and exclusive original gate access. If an orphan Pending is readable after
failure, preserve bounded original bytes/hash for diagnosis, never delete it.
Missing original process exit evidence remains UNKNOWN; an explicit original
engine log may be assessed independently but cannot silently supply broker exit.

## Known concrete cleanup boundary before any real commit

Native Resources::open creates the fixed coordination directory and gate.lock
(`native.rs:238-275`). `clear_pending` deletes only pending.v1 and release closes
the gate; it does not delete gate.lock/directory (`native.rs:461-505`). Formal
MSI authoring owns the program tree/component markers only, and the packaging
contract explicitly does not claim coordination-gate retirement. Thus even a
successful formal `/x` cannot currently be called zero test residue automatically.

Before executing initial fresh commit, root must review a concrete, separate
test-only retirement procedure for the exact gate objects created after this
run's BEFORE absence. The instrument is now prepared separately; any inability
to establish its prerequisites retains FAIL and the original objects. A safe proposal requires all original helper/
broker handles returned, Pending absent, exact directory/gate volume+fileID+
creation/owner/protected ACL captured after initial settle and unchanged after
formal `/x`, exact membership only gate.lock, no reparse/hard links, exclusive
gate open with the same identity and final original controls closed. Deletion
must target only those held original test-created objects, not a reopened unknown
path. Test-only GateRetirement.cs now supplies this narrow held-object procedure;
it is not invoked by the prep CLI or preflight script. See INSTRUMENTATION.md.
Its C# compilation and actual Windows behavior remain NOT_RUN.
Any mismatch/unknown retains FAIL and this test's evidence for root. This is an
actual documented source gap, not an invented arbitrary-MSI/transform release gate.

Similarly, a failed native maintenance can intentionally leave durable Pending
which prevents another normal Begin and startup. This slice has no stale-owner
recovery API. The finally rule must retain that state; it cannot promise formal
`/x` can clean every failed/incomplete installation. Root reviews this before
choosing the first real product mutation, and source diagnostics can continue
without silently weakening the fail-closed behavior.

## Remaining concrete dependencies

Actual accepted same3bad Win7-target MSVC ZIP/result and normal GUI app/helper;
root-built original product MSI/static extraction/Binary ledger; candidate-specific
config; reviewed external observer/held-handle identity and exact gate-retirement
implementation. These are why this delivery is bounded preparation rather than a
finished Windows runner. No source changes or extra DLL/new product binary are
proposed here. Root alone decides and performs Windows execution after reviewing
the actual candidate and these exact closure points. All historical failures
remain original; product MSI maintenance is still NOT_RUN.
