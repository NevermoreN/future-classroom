// TEST-ONLY cleanup of SIX captured, exact-image temporary files. No Main.
// Root must independently prove original controls returned, product/components/
// related/Run/Pending/gate absent before invocation. This class cannot establish
// MSI settlement and deliberately accepts no caller-supplied authority booleans.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

public static class FcR76ExactMsiImageRetirement {
    const string DirectoryPath=@"C:\Windows\Installer";
    const string ExpectedSha="b4e4626c2d3eca60b72b0f2e934da5606ba0eb09bfc42d025e5c36b41fb27be8";
    const uint ExpectedBytes=395144;
    static readonly string[] Leaves={"MSI72B5.tmp","MSI75E5.tmp","MSIED48.tmp","MSIF049.tmp","MSIF1F0.tmp","MSIF445.tmp"};
    const uint ReadAttributes=0x80,ReadControl=0x20000,Delete=0x10000,GenericRead=0x80000000;
    const uint Existing=3,NoFollow=0x00200000,Backup=0x02000000;
    static bool used,faulted;
    [StructLayout(LayoutKind.Sequential)] struct Info {
        public uint Attributes,CreationLow,CreationHigh,AccessLow,AccessHigh;
        public uint WriteLow,WriteHigh,Volume,SizeHigh,SizeLow,Links,IndexHigh,IndexLow;
    }
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr CreateFile(string p,uint access,uint share,IntPtr sa,uint disposition,uint flags,IntPtr template);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetFileInformationByHandle(IntPtr h,out Info info);
    [DllImport("kernel32.dll",SetLastError=true)] static extern uint GetFileType(IntPtr h);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool ReadFile(IntPtr h,byte[] b,uint count,out uint read,IntPtr overlap);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool SetFileInformationByHandle(IntPtr h,int kind,byte[] b,uint count);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool CloseHandle(IntPtr h);
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern uint GetFinalPathNameByHandle(IntPtr h,StringBuilder p,uint count,uint flags);
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern uint GetFileAttributes(string p);
    public sealed class FileFact {
        public string Path,Status="NOT_OPENED",Stage="INITIAL",BeforeIdentity,AfterIdentity,ActualSha256,FinalHeldPath;
        public uint? Bytes,Links,Attributes,OpenError,DispositionError,CloseError,AbsenceError;
        public bool? DispositionSuccess,CloseSuccess;
        public string ExternalPathStatus="NOT_QUERIED";
    }
    public sealed class ParentFact {
        public string Path,Identity; public bool? CloseSuccess;public int? CloseError;
        internal IntPtr Handle;
    }
    public sealed class Report {
        public string Status="FAIL_RETAIN_UNDELETED_OR_UNKNOWN_ORIGINALS";
        public string Scope="TEST_ONLY_SIX_FIXED_ORIGINAL_OVERLAY_IMAGES_NO_CACHED_MSI_NO_SERVICE_MUTATION";
        public string ExpectedSha256=ExpectedSha;
        public uint ExpectedImageBytes=ExpectedBytes;
        public int OriginalBudgetMilliseconds=30000;
        public bool SourceCalledOnce,AllPreflightPassed,ProcessMutation=false,RegistryMutation=false,ServiceMutation=false;
        public long ElapsedMilliseconds;
        public string FailureStage,FailureType;public int? FailureHresult;
        public FileFact[] Files;public ParentFact[] Parents;
        public List<string> Errors=new List<string>();
    }
    sealed class Held { internal IntPtr Handle;internal Info Info;internal FileFact Fact; }
    static void Need(bool value,string stage) { if(!value)throw new InvalidOperationException(stage); }
    static Exception Error(string stage) { return new Win32Exception(Marshal.GetLastWin32Error(),stage); }
    static string Id(Info i) { return i.Volume.ToString("x8")+":"+i.IndexHigh.ToString("x8")+i.IndexLow.ToString("x8")+":"+i.CreationHigh.ToString("x8")+i.CreationLow.ToString("x8")+":"+i.WriteHigh.ToString("x8")+i.WriteLow.ToString("x8"); }
    static Info Inspect(IntPtr h,bool directory) {
        Info i;if(!GetFileInformationByHandle(h,out i))throw Error("GetFileInformationByHandle");
        Need((i.Attributes&0x400)==0&&((i.Attributes&16)!=0)==directory,"NO_REPARSE_OR_WRONG_TYPE");
        Need(GetFileType(h)==1,"DISK_OBJECT_ONLY");
        if(!directory)Need(i.Links==1&&i.SizeHigh==0&&i.SizeLow==ExpectedBytes,"EXACT_EMPTY_OF_OTHERS_SINGLE_LINK_IMAGE_SIZE");
        return i;
    }
    static bool Same(Info a,Info b) { return Id(a)==Id(b)&&a.Attributes==b.Attributes&&a.SizeHigh==b.SizeHigh&&a.SizeLow==b.SizeLow&&a.Links==b.Links; }
    static string FinalPath(IntPtr h) {
        StringBuilder p=new StringBuilder(1024);uint n=GetFinalPathNameByHandle(h,p,1024,0);
        if(n==0)throw Error("GetFinalPathNameByHandle");Need(n<1024,"BOUNDED_FINAL_PATH");return p.ToString();
    }
    static void CheckClock(Stopwatch clock) { Need(clock.ElapsedMilliseconds<30000,"ORIGINAL_TEST_CLEANUP_DEADLINE"); }
    static string Hash(IntPtr h,Stopwatch clock) {
        byte[] buffer=new byte[4096];uint total=0;
        using(SHA256 hash=SHA256.Create()) {
            for(int i=0;i<128;i++) {
                CheckClock(clock);uint n;if(!ReadFile(h,buffer,(uint)buffer.Length,out n,IntPtr.Zero))throw Error("ReadFile");
                if(n==0) { Need(total==ExpectedBytes,"EXACT_EOF_SIZE");hash.TransformFinalBlock(new byte[0],0,0);return BitConverter.ToString(hash.Hash).Replace("-","").ToLowerInvariant(); }
                Need(n<=buffer.Length&&total+n<=ExpectedBytes,"BOUNDED_IMAGE_READ");
                hash.TransformBlock(buffer,0,(int)n,buffer,0);total+=n;
            }
        }
        throw new InvalidOperationException("HASH_ITERATION_BOUND");
    }
    static bool CloseOnce(ref IntPtr h,out int error) {
        error=0;if(h==IntPtr.Zero)return true;
        IntPtr original=h;h=IntPtr.Zero; // unknown CloseHandle is NEVER retried
        if(CloseHandle(original))return true;
        error=Marshal.GetLastWin32Error();faulted=true;return false;
    }
    static void ReadAbsence(FileFact f) {
        uint a=GetFileAttributes(f.Path);
        if(a!=0xffffffff) { f.ExternalPathStatus="PRESENT_REVIEW_REQUIRED";return; }
        int e=Marshal.GetLastWin32Error();f.AbsenceError=(uint)e;
        f.ExternalPathStatus=(e==2||e==3)?"KNOWN_ABSENT":"UNKNOWN_RETAIN_FAILURE";
    }
    // No arguments: callers cannot select paths, substitute a hash, request force,
    // supply effects flags, retry an unknown close, or touch registered MSI caches.
    public static Report RetireSix() {
        Report r=new Report();List<ParentFact> parents=new List<ParentFact>();List<Held> held=new List<Held>();Stopwatch clock=Stopwatch.StartNew();string stage="ADMISSION";
        try {
            Need(!used&&!faulted,"SINGLE_INVOCATION_NO_RETRY");used=true;r.SourceCalledOnce=true;
            Need(String.Equals(Environment.GetFolderPath(Environment.SpecialFolder.Windows),@"C:\Windows",StringComparison.OrdinalIgnoreCase),"FIXED_ACTUAL_WINDOWS_ROOT");
            foreach(string p in new string[]{@"C:\",@"C:\Windows",DirectoryPath}) {
                CheckClock(clock);stage="PIN_PARENT:"+p;
                IntPtr h=CreateFile(p,ReadAttributes|ReadControl,3,IntPtr.Zero,Existing,NoFollow|Backup,IntPtr.Zero);
                if(h==new IntPtr(-1))throw Error("OPEN_EXISTING_PARENT");
                ParentFact f=new ParentFact();f.Path=p;f.Handle=h;parents.Add(f);f.Identity=Id(Inspect(h,true));
            }
            foreach(string leaf in Leaves) {
                CheckClock(clock);FileFact f=new FileFact();f.Path=DirectoryPath+"\\"+leaf;Held h=new Held();h.Fact=f;held.Add(h);stage="PREFLIGHT:"+leaf;f.Stage="OPEN_EXISTING_SHARE0_READ_DELETE";
                h.Handle=CreateFile(f.Path,GenericRead|Delete|ReadAttributes,0,IntPtr.Zero,Existing,NoFollow,IntPtr.Zero);
                if(h.Handle==new IntPtr(-1)) {
                    int e=Marshal.GetLastWin32Error();h.Handle=IntPtr.Zero;f.OpenError=(uint)e;
                    if(e==2) { f.Status="KNOWN_ALREADY_ABSENT_NO_MUTATION";f.ExternalPathStatus="KNOWN_ABSENT";continue; }
                    throw new Win32Exception(e,"OPEN_EXISTING_IMAGE_BUSY_OR_UNKNOWN");
                }
                h.Info=Inspect(h.Handle,false);f.BeforeIdentity=Id(h.Info);f.Bytes=h.Info.SizeLow;f.Links=h.Info.Links;f.Attributes=h.Info.Attributes;
                f.FinalHeldPath=FinalPath(h.Handle);Need(String.Equals(f.FinalHeldPath,@"\\?\"+f.Path,StringComparison.OrdinalIgnoreCase),"EXACT_HELD_FINAL_PATH");
                f.Stage="FULL_ORIGINAL_OVERLAY_HASH";f.ActualSha256=Hash(h.Handle,clock);Need(f.ActualSha256==ExpectedSha,"FULL_EXACT_ORIGINAL_OVERLAY_SHA");
                Info after=Inspect(h.Handle,false);f.AfterIdentity=Id(after);Need(Same(h.Info,after),"STABLE_SAME_HANDLE_IDENTITY_SIZE_CREATION_WRITE_TIME");
                f.Status="EXACT_PREFLIGHTED_NOT_DELETED";
            }
            HashSet<string> identities=new HashSet<string>(StringComparer.Ordinal);
            foreach(Held h in held) if(h.Handle!=IntPtr.Zero)Need(identities.Add(h.Fact.BeforeIdentity),"NO_SHARED_OR_DUPLICATE_FILE_IDENTITIES");
            r.AllPreflightPassed=true;
            foreach(Held h in held) {
                if(h.Handle==IntPtr.Zero)continue;CheckClock(clock);FileFact f=h.Fact;stage="RETIRE:"+Path.GetFileName(f.Path);f.Stage="SAME_HANDLE_IDENTITY_RECHECK";
                Need(Same(h.Info,Inspect(h.Handle,false)),"UNCHANGED_ORIGINAL_OBJECT_BEFORE_DISPOSITION");
                f.Stage="FILE_DISPOSITION_INFO";bool ok=SetFileInformationByHandle(h.Handle,4,new byte[]{1},1);f.DispositionSuccess=ok;
                if(!ok) { f.DispositionError=(uint)Marshal.GetLastWin32Error();throw new Win32Exception((int)f.DispositionError.Value,"ORIGINAL_DISPOSITION_FAILED_NO_FORCE"); }
                f.Stage="CHECKED_CLOSE_ONCE";int error;bool close=CloseOnce(ref h.Handle,out error);f.CloseSuccess=close;f.CloseError=(uint)error;
                Need(close,"UNKNOWN_CLOSE_NOT_RETRIED");f.Status="ORIGINAL_DISPOSITION_AND_CLOSE_SUCCEEDED";
                ReadAbsence(f);Need(f.ExternalPathStatus=="KNOWN_ABSENT","EXTERNAL_ABSENCE_REQUIRED");f.Stage="ABSENT";
            }
            foreach(Held h in held) { ReadAbsence(h.Fact);Need(h.Fact.ExternalPathStatus=="KNOWN_ABSENT","ALL_SIX_EXACT_PATHS_KNOWN_ABSENT"); }
            r.Status="PASS_SIX_EXACT_TEST_IMAGE_PATHS_ABSENT_CHECKED_ORIGINAL_RETIREMENT";
        } catch(Exception e) { r.FailureStage=stage;r.FailureType=e.GetType().FullName;r.FailureHresult=e.HResult;r.Errors.Add(e.Message); }
        finally {
            for(int i=held.Count-1;i>=0;i--) {
                Held h=held[i];if(h.Handle==IntPtr.Zero)continue;int error;bool ok=CloseOnce(ref h.Handle,out error);h.Fact.CloseSuccess=ok;h.Fact.CloseError=(uint)error;
                if(!ok) { r.Status="FAIL_UNKNOWN_ORIGINAL_CLOSE_NOT_RETRIED";r.Errors.Add("image_close_unknown:"+Path.GetFileName(h.Fact.Path)); }
            }
            for(int i=parents.Count-1;i>=0;i--) {
                ParentFact p=parents[i];int error;bool ok=CloseOnce(ref p.Handle,out error);p.CloseSuccess=ok;p.CloseError=error;
                if(!ok) { r.Status="FAIL_UNKNOWN_PARENT_CLOSE_NOT_RETRIED";r.Errors.Add("parent_close_unknown:"+p.Path); }
            }
            if(faulted)r.Status="FAIL_INSTRUMENT_STICKY_UNKNOWN_CLOSE";
            List<FileFact> output=new List<FileFact>();foreach(Held h in held)output.Add(h.Fact);
            r.Files=output.ToArray();r.Parents=parents.ToArray();r.ElapsedMilliseconds=clock.ElapsedMilliseconds;
        }
        return r;
    }
}
