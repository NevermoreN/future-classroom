R76 Win7-target MSVC finite runtime ON WIN11 preparation — NOT RUN

Entry: /tmp/fc-round76-ci-evidence/ui-win7target-runtime-preparation-first/run-windows-win7target-first.py
Root remains sole Windows owner. No --execute: missing inputs return WAIT without connection or runtime report;
with all actual inputs present, default prints only PREPARED_RUNTIME_CONTROLLER_ONLY_NOT_EXECUTED.

Actual future command (root supplies each terminal original, artifact ID/hash/path; no values guessed):
python3 -B /tmp/fc-round76-ci-evidence/ui-win7target-runtime-preparation-first/run-windows-win7target-first.py \
 --source-sha 3bad94949012e840cd1dda6a73a0ea1ddb067697 --baseline win7 --run-id 41315385139 \
 --job-id <actual-win7-target-job> --artifact-id <actual-win7-target-artifact> \
 --zip <owned-original-completed-ZIP> --zip-bytes <actual-bytes> --zip-sha256 <actual64hex> \
 --run-metadata <terminal-original-win7-run-API-wrapper> \
 --job-metadata <terminal-original-win7-jobs-API-wrapper> \
 --artifact-metadata <actual-original-artifact-API-wrapper> \
 --download-receipt <terminal-successful-download-receipt> --download-receipt-sha256 <actual64hex> \
 --download-operation <actual-terminal-download-parent> --download-operation-sha256 <actual64hex> \
 --output-dir <EXACT-static-auditor-extraction-output-dir> \
 --static-audit <actual-v2-static-PASS-report> --static-audit-sha256 <actual64hex> \
 --static-operation <actual-static-auditor-parent-PASS-operation> --static-operation-sha256 <actual64hex> \
 --report /tmp/fc-round76-ci-evidence/<new-win7target-on-win11-runtime-report>.json \
 --operation /tmp/fc-round76-ci-evidence/<new-win7target-on-win11-runtime-operation>.json

Only after review add --execute. The --output-dir belongs to the original static auditor and is required to match
that exact executed command; it is not a fresh runtime directory. All proposed runtime report/operation/raw log names
must be new. Every input must be under R76 owned root; metadata and static/download parent commands/logs are reopened.
The static gate directory is untouched. New runtime-input bridge validates source3bad/run41315385139/attempt1,
actual v2 PASS_STATIC_ONLY_RUNTIME_NOT_RUN six phases/helper SHA and actual parent exit0/report SHA/command;
all24 PE hashes and profile.test/subsystem roles; metadata-derived exact22 target inventory and Cargo JSON mappings;
exact two normal GUI targets and pinned current broker Git/LF-or-CRLF checkout identity.

Runtime command delegates to unchanged main scripts/windows-probe.py:
 --host elior@192.168.10.212
 --identity /config/.local/share/future-classroom-test-access/win11-192.168.10.212
 --test-timeout-seconds 900 --native-seconds 1 --system-host --public-desktop
SSH private-key bytes are never inspected by preparation; later SSH uses it only as existing transport identity.
Upload is exactly22 test CUI plus app normalGUI=23. Lifecycle normalGUI helper is hash-pinned but never uploaded or
executed by this runner. Its separate test harness is included in the22. Runtime verifies actual23 uploaded hashes,
all22 individual names/exit/summaries/cases, app self/native/system host exit0 and public20/cleanupPASS.
All24 artifacts, metadata, static/download/official inputs and pinned source/probe/parsers are rehashed before/after.

Native stdout uses current broker source9fc3247c... same actual child topology independently observed in R75:
exactly2 child running/case/summary triples (6 lines) kept separately; outer derived view goes through unchanged R67
strict per-case parser. Parent/native case count and totals come from actual output, never fixed1560/old261/1554.
Original raw/normalized output is retained. Missing raw PID/create cannot become independently observed OS identity.

Scope is finite actual authorized Windows11 build26300/WOW64 only. No Win7OS/Win10OS, newMSI, ordinary31,
recovery, visual, Edge, header, campus or full production acceptance. Static CI evidence is separate from runtime.
Preparation performed AST, actual default-WAIT command and fixed-baseline/run/source/PE6.1 pure negatives;
child attribution logic is byte-identical to already-checked modern parser except the scope comment; no actual R76 artifact, Windows/SSH, network, Cargo, normalhelper, MSI or product EXE run.

This entry and its input bridge each independently require baseline win7/run41315385139/source3bad.
All24 actual PE subsystem versions must be6.1; normal products must GUI2/profile.test=false.
Actual status can only be PASS_R76_WIN7_TARGET_MSVC_FULL22_ON_WIN11_ONLY, never Win7 OS PASS.
