"""Create one same-source owned checkout; exact raw successful CI bytes required."""
from pathlib import Path
import argparse, hashlib, json, stat, subprocess, time
R=Path('/tmp/fc-round76-ci-evidence'); MAIN=Path('/workspace/共享/Eliora/未来教室计划')
D=R/'msi-checkout-preparation-first'; WT=D/'checkout-3bad949-first'
SOURCE='3bad94949012e840cd1dda6a73a0ea1ddb067697'
AUDIT=R/'ui-preparation-first/win7-independent-first.json'
AUDIT_SHA='36ea9d1547ba3dec8d4cf5c53c92d57878ee37cc8095df17bcffde3dcb663ef1'
RAW=R/'ui-preparation-first/win7-artifact-original/raw'
def need(v,s):
    if not v: raise AssertionError(s)
def digest(b):return hashlib.sha256(b).hexdigest()
def git(*tail,root=MAIN):return subprocess.check_output(['git','-C',str(root),'-c','core.autocrlf=true',*tail],timeout=30)
def fact(p):
    need(stat.S_ISREG(p.lstat().st_mode),'REGULAR_FILE');b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=digest(b))
def main():
    p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');a=p.parse_args()
    if not a.execute: print(json.dumps(dict(status='NOT_RUN_PREPARATION_ONLY',sourceSha=SOURCE)));return 0
    need((R/'.owner').read_bytes()==b'future-classroom-owned-r76-ci-evidence/v1\n','EXACT_R76_OWNER')
    need(digest(AUDIT.read_bytes())==AUDIT_SHA,'ACTUAL_ACCEPTED_WIN7_AUDIT')
    audit=json.loads(AUDIT.read_bytes());need(audit['status']=='PASS_STATIC_ONLY_RUNTIME_NOT_RUN' and audit['sourceSha']==SOURCE and audit['runId']==41315385139 and audit['baseline']=='Win7','EXACT_ACTUAL_WIN7_SOURCE')
    members={r['path']:r for r in audit['members']};need(len(members)==len(audit['members']),'UNIQUE_ACCEPTED_MEMBERS')
    for n in ['input-sha256.json','input-sha256-after.json']:
        b=(RAW/n).read_bytes();need(len(b)==members[n]['bytes'] and digest(b)==members[n]['sha256'],'EXACT_ORIGINAL_CI_INVENTORY')
    before=(RAW/'input-sha256.json').read_bytes();need(before==(RAW/'input-sha256-after.json').read_bytes(),'EXACT_CI_BEFORE_AFTER')
    inventory=json.loads(before);rows={r['path']:r for r in inventory};need(len(rows)==len(inventory),'UNIQUE_CI_INPUTS')
    need(git('rev-parse','HEAD').decode().strip()==SOURCE and git('status','--porcelain','-z','--untracked-files=all')==b'','MAIN_HEAD_AND_CLEAN')
    need(D.is_dir() and not WT.exists(),'FRESH_OWNED_CHECKOUT')
    report=D/'actual-checkout-first.json';need(not report.exists(),'NEW_REPORT')
    cmd=['git','-C',str(MAIN),'-c','core.autocrlf=true','worktree','add','--detach',str(WT),SOURCE]
    value=dict(status='RUNNING',sourceSha=SOURCE,command=cmd,originalBudgetSeconds=180,acceptedAudit=fact(AUDIT),scope='Same committed source with command-local Git checkout settings. No source normalization, Cargo, MSI, target executable or Windows operation.')
    report.write_text(json.dumps(value,indent=2)+'\n');start=time.monotonic()
    try:
        child=subprocess.run(cmd,capture_output=True,timeout=180);value.update(actualExit=True,exitCode=child.returncode,elapsedSeconds=time.monotonic()-start)
        for n,b in [('stdout',child.stdout),('stderr',child.stderr)]:
            f=D/('actual-checkout-first.'+n+'.log');f.write_bytes(b);value[n]=fact(f)
        need(child.returncode==0,'ACTUAL_CHECKOUT_COMMAND_EXIT0')
        need(git('rev-parse','HEAD',root=WT).decode().strip()==SOURCE,'ACTUAL_CHECKOUT_HEAD')
        sym=subprocess.run(['git','-C',str(WT),'symbolic-ref','-q','HEAD'],capture_output=True,timeout=10);need(sym.returncode==1 and not sym.stdout and not sym.stderr,'DETACHED_HEAD')
        need(git('status','--porcelain','-z','--untracked-files=all',root=WT)==b'','ACTUAL_CHECKOUT_CLEAN')
        selected=[n for n in git('ls-files','-z',root=WT).decode().split('\0') if n and (n.startswith(('crates/','scripts/','web/','.cargo/')) or n in ('Cargo.toml','Cargo.lock'))]
        actual=[]
        for n in selected:
            f=fact(WT/n);need(rows.get(n)==dict(path=n,bytes=f['bytes'],sha256=f['sha256']),'EXACT_RAW_CI_INPUT_'+n);actual.append(f)
        script='scripts/package-msi-candidate.py';blob=git('show','HEAD:'+script,root=WT)
        need(blob==git('show','HEAD:'+script),'UNCHANGED_GIT_BLOB')
        value.update(status='PASS_ACTUAL_CI_CHECKOUT_BYTES_EXACT',checkout=str(WT),detached=True,checkoutClean=True,selectedCount=len(actual),selectedInputs=actual,scriptCheckout=fact(WT/script),scriptGitBlobOidSha1=git('rev-parse','HEAD:'+script,root=WT).decode().strip(),scriptGitBlobContentSha256=digest(blob))
    except Exception as e:value.update(status='FAIL_RETAIN_CHECKOUT_AND_ALL_ORIGINALS',errorKind=type(e).__name__,reason=str(e) if isinstance(e,AssertionError) else 'CHECKOUT_OR_INPUT_CAPTURE_FAILURE')
    report.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps({k:value.get(k) for k in ['status','exitCode','selectedCount','scriptCheckout','scriptGitBlobContentSha256']}));return 0 if value['status']=='PASS_ACTUAL_CI_CHECKOUT_BYTES_EXACT' else 1
if __name__=='__main__':raise SystemExit(main())
