param([switch]$Execute,[string]$ScratchRoot,[string]$ExpectedConfigSha256,[string]$ExpectedInputsManifestSha256)
# Root alone invokes in a fresh PowerShell5.1 x64 process after nonce-owned
# scratch upload. Default performs no file/state/API inspection or compilation.
if(-not $Execute){@{status='PREPARED_NO_EXECUTION';windowsRuntime='NOT_RUN';remaining='Actual pinned config/MSI/upload manifest; root review, compilation and finite observation'}|ConvertTo-Json -Compress;return}
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$whole=[Diagnostics.Stopwatch]::StartNew()
$script:beforeAbsent=$false;$script:installAttempted=$false;$script:formalAttempted=$false
$script:ownerUnknown=$false;$script:instrumentUnknown=$false;$script:gateSnapshot=$null;$script:retireAttempted=$false
$script:retainedClients=[Collections.Generic.List[Diagnostics.Process]]::new()
$script:result=[ordered]@{status='FAIL_NOT_COMPLETE';originalWholeMilliseconds=600000;cleanupReserveMilliseconds=180000;maximumClientPhaseMilliseconds=150000;nativeBrokerOriginalSeconds=120;phases=@();installationScope='Authorized current-user administrator Win11 only; Win7-target binary is not Win7 OS proof';cleanup='NOT_RUN';engineLogSupplement='NOT_IMPLEMENTED_BY_THIS_PREPARATION_UNKNOWN_IS_NOT_EXIT0'}
function Require([bool]$v,[string]$code){if(-not $v){throw $code}}
function Digest([string]$p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function New-Bytes([string]$p,[byte[]]$b){$s=[IO.File]::Open($p,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);try{$s.Write($b,0,$b.Length);$s.Flush()}finally{$s.Dispose()}}
function New-Json([string]$p,$v){New-Bytes $p ([Text.UTF8Encoding]::new($false).GetBytes(($v|ConvertTo-Json -Depth 18)+"`n"))}
function Copy-Fact($v){return (($v|ConvertTo-Json -Depth 18 -Compress)|ConvertFrom-Json)}
function Remaining {return [Math]::Max(0,600000-$whole.ElapsedMilliseconds)}
function Quote([string]$v){Require (-not $v.Contains('"') -and -not $v.EndsWith('\') -and -not $v.Contains("`r") -and -not $v.Contains("`n")) 'CLOSED_ARGUMENT_ENCODING';return '"'+$v+'"'}
function Known-Path([string]$p){
 try{$a=[IO.File]::GetAttributes($p);return @{path=$p;status='KNOWN_PRESENT';directory=(($a-band[IO.FileAttributes]::Directory)-ne 0);reparse=(($a-band[IO.FileAttributes]::ReparsePoint)-ne 0)}}
 catch{$e=$_.Exception;while($null-ne$e.InnerException){$e=$e.InnerException};if($e-is[IO.FileNotFoundException]-or$e-is[IO.DirectoryNotFoundException]){return @{path=$p;status='KNOWN_ABSENT';directory=$false;reparse=$false}};return @{path=$p;status='UNKNOWN';exceptionKind=$e.GetType().FullName;hresult=$e.HResult;directory=$false;reparse=$false}}
}
function Coordination {
 $g=Known-Path $script:gateRoot;$p=Known-Path (Join-Path $script:gateRoot 'pending.v1')
 return @{root=$g;pending=$p;pendingKnownAbsent=($p.status-ceq'KNOWN_ABSENT' -and ($g.status-ceq'KNOWN_ABSENT' -or ($g.status-ceq'KNOWN_PRESENT' -and $g.directory -and -not$g.reparse)));namespaceKnownAbsent=($g.status-ceq'KNOWN_ABSENT');scope='Read-only fixed coordination path; not an owner/lease/settlement capability'}
}
function Measure-State([string]$expected){
 $v=Measure-FcProductState -Config $script:c -Expected $expected
 Require ($null-ne$v -and $v.stateClassification-in@('HEALTHY_PRESENT','KNOWN_ABSENT','UNKNOWN_OR_MISMATCH')) 'TYPED_STATE_RECEIPT'
 return (Copy-Fact $v)
}
function Assert-State($v,[string]$expected){
 if($expected-ceq'Present'){Require ($v.status-ceq'PASS_READONLY_EXPECTED_PRESENT' -and $v.healthyPresent-eq$true -and $v.stateClassification-ceq'HEALTHY_PRESENT') 'EXACT_HEALTHY_PRESENT_REQUIRED'}
 else{Require ($v.status-ceq'PASS_READONLY_EXPECTED_ABSENT' -and $v.knownAbsent-eq$true -and $v.stateClassification-ceq'KNOWN_ABSENT') 'EXACT_KNOWN_ABSENT_REQUIRED'}
}
function Owner-Proof($closed,$live){
 $returnProblems=[Collections.Generic.List[string]]::new();$coverageProblems=[Collections.Generic.List[string]]::new()
 if(-not $closed.WmiStarted -or -not $closed.Closed -or @($closed.Errors).Count-ne0){$returnProblems.Add('OBSERVER_ERROR_OR_NOT_RETURNED')}
 $facts=@($closed.Processes)
 foreach($f in $facts){
  if($f.IdentityStatus-cne'ORIGINAL_QUERY_SYNC_HANDLE_EXACT_IMAGE_BYTES_USER' -or $f.CommandStatus-cne'EXACT_CREATION_MATCHED_WMI_FACT_ONLY' -or $f.Role-ceq'UNKNOWN' -or $f.Sha256-cne$script:c.embeddedHelper.sha256 -or $f.Sid-cne$script:c.expectedUserSid -or $f.ActualWait-ne0 -or $f.ActualExitCode-ne0 -or $f.ExitStatus-cne'ACTUAL_ORIGINAL_GET_EXIT_CODE' -or $f.CloseStatus-cne'CHECKED_CLOSE_SUCCESS'){$returnProblems.Add('CAPTURED_ORIGINAL_UNKNOWN_OR_NONZERO')}
 }
 # Original held broker identity and return are mandatory. A live Wait258 sample
 # is observational only: scheduling cannot invalidate same-handle Wait0/Exit0.
 $brokers=@($facts|Where-Object{$_.Role-ceq'broker'})
 if($brokers.Count-ne1){$returnProblems.Add('ORIGINAL_BROKER_UNKNOWN_OR_NONUNIQUE')}
 foreach($role in @('begin','broker','guardian')){
  $same=@($facts|Where-Object{$_.Role-ceq$role})
  if($same.Count-ne1){$coverageProblems.Add('ROLE_'+$role+'_UNKNOWN_OR_NONUNIQUE');continue}
  $f=$same[0]
  if($role-ceq'broker'){
   if($f.ParentLink-cne'HELD_ORIGINAL_BEGIN_INSTANCE'){$coverageProblems.Add('BROKER_ORIGINAL_BEGIN_LINK_UNKNOWN')}
  }elseif($f.ParentLink-cne'ORIGINAL_ENGINE_INSTANCE_FACT_NOT_SESSION_ID'){$coverageProblems.Add('ROLE_'+$role+'_ENGINE_INSTANCE_UNKNOWN')}
 }
 return @{knownControlsReturned=($returnProblems.Count-eq0);complete=($returnProblems.Count-eq0 -and $coverageProblems.Count-eq0);returnProblems=@($returnProblems.ToArray());coverageProblems=@($coverageProblems.ToArray());brokerEverObservedWait258=($live.Count-gt0);channel='Actual original held process identity/wait/getExit/checkedClose; Wait258 is observation only; missing roles remain UNKNOWN';engineSupplement='UNKNOWN_NOT_IMPLEMENTED'}
}
function Invoke-Phase([string]$name,[ValidateSet('Fresh','Reapply','Uninstall')][string]$kind,[int]$reserve){
 $budget=[int][Math]::Min(150000,[Math]::Max(0,(Remaining)-$reserve))
 Require ($budget-gt0) 'ORIGINAL_WHOLE_AND_CLEANUP_RESERVE_EXHAUSTED'
 $deadline=$whole.ElapsedMilliseconds+$budget
 $row=[ordered]@{name=$name;kind=$kind;startWholeMilliseconds=$whole.ElapsedMilliseconds;phaseDeadlineWholeMilliseconds=$deadline;phaseBudgetMilliseconds=$budget;nativeBrokerOriginalSeconds=120;client=@{started=$false;actualExit=$false;pipesComplete=$false;timedOut=$false;exitCode=$null};ownerProof=@{complete=$false;knownControlsReturned=$false;coverageProblems=@('NOT_CAPTURED');returnProblems=@('NOT_CAPTURED');brokerEverObservedWait258=$false};engineEvidence='UNKNOWN_NO_INDEPENDENT_EXPLICIT_ENGINE_RESULT_PARSER';observations='NOT_COMPLETE'}
 $script:result.phases+=,$row;$script:ownerUnknown=$true
 $observer=$null;$client=$null;$out=$null;$err=$null;$snap=$null;$closed=$null;$live=@{};$lastText=$null
 $snapshotPath=Join-Path $ScratchRoot ($name+'-original-observer.jsonl')
 $snapshotFile=[IO.File]::Open($snapshotPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
 function Save-Snapshot($value){
  # C# Facts refer to live records; serialize immediately, never retain aliases.
  $text=$value|ConvertTo-Json -Depth 18 -Compress
  if($text-cne$script:phaseLastSnapshot){$bytes=[Text.UTF8Encoding]::new($false).GetBytes($text+"`n");Require ($snapshotFile.Length+$bytes.Length-le16777216) 'SNAPSHOT_LOG_BOUND';$snapshotFile.Write($bytes,0,$bytes.Length);$snapshotFile.Flush();$script:phaseLastSnapshot=$text}
  foreach($fact in @($value.Processes)){if($fact.Role-ceq'broker' -and $fact.ActualWait-eq258){$live[([string]$fact.Pid)+':'+([string]$fact.CreationFiletime)]=$true}}
  return ($text|ConvertFrom-Json)
 }
 $script:phaseLastSnapshot=$null
 try{
  $left=[int][Math]::Min(150000,$deadline-$whole.ElapsedMilliseconds);Require ($left-gt0) 'PHASE_EXPIRED_BEFORE_OBSERVER'
  $observer=[FcR76ProcessObserver]::new($script:c.embeddedHelper.sha256,[int]$script:c.embeddedHelper.bytes,$script:c.expectedUserSid,$left)
  $log=Join-Path $ScratchRoot ($name+'-msi.log');Require (-not(Test-Path -LiteralPath $log)) 'EXCLUSIVE_MSI_LOG'
  $tail=' /qn /norestart REBOOT=ReallySuppress MSIRESTARTMANAGERCONTROL=DisableShutdown /L*vx '+(Quote $log)
  $arguments=if($kind-ceq'Uninstall'){'/x '+$script:productArgument+$tail}elseif($kind-ceq'Reapply'){'/i '+(Quote $script:msiPath)+' REINSTALL=ALL REINSTALLMODE=amus'+$tail}else{'/i '+(Quote $script:msiPath)+$tail}
  $client=[Diagnostics.Process]::new();$client.StartInfo.FileName=$script:msiexec;$client.StartInfo.Arguments=$arguments;$client.StartInfo.WorkingDirectory=$ScratchRoot
  $client.StartInfo.UseShellExecute=$false;$client.StartInfo.CreateNoWindow=$true;$client.StartInfo.RedirectStandardInput=$true;$client.StartInfo.RedirectStandardOutput=$true;$client.StartInfo.RedirectStandardError=$true
  $out=[IO.File]::Open((Join-Path $ScratchRoot ($name+'-client.stdout.log')),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
  $err=[IO.File]::Open((Join-Path $ScratchRoot ($name+'-client.stderr.log')),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
  Require ($whole.ElapsedMilliseconds-lt$deadline -and (Remaining)-gt$reserve) 'ORIGINAL_DEADLINE_BEFORE_START'
  if($kind-ceq'Fresh'){$script:installAttempted=$true}
  Require ($client.Start()) 'CLIENT_START_FALSE';$row.client.started=$true;$client.StandardInput.Close()
  $row.client['pid']=$client.Id;$row.client['creationFiletime']=$client.StartTime.ToUniversalTime().ToFileTimeUtc();$row.client['file']=$script:msiexec;$row.client['arguments']=$arguments;$row['rawMsiLog']=$log
  $ot=$client.StandardOutput.BaseStream.CopyToAsync($out);$et=$client.StandardError.BaseStream.CopyToAsync($err)
  while($whole.ElapsedMilliseconds-lt$deadline -and (Remaining)-gt$reserve){
   $snap=Save-Snapshot ($observer.Snapshot())
   $row.client.actualExit=$client.HasExited
   if($row.client.actualExit){$row.client.exitCode=$client.ExitCode;if(@($snap.Processes|Where-Object{$_.Role-ceq'broker'}).Count-eq1 -and @($snap.Processes|Where-Object{$_.ActualWait-ne0}).Count-eq0){break}}
   Start-Sleep -Milliseconds 10
  }
  $row.client.actualExit=$client.HasExited
  if($row.client.actualExit){$row.client.exitCode=$client.ExitCode}else{$row.client.timedOut=$true;$script:retainedClients.Add($client);$client=$null}
  $wait=[int][Math]::Max(0,[Math]::Min(2000,$deadline-$whole.ElapsedMilliseconds))
  $row.client.pipesComplete=[Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($ot,$et),$wait)
 }catch{$row['phaseFailureType']=$_.Exception.GetType().FullName;$row['phaseFailureCode']=$(if($_.Exception.Message-cmatch'^[A-Z0-9_]+$'){$_.Exception.Message}else{'PHASE_NATIVE_OR_CLIENT_ERROR'})}
 finally{
  if($null-ne$observer){try{$closed=Save-Snapshot ($observer.FinishAndClose());$row['observerFinal']=$closed;$row.ownerProof=Owner-Proof $closed $live}catch{$script:instrumentUnknown=$true;$row['observerFinishFailure']='UNKNOWN_ORIGINAL_OBSERVER_RETURN_NO_RETRY'}}
  if($null-ne$client){if(-not$row.client.started){$client.Dispose()}else{try{if(-not $client.HasExited){$script:retainedClients.Add($client);$client=$null}else{$client.Dispose()}}catch{$script:instrumentUnknown=$true;$script:retainedClients.Add($client);$client=$null}}}
  foreach($s in @($out,$err,$snapshotFile)){if($null-ne$s){$s.Dispose()}}
  $row['endWholeMilliseconds']=$whole.ElapsedMilliseconds;$row['snapshotLog']=$snapshotPath
  $script:ownerUnknown=(-not($row.client.started -and $row.client.actualExit -and $row.client.pipesComplete -and -not$row.client.timedOut -and $row.ownerProof.knownControlsReturned))
  New-Json (Join-Path $ScratchRoot ($name+'-phase.json')) $row
 }
 return $row
}
function Require-ReturnedControls($row){Require (-not$script:ownerUnknown -and -not$script:instrumentUnknown -and $row.client.exitCode-eq0) 'PHASE_ORIGINAL_CLIENT_OWNER_RETURN_INCOMPLETE'}
function Require-Phase($row){Require-ReturnedControls $row;Require $row.ownerProof.complete 'PHASE_INDEPENDENT_ROLE_COVERAGE_UNKNOWN'}
function Capture-Gate {
 try{$script:gateSnapshot=[FcR76GateRetirement]::Capture($script:c.expectedUserSid);$script:result['originalGateFacts']=@($script:gateSnapshot.Facts())}
 catch{$script:instrumentUnknown=$true;throw}
}
function Retire-Gate {
 Require (-not$script:ownerUnknown -and -not$script:instrumentUnknown -and $null-ne$script:gateSnapshot -and -not$script:retireAttempted -and (Remaining)-gt0) 'NO_ORIGINAL_GATE_RETIREMENT_AUTHORITY'
 $coord=Coordination;Require $coord.pendingKnownAbsent 'PENDING_NOT_KNOWN_ABSENT'
 $script:retireAttempted=$true
 try{$script:result['gateRetirementNative']=[FcR76GateRetirement]::Retire($script:gateSnapshot)}catch{$script:instrumentUnknown=$true;throw}
 $after=Coordination;$script:result['gateRetirementExternalReadback']=$after
 Require ($after.namespaceKnownAbsent -and $after.pendingKnownAbsent) 'EXTERNAL_GATE_NAMESPACE_ABSENCE_NOT_PROVEN'
}
$ready=$false;$mainSucceeded=$false;$scratchAdmitted=$false
try{
 Require ([Environment]::Is64BitProcess -and $PSVersionTable.PSVersion.Major-eq5 -and $PSVersionTable.PSVersion.Minor-eq1) 'EXPECTED_FRESH_X64_PS51'
 Require ($ExpectedConfigSha256-cmatch'^[0-9a-f]{64}$' -and $ExpectedInputsManifestSha256-cmatch'^[0-9a-f]{64}$') 'EXPLICIT_ROOT_INPUT_HASHES'
 Require ($ScratchRoot-ceq[IO.Path]::GetFullPath($ScratchRoot)) 'EXACT_SCRATCH_PATH'
 $cursor=$ScratchRoot;while($cursor){$fact=Known-Path $cursor;Require ($fact.status-ceq'KNOWN_PRESENT' -and $fact.directory -and -not$fact.reparse) 'SCRATCH_ANCESTOR_UNKNOWN_OR_REPARSE';$cursor=[IO.Path]::GetDirectoryName($cursor)}
 foreach($name in @('.owner','candidate-inputs.json','runtime-inputs.json')){$f=Get-Item -LiteralPath (Join-Path $ScratchRoot $name) -Force;Require (-not$f.PSIsContainer -and -not($f.Attributes-band[IO.FileAttributes]::ReparsePoint)) 'REGULAR_ROOT_METADATA_NO_REPARSE'}
 Require ([IO.File]::ReadAllText((Join-Path $ScratchRoot '.owner'))-ceq"future-classroom-owned-r76-production-msi-runtime/v1`n") 'EXACT_RUNTIME_OWNER'
 $configPath=Join-Path $ScratchRoot 'candidate-inputs.json';$manifestPath=Join-Path $ScratchRoot 'runtime-inputs.json'
 Require ((Digest $configPath)-ceq$ExpectedConfigSha256 -and (Digest $manifestPath)-ceq$ExpectedInputsManifestSha256) 'EXACT_CONFIG_MANIFEST_BYTES'
 $script:c=Get-Content -LiteralPath $configPath -Raw -Encoding UTF8|ConvertFrom-Json
 Require ($script:c.sourceGit-ceq'3bad94949012e840cd1dda6a73a0ea1ddb067697' -and $script:c.target-ceq'i686-win7-windows-msvc' -and $script:c.family-ceq'99378807-098D-5F04-8D4D-F181DFA218D5' -and $script:c.status-ceq'BOUND_PLAN_ONLY_NOT_EXECUTABLE_OR_RUNTIME_PASS') 'CLOSED_SOURCE_TARGET_FAMILY_CONFIG'
 Require ($script:c.runtimeNonce-cmatch'^[0-9a-f]{32}$' -and $script:c.runtimeRootName-ceq('FutureClassroom-r76-production-msi-'+$script:c.runtimeNonce) -and [IO.Path]::GetFileName($ScratchRoot)-ceq$script:c.runtimeRootName) 'EXACT_NONCE_RUNTIME_ROOT'
 Require ($script:c.budget.wholeTestSeconds-eq600 -and $script:c.budget.cleanupReserveSeconds-eq180 -and $script:c.budget.eachMsiClientWaitMaximumSeconds-eq150 -and $script:c.budget.productionBrokerOriginalSeconds-eq120 -and $script:c.budget.noRenewal-eq$true) 'ORIGINAL_BUDGETS_UNCHANGED'
 $who=[Security.Principal.WindowsIdentity]::GetCurrent();try{Require ($who.User.Value-ceq$script:c.expectedUserSid) 'EXACT_CURRENT_USER_SID'}finally{$who.Dispose()}
 $names=@('GateRetirement.cs','ProcessObserver.cs','ReadOnlyPreflightFunction.ps1','ProductState.cs','ProductState.ps1','Invoke-ProductionMsiPhases.ps1','candidate-inputs.json','candidate.msi')
 $manifest=Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8|ConvertFrom-Json
 Require (@($manifest.files).Count-eq$names.Count) 'CLOSED_UPLOADED_DEPENDENCIES'
 $seen=@{};foreach($row in $manifest.files){Require ($row.path-cin$names -and -not$seen.ContainsKey($row.path)) 'EXACT_UPLOAD_FILENAME';$seen[$row.path]=$true;$path=Join-Path $ScratchRoot $row.path;$f=Get-Item -LiteralPath $path -Force;Require (-not$f.PSIsContainer -and -not($f.Attributes-band[IO.FileAttributes]::ReparsePoint) -and $f.Length-eq$row.bytes -and (Digest $path)-ceq$row.sha256) 'EXACT_UPLOADED_FILE_BYTES'}
 Require (@(Get-ChildItem -LiteralPath $ScratchRoot -Force).Count-eq($names.Count+2)) 'FRESH_SCRATCH_NO_UNKNOWN_MEMBER'
 $script:msiPath=Join-Path $ScratchRoot 'candidate.msi';Require ((Digest $script:msiPath)-ceq$script:c.msi.sha256 -and (Get-Item -LiteralPath $script:msiPath).Length-eq$script:c.msi.bytes) 'EXACT_ACTUAL_CANDIDATE_MSI'
 Require ($script:c.productCode-cmatch'^(?:[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}|\{[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\})$') 'CANONICAL_BOUND_PRODUCT_CODE';$script:productArgument='{'+$script:c.productCode.Trim('{}')+'}'
 $local=[Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData);Require (-not[string]::IsNullOrEmpty($local)) 'OS_KNOWN_FOLDER_REQUIRED'
 $script:gateRoot=Join-Path $local ('FutureClassroom-Installer-'+$script:c.family)
 $script:msiexec=Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::Windows)) 'System32\msiexec.exe'
 $scratchAdmitted=$true
 . (Join-Path $ScratchRoot 'ReadOnlyPreflightFunction.ps1')
 . (Join-Path $ScratchRoot 'ProductState.ps1')
 $before=Measure-FcBeforePreflight -Config $script:c;$script:result['before']=$before
 Require ($before.status-ceq'PASS_BEFORE_KNOWN_ABSENCE_ONLY_NOT_EXECUTION_ADMISSION') 'BEFORE_ALL_KNOWN_ABSENT_REQUIRED'
 $script:beforeAbsent=$true;$ready=$true
 # Compilation is confined to the original runner process and fresh owned temp.
 $temp=Join-Path $ScratchRoot 'instrument-temp';[void][IO.Directory]::CreateDirectory($temp);$env:TEMP=$temp;$env:TMP=$temp
 Require ($null-eq('FcR76ProcessObserver'-as[type]) -and $null-eq('FcR76GateRetirement'-as[type])) 'FRESH_INSTRUMENT_TYPES_REQUIRED'
 Add-Type -LiteralPath (Join-Path $ScratchRoot 'ProcessObserver.cs') -ReferencedAssemblies @('System.dll','System.Core.dll','System.Management.dll') -ErrorAction Stop
 Add-Type -LiteralPath (Join-Path $ScratchRoot 'GateRetirement.cs') -ErrorAction Stop
 $initial=Measure-State 'Absent';$script:result['initialProductState']=$initial;Assert-State $initial 'Absent';Require ((Coordination).namespaceKnownAbsent) 'BEFORE_COORDINATION_ABSENT'
 $fresh=Invoke-Phase 'fresh' 'Fresh' 180000;Require-Phase $fresh
 $present=Measure-State 'Present';$script:result['freshPresent']=$present;Assert-State $present 'Present';Require ((Coordination).pendingKnownAbsent) 'FRESH_PENDING_ABSENCE';Capture-Gate
 $reapply=Invoke-Phase 'reapply' 'Reapply' 180000;Require-Phase $reapply
 $present=Measure-State 'Present';$script:result['reapplyPresent']=$present;Assert-State $present 'Present';Require ((Coordination).pendingKnownAbsent) 'REAPPLY_PENDING_ABSENCE'
 $script:formalAttempted=$true;$uninstall=Invoke-Phase 'uninstall' 'Uninstall' 0;Require-Phase $uninstall
 $absent=Measure-State 'Absent';$script:result['uninstallAbsent']=$absent;Assert-State $absent 'Absent';Retire-Gate
 Require ((Remaining)-gt0) 'ORIGINAL_WHOLE_DEADLINE_EXCEEDED';$mainSucceeded=$true;$script:result.status='PASS_THREE_PHASE_HELD_OWNERS_STATE_AND_ORIGINAL_GATE_WIN11_ONLY'
}catch{$script:result['failureType']=$_.Exception.GetType().FullName;$script:result['failureCode']=$(if($_.Exception.Message-cmatch'^[A-Z0-9_]+$'){$_.Exception.Message}else{'CONFIG_NATIVE_STATE_OR_PHASE_ERROR'})}
finally{
 if($ready){
  # A real read is mandatory after failure; elapsed time is still the original
  # whole clock. Expiry never grants a new phase or native owner budget.
  try{$final=Measure-State 'Present';$coord=Coordination;$script:result['finallyProductState']=$final;$script:result['finallyCoordination']=$coord
   if(-not$mainSucceeded -and $script:beforeAbsent -and $script:installAttempted -and -not$script:formalAttempted -and -not$script:ownerUnknown -and -not$script:instrumentUnknown -and $final.healthyPresent-eq$true -and $coord.pendingKnownAbsent -and (Remaining)-gt0){
    if($null-eq$script:gateSnapshot){Capture-Gate}
    $script:formalAttempted=$true;$cleanup=Invoke-Phase 'failure-formal-uninstall' 'Uninstall' 0;Require-ReturnedControls $cleanup
    $after=Measure-State 'Absent';$script:result['failureCleanupAbsent']=$after;Assert-State $after 'Absent'
    if($null-ne$script:gateSnapshot -and -not$script:retireAttempted){Retire-Gate}
    $script:result.cleanup='FORMAL_UNINSTALL_RETURNED_ORIGINAL_FAILURE_RETAINED'
   }elseif($mainSucceeded){Require ($final.knownAbsent-eq$true -and $coord.namespaceKnownAbsent -and $coord.pendingKnownAbsent) 'FINAL_EXTERNAL_ABSENCE_RECHECK';$script:result.cleanup='PASS_FORMAL_UNINSTALL_AND_ORIGINAL_GATE_RETIRED'}else{$script:result.cleanup='RETAIN_FAIL_UNKNOWN_OR_NOT_AUTHORIZED_NO_BLIND_CLEANUP'}
  }catch{$mainSucceeded=$false;$script:result.status='FAIL_FINAL_OBSERVATION_OR_CLEANUP';$script:result['finallyFailureType']=$_.Exception.GetType().FullName;$script:result.cleanup='RETAIN_FAIL_CLEANUP_OR_OBSERVATION_UNKNOWN'}
 }
 $script:result['elapsedWholeMilliseconds']=$whole.ElapsedMilliseconds;$script:result['originalBudgetExceeded']=($whole.ElapsedMilliseconds-ge600000);$script:result['ownerUnknown']=$script:ownerUnknown;$script:result['instrumentUnknown']=$script:instrumentUnknown;$script:result['formalUninstallAttempted']=$script:formalAttempted;$script:result['retainedDirectClients']=$script:retainedClients.Count
 if($scratchAdmitted){
  try{New-Json (Join-Path $ScratchRoot 'phase-runner-result.json') $script:result}catch{$mainSucceeded=$false;$script:result.status='FAIL_FINAL_RECEIPT_WRITE';Write-Output 'FINAL_RECEIPT_WRITE_FAILED_NO_CLEANUP_CLAIM'}
 }
}
$script:result|ConvertTo-Json -Depth 18 -Compress
if(-not$mainSucceeded -or $script:result.originalBudgetExceeded){exit 1};exit 0
