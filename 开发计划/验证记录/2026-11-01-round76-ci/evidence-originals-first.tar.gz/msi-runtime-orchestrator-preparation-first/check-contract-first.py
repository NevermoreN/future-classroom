#!/usr/bin/env python3
"""Finite policy models/source checks, NOT a PowerShell parser or Windows run."""
from pathlib import Path
import json
s=Path(__file__).with_name('Invoke-ProductionMsiPhases.ps1').read_text()
checks=[]
def check(name, value):
    if not value: raise AssertionError(name)
    checks.append(name)
def budget(elapsed,reserve): return min(150000,max(0,600000-elapsed-reserve))
check('fresh-budget-original-150s',budget(0,180000)==150000)
check('late-fresh-keeps-cleanup-reserve',budget(400000,180000)==20000)
check('reserve-exhausted-no-new-phase',budget(420000,180000)==0)
check('cleanup-remaining-only',budget(590000,0)==10000)
check('whole-expired-no-renewal',budget(600001,0)==0)
def proof(facts, observer=True, live=False):
    returned=observer and all(x['identity'] and x['returned'] for x in facts) and sum(x['role']=='broker' for x in facts)==1
    covered=all(sum(x['role']==role for x in facts)==1 for role in ('begin','broker','guardian')) and all(x['parent'] for x in facts)
    return returned,returned and covered
base=[dict(role=x,identity=True,returned=True,parent=True) for x in ('begin','broker','guardian')]
check('original-handle-return-sufficient-without258',proof(base,live=False)==(True,True))
check('258-observation-does-not-change-proof',proof(base,live=False)==proof(base,live=True))
check('no-original-broker-is-not-return-proof',proof([])==(False,False))
missing=[base[1]]
check('missing-roles-remain-unknown-not-main-pass',proof(missing)==(True,False))
check('unknown-return-blocks-cleanup',proof([dict(x,returned=False) if x['role']=='broker' else x for x in base])==(False,False))
check('unknown-image-blocks-cleanup',proof([dict(x,identity=False) if x['role']=='broker' else x for x in base])==(False,False))
def cleanup(before,attempted,healthy,pending_absent,returned,instrument_ok,formal_attempted,remaining):
    return before and attempted and healthy and pending_absent and returned and instrument_ok and not formal_attempted and remaining>0
check('coverage-miss-does-not-forbid-necessary-formal-x',cleanup(True,True,True,True,proof(missing)[0],True,False,10000))
for field in ('before','attempted','healthy','pending_absent','returned','instrument_ok'):
    kw=dict(before=True,attempted=True,healthy=True,pending_absent=True,returned=True,instrument_ok=True,formal_attempted=False,remaining=10000);kw[field]=False
    check('cleanup-refuses-'+field,not cleanup(**kw))
check('formal-x-once',not cleanup(True,True,True,True,True,True,True,10000))
check('no-expired-cleanup',not cleanup(True,True,True,True,True,True,False,0))
check('default-before-any-IO',s.index('if(-not $Execute)')<s.index('Get-FileHash'))
check('one-whole-clock',s.count('[Diagnostics.Stopwatch]::StartNew()')==1)
check('one-fixed-msiexec-start-site',s.count('$client.Start()')==1 and "'System32\\msiexec.exe'" in s)
check('closed-standard-quiet-flags','/qn /norestart REBOOT=ReallySuppress MSIRESTARTMANAGERCONTROL=DisableShutdown /L*vx' in s)
check('explicit-framework-references',"@('System.dll','System.Core.dll','System.Management.dll')" in s)
check('failure-cleanup-return-not-coverage',"'failure-formal-uninstall' 'Uninstall' 0;Require-ReturnedControls $cleanup" in s)
check('main-role-coverage-still-required',"Require $row.ownerProof.complete 'PHASE_INDEPENDENT_ROLE_COVERAGE_UNKNOWN'" in s)
check('no-live258-gate','BROKER_ORIGINAL_LIVE_NOT_OBSERVED' not in s and '$live.ContainsKey' not in s)
check('exact-original-exit-code',"$f.ExitStatus-cne'ACTUAL_ORIGINAL_GET_EXIT_CODE'" in s)
check('original-gate-object-reused','::Retire($script:gateSnapshot)' in s and '$script:retireAttempted=$true' in s)
check('receipt-failure-cannot-pass',"$mainSucceeded=$false;$script:result.status='FAIL_FINAL_RECEIPT_WRITE'" in s)
for forbidden in ('Stop-Process','Remove-Item','taskkill','reg.exe delete','Set-ItemProperty','MsiEndTransaction','MsiJoinTransaction','Start-Service'):
    check('no-'+forbidden,forbidden not in s)
check('engine-log-not-exit-authority',"engineLogSupplement='NOT_IMPLEMENTED_BY_THIS_PREPARATION_UNKNOWN_IS_NOT_EXIT0'" in s)
check('all-upload-8-exact-manifest','@($manifest.files).Count-eq$names.Count' in s and '$names.Count+2' in s)
print(json.dumps(dict(status='PASS_PURE_MODELS_AND_SOURCE_POLICY_ONLY',checks=checks,count=len(checks),powershellParse='NOT_RUN',csharpCompile='NOT_RUN',windows='NOT_RUN'),indent=2))
