R76 explicit owned healthy installation continuation transport — PREPARED, NOT RUN

Default python3 -B run-owned-continuation-first.py performs no connection or input/payload access and prints NOT_RUN.
Root-only actual invocation:
python3 -B /tmp/fc-round76-ci-evidence/production-msi-continuation-transport-preparation-first/run-owned-continuation-first.py \
 --execute \
 --continuation-script /tmp/fc-round76-ci-evidence/owned-msi-continuation-preparation-first/Invoke-OwnedMsiContinuation.ps1 \
 --continuation-script-sha256 9747244e579053115583ff82a10769c4382a8694aed5de9324eced80974cbcb8 \
 --continuation-nonce <root-selected-fresh-32-lowerhex> \
 --report /tmp/fc-round76-ci-evidence/<new-owned-continuation-local-result>/report.json

Fixed original root: C:\Users\Elior\AppData\Local\Temp\FutureClassroom-r76-production-msi-a835c46e54774a709d6696a2f8b4885b.
Original config/first transport/first receipt/MSI identities are hard-pinned. First FAIL stays FAIL; its metadata coverage
is UNKNOWN and is never rewritten from later observations. New independent experiment has600s/eachclient150/native120,
outer900, not a renewal of first clock. Backend script performs exact current healthy+Pending absence+original physical
return recheck before reapply, then formal /x and original gate retirement; no new fresh operation exists here.

Creates only originalRoot\Continuation-<nonce> with exact marker and protected current-user/SYSTEM DACL.
Only8 source/config/first-receipt files plus new manifest are uploaded; child owner makes10 total. No MSI upload.
All original16 root files/directories are rehashed before and after allowing only the new child prefix. Original MSI,
first config/receipt/log/source files are never written. New phase output, logs and original observer streams are fully
inventoried/downloaded with per-file SHA/size/membership and receipt equality. All source/config/first receipts unchanged.
New RUN explicitly resets global LASTEXITCODE and exits with script LASTEXITCODE; first parent0/receiptFAIL history stays.

No remote DELETE code. Original root and continuation child are deliberately retained even on success. Root will merge
all first/new exact inventories and downloaded originals before a separately authorized cleanup. Unknown/live/Pending
or timed-out remote parent are retained, never killed or blindly cleaned. Local timed-out SSH/SCP alone is killed/reaped,
which says nothing about remote completion. Actual parent0 and exact successful child receipt/physical returns/final
product+gate+Pending absence are independent gates. roleCoverage may remain UNKNOWN; full role metadata is not forged.
Scope is only source3bad Win7-target product MSI on authorized current-user Win11, not Win7/10 OS or campus acceptance.
Preparation has AST, local safe default and finite pure source/negative-gate checks only. No Windows/SSH/upload/MSI ran.
