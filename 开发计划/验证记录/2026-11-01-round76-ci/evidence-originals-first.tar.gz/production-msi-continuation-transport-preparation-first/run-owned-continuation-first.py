"""Explicit root-only continuation transport; default does not connect.
Never creates/replaces the original runtime root/MSI, or deletes remote scratch.
"""
from pathlib import Path
import argparse,ast,base64,datetime,hashlib,json,re,shutil,subprocess,time
R=Path('/tmp/fc-round76-ci-evidence');D=Path(__file__).resolve().parent
HOST='elior@192.168.10.212';KEY='/config/.local/share/future-classroom-test-access/win11-192.168.10.212'
SID='S-1-5-21-3896111207-1867804362-1971593122-1001';SOURCE='3bad94949012e840cd1dda6a73a0ea1ddb067697'
OLD_NONCE='a835c46e54774a709d6696a2f8b4885b'
OLD_ROOT=r'C:\Users\Elior\AppData\Local\Temp\FutureClassroom-r76-production-msi-a835c46e54774a709d6696a2f8b4885b'
CONFIG=R/'runtime-config-first/candidate-inputs.json';CONFIG_SHA='c1fb126c13840162f9a980262a7c84889c02df8c3710722f083200c43cd11692'
FIRST_REPORT=R/'product-msi-runtime-first/report.json';FIRST_REPORT_SHA='89a2056df13664771d86113652b2c75566e1752f02ed344501e8c0ae6840f118'
FIRST_RECEIPT=R/'product-msi-runtime-first/download'/('FutureClassroom-r76-production-msi-'+OLD_NONCE)/'phase-runner-result.json';FIRST_RECEIPT_SHA='29d2f37f33c048196d296da11565b53263c5c2cf6489a62f276b70ec695a54ac'
MSI_SHA='bb43f2505c70456ba26cf9a110a12b399008ac6269ea713d43fcc606a9c4521d'
BOOT="$ErrorActionPreference='Stop';[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()))"
COMMON=r'''$ErrorActionPreference='Stop';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Fact($p){$a=[IO.File]::GetAttributes($p);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0 -or ($a-band[IO.FileAttributes]::Directory)-ne0){throw 'REGULAR_NO_REPARSE'};return @{bytes=[long]([IO.FileInfo]::new($p).Length);sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function CheckAcl($root,$marker){$a=[IO.File]::GetAttributes($root);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0 -or ($a-band[IO.FileAttributes]::Directory)-eq0){throw 'ROOT_REPARSE_OR_NOT_DIR'};if([IO.File]::ReadAllText((Join-Path $root '.owner'))-cne$marker){throw 'OWNER_MARKER'};$acl=[IO.Directory]::GetAccessControl($root);if(-not$acl.AreAccessRulesProtected -or $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-cne$c.sid){throw 'EXACT_PROTECTED_OWNER'};$rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));if($rules.Count-ne2 -or @($rules|Where-Object{$_.IdentityReference.Value-notin@($c.sid,'S-1-5-18') -or $_.AccessControlType-ne'Allow' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count){throw 'ONLY_USER_SYSTEM_DACL'}}
function CheckOriginal {$ancestor=[IO.Path]::GetDirectoryName($c.originalRoot);while($ancestor){$attributes=[IO.File]::GetAttributes($ancestor);if(($attributes-band[IO.FileAttributes]::ReparsePoint)-ne0 -or ($attributes-band[IO.FileAttributes]::Directory)-eq0){throw 'ORIGINAL_ANCESTOR_REPARSE'};$ancestor=[IO.Path]::GetDirectoryName($ancestor)};if($c.originalRoot-cne'C:\Users\Elior\AppData\Local\Temp\FutureClassroom-r76-production-msi-a835c46e54774a709d6696a2f8b4885b'){throw 'EXACT_ORIGINAL_ROOT'};CheckAcl $c.originalRoot "future-classroom-owned-r76-production-msi-runtime/v1`n";foreach($entry in @(@{name='candidate.msi';sha=$c.msiSha;bytes=6434304},@{name='candidate-inputs.json';sha=$c.configSha;bytes=$c.configBytes},@{name='phase-runner-result.json';sha=$c.firstReceiptSha;bytes=$c.firstReceiptBytes})){$f=Fact (Join-Path $c.originalRoot $entry.name);if($f.sha256-cne$entry.sha -or $f.bytes-ne$entry.bytes){throw 'ORIGINAL_PIN_CHANGED'}}}
function CheckContinuation {CheckOriginal;if($c.continuationNonce-cnotmatch'^[0-9a-f]{32}$' -or $c.continuationRoot-cne(Join-Path $c.originalRoot ('Continuation-'+$c.continuationNonce))){throw 'EXACT_CONTINUATION_CHILD'};CheckAcl $c.continuationRoot "future-classroom-owned-r76-product-msi-continuation/v1`n"}
function Inventory($root){$files=@();$dirs=@();$q=[Collections.Generic.Queue[string]]::new();$q.Enqueue($root);while($q.Count){$dir=$q.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){$a=[IO.File]::GetAttributes($p);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0){throw 'INVENTORY_REPARSE'};$rel=$p.Substring($root.Length+1).Replace('\','/');if(($a-band[IO.FileAttributes]::Directory)-ne0){$dirs+=$rel;$q.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256}};if($files.Count-gt128 -or $dirs.Count-gt16){throw 'INVENTORY_BOUND'}}};return @{files=$files;directories=$dirs}}
function CompareOriginal($now,$allowChild){$prefix='Continuation-'+$c.continuationNonce;$files=@($now.files|Where-Object{-not($allowChild -and $_.path.StartsWith($prefix+'/',[StringComparison]::Ordinal))});$dirs=@($now.directories|Where-Object{-not($allowChild -and ($_-ceq$prefix -or $_.StartsWith($prefix+'/',[StringComparison]::Ordinal)))});if($files.Count-ne$c.firstInventory.files.Count -or $dirs.Count-ne$c.firstInventory.directories.Count){throw 'ORIGINAL_MEMBERSHIP_CHANGED'};foreach($row in $files){$old=@($c.firstInventory.files|Where-Object{$_.path-ceq$row.path});if($old.Count-ne1 -or $old[0].bytes-ne$row.bytes -or $old[0].sha256-cne$row.sha256){throw 'ORIGINAL_BYTES_CHANGED'}};foreach($dir in $dirs){if($dir-cnotin$c.firstInventory.directories){throw 'ORIGINAL_DIRECTORY_CHANGED'}}}
'''
CREATE=r'''if($PSVersionTable.PSVersion.Major-ne5 -or [IntPtr]::Size-ne8){throw 'DESKTOP_PS51_X64_REQUIRED'};$w=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$w.User;if($sid.Value-cne$c.sid){throw 'EXACT_CURRENT_SID'}}finally{$w.Dispose()};CheckOriginal;$before=Inventory $c.originalRoot;CompareOriginal $before $false
$expected=Join-Path $c.originalRoot ('Continuation-'+$c.continuationNonce);if($c.continuationRoot-cne$expected){throw 'EXACT_NEW_CHILD_PATH'}
try{[void][IO.File]::GetAttributes($expected);throw 'CONTINUATION_ALREADY_EXISTS'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
[void][IO.Directory]::CreateDirectory($expected);$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false);foreach($s in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($s,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))};[IO.Directory]::SetAccessControl($expected,$acl);$owner=Join-Path $expected '.owner';$stream=[IO.File]::Open($owner,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$bytes=[Text.UTF8Encoding]::new($false).GetBytes("future-classroom-owned-r76-product-msi-continuation/v1`n");$stream.Write($bytes,0,$bytes.Length);$stream.Flush($true)}finally{$stream.Dispose()};CheckContinuation
@{status='CREATED_NEW_CONTINUATION_CHILD_ONLY';root=$expected;originalRoot=$c.originalRoot;nonce=$c.continuationNonce;sid=$c.sid;originalInventory=$before}|ConvertTo-Json -Depth 8 -Compress
'''
CAPTURE=r'''CheckContinuation;$original=Inventory $c.originalRoot;CompareOriginal $original $true;$child=Inventory $c.continuationRoot;@{status='ORIGINAL_UNCHANGED_CONTINUATION_INVENTORIED';original=$original;continuation=$child}|ConvertTo-Json -Depth 10 -Compress'''
def need(v,c):
 if not v:raise AssertionError(c)
def sha(b):return hashlib.sha256(b).hexdigest()
def scoped(path):
 p=Path(path);need(p.is_absolute() and p.resolve().is_relative_to(R) and not any(x.is_symlink() for x in [p,*p.parents] if x==R or R in x.parents),'OWNED_REGULAR_PATH_SCOPE');need(p.suffix.lower() not in ('.key','.pfx','.p12'),'PRIVATE_FILE_FORBIDDEN');return p
def fact(path):
 p=scoped(path);need(p.is_file(),'REGULAR_LOCAL_INPUT');b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def validate_inventory(v):
 need(isinstance(v,dict) and isinstance(v.get('files'),list) and isinstance(v.get('directories'),list),'INVENTORY_SHAPE');seen=set()
 for row in v['files']:
  p=row['path'];need(isinstance(p,str) and p and '\\' not in p and ':' not in p and all(x not in ('','.','..') for x in p.split('/')) and p not in seen,'SAFE_UNIQUE_FILE');seen.add(p);need(type(row['bytes']) is int and row['bytes']>=0 and re.fullmatch('[0-9a-f]{64}',row['sha256']),'EXACT_FILE_IDENTITY')
 need(len(v['files'])<=128 and len(v['directories'])<=16 and len(set(v['directories']))==len(v['directories']),'INVENTORY_BOUNDS')
 for p in v['directories']:need(isinstance(p,str) and p and '\\' not in p and ':' not in p and all(x not in ('','.','..') for x in p.split('/')) and p not in seen,'SAFE_DIRECTORY')
def verify_download(root,inventory):
 validate_inventory(inventory);files={};dirs=set()
 for p in root.rglob('*'):
  need(not p.is_symlink(),'LOCAL_CAPTURE_NO_SYMLINK');rel=p.relative_to(root).as_posix()
  if p.is_dir():dirs.add(rel)
  else:f=fact(p);files[rel]=dict(path=rel,bytes=f['bytes'],sha256=f['sha256'])
 need(files=={r['path']:r for r in inventory['files']} and dirs==set(inventory['directories']),'DOWNLOADED_EXACT_EVERY_ORIGINAL_BYTE_AND_MEMBERSHIP')
def remote(script,c):
 feed=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+COMMON+script).encode();command=['ssh','-i',KEY,'-o','BatchMode=yes','-o','ConnectTimeout=8',HOST,'powershell.exe','-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-EncodedCommand',base64.b64encode(BOOT.encode('utf-16-le')).decode()];return command,feed
def inventory_equal(first,second):
 validate_inventory(first);validate_inventory(second)
 return {r['path']:r for r in first['files']}=={r['path']:r for r in second['files']} and set(first['directories'])==set(second['directories'])
def phase_admission(value):
 if not isinstance(value,dict):return False
 phases=value.get('phases')
 return (value.get('status')=='PASS_OWNED_HEALTHY_REAPPLY_FORMAL_UNINSTALL_GATE_ABSENT_WIN11_ONLY'
  and value.get('cleanup')=='PASS_FORMAL_UNINSTALL_AND_ORIGINAL_GATE_RETIRED'
  and value.get('ownerUnknown') is False and value.get('instrumentUnknown') is False
  and value.get('retainedDirectClients')==0 and value.get('formalUninstallAttempted') is True
  and value.get('originalBudgetExceeded') is False
  and value.get('finallyProductState',{}).get('knownAbsent') is True
  and value.get('finallyCoordination',{}).get('namespaceKnownAbsent') is True
  and value.get('finallyCoordination',{}).get('pendingKnownAbsent') is True
  and isinstance(value.get('originalGateFacts'),list) and len(value['originalGateFacts'])>0
  and 'gateRetirementNative' in value
  and isinstance(phases,list) and [r.get('name') for r in phases]==['reapply','uninstall']
  and all(r.get('client',{}).get('started') is True and r.get('client',{}).get('actualExit') is True
   and r.get('client',{}).get('pipesComplete') is True and r.get('client',{}).get('timedOut') is False
   and r.get('client',{}).get('exitCode')==0 and r.get('ownerProof',{}).get('knownControlsReturned') is True for r in phases))
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--continuation-script',type=Path);p.add_argument('--continuation-script-sha256');p.add_argument('--continuation-nonce');p.add_argument('--report',type=Path);a=p.parse_args()
 if not a.execute:print(json.dumps(dict(status='PREPARED_OWNED_CONTINUATION_TRANSPORT_NOT_RUN',windows='NOT_RUN',msi='NOT_RUN',originalFirstResult='FAIL_REMAINS_UNCHANGED')));return 0
 need((R/'.owner').read_bytes()==b'future-classroom-owned-r76-ci-evidence/v1\n' and (D/'.owner').read_bytes()==b'future-classroom-owned-r76-product-msi-continuation-transport-preparation/v1\n','EXACT_OWNERS')
 need(a.continuation_script and re.fullmatch('[0-9a-f]{64}',a.continuation_script_sha256 or '') and re.fullmatch('[0-9a-f]{32}',a.continuation_nonce or '') and a.report,'EXPLICIT_FROZEN_SCRIPT_NONCE_NEW_REPORT');need(a.continuation_script.name=='Invoke-OwnedMsiContinuation.ps1' and a.continuation_nonce!=OLD_NONCE,'EXACT_SCRIPT_BASENAME_AND_FRESH_NONCE')
 cfg=fact(CONFIG);first_fact=fact(FIRST_REPORT);receipt_fact=fact(FIRST_RECEIPT);need((cfg['sha256'],first_fact['sha256'],receipt_fact['sha256'])==(CONFIG_SHA,FIRST_REPORT_SHA,FIRST_RECEIPT_SHA),'EXACT_ORIGINAL_CONFIG_REPORT_RECEIPT')
 plan=json.loads(CONFIG.read_text());first=json.loads(FIRST_REPORT.read_text());receipt=json.loads(FIRST_RECEIPT.read_text());need(first['status']=='FAIL_PRODUCT_PHASE_OR_COVERAGE_RETAINED' and receipt==first['phaseResult'] and first['downloadVerified']=='EXACT_EACH_REMOTE_FILE_SIZE_SHA_AND_MEMBERSHIP','FIRST_FAIL_AND_EXACT_ORIGINAL_CAPTURE_PRESERVED');need(plan['sourceGit']==SOURCE and plan['expectedUserSid']==SID and plan['runtimeNonce']==OLD_NONCE and plan['msi']['sha256']==MSI_SHA and plan['msi']['bytes']==6434304,'EXACT_ORIGINAL_CANDIDATE');need(plan['budget']==dict(wholeTestSeconds=600,cleanupReserveSeconds=180,eachMsiClientWaitMaximumSeconds=150,productionBrokerOriginalSeconds=120,noRenewal=True),'ORIGINAL_UNCHANGED_BUDGET')
 oldinventory=first['remoteInventory'];validate_inventory(oldinventory);need(next(r for r in oldinventory['files'] if r['path']=='phase-runner-result.json')['sha256']==FIRST_RECEIPT_SHA,'FIRST_RECEIPT_ORIGINAL_INVENTORY')
 sources=[]
 for name in ('ProcessObserver.cs','GateRetirement.cs','ProductState.cs','ProductState.ps1'):
  row=next(x for x in first['sourceInputs'] if Path(x['path']).name==name);need(fact(row['path'])==row,'EXACT_ORIGINAL_ACCEPTED_INSTRUMENT_SOURCE');sources.append(Path(row['path']))
 script_fact=fact(a.continuation_script);need(script_fact['sha256']==a.continuation_script_sha256=='9747244e579053115583ff82a10769c4382a8694aed5de9324eced80974cbcb8','EXACT_ROOT_REVIEWED_CONTINUATION_SCRIPT_SHA');sources.append(a.continuation_script);source_facts=[fact(x) for x in sources]
 report=scoped(a.report);out=report.parent;need(out.parent==R and not out.exists() and report.name.endswith('.json'),'NEW_LOCAL_RESULT_ROOT');out.mkdir();(out/'.owner').write_text('future-classroom-owned-r76-owned-continuation-transport-result/v1\n');upload=out/'upload';upload.mkdir()
 for path in sources:shutil.copyfile(path,upload/path.name)
 for path,name in [(CONFIG,'candidate-inputs.json'),(FIRST_RECEIPT,'first-phase-runner-result.json'),(FIRST_REPORT,'first-transport-report.json')]:shutil.copyfile(path,upload/name)
 members=[dict(path=x.name,bytes=fact(x)['bytes'],sha256=fact(x)['sha256']) for x in sorted(upload.iterdir())];need(len(members)==8 and all(x['path']!='candidate.msi' for x in members),'EIGHT_CONTINUATION_UPLOADS_NO_MSI');manifest=upload/'continuation-inputs.json';manifest.write_text(json.dumps(dict(files=members),indent=2)+'\n');manifest_fact=fact(manifest)
 c=dict(originalRoot=OLD_ROOT,continuationRoot=OLD_ROOT+'\\Continuation-'+a.continuation_nonce,continuationNonce=a.continuation_nonce,sid=SID,msiSha=MSI_SHA,configSha=CONFIG_SHA,configBytes=cfg['bytes'],firstReceiptSha=FIRST_RECEIPT_SHA,firstReceiptBytes=receipt_fact['bytes'],firstInventory=oldinventory)
 result=dict(status='RUNNING',sourceSha=SOURCE,scope='Explicit new finite continuation of exact retained healthy owned product on Win11; first result remains FAIL. Not a new fresh experiment or Win7 OS proof.',originalFirstReport=first_fact,originalFirstReceipt=receipt_fact,config=cfg,sourceInputs=source_facts,originalRoot=OLD_ROOT,continuationRoot=c['continuationRoot'],continuationNonce=a.continuation_nonce,manifest=manifest_fact,originalOuterSeconds=900,newContinuationSeconds=600,msiClientMaximumSeconds=150,nativeBrokerOriginalSeconds=120,originalFirstClock='NOT_RENEWED_FIRST_FAIL_RETAINED',operations=[],scratchCleanup='NOT_PERFORMED_ROOT_WILL_MERGE_EXACT_ORIGINALS',startedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat());start=time.monotonic();created=False;returned=False;phase=None;download_ok=False
 def save():report.write_text(json.dumps(result,indent=2)+'\n')
 def call(name,command,feed=None,limit=15):
  remaining=900-(time.monotonic()-start);need(remaining>0,'OUTER_BUDGET_EXHAUSTED');began=time.monotonic();code=None;timed=False;child=None;stdout=b'';stderr=b''
  try:
   child=subprocess.Popen(command,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   try:stdout,stderr=child.communicate(feed,timeout=min(limit,remaining))
   except subprocess.TimeoutExpired:timed=True;child.kill();stdout,stderr=child.communicate()
   except BaseException:
    if child.poll() is None:child.kill()
    stdout,stderr=child.communicate();code=child.returncode;raise
   code=child.returncode
  finally:
   row=dict(name=name,command=command,pid=child.pid if child else None,actualExit=code is not None,exitCode=code,timedOut=timed,reaped=bool(child and child.poll() is not None),elapsedSeconds=time.monotonic()-began)
   if feed is not None:row['stdin']=dict(bytes=len(feed),sha256=sha(feed))
   for label,data in [('stdout',stdout),('stderr',stderr)]:path=out/(name+'.'+label+'.log');path.write_bytes(data);row[label]=fact(path)
   result['operations'].append(row);save()
  return code,stdout,not timed and code is not None
 save()
 try:
  command,feed=remote(CREATE,c);code,stdout,natural=call('01-validate-original-create-continuation-child',command,feed,20);need(natural and code==0,'CONTINUATION_CREATE_ACTUAL_EXIT0');before=json.loads(stdout);need(before['status']=='CREATED_NEW_CONTINUATION_CHILD_ONLY' and before['root']==c['continuationRoot'] and before['originalRoot']==OLD_ROOT and before['sid']==SID and before['nonce']==a.continuation_nonce and inventory_equal(before['originalInventory'],oldinventory),'EXACT_OLD_ORIGINALS_AND_NEW_OWNED_CHILD');created=True;result['beforeCreate']=before
  command=['scp','-q','-i',KEY,'-o','BatchMode=yes','-o','ConnectTimeout=8',*[str(x) for x in sorted(upload.iterdir())],HOST+':'+c['continuationRoot'].replace('\\','/')+'/'];code,_,natural=call('02-upload-new-continuation-sources-only',command,limit=60);need(natural and code==0,'CONTINUATION_UPLOAD_ACTUAL_EXIT0')
  run="CheckContinuation;$global:LASTEXITCODE=0;& (Join-Path $c.continuationRoot 'Invoke-OwnedMsiContinuation.ps1') -Execute -OriginalScratchRoot $c.originalRoot -ContinuationRoot $c.continuationRoot -ExpectedConfigSha256 '"+CONFIG_SHA+"' -ExpectedFirstReceiptSha256 '"+FIRST_RECEIPT_SHA+"' -ExpectedFirstReportSha256 '"+FIRST_REPORT_SHA+"' -ExpectedInputsManifestSha256 '"+manifest_fact['sha256']+"';exit $LASTEXITCODE"
  command,feed=remote(run,c);code,stdout,natural=call('03-new-continuation-parent-explicit-exit',command,feed,620);returned=natural;need(natural and code in (0,1),'CONTINUATION_PARENT_UNKNOWN_OR_ABNORMAL');phase=json.loads(stdout);result.update(phaseResult=phase,phaseParentExit=code);result['status']='PASS_CONTINUATION_PENDING_EXACT_CAPTURE' if code==0 and phase_admission(phase) else 'FAIL_CONTINUATION_PHASE_OR_CAPTURE_RETAINED'
 except Exception as error:result.update(status='FAIL_CONTINUATION_TRANSPORT_OR_PHASE',errorType=type(error).__name__,reason=str(error) if isinstance(error,AssertionError) else 'LOCAL_TRANSPORT_OR_CAPTURE_ERROR')
 finally:
  if created and returned:
   try:
    command,feed=remote(CAPTURE,c);code,stdout,natural=call('90-original-unchanged-and-child-inventory',command,feed,20);need(natural and code==0,'EXACT_ORIGINAL_AND_CHILD_INVENTORY_EXIT0');capture=json.loads(stdout);need(capture['status']=='ORIGINAL_UNCHANGED_CONTINUATION_INVENTORIED','ORIGINAL_INVENTORY_STATUS');inventory=capture['continuation'];validate_inventory(inventory);result['remoteInventory']=capture
    local=out/'download';local.mkdir();command=['scp','-q','-r','-i',KEY,'-o','BatchMode=yes','-o','ConnectTimeout=8',HOST+':'+c['continuationRoot'].replace('\\','/'),str(local)+'/'];code,_,natural=call('91-download-all-continuation-originals',command,limit=60);need(natural and code==0,'CONTINUATION_ORIGINAL_DOWNLOAD_EXIT0');download=local/('Continuation-'+a.continuation_nonce);verify_download(download,inventory);have={x['path']:x for x in inventory['files']}
    for row in members+[dict(path='continuation-inputs.json',bytes=manifest_fact['bytes'],sha256=manifest_fact['sha256'])]:need(have.get(row['path'])==row,'UPLOADED_ORIGINALS_UNCHANGED')
    stored=json.loads((download/'continuation-runner-result.json').read_text());need(stored==phase,'DOWNLOADED_RECEIPT_EQUALS_ORIGINAL_STDOUT');download_ok=True;result['downloadVerified']='EXACT_EACH_NEW_ORIGINAL_FILE_BYTES_SHA_AND_MEMBERSHIP';result['originalFirstFilesUnchanged']=True
   except Exception as error:result.update(status='FAIL_CONTINUATION_CAPTURE_OR_IDENTITY_RETAINED',captureErrorType=type(error).__name__,captureErrorCode=str(error) if isinstance(error,AssertionError) else 'LOCAL_CAPTURE_ERROR')
  elif created:result['remoteParentState']='UNKNOWN_RETAIN_ALL_NO_QUERY_OR_DELETE'
  try:need(source_facts==[fact(x) for x in sources] and cfg==fact(CONFIG) and first_fact==fact(FIRST_REPORT) and receipt_fact==fact(FIRST_RECEIPT),'ALL_ORIGINAL_LOCAL_INPUTS_UNCHANGED');result['localSourceUnchanged']=True
  except Exception:result['localSourceUnchanged']=False;result['status']='FAIL_LOCAL_SOURCE_CHANGE'
  result.update(elapsedSeconds=time.monotonic()-start,controllerReturned=True,completedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
  if result['status']=='PASS_CONTINUATION_PENDING_EXACT_CAPTURE' and download_ok and result['localSourceUnchanged'] and result['elapsedSeconds']<900:result['status']='PASS_OWNED_CONTINUATION_PARENT_AND_EXACT_CAPTURE_WIN11_SCRATCH_RETAINED'
  elif result['status']=='PASS_CONTINUATION_PENDING_EXACT_CAPTURE':result['status']='FAIL_CONTINUATION_CAPTURE_INCOMPLETE'
  save()
 print(json.dumps(dict(status=result['status'],scratchCleanup=result['scratchCleanup'],report=fact(report))));return 0 if result['status']=='PASS_OWNED_CONTINUATION_PARENT_AND_EXACT_CAPTURE_WIN11_SCRATCH_RETAINED' else 1
if __name__=='__main__':raise SystemExit(main())
