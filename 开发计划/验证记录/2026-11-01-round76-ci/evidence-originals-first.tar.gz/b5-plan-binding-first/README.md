Executable local B5 candidate config binder only; no Windows mode.

Root runs python3 -B prepare-production-msi-b5-first.py with:
 --builder-script /tmp/fc-round76-ci-evidence/b5-cargo-package-id-preparation-first/scripts/package-msi-candidate.py
 --builder-script-sha256 8ca2f818b481f5cd4a2c9fd4cee4f4d282c505f4f3ccb45ec28b0dc719757378
 --builder-freeze /tmp/fc-round76-ci-evidence/b5-cargo-package-id-preparation-first/b5-implementation-freeze-first.json
 --builder-freeze-sha256 1b615dde2d168892cd992054b14787e46399fd4d8f385fac4235ba811deb684d
 --checkout-proof /tmp/fc-round76-ci-evidence/msi-checkout-preparation-first/actual-checkout-first.json
 --checkout-proof-sha256 <actualSHA>
 --packaging-report /tmp/fc-round76-ci-evidence/msi-candidate-win7-first/report.json
 --packaging-report-sha256 263e5be79bea4e0316f2f7181a71e988aa430ed441d0b28408d46ebdd0f4baef
 --build-evidence /tmp/fc-round76-ci-evidence/metadata-ci-namespace-first
 --normal-helper /tmp/fc-round76-ci-evidence/metadata-ci-namespace-first/product/fc-bootstrap/fc-installer-lifecycle.exe
 --normal-helper-sha256 a01e5eb72667a398771640928d21b2ae6d97a9a9555f657aa5867f00d1b39d3d
 --runtime-nonce <root fresh32lowerhex>
 --expected-user-sid S-1-5-21-3896111207-1867804362-1971593122-1001
 --output-dir <new ownedR76 child>

Only local file/hash/Git readonly checks occur until the final exclusive creation of candidate-inputs.json and its .owner. --describe reads no supplied inputs and creates no config. --check-only verifies all actual supplied inputs but creates no config and needs no runtime nonce/SID/output. Root chooses and runs actual invocation; preparation here ran only AST/pure argv/describe. Existing proofs, source checkout, builder, actual CI and package original bytes are not changed.

The binder keeps new B5 builder file SHA+freeze and all changed/copied import bytes distinct from original3bad compile input checkout. It freshly requires detached clean original HEAD, exact complete selected path set and each raw542 input identity, oldB4 raw abc207... script and LF Gitblob d0fbb23... separately. It configures the explicitly supplied B5 module's public source-root API, revalidates actual local ZIP+manifest/legal/Web and reruns complete normal/metadata/Cargo/PE admission using the exact10 original namespace. The full normal provenance must equal the actual package report. It also checks exact MSI bytes, actual authoring hash, full embedded helper bytes/normal prefix, manifest hash, closed overlay/parser/records, every extracted payload with no aliases/extras, sourceZIP plus fixed note equality, deterministic Product/family/Component IDs. Static PASS remains NOT_VALIDATED/NOT_GRANTED/NOT_RUN. No MSI tools, app/helper or Windows endpoint is invoked.

Schema retains status BOUND_PLAN_ONLY_NOT_EXECUTABLE_OR_RUNTIME_PASS and all original phase-runner fields. Important actual producer shape correction: report.authoring.product_code is canonical bare UUID36; it is strictly checked against deterministic B5 product_code. candidate-inputs.productCode is canonical Windows API {UUID38}, and packagingProductCode records the original bare UUID separately. Marker component_guid strings remain the original bare36 values and are not changed. Windows COM/native calls and formal/x consume productCode with braces. Builder provenance and original compile/source provenance are extra fields, not permission or runtime receipts. Budget remains new experiment600s/cleanup180s/client150s/native original120s/no renewal.
