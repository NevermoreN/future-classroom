#!/usr/bin/env python3
"""Bind the actual B5-produced MSI and old compiled-source checkout. No Windows execution."""
import argparse,hashlib,json,re,runpy,stat,struct,subprocess
from pathlib import Path
from types import SimpleNamespace
R=Path('/tmp/fc-round76-ci-evidence')
MAIN=Path('/workspace/共享/Eliora/未来教室计划')
SOURCE='3bad94949012e840cd1dda6a73a0ea1ddb067697'
TARGET='i686-win7-windows-msvc'
FAMILY='99378807-098D-5F04-8D4D-F181DFA218D5'
OLD_BLOB_SHA='d0fbb23a5dab2d3329e935110265609ea53674b31896102d1139e21cee193059'
UUID=r'[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}'
def need(v,message):
    if not v:raise ValueError(message)
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p,limit=40*1024*1024):
    p=Path(p);need(p.is_absolute() and p.resolve().is_relative_to(R),'R76 owned input')
    need(not any(q.is_symlink() for q in [p,*p.parents] if q==R or R in q.parents),'No aliased input')
    need(stat.S_ISREG(p.lstat().st_mode) and p.stat().st_size<=limit and p.suffix.lower() not in {'.key','.pfx','.p12'},'Bounded nonprivate regular input')
    return p.read_bytes()
def fact(p):
    b=read(p);return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def pinned(p,digest):
    need(isinstance(digest,str) and re.fullmatch('[0-9a-f]{64}',digest),'Explicit SHA256')
    f=fact(p);need(f['sha256']==digest,'Exact explicit SHA256');return f
def git(root,*args):return subprocess.check_output(['git','-C',str(root),'-c','core.autocrlf=true',*args],timeout=30)
def phase_commands(product):
    shared=['/qn','/norestart','REBOOT=ReallySuppress','MSIRESTARTMANAGERCONTROL=DisableShutdown']
    msi='<exact new owned runtimeRoot>\\candidate.msi';logs='<exact new owned runtimeRoot>'
    return {'fresh':['/i',msi,*shared,'/L*vx',logs+'\\fresh.log'],'healthyReapply':['/i',msi,*shared,'REINSTALL=ALL','REINSTALLMODE=amus','/L*vx',logs+'\\healthy-reapply.log'],'formalUninstall':['/x',product,*shared,'/L*vx',logs+'\\uninstall.log']}
def bind_inputs(a):
    need((R/'.owner').read_bytes()==b'future-classroom-owned-r76-ci-evidence/v1\n','Exact R76 owner')
    report_fact=pinned(a.packaging_report,a.packaging_report_sha256);report=json.loads(read(a.packaging_report))
    builder_fact=pinned(a.builder_script,a.builder_script_sha256);freeze_fact=pinned(a.builder_freeze,a.builder_freeze_sha256);freeze=json.loads(read(a.builder_freeze))
    need(freeze['status']=='FROZEN_B5_CANDIDATE_PURE_AND_ACTUAL_READONLY_ADMISSION_PASS_NOT_MSI_OR_RUNTIME' and freeze['originalPeSourceSha']==SOURCE,'Exact B5 frozen candidate scope')
    need(builder_fact in freeze['changedSources'],'Builder is exact B5 changed source')
    for row in freeze['changedSources']+freeze['unchangedIsolatedAuxiliaryCopies']:need(fact(Path(row['path']))==row,'Frozen B5 source/import closure unchanged')
    need(report['script_sha256']==builder_fact['sha256'] and report['builder_source']['script_path']==builder_fact['path'] and report['builder_source']['script_sha256']==builder_fact['sha256'],'New B5 builder bytes distinct from old CI source script')
    proof_fact=pinned(a.checkout_proof,a.checkout_proof_sha256);proof=json.loads(read(a.checkout_proof))
    need(proof['status']=='PASS_ACTUAL_CI_CHECKOUT_BYTES_EXACT' and proof['sourceSha']==SOURCE and proof['detached'] is True and proof['checkoutClean'] is True,'Original exact detached CI checkout proof')
    checkout=Path(proof['checkout']);read(checkout/'Cargo.toml')
    need(git(checkout,'rev-parse','HEAD').decode().strip()==SOURCE and git(checkout,'status','--porcelain','-z','--untracked-files=all')==b'','Original source checkout remains exact clean HEAD')
    symbolic=subprocess.run(['git','-C',str(checkout),'symbolic-ref','-q','HEAD'],capture_output=True,timeout=10)
    need(symbolic.returncode==1 and not symbolic.stdout and not symbolic.stderr,'Actual detached HEAD')
    selected=[s for s in git(checkout,'ls-files','-z').decode().split('\0') if s and (s.startswith(('crates/','scripts/','web/','.cargo/')) or s in ('Cargo.toml','Cargo.lock'))]
    rows=proof['selectedInputs'];need(len(rows)==proof['selectedCount']==len(selected) and len({r['path'] for r in rows})==len(rows),'Complete selected original source domain')
    need({r['path'] for r in rows}=={str(checkout/s) for s in selected},'No source omission or namespace substitution')
    for row in rows:need(fact(Path(row['path']))==row,'All original raw CI checkout bytes unchanged')
    old_script=checkout/'scripts/package-msi-candidate.py';need(proof['scriptCheckout']==fact(old_script),'Old raw B4 script identity retained separately')
    old_blob=git(checkout,'show','HEAD:scripts/package-msi-candidate.py')
    need(sha(old_blob)==OLD_BLOB_SHA==proof['scriptGitBlobContentSha256'] and old_blob==git(MAIN,'show',SOURCE+':scripts/package-msi-candidate.py'),'Separate original LF committed B4 blob')
    need(report['source_checkout']=={'path':str(checkout),'head':SOURCE,'original_ci_inputs_verified':len(rows)},'Report original compiled-source checkout identity')
    need(report['status']=='PASS' and report['target']==TARGET and report['installation']=='NOT_RUN' and report['candidate_status']=='NOT_VALIDATED' and report['readiness']=='NOT_GRANTED','Actual B5 static report is not runtime readiness')
    need(report['payload_extraction']=='EXACT_BYTES_MATCH' and report['msi_lifecycle_binary_readback']=='EXACT_NORMAL_PREFIX_AND_CLOSED_OVERLAY_BYTES_MATCH' and report['msi_contract']['status']=='PASS','Original complete payload/Binary/table readbacks')
    base=a.packaging_report.parent;msi_path=base/report['msi']['path'];msi=read(msi_path)
    need(len(msi)==report['msi']['size'] and sha(msi)==report['msi']['sha256'],'Actual final MSI exact bytes')
    embedded_path=base/report['lifecycle_binary']['path'];embedded=read(embedded_path);normal_fact=pinned(a.normal_helper,a.normal_helper_sha256);normal=read(a.normal_helper)
    helper=report['lifecycle_binary'];need(helper['bytes']==len(embedded) and helper['sha256']==sha(embedded) and helper['normal_prefix_bytes']==len(normal) and helper['normal_prefix_sha256']==sha(normal) and embedded[:len(normal)]==normal,'Whole original normal prefix plus closed overlay')
    module=runpy.run_path(str(a.builder_script));module['configure_source_root'](checkout)
    module['pe_header'](normal)
    zip_path=Path(report['source_zip']['path']);zip_bytes=read(zip_path,module['MAX_ZIP'])
    need(len(zip_bytes)==report['source_zip']['size'] and sha(zip_bytes)==report['source_zip']['sha256'],'Actual local probe ZIP exact bytes')
    manifest,source_payloads=module['validate_zip'](zip_bytes);need(manifest==report['source_manifest'],'Actual original manifest exact value')
    args=SimpleNamespace(build_evidence=a.build_evidence,build_result_sha256=report['normal_helper_provenance']['result_sha256'],lifecycle_helper=a.normal_helper,lifecycle_helper_sha256=a.normal_helper_sha256)
    original,provenance=module['admit_normal_helper'](args,source_payloads,manifest['version'])
    need(original==normal and provenance==report['normal_helper_provenance'] and provenance['source_sha']==SOURCE and provenance['current_inputs_verified']==len(rows),'Actual same Win7 source/metadata/normal Cargo admission unchanged')
    prefix,decoded=module['parse_lifecycle_image'](embedded)
    need(1<=len(report['payloads'])<=72 and len({r['path'] for r in report['payloads']})==len(report['payloads']),'Closed payload records')
    expected={r['path']:{'bytes':r['size'],'sha256':r['sha256'],'component_guid':r['component_guid']} for r in report['payloads']}
    need(prefix==normal and decoded==expected and helper['records']==len(expected),'Full closed overlay independent parse')
    n=struct.unpack_from('<I',embedded,len(embedded)-20)[0];need(sha(embedded[-20-n:-20])==helper['manifest_sha256'],'Overlay manifest exact hash')
    payload_root=base/'payload';disk={}
    for p in payload_root.rglob('*'):
        need(not p.is_symlink(),'No extracted aliases')
        if p.is_dir():continue
        disk[p.relative_to(payload_root).as_posix()]=read(p,module['MAX_INSTALLED'])
    source_payloads['MSI-CANDIDATE.txt']=read(checkout/'packaging/MSI-CANDIDATE.md',65536)
    need(disk==source_payloads and set(disk)==set(expected),'Every extracted payload exactly the local ZIP plus fixed candidate note')
    for name,data in disk.items():
        row=expected[name];need(len(data)==row['bytes'] and sha(data)==row['sha256'] and row['component_guid']==module['component_code'](name),'Payload bytes and exact deterministic components')
    product=report['authoring']['product_code'];need(re.fullmatch(UUID,product) and product==module['product_code'](manifest['version']) and report['authoring']['upgrade_code']==FAMILY,'Original canonical product/family binding')
    author=base/report['authoring']['path'];need(sha(read(author))==report['authoring']['sha256'],'Actual reviewed authoring bytes')
    for row in freeze['changedSources']+freeze['unchangedIsolatedAuxiliaryCopies']:need(fact(Path(row['path']))==row,'Builder unchanged after read-only validation')
    for row in rows:need(fact(Path(row['path']))==row,'Raw original source unchanged after binding')
    return dict(report=report,packagingReport=report_fact,builderScript=builder_fact,builderFreeze=freeze_fact,sourceCheckoutProof=proof_fact,sourcePackagerCheckout=fact(old_script),sourcePackagerGitBlobContentSha256=OLD_BLOB_SHA,normalHelper=normal_fact,embeddedHelper=fact(embedded_path),msi=fact(msi_path),sourceGit=SOURCE,sourceRoot=str(checkout),sourceSelectedCount=len(rows),packagingProductCode=product,productCode='{'+product+'}',version=manifest['version'],payloads=report['payloads'],normalHelperProvenance=provenance)
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--describe',action='store_true');p.add_argument('--check-only',action='store_true')
    for n in ('packaging-report','builder-script','builder-freeze','checkout-proof','normal-helper','build-evidence','output-dir'):p.add_argument('--'+n,type=Path)
    for n in ('packaging-report-sha256','builder-script-sha256','builder-freeze-sha256','checkout-proof-sha256','normal-helper-sha256','runtime-nonce','expected-user-sid'):p.add_argument('--'+n)
    a=p.parse_args()
    if a.describe:
        print(json.dumps({'status':'PREPARED_B5_LOCAL_CONFIG_BINDER_ONLY','sourceGit':SOURCE,'target':TARGET,'builder':'Explicit B5 script+freeze, distinct from original old CI B4 script','runtime':'NOT_RUN','hasWindowsExecuteMode':False,'productCodeFormat':'Windows API canonical braces, original packaging UUID separately retained'}));return
    for n in ('packaging_report','builder_script','builder_freeze','checkout_proof','normal_helper','build_evidence'):need(getattr(a,n) is not None,'Explicit '+n)
    bound=bind_inputs(a)
    if a.check_only:
        print(json.dumps({'status':'PASS_LOCAL_CANDIDATE_BYTES_BOUND_RUNTIME_NOT_RUN','msi':bound['msi'],'builderScript':bound['builderScript'],'sourceRoot':bound['sourceRoot'],'sourceSelectedCount':bound['sourceSelectedCount'],'productCode':bound['productCode'],'noConfigurationCreated':True}));return
    need(re.fullmatch('[0-9a-f]{32}',a.runtime_nonce or '') and re.fullmatch(r'S-1-5-21-(?:[0-9]+-){2}[0-9]+-[0-9]+',a.expected_user_sid or ''),'Explicit fresh nonce/current Windows user SID')
    out=a.output_dir;need(out is not None and out.is_absolute() and out.resolve().is_relative_to(R) and out.parent.is_dir() and not out.exists(),'New owned R76 output')
    need(not any(q.is_symlink() for q in [out.parent,*out.parents] if q==R or R in q.parents),'No aliased output ancestor')
    config={k:v for k,v in bound.items() if k!='report'}
    config.update(status='BOUND_PLAN_ONLY_NOT_EXECUTABLE_OR_RUNTIME_PASS',target=TARGET,runtimeOS='Win11/current authorized administrator user only',expectedUserSid=a.expected_user_sid,runtimeNonce=a.runtime_nonce,runtimeRootName='FutureClassroom-r76-production-msi-'+a.runtime_nonce,family=FAMILY,fixedDestinationKnownFolderSuffix=['Programs','FutureClassroom'],coordinationKnownFolderLeaf='FutureClassroom-Installer-'+FAMILY,registryMarkerKey=r'Software\FutureClassroom\Installer\Components',runKey=r'Software\Microsoft\Windows\CurrentVersion\Run',runValue='FutureClassroom',registryView='Registry32',budget={'wholeTestSeconds':600,'cleanupReserveSeconds':180,'eachMsiClientWaitMaximumSeconds':150,'productionBrokerOriginalSeconds':120,'noRenewal':True},phaseCommands=phase_commands(bound['productCode']),beforeGuard='Measure-FcBeforePreflight must report exact known absence; product native admission remains independent',remainingExecutionDependencies=['Root actual before/SCM/SSH/foreground audit and exact original process/effects/Pending proof','Test-only original gate retirement only after complete formal uninstall and owner return'],hasExecuteMode=False)
    out.mkdir();(out/'.owner').write_text('future-classroom-owned-r76-production-msi-bound-plan/v1\n')
    dest=out/'candidate-inputs.json'
    with dest.open('x') as f:json.dump(config,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({'status':config['status'],'plan':fact(dest),'productCode':config['productCode'],'packagingProductCode':config['packagingProductCode'],'runtime':'NOT_RUN'}))
if __name__=='__main__':main()
