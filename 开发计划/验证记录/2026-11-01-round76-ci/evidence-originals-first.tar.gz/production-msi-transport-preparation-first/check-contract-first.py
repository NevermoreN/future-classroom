"""Finite transport-policy models and source/default checks; no connection."""
from pathlib import Path
import ast,sys,json,tempfile,contextlib,io
p=Path(__file__).with_name('run-production-msi-first.py');s=p.read_text();ast.parse(s)
ns={'__name__':'finite_contract_only'};exec(compile(s,str(p),'exec'),ns)
checks=[]
def ck(name,v):
 if not v:raise AssertionError(name)
 checks.append(name)
ns['subprocess'].Popen=lambda *a,**kw:(_ for _ in ()).throw(AssertionError('NO_SUBPROCESS_DURING_PURE_CHECK'))
old=sys.argv;sys.argv=[str(p)]
try:
 out=io.StringIO()
 with contextlib.redirect_stdout(out):code=ns['main']()
 ck('default-no-network-no-input-inspection',code==0 and json.loads(out.getvalue())['status']=='PREPARED_PRODUCT_TRANSPORT_NOT_RUN')
finally:sys.argv=old
admit=ns['phase_cleanup_admission']
ck('missing-phase-result-retains',admit(None)=='RETAIN_UNKNOWN')
ck('missing-phase-list-retains',admit({})=='RETAIN_UNKNOWN')
ck('explicit-never-started-phase-only-scratch',admit({'phases':[{'client':{'started':False}}]})=='NO_MSI_CLIENT_STARTED_PARENT_RETURNED_ONLY')
ck('unknown-start-retains',admit({'phases':[{'client':{}}]})=='RETAIN_UNKNOWN')
ck('started-product-not-pass-retains',admit({'phases':[{'client':{'started':True}}]})=='RETAIN_UNKNOWN')
base={'status':'PASS_THREE_PHASE_HELD_OWNERS_STATE_AND_ORIGINAL_GATE_WIN11_ONLY','cleanup':'PASS_FORMAL_UNINSTALL_AND_ORIGINAL_GATE_RETIRED','ownerUnknown':False,'instrumentUnknown':False,'retainedDirectClients':0,'formalUninstallAttempted':True,'originalBudgetExceeded':False,'finallyProductState':{'knownAbsent':True},'finallyCoordination':{'namespaceKnownAbsent':True,'pendingKnownAbsent':True},'phases':[{'client':{'started':True,'actualExit':True,'pipesComplete':True,'exitCode':0},'ownerProof':{'complete':True}} for _ in range(3)]}
ck('complete-exact-pass-admission',admit(base)=='COMPLETE_PHASE_PASS_ONLY')
for name,change in [('owner-live',{'ownerUnknown':True}),('instrument-unknown',{'instrumentUnknown':True}),('retained-client',{'retainedDirectClients':1}),('no-formal-x',{'formalUninstallAttempted':False}),('budget-exceeded',{'originalBudgetExceeded':True}),('pending-unknown',{'finallyCoordination':{'namespaceKnownAbsent':True,'pendingKnownAbsent':False}}),('product-not-absent',{'finallyProductState':{'knownAbsent':False}})]:
 ck('refuse-'+name,admit(dict(base,**change))=='RETAIN_UNKNOWN')
v={'files':[{'path':'sample.txt','bytes':1,'sha256':ns['sha'](b'x')}],'directories':['empty']}
with tempfile.TemporaryDirectory(dir=p.parent,prefix='owned-contract-') as t:
 q=Path(t);(q/'sample.txt').write_bytes(b'x');(q/'empty').mkdir();ns['verify_download'](q,v);ck('download-exact-files-sha-membership',True)
 (q/'sample.txt').write_bytes(b'y')
 try:ns['verify_download'](q,v);bad=False
 except AssertionError:bad=True
 ck('reject-download-byte-change',bad)
for path in ('../escape','a/../b','C:/outside','/absolute','back\\slash',''):
 try:ns['validate_inventory']({'files':[dict(v['files'][0],path=path)],'directories':[]});bad=False
 except AssertionError:bad=True
 ck('reject-unsafe-inventory-'+repr(path),bad)
ck('fixed-eight-upload-files',len(ns['FILES'])==6 and "len(members)==8" in s)
ck('binary-scp-not-msi-base64',"shutil.copyfile(msi,upload/'candidate.msi')" in s and s.count('base64.b64encode')==1)
ck('before-precedes-create',ns['CREATE'].index('Measure-FcBeforePreflight')<ns['CREATE'].index('CreateDirectory'))
ck('actual-user-not-overwritten',"$c.sid=$sid.Value" not in ns['CREATE'] and 'EXACT_CURRENT_USER_SID' in ns['CREATE'])
ck('protected-user-system-scratch','SetAccessRuleProtection($true,$false)' in ns['CREATE'])
ck('post-parent-only-capture','if created and run_returned:' in s)
ck('no-auto-retry','retry' not in s.lower())
ck('outer-original-900',"remaining=900-(time.monotonic()-start)" in s)
ck('run620-create15-upload60-cleanup20',"feed,620" in s and "feed,15" in s and "limit=60" in s and "feed,20" in s)
ck('phase-original600-native120',"wholeTestSeconds=600" in s and "productionBrokerOriginalSeconds=120" in s)
ck('never-reads-private-key',ns['KEY'] not in [str(x) for x in ns['FILES']] and 'read_bytes(KEY)' not in s)
print(json.dumps({'status':'PASS_PURE_MODELS_SOURCE_DEFAULT_ONLY','count':len(checks),'checks':checks,'network':'NOT_RUN','windows':'NOT_RUN','msi':'NOT_RUN'},indent=2))
