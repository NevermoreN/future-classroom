# R76 root-only product MSI transport preparation

This code is prepared only. It has not connected to Windows, uploaded files, installed MSI, or modified main. Actual instrument-third compilation/parse/idle-WMI and actual product-package/static results belong to root's separate evidence, not this preparation's pure checks.

```bash
python3 /tmp/fc-round76-ci-evidence/production-msi-transport-preparation-first/run-production-msi-first.py
# No execute: no config read, subprocess, network or Windows state access.

# Only root, after reviewing actual B5 config and current authorized Windows:
python3 /tmp/fc-round76-ci-evidence/production-msi-transport-preparation-first/run-production-msi-first.py \
  --config /tmp/fc-round76-ci-evidence/<root-created-config>/candidate-inputs.json \
  --config-sha256 <actual-64-lowerhex> \
  --report /tmp/fc-round76-ci-evidence/<fresh-direct-child>/report.json \
  --execute
```

The report parent must be a fresh direct R76 child; no overwrite/resume/automatic retry is supported. Root chooses a fresh config nonce. The fixed actual SID is `S-1-5-21-3896111207-1867804362-1971593122-1001`, source is `3bad94949012e840cd1dda6a73a0ea1ddb067697`, target is `i686-win7-windows-msvc`. Config schema is the native B5 binder's `BOUND_PLAN_ONLY_NOT_EXECUTABLE_OR_RUNTIME_PASS`, including `msi {path,bytes,sha256}`, `embeddedHelper`, payloads, fixed family, and original budgets. The B5 binder separately authenticates all actual packaging inputs; outer config SHA is root's explicit acceptance, never a newly invented packaging producer. Product code remains its canonical braced value and no operation mode boolean is added.

Six frozen scripts/sources are pinned in order: first Native observer/gate/preflight, third UI ProductState C#/same PS module, first overall phase runner. Config and actual MSI make eight upload files. The new local upload directory preserves MSI bytes with ordinary binary `copyfile` and binary scp; MSI is never Base64 or JSON. `runtime-inputs.json` lists precisely those eight path/size/SHA members, excludes itself, and is CLI-pinned into the remote runner. Remote `.owner` makes ten initial members.

SSH uses the existing authorized test identity path with normal `ssh -i`; its contents are not read or hashed. The fresh PowerShell5.1 bootstrap receives UTF8 source over stdin. Before any scratch creation/upload, embedded frozen `Measure-FcBeforePreflight` executes the actual full absent guard using the bound config. Current SID must equal the known SID. Only then is `FutureClassroom-r76-production-msi-<nonce>` created under actual remote TEMP with protected exact user+SYSTEM full-control DACL and marker `future-classroom-owned-r76-production-msi-runtime/v1\n`. All ancestor/reparse checks, inventories and exact deletion derive from root's actual third warmup pattern with explicit product prefix/marker changes.

One original outer clock is 900 seconds. Create<=15s, upload<=60s, original phase-parent<=620s, combined capture/download<=60s, deletion<=20s, each further shortened by remaining original outer time. The phase runner's original600s, reserve180s, phase150s, and native broker120s are not modified. Every actual Popen records argv, PID, stdin byte count/SHA, raw stdout/stderr files, actual exit, elapsed time, timeout and reaped status. A local ssh/scp timeout is reaped locally and leaves remote state UNKNOWN; it does not kill a Windows process or permit cleanup. Original MSI phase failure remains FAIL, never retried or replaced by successful cleanup.

Only after the original phase SSH parent naturally returns is a fresh nonfollowing exact inventory obtained. scp recursively copies that exact owned root to a fresh local capture. Every file's actual size/SHA and exact directory/file membership must match; all nine original uploaded members must still match, and downloaded `phase-runner-result.json` must equal original stdout's typed receipt. Compiler temp files already automatically gone before this new inventory are not fabricated as missing originals. Later transient differences cause retention, not relaxed comparison.

Automatic scratch deletion requires either complete three-phase PASS with formal uninstall/gate external absence, original owners returned, zero retained clients and no instrumentation/budget fault; or an explicit returned phase receipt proving no MSI client ever started. The latter permits only scratch cleanup and preserves overall failure. Any installed/live/Pending/unknown/incomplete owner or native state leaves the remote scratch for root. Deletion rechecks exact owner/DACL/current inventory against the already downloaded original bytes, deletes regular files/directories nonrecursively in bounded known order, and verifies exact root absent. It never deletes product files, MSI cache/registration, gate/Pending, Run values or services; it never starts the application or touches school data/foreground. Full local binary copies must be retained for diagnosis and later excluded from source archival by root's binary policy.

`check-contract-first.py` is pure policy/model/default/source verification only. Actual root review, config binding, before guard, SCP/SSH transfer, three-phase MSI runtime and final independent baseline checks remain required. Transport failure before a typed receipt or any capture discrepancy fails closed and reports retained state; no script claims an unobserved process has returned.
