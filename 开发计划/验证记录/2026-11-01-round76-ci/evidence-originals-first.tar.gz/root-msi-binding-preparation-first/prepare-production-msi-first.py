#!/usr/bin/env python3
"""Bind a future accepted production MSI into a bounded PLAN ONLY; no execution."""
import argparse,hashlib,json,re,runpy,stat,struct
from pathlib import Path
MAIN=Path('/workspace/共享/Eliora/未来教室计划')
ROUND=Path('/tmp/fc-round76-ci-evidence')
SOURCE='3bad94949012e840cd1dda6a73a0ea1ddb067697'
TARGET='i686-win7-windows-msvc'
FAMILY='99378807-098D-5F04-8D4D-F181DFA218D5'
def need(v,c):
    if not v:raise ValueError(c)
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p,n=40*1024*1024):
    p=Path(p);need(p.is_absolute() and p.resolve().is_relative_to(ROUND) and stat.S_ISREG(p.lstat().st_mode) and p.stat().st_size<=n,'bounded R76 regular input')
    need(not any(x.is_symlink() for x in [p,*p.parents] if x==ROUND or ROUND in x.parents) and p.suffix.lower() not in {'.key','.pfx','.p12'},'nonlink nonprivate inputs');return p.read_bytes()
def fact(p):
    b=read(p);return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def pe_gui_win7(b):
    need(len(b)>=64 and b[:2]==b'MZ','PE image');p=struct.unpack_from('<I',b,60)[0]
    need(p+120<=len(b) and b[p:p+4]==b'PE\0\0' and struct.unpack_from('<H',b,p+4)[0]==0x14c and struct.unpack_from('<H',b,p+24)[0]==0x10b,'I386 PE32')
    need(struct.unpack_from('<H',b,p+92)[0]==2 and struct.unpack_from('<HH',b,p+72)==(6,1),'normal GUI2 subsystemVersion6.1')
def command_plan(product,remote_msi,remote_logs):
    shared=['/qn','/norestart','REBOOT=ReallySuppress','MSIRESTARTMANAGERCONTROL=DisableShutdown']
    return {'fresh':['/i',remote_msi,*shared,'/L*vx',remote_logs+'\\fresh.log'],
            'healthyReapply':['/i',remote_msi,*shared,'REINSTALL=ALL','REINSTALLMODE=amus','/L*vx',remote_logs+'\\healthy-reapply.log'],
            'formalUninstall':['/x',product,*shared,'/L*vx',remote_logs+'\\uninstall.log']}
def admit(report,normal,msi,embedded,packager_sha):
    need(report['status']=='PASS' and report['target']==TARGET and report['installation']=='NOT_RUN' and report['readiness']=='NOT_GRANTED' and report['candidate_status']=='NOT_VALIDATED','actual packager PASS remains runtime NOT_RUN')
    need(report['script_sha256']==packager_sha and report['normal_helper_provenance']['source_sha']==SOURCE and report['normal_helper_provenance']['profile_test'] is False,'same exact source/current packager/non-test normal helper')
    need(report['payload_extraction']=='EXACT_BYTES_MATCH' and report['msi_lifecycle_binary_readback']=='EXACT_NORMAL_PREFIX_AND_CLOSED_OVERLAY_BYTES_MATCH','actual closed table/Binary/payload readbacks')
    need(report['msi']['size']==len(msi) and report['msi']['sha256']==sha(msi),'final MSI exact bytes')
    helper=report['lifecycle_binary'];need(helper['bytes']==len(embedded) and helper['sha256']==sha(embedded) and helper['normal_prefix_bytes']==len(normal) and helper['normal_prefix_sha256']==sha(normal) and embedded[:len(normal)]==normal,'embedded original normal PE prefix/overlay exact identity')
    need(report['normal_helper_provenance']['normal_helper_sha256']==sha(normal),'normal helper provenance exact bytes');pe_gui_win7(normal)
    need(report['authoring']['upgrade_code']==FAMILY and re.fullmatch(r'\{[0-9A-F-]{36}\}',report['authoring']['product_code']),'fixed family/exact product GUID')
    need(1<=len(report['payloads'])<=72 and len({r['path'] for r in report['payloads']})==len(report['payloads']),'closed bounded payload records')
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--describe',action='store_true')
    p.add_argument('--checkout-proof',type=Path);p.add_argument('--checkout-proof-sha256');p.add_argument('--packager-script-sha256');p.add_argument('--packaging-report',type=Path);p.add_argument('--packaging-report-sha256');p.add_argument('--normal-helper',type=Path);p.add_argument('--normal-helper-sha256');p.add_argument('--runtime-nonce');p.add_argument('--expected-user-sid');p.add_argument('--output-dir',type=Path)
    a=p.parse_args()
    if a.describe:
        print(json.dumps({'status':'PREPARED_PLAN_ONLY_MISSING_ACTUAL_ACCEPTED_WIN7_MSVC_ARTIFACT','sourceGit':SOURCE,'target':TARGET,'runtimeOS':'authorized current administrator account Win11 ONLY','hasExecuteMode':False,'normalRustHelperRuntime':'NOT_RUN','productMSIMaintenance':'NOT_RUN','remaining':['Actual accepted same-source Win7 MSVC CI ZIP/result+two profile.test=false GUI binaries','Root-admitted real final product MSI/closed table extraction report','Original helper/broker process lifetime instrumentation and exact gate-retirement review before commit']}));return
    for v in [a.packaging_report_sha256,a.normal_helper_sha256]:need(isinstance(v,str) and re.fullmatch('[0-9a-f]{64}',v),'explicit input SHA256')
    need(a.packaging_report and a.normal_helper and a.output_dir and re.fullmatch('[0-9a-f]{32}',a.runtime_nonce or '') and re.fullmatch(r'S-1-5-21-(?:[0-9]+-){2}[0-9]+-[0-9]+',a.expected_user_sid or ''),'actual report/helper + explicit nonce/user SID/new output')
    need((ROUND/'.owner').read_bytes()==b'future-classroom-owned-r76-ci-evidence/v1\n','exact R76 owner marker')
    raw=read(a.packaging_report,4*1024*1024);normal=read(a.normal_helper);need(sha(raw)==a.packaging_report_sha256 and sha(normal)==a.normal_helper_sha256,'explicit report/normal helper hashes')
    report=json.loads(raw);base=a.packaging_report.parent;msi_path=base/report['msi']['path'];embedded_path=base/report['lifecycle_binary']['path'];msi=read(msi_path);embedded=read(embedded_path)
    need(a.checkout_proof and re.fullmatch('[0-9a-f]{64}',a.checkout_proof_sha256 or '') and re.fullmatch('[0-9a-f]{64}',a.packager_script_sha256 or ''),'explicit actual checkout/script proof')
    proof_raw=read(a.checkout_proof);need(sha(proof_raw)==a.checkout_proof_sha256,'exact actual checkout proof SHA')
    proof=json.loads(proof_raw);need(proof['status']=='PASS_ACTUAL_CI_CHECKOUT_BYTES_EXACT' and proof['sourceSha']==SOURCE and proof['detached'] is True and proof['checkoutClean'] is True,'actual same-source detached checkout proof')
    checkout=ROUND/'msi-checkout-preparation-first/checkout-3bad949-first';script=checkout/'scripts/package-msi-candidate.py'
    need(proof['checkout']==str(checkout) and proof['scriptCheckout']==fact(script) and proof['scriptCheckout']['sha256']==a.packager_script_sha256,'exact raw CI-matching checkout script')
    need(proof['scriptGitBlobContentSha256']==sha(subprocess.check_output(['git','-C',str(MAIN),'show',SOURCE+':scripts/package-msi-candidate.py'],timeout=10)),'raw checkout versus committed blob identities separate')
    need(subprocess.check_output(['git','-C',str(checkout),'rev-parse','HEAD'],timeout=10).decode().strip()==SOURCE and subprocess.check_output(['git','-C',str(checkout),'-c','core.autocrlf=true','status','--porcelain','-z','--untracked-files=all'],timeout=30)==b'','same committed clean source at binding')
    for row in proof['selectedInputs']:need(fact(Path(row['path']))==row,'all original CI checkout input bytes unchanged at binding')
    module=runpy.run_path(str(script));admit(report,normal,msi,embedded,a.packager_script_sha256)
    prefix,decoded=module['parse_lifecycle_image'](embedded);expected={r['path']:{'bytes':r['size'],'sha256':r['sha256'],'component_guid':r['component_guid']} for r in report['payloads']}
    need(prefix==normal and decoded==expected,'current closed overlay parser/payload+component exact agreement')
    need(report['authoring']['product_code']==module['product_code'](report['source_manifest']['version']),'closed deterministic product/version')
    for row in report['payloads']:
        b=read(base/'payload'/row['path']);need(len(b)==row['size'] and sha(b)==row['sha256'] and row['component_guid']==module['component_code'](row['path']),'each actual extracted payload/component exact bytes')
    output=a.output_dir;need(output.is_absolute() and output.resolve().is_relative_to(ROUND) and output.parent.is_dir() and not output.exists(),'new owned R76 plan directory')
    config={'status':'BOUND_PLAN_ONLY_NOT_EXECUTABLE_OR_RUNTIME_PASS','sourceGit':SOURCE,'target':TARGET,'runtimeOS':'Win11/current authorized administrator user only','expectedUserSid':a.expected_user_sid,'runtimeNonce':a.runtime_nonce,'runtimeRootName':'FutureClassroom-r76-production-msi-'+a.runtime_nonce,'family':FAMILY,'productCode':report['authoring']['product_code'],'version':report['source_manifest']['version'],'fixedDestinationKnownFolderSuffix':['Programs','FutureClassroom'],'coordinationKnownFolderLeaf':'FutureClassroom-Installer-'+FAMILY,'registryMarkerKey':r'Software\FutureClassroom\Installer\Components','runKey':r'Software\Microsoft\Windows\CurrentVersion\Run','runValue':'FutureClassroom','registryView':'Registry32','payloads':report['payloads'],'sourceCheckoutProof':fact(a.checkout_proof),'sourcePackagerCheckout':fact(script),'sourcePackagerGitBlobContentSha256':proof['scriptGitBlobContentSha256'],'packagingReport':fact(a.packaging_report),'normalHelper':fact(a.normal_helper),'embeddedHelper':fact(embedded_path),'msi':fact(msi_path),'budget':{'wholeTestSeconds':600,'cleanupReserveSeconds':180,'eachMsiClientWaitMaximumSeconds':150,'productionBrokerOriginalSeconds':120,'noRenewal':True},'phaseCommands':command_plan(report['authoring']['product_code'],'<exact new owned runtimeRoot>\\candidate.msi','<exact new owned runtimeRoot>'),'beforeGuard':'ReadOnlyPreflight.ps1 must report exact known absence before any actual product mutation','remainingExecutionDependencies':['Root reviews original helper/broker capture and Pending/gate proof protocol','Root accepts exact test-owned gate retirement or records this as known remaining cleanup limitation','Actual final Windows/source/SCM baseline and all explicit input hashes reviewed'],'hasExecuteMode':False}
    output.mkdir();(output/'.owner').write_text('future-classroom-owned-r76-production-msi-bound-plan/v1\n');dest=output/'candidate-inputs.json'
    with dest.open('x') as f:json.dump(config,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps({'status':config['status'],'plan':fact(dest),'productCode':config['productCode']}))
if __name__=='__main__':main()
