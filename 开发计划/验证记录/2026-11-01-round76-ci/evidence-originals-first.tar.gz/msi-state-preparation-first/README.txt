R76 independent read-only MSI poststate preparation — NOT COMPILED / NOT RUN

Files: ProductState.ps1 (dot-source defines function only), ProductState.cs (test instrument).
Root overall wrapper must pin both file SHA identities before invoking. Use a fresh authorized PowerShell5.1 process;
set its TEMP/TMP to an owned test temp root before Add-Type, which may compile ordinary transient .NET artifacts.
Only the explicit Measure call loads/compiles the C# source; this preparation did not run any compiler or Windows call.

 . <owned path>\ProductState.ps1
 $observation=Measure-FcProductState -Config $c -Expected Present   # after fresh or healthy reapply
 $observation | ConvertTo-Json -Depth 24 -Compress
 $observation=Measure-FcProductState -Config $c -Expected Absent    # after formal /x

$c is the exact SHA-pinned candidate-inputs.json from production-msi-preparation-first/prepare-production-msi.py.
All root/source/family/registry/path/typed payload/SID checks must succeed before any product-state read. Expected is
only a comparison label, never permission. Returned flags cannot grant MSI authority, owner release or Settlement.
Module does not inspect Pending/gate and never cleans anything. Root must independently FinishAndClose its observer
and prove original process ownership/termination before using any poststate result. All original pins close finally
before return. HealthyPresent alone must never authorize cleanup, uninstall or transaction settlement.

Return shape (one JSON-serializable dictionary):
 status: PASS_READONLY_EXPECTED_PRESENT | PASS_READONLY_EXPECTED_ABSENT | FAIL_READONLY_POSTSTATE |
         FAIL_CONFIG_OR_INSTRUMENTATION
 expected, sourceGit, currentUserSid (only if observed), healthyPresent, knownAbsent, matchesExpected,
 stateClassification: HEALTHY_PRESENT | KNOWN_ABSENT | UNKNOWN_OR_MISMATCH
 observations: files, markers, registration, components, run (independent per-phase records)
 phaseErrors: phase/exceptionType/hresult/win32Error/code/actual/partialObservation, as available
 mutations:false, coordinationGate:NOT_MEASURED_BY_THIS_MODULE
 runAbsent (only after actual observation aggregation); false/unknown must not become absence.
Invalid config/label or compilation failure returns a typed failure rather than exiting or discarding raw observations.
ExpectedPresent also calculates knownAbsent, useful for observing a failure; mixed/unknown states remain UNKNOWN.

Read-only contracts:
* Current WindowsIdentity SID must exactly equal expectedUserSid. Fixed source3bad, family99378807... and Win7-target
  candidate schema; duplicate/case-aliased/illegal paths/components, nonnumeric sizes, invalid hashes and overbounds
  are rejected. At most72 payloads/30MiB, including all9 required manifest files.
* OS LocalApplicationData/Programs/FutureClassroom only. Pin each ancestor and each allowed directory with
  OPEN_EXISTING + OPEN_REPARSE_POINT and no DELETE sharing; reject reparses. Do not enumerate ancestor contents.
  Bounded FindFirst/Next traverses only expected directories. Unknown names are listed without reading contents.
  Actual files require linkCount1/size/SHA; original read handles deny WRITE/DELETE sharing and remain pinned through
  all checks. Recheck directory snapshots/file identity/link counts. Internal verbatim Win32 boundary supports long
  local paths; no caller-supplied destination/UNC/ADS. This is a finite observation, not atomic registry/FS CAS.
* HKCU Registry32 fixed Components key: exact GUID value-name set, DWORD1, no subkeys. Unknown value contents unread.
  Fixed Run value FutureClassroom queried for existence/type/size via RegQueryValueExW with null data buffer; no other
  startup names/contents enumerated, no write/deletion. Key absent or query ERROR_FILE_NOT_FOUND proves this value
  absent; any other native error is recorded and cannot pass absence.
* MsiEnumProductsExW is the actual native ProductsEx API (not COM scalar.Count). Exact product filter, actual SID for
  user contexts3, explicit native NULL for machine context4. Max8 rows per context; record each actual return/context/
  SID/count. VersionString queried with actual context/SID (machine NULL); require one USERUNMANAGED context2,
  expected SID/version, ProductState DEFAULT5 for Present. RelatedProducts exact fixed family must return only this
  product. End259 or first UNKNOWN_PRODUCT1605 only where documented by existing source no_product gate; errors
  or truncated buffers fail. This does not enumerate other-user products/cache.
* Each exact component: MsiGetComponentPathExW(product,{component},actualSID,context2), bounded1024 WCHAR; require
  INSTALLSTATE_LOCAL3 and exact case-insensitive 01:\Software\FutureClassroom\Installer\Components\GUID.
  After /x require UNKNOWN-1 with no returned path, exact product/related absence, marker key and payload tree absence.
* All buffers fixed39/256/1024 WCHAR; no unbounded retry. Actual return/state/length values retained even on mismatch.
  Registry handles/WindowsIdentity use Dispose; file pins close finally; FindClose is checked. No COM objects used.

Existing local first-party API contracts reviewed: prepare-production-msi.py, native/broker/effects.rs (same component
HKCU32 keypath01/LOCAL3/current-user registration contract), broker/manifest.rs. References to expected native ABI
are static preparation only, not new Windows API/actual MSI success. Root must compile and observe actual receipts.
No Windows/PowerShell AST host or C# compiler was available locally. Seven source policy/lexical checks are recorded;
none is presented as compiler, runtime, fresh install, healthy reapply, uninstall, Win7OS or Win10OS PASS.
