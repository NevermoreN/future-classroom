"""Prepared same-source Win7-target B4 packager. No --execute means no build.
Requires root's actual accepted static artifact report and original CI namespace.
A Windows 7 target artifact is not evidence of Windows 7 OS execution.
"""
from pathlib import Path
import argparse, hashlib, json, os, re, runpy, signal, stat, subprocess, sys, time
sys.dont_write_bytecode=True
R=Path('/tmp/fc-round76-ci-evidence');D=R/'msi-tools-preparation-first';T=R/'tools'
MAIN=Path('/workspace/共享/Eliora/未来教室计划');SCRIPT=MAIN/'scripts/package-msi-candidate.py'
SOURCE='3bad94949012e840cd1dda6a73a0ea1ddb067697';RUN=41315385139
SCRIPT_SHA='d0fbb23a5dab2d3329e935110265609ea53674b31896102d1139e21cee193059'
MSIBUILD_SHA='87ee3aa0af25bb997646071a45e35ebae3e3ba5f26fe7b479df97aa31bd8a1eb'

def need(v,c):
    if not v:raise AssertionError(c)
def sha(b):return hashlib.sha256(b).hexdigest()
def owned(p):
    p=Path(p);need(p.is_absolute() and p.resolve().is_relative_to(R) and not any(x.is_symlink() for x in [p,*p.parents] if x==R or R in x.parents),'OWNED_R76_INPUT');return p

def fact(p):
    need(stat.S_ISREG(p.lstat().st_mode) and p.suffix.lower() not in {'.key','.pfx','.p12'},'REGULAR_NONPRIVATE_INPUT');b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def pinned(p,digest):
    f=fact(p);need(re.fullmatch('[0-9a-f]{64}',digest) and f['sha256']==digest,'EXACT_INPUT_SHA');return f

def accepted_gate(report,source):
    need(report.get('schema')=='future-classroom.ci-independent-artifact/v2' and report.get('status')=='PASS_STATIC_ONLY_RUNTIME_NOT_RUN','ACTUAL_ACCEPTED_STATIC_REPORT')
    need(report.get('sourceSha')==source==SOURCE and report.get('baseline')=='Win7' and report.get('runId')==RUN,'SAME_ACTUAL_WIN7_SOURCE_RUN')
    need(report.get('helperUnchanged') is True and report.get('artifactIntegrity')=='PASS_WHOLE_ZIP_CRC_AND_COMPLETE_PRODUCER_LEDGER','WHOLE_ORIGINAL_ARTIFACT_ACCEPTED')
    for key,target in [('normalExecutable','fc-bootstrap'),('lifecycleExecutable','fc-installer-lifecycle')]:
        row=report[key]['producer'];need(row['target']==target and row['role']=='product' and row['package']=='fc-bootstrap' and row['cargo_profile_test'] is False and row['pe_subsystem']==2 and row['pe_subsystem_version']=='6.1','ACTUAL_NORMAL_GUI_NOT_GNU_TEST_OR_CLONE')

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source-sha',required=True)
    for name in ('accepted-static-report','input-zip','build-evidence','lifecycle-helper','output-dir','report','objdump'):p.add_argument('--'+name,type=Path,required=True)
    for name in ('accepted-static-report-sha256','input-sha256','build-result-sha256','lifecycle-helper-sha256','objdump-sha256'):p.add_argument('--'+name,required=True)
    p.add_argument('--execute',action='store_true');a=p.parse_args();need(a.source_sha==SOURCE,'EXACT_PUSHED_SOURCE')
    if not a.execute:
        print(json.dumps(dict(status='PREPARED_PACKAGE_COMMAND_ONLY_NOT_RUN',sourceSha=SOURCE,requiredBaseline='Win7',requiredTarget='i686-win7-windows-msvc',requiredRunId=RUN,installation='NOT_RUN',sameSourceModern='INDEPENDENT_REFERENCE_ONLY')));return 0
    need((R/'.owner').read_bytes()==b'future-classroom-owned-r76-ci-evidence/v1\n' and (T/'.owner').read_bytes()==b'future-classroom-owned-r76-msi-tools/v1\n','EXACT_OWNERS')
    reportpath=owned(a.report);need(reportpath.parent==D and not reportpath.exists(),'NEW_OWNED_REPORT')
    result=dict(status='NOT_RUN_BLOCKED',sourceSha=SOURCE,installation='NOT_RUN',readiness='NOT_GRANTED',scope='Local candidate MSI build/static only after root-provided accepted Win7 same-source actual CI artifacts. No target EXE or Windows execution.')
    try:
        need(subprocess.check_output(['git','-C',str(MAIN),'rev-parse','HEAD'],timeout=10).decode().strip()==SOURCE,'CURRENT_HEAD_SAME_SOURCE')
        inputs=[pinned(SCRIPT,SCRIPT_SHA),pinned(owned(a.accepted_static_report),a.accepted_static_report_sha256),pinned(owned(a.input_zip),a.input_sha256),pinned(owned(a.lifecycle_helper),a.lifecycle_helper_sha256),pinned(a.objdump,a.objdump_sha256)]
        accepted=json.loads(a.accepted_static_report.read_bytes());accepted_gate(accepted,a.source_sha)
        build=owned(a.build_evidence);need(build.is_dir(),'ORIGINAL_BUILD_NAMESPACE');members={r['path']:r for r in accepted['members']};need(len(members)==len(accepted['members']),'UNIQUE_ACCEPTED_MEMBERS')
        names=['result.json','input-sha256.json','input-sha256-after.json','executables.json','logs/product-compile.stdout.log','logs/lifecycle-compile.stdout.log','product/fc-bootstrap/fc-bootstrap.exe','product/fc-bootstrap/fc-installer-lifecycle.exe']
        for name in names:
            actual=fact(owned(build/name));row=members[name];need(actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'],'ORIGINAL_CI_MEMBER_STATIC_BINDING');inputs.append(actual)
        need(pinned(build/'result.json',a.build_result_sha256)['sha256']==members['result.json']['sha256'],'EXACT_ACCEPTED_CI_RESULT')
        need(a.lifecycle_helper==build/'product/fc-bootstrap/fc-installer-lifecycle.exe','ORIGINAL_NORMAL_HELPER_NAMESPACE')
        inner=fact(a.input_zip);matches=[r for r in members.values() if r['bytes']==inner['bytes'] and r['sha256']==inner['sha256']];need(len(matches)==1,'INPUT_ZIP_IS_UNIQUE_ACCEPTED_ORIGINAL_MEMBER')
        tools=json.loads((D/'msi-tools-preparation-first.json').read_bytes());need(tools['status']=='PASS_EXACT_PACKAGES_LOCAL_EXTRACTION_ELF_BINDING_AND_SCOPED_TOOL_LOADING_ONLY','ACTUAL_LOCAL_TOOLS_READY')
        inputs.append(fact(D/'msi-tools-preparation-first.json'))
        for row in tools['tools']+tools['libraries']+[tools['wixlWrapper']]:inputs.append(pinned(Path(row['path']),row['sha256']))
        invocation=tools['invocation'];need(invocation['msibuild_sha256']==MSIBUILD_SHA,'PINNED_MSIBUILD')
        M=runpy.run_path(str(SCRIPT));manifest,payloads=M['validate_zip'](a.input_zip.read_bytes());M['pe_header'](payloads['fc-bootstrap.exe']);normal,provenance=M['admit_normal_helper'](a,payloads,manifest['version'])
        need(provenance['main_sha256']==accepted['normalExecutable']['producer']['sha256'] and provenance['normal_helper_sha256']==accepted['lifecycleExecutable']['producer']['sha256'],'SAME_ACCEPTED_TWO_NORMALS')
        output=owned(a.output_dir);need(output.parent==R and not output.exists(),'NEW_EXCLUSIVE_CANDIDATE_OUTPUT')
        command=['python3','-B',str(SCRIPT),'--input-zip',str(a.input_zip),'--input-sha256',a.input_sha256,'--lifecycle-helper',str(a.lifecycle_helper),'--lifecycle-helper-sha256',a.lifecycle_helper_sha256,'--build-evidence',str(build),'--build-result-sha256',a.build_result_sha256,'--output-dir',str(output)]
        for name in ('wixl','msibuild','msiinfo','msiextract'):command+=['--'+name,invocation[name]]
        command+=['--msibuild-sha256',MSIBUILD_SHA,'--objdump',str(a.objdump)]
        env=os.environ.copy()
        for name in ('LD_PRELOAD','LD_AUDIT','GIO_EXTRA_MODULES','GIO_MODULE_DIR'):env.pop(name,None)
        env.update(invocation['environment'])
        result.update(status='RUNNING',command=command,inputs=inputs,normalProvenance=provenance,originalPerToolBudgetSeconds=120,outerBudgetSeconds=1200)
        reportpath.write_text(json.dumps(result,indent=2)+'\n');started=time.monotonic()
        out=reportpath.with_suffix('.stdout.log');err=reportpath.with_suffix('.stderr.log');need(not out.exists() and not err.exists(),'EXCLUSIVE_STREAMS')
        with out.open('xb') as so,err.open('xb') as se:
            child=subprocess.Popen(command,cwd=MAIN,env=env,stdout=so,stderr=se,start_new_session=True);result['pid']=child.pid
            try:code=child.wait(timeout=1200);timed=False
            except subprocess.TimeoutExpired:
                timed=True;os.killpg(child.pid,signal.SIGTERM)
                try:code=child.wait(timeout=5)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=5)
        result.update(actualExit=True,exitCode=code,timedOut=timed,elapsedSeconds=time.monotonic()-started,stdout=fact(out),stderr=fact(err))
        need(code==0 and not timed,'ACTUAL_LOCAL_PACKAGE_FAILED')
        need(all(fact(Path(row['path']))==row for row in inputs),'ALL_INPUTS_UNCHANGED')
        actual=json.loads((output/'report.json').read_bytes());need(actual['status']=='PASS' and actual['installation']=='NOT_RUN' and actual['normal_helper_provenance']==provenance,'ACTUAL_PACKAGE_REPORT')
        result.update(status='PASS_LOCAL_PRODUCT_MSI_STATIC_ONLY_WINDOWS_NOT_RUN',packageReport=fact(output/'report.json'),candidateMSI=fact(output/'candidate.msi'))
    except Exception as error:result.update(status='FAIL_RETAIN_ALL_PACKAGE_ORIGINALS' if result['status']=='RUNNING' else 'NOT_RUN_BLOCKED',errorType=type(error).__name__,reasonCode=str(error) if isinstance(error,AssertionError) else 'LOCAL_ARTIFACT_ADMISSION_OR_BUILD_ERROR')
    reportpath.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],report=str(reportpath),installation='NOT_RUN')));return 0 if result['status']=='PASS_LOCAL_PRODUCT_MSI_STATIC_ONLY_WINDOWS_NOT_RUN' else 1
if __name__=='__main__':raise SystemExit(main())
