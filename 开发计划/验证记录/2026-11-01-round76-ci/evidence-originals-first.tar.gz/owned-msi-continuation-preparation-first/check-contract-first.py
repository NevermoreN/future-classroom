"""Finite actual-first policy reassessment and negative models, no Windows."""
from pathlib import Path
import json,re,hashlib
D=Path(__file__).parent;R=D.parent;s=(D/'Invoke-OwnedMsiContinuation.ps1').read_text()
checks=[]
def ck(n,v):
 if not v:raise AssertionError(n)
 checks.append(n)
f=R/'product-msi-runtime-first/report.json';first=json.loads(f.read_text());receipt=first['phaseResult'];c=json.loads((R/'runtime-config-first/candidate-inputs.json').read_text())
ck('first-report-pinned',hashlib.sha256(f.read_bytes()).hexdigest()=='89a2056df13664771d86113652b2c75566e1752f02ed344501e8c0ae6840f118')
def physical(closed):
 facts=closed['Processes'];ids={(x['Pid'],x['CreationFiletime']) for x in facts}
 if not closed['WmiStarted'] or not closed['Closed'] or len(ids)!=len(facts):return False
 for x in facts:
  if not(x['Pid']>0 and x['CreationFiletime']>0 and x['IdentityStatus']=='ORIGINAL_QUERY_SYNC_HANDLE_EXACT_IMAGE_BYTES_USER' and x['Sha256']==c['embeddedHelper']['sha256'] and x['Sid']==c['expectedUserSid'] and x['ActualWait']==0 and x['ActualExitCode']==0 and x['WaitStatus']=='ORIGINAL_OBJECT_SIGNALED' and x['ExitStatus']=='ACTUAL_ORIGINAL_GET_EXIT_CODE' and x['CloseStatus']=='CHECKED_CLOSE_SUCCESS'):return False
 def broker(x):return x['Role']=='broker' and x['CommandStatus']=='EXACT_CREATION_MATCHED_WMI_FACT_ONLY' and x['ExactCandidateArgv']==[x['Image'],'broker']
 if sum(broker(x) for x in facts)!=1:return False
 for e in closed['Errors']:
  m=re.fullmatch(r'candidate_metadata:(\d+):Win32Exception:image',e)
  if not m:return False
  bs=[x for x in facts if x['Pid']==int(m[1]) and broker(x)]
  if len(bs)!=1:return False
  b=bs[0];parents=[x for x in facts if x['Pid']==b['ParentPid'] and x['CreationFiletime']<b['CreationFiletime']]
  if len(parents)!=1:return False
 return True
closed=receipt['phases'][0]['observerFinal'];ck('actual-first-four-original-facts-physically-returned',physical(closed))
ck('old-first-fail-unchanged',receipt['status']=='FAIL_NOT_COMPLETE' and receipt['phases'][0]['ownerProof']['complete'] is False)
for key,value in [('ActualWait',258),('ActualExitCode',1),('CloseStatus','UNKNOWN_CLOSE_NOT_RETRIED'),('IdentityStatus','UNKNOWN'),('Sha256','0'*64),('Sid','S-1-5-18')]:
 x=json.loads(json.dumps(closed));x['Processes'][0][key]=value;ck('reject-original-'+key,not physical(x))
for error in ('capture:27436:Win32Exception:image','candidate_metadata:27436:Win32Exception:token','parent_query_CloseHandle_unknown','candidate_metadata:1:Win32Exception:image'):
 x=json.loads(json.dumps(closed));x['Errors']=[error];ck('reject-error-'+error,not physical(x))
x=json.loads(json.dumps(closed));x['Processes'][1]['ExactCandidateArgv']=None;ck('reject-no-original-broker-argv',not physical(x))
x=json.loads(json.dumps(closed));x['Processes'][1]['ParentPid']=99;ck('reject-supplement-without-earlier-original-parent',not physical(x))
ck('no-first-clock-renewal-claim','NEW_EXPLICIT_600S_EXPERIMENT_NOT_FIRST_CLOCK_RENEWAL' in s)
ck('no-fresh-command',"[ValidateSet('Reapply','Uninstall')]" in s and "[ValidateSet('Fresh'" not in s and "$kind-ceq'Fresh'" not in s)
ck('no-metadata-coverage-gate',"function Require-Phase($row){Require-ReturnedControls $row}" in s)
ck('no-live258-gate','$live.ContainsKey' not in s and 'BROKER_ORIGINAL_LIVE_NOT_OBSERVED' not in s)
ck('old-root-only-msi-source',"$script:msiPath=Join-Path $OriginalScratchRoot 'candidate.msi'" in s)
ck('gate-before-reapply',s.index('Capture-Gate;$ready=$true')<s.index("$reapply=Invoke-Phase 'reapply'"))
ck('all-output-new-child',"New-Json (Join-Path $ContinuationRoot 'continuation-runner-result.json')" in s and 'New-Json (Join-Path $OriginalScratchRoot' not in s)
ck('default-before-state','if(-not $Execute)' in s and s.index('if(-not $Execute)')<s.index('Get-FileHash'))
ck('one-new-clock',s.count('[Diagnostics.Stopwatch]::StartNew()')==1)
ck('literal-original-bindings',all(x in s for x in ('c1fb126c13840162f9a980262a7c84889c02df8c3710722f083200c43cd11692','29d2f37f33c048196d296da11565b53263c5c2cf6489a62f276b70ec695a54ac','89a2056df13664771d86113652b2c75566e1752f02ed344501e8c0ae6840f118')))
ck('no-process-kill-or-blind-delete',all(x not in s for x in ('Stop-Process','Remove-Item','taskkill','Set-ItemProperty')))
print(json.dumps({'status':'PASS_PURE_ACTUAL_FIRST_REASSESSMENT_AND_NEGATIVE_MODELS_ONLY','count':len(checks),'checks':checks,'powershellParse':'NOT_RUN','windows':'NOT_RUN','msi':'NOT_RUN'},indent=2))
