param([switch]$Execute,[string]$OriginalScratchRoot,[string]$ContinuationRoot,[string]$ExpectedConfigSha256,[string]$ExpectedFirstReceiptSha256,[string]$ExpectedFirstReportSha256,[string]$ExpectedInputsManifestSha256)
# New explicit finite experiment on the already-owned healthy first installation.
# This does not resume/extend the first600s clock or change its original FAIL.
if(-not $Execute){@{status='PREPARED_OWNED_CONTINUATION_NOT_RUN';windows='NOT_RUN';scope='Healthy reapplication and formal uninstall only; original first FAIL retained'}|ConvertTo-Json -Compress;return}
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$whole=[Diagnostics.Stopwatch]::StartNew()
$script:ownerUnknown=$true;$script:instrumentUnknown=$false;$script:formalAttempted=$false;$script:gateSnapshot=$null;$script:retireAttempted=$false
$script:retainedClients=[Collections.Generic.List[Diagnostics.Process]]::new()
$script:result=[ordered]@{status='FAIL_OWNED_CONTINUATION';experiment='NEW_EXPLICIT_600S_EXPERIMENT_NOT_FIRST_CLOCK_RENEWAL';scope='Only owned actual first fresh healthy installation: healthy same-MSI reapplication then formal uninstall';originalFirstStatus='FAIL_RETAINED_UNCHANGED';originalWholeMilliseconds=600000;cleanupReserveMilliseconds=180000;maximumClientPhaseMilliseconds=150000;nativeBrokerOriginalSeconds=120;phases=@();cleanup='NOT_RUN';engineLogSupplement='NOT_IMPLEMENTED_UNKNOWN_METADATA_RETAINED'}
function Require([bool]$v,[string]$code){if(-not $v){throw $code}}
function Digest([string]$p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function New-Bytes([string]$p,[byte[]]$b){$s=[IO.File]::Open($p,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);try{$s.Write($b,0,$b.Length);$s.Flush()}finally{$s.Dispose()}}
function New-Json([string]$p,$v){New-Bytes $p ([Text.UTF8Encoding]::new($false).GetBytes(($v|ConvertTo-Json -Depth 18)+"`n"))}
function Copy-Fact($v){return (($v|ConvertTo-Json -Depth 18 -Compress)|ConvertFrom-Json)}
function Remaining {return [Math]::Max(0,600000-$whole.ElapsedMilliseconds)}
function Quote([string]$v){Require (-not $v.Contains('"') -and -not $v.EndsWith('\') -and -not $v.Contains("`r") -and -not $v.Contains("`n")) 'CLOSED_ARGUMENT_ENCODING';return '"'+$v+'"'}
function Known-Path([string]$p){
 try{$a=[IO.File]::GetAttributes($p);return @{path=$p;status='KNOWN_PRESENT';directory=(($a-band[IO.FileAttributes]::Directory)-ne 0);reparse=(($a-band[IO.FileAttributes]::ReparsePoint)-ne 0)}}
 catch{$e=$_.Exception;while($null-ne$e.InnerException){$e=$e.InnerException};if($e-is[IO.FileNotFoundException]-or$e-is[IO.DirectoryNotFoundException]){return @{path=$p;status='KNOWN_ABSENT';directory=$false;reparse=$false}};return @{path=$p;status='UNKNOWN';exceptionKind=$e.GetType().FullName;hresult=$e.HResult;directory=$false;reparse=$false}}
}
function Coordination {
 $g=Known-Path $script:gateRoot;$p=Known-Path (Join-Path $script:gateRoot 'pending.v1')
 return @{root=$g;pending=$p;pendingKnownAbsent=($p.status-ceq'KNOWN_ABSENT' -and ($g.status-ceq'KNOWN_ABSENT' -or ($g.status-ceq'KNOWN_PRESENT' -and $g.directory -and -not$g.reparse)));namespaceKnownAbsent=($g.status-ceq'KNOWN_ABSENT');scope='Read-only fixed coordination path; not an owner/lease/settlement capability'}
}
function Measure-State([string]$expected){
 $v=Measure-FcProductState -Config $script:c -Expected $expected
 Require ($null-ne$v -and $v.stateClassification-in@('HEALTHY_PRESENT','KNOWN_ABSENT','UNKNOWN_OR_MISMATCH')) 'TYPED_STATE_RECEIPT'
 return (Copy-Fact $v)
}
function Assert-State($v,[string]$expected){
 if($expected-ceq'Present'){Require ($v.status-ceq'PASS_READONLY_EXPECTED_PRESENT' -and $v.healthyPresent-eq$true -and $v.stateClassification-ceq'HEALTHY_PRESENT') 'EXACT_HEALTHY_PRESENT_REQUIRED'}
 else{Require ($v.status-ceq'PASS_READONLY_EXPECTED_ABSENT' -and $v.knownAbsent-eq$true -and $v.stateClassification-ceq'KNOWN_ABSENT') 'EXACT_KNOWN_ABSENT_REQUIRED'}
}
function Owner-Proof($closed,$live){
 $problems=[Collections.Generic.List[string]]::new();$metadata=[Collections.Generic.List[string]]::new();$facts=@($closed.Processes);$seen=@{}
 if(-not $closed.WmiStarted -or -not $closed.Closed){$problems.Add('OBSERVER_NOT_STARTED_OR_NOT_CLOSED')}
 foreach($f in $facts){
  $key=([string]$f.Pid)+':'+([string]$f.CreationFiletime)
  if($seen.ContainsKey($key)){$problems.Add('DUPLICATE_ORIGINAL_IDENTITY')};$seen[$key]=$true
  if($f.Pid-le0 -or $f.CreationFiletime-le0 -or $f.IdentityStatus-cne'ORIGINAL_QUERY_SYNC_HANDLE_EXACT_IMAGE_BYTES_USER' -or $f.Sha256-cne$script:c.embeddedHelper.sha256 -or $f.Sid-cne$script:c.expectedUserSid -or $f.ActualWait-ne0 -or $f.ActualExitCode-ne0 -or $f.WaitStatus-cne'ORIGINAL_OBJECT_SIGNALED' -or $f.ExitStatus-cne'ACTUAL_ORIGINAL_GET_EXIT_CODE' -or $f.CloseStatus-cne'CHECKED_CLOSE_SUCCESS'){$problems.Add('ORIGINAL_IDENTITY_WAIT_EXIT_OR_CLOSE_NOT_RETURNED')}
  if($f.CommandStatus-cne'EXACT_CREATION_MATCHED_WMI_FACT_ONLY' -or $f.Role-ceq'UNKNOWN' -or $f.ParentLink-ceq'UNKNOWN'){$metadata.Add('SHORT_ROLE_OR_PARENT_METADATA_UNKNOWN')}
 }
 foreach($errorText in @($closed.Errors)){
  # In this unchanged observer, literal metadata:image occurs only in Parent(),
  # after the candidate's own OS image/hash/token/held identity was established.
  # Keep its raw text; never suppress capture/image/token/wait/close errors.
  if($errorText-cmatch'^candidate_metadata:([0-9]+):Win32Exception:image$'){
   $errorPid=[uint32]$Matches[1];$matched=@($facts|Where-Object{$_.Pid-eq$errorPid -and $_.Role-ceq'broker' -and $_.CommandStatus-ceq'EXACT_CREATION_MATCHED_WMI_FACT_ONLY' -and @($_.ExactCandidateArgv).Count-eq2 -and $_.ExactCandidateArgv[1]-ceq'broker' -and [string]::Equals($_.ExactCandidateArgv[0],$_.Image,[StringComparison]::OrdinalIgnoreCase)})
   if($matched.Count-eq1){$child=$matched[0];$parents=@($facts|Where-Object{$_.Pid-eq$child.ParentPid -and $_.CreationFiletime-lt$child.CreationFiletime -and $_.IdentityStatus-ceq'ORIGINAL_QUERY_SYNC_HANDLE_EXACT_IMAGE_BYTES_USER' -and $_.Sha256-ceq$script:c.embeddedHelper.sha256 -and $_.Sid-ceq$script:c.expectedUserSid -and $_.ActualWait-eq0 -and $_.ActualExitCode-eq0 -and $_.CloseStatus-ceq'CHECKED_CLOSE_SUCCESS'});if($parents.Count-eq1){$metadata.Add('BROKER_ORIGINAL_PARENT_IMAGE_METADATA_UNKNOWN_WITH_EARLIER_RETURNED_CAPTURE');continue}}
  }
  $problems.Add('NON_SUPPLEMENTAL_OBSERVER_ERROR')
 }
 $brokers=@($facts|Where-Object{$_.Role-ceq'broker' -and $_.CommandStatus-ceq'EXACT_CREATION_MATCHED_WMI_FACT_ONLY' -and @($_.ExactCandidateArgv).Count-eq2 -and $_.ExactCandidateArgv[1]-ceq'broker' -and [string]::Equals($_.ExactCandidateArgv[0],$_.Image,[StringComparison]::OrdinalIgnoreCase)})
 if($brokers.Count-ne1){$problems.Add('ORIGINAL_ARGV_BROKER_NOT_EXACTLY_ONE')}
 foreach($role in @('begin','guardian')){if(@($facts|Where-Object{$_.Role-ceq$role -and $_.CommandStatus-ceq'EXACT_CREATION_MATCHED_WMI_FACT_ONLY'}).Count-ne1){$metadata.Add('ROLE_'+$role+'_UNKNOWN_OR_NONUNIQUE')}}
 return @{knownControlsReturned=($problems.Count-eq0);complete=($problems.Count-eq0 -and $metadata.Count-eq0);coverageComplete=($metadata.Count-eq0);returnProblems=@($problems.ToArray());metadataUnknown=@($metadata.ToArray());roleCoverage=$(if($metadata.Count){'UNKNOWN_SUPPLEMENTAL_METADATA_RETAINED'}else{'OBSERVED_METADATA_ONLY_NOT_SESSION_AUTHORITY'});brokerEverObservedWait258=($live.Count-gt0);channel='Original held OS identity+Wait0+GetExit0+checkedClose; actual broker argv required; short role metadata and Wait258 sampling are not return authority';engineSupplement='UNKNOWN_NOT_IMPLEMENTED'}
}
function Invoke-Phase([string]$name,[ValidateSet('Reapply','Uninstall')][string]$kind,[int]$reserve){
 $budget=[int][Math]::Min(150000,[Math]::Max(0,(Remaining)-$reserve))
 Require ($budget-gt0) 'ORIGINAL_WHOLE_AND_CLEANUP_RESERVE_EXHAUSTED'
 $deadline=$whole.ElapsedMilliseconds+$budget
 $row=[ordered]@{name=$name;kind=$kind;startWholeMilliseconds=$whole.ElapsedMilliseconds;phaseDeadlineWholeMilliseconds=$deadline;phaseBudgetMilliseconds=$budget;nativeBrokerOriginalSeconds=120;client=@{started=$false;actualExit=$false;pipesComplete=$false;timedOut=$false;exitCode=$null};ownerProof=@{complete=$false;knownControlsReturned=$false;coverageProblems=@('NOT_CAPTURED');returnProblems=@('NOT_CAPTURED');brokerEverObservedWait258=$false};engineEvidence='UNKNOWN_NO_INDEPENDENT_EXPLICIT_ENGINE_RESULT_PARSER';observations='NOT_COMPLETE'}
 $script:result.phases+=,$row;$script:ownerUnknown=$true
 $observer=$null;$client=$null;$out=$null;$err=$null;$snap=$null;$closed=$null;$live=@{};$lastText=$null
 $snapshotPath=Join-Path $ContinuationRoot ($name+'-original-observer.jsonl')
 $snapshotFile=[IO.File]::Open($snapshotPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
 function Save-Snapshot($value){
  # C# Facts refer to live records; serialize immediately, never retain aliases.
  $text=$value|ConvertTo-Json -Depth 18 -Compress
  if($text-cne$script:phaseLastSnapshot){$bytes=[Text.UTF8Encoding]::new($false).GetBytes($text+"`n");Require ($snapshotFile.Length+$bytes.Length-le16777216) 'SNAPSHOT_LOG_BOUND';$snapshotFile.Write($bytes,0,$bytes.Length);$snapshotFile.Flush();$script:phaseLastSnapshot=$text}
  foreach($fact in @($value.Processes)){if($fact.Role-ceq'broker' -and $fact.ActualWait-eq258){$live[([string]$fact.Pid)+':'+([string]$fact.CreationFiletime)]=$true}}
  return ($text|ConvertFrom-Json)
 }
 $script:phaseLastSnapshot=$null
 try{
  $left=[int][Math]::Min(150000,$deadline-$whole.ElapsedMilliseconds);Require ($left-gt0) 'PHASE_EXPIRED_BEFORE_OBSERVER'
  $observer=[FcR76ProcessObserver]::new($script:c.embeddedHelper.sha256,[int]$script:c.embeddedHelper.bytes,$script:c.expectedUserSid,$left)
  $log=Join-Path $ContinuationRoot ($name+'-msi.log');Require (-not(Test-Path -LiteralPath $log)) 'EXCLUSIVE_MSI_LOG'
  $tail=' /qn /norestart REBOOT=ReallySuppress MSIRESTARTMANAGERCONTROL=DisableShutdown /L*vx '+(Quote $log)
  $arguments=if($kind-ceq'Uninstall'){'/x '+$script:productArgument+$tail}elseif($kind-ceq'Reapply'){'/i '+(Quote $script:msiPath)+' REINSTALL=ALL REINSTALLMODE=amus'+$tail}else{throw 'CONTINUATION_CLOSED_PHASE_ROLE'}
  $client=[Diagnostics.Process]::new();$client.StartInfo.FileName=$script:msiexec;$client.StartInfo.Arguments=$arguments;$client.StartInfo.WorkingDirectory=$ContinuationRoot
  $client.StartInfo.UseShellExecute=$false;$client.StartInfo.CreateNoWindow=$true;$client.StartInfo.RedirectStandardInput=$true;$client.StartInfo.RedirectStandardOutput=$true;$client.StartInfo.RedirectStandardError=$true
  $out=[IO.File]::Open((Join-Path $ContinuationRoot ($name+'-client.stdout.log')),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
  $err=[IO.File]::Open((Join-Path $ContinuationRoot ($name+'-client.stderr.log')),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
  Require ($whole.ElapsedMilliseconds-lt$deadline -and (Remaining)-gt$reserve) 'ORIGINAL_DEADLINE_BEFORE_START'
  Require ($client.Start()) 'CLIENT_START_FALSE';$row.client.started=$true;$client.StandardInput.Close()
  $row.client['pid']=$client.Id;$row.client['creationFiletime']=$client.StartTime.ToUniversalTime().ToFileTimeUtc();$row.client['file']=$script:msiexec;$row.client['arguments']=$arguments;$row['rawMsiLog']=$log
  $ot=$client.StandardOutput.BaseStream.CopyToAsync($out);$et=$client.StandardError.BaseStream.CopyToAsync($err)
  while($whole.ElapsedMilliseconds-lt$deadline -and (Remaining)-gt$reserve){
   $snap=Save-Snapshot ($observer.Snapshot())
   $row.client.actualExit=$client.HasExited
   if($row.client.actualExit){$row.client.exitCode=$client.ExitCode;if(@($snap.Processes|Where-Object{$_.Role-ceq'broker'}).Count-eq1 -and @($snap.Processes|Where-Object{$_.ActualWait-ne0}).Count-eq0){break}}
   Start-Sleep -Milliseconds 10
  }
  $row.client.actualExit=$client.HasExited
  if($row.client.actualExit){$row.client.exitCode=$client.ExitCode}else{$row.client.timedOut=$true;$script:retainedClients.Add($client);$client=$null}
  $wait=[int][Math]::Max(0,[Math]::Min(2000,$deadline-$whole.ElapsedMilliseconds))
  $row.client.pipesComplete=[Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($ot,$et),$wait)
 }catch{$row['phaseFailureType']=$_.Exception.GetType().FullName;$row['phaseFailureCode']=$(if($_.Exception.Message-cmatch'^[A-Z0-9_]+$'){$_.Exception.Message}else{'PHASE_NATIVE_OR_CLIENT_ERROR'})}
 finally{
  if($null-ne$observer){try{$closed=Save-Snapshot ($observer.FinishAndClose());$row['observerFinal']=$closed;$row.ownerProof=Owner-Proof $closed $live}catch{$script:instrumentUnknown=$true;$row['observerFinishFailure']='UNKNOWN_ORIGINAL_OBSERVER_RETURN_NO_RETRY'}}
  if($null-ne$client){if(-not$row.client.started){$client.Dispose()}else{try{if(-not $client.HasExited){$script:retainedClients.Add($client);$client=$null}else{$client.Dispose()}}catch{$script:instrumentUnknown=$true;$script:retainedClients.Add($client);$client=$null}}}
  foreach($s in @($out,$err,$snapshotFile)){if($null-ne$s){$s.Dispose()}}
  $row['endWholeMilliseconds']=$whole.ElapsedMilliseconds;$row['snapshotLog']=$snapshotPath
  $script:ownerUnknown=(-not($row.client.started -and $row.client.actualExit -and $row.client.pipesComplete -and -not$row.client.timedOut -and $row.ownerProof.knownControlsReturned))
  New-Json (Join-Path $ContinuationRoot ($name+'-phase.json')) $row
 }
 return $row
}
function Require-ReturnedControls($row){Require (-not$script:ownerUnknown -and -not$script:instrumentUnknown -and $row.client.exitCode-eq0) 'PHASE_ORIGINAL_CLIENT_OWNER_RETURN_INCOMPLETE'}
function Require-Phase($row){Require-ReturnedControls $row}
function Capture-Gate {
 try{$script:gateSnapshot=[FcR76GateRetirement]::Capture($script:c.expectedUserSid);$script:result['originalGateFacts']=@($script:gateSnapshot.Facts())}
 catch{$script:instrumentUnknown=$true;throw}
}
function Retire-Gate {
 Require (-not$script:ownerUnknown -and -not$script:instrumentUnknown -and $null-ne$script:gateSnapshot -and -not$script:retireAttempted -and (Remaining)-gt0) 'NO_ORIGINAL_GATE_RETIREMENT_AUTHORITY'
 $coord=Coordination;Require $coord.pendingKnownAbsent 'PENDING_NOT_KNOWN_ABSENT'
 $script:retireAttempted=$true
 try{$script:result['gateRetirementNative']=[FcR76GateRetirement]::Retire($script:gateSnapshot)}catch{$script:instrumentUnknown=$true;throw}
 $after=Coordination;$script:result['gateRetirementExternalReadback']=$after
 Require ($after.namespaceKnownAbsent -and $after.pendingKnownAbsent) 'EXTERNAL_GATE_NAMESPACE_ABSENCE_NOT_PROVEN'
}
$ready=$false;$mainSucceeded=$false;$childAdmitted=$false
try{
 Require ([Environment]::Is64BitProcess -and $PSVersionTable.PSVersion.Major-eq5 -and $PSVersionTable.PSVersion.Minor-eq1) 'EXPECTED_FRESH_X64_PS51'
 Require ($ExpectedConfigSha256-ceq'c1fb126c13840162f9a980262a7c84889c02df8c3710722f083200c43cd11692' -and $ExpectedFirstReceiptSha256-ceq'29d2f37f33c048196d296da11565b53263c5c2cf6489a62f276b70ec695a54ac' -and $ExpectedFirstReportSha256-ceq'89a2056df13664771d86113652b2c75566e1752f02ed344501e8c0ae6840f118' -and $ExpectedInputsManifestSha256-cmatch'^[0-9a-f]{64}$') 'EXPLICIT_ACTUAL_FIRST_BINDINGS'
 Require ($OriginalScratchRoot-ceq[IO.Path]::GetFullPath($OriginalScratchRoot) -and $ContinuationRoot-ceq[IO.Path]::GetFullPath($ContinuationRoot) -and [IO.Path]::GetDirectoryName($ContinuationRoot)-ceq$OriginalScratchRoot -and [IO.Path]::GetFileName($ContinuationRoot)-cmatch'^Continuation-[0-9a-f]{32}$') 'EXACT_EXISTING_PARENT_NEW_CHILD'
 $cursor=$ContinuationRoot;while($cursor){$f=Known-Path $cursor;Require ($f.status-ceq'KNOWN_PRESENT' -and $f.directory -and -not$f.reparse) 'ANCESTOR_NO_REPARSE';$cursor=[IO.Path]::GetDirectoryName($cursor)}
 foreach($root in @($OriginalScratchRoot,$ContinuationRoot)){
  $acl=[IO.Directory]::GetAccessControl($root);Require ($acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq'S-1-5-21-3896111207-1867804362-1971593122-1001') 'EXACT_ROOT_OWNER'
  $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Require ($rules.Count-eq2 -and @($rules|Where-Object{$_.IdentityReference.Value-notin@('S-1-5-21-3896111207-1867804362-1971593122-1001','S-1-5-18') -or $_.AccessControlType-ne'Allow' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count-eq0) 'EXACT_USER_SYSTEM_RULES'
  if($root-ceq$OriginalScratchRoot){Require $acl.AreAccessRulesProtected 'ORIGINAL_PROTECTED_DACL'}
 }
 foreach($pair in @(@($OriginalScratchRoot,'.owner'),@($ContinuationRoot,'.owner'),@($ContinuationRoot,'continuation-inputs.json'))){$f=Get-Item -LiteralPath (Join-Path $pair[0] $pair[1]) -Force;Require (-not$f.PSIsContainer -and -not($f.Attributes-band[IO.FileAttributes]::ReparsePoint)) 'REGULAR_ROOT_METADATA'}
 Require ([IO.File]::ReadAllText((Join-Path $OriginalScratchRoot '.owner'))-ceq"future-classroom-owned-r76-production-msi-runtime/v1`n" -and [IO.File]::ReadAllText((Join-Path $ContinuationRoot '.owner'))-ceq"future-classroom-owned-r76-product-msi-continuation/v1`n") 'EXACT_PARENT_AND_CHILD_MARKERS'
 $manifestPath=Join-Path $ContinuationRoot 'continuation-inputs.json';Require ((Digest $manifestPath)-ceq$ExpectedInputsManifestSha256) 'EXACT_CHILD_MANIFEST'
 $manifest=Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8|ConvertFrom-Json
 $pins=@{'ProcessObserver.cs'='ae5ad0205854e0f2e731394e6f72a0f2481818da1efabf88abeccd716a256b31';'GateRetirement.cs'='6384a7e0ab90e91fc3eeed9f0d922fc73f7a1f6d9c70062cf949253265d6cf01';'ProductState.cs'='13e94e6a04275a29473757ed77ad8d9d36c29e2725d5cb86ff0c36e76bd3b528';'ProductState.ps1'='0bfbc62da1da4d28babd88700fecf3ece88408deb31c932009ccbec54ad3e294';'candidate-inputs.json'=$ExpectedConfigSha256;'first-phase-runner-result.json'=$ExpectedFirstReceiptSha256;'first-transport-report.json'=$ExpectedFirstReportSha256}
 $names=@($pins.Keys)+@('Invoke-OwnedMsiContinuation.ps1');Require (@($manifest.files).Count-eq8 -and @(Get-ChildItem -LiteralPath $ContinuationRoot -Force).Count-eq10) 'FRESH_CHILD_EXACT_EIGHT_INPUTS'
 $seen=@{};foreach($row in $manifest.files){Require ($row.path-cin$names -and -not$seen.ContainsKey($row.path)) 'CLOSED_CHILD_MEMBER';$seen[$row.path]=$true;$path=Join-Path $ContinuationRoot $row.path;$f=Get-Item -LiteralPath $path -Force;Require (-not$f.PSIsContainer -and -not($f.Attributes-band[IO.FileAttributes]::ReparsePoint) -and $f.Length-eq$row.bytes -and (Digest $path)-ceq$row.sha256) 'EXACT_CHILD_FILE';if($pins.ContainsKey($row.path)){Require ($row.sha256-ceq$pins[$row.path]) 'ACCEPTED_CHILD_DEPENDENCY_PIN'}}
 foreach($row in @(@('candidate-inputs.json',$ExpectedConfigSha256),@('phase-runner-result.json',$ExpectedFirstReceiptSha256),@('candidate.msi','bb43f2505c70456ba26cf9a110a12b399008ac6269ea713d43fcc606a9c4521d'))){$p=Join-Path $OriginalScratchRoot $row[0];$f=Get-Item -LiteralPath $p -Force;Require (-not$f.PSIsContainer -and -not($f.Attributes-band[IO.FileAttributes]::ReparsePoint) -and (Digest $p)-ceq$row[1]) 'ORIGINAL_FIRST_BYTES_UNCHANGED'}
 $script:c=Get-Content -LiteralPath (Join-Path $ContinuationRoot 'candidate-inputs.json') -Raw -Encoding UTF8|ConvertFrom-Json
 Require ($script:c.sourceGit-ceq'3bad94949012e840cd1dda6a73a0ea1ddb067697' -and $script:c.target-ceq'i686-win7-windows-msvc' -and $script:c.family-ceq'99378807-098D-5F04-8D4D-F181DFA218D5' -and $script:c.expectedUserSid-ceq'S-1-5-21-3896111207-1867804362-1971593122-1001' -and $script:c.status-ceq'BOUND_PLAN_ONLY_NOT_EXECUTABLE_OR_RUNTIME_PASS') 'SAME_ACTUAL_SOURCE_TARGET_USER_FAMILY'
 Require ([IO.Path]::GetFileName($OriginalScratchRoot)-ceq$script:c.runtimeRootName -and $script:c.runtimeNonce-ceq'a835c46e54774a709d6696a2f8b4885b') 'ONLY_ACTUAL_FIRST_PARENT_NONCE'
 $who=[Security.Principal.WindowsIdentity]::GetCurrent();try{Require ($who.User.Value-ceq$script:c.expectedUserSid) 'SAME_CURRENT_USER'}finally{$who.Dispose()}
 $script:msiPath=Join-Path $OriginalScratchRoot 'candidate.msi';Require ($script:c.msi.sha256-ceq'bb43f2505c70456ba26cf9a110a12b399008ac6269ea713d43fcc606a9c4521d' -and $script:c.msi.bytes-eq6434304 -and (Get-Item -LiteralPath $script:msiPath).Length-eq6434304 -and $script:c.productCode-ceq'{9E50831D-7811-5039-8BC3-4934647448D8}') 'SAME_ACTUAL_MSI_AND_PRODUCT'
 $script:productArgument=$script:c.productCode
 $local=[Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData);Require (-not[string]::IsNullOrEmpty($local)) 'KNOWN_FOLDER_REQUIRED';$script:gateRoot=Join-Path $local ('FutureClassroom-Installer-'+$script:c.family)
 $script:msiexec=Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::Windows)) 'System32\msiexec.exe'
 $first=Get-Content -LiteralPath (Join-Path $ContinuationRoot 'first-phase-runner-result.json') -Raw -Encoding UTF8|ConvertFrom-Json
 $transport=Get-Content -LiteralPath (Join-Path $ContinuationRoot 'first-transport-report.json') -Raw -Encoding UTF8|ConvertFrom-Json
 Require ($first.status-ceq'FAIL_NOT_COMPLETE' -and @($first.phases).Count-eq1 -and $first.phases[0].kind-ceq'Fresh' -and $first.phases[0].client.started -and $first.phases[0].client.actualExit -and $first.phases[0].client.pipesComplete -and -not$first.phases[0].client.timedOut -and $first.phases[0].client.exitCode-eq0 -and $first.retainedDirectClients-eq0 -and -not$first.formalUninstallAttempted) 'ACTUAL_FIRST_FRESH_EXIT_ZERO_NO_MAINTENANCE'
 Require ($transport.status-ceq'FAIL_PRODUCT_PHASE_OR_COVERAGE_RETAINED' -and $transport.sourceUnchanged -and $transport.controllerReturned -and $transport.config.sha256-ceq$ExpectedConfigSha256 -and $transport.msi.sha256-ceq$script:c.msi.sha256 -and $transport.beforeCreate.root-ceq$OriginalScratchRoot -and $transport.downloadVerified-ceq'EXACT_EACH_REMOTE_FILE_SIZE_SHA_AND_MEMBERSHIP') 'ACTUAL_FIRST_TRANSPORT_CAPTURE_BINDING'
 $before=$first.before;Require ($before.status-ceq'PASS_BEFORE_KNOWN_ABSENCE_ONLY_NOT_EXECUTION_ADMISSION' -and $before.sourceGit-ceq$script:c.sourceGit -and $before.currentUserSid-ceq$script:c.expectedUserSid -and $before.componentMarkers.knownAbsent -and $before.run.knownAbsent -and $before.registration.knownAbsent -and $before.registration.count-eq0 -and $before.registration.state-eq-1 -and $before.registration.relatedCount-eq0 -and @($before.fixedPaths).Count-eq2 -and @($before.fixedPaths|Where-Object{$_.status-cne'KNOWN_ABSENT'}).Count-eq0) 'ACTUAL_FIRST_BEFORE_ALL_ABSENT'
 Require ($before.fixedPaths[0].path-ceq(Join-Path $local 'Programs\FutureClassroom') -and $before.fixedPaths[1].path-ceq$script:gateRoot -and $first.initialProductState.status-ceq'PASS_READONLY_EXPECTED_ABSENT' -and $first.initialProductState.knownAbsent) 'ACTUAL_FIRST_TYPED_ABSENT_PATHS'
 $oldProof=Owner-Proof $first.phases[0].observerFinal @{};$script:result['firstPhysicalReturnReassessment']=$oldProof;Require $oldProof.knownControlsReturned 'FIRST_ORIGINAL_CONTROLS_NOT_PHYSICALLY_RETURNED'
 $script:ownerUnknown=$false;$childAdmitted=$true;$script:result['bindings']=@{configSha256=$ExpectedConfigSha256;firstReceiptSha256=$ExpectedFirstReceiptSha256;firstTransportSha256=$ExpectedFirstReportSha256;firstStatus=$first.status;msiSha256=$script:c.msi.sha256;originalScratchRoot=$OriginalScratchRoot;continuationRoot=$ContinuationRoot}
 . (Join-Path $ContinuationRoot 'ProductState.ps1')
 $temp=Join-Path $ContinuationRoot 'instrument-temp';[void][IO.Directory]::CreateDirectory($temp);$env:TEMP=$temp;$env:TMP=$temp
 Require ($null-eq('FcR76ProcessObserver'-as[type]) -and $null-eq('FcR76GateRetirement'-as[type])) 'FRESH_INSTRUMENT_TYPES_REQUIRED'
 Add-Type -LiteralPath (Join-Path $ContinuationRoot 'ProcessObserver.cs') -ReferencedAssemblies @('System.dll','System.Core.dll','System.Management.dll') -ErrorAction Stop
 Add-Type -LiteralPath (Join-Path $ContinuationRoot 'GateRetirement.cs') -ErrorAction Stop
 $present=Measure-State 'Present';$script:result['beforeContinuationHealthy']=$present;Assert-State $present 'Present';$coord=Coordination;$script:result['beforeContinuationCoordination']=$coord;Require ($coord.pendingKnownAbsent -and $coord.root.status-ceq'KNOWN_PRESENT') 'CURRENT_HEALTHY_PENDING_ABSENT_REQUIRED'
 Capture-Gate;$ready=$true
 $reapply=Invoke-Phase 'reapply' 'Reapply' 180000;Require-Phase $reapply
 $present=Measure-State 'Present';$script:result['reapplyPresent']=$present;Assert-State $present 'Present';Require ((Coordination).pendingKnownAbsent) 'REAPPLY_PENDING_ABSENCE'
 $script:formalAttempted=$true;$uninstall=Invoke-Phase 'uninstall' 'Uninstall' 0;Require-Phase $uninstall
 $absent=Measure-State 'Absent';$script:result['uninstallAbsent']=$absent;Assert-State $absent 'Absent';Retire-Gate
 Require ((Remaining)-gt0) 'NEW_EXPERIMENT_DEADLINE_EXCEEDED';$mainSucceeded=$true;$script:result.status='PASS_OWNED_HEALTHY_REAPPLY_FORMAL_UNINSTALL_GATE_ABSENT_WIN11_ONLY'
}catch{$script:result['failureType']=$_.Exception.GetType().FullName;$script:result['failureCode']=$(if($_.Exception.Message-cmatch'^[A-Z0-9_]+$'){$_.Exception.Message}else{'CONTINUATION_CONFIG_NATIVE_STATE_OR_PHASE_ERROR'})}
finally{
 if($ready){
  try{$final=Measure-State 'Present';$coord=Coordination;$script:result['finallyProductState']=$final;$script:result['finallyCoordination']=$coord
   if(-not$mainSucceeded -and -not$script:formalAttempted -and -not$script:ownerUnknown -and -not$script:instrumentUnknown -and $final.healthyPresent -and $coord.pendingKnownAbsent -and (Remaining)-gt0){
    $script:formalAttempted=$true;$cleanup=Invoke-Phase 'failure-formal-uninstall' 'Uninstall' 0;Require-ReturnedControls $cleanup
    $after=Measure-State 'Absent';$script:result['failureCleanupAbsent']=$after;Assert-State $after 'Absent';Retire-Gate;$script:result.cleanup='FORMAL_UNINSTALL_RETURNED_ORIGINAL_CONTINUATION_FAILURE_RETAINED'
   }elseif($mainSucceeded){Require ($final.knownAbsent -and $coord.namespaceKnownAbsent -and $coord.pendingKnownAbsent) 'FINAL_EXTERNAL_ABSENCE_RECHECK';$script:result.cleanup='PASS_FORMAL_UNINSTALL_AND_ORIGINAL_GATE_RETIRED'}else{$script:result.cleanup='RETAIN_FAIL_UNKNOWN_NO_BLIND_CLEANUP'}
  }catch{$mainSucceeded=$false;$script:result.status='FAIL_CONTINUATION_FINAL_OBSERVATION_OR_CLEANUP';$script:result['finallyFailureType']=$_.Exception.GetType().FullName;$script:result.cleanup='RETAIN_FAIL_CLEANUP_OR_OBSERVATION_UNKNOWN'}
 }
 $script:result['elapsedWholeMilliseconds']=$whole.ElapsedMilliseconds;$script:result['originalBudgetExceeded']=($whole.ElapsedMilliseconds-ge600000);$script:result['ownerUnknown']=$script:ownerUnknown;$script:result['instrumentUnknown']=$script:instrumentUnknown;$script:result['formalUninstallAttempted']=$script:formalAttempted;$script:result['retainedDirectClients']=$script:retainedClients.Count
 if($childAdmitted){try{New-Json (Join-Path $ContinuationRoot 'continuation-runner-result.json') $script:result}catch{$mainSucceeded=$false;$script:result.status='FAIL_CONTINUATION_RECEIPT_WRITE'}}
}
$script:result|ConvertTo-Json -Depth 24 -Compress
if(-not$mainSucceeded -or $script:result.originalBudgetExceeded){exit 1};exit 0
