"""Pure/default preparation checks only; model SHA is not a source fact.
Every subprocess lacks --execute. No Git credential/network/Git push/EXE call.
"""
from pathlib import Path
import ast,hashlib,json,subprocess,time
R=Path(__file__).parent;MODEL='a'*40
assert (R/'.owner').read_bytes()==b'future-classroom-owned-r76-ci-evidence/v1\n'
checks=[]
def f(p):
 b=p.read_bytes();return dict(path=p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
for p in R.glob('*.py'):ast.parse(p.read_bytes())
checks.append(dict(name='Python_AST',status='PASS'))
cases=[('dispatch-default-modern',['dispatch-ci-once.py','--source-sha',MODEL,'--workflow','windows-msvc.yml'],0),('dispatch-default-win7',['dispatch-ci-once.py','--source-sha',MODEL,'--workflow','windows-win7-msvc.yml'],0),('record-dispatch-default',['record-dispatch-once.py','--source-sha',MODEL,'--workflow','windows-msvc.yml'],0),('observe-default',['observe-run-once.py','--source-sha',MODEL,'--baseline','modern','--run-id','1','--label','model'],0),('download-default',['download-original-official-second.py','--source-sha',MODEL,'--baseline','modern','--run-id','1','--artifact-id','1','--expected-bytes','1','--expected-sha256','b'*64],0),('record-download-default',['record-download-official-second.py','--source-sha',MODEL,'--baseline','modern'],0),('source-required',['record-dispatch-once.py','--workflow','windows-msvc.yml'],2),('bad-source',['dispatch-ci-once.py','--source-sha','not-a-sha','--workflow','windows-msvc.yml'],1)]
for label,args,wanted in cases:
 cmd=['python3','-B',str(R/args[0]),*args[1:]];o=R/(label+'.stdout.log');e=R/(label+'.stderr.log');t=time.monotonic()
 with o.open('xb') as so,e.open('xb') as se:
  p=subprocess.Popen(cmd,stdout=so,stderr=se);code=p.wait(timeout=15)
 assert code==wanted,(label,code)
 if wanted==0:assert json.loads(o.read_bytes())['status']=='NOT_RUN_PREPARATION_ONLY'
 checks.append(dict(name=label,command=cmd,pid=p.pid,actualExit=True,exitCode=code,expectedExit=wanted,timedOut=False,elapsedSeconds=time.monotonic()-t,stdout=f(o),stderr=f(e)))
s=(R/'dispatch-ci-once.py').read_text();assert s.count("call('POST',")==1 and "Do not repeat dispatch" in s and "DISPATCH_REQUEST_ABOUT_TO_SEND" in s and "do not repeat POST" in s
assert "opener.open(request" in s and 'class NoRedirect' in s
checks.append(dict(name='one_POST_site_preserve_uncertain_and_no_auth_redirect',status='PASS'))
s=(R/'record-dispatch-once.py').read_text();assert "'--source-sha',a.source_sha" in s and "'2dfb2e7" not in s
checks.append(dict(name='no_hardcoded_candidate_source_commit',status='PASS'))
s=(R/'download-original-official-second.py').read_text();assert 'Never forward the GitHub credential' in s and "Request(location,headers={'Accept-Encoding':'identity'})" in s and "build_opener(NoRedirect).open" in s
checks.append(dict(name='memory_only_allowlisted_redirect_new_request_no_Authorization',status='PASS'))
for n in ('dispatch-ci-once.py','record-dispatch-once.py','observe-run-once.py','download-original-official-second.py','record-download-official-second.py'):
 assert '/tmp/fc-round74' not in (R/n).read_text()
checks.append(dict(name='no_active_R74_temp_references',status='PASS'))
(R/'checks-first.json').write_text(json.dumps(dict(status='PASS_PREPARATION_DEFAULTS_AND_AST_NOT_DISPATCHED',sourceModelQualification='a*40 is only a CLI-shape model, never actual committed or pushed source identity',networkExecuted=False,dispatchExecuted=False,downloadExecuted=False,windowsExecuted=False,checks=checks),indent=2)+'\n')
print(json.dumps(dict(status='PASS_PREPARATION_ONLY_NOT_RUN',checks=len(checks))))
