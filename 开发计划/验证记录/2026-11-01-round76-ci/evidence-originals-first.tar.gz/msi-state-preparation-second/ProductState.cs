// R76 independent bounded READ-ONLY poststate observer, not broker authority.
using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Principal;
using Microsoft.Win32;
using Microsoft.Win32.SafeHandles;

public static class FcR76ProductState {
    const string Source = "3bad94949012e840cd1dda6a73a0ea1ddb067697";
    const string Family = "99378807-098D-5F04-8D4D-F181DFA218D5";
    const string Markers = @"Software\FutureClassroom\Installer\Components";
    const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
    const uint Reparse=0x400, DirectoryAttribute=0x10;
    const int MaxEntries=96;
    [StructLayout(LayoutKind.Sequential)] struct FT { public uint Low,High; }
    [StructLayout(LayoutKind.Sequential)] struct Info {
        public uint Attributes; public FT Creation,Access,Write; public uint Volume,SizeHigh,SizeLow,Links,IndexHigh,IndexLow;
    }
    [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode,ExactSpelling=true)] struct FindData {
        public uint Attributes;public FT Creation,Access,Write;public uint SizeHigh,SizeLow,Reserved0,Reserved1;
        [MarshalAs(UnmanagedType.ByValTStr,SizeConst=260)]public string Name;
        [MarshalAs(UnmanagedType.ByValTStr,SizeConst=14)]public string Alternate;
    }
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true,ExactSpelling=true)]static extern SafeFileHandle CreateFileW(string p,uint access,uint share,IntPtr security,uint disposition,uint flags,IntPtr template);
    [DllImport("kernel32.dll",SetLastError=true,ExactSpelling=true)]static extern bool GetFileInformationByHandle(SafeFileHandle handle,out Info info);
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true,ExactSpelling=true)]static extern IntPtr FindFirstFileW(string pattern,out FindData data);
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true,ExactSpelling=true)]static extern bool FindNextFileW(IntPtr handle,out FindData data);
    [DllImport("kernel32.dll",SetLastError=true,ExactSpelling=true)]static extern bool FindClose(IntPtr handle);
    [DllImport("advapi32.dll",CharSet=CharSet.Unicode,ExactSpelling=true)]static extern int RegQueryValueExW(SafeRegistryHandle key,string name,IntPtr reserved,out uint type,IntPtr data,ref uint size);
    [DllImport("msi.dll",CharSet=CharSet.Unicode,ExactSpelling=true)]static extern uint MsiEnumProductsExW(string product,string sid,uint context,uint index,StringBuilder found,out uint actualContext,StringBuilder actualSid,ref uint sidChars);
    [DllImport("msi.dll",CharSet=CharSet.Unicode,ExactSpelling=true)]static extern uint MsiEnumRelatedProductsW(string family,uint reserved,uint index,StringBuilder product);
    [DllImport("msi.dll",CharSet=CharSet.Unicode,ExactSpelling=true)]static extern uint MsiGetProductInfoExW(string product,string sid,uint context,string property,StringBuilder value,ref uint chars);
    [DllImport("msi.dll",CharSet=CharSet.Unicode,ExactSpelling=true)]static extern int MsiQueryProductStateW(string product);
    [DllImport("msi.dll",CharSet=CharSet.Unicode,ExactSpelling=true)]static extern int MsiGetComponentPathExW(string product,string component,string sid,uint context,StringBuilder path,ref uint chars);
    static Dictionary<string,object> D(params object[] pairs) {
        var d=new Dictionary<string,object>();for(int i=0;i<pairs.Length;i+=2)d.Add((string)pairs[i],pairs[i+1]);return d;
    }
    static void Require(bool value,string code) { if(!value)throw new InvalidOperationException(code); }
    static void Actual(bool value,string code,Dictionary<string,object> facts) {if(!value){var e=new InvalidOperationException(code);e.Data["actual"]=facts;throw e;}}
    static string Hex(byte[] data) {return BitConverter.ToString(data).Replace("-","").ToLowerInvariant();}
    static bool GuidText(string text,bool braces) {
        Guid id;if(text==null||!Guid.TryParse(text,out id))return false;
        return String.Equals(text,braces?"{"+id.ToString("D").ToUpperInvariant()+"}":id.ToString("D").ToUpperInvariant(),StringComparison.Ordinal);
    }
    static bool PathAllowed(string value) {
        string[] fixedNames={"fc-bootstrap.exe","LICENSE","PROBE-README.txt","THIRD-PARTY-NOTICES.txt","manifest.json","MSI-CANDIDATE.txt","web/index.html","web/fc-assets.json","web/THIRD-PARTY-NOTICES.txt"};
        if(Array.IndexOf(fixedNames,value)>=0)return true;
        if(value==null||value.Length>240||!value.StartsWith("web/assets/",StringComparison.Ordinal))return false;
        string leaf=value.Substring(11);if(leaf.Length==0||leaf.EndsWith(".")||leaf.EndsWith(" "))return false;
        foreach(char c in leaf)if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='.'||c=='_'||c=='-'))return false;
        string stem=leaf.Split('.')[0].ToUpperInvariant();return stem.Length>0&&stem!="CON"&&stem!="PRN"&&stem!="AUX"&&stem!="NUL"&&!System.Text.RegularExpressions.Regex.IsMatch(stem,@"^(COM|LPT)[1-9]$");
    }
    public static void Validate(string source,string product,string family,string version,string sid,string[] paths,long[] sizes,string[] hashes,string[] components) {
        Require(source==Source&&family==Family&&GuidText(product,true),"EXACT_SOURCE_FAMILY_PRODUCT_GUID");
        Require(sid!=null&&System.Text.RegularExpressions.Regex.IsMatch(sid,@"^S-1-5-21-(?:[0-9]+-){3}[0-9]+$"),"EXPECTED_USER_SID_FORMAT");
        string[] fields=(version??"").Split('.');Require(fields.Length==3,"MSI_VERSION_THREE_PARTS");
        for(int i=0;i<3;i++){uint n;Require(System.Text.RegularExpressions.Regex.IsMatch(fields[i],@"^[0-9]+$")&&UInt32.TryParse(fields[i],out n)&&n<=(i==2?65535U:255U),"MSI_VERSION_RANGE");}
        Require(paths!=null&&sizes!=null&&hashes!=null&&components!=null&&paths.Length>=1&&paths.Length<=72&&paths.Length==sizes.Length&&paths.Length==hashes.Length&&paths.Length==components.Length,"BOUNDED_PARALLEL_PAYLOAD_ROWS");
        var names=new HashSet<string>(StringComparer.OrdinalIgnoreCase);var ids=new HashSet<string>(StringComparer.OrdinalIgnoreCase);long total=0;
        for(int i=0;i<paths.Length;i++){
            Require(PathAllowed(paths[i])&&names.Add(paths[i]),"CLOSED_UNIQUE_CANONICAL_PAYLOAD_PATH");
            Require(sizes[i]>=0&&sizes[i]<=30*1024*1024,"PAYLOAD_SIZE_BOUND");total=checked(total+sizes[i]);
            Require(hashes[i]!=null&&System.Text.RegularExpressions.Regex.IsMatch(hashes[i],@"^[0-9a-f]{64}$"),"PAYLOAD_SHA256");
            Require(GuidText(components[i],false)&&ids.Add(components[i]),"UNIQUE_CANONICAL_COMPONENT_GUID");
        }
        Require(total<=30*1024*1024,"TOTAL_PAYLOAD_BOUND");
        foreach(string required in new string[]{"fc-bootstrap.exe","LICENSE","PROBE-README.txt","THIRD-PARTY-NOTICES.txt","manifest.json","MSI-CANDIDATE.txt","web/index.html","web/fc-assets.json","web/THIRD-PARTY-NOTICES.txt"})Require(names.Contains(required),"REQUIRED_CLOSED_PAYLOAD_MEMBER");
    }
    static Info FileInfo(SafeFileHandle handle) {Info info;if(!GetFileInformationByHandle(handle,out info))throw new Win32Exception(Marshal.GetLastWin32Error());return info;}
    static long Length(Info info) {return checked((long)(((ulong)info.SizeHigh<<32)|info.SizeLow));}
    static string ApiPath(string path) {Require(path!=null&&path.Length<32760&&System.Text.RegularExpressions.Regex.IsMatch(path,@"^[A-Za-z]:\\"),"BOUNDED_CANONICAL_WIN32_FILE_PATH");return @"\\?\"+path;}
    static SafeFileHandle Open(string path,bool directory) {
        // OPEN_EXISTING only, OPEN_REPARSE_POINT. Directory pins deny DELETE sharing;
        // file pins deny WRITE and DELETE sharing for stable read/hash observations.
        var handle=CreateFileW(ApiPath(path),directory?0x81U:0x80000080U,directory?3U:1U,IntPtr.Zero,3,0x00200000U|(directory?0x02000000U:0),IntPtr.Zero);
        if(handle.IsInvalid){int code=Marshal.GetLastWin32Error();handle.Dispose();throw new Win32Exception(code);}
        try {Info info=FileInfo(handle);Actual((info.Attributes&Reparse)==0&&((info.Attributes&DirectoryAttribute)!=0)==directory,"NONREPARSE_EXPECTED_NODE_TYPE",D("path",path,"attributes",info.Attributes,"expectedDirectory",directory));return handle;}
        catch {handle.Dispose();throw;}
    }
    static string[] Names(string directory) {
        FindData data;IntPtr handle=FindFirstFileW(ApiPath(directory)+@"\*",out data);
        if(handle==new IntPtr(-1))throw new Win32Exception(Marshal.GetLastWin32Error());
        var names=new List<string>();try {
            while(true){Require(!String.IsNullOrEmpty(data.Name)&&data.Name.Length<260,"BOUNDED_ENUMERATED_NAME");if(data.Name!="."&&data.Name!=".."){Require(names.Count<MaxEntries,"DIRECTORY_ENTRY_BOUND");names.Add(data.Name);}
                if(!FindNextFileW(handle,out data)){int code=Marshal.GetLastWin32Error();if(code!=18)throw new Win32Exception(code);break;}}
        }finally{if(!FindClose(handle))throw new Win32Exception(Marshal.GetLastWin32Error());}
        names.Sort(StringComparer.Ordinal);return names.ToArray();
    }
    static bool SameNames(string[] a,string[] b) {return String.Join("\n",a)==String.Join("\n",b);}
    static void PinAncestors(string target,List<SafeFileHandle> pins) {
        Require(System.Text.RegularExpressions.Regex.IsMatch(target,@"^[A-Za-z]:\\")&&!target.StartsWith(@"\\"),"FIXED_LOCAL_DRIVE_KNOWN_FOLDER");
        string current=Path.GetPathRoot(target);pins.Add(Open(current,true));string[] parts=target.Substring(current.Length).Split('\\');
        foreach(string part in parts){Require(part.Length>0&&part!="."&&part!=".."&&!part.Contains(":"),"CANONICAL_ANCESTOR_COMPONENT");current=Path.Combine(current,part);pins.Add(Open(current,true));}
    }
    static Dictionary<string,object> Files(string[] paths,long[] sizes,string[] hashes) {
        string local=Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);Require(!String.IsNullOrEmpty(local),"LOCALAPPDATA_KNOWN_FOLDER");
        string parent=Path.Combine(local,"Programs"),target=Path.Combine(parent,"FutureClassroom");var result=D("root",target,"presentExact",false,"absentExact",false,"files",new List<object>());var pins=new List<SafeFileHandle>();
        try {
            // Never enumerate ancestors: pin only the OS-known-folder chain and fixed Programs.
            PinAncestors(local,pins);
            try{pins.Add(Open(parent,true));}catch(Win32Exception e){if(e.NativeErrorCode==2||e.NativeErrorCode==3){result["programsOpenCode"]=e.NativeErrorCode;result["absentExact"]=true;return result;}throw;}
            try{pins.Add(Open(target,true));}catch(Win32Exception e){if(e.NativeErrorCode==2||e.NativeErrorCode==3){result["rootOpenCode"]=e.NativeErrorCode;result["absentExact"]=true;return result;}throw;}
            var expectedFiles=new Dictionary<string,int>(StringComparer.Ordinal);var expectedDirs=new HashSet<string>(StringComparer.Ordinal);expectedDirs.Add("");
            for(int i=0;i<paths.Length;i++){expectedFiles.Add(paths[i],i);int slash=paths[i].LastIndexOf('/');while(slash>=0){string prefix=paths[i].Substring(0,slash);expectedDirs.Add(prefix);slash=prefix.LastIndexOf('/');}}
            var seenFiles=new HashSet<string>(StringComparer.Ordinal);var seenDirs=new HashSet<string>(StringComparer.Ordinal);seenDirs.Add("");var queue=new Queue<string>();queue.Enqueue("");var snapshots=new Dictionary<string,string[]>();bool exact=true;var observations=(List<object>)result["files"];
            while(queue.Count>0){string relative=queue.Dequeue(),directory=relative==""?target:Path.Combine(target,relative.Replace('/','\\'));string[] names=Names(directory);snapshots.Add(directory,names);
                foreach(string leaf in names){Require(leaf.IndexOfAny(new char[]{'\\','/',':'})<0&&leaf!="."&&leaf!="..","ENUMERATED_CANONICAL_LEAF");string rel=relative==""?leaf:relative+"/"+leaf;string path=Path.Combine(directory,leaf);
                    if(expectedDirs.Contains(rel)){pins.Add(Open(path,true));seenDirs.Add(rel);queue.Enqueue(rel);continue;}
                    int index;if(!expectedFiles.TryGetValue(rel,out index)){observations.Add(D("path",rel,"status","UNEXPECTED_NAME_CONTENT_NOT_READ"));exact=false;continue;}
                    var handle=Open(path,false);pins.Add(handle);Info before=FileInfo(handle);long size=Length(before);var fact=D("path",rel,"bytes",size,"links",before.Links,"volume",before.Volume,"fileIndexHigh",before.IndexHigh,"fileIndexLow",before.IndexLow);observations.Add(fact);seenFiles.Add(rel);
                    if(size!=sizes[index]||before.Links!=1){fact["status"]="SIZE_OR_HARDLINK_MISMATCH_CONTENT_NOT_READ";exact=false;continue;}
                    string digest;using(var hash=SHA256.Create())using(var view=new SafeFileHandle(handle.DangerousGetHandle(),false))using(var stream=new FileStream(view,FileAccess.Read,4096,false)){digest=Hex(hash.ComputeHash(stream));}
                    // The stream owns only a non-owning wrapper; the original file pin remains until final phase cleanup.
                    Info after=FileInfo(handle);Require(after.Links==1&&Length(after)==size&&after.Volume==before.Volume&&after.IndexHigh==before.IndexHigh&&after.IndexLow==before.IndexLow&&after.Write.Low==before.Write.Low&&after.Write.High==before.Write.High,"STABLE_ORIGINAL_FILE_IDENTITY_AFTER_HASH");
                    fact["sha256"]=digest;fact["status"]=digest==hashes[index]?"EXACT":"HASH_MISMATCH";exact&=digest==hashes[index];
                }
            }
            foreach(var snapshot in snapshots)exact&=SameNames(snapshot.Value,Names(snapshot.Key));
            var finalLinks=new List<object>();foreach(var pin in pins){Info info=FileInfo(pin);if((info.Attributes&DirectoryAttribute)==0){finalLinks.Add(info.Links);exact&=info.Links==1;}}result["finalFileLinkCounts"]=finalLinks;
            exact&=seenFiles.SetEquals(expectedFiles.Keys)&&seenDirs.SetEquals(expectedDirs);result["observedDirectories"]=new List<string>(seenDirs);result["presentExact"]=exact;return result;
        }catch(Exception e){e.Data["partialObservation"]=result;throw;}finally{for(int i=pins.Count-1;i>=0;i--)pins[i].Dispose();}
    }
    static Dictionary<string,object> Registry(string[] components) {
        var result=D("view","Registry32","key",Markers,"presentExact",false,"absentExact",false,"values",new List<object>());
        using(var root=RegistryKey.OpenBaseKey(RegistryHive.CurrentUser,RegistryView.Registry32))using(var key=root.OpenSubKey(Markers,false)){
            if(key==null){result["absentExact"]=true;return result;}
            result["subKeyCount"]=key.SubKeyCount;result["valueCount"]=key.ValueCount;Require(key.ValueCount<=72&&key.SubKeyCount<=72,"REGISTRY_COLLECTION_BOUND");
            var expected=new HashSet<string>(components,StringComparer.Ordinal);var seen=new HashSet<string>(StringComparer.Ordinal);bool exact=key.SubKeyCount==0;var values=(List<object>)result["values"];
            foreach(string name in key.GetValueNames()){
                if(!expected.Contains(name)){values.Add(D("name",name,"status","UNEXPECTED_NAME_CONTENT_NOT_READ"));exact=false;continue;}
                RegistryValueKind kind=key.GetValueKind(name);object value=kind==RegistryValueKind.DWord?key.GetValue(name,null,RegistryValueOptions.DoNotExpandEnvironmentNames):null;
                values.Add(D("name",name,"kind",kind.ToString(),"dword",value));exact&=kind==RegistryValueKind.DWord&&value is Int32&&(Int32)value==1;seen.Add(name);
            }
            result["presentExact"]=exact&&seen.SetEquals(expected)&&key.SubKeyCount==0&&key.ValueCount==seen.Count;
        }return result;
    }
    static Dictionary<string,object> Run() {
        using(var root=RegistryKey.OpenBaseKey(RegistryHive.CurrentUser,RegistryView.Registry32))using(var key=root.OpenSubKey(RunKey,false)){
            if(key==null)return D("view","Registry32","value","FutureClassroom","absent",true,"keyAbsent",true,"contentsRead",false);
            uint kind,size=0;int code=RegQueryValueExW(key.Handle,"FutureClassroom",IntPtr.Zero,out kind,IntPtr.Zero,ref size);
            return D("view","Registry32","value","FutureClassroom","queryCode",code,"type",kind,"bytes",size,"absent",code==2,"contentsRead",false);
        }
    }
    static Dictionary<string,object> Registration(string product,string sid,string version) {
        var items=new List<object>();var related=new List<object>();var calls=new List<object>();bool exactCalls=true;
        // Machine native SID is explicitly null; user native SID is explicitly actual SID, never empty-string substitution.
        foreach(uint queryContext in new uint[]{3,4}){
            string querySid=queryContext==4?null:sid;bool ended=false;
            for(uint i=0;i<8;i++){
                var found=new StringBuilder(39);var actualSid=new StringBuilder(256);uint context,chars=256;uint rc=MsiEnumProductsExW(product,querySid,queryContext,i,found,out context,actualSid,ref chars);
                calls.Add(D("index",i,"queryContext",queryContext,"sidArgument",querySid,"code",rc,"returnedSidChars",chars));
                if(rc==259||(i==0&&rc==1605)){ended=true;break;}if(rc!=0||chars>=256){exactCalls=false;break;}
                var record=D("productCode",found.ToString(),"context",context,"userSid",actualSid.ToString());items.Add(record);
                var buffer=new StringBuilder(256);uint n=256;uint info=MsiGetProductInfoExW(found.ToString(),context==4?null:actualSid.ToString(),context,"VersionString",buffer,ref n);
                record["versionCode"]=info;record["versionChars"]=n;record["version"]=buffer.ToString();if(info!=0||n>=256)exactCalls=false;
            }exactCalls&=ended;
        }
        bool relatedEnded=false;for(uint i=0;i<8;i++){var found=new StringBuilder(39);uint rc=MsiEnumRelatedProductsW("{"+Family+"}",0,i,found);calls.Add(D("relatedIndex",i,"code",rc));if(rc==259){relatedEnded=true;break;}if(rc!=0){exactCalls=false;break;}related.Add(found.ToString());}exactCalls&=relatedEnded;
        int state=MsiQueryProductStateW(product);bool present=exactCalls&&items.Count==1&&related.Count==1&&state==5;
        if(present){var item=(Dictionary<string,object>)items[0];present=(string)item["productCode"]==product&&(uint)item["context"]==2&&(string)item["userSid"]==sid&&(uint)item["versionCode"]==0&&(string)item["version"]==version&&(string)related[0]==product;}
        return D("productsEx",items,"relatedProducts",related,"calls",calls,"productState",state,"apiCallsComplete",exactCalls,"presentExact",present,"absentExact",exactCalls&&items.Count==0&&related.Count==0&&state==-1,"scope","Exact product, actual-user managed/unmanaged plus machine contexts; no other-user enumeration");
    }
    static Dictionary<string,object> Components(string product,string sid,string[] components) {
        var rows=new List<object>();bool present=true,absent=true;
        foreach(string component in components){var path=new StringBuilder(1024);uint n=1024;int state=MsiGetComponentPathExW(product,"{"+component+"}",sid,2,path,ref n);string text=path.ToString(),expected=@"01:\"+Markers+@"\"+component;
            rows.Add(D("component",component,"context",2,"sidArgument",sid,"state",state,"reportedCharacterCount",n,"path",text));
            present&=state==3&&n>0&&n<1024&&text.Length==n&&String.Equals(text,expected,StringComparison.OrdinalIgnoreCase);absent&=state==-1&&text.Length==0;
        }return D("rows",rows,"presentExact",present,"absentExact",absent);
    }
    public static Dictionary<string,object> Measure(string source,string product,string family,string version,string sid,string[] paths,long[] sizes,string[] hashes,string[] components,string expected) {
        var observations=new Dictionary<string,object>();var errors=new List<object>();var result=D("status","FAIL_CONFIG_OR_INSTRUMENTATION","sourceGit",source,"expected",expected,"healthyPresent",false,"knownAbsent",false,"matchesExpected",false,"stateClassification","UNKNOWN_OR_MISMATCH","observations",observations,"phaseErrors",errors,"mutations",false,"coordinationGate","NOT_MEASURED_BY_THIS_MODULE","scope","Independent finite readonly poststate, not permission or broker Settlement; no Pending/gate query or cleanup");
        try{Validate(source,product,family,version,sid,paths,sizes,hashes,components);Require(expected=="Present"||expected=="Absent","EXPECTED_LABEL");using(var identity=WindowsIdentity.GetCurrent()){result["currentUserSid"]=identity.User.Value;Require(identity.User.Value==sid,"EXACT_ACTUAL_CURRENT_USER_SID");}}
        catch(Exception e){errors.Add(Error("configOrCurrentIdentity",e));return result;}
        Action<string,Func<Dictionary<string,object>>> phase=(name,read)=>{try{observations.Add(name,read());}catch(Exception e){errors.Add(Error(name,e));}};
        phase("files",()=>Files(paths,sizes,hashes));phase("markers",()=>Registry(components));phase("registration",()=>Registration(product,sid,version));phase("components",()=>Components(product,sid,components));phase("run",()=>Run());
        bool present=errors.Count==0,absent=errors.Count==0;
        foreach(string name in new string[]{"files","markers","registration","components"}){object value;if(!observations.TryGetValue(name,out value)){present=absent=false;continue;}var fact=(Dictionary<string,object>)value;present&=(bool)fact["presentExact"];absent&=(bool)fact["absentExact"];}
        object run;bool runAbsent=observations.TryGetValue("run",out run)&&(bool)((Dictionary<string,object>)run)["absent"];present&=runAbsent;absent&=runAbsent;
        result["runAbsent"]=runAbsent;result["healthyPresent"]=present;result["knownAbsent"]=absent;result["stateClassification"]=present?"HEALTHY_PRESENT":absent?"KNOWN_ABSENT":"UNKNOWN_OR_MISMATCH";bool matches=expected=="Present"?present:absent;result["matchesExpected"]=matches;result["status"]=matches?(expected=="Present"?"PASS_READONLY_EXPECTED_PRESENT":"PASS_READONLY_EXPECTED_ABSENT"):"FAIL_READONLY_POSTSTATE";return result;
    }
    static Dictionary<string,object> Error(string phase,Exception error) {return D("phase",phase,"exceptionType",error.GetType().FullName,"hresult",error.HResult,"win32Error",error is Win32Exception?(object)((Win32Exception)error).NativeErrorCode:null,"code",error is InvalidOperationException?error.Message:"ACTUAL_EXCEPTION_NUMERIC_IDENTITY_RETAINED","actual",error.Data["actual"],"partialObservation",error.Data["partialObservation"]);}
}
