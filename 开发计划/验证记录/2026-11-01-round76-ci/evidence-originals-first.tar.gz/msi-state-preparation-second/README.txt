R76 read-only MSI state instrument, second preparation — NOT COMPILED / NOT RUN

API remains Measure-FcProductState -Config $c -Expected Present|Absent. Dot-source defines functions only.
ProductState.ps1 is byte-identical to frozen first version and reads ProductState.cs from its own PSScriptRoot.
Only ProductState.cs change: RegQueryValueExW first PInvoke parameter IntPtr -> SafeRegistryHandle.
Actual first .NETFramework compile proved RegistryKey.Handle has SafeRegistryHandle type. The PInvoke now accepts
that actual type; SafeHandle marshalling keeps the argument alive during the call, and enclosing using RegistryKey
continues to own/dispose it after the call. No registry handle is extracted or closed manually. All other file-handle
interop, registry query arguments, null output-data pointer, state logic, buffers, source constraints and failures remain
byte-identical. There is exactly one key.Handle call in this instrument; it is the fixed Run value existence query.
The first actual compile failure and raw report remain unchanged. Second has only local byte/contract checks, no
Windows, PowerShell/C# compile, product API, MSI, network, source/main or first-version modification. Root must
pin both second file SHA values and perform actual compilation before treating any observation as valid.
Use a fresh PS process or ensure the rejected first type is not loaded; root caller still bounds compilation TEMP/TMP.
Other first-version contracts/limitations remain in the archived first README; this change grants no authority and
performs no product mutation/cleanup. It cannot supply broker Settlement or Pending/gate permission.
