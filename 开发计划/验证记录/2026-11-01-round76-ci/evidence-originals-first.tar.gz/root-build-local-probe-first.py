"""Build a local ZIP with original same-source packager, never execute the PE."""
from pathlib import Path
import argparse, hashlib, json, runpy, subprocess, time
R=Path('/tmp/fc-round76-ci-evidence');SOURCE='3bad94949012e840cd1dda6a73a0ea1ddb067697'
WT=R/'msi-checkout-preparation-first/checkout-3bad949-first'
BUILD=R/'production-msi-preparation-second/original-ci-namespace-first'
AUDIT=R/'ui-preparation-first/win7-independent-first.json'
WEB=R/'web-build-first/build-report-first.json';WEB_SHA='2c9fd214c70b9d09c8f551f04edaa8c3e01d4162292c1f8e07e25dd3a6b338b0'
D=R/'local-probe-first';OUTPUT=D/'FutureClassroom-0.1.0-windows-x86-dev.zip'
def need(v,c):
    if not v:raise AssertionError(c)
def sha(b):return hashlib.sha256(b).hexdigest()
def fact(p):
    p=Path(p);need(p.is_file() and not p.is_symlink(),'REGULAR_INPUT');b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def main():
    p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');a=p.parse_args()
    if not a.execute:print(json.dumps(dict(status='PREPARED_LOCAL_PROBE_ONLY_NOT_RUN',sourceSha=SOURCE)));return 0
    need((R/'.owner').read_bytes()==b'future-classroom-owned-r76-ci-evidence/v1\n','EXACT_R76_OWNER')
    need(fact(WEB)['sha256']==WEB_SHA,'EXPLICIT_ACTUAL_WEB_REPORT');web=json.loads(WEB.read_bytes())
    need(web['status']=='PASS_LOCAL_SAME_SOURCE_WEB_BUILD_ONLY' and web['sourceSha']==SOURCE and web['checkoutUnchanged'] is True and web['lockUnchanged'] is True and web['copyOriginalSourceUnchangedExceptNotice'] is True and web['notice']['onlyLfCrLfEquivalent'] is True,'ACTUAL_SAME_SOURCE_LOCKED_WEB_AND_UNCHANGED_INPUTS')
    need(all(s['actualExit'] is True and s['exitCode']==0 and not s['timedOut'] for s in web['steps']),'ALL_ACTUAL_WEB_CHILDREN_EXIT0')
    audit=json.loads(AUDIT.read_bytes());need(fact(AUDIT)['sha256']=='36ea9d1547ba3dec8d4cf5c53c92d57878ee37cc8095df17bcffde3dcb663ef1','EXPLICIT_ACTUAL_WIN7_AUDIT')
    app=BUILD/'product/fc-bootstrap/fc-bootstrap.exe';need(fact(app)['sha256']==audit['normalExecutable']['producer']['sha256'],'ACTUAL_ACCEPTED_NORMAL_APP')
    dist=Path(web['dist']['path']);need(dist==R/'web-build-first/source/web/dist','EXACT_OWNED_WEB_DIST')
    for row in web['dist']['files']:
        f=fact(dist/row['path']);need(f['bytes']==row['bytes'] and f['sha256']==row['sha256'],'ACTUAL_WEB_OUTPUT_BYTES')
    inventory=json.loads((BUILD/'input-sha256.json').read_bytes());by={r['path']:r for r in inventory}
    tracked=subprocess.check_output(['git','-C',str(WT),'ls-files','-z'],timeout=30).decode().split('\0')
    selected=[n for n in tracked if n and (n.startswith(('crates/','scripts/','web/','.cargo/')) or n in ('Cargo.toml','Cargo.lock'))]
    inputs=[]
    for n in selected:
        f=fact(WT/n);need(by.get(n)==dict(path=n,bytes=f['bytes'],sha256=f['sha256']),'CHECKOUT_REMAINS_ACTUAL_CI_BYTES');inputs.append(f)
    need(subprocess.check_output(['git','-C',str(WT),'rev-parse','HEAD'],timeout=10).decode().strip()==SOURCE,'SAME_SOURCE_HEAD')
    need(subprocess.check_output(['git','-C',str(WT),'-c','core.autocrlf=true','status','--porcelain','-z','--untracked-files=all'],timeout=30)==b'','CLEAN_ORIGINAL_CHECKOUT')
    script=WT/'scripts/package-probe.py';objdump=Path('/usr/bin/i686-w64-mingw32-objdump');need(fact(objdump)['sha256']=='521df27111c0ac3c8f6b6498505cbd35e8f087551418f4e084055f8ac308379a','ORIGINAL_PINNED_OBJDUMP')
    need(not D.exists(),'NEW_LOCAL_PRODUCER_ROOT');D.mkdir();(D/'.owner').write_text('future-classroom-owned-r76-local-probe/v1\n')
    result=json.loads((BUILD/'result.json').read_bytes());toolchain=result['toolchain']
    cmd=['python3','-B',str(script),'--exe',str(app),'--output',str(OUTPUT),'--target','i686-win7-windows-msvc','--objdump',str(objdump),'--toolchain',toolchain,'--web-dist',str(dist)]
    report=D/'producer-first.json';value=dict(status='RUNNING',sourceSha=SOURCE,target='i686-win7-windows-msvc',command=cmd,originalBudgetSeconds=300,acceptedStatic=fact(AUDIT),normalApp=fact(app),script=fact(script),webBuild=fact(WEB),webDist=str(dist),objdump=fact(objdump),sourceInputs=inputs,origin='LOCAL_PACKAGE_PROBE_NOT_CI_ARTIFACT_MEMBER',productMSI='NOT_RUN',runtime='NOT_RUN_BY_PACKAGING')
    report.write_text(json.dumps(value,indent=2)+'\n');start=time.monotonic()
    try:
        child=subprocess.run(cmd,cwd=WT,capture_output=True,timeout=300);value.update(actualExit=True,exitCode=child.returncode,elapsedSeconds=time.monotonic()-start)
        for n,b in [('stdout',child.stdout),('stderr',child.stderr)]:
            f=D/('producer-first.'+n+'.log');f.write_bytes(b);value[n]=fact(f)
        need(child.returncode==0,'ACTUAL_LOCAL_PROBE_EXIT0')
        module=runpy.run_path(str(WT/'scripts/package-msi-candidate.py'));manifest,payloads=module['validate_zip'](OUTPUT.read_bytes())
        need(payloads['fc-bootstrap.exe']==app.read_bytes() and manifest['target']=='i686-win7-windows-msvc' and manifest['frontend']['included'] is True,'CLOSED_LOCAL_ZIP_ACTUAL_NORMAL_AND_WEB')
        need(all(fact(Path(r['path']))==r for r in inputs),'ALL_CI_CHECKOUT_INPUTS_UNCHANGED_AFTER_LOCAL_PACKAGE')
        need(fact(WEB)==value['webBuild'] and fact(app)==value['normalApp'] and fact(AUDIT)==value['acceptedStatic'],'BOUND_ORIGINAL_INPUTS_UNCHANGED')
        value.update(status='PASS_LOCAL_SAME_SOURCE_PROBE_ZIP_ONLY_RUNTIME_NOT_RUN',sourceInputsUnchanged=True,artifact=fact(OUTPUT),closedPayloadCount=len(payloads),manifest=manifest)
    except Exception as e:value.update(status='FAIL_RETAIN_LOCAL_PROBE_ORIGINALS',errorKind=type(e).__name__,reason=str(e) if isinstance(e,AssertionError) else 'LOCAL_BUILD_OR_INPUT_FAILURE')
    report.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps({k:value.get(k) for k in ['status','exitCode','artifact','closedPayloadCount','reason']}));return 0 if value['status']=='PASS_LOCAL_SAME_SOURCE_PROBE_ZIP_ONLY_RUNTIME_NOT_RUN' else 1
if __name__=='__main__':raise SystemExit(main())
