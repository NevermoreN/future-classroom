from pathlib import Path
import hashlib,json,runpy,subprocess
D=Path(__file__).resolve().parent;R=D.parent
RAW=R/'ui-preparation-first/win7-artifact-original/raw'
SOURCE=R/'msi-checkout-preparation-first/checkout-3bad949-first'
def fact(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
paths=[RAW/'result.json',RAW/'logs/cargo-metadata.stdout.log',RAW/'logs/product-compile.stdout.log',RAW/'logs/lifecycle-compile.stdout.log',D/'scripts/package-msi-candidate.py']
before=[fact(p) for p in paths]
accepted=R/'ui-preparation-first/win7-independent-first.json';assert fact(accepted)['sha256']=='36ea9d1547ba3dec8d4cf5c53c92d57878ee37cc8095df17bcffde3dcb663ef1'
report=json.loads(accepted.read_bytes());members={r['path']:r for r in report['members']}
for p in paths[:-1]:
 f=fact(p);row=members[p.relative_to(RAW).as_posix()];assert all(f[k]==row[k] for k in ('bytes','sha256'))
result=json.loads((RAW/'result.json').read_bytes());assert result['source_sha']==result['dispatch_source_sha']=='3bad94949012e840cd1dda6a73a0ea1ddb067697'
assert result['target']=='i686-win7-windows-msvc' and result['baseline']=='Win7'
assert subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],timeout=10).decode().strip()==result['source_sha']
M=runpy.run_path(str(D/'scripts/package-msi-candidate.py'));M['configure_source_root'](SOURCE)
package,targets,metadataSha=M['cargo_metadata_normal_package'](RAW,result,'0.1.0')
rows=[]
for name,phase in [('fc-bootstrap','product-compile'),('fc-installer-lifecycle','lifecycle-compile')]:
 p=RAW/('logs/'+phase+'.stdout.log');steps=[s for s in result['commands'] if s['name']==phase]
 assert len(steps)==1 and steps[0]['passed'] and steps[0]['parent_exited'] and steps[0]['exit_code']==0 and steps[0]['stdout_sha256']==fact(p)['sha256']
 messages=[]
 for line in p.read_bytes().splitlines():
  if line.startswith(b'{'):
   x=json.loads(line)
   if x.get('reason')=='compiler-artifact' and x.get('executable') and x['target']['name']==name:messages.append(x)
 assert len(messages)==1 and messages[0]['profile']['test'] is False
 M['match_normal_metadata'](messages[0],name,package,targets)
 rows.append({'target':name,'packageId':messages[0]['package_id'],'manifestPath':messages[0]['manifest_path'],'exactTargetEqualsOriginalMetadata':True,'profileTest':False,'cargoStream':fact(p)})
assert before==[fact(p) for p in paths]
p=D/'actual-metadata-association-first.json'
assert not p.exists()
p.write_text(json.dumps({'status':'PASS_ACTUAL_ORIGINAL_METADATA_AND_TWO_NORMAL_CARGO_ASSOCIATIONS_ONLY','acceptedStatic':fact(accepted),'originalSourceHead':result['source_sha'],'explicitSourceRoot':str(SOURCE),'builderScript':fact(D/'scripts/package-msi-candidate.py'),'metadata':fact(RAW/'logs/cargo-metadata.stdout.log'),'metadataShaReturned':metadataSha,'packageName':package['name'],'packageVersion':package['version'],'actualOpaquePackageId':package['id'],'normalMessages':rows,'inputsBefore':before,'inputsAfter':[fact(p) for p in paths],'sourceInputsModified':False,'fullAdmit':'NOT_RUN_MISSING_ADDITIONAL_ORIGINAL_METADATA_MEMBER_IN_OLD_NINE_MEMBER_NAMESPACE','fullAdmitNeeds':'A new exact namespace containing the nine original members plus real logs/cargo-metadata.stdout.log; never modify old namespace/result or inject a fake path/log','msi':'NOT_BUILT','windows':'NOT_RUN','network':'NOT_RUN','cargo':'NOT_RUN'},indent=2)+'\n')
print(json.dumps(fact(p)))
