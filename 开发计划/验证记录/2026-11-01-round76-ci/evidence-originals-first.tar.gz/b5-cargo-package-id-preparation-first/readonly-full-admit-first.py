from pathlib import Path
from types import SimpleNamespace
import hashlib,json,runpy
D=Path(__file__).resolve().parent;R=D.parent
SOURCE=R/'msi-checkout-preparation-first/checkout-3bad949-first';N=R/'metadata-ci-namespace-first'
ZIP=R/'local-probe-first/FutureClassroom-0.1.0-windows-x86-dev.zip'
def fact(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
accepted=R/'ui-preparation-first/win7-independent-first.json';assert fact(accepted)['sha256']=='36ea9d1547ba3dec8d4cf5c53c92d57878ee37cc8095df17bcffde3dcb663ef1'
a=json.loads(accepted.read_bytes());members={r['path']:r for r in a['members']}
paths=[N/n for n in ['artifact-sha256.json','result.json','input-sha256.json','input-sha256-after.json','executables.json','logs/product-compile.stdout.log','logs/lifecycle-compile.stdout.log','logs/cargo-metadata.stdout.log','product/fc-bootstrap/fc-bootstrap.exe','product/fc-bootstrap/fc-installer-lifecycle.exe']]
for p in paths:
 row=members[p.relative_to(N).as_posix()];f=fact(p);assert all(f[k]==row[k] for k in ('bytes','sha256'))
paths.extend([ZIP,D/'scripts/package-msi-candidate.py',D/'scripts/check-msi-candidate.py',R/'metadata-ci-namespace-first-receipt.json'])
before=[fact(p) for p in paths]
M=runpy.run_path(str(D/'scripts/package-msi-candidate.py'));M['configure_source_root'](SOURCE)
raw=M['PROBE']['bounded_regular_file'](ZIP,M['MAX_ZIP'])
manifest,payloads=M['validate_zip'](raw);M['pe_header'](payloads['fc-bootstrap.exe'])
helper=N/'product/fc-bootstrap/fc-installer-lifecycle.exe'
args=SimpleNamespace(build_evidence=N,build_result_sha256=members['result.json']['sha256'],lifecycle_helper=helper,lifecycle_helper_sha256=members[helper.relative_to(N).as_posix()]['sha256'],source_root=SOURCE)
normal,provenance=M['admit_normal_helper'](args,payloads,manifest['version'])
assert provenance['source_sha']=='3bad94949012e840cd1dda6a73a0ea1ddb067697'
assert provenance['main_sha256']==a['normalExecutable']['producer']['sha256'] and provenance['normal_helper_sha256']==a['lifecycleExecutable']['producer']['sha256']
assert before==[fact(p) for p in paths]
p=D/'actual-full-admit-first.json';assert not p.exists()
p.write_text(json.dumps({'status':'PASS_ACTUAL_READONLY_NORMAL_AND_LOCAL_ZIP_ADMISSION_NOT_MSI_BUILD_OR_RUNTIME','acceptedStatic':fact(accepted),'normalHelperProvenance':provenance,'explicitSourceRoot':str(SOURCE),'builderSource':fact(D/'scripts/package-msi-candidate.py'),'inputZip':fact(ZIP),'inputZipProducer':'LOCAL_SAME_SOURCE_PACKAGE_PROBE_NOT_ORIGINAL_CI_MEMBER','manifestVersion':manifest['version'],'target':manifest['target'],'manifestReadiness':manifest['status'],'sourceNamespace':str(N),'namespaceReceipt':fact(R/'metadata-ci-namespace-first-receipt.json'),'inputsBefore':before,'inputsAfter':[fact(p) for p in paths],'originalsUnchanged':True,'normalPeExecuted':False,'msiBuilt':False,'windows':'NOT_RUN','network':'NOT_RUN','cargo':'NOT_RUN'},indent=2)+'\n')
print(json.dumps(fact(p)));print(json.dumps(provenance))
