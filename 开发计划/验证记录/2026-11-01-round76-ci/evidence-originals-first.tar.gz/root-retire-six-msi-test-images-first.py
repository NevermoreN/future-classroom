"""Retire six exact owned test images only after product uninstall; preserve all raw facts."""
from pathlib import Path
import argparse,base64,hashlib,json,runpy,subprocess,time,uuid,sys
sys.dont_write_bytecode=True
R=Path('/tmp/fc-round76-ci-evidence')
def sha(b):return hashlib.sha256(b).hexdigest()
def fact(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def main():
 a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');a.add_argument('--source-sha256');args=a.parse_args()
 if not args.execute:print('PREPARED_NOT_RUN');return 0
 source=R/'exact-msi-image-retirement-preparation-first/ExactMsiImageRetirement.cs';b=source.read_bytes();assert sha(b)==args.source_sha256
 cfg=R/'runtime-config-first/candidate-inputs.json';assert sha(cfg.read_bytes())=='c1fb126c13840162f9a980262a7c84889c02df8c3710722f083200c43cd11692'
 preflight=R/'production-msi-preparation-first/ReadOnlyPreflightFunction.ps1';assert sha(preflight.read_bytes())=='1843f75e8165a043575c89a49416825e5f007f3f2b0730e6b2f43250f87546ae'
 cleanup=R/'root-cleanup-owned-msi-first.json';assert sha(cleanup.read_bytes())=='d341f782442e5a6e2c5acba4ee69d1b58ba22906148e910e5348ea77fb9e2848' and json.loads(cleanup.read_bytes())['status']=='PASS'
 m=runpy.run_path(str(R/'production-msi-continuation-transport-preparation-first/run-owned-continuation-first.py'))
 out=R/'six-msi-test-images-retirement-first';assert not out.exists();out.mkdir();(out/'.owner').write_text('future-classroom-owned-r76-six-test-image-retirement-result/v1\n');report=out/'report.json';start=time.monotonic()
 nonce=uuid.uuid4().hex;root='C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r76-image-retirement-'+nonce
 c=dict(root=root,sid=m['SID'],config=json.loads(cfg.read_bytes()),csBase64=base64.b64encode(b).decode(),csSha=sha(b))
 result=dict(status='FAIL',source=fact(source),config=fact(cfg),originalCleanup=fact(cleanup),root=root,operations=[])
 common=m['COMMON'].split('function CheckOriginal')[0]+m['COMMON'][m['COMMON'].index('function Inventory('):m['COMMON'].index('function CompareOriginal(')]
 def call(name,script,seconds=30):
  feed=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+common+script).encode();boot=m['BOOT'];command=['ssh','-i',m['KEY'],'-o','BatchMode=yes','-o','ConnectTimeout=8',m['HOST'],'powershell.exe','-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-EncodedCommand',base64.b64encode(boot.encode('utf-16-le')).decode()]
  begun=time.monotonic();p=subprocess.run(command,input=feed,capture_output=True,timeout=seconds);row=dict(name=name,command=command,actualExit=True,exitCode=p.returncode,reaped=True,elapsedSeconds=time.monotonic()-begun)
  for label,data in [('stdin',feed),('stdout',p.stdout),('stderr',p.stderr)]:
   path=out/(name+'.'+label+'.log');path.write_bytes(data);row[label]=fact(path)
  result['operations'].append(row);report.write_text(json.dumps(result,indent=2)+'\n');return p
 create=r'''$who=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$who.User;if($sid.Value-cne$c.sid){throw 'EXACT_SID'}}finally{$who.Dispose()}
$root=$c.root;if($root-cnotmatch'^C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r76-image-retirement-[0-9a-f]{32}$'){throw 'EXACT_NEW_ROOT'}
try{[void][IO.File]::GetAttributes($root);throw 'ROOT_EXISTS'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
[void][IO.Directory]::CreateDirectory($root);$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false);foreach($s in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($s,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))};[IO.Directory]::SetAccessControl($root,$acl);[IO.File]::WriteAllText((Join-Path $root '.owner'),"future-classroom-owned-r76-exact-test-images/v1`n",[Text.UTF8Encoding]::new($false));CheckAcl $root "future-classroom-owned-r76-exact-test-images/v1`n"
$env:TEMP=$root;$env:TMP=$root
'''+preflight.read_text()+r'''
$before=Measure-FcBeforePreflight -Config $c.config;if($before.status-cne'PASS_BEFORE_KNOWN_ABSENCE_ONLY_NOT_EXECUTION_ADMISSION'){throw 'GLOBAL_PRODUCT_ABSENCE_REQUIRED'}
$src=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($c.csBase64));Add-Type -TypeDefinition $src -ErrorAction Stop
$actual=[FcR76ExactMsiImageRetirement]::RetireSix()
$after=Measure-FcBeforePreflight -Config $c.config
$v=@{status=$(if($actual.Status-ceq'PASS_SIX_EXACT_TEST_IMAGE_PATHS_ABSENT_CHECKED_ORIGINAL_RETIREMENT' -and $after.status-ceq'PASS_BEFORE_KNOWN_ABSENCE_ONLY_NOT_EXECUTION_ADMISSION'){'PASS_SIX_EXACT_OWNED_TEST_TEMP_IMAGES_RETIRED'}else{'FAIL_TEST_IMAGE_RETIREMENT'});before=$before;native=$actual;after=$after;productAutomaticCleanup='GAP_RETAINED_NOT_FIXED_BY_TEST_ONLY_TOOL'}
$text=$v|ConvertTo-Json -Depth 16 -Compress;[IO.File]::WriteAllText((Join-Path $root 'result.json'),$text,[Text.UTF8Encoding]::new($false));$text
if($v.status-cne'PASS_SIX_EXACT_OWNED_TEST_TEMP_IMAGES_RETIRED'){exit 1};exit 0
'''
 p=call('01-retire-exact-original-images',create,50);assert p.returncode in (0,1);v=json.loads(p.stdout);result['actual']=v;result['phaseExit']=p.returncode
 p=call('02-inventory-after-original-parent-return',r'''CheckAcl $c.root "future-classroom-owned-r76-exact-test-images/v1`n";Inventory $c.root|ConvertTo-Json -Depth 8 -Compress''');assert p.returncode==0;inventory=json.loads(p.stdout);m['validate_inventory'](inventory);result['inventory']=inventory
 local=out/'download';local.mkdir();command=['scp','-q','-r','-i',m['KEY'],'-o','BatchMode=yes','-o','ConnectTimeout=8',m['HOST']+':'+root.replace('\\','/'),str(local)+'/'];begun=time.monotonic();p=subprocess.run(command,capture_output=True,timeout=30)
 row=dict(name='03-download-compiler-and-native-receipt-originals',command=command,actualExit=True,exitCode=p.returncode,reaped=True,elapsedSeconds=time.monotonic()-begun)
 for label,data in [('stdout',p.stdout),('stderr',p.stderr)]:path=out/('03-download.'+label+'.log');path.write_bytes(data);row[label]=fact(path)
 result['operations'].append(row);assert p.returncode==0;download=local/root.split('\\')[-1];m['verify_download'](download,inventory);assert json.loads((download/'result.json').read_bytes())==v;result['downloadVerified']=True
 c['inventory']=inventory
 script=r'''CheckAcl $c.root "future-classroom-owned-r76-exact-test-images/v1`n";$now=Inventory $c.root;if($now.files.Count-ne$c.inventory.files.Count -or $now.directories.Count-ne$c.inventory.directories.Count){throw 'MEMBERSHIP_CHANGED'}
foreach($f in $now.files){$old=@($c.inventory.files|Where-Object{$_.path-ceq$f.path});if($old.Count-ne1-or$old[0].bytes-ne$f.bytes-or$old[0].sha256-cne$f.sha256){throw 'BYTES_CHANGED'}}
foreach($f in $c.inventory.files){[IO.File]::Delete((Join-Path $c.root ($f.path.Replace('/','\'))))};foreach($d in @($c.inventory.directories|Sort-Object Length -Descending)){[IO.Directory]::Delete((Join-Path $c.root ($d.Replace('/','\'))),$false)};[IO.Directory]::Delete($c.root,$false)
try{[void][IO.File]::GetAttributes($c.root);throw 'ROOT_STILL_EXISTS'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
@{status='PASS_EXACT_INSTRUMENT_SCRATCH_REMOVED';rootKnownAbsent=$true;files=$c.inventory.files.Count}|ConvertTo-Json -Compress'''
 p=call('04-clean-exact-instrument-compiler-scratch',script);assert p.returncode==0;result['scratchCleanup']=json.loads(p.stdout)
 result['status']='PASS' if v['status']=='PASS_SIX_EXACT_OWNED_TEST_TEMP_IMAGES_RETIRED' and result['phaseExit']==0 else 'FAIL_NATIVE_RETIREMENT_ORIGINAL_RETAINED';result['elapsedSeconds']=time.monotonic()-start;report.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],report=fact(report),native=v['native'],scratchCleanup=result['scratchCleanup'])));return 0 if result['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
