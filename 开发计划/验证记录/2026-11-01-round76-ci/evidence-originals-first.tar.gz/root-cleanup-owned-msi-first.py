"""Root-only exact R76 product-test cleanup after original formal MSI uninstall.
No fresh install, product/cache/Run mutation, process kill or SSH revocation.
"""
from pathlib import Path
import hashlib,json,runpy,subprocess,time,sys
sys.dont_write_bytecode=True
R=Path('/tmp/fc-round76-ci-evidence')
def sha(b):return hashlib.sha256(b).hexdigest()
def fact(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def main():
 report=R/'root-cleanup-owned-msi-first.json';assert not report.exists()
 source=R/'production-msi-continuation-transport-preparation-first/run-owned-continuation-first.py';assert sha(source.read_bytes())=='a499b60afa479023c6761989828aaba8540f409311c903ab3849d1613a9d288c'
 m=runpy.run_path(str(source));p=R/'product-msi-continuation-first/report.json';assert sha(p.read_bytes())=='c315be4f7dcf762cb9140b770cdd115238c73231d7d7e6048e132dc4b2a1d08c'
 v=json.loads(p.read_bytes());old=json.loads(m['FIRST_REPORT'].read_bytes());r=v['phaseResult']
 assert v['status']=='PASS_OWNED_CONTINUATION_PARENT_AND_EXACT_CAPTURE_WIN11_SCRATCH_RETAINED' and v['localSourceUnchanged'] and v['originalFirstFilesUnchanged'] and m['phase_admission'](r)
 expected=v['remoteInventory']['original'];m['validate_inventory'](expected);prefix='Continuation-'+v['continuationNonce'];local_old=m['FIRST_RECEIPT'].parent;local_new=R/'product-msi-continuation-first/download'/prefix
 for row in expected['files']:
  rel=row['path'];path=(local_new/rel[len(prefix)+1:]) if rel.startswith(prefix+'/') else local_old/rel
  f=fact(path);assert (f['bytes'],f['sha256'])==(row['bytes'],row['sha256'])
 before_path=R/'windows-msi-registry-ancestor-before-first.json';before=json.loads(before_path.read_bytes());assert before['exitCode']==0 and all(f['knownAbsent'] for f in before['actual']['facts'])
 c=dict(originalRoot=v['originalRoot'],continuationRoot=v['continuationRoot'],continuationNonce=v['continuationNonce'],sid=m['SID'],msiSha=m['MSI_SHA'],configSha=m['CONFIG_SHA'],configBytes=v['config']['bytes'],firstReceiptSha=m['FIRST_RECEIPT_SHA'],firstReceiptBytes=v['originalFirstReceipt']['bytes'],firstInventory=old['remoteInventory'],expectedInventory=expected)
 script=r'''CheckContinuation;$now=Inventory $c.originalRoot;CompareOriginal $now $true
if($now.files.Count-ne$c.expectedInventory.files.Count -or $now.directories.Count-ne$c.expectedInventory.directories.Count){throw 'EXACT_COMBINED_MEMBERSHIP_REQUIRED'}
foreach($f in $now.files){$old=@($c.expectedInventory.files|Where-Object{$_.path-ceq$f.path});if($old.Count-ne1 -or $old[0].bytes-ne$f.bytes -or $old[0].sha256-cne$f.sha256){throw 'EXACT_COMBINED_BYTES_REQUIRED'}}
foreach($d in $now.directories){if($d-cnotin$c.expectedInventory.directories){throw 'EXACT_COMBINED_DIRECTORIES_REQUIRED'}}
. (Join-Path $c.originalRoot 'ReadOnlyPreflightFunction.ps1')
$cfg=Get-Content -LiteralPath (Join-Path $c.originalRoot 'candidate-inputs.json') -Raw -Encoding UTF8|ConvertFrom-Json
$absence=Measure-FcBeforePreflight -Config $cfg
if($absence.status-cne'PASS_BEFORE_KNOWN_ABSENCE_ONLY_NOT_EXECUTION_ADMISSION'){throw 'POST_UNINSTALL_GLOBAL_ABSENCE_REQUIRED'}
$registry=@();$base=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry32)
try{
 foreach($name in @('Software\FutureClassroom\Installer\Components','Software\FutureClassroom\Installer','Software\FutureClassroom')){
  $key=$null;$empty=$false
  try{$key=$base.OpenSubKey($name,$false);if($null-ne$key){$empty=($key.ValueCount-eq0 -and $key.SubKeyCount-eq0);if(-not$empty){throw 'PROJECT_REGISTRY_ANCESTOR_NOT_EMPTY'}}}finally{if($null-ne$key){$key.Dispose()}}
  if($empty){$base.DeleteSubKey($name,$false)}
  $after=$null;try{$after=$base.OpenSubKey($name,$false);if($null-ne$after){throw 'PROJECT_EMPTY_ANCESTOR_DELETE_READBACK'}}finally{if($null-ne$after){$after.Dispose()}}
  $registry+=@{key=$name;view='Registry32';beforeAbsentBaselinePinned=$true;emptyOnlyDelete=$empty;knownAbsent=$true;recursiveDelete=$false}
 }
}finally{$base.Dispose()}
# Every file has already been downloaded and rechecked against its original receipt.
# Recheck immediately before each exact delete; never follow a reparse point.
$removed=0;$removedBytes=[long]0
foreach($row in $c.expectedInventory.files){$p=Join-Path $c.originalRoot ($row.path.Replace('/','\'));$f=Fact $p;if($f.bytes-ne$row.bytes -or $f.sha256-cne$row.sha256){throw 'PREDELETE_BYTE_CHANGE'};[IO.File]::Delete($p);$removed++;$removedBytes+=$f.bytes}
foreach($dir in @($c.expectedInventory.directories|Sort-Object Length -Descending)){$p=Join-Path $c.originalRoot ($dir.Replace('/','\'));$a=[IO.File]::GetAttributes($p);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0 -or ($a-band[IO.FileAttributes]::Directory)-eq0){throw 'PREDELETE_DIRECTORY_REPARSE'};[IO.Directory]::Delete($p,$false)}
[IO.Directory]::Delete($c.originalRoot,$false)
try{[void][IO.File]::GetAttributes($c.originalRoot);throw 'SCRATCH_STILL_EXISTS'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
$final=Measure-FcBeforePreflight -Config $cfg;if($final.status-cne'PASS_BEFORE_KNOWN_ABSENCE_ONLY_NOT_EXECUTION_ADMISSION'){throw 'FINAL_GLOBAL_ABSENCE_REQUIRED'}
@{status='PASS_EXACT_OWNED_MSI_TEST_RESIDUE_REMOVED';removedFiles=$removed;removedLogicalBytes=$removedBytes;removedDirectories=($c.expectedInventory.directories.Count+1);rootKnownAbsent=$true;predeleteAbsence=$absence;finalAbsence=$final;registryAncestorCleanup=$registry;sharedMsiService='NOT_STOPPED';persistentSsh='NOT_MODIFIED';processKill=$false;productManualDelete=$false;cacheManualDelete=$false;runWrite=$false}|ConvertTo-Json -Depth 12 -Compress
'''
 cmd,feed=m['remote'](script,c);start=time.monotonic();p=subprocess.run(cmd,input=feed,capture_output=True,timeout=45)
 row=dict(status='FAIL_ROOT_EXACT_CLEANUP',controllerSource=fact(Path(__file__)),continuationReport=fact(R/'product-msi-continuation-first/report.json'),originalRegistryAbsence=fact(before_path),command=cmd,stdin={'bytes':len(feed),'sha256':sha(feed)},actualExit=True,exitCode=p.returncode,reaped=True,elapsedSeconds=time.monotonic()-start)
 for label,data in [('stdout',p.stdout),('stderr',p.stderr)]:
  out=R/('root-cleanup-owned-msi-first.'+label+'.log');assert not out.exists();out.write_bytes(data);row[label]=fact(out)
 if p.returncode==0:
  actual=json.loads(p.stdout);row['actual']=actual
  if actual['status']=='PASS_EXACT_OWNED_MSI_TEST_RESIDUE_REMOVED':row['status']='PASS'
 report.write_text(json.dumps(row,indent=2)+'\n');print(json.dumps({'status':row['status'],'report':fact(report),'actual':row.get('actual')}));return 0 if row['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
