"""Root-only finite C#/PS/idle-WMI warmup. Never invokes MSI or a product PE."""
from pathlib import Path
import argparse,base64,datetime,hashlib,json,subprocess,time,uuid
R=Path('/tmp/fc-round76-ci-evidence');D=R/'instrument-warmup-first'
HOST='elior@192.168.10.212';KEY='/config/.local/share/future-classroom-test-access/win11-192.168.10.212'
BOOT="$ErrorActionPreference='Stop';[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()))"
FILES=[R/'production-msi-preparation-first'/n for n in ['ProcessObserver.cs','GateRetirement.cs','ReadOnlyPreflightFunction.ps1']]+[R/'msi-state-preparation-first'/n for n in ['ProductState.cs','ProductState.ps1']]+[R/'msi-runtime-orchestrator-preparation-first/Invoke-ProductionMsiPhases.ps1']
COMMON=r'''$ErrorActionPreference='Stop';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function RootPath {return Join-Path ([IO.Path]::GetFullPath($env:TEMP)) ('FutureClassroom-r76-instrument-'+$c.nonce)}
function Fact($p){$a=[IO.File]::GetAttributes($p);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0 -or ($a-band[IO.FileAttributes]::Directory)-ne0){throw 'REGULAR_NO_REPARSE'};return @{bytes=[long]([IO.FileInfo]::new($p).Length);sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function CheckRoot($root){if($root-cne$c.root -or [IO.Path]::GetFileName($root)-cne('FutureClassroom-r76-instrument-'+$c.nonce)){throw 'EXACT_ROOT'};$a=[IO.File]::GetAttributes($root);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0){throw 'ROOT_REPARSE'};if([IO.File]::ReadAllText((Join-Path $root '.owner'))-cne"future-classroom-owned-r76-instrument-warmup/v1`n"){throw 'OWNER_MARKER'};$acl=[IO.Directory]::GetAccessControl($root);if(-not$acl.AreAccessRulesProtected -or $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-cne$c.sid){throw 'EXACT_PROTECTED_OWNER'};$rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));if($rules.Count-ne2 -or @($rules|Where-Object{$_.IdentityReference.Value-notin@($c.sid,'S-1-5-18') -or $_.AccessControlType-ne'Allow' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count){throw 'ONLY_USER_SYSTEM_DACL'}}
function Inventory($root){CheckRoot $root;$files=@();$dirs=@();$q=[Collections.Generic.Queue[string]]::new();$q.Enqueue($root);while($q.Count){$dir=$q.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){$a=[IO.File]::GetAttributes($p);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0){throw 'INVENTORY_REPARSE'};$rel=$p.Substring($root.Length+1).Replace('\','/');if(($a-band[IO.FileAttributes]::Directory)-ne0){$dirs+=$rel;$q.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256}};if($files.Count-gt128 -or $dirs.Count-gt16){throw 'INVENTORY_BOUND'}}};return @{files=$files;directories=$dirs}}
'''
CREATE=r'''if($PSVersionTable.PSVersion.Major-ne5 -or [IntPtr]::Size-ne8){throw 'DESKTOP_PS51_X64_REQUIRED'};$w=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$w.User;$c.sid=$sid.Value}finally{$w.Dispose()};$root=RootPath
try{[void][IO.File]::GetAttributes($root);throw 'ROOT_ALREADY_EXISTS'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
$cursor=[IO.Path]::GetDirectoryName($root);while($cursor){$a=[IO.File]::GetAttributes($cursor);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0 -or ($a-band[IO.FileAttributes]::Directory)-eq0){throw 'ANCESTOR_ALIAS'};$cursor=[IO.Path]::GetDirectoryName($cursor)}
[void][IO.Directory]::CreateDirectory($root);$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false);foreach($s in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($s,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))};[IO.Directory]::SetAccessControl($root,$acl);[IO.File]::WriteAllText((Join-Path $root '.owner'),"future-classroom-owned-r76-instrument-warmup/v1`n",[Text.UTF8Encoding]::new($false));$c.root=$root;CheckRoot $root
@{status='CREATED_ONLY_OWNED_INSTRUMENT_ROOT';root=$root;sid=$c.sid;nonce=$c.nonce;powershell=$PSVersionTable.PSVersion.ToString();localAppData=[Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)}|ConvertTo-Json -Compress
'''
WARM=r'''CheckRoot $c.root;foreach($row in $c.files){$f=Fact (Join-Path $c.root $row.name);if($f.sha256-cne$row.sha256 -or $f.bytes-ne$row.bytes){throw 'PINNED_UPLOADED_SOURCE'}}
$r=@{status='FAIL_INSTRUMENT_WARMUP';scope='Only actual C# compilation, PowerShell parsing and idle WMI subscription. No product PE/MSI/gate operation; prefix hash is an explicit inert expected-image model, not an overlay/admission proof.';compilation=@();parsing=@();errors=@();observer=$null;productMSI='NOT_RUN';normalRustHelper='NOT_RUN'}
$oldTemp=$env:TEMP;$oldTmp=$env:TMP;$temp=Join-Path $c.root 'compiler-temp';[void][IO.Directory]::CreateDirectory($temp);$env:TEMP=$temp;$env:TMP=$temp
try{
 foreach($name in @('ProcessObserver.cs','GateRetirement.cs','ProductState.cs')){
  try{if($name-ceq'ProcessObserver.cs'){Add-Type -LiteralPath (Join-Path $c.root $name) -ReferencedAssemblies @('System.dll','System.Core.dll','System.Management.dll') -ErrorAction Stop}else{Add-Type -LiteralPath (Join-Path $c.root $name) -ErrorAction Stop};$r.compilation+=@{name=$name;status='ACTUAL_COMPILED'}}catch{$r.compilation+=@{name=$name;status='FAIL';error=[string]$_};$r.errors+=[string]$_}
 }
 foreach($name in @('ReadOnlyPreflightFunction.ps1','ProductState.ps1','Invoke-ProductionMsiPhases.ps1')){$tokens=$null;$parseErrors=$null;[void][Management.Automation.Language.Parser]::ParseFile((Join-Path $c.root $name),[ref]$tokens,[ref]$parseErrors);$r.parsing+=@{name=$name;errorCount=@($parseErrors).Count;errors=@($parseErrors|ForEach-Object{@{message=$_.Message;line=$_.Extent.StartLineNumber;column=$_.Extent.StartColumnNumber}})};if(@($parseErrors).Count){$r.errors+='POWERSHELL_PARSE_FAILURE_'+$name}}
 if($r.errors.Count-eq0){$o=$null;try{$o=[FcR76ProcessObserver]::new($c.prefixSha,[int]$c.prefixBytes,$c.sid,10000);$r.idleSnapshot=$o.Snapshot();$r.observer=$o.FinishAndClose();$o=$null;if(-not$r.observer.WmiStarted -or -not$r.observer.Closed -or @($r.observer.Processes).Count -or @($r.observer.Errors).Count){throw 'IDLE_WMI_OR_CLOSE_UNKNOWN'}}catch{$r.errors+=[string]$_}finally{if($null-ne$o){try{$r.observer=$o.FinishAndClose()}catch{$r.errors+=[string]$_}}}}
 if($r.errors.Count-eq0){$r.status='PASS_ACTUAL_CSHARP_COMPILE_PS_PARSE_AND_IDLE_WMI_ONLY'}
}finally{$env:TEMP=$oldTemp;$env:TMP=$oldTmp}
$r.inventory=Inventory $c.root;$r|ConvertTo-Json -Depth 12 -Compress
if($r.status-cne'PASS_ACTUAL_CSHARP_COMPILE_PS_PARSE_AND_IDLE_WMI_ONLY'){exit 1}
'''
DELETE=r'''CheckRoot $c.root;$now=Inventory $c.root;if($now.files.Count-ne$c.inventory.files.Count -or $now.directories.Count-ne$c.inventory.directories.Count){throw 'MEMBERSHIP_CHANGED'};foreach($row in $now.files){$old=@($c.inventory.files|Where-Object{$_.path-ceq$row.path});if($old.Count-ne1 -or $old[0].bytes-ne$row.bytes -or $old[0].sha256-cne$row.sha256){throw 'ORIGINAL_FILE_BYTES_CHANGED'}};foreach($dir in $now.directories){if($dir-cnotin$c.inventory.directories){throw 'DIRECTORY_CHANGED'}}
foreach($row in $now.files){if($row.path-cne'.owner'){[IO.File]::Delete((Join-Path $c.root ($row.path.Replace('/','\'))))}};foreach($dir in @($now.directories|Sort-Object Length -Descending)){[IO.Directory]::Delete((Join-Path $c.root ($dir.Replace('/','\'))),$false)};[IO.File]::Delete((Join-Path $c.root '.owner'));[IO.Directory]::Delete($c.root,$false)
try{[void][IO.File]::GetAttributes($c.root);throw 'ROOT_STILL_EXISTS'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
@{status='REMOVED_EXACT_WARMUP_ROOT';nonce=$c.nonce;knownAbsent=$true}|ConvertTo-Json -Compress
'''
def sha(b):return hashlib.sha256(b).hexdigest()
def need(v,c):
    if not v:raise AssertionError(c)
def fact(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def remote(script,c):
    source=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+COMMON+script).encode()
    return ['ssh','-i',KEY,'-o','BatchMode=yes','-o','ConnectTimeout=8',HOST,'powershell.exe','-NoLogo','-NoProfile','-NonInteractive','-EncodedCommand',base64.b64encode(BOOT.encode('utf-16-le')).decode()],source
def main():
    p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');a=p.parse_args()
    if not a.execute:print(json.dumps(dict(status='PREPARED_INSTRUMENT_WARMUP_ONLY_NOT_RUN')));return 0
    need((R/'.owner').read_bytes()==b'future-classroom-owned-r76-ci-evidence/v1\n' and not D.exists(),'EXACT_NEW_OWNED_ROUND_ROOT');D.mkdir();(D/'.owner').write_text('future-classroom-owned-r76-local-instrument-warmup/v1\n')
    inputs=[fact(p) for p in FILES];nonce=uuid.uuid4().hex;c=dict(nonce=nonce,sid=None,root=None,prefixSha='a01e5eb72667a398771640928d21b2ae6d97a9a9555f657aa5867f00d1b39d3d',prefixBytes=393728,files=[dict(name=Path(r['path']).name,bytes=r['bytes'],sha256=r['sha256']) for r in inputs])
    result=dict(status='RUNNING',scope='COMPILE_PARSE_IDLE_WMI_ONLY_NO_MSI_OR_PRODUCT_PE',startedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),originalWholeBudgetSeconds=180,inputs=inputs,operations=[],cleanup='NOT_RUN');report=D/'warmup-first.json';report.write_text(json.dumps(result,indent=2)+'\n');start=time.monotonic();created=False;inventory=None
    def call(name,cmd,feed=None,limit=30):
        remaining=180-(time.monotonic()-start);need(remaining>0,'ORIGINAL_WARMUP_BUDGET');begin=time.monotonic();out=b'';err=b'';code=None
        try:
            cp=subprocess.run(cmd,input=feed,capture_output=True,timeout=min(remaining,limit));code=cp.returncode;out=cp.stdout;err=cp.stderr
        except subprocess.TimeoutExpired as e:out=e.stdout or b'';err=e.stderr or b''
        row=dict(name=name,command=cmd,exitCode=code,actualExit=code is not None,elapsedSeconds=time.monotonic()-begin)
        if feed is not None:row['stdin']=dict(bytes=len(feed),sha256=sha(feed))
        for label,b in [('stdout',out),('stderr',err)]:
            dest=D/(name+'.'+label+'.log');dest.write_bytes(b);row[label]=fact(dest)
        result['operations'].append(row);report.write_text(json.dumps(result,indent=2)+'\n');return code,out
    try:
        cmd,feed=remote(CREATE,c);code,out=call('01-create',cmd,feed,15);need(code==0,'CREATE_EXIT0');before=json.loads(out);created=True;c.update(root=before['root'],sid=before['sid']);result['before']=before
        code,_=call('02-upload',['scp','-q','-i',KEY,'-o','BatchMode=yes','-o','ConnectTimeout=8',*[str(p) for p in FILES],HOST+':'+c['root'].replace('\\','/')+'/'],limit=30);need(code==0,'UPLOAD_EXIT0')
        cmd,feed=remote(WARM,c);code,out=call('03-compile-parse-idle',cmd,feed,75);warm=json.loads(out);result['actual']=warm;inventory=warm.get('inventory');need(code==0 and warm['status']=='PASS_ACTUAL_CSHARP_COMPILE_PS_PARSE_AND_IDLE_WMI_ONLY','ACTUAL_WARMUP_PASS');result['status']='PASS_INSTRUMENT_WARMUP_ONLY'
    except Exception as e:result.update(status='FAIL_INSTRUMENT_WARMUP',errorKind=type(e).__name__,reason=str(e) if isinstance(e,AssertionError) else 'TRANSPORT_OR_CAPTURE_FAILURE')
    finally:
        if created:
            try:
                if inventory is None:
                    cmd,feed=remote('Inventory $c.root|ConvertTo-Json -Depth 8 -Compress',c);code,out=call('90-inventory',cmd,feed,15);need(code==0,'ACTUAL_OWNED_INVENTORY');inventory=json.loads(out);result['recoveryInventory']=inventory
                cmd,feed=remote(DELETE,dict(c,inventory=inventory));code,out=call('99-cleanup',cmd,feed,20);clean=json.loads(out);result['cleanupActual']=clean;need(code==0 and clean['knownAbsent'] is True and clean['nonce']==nonce,'EXACT_WARMUP_ROOT_REMOVED');result['cleanup']='PASS'
            except Exception as e:result.update(cleanup='FAIL_OR_UNKNOWN_RETAINED',cleanupError=type(e).__name__)
        need(inputs==[fact(p) for p in FILES],'LOCAL_ORIGINAL_SOURCES_UNCHANGED')
    result.update(elapsedSeconds=time.monotonic()-start,actualControllerReturned=True);report.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],cleanup=result['cleanup'],report=fact(report))));return 0 if result['status']=='PASS_INSTRUMENT_WARMUP_ONLY' and result['cleanup']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
