R76 preparation only. Actual source40 is NOT_KNOWN_YET; dispatch, poll, download, CI and runtime status are NOT_RUN. This owned directory is separate from R75 and contains no active R74 temporary-root references. The immutable actual R74 main archive supplied the five templates; templates-first.json and the per-tool diffs retain their exact provenance.

Root first finishes, commits and pushes the complete R75 source/evidence batch. Supply that actual lowercase40 HEAD as SOURCE_SHA. The tools do not invent or hardcode it. Each workflow is dispatched separately once:

```sh
python3 -B /tmp/fc-round76-ci-evidence/record-dispatch-once.py --source-sha "$SOURCE_SHA" --workflow windows-msvc.yml --execute
python3 -B /tmp/fc-round76-ci-evidence/record-dispatch-once.py --source-sha "$SOURCE_SHA" --workflow windows-win7-msvc.yml --execute
```

Without --execute, tools print NOT_RUN_PREPARATION_ONLY and stop before credentials, Git or network. With it, dispatch checks exact main branch, clean local HEAD and read-only origin main SHA, then the official API current ref/workflow and existing same-source workflow_dispatch runs. A present dispatch/operation record stops reuse. One POST site performs the exact official dispatch with ref main and input source_sha; the request-about-to-send record is durable before sending. An uncertain HTTP/transport result, timeout or unidentified run is retained and is never authorization to redispatch. No push, cancellation or rerun is implemented.

Prefer the connected GitHub read tools for jobs and artifacts: github.fetch_workflow_run_jobs and github.fetch_workflow_run_artifacts for the exact retained run ID on NevermoreN/future-classroom. Save only non-secret official API metadata: source SHA, workflow/run IDs, statuses/conclusions, artifact ID/name/bytes/digest/expiry. The available github.fetch_commit_workflow_runs wrapper is documented as PR-triggered-only, so the retained R74 one-GET fallback is appropriate for the exact manual run when no exact plugin run lookup exists:

```sh
python3 -B /tmp/fc-round76-ci-evidence/observe-run-once.py --baseline modern --label observation1 --source-sha "$SOURCE_SHA" --run-id "$MODERN_RUN_ID" --execute
```

Use baseline win7 for the second workflow and a fresh alphanumeric label per observation. Polling is read-only and validates the retained dispatch identity. A queued/in_progress observation is not CI PASS; completed/conclusion success must be separately confirmed before artifact use. The root owns scheduling and read-only plugin calls; no autonomous loop dispatches or reruns work.

Prefer the GitHub artifact download connector when its bounded transfer is sufficient. If its actual limitation requires the previously verified official byte-transfer fallback, retain that original attempt, confirm matching completed-success run and official artifact metadata first, then use:

```sh
python3 -B /tmp/fc-round76-ci-evidence/record-download-official-second.py --baseline modern --source-sha "$SOURCE_SHA" --run-id "$MODERN_RUN_ID" --artifact-id "$ARTIFACT_ID" --expected-bytes "$ARTIFACT_BYTES" --expected-sha256 "$ARTIFACT_SHA256" --execute
```

The original1200s overall/25s socket/512MiB bounds remain. Original artifact ZIP bytes are create-new, size/SHA-checked and ZIP-CRC checked; this is not product acceptance. Credentials are obtained by the existing git credential helper only in memory. Authenticated API requests do not follow redirects. The one allowed artifact redirect is HTTPS on the exact retained Azure/GitHub host suffix allowlist, with no userinfo/fragment/non443 port. It is opened as a fresh unauthenticated nonredirecting request. Tokens and signed redirect URLs are never printed, persisted, hashed or forwarded to a redirected host. The raw response bytes here are ordinary GitHub JSON/ZIP, not credentials. Do not copy a connector's temporary signed URL into evidence.

Only the preparation's AST and default no-execute/negative contracts have run. The a*40 value in those model checks is expressly not a candidate source fact. No normal products or artifact parser were prepared ahead of the actual same-source dual MSVC bytes. Root will reuse the archived R74 actual static/audit machinery with the future real artifacts, and independently validate both normal app/helper and all actual harness metadata.
