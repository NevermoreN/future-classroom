R76 compact archive preparation — NOT EXECUTED

Use archive-evidence-packed-first.py. The earlier archive-evidence-first.py per-file draft is retained only as an
unexecuted preparation/reference: its proposed1932paths would violate the remaining20000Git-path headroom and it
must not be used. Exact current snapshot was1995unpruned originals,1932eligible text and63excluded payloads.

Future root-only command:
python3 -B /tmp/fc-round76-ci-evidence/archive-preparation-first/archive-evidence-packed-first.py \
 --source-base-git 3bad94949012e840cd1dda6a73a0ea1ddb067697 \
 --acceptance-report <root-relative actual final independent report> --expected-acceptance-sha256 <actual64hex> \
 --expected-acceptance-status <exact final PASS_R76_scope> \
 --readonly-audit <root-relative actual final readonly report> --expected-readonly-sha256 <actual64hex> \
 --modern-static-audit ui-preparation-first/modern-independent-first.json --expected-modern-static-sha256 <actual64hex> \
 --win7-static-audit ui-preparation-first/win7-independent-first.json --expected-win7-static-sha256 <actual64hex> \
 --promote <root-relative key original report> [--promote <another report> ...]

Default only prints preparation with no payload read/archive. Add --root-controllers-terminal --execute only after
root freezes all source/controller membership and confirms final actual terminal outcomes. Missing/incomplete/running
final acceptance/readonly input yields WAIT, without creating archive. All hashes/limits remain original; no CI dispatch,
Windows, network, Cargo, PE execution, Git mutation or deletion. Optional exact public-certificate allowlist remains.
SOURCE=/tmp/fc-round76-ci-evidence, DEST=main/开发计划/验证记录/2026-11-01-round76-ci, exact root/controller owners checked.

Capacity: at most24unique --promote originals, plus evidence-originals-first.tar.gz/index/receipt = at most27 Git paths.
All retained text/JSON/scripts/rawFAIL/RUNNING/log originals are in one deterministic gzip/PAX tar, including the same
promoted originals. Each tar member has original relative path/bytes/SHA in index. Only regular members, uid/gid0,
mode0600,mtime0,uname/gname empty; gzip filename empty/mtime0. Tar preserves original bytes, not original file ACL/mode.
Objdump raw text is losslessly compressed as tar members by the one gzip stream, never normalized or summarized.
Optional promoted reports are exact duplicate raw bytes for direct links. Archive index and final verification receipt
are standalone to avoid a circular container hash. Index has per-source path/tarMember and optional promoted path;
archiveContainer records full compressed size/SHA. storedBytes excludes the index itself, whose SHA is printed externally.
Independent second and final rereads verify every source/member/promoted byte, exact tar/destination membership and
excluded identities; credential scan covers retained source, actual decompressed members and promoted duplicates.
Only declared base64/encodedCommand JSON streams and nested JSON string views are decoded. MZ classification needs
an actual bounded PE header at offset0, not a text/test label. ValidPE/CFBF/ZIP/ELF/AR/compressed payloads and compiled
suffixes (.msi/.exe/.dll/.zip/.deb etc) are identity-only excluded, never committed. Unknown encodings/binary embedded
payloads/credential findings fail; strict CP936 PowerShellCLIXML decoder reused without lossy replacement.

Whole tools, msi-checkout-preparation-first/checkout-3bad949-first, web-build-first/source and npm-cache subtrees are
pruned before recursion: not raw archived and not member hashed. The original542source/65Web ledgers and full CI
producer/provenance reports remain exact originals.48actual CIPE identities are independently checked and also in
unpruned exclusions; seven explicit tools/packages/*.deb originals are separately hashed despite tools prune. No other
cache/WT member is read/hash-indexed. Original MSI/probeZIP/duplicate downloaded payloads are excluded with identities.
Final index fields: schemaVersion3,files,archiveContainer,promotedOriginals,excludedCompiledPayloads,
explicitPrunedPackageIdentities,acceptedCiPeIdentities,prunedSubtrees,verificationReceipt,originalFiles/Bytes,
storedBytes,archiveFileCount. files rows use storage tar_gzip_original_bytes,archivePath common tar,tarMember same source;
optional promotedArchivePath same relative path. Final receipt row is exact_original_bytes at standalone path.

Actual original product firstFAIL, subsequent independent continuation/cleanup and metadata UNKNOWN qualifiers stay
unaltered. Source3bad denotes original committedCI/normalPE; localB5builder change retains separate raw provenance.
Archive never changes or extends actual Win11/Win7-target/Win7OS/Win10OS/MSI acceptance scope.
Actual prepare-mode default and a tiny in-memory deterministic tar roundtrip passed; no real archive was executed.
