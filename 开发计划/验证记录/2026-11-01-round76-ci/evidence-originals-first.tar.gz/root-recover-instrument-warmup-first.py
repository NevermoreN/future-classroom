"""Fresh bounded cleanup of exact owned warmup residue; original FAIL is unchanged."""
from pathlib import Path
import hashlib,json,runpy,subprocess,time
R=Path('/tmp/fc-round76-ci-evidence');D=R/'instrument-warmup-recovery-first'
M=runpy.run_path(str(R/'root-instrument-warmup-first.py'))
original=json.loads((R/'instrument-warmup-first/warmup-first.json').read_bytes())
assert original['status']=='FAIL_INSTRUMENT_WARMUP' and original['actualControllerReturned'] is True
assert not D.exists();D.mkdir();(D/'.owner').write_text('future-classroom-owned-r76-instrument-warmup-recovery/v1\n')
before=original['before'];c=dict(root=before['root'],sid=before['sid'],nonce=before['nonce'])
old=original['actual']['inventory'];old_files={r['path']:r for r in old['files']}
result=dict(status='RUNNING',scope='Only exact existing nonce-owned warmup scratch. Native product/MSI not run; original compile failure remains FAIL.',originalWarmupReportSha256=hashlib.sha256((R/'instrument-warmup-first/warmup-first.json').read_bytes()).hexdigest(),operations=[])
def call(name,script,config):
    cmd,feed=M['remote'](script,config);t=time.monotonic();p=subprocess.run(cmd,input=feed,capture_output=True,timeout=20)
    row=dict(name=name,command=cmd,actualExit=True,exitCode=p.returncode,elapsedSeconds=time.monotonic()-t,stdinSha256=hashlib.sha256(feed).hexdigest())
    for k,b in [('stdout',p.stdout),('stderr',p.stderr)]:
        path=D/(name+'.'+k+'.log');path.write_bytes(b);row[k]=dict(path=str(path),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
    result['operations'].append(row);assert p.returncode==0,name;return json.loads(p.stdout)
try:
    now=call('01-reinventory','Inventory $c.root|ConvertTo-Json -Depth 8 -Compress',c)
    assert all(old_files.get(r['path'])==r for r in now['files'])
    assert set(now['directories'])<=set(old['directories'])
    have={r['path'] for r in now['files']};assert {Path(r['path']).name for r in original['inputs']}|{'.owner'}<=have
    result.update(previousInventory=old,currentInventory=now,disappearedOwnedCompilerFiles=[r for r in old['files'] if r['path'] not in have],qualification='After original PowerShell/CodeDom returned, some owned compiler temporaries disappeared automatically. No new member or changed byte is accepted; required original uploads/owner all remain exact.')
    clean=call('02-exact-cleanup',M['DELETE'],dict(c,inventory=now));assert clean['knownAbsent'] is True and clean['nonce']==c['nonce']
    result.update(status='PASS_EXACT_WARMUP_RESIDUE_REMOVED_ORIGINAL_COMPILE_FAIL_UNCHANGED',cleanup=clean)
except Exception as e:result.update(status='FAIL_RETAIN_UNKNOWN_WARMUP_RESIDUE',errorKind=type(e).__name__)
(D/'recovery-first.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],report=str(D/'recovery-first.json'))))
raise SystemExit(0 if result['status'].startswith('PASS_') else 1)
