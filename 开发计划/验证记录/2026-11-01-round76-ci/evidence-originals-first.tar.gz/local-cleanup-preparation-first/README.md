# R76 local cleanup controller: prepared, not executed

Only `cleanup-round76-first.py` is the frozen executable source. Preparation checks Python AST only; no default run, Git mutation, process scan, cleanup or Windows access has occurred.

Root must first finish/freeze R76 evidence, actually create and review the compact archive, copy this exact script into main and commit the verified source/archive/controller. Then explicitly provide:

```bash
python3 /tmp/fc-round76-cleanup-controller-first/cleanup-round76-first.py \
  --commit <actual committed 40hex> \
  --index '/workspace/共享/Eliora/未来教室计划/开发计划/验证记录/2026-11-01-round76-ci/archive-index-first.json' \
  --expected-index-sha256 <actual64hex> \
  --archive '/workspace/共享/Eliora/未来教室计划/开发计划/验证记录/2026-11-01-round76-ci/evidence-originals-first.tar.gz' \
  --expected-archive-sha256 <actual64hex> \
  --controller-committed-path '<main-relative exact committed copy of this script>' \
  --all-controllers-reaped --execute
```

Without `--execute` it returns PREPARED_NO_ACTIONS before input or state inspection. Actual commit/index/container pins and controller-copy path remain unknown until root's actual archive and commit. No placeholder is accepted as success. The one actual receipt is create-new main `开发计划/验证记录/2026-11-01-round76-cleanup-first.json`, for root's later closure commit; existing receipt is never overwritten.

Schema is UI packed index3: status `ORIGINAL_BYTES_ARCHIVED_IN_GZIP_TAR`, tar original file rows, standalone verification receipt, promoted originals, container and index, full excluded payload identities, seven explicitly read Debian packages,48 CI PE identities, and the four explicit pruned subtrees. Reopens every archived original against source and tar member bytes/SHA, checks tar regular-member complete set/fixed metadata, promoted/receipt byte equality, exact archive tree, and committed Git blobs plus current bytes for every archive file, exact B5 source3 and this controller copy. Nonpruned source file set must equal archived originals plus excluded rows. Unpruned symlink or unknown special entries fail closed. Excluded payloads are rehashed; pruned tools/Web/npm cache/worktree receive own-scope/marker and nonfollowing metadata inventory checks, not an invented per-leaf archive requirement.

Only `/tmp/fc-round76-ci-evidence` and its exact registered detached `msi-checkout-preparation-first/checkout-3bad949-first` are deletion targets. Original base3bad, detached registration and command-local autocrlf clean status are required. Root confirms all original controllers reaped; a separate `/proc` scan excludes self/ancestors and refuses related active processes. It does not kill any such process. Actual registered worktree removal uses normal `git worktree remove` without force or branch deletion. Only the removed worktree subtree and its parent's directory metadata may change before the remaining root is removed. Any uncovered delta retains the remainder with failure.

Final removal walks owned root bottom-up without following symlinks; links are unlinked, regular files unlinked, known directories removed without recursive-follow behavior. Success reports regular-file counts and logical bytes, including exact pre-removal worktree membership; it makes no claim of physical disk-space reclamation. Failure after action starts explicitly says so and never claims no deletion. Main repository/target/global caches/intended ZIPs and active external roots are outside both targets. The persistent SSH private key is checked by lstat for regular0600 metadata only; its contents are not read or hashed. No Windows, service, credentials or school data operations exist. This independent controller root stays outside the deletion scope, for root's subsequent archival/closure handling.
