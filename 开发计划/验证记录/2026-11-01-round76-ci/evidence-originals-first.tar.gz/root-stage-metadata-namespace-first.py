"""Stage ten actual accepted CI members; includes original Cargo metadata, no ZIP."""
from pathlib import Path
import hashlib,json,shutil,stat
R=Path('/tmp/fc-round76-ci-evidence');AUDIT=R/'ui-preparation-first/win7-independent-first.json';SRC=R/'ui-preparation-first/win7-artifact-original';D=R/'metadata-ci-namespace-first'
def sha(b):return hashlib.sha256(b).hexdigest()
def fact(p):
    assert stat.S_ISREG(p.lstat().st_mode);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
assert (R/'.owner').read_bytes()==b'future-classroom-owned-r76-ci-evidence/v1\n'
assert sha(AUDIT.read_bytes())=='36ea9d1547ba3dec8d4cf5c53c92d57878ee37cc8095df17bcffde3dcb663ef1'
audit=json.loads(AUDIT.read_bytes());assert audit['status']=='PASS_STATIC_ONLY_RUNTIME_NOT_RUN' and audit['sourceSha']=='3bad94949012e840cd1dda6a73a0ea1ddb067697' and audit['baseline']=='Win7' and audit['runId']==41315385139
members={r['path']:r for r in audit['members']};assert len(members)==len(audit['members'])
names=['artifact-sha256.json','result.json','input-sha256.json','input-sha256-after.json','executables.json','logs/product-compile.stdout.log','logs/lifecycle-compile.stdout.log','logs/cargo-metadata.stdout.log','product/fc-bootstrap/fc-bootstrap.exe','product/fc-bootstrap/fc-installer-lifecycle.exe']
plan=[]
for name in names:
    source=SRC/('programs' if name.endswith('.exe') else 'raw')/name;f=fact(source);row=members[name];assert f['bytes']==row['bytes'] and f['sha256']==row['sha256'];plan.append(dict(member=name,source=f))
assert not D.exists();D.mkdir();(D/'.owner').write_text('future-classroom-owned-r76-exact-metadata-ci-namespace/v1\n')
result=dict(status='RUNNING',sourceSha=audit['sourceSha'],runId=audit['runId'],acceptedAudit=fact(AUDIT),origin='TEN_ORIGINAL_CI_MEMBERS_NO_LOCAL_PACKAGE_ZIP',mappings=[])
try:
    for row in plan:
        dest=D/row['member'];dest.parent.mkdir(parents=True,exist_ok=True)
        with dest.open('xb') as out:out.write(Path(row['source']['path']).read_bytes())
        f=fact(dest);assert f['bytes']==row['source']['bytes'] and f['sha256']==row['source']['sha256'] and fact(Path(row['source']['path']))==row['source'];result['mappings'].append(dict(**row,destination=f))
    r=json.loads((D/'result.json').read_bytes());assert r['status']=='COMPILE_CHECKS_PASSED_RUNTIME_NOT_RUN' and r['baseline']=='Win7' and r['target']=='i686-win7-windows-msvc' and r['source_sha']==r['dispatch_source_sha']==audit['sourceSha']
    command=[s for s in r['commands'] if s['name']=='cargo-metadata'];assert len(command)==1 and command[0]['passed'] is True and command[0]['exit_code']==0 and command[0]['parent_exited'] is True and command[0]['stdout_sha256']==fact(D/'logs/cargo-metadata.stdout.log')['sha256']
    result.update(status='PASS_TEN_EXACT_ORIGINAL_CI_MEMBERS_ONLY_NOT_MSI',memberCount=10)
finally:
    (R/'metadata-ci-namespace-first-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(status=result['status'],memberCount=len(result['mappings']),namespace=str(D))))
