#!/usr/bin/env python3
"""R76 exact evidence archive + independent source reread + decoded secret scan.
Only owned new archive files and this root's new verification receipt are written.
No removal, Git mutation, source change, Windows, SSH, Cargo or network operation.
"""
from pathlib import Path
import argparse
import base64
import datetime
import gzip
import hashlib
import json
import re
import stat
import sys
import ssl
import subprocess
import struct
import tarfile
import io
import xml.etree.ElementTree as ET

SOURCE=Path('/tmp/fc-round76-ci-evidence')
DEST=Path('/workspace/共享/Eliora/未来教室计划/开发计划/验证记录/2026-11-01-round76-ci')
RECEIPT='archive-verification-first.json'
CONTROLLER=SOURCE/'archive-preparation-second'
EXACT_SOURCE='3bad94949012e840cd1dda6a73a0ea1ddb067697'
PRUNE_RELATIVE={'tools','msi-checkout-preparation-first/checkout-3bad949-first','web-build-first/source','web-build-first/npm-cache','web-build-first/process-temp/node-compile-cache'}
PRUNE_NAMES={'node_modules','__pycache__','target','.cache','.npm-cache'}
EXCLUDED_SUFFIXES={'.exe','.zip','.pdb','.dll','.lib','.rlib','.rmeta','.pyc','.db','.sqlite','.sqlite3','.cache','.obj','.o','.a','.so','.dylib','.wasm','.7z','.tar','.msi','.msp','.msm','.deb','.cab','.gz','.xz','.bz2','.bin','.nupkg'}
CERTIFICATES={}
CERT_SUFFIXES={'.pem','.crt','.cer','.der'}
PRIVATE_SUFFIXES={'.key','.pfx','.p12'}
COMPRESS=re.compile(r'.*objdump[^/]*\.stdout\.log')
PATTERNS={
 'private-key-pem':re.compile(r'-----BEGIN (?:OPENSSH |RSA |EC |DSA |ENCRYPTED )?PRIVATE KEY-----\s+[A-Za-z0-9+/=\s]{32,}-----END (?:OPENSSH |RSA |EC |DSA |ENCRYPTED )?PRIVATE KEY-----'),
 'github-token':re.compile(r'(?<![A-Za-z0-9])(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})(?![A-Za-z0-9])'),
 'openai-secret':re.compile(r'(?<![A-Za-z0-9])sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{24,}'),
 'aws-access-key':re.compile(r'(?<![A-Z0-9])(?:AKIA|ASIA)[A-Z0-9]{16}(?![A-Z0-9])'),
 'bearer-secret':re.compile(r'(?i)authorization\s*[=:]\s*[\x22\x27]?Bearer\s+[A-Za-z0-9._~-]{24,}'),
 'basic-secret':re.compile(r'(?i)authorization\s*[=:]\s*[\x22\x27]?Basic\s+[A-Za-z0-9+/]{16,}={0,2}'),
 'signed-download-url':re.compile(r'(?i)https?://[^\s\x22\x27<>]{5,}[?&](?:sig|signature|x-amz-signature)=[A-Za-z0-9%_+/-]{20,}'),
 'session-cookie-bearer':re.compile(r'__Host-FutureClassroom=[0-9a-fA-F]{64}'),
 'json-issued-web-secret':re.compile(r'(?i)[\x22\x27](?:csrf|pollSecret|sessionCookie|accessToken|refreshToken)[\x22\x27]\s*:\s*[\x22\x27][A-Za-z0-9_./+=-]{32,}[\x22\x27]'),
 'json-password-value':re.compile(r'(?i)[\x22\x27]password[\x22\x27]\s*:\s*[\x22\x27][^\x22\x27\n]{12,128}[\x22\x27]'),
 'potential-pairing-short-code':re.compile(r'(?i)\\?[\x22\x27]pairingCode\\?[\x22\x27]\s*:\s*\\?[\x22\x27][0-9]{8}\\?[\x22\x27]'),
}

def need(v,m):
 if not v:raise AssertionError(m)
def sha(d):return hashlib.sha256(d).hexdigest()
def original(path):
 need(stat.S_ISREG(path.lstat().st_mode),'nonregular original '+str(path))
 need(path.suffix.lower() not in PRIVATE_SUFFIXES,'private material forbidden by filename; contents not read '+str(path))
 if path.suffix.lower() in CERT_SUFFIXES:need(path.relative_to(SOURCE).as_posix() in CERTIFICATES,'unlisted certificate forbidden '+str(path))
 data=path.read_bytes()
 if path.suffix.lower() in CERT_SUFFIXES:public_certificate(path,data)
 return data,{'path':path.relative_to(SOURCE).as_posix(),'bytes':len(data),'sha256':sha(data)}
def write_new(path,data):
 path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('xb') as stream:stream.write(data)
 need(path.read_bytes()==data,'write readback mismatch '+str(path))
def as_json(data):
 return json.loads(data.decode('utf-8-sig'))
def valid_pe(data):
 if len(data)<64 or not data.startswith(b'MZ'):return False
 offset=int.from_bytes(data[60:64],'little')
 if offset<64 or offset>len(data)-24 or data[offset:offset+4]!=b'PE\0\0':return False
 machine,sections=struct.unpack_from('<HH',data,offset+4);optional=struct.unpack_from('<H',data,offset+20)[0];characteristics=struct.unpack_from('<H',data,offset+22)[0];start=offset+24
 if machine not in (0x14c,0x8664,0xaa64) or not 1<=sections<=96 or optional<96 or start+optional+40*sections>len(data) or not characteristics&2:return False
 return struct.unpack_from('<H',data,start)[0] in (0x10b,0x20b)
def binary_magic(data):
 return valid_pe(data) or data.startswith((bytes.fromhex('d0cf11e0a1b11ae1'),b'PK\x03\x04',b'PK\x05\x06',b'PK\x07\x08',b'\x7fELF',b'!<arch>\n',b'\x1f\x8b',b'\xfd7zXZ\x00',b'7z\xbc\xaf\x27\x1c'))
def excluded(path,data=None):
 return path.suffix.lower() in EXCLUDED_SUFFIXES or path.name.endswith(('.db-wal','.db-shm','.sqlite-wal','.sqlite-shm')) or (data is not None and binary_magic(data))
def source_members():
 files=[];pruned=[]
 def walk(directory):
  for path in sorted(directory.iterdir()):
   relative=path.relative_to(SOURCE).as_posix()
   if relative in PRUNE_RELATIVE or path.name in PRUNE_NAMES:
    need(path.is_dir() and not path.is_symlink(),'pruned root must be a real directory '+relative)
    pruned.append({'path':relative,'scope':'ENTIRE_SUBTREE_PRUNED_NOT_ARCHIVED_NOT_RECURSED_NOT_MEMBER_HASHED','reason':'Rebuildable checkout, local copied web source/dist, dependencies, cache or tools; exact original provenance reports remain archived.'});continue
   need(not path.is_symlink(),'unpruned symlink forbidden '+relative)
   if path.is_dir():walk(path)
   else:need(stat.S_ISREG(path.lstat().st_mode),'nonregular source '+relative);files.append(path)
 walk(SOURCE)
 return files,pruned
def credential_text_views(data):
 views=[]
 try:views.append(('utf8',data.decode('utf-8-sig')))
 except UnicodeError:
  # A strictly bounded Windows PowerShell transport exception: only an actual
  # CLIXML envelope, strict CP936 roundtrip and validated PowerShell Objs XML.
  if data.startswith(b'#< CLIXML'):
   text=data.decode('cp936',errors='strict')
   need(text.encode('cp936',errors='strict')==data,'CP936 CLIXML exact roundtrip')
   match=re.match(r'\A#< CLIXML\r?\n',text)
   need(match is not None,'CP936 CLIXML exact header')
   xml=text[match.end():]
   need('<!DOCTYPE' not in xml and '<!ENTITY' not in xml,'CP936 CLIXML DTD/entity forbidden')
   try:document=ET.fromstring(xml)
   except ET.ParseError:raise AssertionError('CP936 CLIXML malformed XML') from None
   need(document.tag=='{http://schemas.microsoft.com/powershell/2004/04}Objs','CP936 CLIXML known PowerShell Objs namespace')
   views.append(('cp936-clixml',text))
 if data.startswith((b'\xff\xfe',b'\xfe\xff')) or (len(data)>4 and data.count(b'\0')>len(data)//8):
  for encoding in ('utf-16-le','utf-16-be'):
   try:views.append((encoding,data.decode(encoding).lstrip('\ufeff')))
   except UnicodeError:pass
 need(bool(views),'unrecognized retained evidence encoding')
 return views

def public_certificate_der(data):
    # Exactly one public certificate block, never a bundle, key or surrounding
    # text. Decode strictly, reject trailing/noncanonical DER, then parse X.509.
    match = re.fullmatch(br'-----BEGIN CERTIFICATE-----\r?\n([A-Za-z0-9+/=\r\n]+)-----END CERTIFICATE-----\r?\n?', data)
    need(match is not None, 'public certificate PEM envelope rejected')
    encoded = match.group(1).replace(b'\r', b'').replace(b'\n', b'')
    try:
        der = base64.b64decode(encoded, validate=True)
    except (ValueError, TypeError):
        raise AssertionError('public certificate base64 rejected') from None
    need(base64.b64encode(der) == encoded and len(der) >= 4 and der[0] == 0x30,
         'public certificate DER sequence rejected')
    first = der[1]
    if first < 0x80:
        header, length = 2, first
    else:
        count = first & 0x7f
        need(1 <= count <= 4 and len(der) >= 2 + count and der[2] != 0,
             'public certificate DER length rejected')
        header, length = 2 + count, int.from_bytes(der[2:2 + count], 'big')
        need(length >= 0x80 and (length.bit_length() + 7) // 8 == count,
             'public certificate DER nonminimal length rejected')
    need(header + length == len(der), 'public certificate DER trailing bytes rejected')
    try:
        ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT).load_verify_locations(cadata=der)
    except (ssl.SSLError, ValueError):
        raise AssertionError('public certificate X509 parse rejected') from None
    return der


def public_certificate(path,data):
 row=CERTIFICATES[path.relative_to(SOURCE).as_posix()]
 need(len(data)==row['bytes'] and sha(data)==row['sha256'],'exact listed public certificate')
 report=SOURCE/row['report'];need(report.resolve().is_relative_to(SOURCE.resolve()) and report.is_file() and not report.is_symlink(),'certificate original report scope')
 need(sha(report.read_bytes())==row['reportSha256'],'certificate original report identity')
 need(path.name=='tls-public.pem','only exact controlled tls-public.pem certificates are admissible')
 original=as_json(report.read_bytes());preserved=original['rawPreservation'];record=preserved['files']['tls-public.pem']
 need(preserved['status']==record['status']=='PASS' and Path(preserved['directory'])==path.parent and record['artifact']==str(path)
  and record['remote']==record['downloaded']=={'bytes':len(data),'sha256':sha(data)}
  and base64.b64decode(record['base64'],validate=True)==data,'controlled original public certificate provenance')
 der=public_certificate_der(data)
 return dict(path=path.relative_to(SOURCE).as_posix(),bytes=len(data),sha256=sha(data),derSha256=sha(der),x509ParseExitCode=0,report=row['report'],reportSha256=row['reportSha256'])

def main():
 global CERTIFICATES
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--source-base-git',required=True)
 parser.add_argument('--acceptance-report',required=True)
 parser.add_argument('--expected-acceptance-sha256',required=True)
 parser.add_argument('--expected-acceptance-status',required=True)
 parser.add_argument('--readonly-audit',required=True)
 parser.add_argument('--modern-static-audit',required=True)
 parser.add_argument('--expected-modern-static-sha256',required=True)
 parser.add_argument('--win7-static-audit',required=True)
 parser.add_argument('--expected-win7-static-sha256',required=True)
 parser.add_argument('--expected-readonly-sha256',required=True)
 parser.add_argument('--public-certificate-allowlist',type=Path)
 parser.add_argument('--root-controllers-terminal',action='store_true')
 parser.add_argument('--execute',action='store_true')
 parser.add_argument('--promote',action='append',default=[])
 args=parser.parse_args()
 need(args.source_base_git==EXACT_SOURCE,'exact R76 committed CI/product runtime source; later builder patches retain separate provenance')
 for value in (args.expected_acceptance_sha256,args.expected_readonly_sha256,args.expected_modern_static_sha256,args.expected_win7_static_sha256):need(re.fullmatch(r'[0-9a-f]{64}',value),'explicit terminal report SHA')
 need(args.expected_acceptance_status.startswith('PASS_R76_') and not any(x in args.expected_acceptance_status for x in ('STATIC','PREPARED','NOT_RUN')),'actual runtime acceptance status required')
 if not args.execute:
  print(json.dumps({'status':'PREPARED_ARCHIVE_ONLY_NOT_EXECUTED','sourceBaseGit':args.source_base_git,'sourceRoot':str(SOURCE),'destination':str(DEST),'sourcePayloadRead':False,'scope':'Await final independent finite runtime audit and readonly terminal hashes; no archive or deletion.'}));return
 need(args.root_controllers_terminal,'root must confirm every original controller terminal and source membership frozen')
 owner=SOURCE/'.owner';owner_bytes=owner.read_bytes();need(owner_bytes==b'future-classroom-owned-r76-ci-evidence/v1\n','exact R76 owner marker')
 need(SOURCE.is_dir() and not SOURCE.is_symlink() and not DEST.exists(),'fresh archive required')
 need(Path(__file__).resolve().parent==CONTROLLER and (CONTROLLER/'.owner').read_bytes()==b'future-classroom-owned-r76-archive-preparation-second/v1\n','exact R76 controller owner')
 need(not (SOURCE/RECEIPT).exists(),'fresh receipt required')
 acceptance_path=SOURCE/args.acceptance_report;final_path=SOURCE/args.readonly_audit
 for path in (acceptance_path,final_path):
  need(path.resolve().is_relative_to(SOURCE.resolve()),'terminal report scope')
  if not path.exists():
   print(json.dumps({'status':'WAIT','reasonCode':'MISSING_FINAL_'+path.name,'reportCreated':False}));return
  need(path.is_file() and not path.is_symlink(),'terminal report regular file')
  try:pending=as_json(path.read_bytes())
  except (ValueError,UnicodeError):
   print(json.dumps({'status':'WAIT','reasonCode':'INCOMPLETE_FINAL_'+path.name,'reportCreated':False}));return
  if pending.get('status') in ('RUNNING','STARTED','OBSERVATION_INTERRUPTED_NOT_COMPLETION'):
   print(json.dumps({'status':'WAIT','reasonCode':'NONTERMINAL_FINAL_'+path.name,'reportCreated':False}));return
 final=as_json(final_path.read_bytes())
 need(final['status']=='PASS' and final.get('completedAtUtc') and sha(final_path.read_bytes())==args.expected_readonly_sha256,'exact terminal readonly audit')
 runtime=as_json(acceptance_path.read_bytes())
 need(runtime['status']==args.expected_acceptance_status and sha(acceptance_path.read_bytes())==args.expected_acceptance_sha256,'exact finite independent acceptance')
 need(runtime.get('sourceSha')==EXACT_SOURCE,'exact final source scope')
 ci_bindings=[];ci_payloads=[]
 for baseline,run_id,name,digest in [('Modern',41315306076,args.modern_static_audit,args.expected_modern_static_sha256),('Win7',41315385139,args.win7_static_audit,args.expected_win7_static_sha256)]:
  audit_path=SOURCE/name;need(audit_path.resolve().is_relative_to(SOURCE.resolve()) and audit_path.is_file() and not audit_path.is_symlink(),'owned explicit actual static report');audit_data=audit_path.read_bytes();need(sha(audit_data)==digest,'exact reviewed static report SHA');audit=as_json(audit_data)
  need(audit['schema']=='future-classroom.ci-independent-artifact/v2' and audit['status']=='PASS_STATIC_ONLY_RUNTIME_NOT_RUN' and audit['sourceSha']==EXACT_SOURCE and audit['runId']==run_id and audit['baseline']==baseline and len(audit['phases'])==6 and all(v['status']=='PASS' for v in audit['phases']),'exact successful source-bound static result')
  need(audit['counts']['executables']==24 and audit['counts']['tests']==audit['counts']['metadataExpectedTests']==22 and audit['counts']['product']==2 and len(audit['executables'])==24,'actual complete 22 test plus two normal GUI inventory')
  for row in audit['executables']:
   p=Path(row['localPath']);need(p.resolve().is_relative_to(SOURCE.resolve()) and not p.is_symlink(),'exact owned actual PE');data,identity=original(p);producer=row['producer'];need(valid_pe(data) and identity['bytes']==producer['bytes'] and identity['sha256']==producer['sha256'],'actual24 PE identity');ci_payloads.append(identity)
  ci_bindings.append({'baseline':baseline,'runId':run_id,'audit':name,'auditSha256':digest,'executables':24,'runtimeScope':'Actual target runtime on current Win11 only; not Win7/Win10 OS. Final runtime/product/cleanup details remain in the exact independent acceptance.'})
 # Explicit seven package identities only, no recursion into tools or caches.
 package_dir=SOURCE/'tools/packages';need(package_dir.is_dir() and package_dir.resolve().is_relative_to(SOURCE.resolve()) and not any(x.is_symlink() for x in [package_dir,*package_dir.parents] if x==SOURCE or SOURCE in x.parents),'owned packages root');packages=sorted(package_dir.glob('*.deb'));need(len(packages)==7,'exact seven original Debian tool packages');pruned_payloads=[]
 for path in packages:
  need(not path.is_symlink(),'package symlink forbidden');data,identity=original(path);need(data.startswith(b'!<arch>\n'),'actual Debian archive signature');identity['reason']='Explicit original tool package identity only; entire tools subtree pruned.';pruned_payloads.append(identity)
 if args.public_certificate_allowlist:
  p=args.public_certificate_allowlist;need(p.resolve().is_relative_to(SOURCE.resolve()) and not p.is_symlink(),'certificate allowlist scope')
  listing=as_json(p.read_bytes());need(listing['sourceSha']==args.source_base_git and listing['status']=='ROOT_REVIEWED_PUBLIC_CERTIFICATES_ONLY','exact reviewed public certificate list')
  CERTIFICATES=listing['certificates'];need(isinstance(CERTIFICATES,dict),'certificate list object')
 paths,pruned=source_members()
 promoted=set(args.promote);need(len(promoted)==len(args.promote) and len(promoted)<=24,'unique at most24 explicitly promoted reports')
 for name in promoted:
  p=Path(name);need(not p.is_absolute() and p.as_posix()==name and all(x not in ('','.','..') for x in p.parts) and name not in ('archive-index-first.json',RECEIPT,'evidence-originals-first.tar.gz'),'canonical promoted original path')
 rows=[];omitted=[];promoted_rows=[]
 for path in paths:
  need(path.suffix.lower() not in PRIVATE_SUFFIXES,'private material forbidden; contents not read '+str(path))
  if path.suffix.lower() in CERT_SUFFIXES:need(path.relative_to(SOURCE).as_posix() in CERTIFICATES,'unlisted certificate forbidden '+str(path))
 DEST.mkdir(parents=True);container_path=DEST/'evidence-originals-first.tar.gz'
 with container_path.open('xb') as outer:
  with gzip.GzipFile(filename='',mode='wb',fileobj=outer,compresslevel=9,mtime=0) as compressed:
   with tarfile.open(fileobj=compressed,mode='w',format=tarfile.PAX_FORMAT) as archive:
    for path in paths:
     data,row=original(path)
     if excluded(path,data):row['reason']='Unpruned compiled/archive/database payload identity only; original bytes not committed.';omitted.append(row);continue
     relative=row['path'];info=tarfile.TarInfo(relative);info.size=len(data);info.mode=0o600;info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;info.type=tarfile.REGTYPE;archive.addfile(info,io.BytesIO(data))
     row.update(storage='tar_gzip_original_bytes',archivePath='evidence-originals-first.tar.gz',tarMember=relative)
     if relative in promoted:
      write_new(DEST/relative,data);row['promotedArchivePath']=relative;promoted_rows.append({'path':relative,'bytes':len(data),'sha256':sha(data),'archivePath':relative})
     rows.append(row)
 need({r['path'] for r in promoted_rows}==promoted,'every requested promote is a retained actual original')
 container_data=container_path.read_bytes();container={'path':container_path.name,'bytes':len(container_data),'sha256':sha(container_data),'format':'deterministic gzip + PAX tar','memberCount':len(rows),'gzipMtime':0}
 need(len({r['path'] for r in rows+omitted})==len(rows)+len(omitted),'unique complete original membership')
 omitted_by_path={r['path']:r for r in omitted}
 for row in ci_payloads:need({k:omitted_by_path[row['path']][k] for k in ('path','bytes','sha256')}==row,'all48 CI PE identities excluded from Git')
 with tarfile.open(container_path,'r:gz') as archive:
  members=archive.getmembers();need(len(members)==len(rows) and len({m.name for m in members})==len(members) and {m.name for m in members}=={r['path'] for r in rows},'exact tar original membership')
  need(all(m.isfile() and m.uid==m.gid==m.mtime==0 and m.mode==0o600 and m.uname==m.gname=='' for m in members),'only deterministic regular tar originals')
  verified=[]
  for row in rows:
   source,identity=original(SOURCE/row['path']);need(identity=={k:row[k] for k in ('path','bytes','sha256')},'source identity changed '+row['path'])
   stored=archive.extractfile(row['tarMember']).read();need(stored==source and len(stored)==row['bytes'] and sha(stored)==row['sha256'],'independent exact tar/source replay '+row['path'])
   if row.get('promotedArchivePath'):need((DEST/row['promotedArchivePath']).read_bytes()==source,'exact promoted original '+row['path'])
   verified.append({k:row[k] for k in ('path','bytes','sha256','tarMember')})
 for row in omitted+pruned_payloads:
  _,identity=original(SOURCE/row['path']);need(identity=={k:row[k] for k in ('path','bytes','sha256')},'excluded identity changed '+row['path'])
 need({p.relative_to(SOURCE).as_posix() for p in source_members()[0]}=={r['path'] for r in rows+omitted} and source_members()[1]==pruned,'source/pruned scope changed')
 findings=[];stats={'sourceFiles':0,'storedFiles':0,'gzipFiles':1,'promotedFiles':0,'utf16Views':0,'decodedRawPayloads':0,'jsonContainers':0,'textViews':0,'decodedJsonStringViews':0,'cp936ClixmlViews':0};decoder_provenance=[]
 def scan(data,label,depth=0):
  need(depth<=12,'credential decoder depth bound '+label)
  try:views=credential_text_views(data)
  except (AssertionError,UnicodeError):raise AssertionError('unrecognized or invalid retained evidence encoding '+label) from None
  stats['utf16Views']+=sum(encoding.startswith('utf-16-') for encoding,_ in views)
  if any(encoding=='cp936-clixml' for encoding,_ in views):
   stats['cp936ClixmlViews']+=1;decoder_provenance.append({'path':label,'bytes':len(data),'sha256':sha(data),'encoding':'cp936','strictRoundtrip':True,'xmlRoot':'PowerShell Objs namespace'})
  for encoding,text in views:
   stats['textViews']+=1
   for kind,pattern in PATTERNS.items():
    if pattern.search(text):findings.append({'path':label,'kind':kind,'view':encoding})
   try:value=json.loads(text)
   except (ValueError,RecursionError):continue
   stats['jsonContainers']+=1
   budget=[0]
   def walk(item,trail):
    budget[0]+=1;need(budget[0]<=250000,'JSON credential traversal bound '+label)
    if isinstance(item,dict):
     for key,value in item.items():
      if isinstance(value,str) and (key.lower() in ('base64','encodedcommand','stdoutbase64','stderrbase64') or key.lower().endswith('base64')):
       try:decoded=base64.b64decode(value,validate=True)
       except (ValueError,TypeError):pass
       else:
        need(len(decoded)<=32*1024*1024,'decoded credential view bound '+label)
        need(not binary_magic(decoded),'unreviewed embedded compiled/archive payload in declared base64 '+label+'::'+trail+'/'+key)
        stats['decodedRawPayloads']+=1;scan(decoded,label+'::'+trail+'/'+key,depth+1)
      elif isinstance(value,str):
       stats['decodedJsonStringViews']+=1;scan(value.encode('utf-8'),label+'::json-string'+trail+'/'+str(key),depth+1)
      elif isinstance(value,(dict,list)):walk(value,trail+'/'+str(key))
    elif isinstance(item,list):
     for index,value in enumerate(item):
      if isinstance(value,str):
       stats['decodedJsonStringViews']+=1;scan(value.encode('utf-8'),label+'::json-string'+trail+'/'+str(index),depth+1)
      else:walk(value,trail+'/'+str(index))
   walk(value,'')
 with tarfile.open(container_path,'r:gz') as archive:
  for row in rows:
   source=(SOURCE/row['path']).read_bytes();stored=archive.extractfile(row['tarMember']).read()
   if Path(row['path']).suffix.lower() not in CERT_SUFFIXES:
    scan(source,'source:'+row['path']);scan(stored,'stored-tar-gzip-decoded:'+row['path'])
   stats['sourceFiles']+=1;stats['storedFiles']+=1
   if row.get('promotedArchivePath'):
    data=(DEST/row['promotedArchivePath']).read_bytes()
    if Path(row['path']).suffix.lower() not in CERT_SUFFIXES:scan(data,'promoted:'+row['path'])
    stats['promotedFiles']+=1
 need(not findings,'credential findings by path/kind only: '+json.dumps(findings))
 receipt={'schemaVersion':3,'status':'PASS_EXACT_ORIGINAL_AND_TAR_GZIP_BYTES_AND_DECODED_CREDENTIAL_SCAN','sourceRoot':str(SOURCE),'archiveRoot':str(DEST),'sourceBaseGit':args.source_base_git,'sourceSha':EXACT_SOURCE,'recordedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'scope':'Exact R76 final independent acceptance only; first failures, coverage UNKNOWN, separate continuation/cleanup retained. No Win7/Win10 OS promotion. Builder B5 source/provenance separate from3bad CI/normalPE.',
  'archiveContainer':container,'verifiedOriginalFilesBeforeThisReceipt':len(rows),'verifiedOriginalBytesBeforeThisReceipt':sum(r['bytes'] for r in rows),'verified':verified,'promotedOriginals':promoted_rows,'excludedCompiledPayloads':omitted,'explicitPrunedPackageIdentities':pruned_payloads,'acceptedCiPeIdentities':ci_payloads,'prunedSubtrees':pruned,
  'credentialScan':{'status':'PASS_NO_MATCHES','statistics':stats,'patterns':list(PATTERNS),'findings':[],'decoderProvenance':decoder_provenance,'coverage':'Retained source, decompressed tar originals, and promoted counterparts; strict UTF8/UTF16/known CP936 CLIXML, declared JSON base64/encodedCommand streams and nested JSON strings. Binary classification applies to actual file/decoded streams, not ordinary MZ text labels. No excluded binary payload committed.'},
  'ciSourceEvidence':ci_bindings,'runtimeEvidence':{'path':args.acceptance_report,'sha256':sha(acceptance_path.read_bytes()),'status':runtime['status']},'windowsFinalAudit':{'path':args.readonly_audit,'sha256':sha(final_path.read_bytes()),'status':final['status']},'ownedRootMarker':{'path':str(owner),'bytes':len(owner_bytes),'sha256':sha(owner_bytes)},
  'historicalScopes':'All original FAIL/RUNNING observations retained verbatim; archive never relabels raw outcomes. Entire pruned rebuildable subtrees are not raw archived or member hashed; their original source542/Web65/producer/tool provenance records remain exact originals.',
  'publicCertificates':[public_certificate(SOURCE/name,(SOURCE/name).read_bytes()) for name in sorted(CERTIFICATES)]}
 receipt_data=(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n').encode();scan(receipt_data,'new-verification-receipt');need(not findings,'credential finding in verification receipt')
 write_new(SOURCE/RECEIPT,receipt_data);write_new(DEST/RECEIPT,receipt_data);receipt_row={'path':RECEIPT,'bytes':len(receipt_data),'sha256':sha(receipt_data),'storage':'exact_original_bytes','archivePath':RECEIPT};rows.append(receipt_row)
 index={'schemaVersion':3,'status':'ORIGINAL_BYTES_ARCHIVED_IN_GZIP_TAR','sourceRoot':str(SOURCE),'files':rows,'archiveContainer':container,'promotedOriginals':promoted_rows,'excludedCompiledPayloads':omitted,'explicitPrunedPackageIdentities':pruned_payloads,'acceptedCiPeIdentities':ci_payloads,'prunedSubtrees':pruned,'verificationReceipt':receipt_row,'originalFiles':len(rows),'originalBytes':sum(r['bytes'] for r in rows),'storedBytes':container['bytes']+sum(r['bytes'] for r in promoted_rows)+len(receipt_data),'archiveFileCount':len(promoted_rows)+3,
  'scope':'One replayable deterministic gzip/PAX tar preserves every retained original, with optional exact promoted duplicates for links. Receipt and index standalone avoid circular hashing. No compiled payloads/caches/checkout/tools copied; original result scopes remain separate.'}
 index_data=(json.dumps(index,ensure_ascii=False,indent=2)+'\n').encode();write_new(DEST/'archive-index-first.json',index_data)
 with tarfile.open(container_path,'r:gz') as archive:
  for row in rows:
   original_data=(SOURCE/row['path']).read_bytes();need(len(original_data)==row['bytes'] and sha(original_data)==row['sha256'],'final source identity '+row['path']);stored=archive.extractfile(row['tarMember']).read() if row['storage']=='tar_gzip_original_bytes' else (DEST/row['archivePath']).read_bytes();need(stored==original_data,'final exact member bytes '+row['path'])
 need(sha(container_path.read_bytes())==container['sha256'],'final tar container unchanged')
 need({p.relative_to(SOURCE).as_posix() for p in source_members()[0]}=={r['path'] for r in rows+omitted} and source_members()[1]==pruned,'final source membership/prunes unchanged')
 need({p.relative_to(DEST).as_posix() for p in DEST.rglob('*') if not p.is_dir()}=={container_path.name,RECEIPT,'archive-index-first.json'}|{r['archivePath'] for r in promoted_rows},'exact compact archive membership')
 need(index['archiveFileCount']<=27,'R76 compact archive Git path budget')
 print(json.dumps({'status':'PASS','originalFiles':index['originalFiles'],'originalBytes':index['originalBytes'],'storedBytes':index['storedBytes'],'archiveFileCount':index['archiveFileCount'],'tarMemberCount':container['memberCount'],'promotedFiles':len(promoted_rows),'excludedCompiledPayloads':len(omitted),'explicitPrunedPackages':len(pruned_payloads),'indexSha256':sha(index_data),'verificationReceiptSha256':sha(receipt_data),'archiveContainerSha256':container['sha256'],'credentialScan':'PASS_NO_MATCHES','sourceRemoved':False}))

if __name__=='__main__':main()
