R76 packed archive second preparation — NOT EXECUTED
Only functional policy change: exact fifth whole-subtree prune web-build-first/process-temp/node-compile-cache.
This generated extensionless Node cache is not evidence text, is not encoded/reclassified, not archived or member-hashed.
Original Web build provenance/source65 ledgers remain raw archive inputs. First actual failure and first controller unchanged.
Other two changes are exact new controller path and exact second owner marker. No decoder/security/tar/budget/capacity/
source/DEST/input/24promotion changes. Source failed-archive-first raw tar is excluded by existing.gz suffix identity policy;
its promoted raw copies and original failure/recovery report remain ordinary retained originals.
Use same actual root CLI and --promote list, only replace executable path with:
 /tmp/fc-round76-ci-evidence/archive-preparation-second/archive-evidence-packed-second.py
Root must finish preserving/moving first partial archive, freeze all originals and supply a fresh DEST before --execute.
Only AST and actual safe default(no payload read) checked; no archive/Windows/cleanup executed by this preparation.
