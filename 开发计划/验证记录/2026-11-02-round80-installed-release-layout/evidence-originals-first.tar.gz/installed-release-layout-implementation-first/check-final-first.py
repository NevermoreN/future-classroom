from pathlib import Path
import subprocess,os,json,time,hashlib,shutil
R=Path('/tmp/fc-round80-controlled-repair');W=R/'checkout-installed-release-layout-first';O=R/'installed-release-layout-implementation-first';report=json.loads((O/'build-report-first.json').read_bytes());r={'sourceBefore':report['sourceAfter'],'checks':[]}
env=os.environ.copy();env['CARGO_TARGET_DIR']=str(R/'installed-release-layout-target-first');env['CARGO_BUILD_JOBS']='1'
files=['crates/fc-windows/src/installer_lifecycle/native/broker.rs']+[str(p.relative_to(W))for p in sorted((W/'crates/fc-windows/src/installer_lifecycle/native/broker/installed_release').rglob('*.rs'))]+['crates/fc-windows/src/installer_lifecycle/native/broker/installed_release.rs']
for key in list(env):
 if key.startswith('FC_OWNED_REMOVAL'):del env[key]
for name,cmd in [('clippy-final',['cargo','clippy','--release','--locked','--offline','--target','i686-pc-windows-gnu','-p','fc-windows','--tests','--','-D','warnings']),('fmt-final',['rustfmt','--edition','2021','--check','--config','skip_children=true']+files),('architecture-final',['python3','scripts/check-architecture.py']),('diff-final',['git','diff','--check'])]:
 start=time.monotonic()
 with(O/(name+'.stdout.log')).open('xb')as so,(O/(name+'.stderr.log')).open('xb')as se:
  p=subprocess.Popen(cmd,cwd=W,env=env,stdout=so,stderr=se);exit=p.wait(timeout=900)
 r['checks'].append(dict(name=name,argv=cmd,actualExit=exit,parentReaped=True,seconds=time.monotonic()-start));
 if exit:break
for row in r['sourceBefore']:
 b=(W/row['path']).read_bytes();assert len(b)==row['bytes']and hashlib.sha256(b).hexdigest()==row['sha256']
r['sourceUnchanged']=True;(O/'final-checks-first.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'checks':r['checks'],'sourceUnchanged':True}))
