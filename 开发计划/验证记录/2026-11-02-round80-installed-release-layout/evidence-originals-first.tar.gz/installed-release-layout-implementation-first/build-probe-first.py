from pathlib import Path
import json,hashlib,os,subprocess,time,shutil
R=Path('/tmp/fc-round80-controlled-repair');W=R/'checkout-installed-release-layout-first';O=R/'installed-release-layout-implementation-first';T=R/'installed-release-layout-target-first'
def sha(b):return hashlib.sha256(b).hexdigest()
def fact(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def inventory():
 paths=sorted(set([p for p in(W/'crates').rglob('*')if p.is_file()and(p.suffix=='.rs'or p.name=='Cargo.toml')]+[W/p for p in('Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml')if(W/p).is_file()]))
 return [dict(path=str(p.relative_to(W)),bytes=len((b:=p.read_bytes())),sha256=sha(b))for p in paths]
r=dict(status='STARTED_LOCAL_GNU_COMPILE_ONLY',sourceBase='a4702b56bff66da5f5cbe74551d8751eb33fa520',worktree=str(W),target='i686-pc-windows-gnu',operations=[],sourceBefore=inventory(),scope='New bounded directory/CA/sequence GNU cfgtest reader separate from fixed a470 MSVC normal product; no Windows or PE execution')
(O/'compiler-inputs-before-first.json').write_text(json.dumps(r['sourceBefore'],indent=2)+'\n');env=os.environ.copy();env['CARGO_TARGET_DIR']=str(T);env['CARGO_BUILD_JOBS']='1'
for key in list(env):
 if key.startswith('FC_OWNED_REMOVAL'):del env[key]
try:
 for name,cmd in [('cargo-metadata-first',['cargo','metadata','--locked','--offline','--format-version','1','--no-deps']),('release-test-compile-first',['cargo','test','--locked','--offline','--release','--target','i686-pc-windows-gnu','-p','fc-windows','--no-run','--message-format=json'])]:
  start=time.monotonic()
  with (O/(name+'.stdout.log')).open('xb')as so,(O/(name+'.stderr.log')).open('xb')as se:
   p=subprocess.Popen(cmd,cwd=W,env=env,stdout=so,stderr=se);exit=p.wait(timeout=900)
  r['operations'].append(dict(name=name,argv=cmd,actualExit=exit,parentReaped=True,seconds=time.monotonic()-start,stdout=fact(O/(name+'.stdout.log')),stderr=fact(O/(name+'.stderr.log'))));assert exit==0
 events=[json.loads(line)for line in(O/'release-test-compile-first.stdout.log').read_bytes().splitlines()if line.strip()]
 artifacts=[j for j in events if j.get('reason')=='compiler-artifact'and j.get('target',{}).get('name')=='fc_windows'and j.get('profile',{}).get('test')is True and j.get('executable')]
 assert len(artifacts)==1;artifact=artifacts[0];assert artifact['features']==['default'] and artifact['profile']['opt_level']=='3'
 exe=Path(artifact['executable']);assert exe.is_relative_to(T)and exe.suffix=='.exe';b=exe.read_bytes();assert b.startswith(b'MZ')and 0<len(b)<=64*1024*1024
 dst=O/'probe-artifact-first';dst.mkdir();shutil.copyfile(exe,dst/'db-reader-tests.exe');r.update(status='PASS_FROZEN_GNU_RELEASE_PROBE_COMPILER_ARTIFACT_ONLY_NATIVE_NOT_RUN',compilerArtifact=artifact,executable=fact(dst/'db-reader-tests.exe'),originalExecutable=fact(exe),metadata=fact(O/'cargo-metadata-first.stdout.log'))
except Exception as e:r.update(status='FAIL_LOCAL_PROBE_BUILD_OR_QUALIFICATION',errorType=type(e).__name__,error=str(e))
finally:
 r['sourceAfter']=inventory();r['sourceUnchanged']=r['sourceBefore']==r['sourceAfter'];(O/'compiler-inputs-after-first.json').write_text(json.dumps(r['sourceAfter'],indent=2)+'\n');assert r['sourceUnchanged'];(O/'build-report-first.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items()if k in('status','error','errorType','sourceUnchanged','executable')}));raise SystemExit(0 if r['status'].startswith('PASS_') else 1)
