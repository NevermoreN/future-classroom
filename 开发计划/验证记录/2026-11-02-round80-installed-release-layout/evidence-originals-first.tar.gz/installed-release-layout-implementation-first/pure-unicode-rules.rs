#[path = "/tmp/fc-round80-controlled-repair/checkout-installed-release-layout-first/crates/fc-windows/src/installer_lifecycle/native/broker/installed_release/database_rules.rs"]
mod database_rules;
#[test]
fn wire_ascii_domain_rejects_unicode_case_aliases_in_real_declared_path_rule() {
    use database_rules::{declared_directory_paths, DirectoryRow};
    let mut rows: Vec<_> = [
        ("TARGETDIR", None, "SourceDir"),
        ("LocalAppDataFolder", Some("TARGETDIR"), "."),
        ("UserPrograms", Some("LocalAppDataFolder"), "Programs"),
        ("FcInstallDir", Some("UserPrograms"), "FutureClassroom"),
        ("Web", Some("FcInstallDir"), "web"),
    ].into_iter().map(|(directory,parent,default_dir)| DirectoryRow {
        directory:directory.into(),parent:parent.map(str::to_owned),default_dir:default_dir.into()
    }).collect();
    assert!(declared_directory_paths(&rows).is_some());
    for name in ["Ä", "ä"] {
        rows[4].default_dir=name.into();
        assert!(declared_directory_paths(&rows).is_none());
    }
}
