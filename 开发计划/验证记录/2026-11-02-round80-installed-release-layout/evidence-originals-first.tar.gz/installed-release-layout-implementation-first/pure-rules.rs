#[path = "/tmp/fc-round80-controlled-repair/checkout-installed-release-layout-first/crates/fc-windows/src/installer_lifecycle/native/broker/installed_release/database_rules.rs"]
mod database_rules;
