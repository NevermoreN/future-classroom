function Read-Probe {
 $budget=[int][Math]::Min(150000,[Math]::Max(0,(Remaining)-180000));Require ($budget-gt0) 'ORIGINAL_PROBE_RESERVE';$deadline=(Elapsed)+$budget
 $row=[ordered]@{scope='ACTUAL_RUST_GNU_CFGTEST_DATABASE_API_READER_NOT_CSHARP_SUBSTITUTE';started=$false;actualExit=$false;exitCode=$null;pipesComplete=$false;knownControlsReturned=$false;nativeProbePassed=$false;maximumMilliseconds=$budget;apiInternalSeconds=120;rustSuccessLineObserved=$false;strictSingleTestPass=$false}
 $capture=$null;$process=$null;$out=$null;$err=$null;$ot=$null;$et=$null;$script:ownerUnknown=$true
 try {
  $exe=Join-Path $ScratchRoot 'db-reader-tests.exe';$capture=[Fc79Capture]::new();$process=[Diagnostics.Process]::new();$process.StartInfo.FileName=$exe;$process.StartInfo.Arguments='--ignored --exact installer_lifecycle::native::broker::installed_release::cached_database::native_probe::captures_real_installed_a470_cache_and_returns_every_owned_handle --nocapture --test-threads=1';$process.StartInfo.WorkingDirectory=$ScratchRoot;$process.StartInfo.UseShellExecute=$false;$process.StartInfo.CreateNoWindow=$true;$process.StartInfo.WindowStyle=[Diagnostics.ProcessWindowStyle]::Hidden;$process.StartInfo.RedirectStandardInput=$true;$process.StartInfo.RedirectStandardOutput=$true;$process.StartInfo.RedirectStandardError=$true
  $stdout=Join-Path $ScratchRoot 'rust-db-probe.stdout.log';$stderr=Join-Path $ScratchRoot 'rust-db-probe.stderr.log';$out=[IO.File]::Open($stdout,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);$err=[IO.File]::Open($stderr,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
  Require ((Elapsed)-lt$deadline -and (Remaining)-gt180000) 'ORIGINAL_PROBE_CLOCK_BEFORE_CREATEPROCESS';Require ($process.Start()) 'PROBE_CREATEPROCESS_FALSE';$row.started=$true;$process.StandardInput.Close();$creation=$process.StartTime.ToUniversalTime().ToFileTimeUtc();$row['pid']=$process.Id;$row['creationFiletime']=$creation
  $row['originalStart']=Clone ($capture.HoldStartedClient($process.Handle,[uint32]$process.Id,$creation,$exe,$script:c.probe.executable.sha256,$script:c.expectedUserSid))
  $ot=$process.StandardOutput.BaseStream.CopyToAsync($out);$et=$process.StandardError.BaseStream.CopyToAsync($err)
  while((Elapsed)-lt$deadline -and (Remaining)-gt180000 -and -not$process.HasExited){Start-Sleep -Milliseconds 10}
  $row.actualExit=$process.HasExited;if($row.actualExit){$row.exitCode=$process.ExitCode}
  $wait=[int][Math]::Max(0,[Math]::Min(2000,$deadline-(Elapsed)));$row.pipesComplete=[Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($ot,$et),$wait)
 }catch{$row['failureType']=$_.Exception.GetType().FullName;$row['failureCode']=$(if($_.Exception.Message-cmatch'^[A-Z0-9_]+$'){$_.Exception.Message}else{'NATIVE_PROBE_CAPTURE_FAILURE_RETAIN'})}
 finally {
  if($capture){try{$row['originalFinal']=@((Clone ($capture.FinishAndClose())));$row['originalNativeReturns']=Clone ($capture.NativeReturns());$row['closeUnknown']=$capture.NativeCloseUnknown}catch{$script:instrumentUnknown=$true;$row['finish']='UNKNOWN_NO_RETRY'}}
  if($process){try{if($row.started -and -not$process.HasExited){$row['retainedProcess']='LIVE_NOT_KILLED'}else{$process.Dispose()}}catch{$script:instrumentUnknown=$true}}
  foreach($stream in @($out,$err)){if($stream){try{$stream.Dispose()}catch{$script:instrumentUnknown=$true}}}
  $good=($row.Contains('originalFinal') -and @($row.originalFinal).Count-eq1 -and @($row.originalFinal|Where-Object{$_.Status-cne'HELD_ORIGINAL_IDENTITY' -or $_.Wait-ne0 -or -not$_.ExitKnown -or -not$_.CloseAttempted -or -not$_.CheckedClose}).Count-eq0 -and -not$row.closeUnknown)
  $row.knownControlsReturned=($good -and $row.actualExit -and $row.pipesComplete -and -not$script:instrumentUnknown);$script:ownerUnknown=-not$row.knownControlsReturned
  if($row.knownControlsReturned){
   $text=[IO.File]::ReadAllText((Join-Path $ScratchRoot 'rust-db-probe.stdout.log'));Require ($text.Length-le1048576) 'RUST_PROBE_STDOUT_BOUND'
   $row.rustSuccessLineObserved=($text-cmatch'(?m)^FC_DB_PROBE_SUCCESS original_thread=[0-9]+ components=14 files=14 msi_closes=74 claims=0 retained=0 faulted=false\r?$')
   $row.strictSingleTestPass=($text-cmatch'(?m)^running 1 test\r?$' -and @([regex]::Matches($text,'(?m)^test result:')).Count-eq1 -and $text-cmatch'(?m)^test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; [0-9]+ filtered out; finished in [^\r\n]+\r?$' -and $text-cnotmatch'(?m)^test result: FAILED')
   $row.nativeProbePassed=($row.exitCode-eq0 -and @($row.originalFinal|Where-Object{$_.ExitCode-ne0}).Count-eq0 -and $row.rustSuccessLineObserved -and $row.strictSingleTestPass)
  }
  New-Json (Join-Path $ScratchRoot 'rust-db-probe-phase.json') $row
 }
 return $row
}
