from pathlib import Path
import runpy,json,hashlib
P=Path(__file__).parent
ns=runpy.run_path(str(P/'run-controlled-product.py'))
a=P/'artifact-manifest.json';s=P/'source-manifest.json';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan,af,sf=ns['bind'](a,h(a),s,h(s));pin=ns['bind_probe']()
assert plan['sourceGit']=='a4702b56bff66da5f5cbe74551d8751eb33fa520'
assert plan['target']=='i686-win7-windows-msvc' and pin['executable']['sha256']=='97afd38afe3d7e88d239e207fa1c11ae04a389ee9ef88bdf5c370f2ce1d0c07c'
assert pin['sourceDomains']['probe'].startswith('New W6')
print(json.dumps(dict(status='PASS_LOCAL_FIXED_OFFICIAL_A470_PRODUCT_AND_NEW_W6_GNU_CFGTEST_PROBE_INPUTS',normalProductSource='a470 official Win7MSVC normal profiletestfalse',newReader='GNU cfgtest profiletesttrue;rawDirectory6/CA1/execute23/native74closes assertions not yet executed',Windows='NOT_RUN',newNativeResult='NOT_RUN',Upgrade='NOT_AUTHORIZED',Win7OS='NOT_RUN',Win10OS='NOT_RUN',newMSVCReader='NOT_VALIDATED')))
