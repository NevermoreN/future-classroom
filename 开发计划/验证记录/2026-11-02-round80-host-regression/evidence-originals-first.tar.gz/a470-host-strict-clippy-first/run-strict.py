from pathlib import Path
import hashlib,json,os,signal,subprocess,time,uuid,shutil
R=Path('/tmp/fc-round80-controlled-repair/a470-host-strict-clippy-first');W=Path('/tmp/fc-round80-controlled-repair/checkout-msvc-clippy-fix-first');T='/tmp/fc-round80-controlled-repair/target-a470-host-first'
assert not (R/'report.json').exists();R.joinpath('.owner').write_text('future-classroom-owned-a470-host-strict-clippy/v1\n')
def git(args):return subprocess.run(['git',*args],cwd=W,capture_output=True,check=True).stdout
head=git(['rev-parse','HEAD']).decode().strip();assert head=='a4702b56bff66da5f5cbe74551d8751eb33fa520' and not git(['status','--porcelain'])
def snapshot():
 paths=git(['ls-files','-z']).decode().split('\0');out=[]
 for path in paths:
  if not path or not (path.endswith(('.rs','.toml','.lock')) or path=='.cargo/config.toml'):continue
  b=(W/path).read_bytes();out.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 return out
before=snapshot();tmp=R/('tmp-'+uuid.uuid4().hex);tmp.mkdir(mode=0o700)
env=os.environ.copy();env.update(TMPDIR=str(tmp),TEMP=str(tmp),TMP=str(tmp),CARGO_TARGET_DIR=T,CARGO_BUILD_JOBS='2')
argv=['cargo','clippy','--workspace','--all-targets','--locked','--offline','--','-D','warnings'];start=time.monotonic();signals=[];timeout=False
with (R/'stdout.log').open('wb') as out,(R/'stderr.log').open('wb') as err:
 p=subprocess.Popen(argv,cwd=W,env=env,stdout=out,stderr=err,start_new_session=True)
 (R/'started.json').write_text(json.dumps({'sourceGit':head,'argv':argv,'budgetSeconds':600,'controllerPid':os.getpid(),'originalCargoPid':p.pid,'processGroup':p.pid,'environment':{k:env[k] for k in ['TMPDIR','TEMP','TMP','CARGO_TARGET_DIR','CARGO_BUILD_JOBS']}},indent=2)+'\n')
 try:code=p.wait(timeout=600)
 except subprocess.TimeoutExpired:
  timeout=True
  for sig,wait in [(signal.SIGTERM,2),(signal.SIGKILL,5)]:
   os.killpg(p.pid,sig);signals.append(sig.name)
   try:code=p.wait(timeout=wait);break
   except subprocess.TimeoutExpired:continue
  else:raise RuntimeError('owned group failed to reap')
remaining=[]
for entry in Path('/proc').iterdir():
 if not entry.name.isdigit():continue
 try:
  raw=(entry/'stat').read_text();parts=raw[raw.rindex(')')+2:].split()
  if int(parts[2])==p.pid:remaining.append({'pid':int(entry.name),'startTicks':int(parts[19]),'exe':os.readlink(entry/'exe')})
 except (OSError,ValueError):pass
assert not remaining
inventory=[]
for f in sorted(tmp.rglob('*')):
 assert not f.is_symlink()
 if f.is_file():
  b=f.read_bytes();inventory.append({'path':f.relative_to(tmp).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
st=tmp.stat();shutil.rmtree(tmp);after=snapshot();assert before==after and not git(['status','--porcelain'])
report={'schema':'future-classroom-host-strict-clippy-result/v1','sourceGit':head,'argv':argv,'budgetSeconds':600,'actualExit':code,'elapsedSeconds':time.monotonic()-start,'timedOut':timeout,'signals':signals,'originalCargoPid':p.pid,'originalCargoReaped':True,'remainingGroup':remaining,'sourceBefore':before,'sourceAfter':after,'sourceUnchanged':True,'fixtureCleanup':{'root':str(tmp),'dev':st.st_dev,'ino':st.st_ino,'filesBeforeCleanup':inventory,'knownAbsent':not tmp.exists()},'windows':'NOT_CONTACTED'}
(R/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'actualExit':code,'seconds':report['elapsedSeconds'],'sourceUnchanged':True,'groupEmpty':True}),flush=True)
