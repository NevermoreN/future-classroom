from pathlib import Path
import hashlib,json,os,signal,subprocess,time,uuid,shutil
R=Path('/tmp/fc-round80-controlled-repair/host-platform-cfg-validation-first');W=Path('/tmp/fc-round80-controlled-repair/checkout-host-cfg-first');T='/tmp/fc-round80-controlled-repair/target-a470-host-first'
R.joinpath('.owner').write_text('future-classroom-owned-host-platform-cfg-validation/v1\n')
paths=['crates/fc-bootstrap/src/backend/web.rs','crates/fc-bootstrap/src/backend/https_settings.rs','crates/fc-bootstrap/src/backend/web/runtime.rs','crates/fc-bootstrap/src/web_transfer.rs']
def git(args):return subprocess.run(['git',*args],cwd=W,capture_output=True,check=True).stdout
assert git(['rev-parse','HEAD']).decode().strip()=='a4702b56bff66da5f5cbe74551d8751eb33fa520'
assert set(git(['diff','--name-only']).decode().splitlines())==set(paths)
def snapshot():
 out=[]
 for path in git(['ls-files','-z','--','crates','scripts','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo']).decode().split('\0'):
  if not path or not path.endswith(('.rs','.toml','.lock')):continue
  b=(W/path).read_bytes();out.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 return out
before=snapshot();commands=[('runtime-tests',['cargo','test','-p','fc-bootstrap','--lib','--release','--locked','--offline','backend::web::tests::runtime_tests::','--','--test-threads=1']),('self-check',['cargo','run','-p','fc-bootstrap','--release','--locked','--offline','--','--self-check'])];checks=[]
for name,argv in commands:
 tmp=R/('tmp-'+name+'-'+uuid.uuid4().hex);tmp.mkdir(mode=0o700);env=os.environ.copy();env.update(TMPDIR=str(tmp),TEMP=str(tmp),TMP=str(tmp),CARGO_TARGET_DIR=T,CARGO_BUILD_JOBS='2')
 start=time.monotonic();signals=[];timeout=False
 with (R/(name+'.stdout.log')).open('wb') as out,(R/(name+'.stderr.log')).open('wb') as err:
  p=subprocess.Popen(argv,cwd=W,env=env,stdout=out,stderr=err,start_new_session=True)
  (R/'live.json').write_text(json.dumps({'command':name,'argv':argv,'controllerPid':os.getpid(),'cargoOrToolPid':p.pid,'processGroup':p.pid,'budgetSeconds':600},indent=2)+'\n')
  try:code=p.wait(timeout=600)
  except subprocess.TimeoutExpired:
   timeout=True
   for sig,wait in [(signal.SIGTERM,2),(signal.SIGKILL,5)]:
    os.killpg(p.pid,sig);signals.append(sig.name)
    try:code=p.wait(timeout=wait);break
    except subprocess.TimeoutExpired:continue
   else:raise RuntimeError('owned group did not reap')
 group=[]
 for candidate in Path('/proc').iterdir():
  if not candidate.name.isdigit():continue
  try:
   stat=(candidate/'stat').read_text();a=stat[stat.rindex(')')+2:].split()
   if int(a[2])==p.pid:group.append({'pid':int(candidate.name),'startTicks':int(a[19]),'exe':os.readlink(candidate/'exe')})
  except (OSError,ValueError):pass
 assert not group
 leftover=[]
 for f in sorted(tmp.rglob('*')):
  assert not f.is_symlink()
  if f.is_file():
   b=f.read_bytes();leftover.append({'path':f.relative_to(tmp).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 shutil.rmtree(tmp)
 checks.append({'name':name,'argv':argv,'actualExit':code,'elapsedSeconds':time.monotonic()-start,'budgetSeconds':600,'timedOut':timeout,'signals':signals,'originalPid':p.pid,'reaped':True,'remainingGroup':group,'tmpRoot':str(tmp),'tmpFilesBeforeCleanup':leftover,'tmpKnownAbsent':not tmp.exists(),'targetDir':T})
 after=snapshot();assert before==after
 (R/'checks-first.json').write_text(json.dumps({'sourceBefore':before,'sourceAfter':after,'sourceUnchanged':True,'checks':checks},indent=2)+'\n');print(json.dumps({'name':name,'actualExit':code,'seconds':checks[-1]['elapsedSeconds']}),flush=True)
 if code:break
