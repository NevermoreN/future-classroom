from pathlib import Path
import argparse,hashlib,json,os,re,signal,subprocess,time,uuid,shutil
R=Path('/tmp/fc-round80-controlled-repair/a470-host-failure-diagnosis-first');W=Path('/tmp/fc-round80-controlled-repair/checkout-msvc-clippy-fix-first')
p=argparse.ArgumentParser();p.add_argument('--medium',choices=['disk','tmpfs'],required=True);a=p.parse_args()
tests=re.findall(r'^test (\S+) \.\.\. FAILED$',Path('/tmp/fc-round80-controlled-repair/a470-host-workspace-first/stdout.log').read_text(),re.M);assert len(tests)==11
root=(R if a.medium=='disk' else Path('/dev/shm'))/('fc-a470-batch-'+a.medium+'-'+uuid.uuid4().hex);root.mkdir(mode=0o700);(root/'.owner').write_text('future-classroom-owned-a470-host-failure-diagnosis/v1\n')
case=root/'fixture';case.mkdir();prefix=a.medium+'-batch-first';env=os.environ.copy();env.update(TMPDIR=str(case),TEMP=str(case),TMP=str(case),CARGO_TARGET_DIR='/tmp/fc-round80-controlled-repair/target-a470-host-first',CARGO_BUILD_JOBS='2',RUST_BACKTRACE='1')
argv=['cargo','test','--offline','--locked','-p','fc-bootstrap','--lib','--','--exact','--nocapture','--test-threads=8',*tests]
def members(group):
 result=[]
 for candidate in Path('/proc').iterdir():
  if not candidate.name.isdigit():continue
  try:
   raw=(candidate/'stat').read_text();fields=raw[raw.rindex(')')+2:].split()
   if int(fields[2])!=group:continue
   result.append({'pid':int(candidate.name),'group':int(fields[2]),'startTicks':int(fields[19]),'state':fields[0],'exe':os.readlink(candidate/'exe')})
  except (OSError,ValueError):pass
 return result
start=time.monotonic();timedout=False;signals=[]
with (R/(prefix+'.stdout.log')).open('wb') as out,(R/(prefix+'.stderr.log')).open('wb') as err:
 proc=subprocess.Popen(argv,cwd=W,env=env,stdout=out,stderr=err,start_new_session=True);original=members(proc.pid)
 try:code=proc.wait(timeout=300)
 except subprocess.TimeoutExpired:
  timedout=True
  for sig,wait in [(signal.SIGTERM,1),(signal.SIGKILL,3)]:
   captured=members(proc.pid)
   if captured:os.killpg(proc.pid,sig);signals.append({'signal':sig.name,'members':captured})
   try:code=proc.wait(timeout=wait);break
   except subprocess.TimeoutExpired:continue
  else:raise RuntimeError('owned batch processgroup failed to reap')
elapsed=time.monotonic()-start;remaining=members(proc.pid);assert not remaining
inventory=[]
for f in sorted(case.rglob('*')):
 assert not f.is_symlink()
 if f.is_file():
  b=f.read_bytes();inventory.append({'path':f.relative_to(root).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
st=root.stat();shutil.rmtree(root);assert not root.exists()
result={'medium':a.medium,'originalFailedTests':tests,'argv':argv,'environment':{k:env[k] for k in ['TMPDIR','TEMP','TMP','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','RUST_BACKTRACE']},'actualExit':code,'elapsedSeconds':elapsed,'timedOut':timedout,'originalGroup':original,'signals':signals,'remainingGroup':remaining,'ownedFixtureFilesBeforeCleanup':inventory,'fixtureRoot':str(root),'fixtureIdentity':{'dev':st.st_dev,'ino':st.st_ino},'fixtureKnownAbsent':True,'stdout':prefix+'.stdout.log','stderr':prefix+'.stderr.log'}
(R/(prefix+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'medium':a.medium,'actualExit':code,'seconds':elapsed,'fixtureKnownAbsent':True}),flush=True)
