from pathlib import Path
import argparse,hashlib,json,os,re,signal,subprocess,time,uuid,shutil
R=Path('/tmp/fc-round80-controlled-repair/a470-host-failure-diagnosis-first')
W=Path('/tmp/fc-round80-controlled-repair/checkout-msvc-clippy-fix-first')
TARGET='/tmp/fc-round80-controlled-repair/target-a470-host-first'
p=argparse.ArgumentParser();p.add_argument('--medium',choices=['disk','tmpfs'],required=True);a=p.parse_args()
source=Path('/tmp/fc-round80-controlled-repair/a470-host-workspace-first/stdout.log').read_text()
tests=re.findall(r'^test (\S+) \.\.\. FAILED$',source,re.M);assert len(tests)==11;tests=tests[-1:]
root=(R if a.medium=='disk' else Path('/dev/shm'))/('fc-a470-exact-'+a.medium+'-'+uuid.uuid4().hex)
root.mkdir(mode=0o700);(root/'.owner').write_text('future-classroom-owned-a470-host-failure-diagnosis/v1\n')
(R/'.owner').write_text('future-classroom-owned-a470-host-failure-diagnosis/v1\n')
def fact(p):
 b=p.read_bytes();return {'path':p.relative_to(root).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def group_members(group):
 result=[]
 for candidate in Path('/proc').iterdir():
  if not candidate.name.isdigit():continue
  try:
   raw=(candidate/'stat').read_text();fields=raw[raw.rindex(')')+2:].split()
   if int(fields[2])!=group:continue
   result.append({'pid':int(candidate.name),'group':int(fields[2]),'startTicks':int(fields[19]),'state':fields[0],'exe':os.readlink(candidate/'exe')})
  except (OSError,ValueError):pass
 return result
results=[]
for index,test in enumerate(tests):
 case=root/f'{index+1:02d}';case.mkdir();prefix=f'{a.medium}-reopen-second-{index+1:02d}';env=os.environ.copy();env.update(TMPDIR=str(case),TEMP=str(case),TMP=str(case),CARGO_TARGET_DIR=TARGET,CARGO_BUILD_JOBS='2',RUST_BACKTRACE='1')
 argv=['cargo','test','--offline','--locked','-p','fc-bootstrap','--lib',test,'--','--exact','--nocapture','--test-threads=1']
 start=time.monotonic();timedout=False;signals=[]
 with (R/(prefix+'.stdout.log')).open('wb') as out,(R/(prefix+'.stderr.log')).open('wb') as err:
  proc=subprocess.Popen(argv,cwd=W,env=env,stdout=out,stderr=err,start_new_session=True)
  original=group_members(proc.pid)
  try:code=proc.wait(timeout=180)
  except subprocess.TimeoutExpired:
   timedout=True
   for sig,wait in [(signal.SIGTERM,1),(signal.SIGKILL,3)]:
    members=group_members(proc.pid)
    if members:
     assert all(m['group']==proc.pid for m in members)
     os.killpg(proc.pid,sig);signals.append({'signal':sig.name,'members':members})
    try:code=proc.wait(timeout=wait);break
    except subprocess.TimeoutExpired:continue
   else:raise RuntimeError('exact owned processgroup failed to reap')
 elapsed=time.monotonic()-start
 remaining=group_members(proc.pid);assert not remaining,remaining
 inventory=[]
 for f in sorted(case.rglob('*')):
  assert not f.is_symlink()
  if f.is_file():inventory.append(fact(f))
 st=case.stat();shutil.rmtree(case);assert not case.exists()
 result={'test':test,'argv':argv,'environment':{k:env[k] for k in ['TMPDIR','TEMP','TMP','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','RUST_BACKTRACE']},'medium':a.medium,'actualExit':code,'elapsedSeconds':elapsed,'timedOut':timedout,'originalGroup':original,'signals':signals,'remainingGroup':remaining,'ownedFixtureFilesBeforeCleanup':inventory,'fixtureIdentity':{'dev':st.st_dev,'ino':st.st_ino},'fixtureKnownAbsent':True,'stdout':prefix+'.stdout.log','stderr':prefix+'.stderr.log'}
 results.append(result);(R/(a.medium+'-reopen-second-results.json')).write_text(json.dumps({'medium':a.medium,'results':results,'completed':len(results)==len(tests)},indent=2)+'\n')
 print(json.dumps({'medium':a.medium,'index':index+1,'actualExit':code,'seconds':round(elapsed,3),'test':test}),flush=True)
assert sorted(x.name for x in root.iterdir())==['.owner']
(root/'.owner').unlink();root.rmdir();assert not root.exists()
(R/(a.medium+'-reopen-second-cleanup.json')).write_text(json.dumps({'root':str(root),'knownAbsent':True,'cases':len(results),'processGroupsAllKnownAbsent':True},indent=2)+'\n')
