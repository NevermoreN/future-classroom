from pathlib import Path
import hashlib,json,os,re,signal,subprocess,time,uuid,shutil
R=Path('/tmp/fc-round80-controlled-repair/a470-host-workspace-release-serial-first');W=Path('/tmp/fc-round80-controlled-repair/checkout-msvc-clippy-fix-first');T=Path('/tmp/fc-round80-controlled-repair/target-a470-host-first')
assert not (R/'started.json').exists()
R.joinpath('.owner').write_text('future-classroom-owned-a470-host-workspace-release-serial/v1\n')
def command(args):return subprocess.run(args,cwd=W,capture_output=True,check=True).stdout.decode().strip()
head=command(['git','rev-parse','HEAD']);assert head=='a4702b56bff66da5f5cbe74551d8751eb33fa520';assert not command(['git','status','--porcelain'])
root=R/('fixture-'+uuid.uuid4().hex);root.mkdir(mode=0o700);tmp=root/'tmp';tmp.mkdir();root.joinpath('.owner').write_text('future-classroom-owned-a470-host-workspace-release-serial/v1\n')
shm=Path('/dev/shm');shm_before={p.name:(p.stat().st_dev,p.stat().st_ino) for p in shm.iterdir()}
env=os.environ.copy();env.update(TMPDIR=str(tmp),TEMP=str(tmp),TMP=str(tmp),CARGO_TARGET_DIR=str(T),CARGO_BUILD_JOBS='2',RUST_BACKTRACE='1',RUST_TEST_THREADS='1')
argv=['cargo','test','--workspace','--release','--locked','--offline','--','--test-threads=1']
def members(group):
 out=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   raw=(p/'stat').read_text();fields=raw[raw.rindex(')')+2:].split()
   if int(fields[2])!=group:continue
   out.append({'pid':int(p.name),'group':int(fields[2]),'startTicks':int(fields[19]),'state':fields[0],'exe':os.readlink(p/'exe')})
  except (OSError,ValueError):pass
 return out
def identity(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
inputs={p:identity(W/p) for p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','scripts/verify.sh']}
start=time.monotonic();deadline=start+3600;last_heartbeat=start;observed={};signals=[];timedout=False
release_existed=(T/'release').exists()
with (R/'stdout.log').open('wb') as out,(R/'stderr.log').open('wb') as err:
 proc=subprocess.Popen(argv,cwd=W,env=env,stdout=out,stderr=err,start_new_session=True)
 initial=members(proc.pid)
 receipt={'schema':'future-classroom-host-release-serial-start/v1','status':'STARTED','sourceGit':head,'worktree':str(W),'argv':argv,'environment':{k:env[k] for k in ['TMPDIR','TEMP','TMP','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','RUST_BACKTRACE','RUST_TEST_THREADS']},'budgetSeconds':3600,'controllerPid':os.getpid(),'originalCargoPid':proc.pid,'processGroup':proc.pid,'originalGroup':initial,'releaseProfilePreviouslyExisted':release_existed,'sourceInputs':inputs,'windows':'NOT_CONTACTED','diagnosis':'a470-host-failure-diagnosis-first/freeze-first.json','qualification':'Separate release optimization and serial host validation; original debug600s timeout/11 failures and diagnosis60s timeout remain unchanged; verify.sh existing standard is2threads.'}
 (R/'started.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'status':'STARTED','controllerPid':os.getpid(),'cargoPid':proc.pid,'processGroup':proc.pid,'sourceGit':head,'budgetSeconds':3600,'releaseProfilePreviouslyExisted':release_existed}),flush=True)
 while proc.poll() is None:
  now=time.monotonic();group=members(proc.pid)
  for m in group:observed[(m['pid'],m['startTicks'])]=m
  if now-last_heartbeat>=30:
   (R/'live.json').write_text(json.dumps({'elapsedSeconds':now-start,'controllerPid':os.getpid(),'cargoPid':proc.pid,'group':group,'observedProcessCount':len(observed),'stdoutBytes':(R/'stdout.log').stat().st_size,'stderrBytes':(R/'stderr.log').stat().st_size},indent=2)+'\n');last_heartbeat=now
  if now>=deadline:
   timedout=True
   for sig,wait in [(signal.SIGTERM,2),(signal.SIGKILL,5)]:
    group=members(proc.pid)
    if group:os.killpg(proc.pid,sig);signals.append({'signal':sig.name,'members':group})
    try:proc.wait(timeout=wait);break
    except subprocess.TimeoutExpired:continue
   break
  time.sleep(.1)
 code=proc.wait(timeout=5)
elapsed=time.monotonic()-start;remaining=members(proc.pid)
if remaining:
 for sig,wait in [(signal.SIGTERM,.5),(signal.SIGKILL,.5)]:
  current=members(proc.pid)
  if current:os.killpg(proc.pid,sig);signals.append({'signal':sig.name,'members':current,'reason':'owned descendants remained after original Cargo exit'});time.sleep(wait)
 remaining=members(proc.pid)
assert not remaining,remaining
cleanup=[]
def remove_owned(p):
 assert p.is_dir() and not p.is_symlink();st=p.stat();files=[]
 for f in sorted(p.rglob('*')):
  assert not f.is_symlink(),f
  if f.is_file():files.append(identity(f))
 cleanup.append({'root':str(p),'dev':st.st_dev,'ino':st.st_ino,'filesBeforeCleanup':files});shutil.rmtree(p);assert not p.exists()
remove_owned(root)
pattern=re.compile(r'^FutureClassroom-(?:Accounts-R15|Voice-Backend|Voice-Service|Web-Voice|Web-Voice-Capability)-(\d+)-\d+(?:-\d+)?$')
owned_pids={pid for pid,ticks in observed};unknown_new=0
for p in list(shm.iterdir()):
 if p.name in shm_before:continue
 match=pattern.fullmatch(p.name)
 if match and int(match.group(1)) in owned_pids and p.stat().st_uid==os.getuid():remove_owned(p)
 else:unknown_new+=1
assert command(['git','rev-parse','HEAD'])==head and not command(['git','status','--porcelain'])
report={'schema':'future-classroom-host-release-serial-result/v1','status':'PASS_RELEASE_SERIAL_HOST_WORKSPACE' if code==0 and not timedout else 'FAIL_RELEASE_SERIAL_HOST_WORKSPACE','sourceGit':head,'argv':argv,'budgetSeconds':3600,'actualExit':code,'timedOut':timedout,'elapsedSeconds':elapsed,'originalCargoReaped':True,'controllerPid':os.getpid(),'originalCargoPid':proc.pid,'processGroup':proc.pid,'remainingGroup':remaining,'signals':signals,'observedProcesses':list(observed.values()),'ownedFixtureCleanup':cleanup,'ownedFixtureRootsKnownAbsent':all(not Path(x['root']).exists() for x in cleanup),'unownedNewShmEntriesNotTouched':unknown_new,'sourceInputsBefore':inputs,'sourceInputsAfter':{p:identity(W/p) for p in inputs},'sourceStatusClean':True,'stdout':identity(R/'stdout.log'),'stderr':identity(R/'stderr.log'),'windows':'NOT_CONTACTED','scope':'Host release profile, serial harness. Existing Linux fixtures that explicitly select/dev/shm retain their source-defined behavior; no full-disk durability or Windows/native claim. Original debug failures not reclassified.'}
(R/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'actualExit':code,'seconds':elapsed,'ownedFixtureRootsKnownAbsent':report['ownedFixtureRootsKnownAbsent']}),flush=True)
