#!/usr/bin/env python3
"""Default-inert DEV Type19-only post-InstallExecute negative fixture.

Keeps the canonical immutable host/guard, four Binary streams and all14 payloads.
There is NO extra Type1 intermediate full14 SHA witness in this bounded format.
"""
from pathlib import Path
import argparse,hashlib,json,runpy,subprocess,os,time,re
R=Path('/tmp/fc-round80-controlled-repair');W=R/'checkout-abi2-upgrade-normal-first';C=R/'abi2-upgrade-u2-dev-product-package-first';D=R/'abi2-upgrade-postwrite-package-first';P=Path(__file__).resolve().parent
ACTION='FcTestUpgradePostWriteFail';CONDITION='NOT (REMOVE = "ALL")';MESSAGE='FutureClassroom DEV upgrade post-InstallExecute failure; force rollback.'
def need(v,msg):
 if not v:raise AssertionError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def fact(p):p=Path(p);need(p.is_absolute()and p.resolve()==p and p.is_file()and not p.is_symlink(),'Owned regular input');b=p.read_bytes();need(0<len(b)<=64*1024*1024,'Bounded input');return dict(path=str(p),bytes=len(b),sha256=sha(b))
def inject(m,actions,seq):
 rows=m['idt_rows'](actions,'CustomAction');need(rows==[{'Action':'FcControlledInnerGuard','Type':'1','Source':'FcControlledGuardDll','Target':'FcControlledInnerGuard'}],'Only original canonical Type1 guard')
 s=m['idt_rows'](seq,'InstallExecuteSequence');by={x['Action']:x for x in s};need(by['FcControlledInnerGuard']=={'Action':'FcControlledInnerGuard','Condition':'1','Sequence':'1499'}and by['InstallInitialize']['Sequence']=='1500'and by['RemoveExistingProducts']['Sequence']=='1501'and by['InstallExecute']=={'Action':'InstallExecute','Condition':'','Sequence':'6500'}and by['InstallFinalize']['Sequence']=='6600'and ACTION not in by and all(int(x['Sequence'])!=6502 for x in s),'Exact canonical Upgrade topology;6502 unused')
 a=actions+f'{ACTION}\t19\t\t{MESSAGE}\n'.encode();b=seq+f'{ACTION}\t{CONDITION}\t6502\n'.encode();return a,b

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');a=ap.parse_args()
 if not a.execute:print('{"status":"PREPARED_NOT_RUN","Windows":"NOT_CONTACTED","tools":"NOT_EXECUTED"}');return 0
 need(not D.exists(),'Fresh owned derivation only');need(fact(C/'report.json')['sha256']=='c94aaaede740d64377865128be3f18cb0c0ead2addbe2d606b9cb3fa39ccb239','Actual canonical U2 static report');original=json.loads((C/'report.json').read_bytes());need(original['status']=='PASS_NORMAL_GNU_ABI2_SUCCESSOR_MIXED_NORMAL_SOURCES_STATIC_BUNDLE_NATIVE_NOT_RUN'and original['binaryReadback']=='ALL_FOUR_EXACT'and original['payloadReadback']=='ALL_FOURTEEN_EXACT','Canonical actual four Binary/full14 source')
 module=runpy.run_path(str(W/'scripts/package-abi2-upgrade-dev.py'));m=module['B'];codec=module['C'];m['configure_source_root'](W)
 for key,leaf in [('msi','FutureClassroom.msi'),('setup','Setup.exe')]:need(all(fact(C/leaf)[x]==original[key][x]for x in ('bytes','sha256')),'Original canonical '+key)
 msi=(C/'FutureClassroom.msi').read_bytes();setup=(C/'Setup.exe').read_bytes();template=(C/'lifecycle/guard-client-template.exe').read_bytes();helper=codec['verify_carrier_binding'](template,setup,msi);need(sha(template)==original['template']['sha256'],'Original immutable canonical template')
 payload={x['path']:(C/'payload'/x['path']).read_bytes()for x in original['payloads']};need(len(payload)==14 and all(len(payload[x['path']])==x['size']and sha(payload[x['path']])==x['sha256']for x in original['payloads']),'Actual complete14 canonical payloads')
 tools_path=R/'inner-guard-probe-tools-first/tools.json';env_path=R/'inner-guard-probe-tools-first/child-environment.json';need(fact(tools_path)['sha256']=='d82866321cc565890c38b494f7dd2ae6afa2fed8d4ae55270d7c4e931562099d'and fact(env_path)['sha256']=='d0b2d946aba5c21d94713c6e17cfa90a5c85c74dfa00d2336d4cbf88f05b37a0','Original tools environment closure');tools=json.loads(tools_path.read_bytes());child=json.loads(env_path.read_bytes());need(set(child)=={'LD_LIBRARY_PATH','LC_ALL','GIO_USE_VFS','GSETTINGS_BACKEND'},'Exact fixed child environment')
 for n in ('msibuild','msiinfo','msiextract'):need(fact(Path(tools[n]['path']))['sha256']==tools[n]['sha256'],'Original tool '+n)
 D.mkdir();(D/'.owner').write_text('future-classroom-owned-r80-abi2-upgrade-type19-postwrite-fixture/v1\n');report=dict(status='FAIL_RETAIN_ORIGINALS',scope='DEV_TYPE19_ONLY_UPGRADE_AFTER_INSTALLEXECUTE_NOT_NORMAL_RELEASE',Windows='NOT_RUN',canonicalReport=fact(C/'report.json'),script=fact(Path(__file__)),toolsManifest=fact(tools_path),childEnvironment=fact(env_path),commands=[],fault=dict(action=ACTION,type=19,condition=CONDITION,sequence=6502),intermediateFull14ShaWitness='NOT_AVAILABLE_NO_EXTRA_BINARY_ALLOWED',expectedRuntimeEvidence='Actual InstallExecute Return1 then Type19 Return3 and rollback logs; exact old damaged preimage and registry/components/cache restored',packageCodePolicy='SAME_SUMMARY_PACKAGE_ONLY_FINITE_DEV_NEGATIVE_FIXTURE_NOT_REDISTRIBUTABLE');start=time.monotonic();env=os.environ.copy();env.update(child)
 def run(label,argv):
  left=180-(time.monotonic()-start);need(left>0,'Original180s derivation budget');begin=time.monotonic();p=subprocess.run([str(x)for x in argv],cwd=D,env=env,capture_output=True,timeout=min(60,left));out=D/(label+'.stdout.log');err=D/(label+'.stderr.log');out.write_bytes(p.stdout);err.write_bytes(p.stderr);report['commands'].append(dict(label=label,argv=[str(x)for x in argv],actualExit=p.returncode,originalParentReaped=True,seconds=time.monotonic()-begin,stdout=dict(path=out.name,bytes=len(p.stdout),sha256=sha(p.stdout)),stderr=dict(path=err.name,bytes=len(p.stderr),sha256=sha(p.stderr))));need(p.returncode==0,'Original local tool returned0: '+label);return p.stdout
 def info(label,*args):return run(label,[tools['msiinfo']['path'],*args])
 try:
  target=D/'FutureClassroom.msi';target.write_bytes(msi);summary=info('original-summary','suminfo',target);names=info('original-tables','tables',target).decode().splitlines();need(len(names)==31 and len(set(names))==31 and all(re.fullmatch('[A-Za-z_][A-Za-z0-9_]{0,71}',n)for n in names),'Original exact closed31 table inventory');before={n:info('original-table-'+n,'export',target,n)for n in names};streams=info('original-streams','streams',target).decode().splitlines();need(len(set(streams))==len(streams)<=32,'Bounded exact source streams');before_streams={n:info('original-stream-'+str(i),'extract',target,n)for i,n in enumerate(streams)}
  need(set(n for n in before_streams if n.startswith('Binary.'))=={'Binary.FcControlledGuardDll','Binary.FcGuardClientTemplate','Binary.FcPayloadManifest','Binary.FcPublishedPredecessor'},'Exactly four original Binary streams')
  actions,seq=inject(m,before['CustomAction'],before['InstallExecuteSequence']);(D/'CustomAction.idt').write_bytes(actions);(D/'InstallExecuteSequence.idt').write_bytes(seq);run('exact-two-table-import',[tools['msibuild']['path'],target,'-q','DROP TABLE `CustomAction`','-q','DROP TABLE `InstallExecuteSequence`','-i','CustomAction.idt','-i','InstallExecuteSequence.idt'])
  need(info('derived-summary','suminfo',target)==summary,'Whole Summary/PackageCode unchanged');after_names=info('derived-tables','tables',target).decode().splitlines();need(set(after_names)==set(names)and len(after_names)==31,'Same31 tables')
  for n in names:
   after=info('derived-table-'+n,'export',target,n)
   if n in ('CustomAction','InstallExecuteSequence'):
    expected=actions if n=='CustomAction'else seq;need(after.decode().splitlines()[:3]==expected.decode().splitlines()[:3]and sorted(m['idt_rows'](after,n),key=lambda r:r['Action'])==sorted(m['idt_rows'](expected,n),key=lambda r:r['Action']),'Only fixed extra row in '+n)
   else:need(after==before[n],'Unchanged table exact bytes: '+n)
  after_streams=info('derived-streams','streams',target).decode().splitlines();need(set(after_streams)==set(streams)and len(after_streams)==len(streams),'No new stream or fifth Binary')
  for i,n in enumerate(streams):need(info('derived-stream-'+str(i),'extract',target,n)==before_streams[n],'Original stream exact bytes: '+n)
  extract=D/'extracted';extract.mkdir();run('derived-fourteen-extract',[tools['msiextract']['path'],'-C',extract,target]);mains=list(extract.rglob('fc-bootstrap.exe'));need(len(mains)==1,'One extracted root');base=mains[0].parent;actual={}
  for p in extract.rglob('*'):
   need(not p.is_symlink(),'No extracted symlink')
   if p.is_file():need(p.is_relative_to(base),'No extraction outside fixed root');actual[p.relative_to(base).as_posix()]=p.read_bytes()
  need(actual==payload,'All14 extracted bytes unchanged');new=target.read_bytes();bound=codec['bind_carrier_template'](template,new);need(codec['verify_carrier_binding'](template,bound,new)==helper,'Only32 seal hole rebinding; immutable host exact');(D/'Setup.exe').write_bytes(bound)
  need((C/'FutureClassroom.msi').read_bytes()==msi and(C/'Setup.exe').read_bytes()==setup,'Canonical originals unchanged');report.update(status='PASS_DEV_ABI2_UPGRADE_TYPE19_POSTEXECUTE_FIXTURE_STATIC_ONLY',msi=fact(target),setup=fact(D/'Setup.exe'),productCode=original['productCode'],packageCode=original['packageCode'],version=original['version'],payloads=original['payloads'],templateSha256=sha(template),guardSha256=sha(before_streams['Binary.FcControlledGuardDll']),predecessorSha256=sha(before_streams['Binary.FcPublishedPredecessor']),same31Tables=True,onlyTwoExtraRows=True,noExtraBinary=True,allOriginalStreamsExact=True,all14PayloadBytesExact=True,wholeSummaryExact=True,canonicalUnchanged=True)
 except BaseException as e:report['error']=type(e).__name__+': '+str(e);raise
 finally:report['seconds']=time.monotonic()-start;(D/'derivation-report.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(dict(status=report['status'],output=str(D))));return 0
if __name__=='__main__':raise SystemExit(main())
