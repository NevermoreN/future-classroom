"""Actual immutable U1/U2 normal domains, plus exact two-row Type19 DEV derivation."""
from pathlib import Path
import runpy,hashlib,json,copy
R=Path('/tmp/fc-round80-controlled-repair');NORMAL=R/'abi2-upgrade-u2-dev-product-package-first';F=R/'abi2-upgrade-postwrite-package-second';B=R/'abi2-upgrade-u1-u2-runtime-preparation-second'
def need(v,msg):
 if not v:raise AssertionError(msg)
def fact(p):
 p=Path(p);need(p.is_absolute()and p.resolve()==p and p.is_file()and not p.is_symlink()and p.is_relative_to(R),'Owned bounded regular input');b=p.read_bytes();need(len(b)<=96*1024*1024,'Bounded input');return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def verify(c,source):
 for path,pin in [('/tmp/fc-round80-controlled-repair/abi2-upgrade-u1-u2-runtime-preparation-second/verify-normal-package.py', 'a3a78424849f9293e586d20a7e81552ed24531c43b3ff68265596039ad626569'), ('/tmp/fc-round80-controlled-repair/abi2-upgrade-postwrite-preparation-second/derive-type19.py', 'b8277663524c527bc7841dd19760217295cbd6f47bcd6efb5efb44dc92964d56')]:need(fact(Path(path))['sha256']==pin,'Exact reviewed normal qualifier and finite Type19 deriver')
 canonical=copy.deepcopy(c)
 for key,leaf in [('msi','FutureClassroom.msi'),('setup','Setup.exe')]:canonical['successor'][key]=fact(NORMAL/leaf)
 normal=runpy.run_path(str(B/'verify-normal-package.py'))['verify'](canonical,source)
 report=F/'derivation-report.json';need(fact(report)['sha256']=='b1760a69d22d75d850eadc5c384f5248743f8134c53d5a65b667fe327b629a7c'and c['successor']['forcedDerivation']==fact(report),'Exact actual Type19-only derivation')
 j=json.loads(report.read_bytes());need(j['status']=='PASS_DEV_ABI2_UPGRADE_TYPE19_POSTEXECUTE_FIXTURE_STATIC_ONLY'and j['scope']=='DEV_TYPE19_ONLY_UPGRADE_AFTER_INSTALLEXECUTE_NOT_NORMAL_RELEASE'and j['Windows']=='NOT_RUN'and j['canonicalReport']==fact(NORMAL/'report.json'),'Actual normal immutable source preserved; no runtime claims')
 need(j['fault']==dict(action='FcTestUpgradePostWriteFail',type=19,condition='NOT (REMOVE = "ALL")',sequence=6502)and j['intermediateFull14ShaWitness']=='NOT_AVAILABLE_NO_EXTRA_BINARY_ALLOWED','Closed Type19 afterExecute fault, no fictitious full14 witness')
 for key in ('same31Tables','onlyTwoExtraRows','noExtraBinary','allOriginalStreamsExact','all14PayloadBytesExact','wholeSummaryExact','canonicalUnchanged'):need(j[key]is True,'Actual complete derivation readback '+key)
 need(len(j['commands'])==86 and all(type(x['actualExit'])is int and x['actualExit']==0 and x['originalParentReaped']is True for x in j['commands'])and j['seconds']<180,'Actual original86 tools return0 under180s')
 for x in j['commands']:
  for key in ('stdout','stderr'):
   row=x[key];p=F/row['path'];need(p.resolve().parent==F and all(fact(p)[f]==row[f]for f in ('bytes','sha256')),'Original local tool full stdout/stderr bytes')
 for key,leaf in [('msi','FutureClassroom.msi'),('setup','Setup.exe')]:need(c['successor'][key]==fact(F/leaf)==j[key],'Exact forced '+key)
 need(j['productCode']==c['successor']['productCode'][1:-1]and j['packageCode']==c['successor']['packageCode']and j['version']==c['successor']['version']=='0.3.0'and j['payloads']==c['successor']['payloads'],'Same exact U2 package envelope and all14 payloads')
 q=runpy.run_path(str(R/'abi2-upgrade-u2-package-preparation-first/qualify-u2-product.py'));codec=runpy.run_path(str(q['COMMON']/'scripts/installer-carrier-format.py'));template=(NORMAL/'lifecycle/guard-client-template.exe').read_bytes();codec['verify_carrier_binding'](template,(F/'Setup.exe').read_bytes(),(F/'FutureClassroom.msi').read_bytes());need(j['templateSha256']==hashlib.sha256(template).hexdigest()and j['guardSha256']=='e259cc875beb07c73cf4979ddb46e60d4247d2d1a4934be9ac58653ce1ce9659'and j['predecessorSha256']=='11051059c9a6b3fb988d2a4170375b2b78e7252c75be19c957765b15d6ac12aa','Immutable normal template/guard/predecessor unchanged')
 return dict(status='PASS_LOCAL_ACTUAL_TYPE19_CLOSED4BINARY_DERIVATION_NORMAL_DOMAINS_WINDOWS_NOT_RUN',normal=normal,derivation=fact(report),schoolDataPreservation='NOT_RUN',intermediateNew14ShaWitness='NOT_AVAILABLE')
