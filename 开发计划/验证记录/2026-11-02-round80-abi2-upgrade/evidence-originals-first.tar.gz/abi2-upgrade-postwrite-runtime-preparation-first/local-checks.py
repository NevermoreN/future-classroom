from pathlib import Path
import json,runpy,hashlib,copy,subprocess,sys,time
P=Path(__file__).resolve().parent;R=P.parent

def fact(p):b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def main():
 start=time.monotonic();g=runpy.run_path(str(P/'run-controlled-product.py'));v=runpy.run_path(str(P/'verify-normal-package.py'));a=P/'inputs/artifact-manifest.json';s=P/'inputs/source-manifest.json';c,af,sf=g['bind'](a,fact(a)['sha256'],s,fact(s)['sha256']);source=json.loads(s.read_bytes());rejected=[]
 changes=[('missing_derivation',lambda c:c['successor'].pop('forcedDerivation')),('wrong_derivation',lambda c:c['successor']['forcedDerivation'].update(sha256='1'*64)),('normal_instead_of_forced_msi',lambda c:c['successor'].update(msi=fact(R/'abi2-upgrade-u2-dev-product-package-first/FutureClassroom.msi'))),('normal_instead_of_forced_setup',lambda c:c['successor'].update(setup=fact(R/'abi2-upgrade-u2-dev-product-package-first/Setup.exe'))),('wrong_product',lambda c:c['successor'].update(productCode=c['productCode'])),('wrong_scope',lambda c:c['successor'].update(normalProfileTest=True)),('missing_current_constants',lambda c:c.pop('registryView')),('missing_successor_constants',lambda c:c['successor'].pop('registryView'))]
 for name,change in changes:
  bad=copy.deepcopy(c);change(bad)
  try:v['verify'](bad,source)
  except (AssertionError,KeyError,ValueError):rejected.append(name)
  else:raise AssertionError('NOT_REJECTED_'+name)
 # Source-bound synthetic parser qualification only, derived from real physical-cap schema.
 prior=json.loads((R/'abi2-upgrade-u1-u2-runtime-second/report.json').read_bytes())['phase'];base=prior['phases'][0];phases=[]
 expected=[('install-u1','install','u1',0),('forced-upgrade-u2','install','forced',1603),('repair-u1','repair','u1',0),('uninstall-u1','uninstall','u1',0)]
 for name,verb,bundle,rc in expected:
  row=copy.deepcopy(base);row.update(name=name,verb=verb,bundle=bundle,expectedBusinessExit=rc,expectedBusinessExitObserved=True,terminalEvidence={'classification':'INFERRED_FROM_FIXED_SOURCE_NATIVE_CODE_G0_AND_PENDING_ABSENT_NOT_DIRECT_API_RECEIPT'});row['client']['exitCode']=rc;selected=c['successor']if bundle=='forced'else c
  row['directOriginalFinal'][0].update(ExitCode=rc,Sha256=selected['setup']['sha256']);row['msiLogs'].update(postWriteSequenceObserved=bundle=='forced',guardReturn1Count=2 if bundle=='forced'else 1)
  for cap in row['observerFinal']['Processes']:
   if cap['Role']!='owned-guardian':cap['Role']='setup-'+verb;cap['ActualExitCode']=rc
   cap['Sha256']=selected['setup']['sha256']
  phases.append(row)
 j=dict(status='PASS_GNU_ABI2_TYPE19_UPGRADE_DAMAGED_ROLLBACK_U1_CLEANUP',cleanup='PASS_FORMAL_UNINSTALL_ORIGINAL_GATE_RETIRED',ownerUnknown=False,instrumentUnknown=False,originalBudgetExceeded=False,damagedPreimageRestored=True,rolledBackU2Absent={'knownAbsent':True},repaired={'healthyPresent':True},finallyProduct={'knownAbsent':True},finallyCoordination={'namespaceKnownAbsent':True,'pendingKnownAbsent':True},uninstalledCache={'allObservedAbsent':True},phases=phases);assert g['admission'](j,c);neg=[]
 changes=[('B_wrong_exit',lambda j:j['phases'][1]['client'].update(exitCode=0)),('G_nonzero',lambda j:j['phases'][1]['observerFinal']['Processes'][-1].update(ActualExitCode=1603)),('wrong_parent',lambda j:j['phases'][1]['observerFinal']['Processes'][-1].update(ParentPid=1)),('unknown_close',lambda j:j['phases'][1]['directOriginalFinal'][0].update(CheckedClose=False)),('wrong_hash',lambda j:j['phases'][1]['directOriginalFinal'][0].update(Sha256='1'*64)),('no_rollback_log',lambda j:j['phases'][1]['msiLogs'].update(postWriteSequenceObserved=False)),('one_guard',lambda j:j['phases'][1]['msiLogs'].update(guardReturn1Count=1)),('old_preimage_not_restored',lambda j:j.update(damagedPreimageRestored=False)),('new_product_left',lambda j:j['rolledBackU2Absent'].update(knownAbsent=False)),('pending_left',lambda j:j['finallyCoordination'].update(pendingKnownAbsent=False)),('cache_left',lambda j:j['uninstalledCache'].update(allObservedAbsent=False))]
 for name,change in changes:
  bad=copy.deepcopy(j);change(bad);assert not g['admission'](bad,c),name;neg.append(name)
 result=subprocess.run([sys.executable,str(P/'run-controlled-product.py')],capture_output=True,timeout=10);assert result.returncode==0 and json.loads(result.stdout)['Windows']=='NOT_RUN'
 return dict(status='PASS_LOCAL_TYPE19_STATIC_AND_EXPECTED_BUSINESS_ERROR_CAP_PARSER_QUALIFICATION_ONLY',artifact=af,source=sf,actualInputRejections=rejected,syntheticPositive=1,syntheticRejections=neg,syntheticIsWindowsRollbackEvidence=False,defaultExit=result.returncode,defaultStdout=result.stdout.decode(),Windows='NOT_RUN',intermediateNew14ShaWitness='NOT_AVAILABLE',schoolData='NOT_RUN',seconds=time.monotonic()-start)
if __name__=='__main__':print(json.dumps(main(),indent=2))
