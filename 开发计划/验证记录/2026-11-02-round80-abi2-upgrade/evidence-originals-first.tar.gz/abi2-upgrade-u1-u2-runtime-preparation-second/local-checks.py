"""Actual input qualification; source-bound pure rejection checks. No Windows."""
from pathlib import Path
import runpy,json,hashlib,copy,subprocess,sys,time
P=Path(__file__).resolve().parent;R=P.parent

def fact(p):b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def main():
 start=time.monotonic();g=runpy.run_path(str(P/'run-controlled-product.py'));v=runpy.run_path(str(P/'verify-normal-package.py'));a=P/'inputs/artifact-manifest.json';s=P/'inputs/source-manifest.json';c,af,sf=g['bind'](a,fact(a)['sha256'],s,fact(s)['sha256']);source=json.loads(s.read_bytes());rejected=[]
 changes=[('u1_bare_guid',lambda c:c.update(productCode=c['productCode'][1:-1])),('u2_bare_guid',lambda c:c['successor'].update(productCode=c['successor']['productCode'][1:-1])),('u2_wrong_product',lambda c:c['successor'].update(productCode=c['productCode'])),('u2_wrong_version',lambda c:c['successor'].update(version='0.2.0')),('u2_wrong_package',lambda c:c['successor'].update(packageCode=c['packageCode'])),('u2_cfgtest',lambda c:c['successor'].update(normalProfileTest=True)),('u2_wrong_abi',lambda c:c['successor'].update(guardABI=1)),('u2_wrong_main_source',lambda c:c['successor'].update(productSourceRoot=c['sourceRoot'])),('u2_bad_msi',lambda c:c['successor']['msi'].update(sha256='1'*64)),('u2_bad_setup',lambda c:c['successor']['setup'].update(sha256='1'*64)),('u2_wrong_ledger',lambda c:c['successor']['payloads'][0].update(sha256='1'*64)),('u2_wrong_record',lambda c:c['successor']['publication'].update(sha256='1'*64))]
 for name,change in changes:
  bad=copy.deepcopy(c);change(bad)
  try:v['verify'](bad,source)
  except (AssertionError,ValueError,KeyError):rejected.append(name)
  else:raise AssertionError('NOT_REJECTED_'+name)
 for scope in ('current','successor'):
  for field in ['registryMarkerKey', 'runKey', 'runValue', 'registryView', 'fixedDestinationKnownFolderSuffix']:
   bad=copy.deepcopy(c);target=bad if scope=='current' else bad['successor'];target.pop(field)
   try:v['verify'](bad,source)
   except (AssertionError,KeyError):rejected.append(scope+'.'+field)
   else:raise AssertionError('MISSING_PS_CONSTANT_ACCEPTED')
 # U1 actual process shape feeds parser rules only. A synthetic result is never installed evidence.
 history=R/'abi2-upgrade-u1-product-runtime-first/report.json';j=copy.deepcopy(json.loads(history.read_bytes())['phase']);j.update(status='PASS_GNU_ABI2_U1_U2_WIN11_DEV_INSTALL_UPGRADE_UNINSTALL',removedPredecessor={'knownAbsent':True},upgraded={'healthyPresent':True});j['phases'][1]['verb']='install';j['phases'][1]['msiLogs']['guardReturn1Count']=2;assert g['admission'](j);negative=[]
 changes=[('missing_phase',lambda j:j['phases'].pop()),('wrong_verb',lambda j:j['phases'][1].update(verb='repair')),('one_guard',lambda j:j['phases'][1]['msiLogs'].update(guardReturn1Count=1)),('old_product_remains',lambda j:j['removedPredecessor'].update(knownAbsent=False)),('new_unhealthy',lambda j:j['upgraded'].update(healthyPresent=False)),('pending',lambda j:j['finallyCoordination'].update(pendingKnownAbsent=False)),('namespace',lambda j:j['finallyCoordination'].update(namespaceKnownAbsent=False)),('cache',lambda j:j['uninstalledCache'].update(allObservedAbsent=False)),('close_unknown',lambda j:j['phases'][1]['directOriginalFinal'][0].update(CheckedClose=False)),('G_nonzero',lambda j:j['phases'][1]['observerFinal']['Processes'][-1].update(ActualExitCode=1603)),('owner_unknown',lambda j:j.update(ownerUnknown=True)),('B_nonzero',lambda j:j['phases'][1]['client'].update(exitCode=1603))]
 for name,change in changes:
  bad=copy.deepcopy(j);change(bad);assert not g['admission'](bad),name;negative.append(name)
 runner=(P/'run-controlled-product.py').read_text();ps=(P/'sources/Invoke-ControlledProduct.ps1').read_text();state=(P/'sources/ProductState.cs').read_text();assert 'ObserveRemovedU1' in state and 'same14 paths' in state
 assert "'u1/Setup.exe','u1/FutureClassroom.msi','u2/Setup.exe','u2/FutureClassroom.msi'" in ps and "Phase 'upgrade-u2' 'install'" in ps and 'schoolDataPreservation=\'NOT_RUN\'' in ps
 assert "scp=['scp','-q','-r'" in runner and "upload.rglob('*')" in runner and "-SourceRoot $ScratchRoot" in ps and '. (Join-Path'not in ps
 result=subprocess.run([sys.executable,str(P/'run-controlled-product.py')],capture_output=True,timeout=10);assert result.returncode==0 and json.loads(result.stdout)['Windows']=='NOT_RUN'
 return dict(status='PASS_LOCAL_REAL_U1_U2_SOURCE_AND_STATIC_QUALIFICATION_ONLY',artifact=af,source=sf,actualInputRejections=rejected,syntheticParserShapePositive=1,syntheticParserRejections=negative,parserScope='Synthetic Upgrade shape from actual U1 process receipts; never U2/native installation evidence',defaultExit=result.returncode,defaultStdout=result.stdout.decode(),sourceDomains='Original595 common auxiliary plus independent U2 normal main595 sole visible text delta',Windows='NOT_RUN',schoolDataPreservation='NOT_RUN',enabledRunUpgrade='NOT_RUN_RUN_ABSENT_SCOPE_ONLY',seconds=time.monotonic()-start)
if __name__=='__main__':print(json.dumps(main(),indent=2))
