"""Actual local static assembly only, default inert; never executes any PE/MSI."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,time
R=Path('/tmp/fc-round80-controlled-repair');W=R/'checkout-abi2-upgrade-normal-first';P=R/'abi2-dev-package-revision-third'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fact(p):p=Path(p);assert p.is_file()and not p.is_symlink();return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def main():
 a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');v=a.parse_args()
 if not v.execute:print('{"status":"NOT_RUN"}');return
 assert (R/'.owner').read_bytes()==b'future-classroom-owned-r80-controlled-repair/v1\n'
 T=R/'inner-guard-probe-tools-first';tp=T/'tools.json';ep=T/'child-environment.json';assert sha(tp)=='d82866321cc565890c38b494f7dd2ae6afa2fed8d4ae55270d7c4e931562099d'and sha(ep)=='d0b2d946aba5c21d94713c6e17cfa90a5c85c74dfa00d2336d4cbf88f05b37a0';tools=json.loads(tp.read_bytes());child_env=json.loads(ep.read_bytes());assert set(child_env)=={'LD_LIBRARY_PATH','LC_ALL','GIO_USE_VFS','GSETTINGS_BACKEND'}
 for name in ('wixl','msibuild','msiinfo','msiextract','objdump'):assert sha(tools[name]['path'])==tools[name]['sha256']
 evidence=R/'abi2-upgrade-u1-normal-producer-first/evidence.json';j=json.loads(evidence.read_bytes());assert j['lifecycle_mode']=='ABI2_UPGRADE_CAPABLE_NORMAL_GNU_DEV';assert j['status']=='DEV_FROZEN_NORMAL_BUILD_ONLY' and j['source_root']==str(W)and j['environment']['CARGO_PROFILE_RELEASE_STRIP']=='symbols'and len(j['commands'])==3 and all(x['actual_exit']==0 and x['parent_reaped']and not x['timed_out']for x in j['commands'])
 web=R/'controlled-web-first/report.json';assert sha(web)=='706673da7a6ee05299b04f76b0cfe14329d5842417740bd2be0c4430ae0da41c'
 argv=['python3',str(W/'scripts/package-abi2-upgrade-dev.py'),'--execute','--source-root',str(W),'--evidence',str(evidence),'--evidence-sha256',sha(evidence),'--web-report',str(web),'--web-report-sha256',sha(web),'--web-dist',str(R/'controlled-web-first/web/dist'),'--input-dir',str(R/'abi2-upgrade-u1-package-input-first'),'--output-dir',str(R/'abi2-upgrade-u1-dev-product-package-first'),'--msibuild-sha256',tools['msibuild']['sha256']]
 for name in ('wixl','msibuild','msiinfo','msiextract','objdump'):argv+=['--'+name,tools[name]['path']]
 out=R/'abi2-upgrade-u1-package-operation-first';out.mkdir();(out/'.owner').write_text('runtime-review-owned-abi2-upgrade-u1-package-operation-first\n');env=os.environ.copy();env.update(child_env);env['PYTHONDONTWRITEBYTECODE']='1';start=time.monotonic();p=subprocess.Popen(argv,cwd=W,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);timed=False
 try:so,se=p.communicate(timeout=240)
 except subprocess.TimeoutExpired:timed=True;p.kill();so,se=p.communicate()
 (out/'stdout.log').write_bytes(so);(out/'stderr.log').write_bytes(se)
 report=dict(status='PASS_LOCAL_STATIC_ASSEMBLY'if p.returncode==0 and not timed else'FAIL_RETAIN_ORIGINALS',argv=argv,actualExit=p.returncode,parentReaped=True,timedOut=timed,seconds=time.monotonic()-start,originalBudgetSeconds=240,evidence=fact(evidence),builder=fact(W/'scripts/package-abi2-upgrade-dev.py'),toolsManifest=fact(tp),childEnvironment=fact(ep),stdout=fact(out/'stdout.log'),stderr=fact(out/'stderr.log'),Windows='NOT_RUN',normalOrFormalMSVC='DEV_GNU_ONLY')
 (out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));print(so.decode()[-2000:]);print(se.decode()[-3000:]);raise SystemExit(0 if report['status'].startswith('PASS')else 1)
if __name__=='__main__':main()
