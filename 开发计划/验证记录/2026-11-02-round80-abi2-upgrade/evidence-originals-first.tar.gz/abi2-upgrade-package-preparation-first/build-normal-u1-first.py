"""Root-owned normal GNU producer for a frozen, local controlled-MSI candidate."""
from pathlib import Path
import argparse
import sys
if '--execute' not in sys.argv:
    print('{"status":"NOT_RUN"}');raise SystemExit(0)
import hashlib
import json
import os
import runpy
import signal
import subprocess
import time

ROOT = Path('/tmp/fc-round80-controlled-repair')
WORK = ROOT / 'checkout-abi2-upgrade-normal-first'
OUT = ROOT / 'abi2-upgrade-u1-normal-producer-first'
TARGET = 'i686-pc-windows-gnu'
TARGET_DIR = ROOT / 'abi2-upgrade-normal-target-first'
parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true');args=parser.parse_args()
freeze=ROOT/'abi2-upgrade-implementation-first/freeze-final.json';raw_freeze=freeze.read_bytes();assert hashlib.sha256(raw_freeze).hexdigest()=='c52810e13145909304003b730a3e664c996efdabfb3b738bc2d6749dc735f470'
plan=json.loads((ROOT/'abi2-upgrade-package-preparation-first/overlay-plan-first.json').read_bytes());assert plan['sourceBase']=='6eb6ec099b6b14e78b280df5df526545c8e04ecc'
maintenance_rows=[];retained=[]
for row in plan['rows']:
    path=WORK/row['path'];raw=path.read_bytes();expected=row['upgrade']if row['action']=='COPY_FROZEN_UPGRADE'else row['base']
    assert len(raw)==expected['bytes']and hashlib.sha256(raw).hexdigest()==expected['sha256']
    target=maintenance_rows if row['action']=='COPY_FROZEN_UPGRADE'else retained
    target.append(dict(path=row['path'],**expected))
for row in plan['otherNewerMainSources']:
    raw=(WORK/row['path']).read_bytes();assert len(raw)==row['base']['bytes']and hashlib.sha256(raw).hexdigest()==row['base']['sha256'];retained.append(dict(path=row['path'],**row['base']))
assert len(maintenance_rows)==18 and len(retained)==8
assert (ROOT / '.owner').read_bytes() == b'future-classroom-owned-r80-controlled-repair/v1\n'
assert not OUT.exists()
# Mixed frozen source increments are independently bound by full input ledger.
HEAD = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
assert HEAD == '6eb6ec099b6b14e78b280df5df526545c8e04ecc'
dev = runpy.run_path(str(WORK / 'scripts/package-controlled-dev.py'))
OUT.mkdir()
(OUT / '.owner').write_text('future-classroom-owned-abi2-dev-normal-producer/v1\n')


def fact(path):
    data = path.read_bytes()
    return {'path': str(path.relative_to(OUT)), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


before = dev['source_inventory'](WORK)
maintenance_binding=dict(status='FROZEN_UPGRADE_SOURCE_OVERLAY_BOUND',sourceRoot=str(WORK),lifecycleMode='ABI2_UPGRADE_CAPABLE_NORMAL_GNU_DEV',originalFreeze=dict(path=str(freeze),bytes=len(raw_freeze),sha256=hashlib.sha256(raw_freeze).hexdigest()),sources=maintenance_rows,retainedBaseSources=retained,rootOverlayReceipt=dict(path=str(ROOT/'abi2-upgrade-normal-overlay-first.json'),sha256='e1eb37debe1dc37bc2aa665e1d07794f99164c4489b1d24ed33c059075cc9bb4'))
assert hashlib.sha256((ROOT/'abi2-upgrade-normal-overlay-first.json').read_bytes()).hexdigest()==maintenance_binding['rootOverlayReceipt']['sha256']
(OUT/'upgrade-source.json').write_text(json.dumps(maintenance_binding,indent=2)+'\n')
(OUT / 'inputs-before.json').write_text(json.dumps(before, indent=2) + '\n')
env = os.environ.copy()
env.pop('CARGO_ENCODED_RUSTFLAGS', None)
env.pop('RUSTC_WRAPPER',None)
env.pop('RUSTC_WORKSPACE_WRAPPER',None)
env.pop('FC_OWNED_REMOVAL_SCOPE_HEX', None)
for key in list(env):
    if key.startswith('FC_OWNED_REMOVAL'):del env[key]
scoped_env = {
    'CARGO_BUILD_JOBS': '2',
    'CARGO_PROFILE_RELEASE_STRIP': 'symbols',
    'CARGO_TARGET_DIR': str(TARGET_DIR),
    'CARGO_TARGET_I686_PC_WINDOWS_GNU_LINKER': 'i686-w64-mingw32-gcc',
    'RUSTFLAGS': '-C target-feature=+crt-static -C link-arg=-Wl,--major-subsystem-version,6,--minor-subsystem-version,1',
}
env.update(scoped_env)
report = {'status': 'STARTED', 'target': TARGET, 'source_root': str(WORK),
          'source_head': HEAD, 'formal_ci': False, 'environment': scoped_env,
          'removed_environment_keys': ['CARGO_ENCODED_RUSTFLAGS', 'FC_OWNED_REMOVAL_SCOPE_HEX'],
          'runtime': 'NOT_RUN', 'commands': [], 'lifecycle_mode':'ABI2_UPGRADE_CAPABLE_NORMAL_GNU_DEV', 'upgrade_source':fact(OUT/'upgrade-source.json'),
          'producer_script': {'path': str(Path(__file__)),
                              'sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}}


def save():
    (OUT / 'evidence.json').write_text(json.dumps(report, indent=2) + '\n')


def invoke(name, argv, budget):
    started = time.monotonic()
    process = subprocess.Popen(argv, cwd=WORK, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, start_new_session=True)
    timed_out = False
    try:
        stdout, stderr = process.communicate(timeout=budget)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            stdout, stderr = process.communicate(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            stdout, stderr = process.communicate()
    output = OUT / (name + '.stdout.jsonl')
    errors = OUT / (name + '.stderr.log')
    output.write_bytes(stdout)
    errors.write_bytes(stderr)
    row = {'name': name, 'argv': argv, 'actual_exit': process.returncode,
           'parent_reaped': process.poll() is not None, 'timed_out': timed_out,
           'seconds': time.monotonic() - started, 'original_budget_seconds': budget,
           'stdout': fact(output), 'stderr': fact(errors)}
    if process.returncode != 0 or timed_out:
        report['failed_command'] = row
        report['status'] = 'FAIL_RETAIN_ORIGINALS'
        save()
        raise SystemExit(1)
    return row, stdout


save()
metadata_argv = ['cargo', 'metadata', '--offline', '--locked', '--no-deps', '--format-version', '1']
row, raw = invoke('metadata', metadata_argv, 60)
metadata = json.loads(raw)
assert metadata['workspace_root'] == str(WORK)
assert metadata['target_directory'] == str(TARGET_DIR)
report['metadata_command'] = row
report['metadata'] = row['stdout']
report['inputs_before'] = fact(OUT / 'inputs-before.json')
save()
phases = [('product-compile', 'fc-bootstrap', 'fc-bootstrap', 'fc-bootstrap.exe'),
          ('lifecycle-compile', 'fc-bootstrap', 'fc-installer-lifecycle', 'fc-installer-lifecycle.exe'),
          ('guard-library-compile', 'fc-windows', 'fc_windows', 'fc_windows.dll')]
(OUT / 'artifacts').mkdir()
for name, package, target_name, leaf in phases:
    argv = ['cargo', 'build', '--release', '--offline', '--locked', '-p', package]
    argv += ['--lib'] if name == 'guard-library-compile' else ['--bin', target_name]
    argv += ['--target', TARGET, '--target-dir', str(TARGET_DIR), '--message-format=json']
    row, raw = invoke(name, argv, 900)
    messages = [json.loads(line) for line in raw.splitlines() if line.startswith(b'{')]
    selected = [message for message in messages if message.get('reason') == 'compiler-artifact'
                and message.get('target', {}).get('name') == target_name
                and message.get('profile', {}).get('test') is False]
    assert len(selected) == 1
    message = selected[0]
    assert message['features']==['default'] and metadata['packages'][next(i for i,p in enumerate(metadata['packages']) if p['name']==package)]['features'].get('default')==[]
    filenames = ([path for path in message['filenames'] if Path(path).name == leaf]
                 if name == 'guard-library-compile' else [message['executable']])
    assert len(filenames) == 1
    artifact = Path(filenames[0])
    assert artifact.parent == TARGET_DIR / TARGET / 'release' and artifact.name == leaf
    assert artifact.is_file() and not artifact.is_symlink()
    data = artifact.read_bytes()
    assert 0 < len(data) <= 32 * 1024 * 1024
    copy = OUT / 'artifacts' / leaf
    copy.write_bytes(data)
    row['artifact'] = fact(copy)
    report['commands'].append(row)
    assert before == dev['source_inventory'](WORK)
    save()
    print(json.dumps({'phase': name, 'actual_exit': row['actual_exit'],
                      'seconds': row['seconds'], 'artifact': row['artifact']}), flush=True)
after = dev['source_inventory'](WORK)
assert before == after
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == HEAD
# Mixed frozen source increments are independently bound by full input ledger.
(OUT / 'inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
report['inputs_after'] = fact(OUT / 'inputs-after.json')
report['status'] = 'DEV_FROZEN_NORMAL_BUILD_ONLY'
save()
print(json.dumps({'status': report['status'], 'source_head': HEAD,
                  'input_count': len(before), 'evidence': fact(OUT / 'evidence.json')}), flush=True)
