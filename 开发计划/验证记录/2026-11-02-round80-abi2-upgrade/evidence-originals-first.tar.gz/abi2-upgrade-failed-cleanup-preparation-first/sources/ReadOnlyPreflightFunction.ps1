# TEST INSTRUMENT PREPARATION ONLY. Dot-source defines one function; no top-level side effects.
function Measure-FcBeforePreflight {
    param([Parameter(Mandatory=$true)]$Config)
    $c=$Config
    $ErrorActionPreference='Stop'
    if($c.status-cne'BOUND_GNU_ABI2_UPGRADE_FAILED_FORMAL_CLEANUP_NOT_RELEASE' -or $c.sourceGit-cne'6eb6ec099b6b14e78b280df5df526545c8e04ecc' -or $c.target-cne'i686-pc-windows-gnu' -or $c.guardABI-ne2 -or $c.normalProfileTest-ne$false -or $c.formalCI-ne$false -or $c.lifecycleMode-cne'ABI2_UPGRADE_CAPABLE_NORMAL_GNU_DEV' -or $c.sourceEvidenceSha256-cnotmatch'^[0-9a-f]{64}$' -or $c.family-cne'99378807-098D-5F04-8D4D-F181DFA218D5'){throw 'EXACT_BOUND_SOURCE_TARGET_FAMILY_REQUIRED'}
    if($c.productCode-cne'{D420EDE5-0584-5FDC-8DE8-F25905018A0A}' -or $c.version-cne'0.2.0'){throw 'EXACT_U1_PRODUCT_VERSION'}
    function PathFact($path) {
        try {
            $a=[IO.File]::GetAttributes($path)
            return @{path=$path;status='PRESENT_REFUSE';isDirectory=(($a-band[IO.FileAttributes]::Directory)-ne 0);isReparse=(($a-band[IO.FileAttributes]::ReparsePoint)-ne 0)}
        } catch {
            $e=$_.Exception;while($null-ne$e.InnerException){$e=$e.InnerException}
            if($e-is[IO.FileNotFoundException] -or $e-is[IO.DirectoryNotFoundException]){return @{path=$path;status='KNOWN_ABSENT'}}
            return @{path=$path;status='UNKNOWN_REFUSE';exceptionKind=$e.GetType().FullName;hresult=$e.HResult}
        }
    }
    function Registration {
        $i=$null;$products=$null;$related=$null
        try {
            $i=New-Object -ComObject WindowsInstaller.Installer
            $products=$i.GetType().InvokeMember('ProductsEx',[Reflection.BindingFlags]::GetProperty,$null,$i,@($c.productCode,'',7))
            $n=$products.GetType().InvokeMember('Count',[Reflection.BindingFlags]::GetProperty,$null,$products,@())
            $state=$i.GetType().InvokeMember('ProductState',[Reflection.BindingFlags]::GetProperty,$null,$i,@($c.productCode))
            $related=$i.GetType().InvokeMember('RelatedProducts',[Reflection.BindingFlags]::GetProperty,$null,$i,@('{'+$c.family+'}'))
            $rn=$related.GetType().InvokeMember('Count',[Reflection.BindingFlags]::GetProperty,$null,$related,@())
            if($n-isnot[Int32] -or $rn-isnot[Int32] -or $n-lt 0 -or $rn-lt 0){throw 'ACTUAL_COM_COUNT_TYPE_OR_RANGE'}
            return @{contexts=7;sidArgument='';otherUsers='NOT_QUERIED';product=$c.productCode;relatedFamily=$c.family;count=$n;state=$state;relatedCount=$rn;knownAbsent=($n-eq 0 -and $state-eq -1 -and $rn-eq 0)}
        } finally {
            foreach($o in @($related,$products,$i)){if($null-ne$o){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($o)}}
        }
    }
    $who=[Security.Principal.WindowsIdentity]::GetCurrent()
    try{$sid=$who.User.Value}finally{$who.Dispose()}
    if($sid-cne$c.expectedUserSid){throw 'EXACT_EXPECTED_CURRENT_USER_SID'}
    $local=[Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)
    if([string]::IsNullOrEmpty($local) -or -not [IO.Path]::IsPathRooted($local)){throw 'OS_KNOWN_FOLDER_UNAVAILABLE'}
    $target=Join-Path $local 'Programs\FutureClassroom'
    $gate=Join-Path $local ('FutureClassroom-Installer-'+$c.family)
    $paths=@((PathFact $target),(PathFact $gate))
    # An existing gate, even an apparently empty/released one, is not adopted for a
    # fresh production experiment. Unknown is never converted to absence.
    $base=$null;$marker=$null;$run=$null
    try {
        $base=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry32)
        $marker=$base.OpenSubKey('Software\FutureClassroom\Installer\Components',$false)
        $markers=@{view='Registry32';key='Software\FutureClassroom\Installer\Components';knownAbsent=($null-eq$marker)}
        $run=$base.OpenSubKey('Software\Microsoft\Windows\CurrentVersion\Run',$false)
        $runAbsent=$true
        if($null-ne$run){$sentinel=[Object]::new();$value=$run.GetValue('FutureClassroom',$sentinel,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames);$runAbsent=[Object]::ReferenceEquals($sentinel,$value);$value=$null}
        # Only the fixed project value is queried; no other startup data is dumped.
        $runFact=@{view='Registry32';value='FutureClassroom';knownAbsent=$runAbsent;writePerformed=$false;contentsRetained=$false}
        $registration=Registration
    } finally {
        foreach($key in @($run,$marker,$base)){if($null-ne$key){$key.Dispose()}}
    }
    $pass=(@($paths|Where-Object{$_.status-cne'KNOWN_ABSENT'}).Count-eq 0 -and $markers.knownAbsent -and $runFact.knownAbsent -and $registration.knownAbsent)
    return @{status=$(if($pass){'PASS_BEFORE_KNOWN_ABSENCE_ONLY_NOT_EXECUTION_ADMISSION'}else{'REFUSE_PREEXISTING_OR_UNKNOWN_NO_MUTATION'});sourceGit=$c.sourceGit;target=$c.target;currentUserSid=$sid;localKnownFolder=$local;fixedPaths=$paths;componentMarkers=$markers;run=$runFact;registration=$registration;mutations=$false;normalRustHelper='NOT_EXECUTED';productMSI='NOT_EXECUTED';scope='Current authorized admin Win11 only; other users/cache/school data not queried; candidate helper independently rechecks under original native owner.'}
}
