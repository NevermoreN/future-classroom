from pathlib import Path
import runpy,json,hashlib,copy,subprocess,sys,time
P=Path(__file__).resolve().parent

def fact(p):b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def main():
 start=time.monotonic();g=runpy.run_path(str(P/'run-controlled-product.py'));v=runpy.run_path(str(P/'verify-normal-package.py'));a=P/'inputs/artifact-manifest.json';s=P/'inputs/source-manifest.json';c,af,sf=g['bind'](a,fact(a)['sha256'],s,fact(s)['sha256']);source=json.loads(s.read_bytes());rejected=[]
 for scope in ('current','oldConfig'):
  for field in v['CONSTANTS']:
   bad=copy.deepcopy(c);target=bad if scope=='current'else bad['oldConfig'];target.pop(field)
   try:v['verify'](bad,source)
   except (AssertionError,KeyError):rejected.append(scope+'.'+field)
   else:raise AssertionError('MISSING_CONSTANT_ACCEPTED')
 assert len(rejected)==10
 native=(P/'sources/Invoke-ControlledProduct.ps1').read_text();ps=(P/'sources/ProductState.ps1').read_text();assert 'Assert-FcFixedProductConfig -Config $Config' in ps and 'EXACT_ORIGINAL_FAILURE_GATE_OBJECTS_SID_ACLS' in native and "Phase 'formal-uninstall-u2' 'uninstall'" in native and "Phase 'install"not in native
 result=subprocess.run([sys.executable,str(P/'run-controlled-product.py')],capture_output=True,timeout=10);assert result.returncode==0 and json.loads(result.stdout)['Windows']=='NOT_RUN'
 return dict(status='PASS_LOCAL_CURRENT_U2_FORMAL_CLEANUP_BIND_AND_MISSING_CONSTANT_REJECTIONS_WINDOWS_NOT_RUN',artifact=af,source=sf,originalFailure=c['originalFailure'],originalFiles=len(c['originalInventory']['files']),negative=rejected,actualPsConfigValidator='PRESENT_AND_USED_BY_MEASURE_PENDING_ROOT_PS51_EXECUTION',defaultExit=result.returncode,defaultStdout=result.stdout.decode(),Windows='NOT_RUN',seconds=time.monotonic()-start)
if __name__=='__main__':print(json.dumps(main(),indent=2))
