"""Exact existing U2 formal cleanup, with original failed instrument receipt preserved."""
from pathlib import Path
import runpy,json,hashlib
R=Path('/tmp/fc-round80-controlled-repair');OLD=R/'abi2-upgrade-u1-u2-runtime-preparation-first';FAIL=R/'abi2-upgrade-u1-u2-runtime-first/report.json';FAIL_SHA='653c960f7f9f7e70bb0863be17aa40c3e654e7d2ae8d10f0cd84b61fb4163364'
CONSTANTS=dict(registryMarkerKey='Software\\FutureClassroom\\Installer\\Components',runKey='Software\\Microsoft\\Windows\\CurrentVersion\\Run',runValue='FutureClassroom',registryView='Registry32',fixedDestinationKnownFolderSuffix=['Programs','FutureClassroom'])
def need(v,msg):
 if not v:raise AssertionError(msg)
def fact(p):
 p=Path(p);need(p.is_absolute()and p.resolve()==p and p.is_file()and not p.is_symlink()and p.is_relative_to(R),'Exact root-owned regular file');b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def verify(c,source):
 for path,pin in [('/tmp/fc-round80-controlled-repair/abi2-upgrade-u1-u2-runtime-preparation-first/run-controlled-product.py', '32f707a69e9b12919aedc74f598d18600dab113b08e0881c2a1064cf75574db2'), ('/tmp/fc-round80-controlled-repair/abi2-upgrade-u1-u2-runtime-preparation-first/verify-normal-package.py', 'daf32875b391df8d7dab8a1ff79ce50117ee01c1d98ccde82d53c90397642acf')]:need(fact(Path(path))['sha256']==pin,'Pinned original instrument/frozen qualification source')
 need(fact(FAIL)['sha256']==FAIL_SHA and c['originalFailure']==fact(FAIL),'Original failed runtime exact receipt, never rewritten')
 j=json.loads(FAIL.read_bytes());need(j['downloadVerified']is True and j['phase']['failureCode']=='UPGRADE_NEW_ALL14_HEALTHY'and j['phase']['ownerUnknown']is False and j['phase']['instrumentUnknown']is False and j['phase']['finallyCoordination']['pendingKnownAbsent']is True,'Exact known instrument failure, original owner controls returned and Pending absent')
 old=runpy.run_path(str(OLD/'run-controlled-product.py'));rows=j['phase']['phases'];need(len(rows)==2 and [p['verb']for p in rows]==['install','install']and all(old['phase_returned'](p)and p['postPhaseProcesses']['knownZero']is True for p in rows),'Actual original U1/U2 B/G terminal0 and checkedclose')
 original_manifest=Path(j['artifactManifest']['path']);need(fact(original_manifest)==j['artifactManifest'],'Original failed experiment input still exact');prior=json.loads(original_manifest.read_bytes());runpy.run_path(str(OLD/'verify-normal-package.py'))['verify'](prior,source)
 need(c['status']=='BOUND_GNU_ABI2_UPGRADE_FAILED_FORMAL_CLEANUP_NOT_RELEASE'and c['productCode']=='{9E239183-E743-5E6A-8ACE-EB4B8F7511F6}'and c['version']=='0.3.0','Fixed currently installed U2 formal cleanup only')
 for key in ('sourceGit','sourceRoot','packageCode','productCode','version','expectedUserSid','family','guardABI','normalProfileTest','formalCI','lifecycleMode','setup','msi','packageReport','payloads','productSourceRoot','productEvidence','productQualification'):
  need(c[key]==prior['successor'][key],'Exact original normal U2 source identity: '+key)
 need(c['oldConfig']['productCode']==prior['productCode']and c['oldConfig']['version']==prior['version']and c['oldConfig']['payloads']==prior['payloads'],'Original U1 readonly observation identity')
 for config in (c,c['oldConfig']):
  need(config['status']==c['status'],'Both fixed observation scopes')
  for key,value in CONSTANTS.items():need(config.get(key)==value,'Actual PS/C# config required constant: '+key)
 need(c['sourceManifest']['sha256']==prior['sourceManifest']['sha256']and c['sourceManifest']['bytes']==prior['sourceManifest']['bytes'],'Original common595 source manifest contents')
 need(c['originalGateFacts']==j['phase']['originalGateFacts']and len(c['originalGateFacts'])==6 and c['originalWindowsRoot']==j['windowsRoot']and c['originalNonce']==j['nonce']and c['originalInventory']==j['inventory']and c['originalOldCachePaths']==[p['path']for p in j['phase']['installedCache']['paths']],'Exact original gate identity/ACL and failed scratch/cache facts')
 old['validate_inventory'](c['originalInventory']);need(len(c['originalInventory']['files'])==27,'Original exact27files')
 local=FAIL.parent/'download'/Path(j['windowsRoot'].replace('\\','/')).name;files=[];dirs=[]
 for p in local.rglob('*'):
  need(not p.is_symlink(),'Original full download no links');name=p.relative_to(local).as_posix()
  if p.is_dir():dirs.append(name)
  else:files.append(dict(path=name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 need({p['path']:(p['bytes'],p['sha256'])for p in files}=={p['path']:(p['bytes'],p['sha256'])for p in c['originalInventory']['files']}and set(dirs)==set(c['originalInventory']['directories']),'Original failed27files fully downloaded and byte-replayed before cleanup')
 return dict(status='PASS_LOCAL_FIXED_U2_FORMAL_CLEANUP_CONFIG_AND_PRIOR_ORIGINALS_BIND_WINDOWS_NOT_RUN',failure=fact(FAIL),sourceDomains='Actual original normal U1/U2595 domains; no Rust/helper/DLL rebuilt',oldEnd='NO_NEW_NUMERIC_RETURN_INFERRED_FROM_THIS_CONTROLLER',pendingRemoval='FORBIDDEN_FORMAL_NATIVE_UNINSTALL_ONLY')
