$c='{"nonce":"12f5b860fc3d459e9e4ef2d9543e4429","sid":"S-1-5-21-3896111207-1867804362-1971593122-1001","plan":{"status":"BOUND_GNU_ABI2_UPGRADE_U1_PRODUCT_INPUTS_NOT_RELEASE","target":"i686-pc-windows-gnu","family":"99378807-098D-5F04-8D4D-F181DFA218D5","guardABI":2,"normalProfileTest":false,"formalCI":false,"lifecycleMode":"ABI2_UPGRADE_CAPABLE_NORMAL_GNU_DEV","sourceGit":"6eb6ec099b6b14e78b280df5df526545c8e04ecc","sourceRoot":"/tmp/fc-round80-controlled-repair/checkout-abi2-upgrade-normal-first","sourceEvidenceSha256":"3e60a09f3758cccecba8403fd98548b511a3acb100bc01c849f42cde4d122910","normalEvidence":{"path":"/tmp/fc-round80-controlled-repair/abi2-upgrade-u1-normal-producer-first/evidence.json","bytes":5796,"sha256":"3e60a09f3758cccecba8403fd98548b511a3acb100bc01c849f42cde4d122910"},"normalValidator":{"path":"/tmp/fc-round80-controlled-repair/checkout-abi2-upgrade-normal-first/scripts/package-abi2-upgrade-dev.py","bytes":24471,"sha256":"14502c75cae59e33ae19d74d3a40901756878d378d6e5fd4de0fe926df717c79"},"packageBuilder":{"path":"/tmp/fc-round80-controlled-repair/checkout-abi2-upgrade-normal-first/scripts/package-abi2-upgrade-dev.py","bytes":24471,"sha256":"14502c75cae59e33ae19d74d3a40901756878d378d6e5fd4de0fe926df717c79"},"packageReport":{"path":"/tmp/fc-round80-controlled-repair/abi2-upgrade-u1-dev-product-package-first/report.json","bytes":77210,"sha256":"fff5900354e69684c45116369f57c17e15db6a5eb563559746d8351171469d22"},"productCode":"{D420EDE5-0584-5FDC-8DE8-F25905018A0A}","packageCode":"5F6CF7E9-71B0-4197-BDD7-66B12F088E95","version":"0.2.0","artifactVersion":"0.2.0","expectedUserSid":"S-1-5-21-3896111207-1867804362-1971593122-1001","guardAction":"FcControlledInnerGuard","payloads":[{"path":"LICENSE","size":1067,"sha256":"1fef5a26bc7b7bf66e38e83ac8d246a54e2e4e3d62fcfcb416d4db77603b2e40","component_guid":"BF8ECC92-DF5E-5031-AF8F-B122A05E64E6"},{"path":"MSI-CANDIDATE.txt","size":1784,"sha256":"5995cd920d173e401a7767f2a86974d28b65b0927e866882aa39a8227d9d7634","component_guid":"00CBA46A-3182-5F3E-A3C2-3B4D08BF8FCC"},{"path":"PROBE-README.txt","size":21767,"sha256":"7ebdcc9f18d6f0c1f9d2471f7b496f317e1ac5797264940b0f95be1945f64e09","component_guid":"1F2DCDC9-9F80-51BE-A10D-F294D45FDB05"},{"path":"THIRD-PARTY-NOTICES.txt","size":2401720,"sha256":"b611a4c99e2f65d2c5c2f1618f088dec978cab792cbdef2810937cc60d7ed6b0","component_guid":"44E7E505-D3CB-5DC8-9730-50964BA3CC8C"},{"path":"fc-bootstrap.exe","size":11420672,"sha256":"45aca8bab733c92661c46327ab63894b7a6ff941413620bbad03237addf55d9c","component_guid":"0CA01C62-B71F-5C57-905B-B6C979ACB487"},{"path":"manifest.json","size":34953,"sha256":"c378b2617242b6bba4f36edb5c0bf78ef6949a97974b9504d586e4df2ae97c40","component_guid":"8D7F75D1-8AD6-5097-AEE4-62389B788737"},{"path":"web/THIRD-PARTY-NOTICES.txt","size":25543,"sha256":"67cdd6d8f98149012bd01d11eeb5b1c2942298c26c043db461301a8b64b875e7","component_guid":"51201E26-0CF3-5876-A591-91F68B3A94DB"},{"path":"web/assets/favicon-CXuYoSfB.svg","size":282,"sha256":"46593a2ec46a77d65026d609dcd5630c447360522518d745458091a9df2f7f8a","component_guid":"D0B2E913-0457-5E64-A66B-EC1EE7DA7138"},{"path":"web/assets/index-BkiZ2CBl.js","size":415401,"sha256":"cdf0d8f9c8cfa259031cb22e10aacb1ffea7b1f7affb3a4235478069b2138bf3","component_guid":"18B1A37C-EE86-5233-ACC2-773B48D189BB"},{"path":"web/assets/index-DrrJeLm9.css","size":39554,"sha256":"fd6d963cdb889b3bffdebf631c310d869730a56474a389351fd7bdf49bdf385f","component_guid":"B9ADCF83-BCB1-5F42-97D8-967FF84A306F"},{"path":"web/assets/pcm-worklet-B7E4LRoP.js","size":1724,"sha256":"9934c276d98e30992dc8148ffc3a0dfdc178fed9aacbb8227255bede45c1fcfa","component_guid":"28DB1C02-71DB-5DAF-8D0C-9844E24D16DC"},{"path":"web/assets/wav-worker-LSywWbpJ.js","size":884,"sha256":"a0e364aa7c0d888d0f7118b86d873c95df95e461303546a8ad1d56d5038e1886","component_guid":"C0EC8190-410A-52A3-895E-AD6564B75C1E"},{"path":"web/fc-assets.json","size":1073,"sha256":"2b4034c8a0f0bfa73812a7f2853ba83b766772ff55096fc1e33c9f2ddb9e4593","component_guid":"0C6686BF-2327-51F5-89A6-4243C1FD11CF"},{"path":"web/index.html","size":1232,"sha256":"8761e3d65d2bee4fb860e14b315eec9e634a019b1633aea627c335397f8299f2","component_guid":"58B108D4-3264-56B1-9DE5-19636D8437E2"}],"setup":{"path":"/tmp/fc-round80-controlled-repair/abi2-upgrade-u1-dev-product-package-first/Setup.exe","bytes":767620,"sha256":"87e50ca4ac7ceb5589cc0367d1e2178a89730e49b50f31fd5603ce1170c128e2"},"msi":{"path":"/tmp/fc-round80-controlled-repair/abi2-upgrade-u1-dev-product-package-first/FutureClassroom.msi","bytes":10813952,"sha256":"ae0eb68bdef970cbbeb99aaf1ee7683ddbcd059d68eebed0d5953826e9d7c08e"},"sourceManifest":{"path":"/tmp/fc-round80-controlled-repair/abi2-upgrade-u1-product-runtime-preparation-first/inputs/source-manifest.json","bytes":107686,"sha256":"f2382738160ff0028709b9457d49ee008971c5e3ab456d5bd0dc6a2928449983"},"scope":"U1 normal GNU DEV only; actual base6eb plus595 frozen inputs and18Upgrade/8retained source binding; NOT publication and NOT formal MSVC","commonPackageBuilder":{"path":"/tmp/fc-round80-controlled-repair/checkout-abi2-upgrade-normal-first/scripts/package-abi2-controlled-dev.py","bytes":21677,"sha256":"4800b442a88522dddf9ea9a3313fba9f70047432ea65babdeb38fceb4be17662"},"registryMarkerKey":"Software\\FutureClassroom\\Installer\\Components","runKey":"Software\\Microsoft\\Windows\\CurrentVersion\\Run","runValue":"FutureClassroom","registryView":"Registry32","fixedDestinationKnownFolderSuffix":["Programs","FutureClassroom"]},"root":null}'|ConvertFrom-Json;
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Need([bool]$v,[string]$code){if(-not$v){throw $code}}
function Fact([string]$p){$f=Get-Item -LiteralPath $p -Force;Need (-not$f.PSIsContainer -and ($f.Attributes-band1024)-eq0) 'REGULAR_NO_REPARSE';return @{bytes=[long]$f.Length;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function RootPath {return Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) ('Temp\FutureClassroom-r80-abi2-upgrade-u1-controlled-product-'+$c.nonce)}
function CheckRoot([string]$root){Need ($root-ceq$c.root -and $root-ceq(RootPath)) 'EXACT_NONCE_ROOT';$a=[IO.File]::GetAttributes($root);Need (($a-band1024)-eq0 -and ($a-band16)-ne0) 'REGULAR_ROOT';Need ([IO.File]::ReadAllText((Join-Path $root '.owner'))-ceq"future-classroom-owned-r80-abi2-upgrade-u1-controlled-product-runtime/v1`n") 'OWNER';$acl=[IO.Directory]::GetAccessControl($root);Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq$c.sid) 'PROTECTED_ROOT_OWNER';$rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($rules.Count-eq2 -and @($rules|Where-Object{$_.IdentityReference.Value-cnotin@($c.sid,'S-1-5-18') -or $_.AccessControlType-ne'Allow' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count-eq0) 'ONLY_USER_SYSTEM_DACL'}
function Inventory([string]$root){CheckRoot $root;$files=@();$dirs=@();$q=[Collections.Generic.Queue[string]]::new();$q.Enqueue($root);while($q.Count){$dir=$q.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){$a=[IO.File]::GetAttributes($p);Need (($a-band1024)-eq0) 'NO_INVENTORY_REPARSE';$rel=$p.Substring($root.Length+1).Replace('\','/');if(($a-band16)-ne0){$dirs+=$rel;$q.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256}};Need ($files.Count-le256 -and $dirs.Count-le32) 'INVENTORY_BOUNDS'}};return @{files=$files;directories=$dirs}}
# TEST INSTRUMENT PREPARATION ONLY. Dot-source defines one function; no top-level side effects.
function Measure-FcBeforePreflight {
    param([Parameter(Mandatory=$true)]$Config)
    $c=$Config
    $ErrorActionPreference='Stop'
    if($c.status-cne'BOUND_GNU_ABI2_UPGRADE_U1_PRODUCT_INPUTS_NOT_RELEASE' -or $c.sourceGit-cne'6eb6ec099b6b14e78b280df5df526545c8e04ecc' -or $c.target-cne'i686-pc-windows-gnu' -or $c.guardABI-ne2 -or $c.normalProfileTest-ne$false -or $c.formalCI-ne$false -or $c.lifecycleMode-cne'ABI2_UPGRADE_CAPABLE_NORMAL_GNU_DEV' -or $c.sourceEvidenceSha256-cnotmatch'^[0-9a-f]{64}$' -or $c.family-cne'99378807-098D-5F04-8D4D-F181DFA218D5'){throw 'EXACT_BOUND_SOURCE_TARGET_FAMILY_REQUIRED'}
    if($c.productCode-cne'{D420EDE5-0584-5FDC-8DE8-F25905018A0A}' -or $c.version-cne'0.2.0'){throw 'EXACT_U1_PRODUCT_VERSION'}
    function PathFact($path) {
        try {
            $a=[IO.File]::GetAttributes($path)
            return @{path=$path;status='PRESENT_REFUSE';isDirectory=(($a-band[IO.FileAttributes]::Directory)-ne 0);isReparse=(($a-band[IO.FileAttributes]::ReparsePoint)-ne 0)}
        } catch {
            $e=$_.Exception;while($null-ne$e.InnerException){$e=$e.InnerException}
            if($e-is[IO.FileNotFoundException] -or $e-is[IO.DirectoryNotFoundException]){return @{path=$path;status='KNOWN_ABSENT'}}
            return @{path=$path;status='UNKNOWN_REFUSE';exceptionKind=$e.GetType().FullName;hresult=$e.HResult}
        }
    }
    function Registration {
        $i=$null;$products=$null;$related=$null
        try {
            $i=New-Object -ComObject WindowsInstaller.Installer
            $products=$i.GetType().InvokeMember('ProductsEx',[Reflection.BindingFlags]::GetProperty,$null,$i,@($c.productCode,'',7))
            $n=$products.GetType().InvokeMember('Count',[Reflection.BindingFlags]::GetProperty,$null,$products,@())
            $state=$i.GetType().InvokeMember('ProductState',[Reflection.BindingFlags]::GetProperty,$null,$i,@($c.productCode))
            $related=$i.GetType().InvokeMember('RelatedProducts',[Reflection.BindingFlags]::GetProperty,$null,$i,@('{'+$c.family+'}'))
            $rn=$related.GetType().InvokeMember('Count',[Reflection.BindingFlags]::GetProperty,$null,$related,@())
            if($n-isnot[Int32] -or $rn-isnot[Int32] -or $n-lt 0 -or $rn-lt 0){throw 'ACTUAL_COM_COUNT_TYPE_OR_RANGE'}
            return @{contexts=7;sidArgument='';otherUsers='NOT_QUERIED';product=$c.productCode;relatedFamily=$c.family;count=$n;state=$state;relatedCount=$rn;knownAbsent=($n-eq 0 -and $state-eq -1 -and $rn-eq 0)}
        } finally {
            foreach($o in @($related,$products,$i)){if($null-ne$o){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($o)}}
        }
    }
    $who=[Security.Principal.WindowsIdentity]::GetCurrent()
    try{$sid=$who.User.Value}finally{$who.Dispose()}
    if($sid-cne$c.expectedUserSid){throw 'EXACT_EXPECTED_CURRENT_USER_SID'}
    $local=[Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)
    if([string]::IsNullOrEmpty($local) -or -not [IO.Path]::IsPathRooted($local)){throw 'OS_KNOWN_FOLDER_UNAVAILABLE'}
    $target=Join-Path $local 'Programs\FutureClassroom'
    $gate=Join-Path $local ('FutureClassroom-Installer-'+$c.family)
    $paths=@((PathFact $target),(PathFact $gate))
    # An existing gate, even an apparently empty/released one, is not adopted for a
    # fresh production experiment. Unknown is never converted to absence.
    $base=$null;$marker=$null;$run=$null
    try {
        $base=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry32)
        $marker=$base.OpenSubKey('Software\FutureClassroom\Installer\Components',$false)
        $markers=@{view='Registry32';key='Software\FutureClassroom\Installer\Components';knownAbsent=($null-eq$marker)}
        $run=$base.OpenSubKey('Software\Microsoft\Windows\CurrentVersion\Run',$false)
        $runAbsent=$true
        if($null-ne$run){$sentinel=[Object]::new();$value=$run.GetValue('FutureClassroom',$sentinel,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames);$runAbsent=[Object]::ReferenceEquals($sentinel,$value);$value=$null}
        # Only the fixed project value is queried; no other startup data is dumped.
        $runFact=@{view='Registry32';value='FutureClassroom';knownAbsent=$runAbsent;writePerformed=$false;contentsRetained=$false}
        $registration=Registration
    } finally {
        foreach($key in @($run,$marker,$base)){if($null-ne$key){$key.Dispose()}}
    }
    $pass=(@($paths|Where-Object{$_.status-cne'KNOWN_ABSENT'}).Count-eq 0 -and $markers.knownAbsent -and $runFact.knownAbsent -and $registration.knownAbsent)
    return @{status=$(if($pass){'PASS_BEFORE_KNOWN_ABSENCE_ONLY_NOT_EXECUTION_ADMISSION'}else{'REFUSE_PREEXISTING_OR_UNKNOWN_NO_MUTATION'});sourceGit=$c.sourceGit;target=$c.target;currentUserSid=$sid;localKnownFolder=$local;fixedPaths=$paths;componentMarkers=$markers;run=$runFact;registration=$registration;mutations=$false;normalRustHelper='NOT_EXECUTED';productMSI='NOT_EXECUTED';scope='Current authorized admin Win11 only; other users/cache/school data not queried; candidate helper independently rechecks under original native owner.'}
}
$start=[Diagnostics.Stopwatch]::GetTimestamp();$frequency=[Diagnostics.Stopwatch]::Frequency
Need ($PSVersionTable.PSVersion.Major-eq5 -and $PSVersionTable.PSVersion.Minor-eq1 -and [IntPtr]::Size-eq8) 'PS51_X64'
$who=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$who.User;Need ($sid.Value-ceq$c.sid) 'CURRENT_SID'}finally{$who.Dispose()}
$before=Measure-FcBeforePreflight -Config $c.plan;Need ($before.status-ceq'PASS_BEFORE_KNOWN_ABSENCE_ONLY_NOT_EXECUTION_ADMISSION') 'ALL_KNOWN_ABSENT_BEFORE_ROOT'
$root=RootPath;try{[void][IO.File]::GetAttributes($root);throw 'ROOT_ALREADY_PRESENT'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
$cursor=[IO.Path]::GetDirectoryName($root);while($cursor){$a=[IO.File]::GetAttributes($cursor);Need (($a-band1024)-eq0 -and ($a-band16)-ne0) 'ORIGINAL_NONREPARSE_ANCESTORS';$cursor=[IO.Path]::GetDirectoryName($cursor)}
[void][IO.Directory]::CreateDirectory($root);$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false);foreach($s in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($s,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))};[IO.Directory]::SetAccessControl($root,$acl);[IO.File]::WriteAllText((Join-Path $root '.owner'),"future-classroom-owned-r80-abi2-upgrade-u1-controlled-product-runtime/v1`n",[Text.UTF8Encoding]::new($false));$c.root=$root;CheckRoot $root
@{status='CREATED_ONLY_OWNED_GNU_ABI2_SAME_PACKAGE_MAINTENANCE_PRODUCT_RUNTIME_ROOT';root=$root;sid=$c.sid;nonce=$c.nonce;before=$before;originalStartQpc=$start;originalFrequency=$frequency}|ConvertTo-Json -Depth 18 -Compress
