#!/usr/bin/env python3
"""Default-inert normal U2 main-only producer. Never installs or publishes."""
from pathlib import Path
import argparse,json,runpy
P=Path(__file__).resolve().parent;Q=runpy.run_path(str(P/'qualify-u2-product.py'))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');a=ap.parse_args()
 if not a.execute:print('{"status":"NOT_RUN","Windows":"NOT_CONTACTED","publication":"NOT_GRANTED"}');return 0
 import os,subprocess,time,signal,hashlib
 WORK=Q['WORK'];OUT=Q['OUT'];TARGET=Q['TARGET'];need=Q['need'];before,binding=Q['source_delta']();need(not OUT.exists()and not TARGET.exists(),'Independent fresh U2 output/target')
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip();need(head==Q['BASE'],'Exact base6eb lookup; overlay proved by595 inputs')
 OUT.mkdir();(OUT/'.owner').write_text('future-classroom-owned-r80-abi2-upgrade-u2-product-producer/v1\n');(OUT/'artifacts').mkdir()
 def savejson(p,j):p.write_text(json.dumps(j,indent=2)+'\n')
 def fact(p):f=Q['fact'](p);f['path']=str(p.relative_to(OUT));return f
 savejson(OUT/'inputs-before.json',before)
 env=os.environ.copy();removed=['CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','FC_OWNED_REMOVAL_SCOPE_HEX']
 for key in list(env):
  if key in removed or key.startswith('FC_OWNED_REMOVAL'):env.pop(key,None)
 scoped={'CARGO_BUILD_JOBS':'2','CARGO_PROFILE_RELEASE_STRIP':'symbols','CARGO_TARGET_DIR':str(TARGET),'CARGO_TARGET_I686_PC_WINDOWS_GNU_LINKER':'i686-w64-mingw32-gcc','RUSTFLAGS':'-C target-feature=+crt-static -C link-arg=-Wl,--major-subsystem-version,6,--minor-subsystem-version,1'};env.update(scoped)
 report=dict(status='STARTED',source_root=str(WORK),source_head=head,target='i686-pc-windows-gnu',formal_ci=False,environment=scoped,removed_environment_keys=removed,source_delta=binding,commands=[],producer_script=Q['fact'](Path(__file__)),runtime='NOT_RUN',publication='NOT_GRANTED')
 def save():savejson(OUT/'evidence.json',report)
 def invoke(name,argv,budget):
  start=time.monotonic();proc=subprocess.Popen(argv,cwd=WORK,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);timed=False
  try:so,se=proc.communicate(timeout=budget)
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(proc.pid,signal.SIGTERM)
   try:so,se=proc.communicate(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);so,se=proc.communicate()
  out=OUT/(name+'.stdout.jsonl');err=OUT/(name+'.stderr.log');out.write_bytes(so);err.write_bytes(se);row=dict(name=name,argv=argv,actual_exit=proc.returncode,parent_reaped=proc.poll()is not None,timed_out=timed,seconds=time.monotonic()-start,original_budget_seconds=budget,stdout=fact(out),stderr=fact(err))
  if proc.returncode!=0 or timed:report.update(status='FAIL_RETAIN_ORIGINALS',failed_command=row);save();raise SystemExit(1)
  return row,so
 save();row,so=invoke('metadata',['cargo','metadata','--offline','--locked','--no-deps','--format-version','1'],60);meta=json.loads(so);need(meta['workspace_root']==str(WORK)and meta['target_directory']==str(TARGET),'Actual metadata source/target');report.update(metadata_command=row,metadata=row['stdout'],inputs_before=fact(OUT/'inputs-before.json'));save()
 argv=['cargo','build','--release','--offline','--locked','-p','fc-bootstrap','--bin','fc-bootstrap','--target','i686-pc-windows-gnu','--target-dir',str(TARGET),'--message-format=json'];row,so=invoke('product-compile',argv,900);messages=[json.loads(x)for x in so.splitlines()if x.startswith(b'{')];selected=[x for x in messages if x.get('reason')=='compiler-artifact'and x.get('target',{}).get('name')=='fc-bootstrap'and x.get('profile',{}).get('test')is False];need(len(selected)==1 and selected[0]['features']==['default'],'Actual normal product compiler artifact');exe=Path(selected[0]['executable']);need(exe==TARGET/'i686-pc-windows-gnu/release/fc-bootstrap.exe','Exact original product path');b=exe.read_bytes();need(0<len(b)<=32*1024*1024,'Bounded normal product');copy=OUT/'artifacts/fc-bootstrap.exe';copy.write_bytes(b);row['artifact']=fact(copy);report['commands']=[row]
 after,afterbinding=Q['source_delta']();need(before==after and binding==afterbinding and subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip()==head,'Original frozen U2 source before/after');savejson(OUT/'inputs-after.json',after);report.update(inputs_after=fact(OUT/'inputs-after.json'),status='DEV_FROZEN_NORMAL_U2_PRODUCT_ONLY_BUILD_NOT_RELEASE');save();qualified=Q['qualify'](OUT/'evidence.json',hashlib.sha256((OUT/'evidence.json').read_bytes()).hexdigest());savejson(OUT/'qualification.json',qualified);print(json.dumps(qualified));return 0
if __name__=='__main__':raise SystemExit(main())
