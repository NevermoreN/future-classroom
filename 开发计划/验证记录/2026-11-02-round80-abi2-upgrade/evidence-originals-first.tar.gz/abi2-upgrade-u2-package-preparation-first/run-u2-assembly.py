#!/usr/bin/env python3
"""Default-inert observed local U2 static assembly; root's actual U1 PASS is fixed."""
from pathlib import Path
import argparse,subprocess,json,time,hashlib
R=Path('/tmp/fc-round80-controlled-repair');P=Path(__file__).resolve().parent
def fact(p):b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def main():
 a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');v=a.parse_args()
 if not v.execute:print('{"status":"NOT_RUN","Windows":"NOT_CONTACTED"}');return 0
 d=R/'abi2-upgrade-u2-package-operation-first';assert not d.exists();d.mkdir();(d/'.owner').write_text('future-classroom-owned-r80-abi2-upgrade-u2-package-operation/v1\n')
 argv=['python3',str(P/'assemble-u2-after-u1-pass.py'),'--execute','--u1-package',str(R/'abi2-upgrade-u1-dev-product-package-first/report.json'),'--u1-package-sha','fff5900354e69684c45116369f57c17e15db6a5eb563559746d8351171469d22','--u1-runtime',str(R/'abi2-upgrade-u1-product-runtime-first/report.json'),'--u1-runtime-sha','4605e523204533938dc2923d2c3d1f5c4f16d507500b868b64852fa34b876a03','--u2-evidence-sha','e6e25709ba4fdfbe623b470fd05aa2d30765f68b57ef933f85bb0c83ee1b72bd'];start=time.monotonic();proc=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);timed=False
 try:so,se=proc.communicate(timeout=240)
 except subprocess.TimeoutExpired:timed=True;proc.kill();so,se=proc.communicate()
 (d/'stdout.log').write_bytes(so);(d/'stderr.log').write_bytes(se);j=dict(status='PASS_LOCAL_STATIC_U2_ASSEMBLY_ONLY'if proc.returncode==0 and not timed else'FAIL_RETAIN_ORIGINALS',actualExit=proc.returncode,originalParentReaped=proc.poll()is not None,timedOut=timed,seconds=time.monotonic()-start,originalBudgetSeconds=240,argv=argv,builder=fact(P/'assemble-u2-after-u1-pass.py'),publicationGate=fact(P/'gate-u1-publication-second.py'),productEvidence=fact(R/'abi2-upgrade-u2-product-producer-first/evidence.json'),stdout=fact(d/'stdout.log'),stderr=fact(d/'stderr.log'),Windows='NOT_CONTACTED');(d/'report.json').write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(j));print(so.decode()[-1000:]);print(se.decode()[-2500:]);return 0 if proc.returncode==0 and not timed else 1
if __name__=='__main__':raise SystemExit(main())
