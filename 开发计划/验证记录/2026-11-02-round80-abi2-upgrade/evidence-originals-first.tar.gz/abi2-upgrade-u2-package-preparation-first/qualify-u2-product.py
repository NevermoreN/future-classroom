"""Normal U2 product-only compiler qualification; no runtime/package authorization.

The immutable normal U1 helper/DLL have their original independent evidence.
A genuine visible main.rs version-text change is the sole U2 source difference.
"""
from pathlib import Path
import hashlib,json,runpy
R=Path('/tmp/fc-round80-controlled-repair');COMMON=R/'checkout-abi2-upgrade-normal-first';WORK=R/'checkout-abi2-upgrade-u2-product-first';A=R/'abi2-upgrade-u1-normal-producer-first';OUT=R/'abi2-upgrade-u2-product-producer-first';TARGET=R/'abi2-upgrade-u2-product-target-first';BASE='6eb6ec099b6b14e78b280df5df526545c8e04ecc';MAIN='crates/fc-bootstrap/src/main.rs'
OLD='let _ = fc_windows::startup::show_startup_failure(&e);'
NEW='let _ = fc_windows::startup::show_startup_failure(&format!("FutureClassroom 0.3: {e}"));'
U1_EVIDENCE_SHA='3e60a09f3758cccecba8403fd98548b511a3acb100bc01c849f42cde4d122910'
def need(v,msg):
 if not v:raise AssertionError(msg)
def digest(b):return hashlib.sha256(b).hexdigest()
def fact(p):
 p=Path(p);need(p.is_absolute()and p.resolve()==p and p.is_file()and not p.is_symlink()and p.is_relative_to(R),'Exact owned input');b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=digest(b))
def document(p,pin):need(fact(p)['sha256']==pin,'Pinned original document');return json.loads(Path(p).read_bytes())
def source_delta():
 evidence=document(A/'evidence.json',U1_EVIDENCE_SHA);before=json.loads((A/evidence['inputs_before']['path']).read_bytes());after=json.loads((A/evidence['inputs_after']['path']).read_bytes());need(before==after and len(before)==595,'Original normal3 frozen595')
 module=runpy.run_path(str(COMMON/'scripts/package-abi2-upgrade-dev.py'));module['admit_normal_inputs'](COMMON,A/'evidence.json',U1_EVIDENCE_SHA)
 actual=module['DEV']['source_inventory'](WORK);need(len(actual)==595 and [r['path']for r in actual]==[r['path']for r in before],'Same exact complete source names')
 expected=(COMMON/MAIN).read_text();need(expected.count(OLD)==1 and NEW not in expected,'One actual visible manual-feedback text change');changed=expected.replace(OLD,NEW).encode();need((WORK/MAIN).read_bytes()==changed,'Exact sole main.rs edit')
 for old,new in zip(before,actual):
  if old['path']==MAIN:need(new['bytes']==len(changed)and new['sha256']==digest(changed)and new['sha256']!=old['sha256'],'Actual changed main source')
  else:need(new==old,'All common auxiliary/canonical carrier source remains identical')
 return actual,dict(commonSourceBase=BASE,u2SourceBase=BASE,normal3Evidence=fact(A/'evidence.json'),soleChangedPath=MAIN,oldMain=fact(COMMON/MAIN),newMain=fact(WORK/MAIN),visibleChange=dict(before=OLD,after=NEW),compiledDomains='U2 normal main artifact only; U1 normal helper and guard reused unchanged')
def qualify(evidence_path,evidence_sha):
 p=Path(evidence_path);need(p==OUT/'evidence.json','Fixed U2 normal producer path');e=document(p,evidence_sha);need(e['status']=='DEV_FROZEN_NORMAL_U2_PRODUCT_ONLY_BUILD_NOT_RELEASE'and e['source_root']==str(WORK)and e['source_head']==BASE and e['target']=='i686-pc-windows-gnu'and e['formal_ci']is False,'Exact separate normal main source provenance')
 actual,binding=source_delta();need(e['source_delta']==binding,'Actual sole main delta')
 for key in ('inputs_before','inputs_after','metadata'):
  row=e[key];path=OUT/row['path'];need(path.resolve().parent==OUT and fact(path)['bytes']==row['bytes']and fact(path)['sha256']==row['sha256'],'Exact normal producer original file')
 need(json.loads((OUT/e['inputs_before']['path']).read_bytes())==actual==json.loads((OUT/e['inputs_after']['path']).read_bytes()),'595 current/before/after equal')
 need(e['environment']=={'CARGO_BUILD_JOBS':'2','CARGO_PROFILE_RELEASE_STRIP':'symbols','CARGO_TARGET_DIR':str(TARGET),'CARGO_TARGET_I686_PC_WINDOWS_GNU_LINKER':'i686-w64-mingw32-gcc','RUSTFLAGS':'-C target-feature=+crt-static -C link-arg=-Wl,--major-subsystem-version,6,--minor-subsystem-version,1'}and 'FC_OWNED_REMOVAL_SCOPE_HEX'in e['removed_environment_keys'],'Exact default normal build environment; scope unset')
 meta=json.loads((OUT/e['metadata']['path']).read_bytes());need(meta['workspace_root']==str(WORK)and meta['target_directory']==str(TARGET),'Actual Cargo metadata source and target')
 packages=[x for x in meta['packages']if x['name']=='fc-bootstrap'];need(len(packages)==1 and packages[0]['features']['default']==[],'Ordinary default feature only')
 commands=e['commands'];need(len(commands)==1,'Exactly one genuine U2 main compilation');row=commands[0]
 need(row['name']=='product-compile'and row['argv']==['cargo','build','--release','--offline','--locked','-p','fc-bootstrap','--bin','fc-bootstrap','--target','i686-pc-windows-gnu','--target-dir',str(TARGET),'--message-format=json']and row['actual_exit']==0 and row['parent_reaped']is True and row['timed_out']is False,'Actual compiler success/return')
 for cmd in [e['metadata_command'],row]:
  need(cmd['actual_exit']==0 and cmd['parent_reaped']is True and cmd['timed_out']is False,'Actual original metadata/compiler process returned')
  for key in ('stdout','stderr'):
   identity=cmd[key];path=OUT/identity['path'];need(path.resolve().parent==OUT and all(fact(path)[k]==identity[k]for k in ('bytes','sha256')),'Original compiler output bytes')
 msgs=[json.loads(x)for x in (OUT/row['stdout']['path']).read_bytes().splitlines()if x.startswith(b'{')];selected=[x for x in msgs if x.get('reason')=='compiler-artifact'and x.get('target',{}).get('name')=='fc-bootstrap'and x.get('profile',{}).get('test')is False];need(len(selected)==1,'Unique normal main compilerArtifact');m=selected[0]
 exe=TARGET/'i686-pc-windows-gnu/release/fc-bootstrap.exe';need(m['package_id']==packages[0]['id']and m['target']['src_path']==str(WORK/MAIN)and m['target']['kind']==['bin']and m['target']['crate_types']==['bin']and m['features']==['default']and m['executable']==str(exe)and m['profile']['test']is False,'Actual artifact normal bin/default/testfalse identity')
 copy=OUT/'artifacts/fc-bootstrap.exe';need(all(fact(copy)[k]==row['artifact'][k]==fact(exe)[k]for k in ('bytes','sha256')),'Exact copied and original compiler artifact');common=json.loads((A/'evidence.json').read_bytes());old=[x for x in common['commands']if x['name']=='product-compile'][0];need(fact(copy)['sha256']!=old['artifact']['sha256'],'Real changed payload bytes, not only MSI version')
 module=runpy.run_path(str(COMMON/'scripts/package-abi2-upgrade-dev.py'));extent=module['extent'](copy.read_bytes());return dict(status='PASS_NORMAL_GNU_U2_MAIN_ONLY_WITH_U1_IMMUTABLE_AUX_NOT_RELEASE',product=fact(copy),sourceDelta=binding,evidence=fact(p),normalPEExtent=extent,helperAndGuard='MUST_USE_ORIGINAL_U1_NORMAL3_ARTIFACTS',publication='NOT_GRANTED')
