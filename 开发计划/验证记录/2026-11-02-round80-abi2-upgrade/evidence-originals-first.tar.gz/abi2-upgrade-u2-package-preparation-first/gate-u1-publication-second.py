"""Root-only build-time gate: actual U1 complete chain precedes DEV publication.
No installation/permission CLI; never runs Windows. Default inert.
"""
from pathlib import Path
import hashlib,json,runpy,argparse
R=Path('/tmp/fc-round80-controlled-repair');W=R/'checkout-abi2-upgrade-normal-first'
SUPPORT=runpy.run_path(str(R/'abi2-absent-recovery-runtime-preparation-second/transport-support.py'))
phase_returned=SUPPORT['phase_returned']
U1_PRODUCT='D420EDE5-0584-5FDC-8DE8-F25905018A0A'
def need(v,msg):
 if not v:raise ValueError(msg)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def document(path,pin):
 p=Path(path);need(p.is_absolute()and p.is_relative_to(R)and p.is_file()and not p.is_symlink()and sha(p)==pin,'EXACT_OWNED_ROOT_DOCUMENT_SHA');return json.loads(p.read_bytes())
def validate_chain(runtime,manifest,u1):
 need(u1['version']=='0.2.0'and u1['productCode']==U1_PRODUCT and u1['msiContract']['guardABI']==2,'EXACT_U1_PACKAGE_VERSION_PRODUCT_ABI')
 need(manifest['version']=='0.2.0'and manifest['productCode']=='{'+U1_PRODUCT+'}'and manifest['guardABI']==2 and manifest['sourceGit']=='6eb6ec099b6b14e78b280df5df526545c8e04ecc','EXACT_U1_RUNTIME_MANIFEST')
 for key in ['msi','setup']:need(all(manifest[key][k]==u1[key][k]for k in ['bytes','sha256']),'ACTUAL_U1_RUNTIME_ARTIFACT_MATCHES_STATIC_PACKAGE')
 need(manifest['payloads']==u1['payloads'],'EXACT_U1_COMPLETE14_RUNTIME_LEDGER')
 need(runtime['status']=='PASS_GNU_ABI2_SAME_PACKAGE_MAINTENANCE_WIN11_DEV_CONTROLLED_PRODUCT_CLOSURE_AND_EXACT_SCRATCH_CLEANUP'and runtime['downloadVerified']is True and type(runtime['runtimeActualExit'])is int and runtime['runtimeActualExit']==0 and runtime['originalWholeBudgetExceeded']is False,'ACTUAL_COMPLETE_U1_CHAIN_AND_BYTE_DOWNLOAD')
 p=runtime['phase'];need(p['status']=='PASS_GNU_ABI2_SAME_PACKAGE_MAINTENANCE_WIN11_DEV_CONTROLLED_PRODUCT_INSTALL_LICENSE_REPAIR_UNINSTALL'and p['ownerUnknown']is False and p['instrumentUnknown']is False and p['originalBudgetExceeded']is False and p['allSetupBusinessSucceeded']is True,'ACTUAL_U1_NATIVE_PHASE_QUALIFICATION')
 phases=p['phases'];need(len(phases)==3 and [r['verb']for r in phases]==['install','repair','uninstall'],'U1_SERIAL_COMPLETE_THREE_OPERATIONS')
 for row in phases:
  need(phase_returned(row)and row['nativeBusinessSucceeded']is True and row['postPhaseProcesses']['knownZero']is True,'ACTUAL_U1_ORIGINAL_PROCESS_WAIT_EXIT_AND_CHECKED_CLOSE')
  seen=row['observerFinal']['Processes'];need(len(seen)==2 and sorted(x['Role']for x in seen)==sorted(['setup-'+row['verb'],'owned-guardian']),'EXACT_OBSERVED_ORIGINAL_U1_B_AND_G_EACH_PHASE')
 for key in ['initial','uninstalled','finallyProduct']:need(p[key]['knownAbsent']is True and p[key]['runAbsent']is True and p[key]['status']=='PASS_READONLY_EXPECTED_ABSENT','U1_STRICT_ABSENT_BOUNDARIES')
 for key in ['installed','repaired']:need(p[key]['healthyPresent']is True and p[key]['runAbsent']is True and p[key]['status']=='PASS_READONLY_EXPECTED_PRESENT','U1_COMPLETE14_HEALTH')
 need(p['licenseDamage']['status']=='DELETED_ONLY_EXACT_NEW_INSTALL_LICENSE_BY_ORIGINAL_HANDLE'and p['licenseDamage']['checkedClose']is True and p['damaged']['healthyPresent']is False,'U1_REAL_LICENSE_DAMAGE_AND_REPAIR')
 need(p['finallyCoordination']['pendingKnownAbsent']is True and p['finallyCoordination']['namespaceKnownAbsent']is True,'U1_PENDING_GATE_FINAL_ABSENT')
 for key in ['uninstalledCache']:need(p[key]['allObservedAbsent']is True,'U1_ORIGINAL_CACHE_PATH_RETIRED')
 return True

def prepare_record(package_report,package_sha,runtime_report,runtime_sha):
 need(Path(package_report)==R/'abi2-upgrade-u1-dev-product-package-first/report.json'and package_sha=='fff5900354e69684c45116369f57c17e15db6a5eb563559746d8351171469d22'and Path(runtime_report)==R/'abi2-upgrade-u1-product-runtime-first/report.json'and runtime_sha=='4605e523204533938dc2923d2c3d1f5c4f16d507500b868b64852fa34b876a03','FIXED_ACTUAL_ROOT_U1_STATIC_AND_NATIVE_RECEIPTS')
 u1=document(package_report,package_sha);need(u1['status']=='PASS_NORMAL_GNU_ABI2_UPGRADE_CAPABLE_DEV_STATIC_BUNDLE_NATIVE_NOT_RUN'and u1['lifecycleMode']=='ABI2_UPGRADE_CAPABLE_NORMAL_GNU_DEV','ACTUAL_UPGRADE_CAPABLE_U1_NORMAL_STATIC')
 runtime=document(runtime_report,runtime_sha);af=runtime['artifactManifest'];manifest=document(af['path'],af['sha256']);need(Path(af['path']).stat().st_size==af['bytes'],'U1_ARTIFACT_MANIFEST_BYTES');validate_chain(runtime,manifest,u1)
 need(manifest['status']=='BOUND_GNU_ABI2_UPGRADE_U1_PRODUCT_INPUTS_NOT_RELEASE'and runtime['scope']=='GNU_ABI2_UPGRADE_U1_WIN11_DEV_FRESH_LICENSE_REPAIR_UNINSTALL_NOT_RELEASE','ACTUAL_NEW_U1_INPUT_AND_NATIVE_SCOPE')
 normal=runpy.run_path(str(W/'scripts/package-abi2-upgrade-dev.py'));evidence=R/'abi2-upgrade-u1-normal-producer-first/evidence.json';normal['admit_normal_inputs'](W,evidence,u1['sourceEvidenceSha256'])
 pub=runpy.run_path(str(W/'scripts/installer-upgrade-publication.py'));carrier=normal['C'];schema=pub['schema_from_rust']((W/'crates/fc-windows/src/installer_lifecycle/native/broker/maintenance/schema.rs').read_text())
 source=Path(package_report).parent/u1['msi']['path'];tables=pub['capture'](source,u1['msi']['sha256'],schema);streams=dict(next(rows for name,cols,rows in tables if name=='Binary'));need(set(streams)=={'FcControlledGuardDll','FcGuardClientTemplate','FcPayloadManifest'},'U1_EXACT_THREE_BINARY')
 envelope=streams['FcPayloadManifest'];old=carrier['parse_payload_manifest'](envelope);need(old['product']==U1_PRODUCT and old['version']=='0.2.0'and old['package']==u1['packageCode'],'U1_ACTUAL_BINARY_IDENTITY')
 provenance=u1['normalProvenance'];meta=dict(target=2,source_commit=provenance['source_sha'],source_manifest_sha=provenance['source_inventory_sha256'],producer_sha=provenance['result_sha256'],source_msi_sha=u1['msi']['sha256'],template_sha=hashlib.sha256(streams['FcGuardClientTemplate']).hexdigest(),guard_sha=hashlib.sha256(streams['FcControlledGuardDll']).hexdigest(),logical_sha=pub['signature'](tables)[0],template_bytes=len(streams['FcGuardClientTemplate']))
 need(meta['template_sha']==u1['template']['sha256'],'ACTUAL_U1_CANONICAL_TEMPLATE')
 need(meta['source_commit']=='6eb6ec099b6b14e78b280df5df526545c8e04ecc'and meta['producer_sha']=='3e60a09f3758cccecba8403fd98548b511a3acb100bc01c849f42cde4d122910'and normal['admit_normal_inputs'](W,evidence,u1['sourceEvidenceSha256'])['sourceInputCount']==595,'EXACT_NORMAL_U1_PRODUCER_NOT_OLD_CODEC_FIXTURE')
 interop_path=R/'abi2-upgrade-u1-publication-interop-first/report.json';interop=document(interop_path,'636e9b2bf718b2b7d93025b04654991497194d2e9b08c0024566d0629777b64f');need(interop['status']=='PASS_ACTUAL_U1_SOURCE31_RUST_PYTHON_CANONICAL_BYTES_EQUAL'and interop['sourceUnchanged']is True and interop['logicalSHA256']==meta['logical_sha']and interop['source']['sha256']==meta['source_msi_sha']and interop['tableCount']==31 and all(x['actualExit']==0 and x['originalParentReaped']is True for x in interop['commands']),'ACTUAL_U1_SOURCE31_RUST_PYTHON_CANONICAL_INTEROP')
 blob=pub['encode_format'](meta,envelope,carrier['parse_payload_manifest'])
 return blob,dict(status='BOUND_DEV_PREDECESSOR_FROM_ACTUAL_COMPLETE_U1_CHAIN_NOT_FORMAL_CI',u1Package=dict(path=str(package_report),sha256=package_sha),u1Runtime=dict(path=str(runtime_report),sha256=runtime_sha),meta=meta,cacheCompatibilityEvidence=dict(method='PRODUCTION_SUCCESS_BRANCH_INFERENCE',nativeCacheDigestSerialized=False,sourceCanonicalInterop=dict(path=str(interop_path),bytes=interop_path.stat().st_size,sha256=sha(interop_path)),frozenProductionProofSources=[dict(path=str(W/name),bytes=(W/name).stat().st_size,sha256=sha(W/name))for name in ['crates/fc-windows/src/installer_lifecycle/native/broker/maintenance.rs','crates/fc-windows/src/installer_lifecycle/native/broker/controlled_owner.rs']],directCacheDigestReceipt='NOT_SERIALIZED',actualNativeRepairReturned0=True,sourceDigestOrigin='LIBMSI_READONLY_FIXED31_U1_SOURCE_ONLY',sourceEqualsCacheBasis='Frozen native maintenance.rs same_source compares CNG source_logical and cache_logical before constructing private VerifiedSameSourceMaintenance; controlled_owner requires it for Repair and Uninstall; original actual U1 Repair and Uninstall each returned0',upgradeRechecks='Actual native old cache31 recaptured and compared to this record on every Upgrade; no whole-cache SHA equivalence'),record=dict(bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest()),cacheVsSource='Whole cache SHA NOT equated to source; actual Upgrade native captures old cache31-table logical facts against this source signature before Begin',BeginEndTelemetry='No numeric API return synthesized from logs or exits')

def main():
 p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');p.add_argument('--u1-package');p.add_argument('--u1-package-sha');p.add_argument('--u1-runtime');p.add_argument('--u1-runtime-sha');p.add_argument('--output-dir');a=p.parse_args()
 if not a.execute:print('{"status":"NOT_RUN_NO_PUBLICATION","Windows":"NOT_CONTACTED"}');return
 need(all([a.u1_package,a.u1_package_sha,a.u1_runtime,a.u1_runtime_sha,a.output_dir]),'ALL_ROOT_BOUND_U1_CHAIN_ARGUMENTS')
 blob,report=prepare_record(a.u1_package,a.u1_package_sha,a.u1_runtime,a.u1_runtime_sha);d=Path(a.output_dir);need(d.is_absolute()and d.parent==R and not d.exists(),'NEW_OWNED_PUBLICATION_DIR');d.mkdir();(d/'predecessor.bin').write_bytes(blob);(d/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
if __name__=='__main__':main()
