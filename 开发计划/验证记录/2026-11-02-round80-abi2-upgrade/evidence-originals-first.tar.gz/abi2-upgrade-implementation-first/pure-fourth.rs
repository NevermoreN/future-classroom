mod installer_lifecycle {
#[derive(Debug,PartialEq,Eq)]pub enum LifecycleError {Invalid,Unsettled}
pub type Result<T> = std::result::Result<T,LifecycleError>;
pub const INSTALL_FAMILY:&str="99378807-098D-5F04-8D4D-F181DFA218D5";
pub mod broker {
#[path="/tmp/fc-round80-controlled-repair/checkout-abi2-upgrade-first/crates/fc-windows/src/installer_lifecycle/broker/manifest.rs"]pub mod manifest;
#[path="/tmp/fc-round80-controlled-repair/checkout-abi2-upgrade-first/crates/fc-windows/src/installer_lifecycle/broker/carrier.rs"]pub mod carrier;
#[path="/tmp/fc-round80-controlled-repair/checkout-abi2-upgrade-first/crates/fc-windows/src/installer_lifecycle/broker/payload_manifest.rs"]pub mod payload_manifest;
mod published_host {#[path="/tmp/fc-round80-controlled-repair/checkout-abi2-upgrade-first/crates/fc-windows/src/installer_lifecycle/broker/published_host/predecessor.rs"]pub(crate) mod predecessor;
use super::{
    super::{LifecycleError, Result},
    carrier,
};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum PublishedHostId {
    Abi2Initial,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum HostTarget {
    I686Win7Msvc,
}
#[derive(Debug)]
pub(crate) struct PublishedInstallerHost {
    id: PublishedHostId,
    abi: u16,
    target: HostTarget,
    source_commit: [u8; 20],
    source_manifest_sha256: [u8; 32],
    compiler_artifact_sha256: [u8; 32],
    producer_report_sha256: [u8; 32],
    template_bytes: u32,
    template_sha256: [u8; 32],
    normal_profile_test: bool,
}
// Adding an entry requires separately reviewed original CI/producer/source and
// immutable ABI2 template evidence. Never fill this from self-reported metadata.
const PUBLISHED: &[PublishedInstallerHost] = &[];
impl PublishedInstallerHost {
    pub(crate) fn id(&self) -> PublishedHostId {
        self.id
    }
    pub(crate) fn abi(&self) -> u16 {
        self.abi
    }
    pub(crate) fn source_commit(&self) -> [u8; 20] {
        self.source_commit
    }
    pub(crate) fn source_manifest_sha256(&self) -> [u8; 32] {
        self.source_manifest_sha256
    }
    pub(crate) fn compiler_artifact_sha256(&self) -> [u8; 32] {
        self.compiler_artifact_sha256
    }
    pub(crate) fn producer_report_sha256(&self) -> [u8; 32] {
        self.producer_report_sha256
    }
    pub(crate) fn template_bytes(&self) -> u32 {
        self.template_bytes
    }
    pub(crate) fn expected_template_sha256(&self) -> [u8; 32] {
        self.template_sha256
    }
    fn well_formed(&self) -> bool {
        self.abi == carrier::ABI
            && self.target == HostTarget::I686Win7Msvc
            && self.source_commit != [0; 20]
            && [
                self.source_manifest_sha256,
                self.compiler_artifact_sha256,
                self.producer_report_sha256,
                self.template_sha256,
            ]
            .iter()
            .all(|v| *v != [0; 32])
            && (carrier::MIN_IMAGE_BYTES..=carrier::MAX_IMAGE_BYTES)
                .contains(&(self.template_bytes as usize))
            && !self.normal_profile_test
    }
}
pub(crate) fn lookup(id: PublishedHostId) -> Result<&'static PublishedInstallerHost> {
    let mut found = PUBLISHED.iter().filter(|r| r.id == id);
    let record = found.next().ok_or(LifecycleError::Invalid)?;
    if found.next().is_some() || !record.well_formed() {
        return Err(LifecycleError::Invalid);
    }
    Ok(record)
}

#[cfg(test)]
mod tests {
    use super::*;
    fn fixture_record_not_published() -> PublishedInstallerHost {
        PublishedInstallerHost {
            id: PublishedHostId::Abi2Initial,
            abi: 2,
            target: HostTarget::I686Win7Msvc,
            source_commit: [1; 20],
            source_manifest_sha256: [2; 32],
            compiler_artifact_sha256: [3; 32],
            producer_report_sha256: [4; 32],
            template_bytes: 1156,
            template_sha256: [5; 32],
            normal_profile_test: false,
        }
    }
    #[test]
    fn abi2_publication_registry_has_no_fixture_or_runtime_hash_authority() {
        assert!(lookup(PublishedHostId::Abi2Initial).is_err());
        let fixture = fixture_record_not_published();
        assert!(fixture.well_formed());
        assert!(lookup(fixture.id()).is_err());
        assert_eq!(fixture.abi(), 2);
        assert_eq!(fixture.source_commit(), [1; 20]);
        assert_eq!(fixture.source_manifest_sha256(), [2; 32]);
        assert_eq!(fixture.compiler_artifact_sha256(), [3; 32]);
        assert_eq!(fixture.producer_report_sha256(), [4; 32]);
        assert_eq!(fixture.template_bytes(), 1156);
        assert_eq!(fixture.expected_template_sha256(), [5; 32]);
    }
    #[test]
    fn abi2_publication_metadata_rejects_zero_provenance_test_artifact_and_wrong_abi() {
        let mut r = fixture_record_not_published();
        r.source_commit = [0; 20];
        assert!(!r.well_formed());
        let mut r = fixture_record_not_published();
        r.normal_profile_test = true;
        assert!(!r.well_formed());
        let mut r = fixture_record_not_published();
        r.abi = 1;
        assert!(!r.well_formed());
        let mut r = fixture_record_not_published();
        r.template_sha256 = [0; 32];
        assert!(!r.well_formed());
        let mut r = fixture_record_not_published();
        r.template_bytes = 0;
        assert!(!r.well_formed());
    }
}}
}
mod guard_contract {use super::{LifecycleError, Result};

#[path="/tmp/fc-round80-controlled-repair/checkout-abi2-upgrade-first/crates/fc-windows/src/installer_lifecycle/guard_contract/v2.rs"]pub(crate) mod v2;

pub(crate) const INFO_PREFIX: &str = "FCGI1:";
pub(crate) const PIPE_PREFIX: &str = r"\\.\pipe\FutureClassroom-ControlledGuard-";
pub(crate) const GUARD_TEMPLATE_QUERY: &str =
    "SELECT `Data` FROM `Binary` WHERE `Name` = 'FcGuardClientTemplate'";
pub(crate) const GRANT_BYTES: usize = 48;
pub(crate) const BRIDGE_BYTES: usize = 32;
pub(crate) const MAX_GRANT_MILLIS: u64 = 120_000;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct Nonce([u8; 16]);
impl Nonce {
    pub(crate) fn from_bytes(bytes: [u8; 16]) -> Result<Self> {
        if bytes == [0; 16] {
            return Err(LifecycleError::Invalid);
        }
        Ok(Self(bytes))
    }
    pub(crate) fn parse_info(info: &str) -> Result<Self> {
        let hex = info
            .strip_prefix(INFO_PREFIX)
            .filter(|s| s.len() == 32)
            .ok_or(LifecycleError::Invalid)?;
        fn nibble(b: u8) -> Result<u8> {
            match b {
                b'0'..=b'9' => Ok(b - b'0'),
                b'a'..=b'f' => Ok(b - b'a' + 10),
                _ => Err(LifecycleError::Invalid),
            }
        }
        let mut bytes = [0; 16];
        for (i, pair) in hex.as_bytes().as_chunks::<2>().0.iter().enumerate() {
            bytes[i] = (nibble(pair[0])? << 4) | nibble(pair[1])?;
        }
        Self::from_bytes(bytes)
    }
    fn hex(self) -> String {
        const HEX: &[u8; 16] = b"0123456789abcdef";
        let mut result = String::with_capacity(32);
        for byte in self.0 {
            result.push(char::from(HEX[usize::from(byte >> 4)]));
            result.push(char::from(HEX[usize::from(byte & 15)]));
        }
        result
    }
    pub(crate) fn info(self) -> String {
        format!("{INFO_PREFIX}{}", self.hex())
    }
    pub(crate) fn pipe_name(self) -> String {
        format!("{PIPE_PREFIX}{}", self.hex())
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct Grant {
    nonce: Nonce,
    deadline_ticks: u64,
    transaction_id: u32,
}
impl Grant {
    pub(crate) fn new(nonce: Nonce, deadline_ticks: u64, transaction_id: u32) -> Result<Self> {
        if deadline_ticks == 0 || transaction_id == 0 {
            return Err(LifecycleError::Invalid);
        }
        Ok(Self {
            nonce,
            deadline_ticks,
            transaction_id,
        })
    }
    pub(crate) fn deadline_ticks(self) -> u64 {
        self.deadline_ticks
    }
    pub(crate) fn encode(self) -> [u8; GRANT_BYTES] {
        let mut b = [0; GRANT_BYTES];
        b[..4].copy_from_slice(b"FCGA");
        b[4] = 1;
        b[5] = 1;
        b[8..24].copy_from_slice(&self.nonce.0);
        b[24..32].copy_from_slice(&self.deadline_ticks.to_le_bytes());
        b[32..36].copy_from_slice(&self.transaction_id.to_le_bytes());
        b
    }
    pub(crate) fn parse(bytes: &[u8]) -> Result<Self> {
        let b: &[u8; GRANT_BYTES] = bytes.try_into().map_err(|_| LifecycleError::Invalid)?;
        if &b[..4] != b"FCGA" || b[4] != 1 || b[5] != 1 || b[6..8] != [0; 2] || b[36..48] != [0; 12]
        {
            return Err(LifecycleError::Invalid);
        }
        Self::new(
            Nonce::from_bytes(b[8..24].try_into().unwrap())?,
            u64::from_le_bytes(b[24..32].try_into().unwrap()),
            u32::from_le_bytes(b[32..36].try_into().unwrap()),
        )
    }
    pub(crate) fn validate(self, expected_nonce: Nonce, now_ticks: u64) -> Result<()> {
        if self.nonce != expected_nonce
            || self.deadline_ticks <= now_ticks
            || self.deadline_ticks - now_ticks > MAX_GRANT_MILLIS
        {
            return Err(LifecycleError::Invalid);
        }
        Ok(())
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum BridgeKind {
    Request,
    Ack,
    Returned,
}
impl BridgeKind {
    fn byte(self) -> u8 {
        match self {
            Self::Request => 1,
            Self::Ack => 2,
            Self::Returned => 3,
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct Bridge {
    kind: BridgeKind,
    transaction_id: u32,
    nonce: Nonce,
    code: u32,
}
impl Bridge {
    pub(crate) fn new(
        kind: BridgeKind,
        transaction_id: u32,
        nonce: Nonce,
        code: u32,
    ) -> Result<Self> {
        if transaction_id == 0 || code == u32::MAX || (kind != BridgeKind::Returned && code != 0) {
            return Err(LifecycleError::Invalid);
        }
        Ok(Self {
            kind,
            transaction_id,
            nonce,
            code,
        })
    }
    pub(crate) fn kind(self) -> BridgeKind {
        self.kind
    }
    pub(crate) fn transaction_id(self) -> u32 {
        self.transaction_id
    }
    pub(crate) fn nonce(self) -> Nonce {
        self.nonce
    }
    pub(crate) fn code(self) -> u32 {
        self.code
    }
    pub(crate) fn encode(self) -> [u8; BRIDGE_BYTES] {
        let mut b = [0; BRIDGE_BYTES];
        b[..4].copy_from_slice(b"FCGB");
        b[4] = 1;
        b[5] = self.kind.byte();
        b[8..12].copy_from_slice(&self.transaction_id.to_le_bytes());
        b[12..28].copy_from_slice(&self.nonce.0);
        b[28..32].copy_from_slice(&self.code.to_le_bytes());
        b
    }
    pub(crate) fn parse(bytes: &[u8]) -> Result<Self> {
        let b: &[u8; BRIDGE_BYTES] = bytes.try_into().map_err(|_| LifecycleError::Invalid)?;
        if &b[..4] != b"FCGB" || b[4] != 1 || b[6..8] != [0; 2] {
            return Err(LifecycleError::Invalid);
        }
        let kind = match b[5] {
            1 => BridgeKind::Request,
            2 => BridgeKind::Ack,
            3 => BridgeKind::Returned,
            _ => return Err(LifecycleError::Invalid),
        };
        Self::new(
            kind,
            u32::from_le_bytes(b[8..12].try_into().unwrap()),
            Nonce::from_bytes(b[12..28].try_into().unwrap())?,
            u32::from_le_bytes(b[28..32].try_into().unwrap()),
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn info_is_exact_lower_hex_with_no_zero_or_path_authority() {
        let n = Nonce::parse_info("FCGI1:00112233445566778899aabbccddeeff").unwrap();
        assert_eq!(
            n.0,
            [0, 17, 34, 51, 68, 85, 102, 119, 136, 153, 170, 187, 204, 221, 238, 255]
        );
        assert_eq!(n.info(), "FCGI1:00112233445566778899aabbccddeeff");
        assert_eq!(
            n.pipe_name(),
            format!("{PIPE_PREFIX}00112233445566778899aabbccddeeff")
        );
        for info in [
            "FCGI1:00000000000000000000000000000000",
            "FCGI1:00112233445566778899AABBCCDDEEFF",
            "FCGI1:00112233445566778899aabbccddeeff ",
            "FCGI1:../pipe",
            "FCGI1:00112233445566778899aabbccddee",
            " FCGI1:00112233445566778899aabbccddeeff",
        ] {
            assert!(Nonce::parse_info(info).is_err());
        }
    }
    #[test]
    fn grant_has_fixed_offsets_and_original_absolute_deadline() {
        let n = Nonce::from_bytes([7; 16]).unwrap();
        let g = Grant::new(n, 0x0102030405060708, 0x11223344).unwrap();
        let bytes = g.encode();
        assert_eq!(&bytes[..8], b"FCGA\x01\x01\0\0");
        assert_eq!(&bytes[8..24], &[7; 16]);
        assert_eq!(
            &bytes[24..36],
            &[8, 7, 6, 5, 4, 3, 2, 1, 0x44, 0x33, 0x22, 0x11]
        );
        assert_eq!(&bytes[36..], &[0; 12]);
        assert_eq!(Grant::parse(&bytes).unwrap(), g);
        for i in [0, 4, 5, 6, 7, 36, 39, 40, 47] {
            let mut bad = bytes;
            bad[i] ^= 0x80;
            assert!(Grant::parse(&bad).is_err());
        }
        for len in [0, 1, 47] {
            assert!(Grant::parse(&bytes[..len]).is_err());
        }
        let mut tail = bytes.to_vec();
        tail.push(0);
        assert!(Grant::parse(&tail).is_err());
        let g = Grant::new(n, 120_001, 1).unwrap();
        assert!(g.validate(n, 1).is_ok());
        assert!(g.validate(n, 0).is_err());
        assert!(g.validate(n, 120_001).is_err());
        assert!(g.validate(Nonce::from_bytes([8; 16]).unwrap(), 1).is_err());
        assert!(Grant::new(n, 0, 1).is_err());
        assert!(Grant::new(n, 1, 0).is_err());
    }
    #[test]
    fn bridge_is_closed_and_failure_return_cannot_be_acknowledgement() {
        let n = Nonce::from_bytes([9; 16]).unwrap();
        let b = Bridge::new(BridgeKind::Returned, 0x11223344, n, 1603).unwrap();
        let raw = b.encode();
        assert_eq!(&raw[..12], b"FCGB\x01\x03\0\0\x44\x33\x22\x11");
        assert_eq!(&raw[12..28], &[9; 16]);
        assert_eq!(&raw[28..], &[0x43, 6, 0, 0]);
        assert_eq!(Bridge::parse(&raw).unwrap(), b);
        for kind in [BridgeKind::Request, BridgeKind::Ack] {
            assert!(Bridge::new(kind, 1, n, 1603).is_err());
            assert!(Bridge::new(kind, 1, n, 0).is_ok());
        }
        assert!(Bridge::new(BridgeKind::Returned, 0, n, 0).is_err());
        assert!(Bridge::new(BridgeKind::Returned, 1, n, u32::MAX).is_err());
        for i in [0, 4, 5, 6, 7] {
            let mut bad = raw;
            bad[i] = 255;
            assert!(Bridge::parse(&bad).is_err());
        }
        let mut bad = raw;
        bad[12..28].fill(0);
        assert!(Bridge::parse(&bad).is_err());
        assert!(Bridge::parse(&raw[..31]).is_err());
        let mut bad = raw.to_vec();
        bad.push(0);
        assert!(Bridge::parse(&bad).is_err());
    }
}}
mod exact_guard_association {use super::{LifecycleError,Result};use super::guard_contract::{Nonce,Bridge,BridgeKind,v2};use v2::ObservedPackage;struct GuardAssociation {
    transaction: u32,
    nonce: Option<Nonce>,
    returned: bool,
    packages: Vec<ObservedPackage>,
    ticket: usize,
    previous_nonce: Option<Nonce>,
}
impl GuardAssociation {
    fn new(transaction: u32) -> Self {
        Self {
            transaction,
            nonce: None,
            returned: false,
            packages: Vec::new(),
            ticket: 0,
            previous_nonce: None,
        }
    }
    // Private B-only construction after native Fresh admission/revalidation,
    // exclusive Draft, actual original Begin and armed Pending all succeeded.
    fn package(transaction: u32, package: ObservedPackage) -> Self {
        Self {
            packages: vec![package],
            ..Self::new(transaction)
        }
    }
    fn upgrade(transaction: u32, packages: [ObservedPackage; 2]) -> Self {
        Self {
            packages: packages.into(),
            ..Self::new(transaction)
        }
    }
    fn observe_nonce(
        &mut self,
        kind: BridgeKind,
        transaction: u32,
        nonce: Nonce,
    ) -> Result<Option<BridgeKind>> {
        if transaction != self.transaction {
            return Err(LifecycleError::Invalid);
        }
        match kind {
            BridgeKind::Request if self.nonce.is_none() => {
                self.nonce = Some(nonce);
                Ok(Some(BridgeKind::Ack))
            }
            BridgeKind::Returned if self.nonce == Some(nonce) && !self.returned => {
                self.returned = true;
                Ok(None)
            }
            _ => Err(LifecycleError::Invalid),
        }
    }
    fn observe(&mut self, bridge: Bridge) -> Result<Option<Bridge>> {
        if !self.packages.is_empty() || bridge.code() != 0 {
            return Err(LifecycleError::Invalid);
        }
        let reply = self.observe_nonce(bridge.kind(), bridge.transaction_id(), bridge.nonce())?;
        reply
            .map(|kind| Bridge::new(kind, self.transaction, bridge.nonce(), 0))
            .transpose()
    }
    fn observe_package(&mut self, bridge: v2::Bridge) -> Result<Option<v2::Bridge>> {
        if self.returned
            && bridge.kind() == BridgeKind::Request
            && self.ticket + 1 < self.packages.len()
        {
            if self.packages.get(self.ticket + 1) != Some(bridge.package())
                || self.nonce == Some(bridge.nonce())
            {
                return Err(LifecycleError::Invalid);
            }
            self.previous_nonce = self.nonce;
            self.nonce = None;
            self.returned = false;
            self.ticket += 1;
        }
        if self.packages.get(self.ticket) != Some(bridge.package())
            || self.previous_nonce == Some(bridge.nonce())
        {
            return Err(LifecycleError::Invalid);
        }
        let reply = self.observe_nonce(bridge.kind(), bridge.transaction_id(), bridge.nonce())?;
        reply
            .map(|kind| {
                v2::Bridge::new(
                    kind,
                    self.transaction,
                    bridge.nonce(),
                    bridge.package().clone(),
                )
            })
            .transpose()
    }
    fn require_prefix_returned(&self) -> Result<()> {
        if self.returned {
            Ok(())
        } else {
            Err(LifecycleError::Unsettled)
        }
    }
    fn require_returned(&self) -> Result<()> {
        if self.returned && self.ticket + 1 >= self.packages.len() {
            Ok(())
        } else {
            Err(LifecycleError::Unsettled)
        }
    }
}
    #[test]
    fn upgrade_two_tickets_require_new_then_old_distinct_nonce_and_no_third() {
        let new = ObservedPackage::new(
            "99378807-098D-5F04-8D4D-F181DFA218D6",
            "99378807-098D-5F04-8D4D-F181DFA218D7",
            "0.3.0",
        )
        .unwrap();
        let old = ObservedPackage::new(
            "99378807-098D-5F04-8D4D-F181DFA218D8",
            "99378807-098D-5F04-8D4D-F181DFA218D9",
            "0.2.0",
        )
        .unwrap();
        let a = Nonce::from_bytes([7; 16]).unwrap();
        let b = Nonce::from_bytes([8; 16]).unwrap();
        let msg = |kind, nonce, p| v2::Bridge::new(kind, 42, nonce, p).unwrap();
        let mut g = GuardAssociation::upgrade(42, [new.clone(), old.clone()]);
        assert!(g
            .observe_package(msg(BridgeKind::Request, a, old.clone()))
            .is_err());
        g.observe_package(msg(BridgeKind::Request, a, new.clone()))
            .unwrap();
        assert!(g
            .observe_package(msg(BridgeKind::Request, b, old.clone()))
            .is_err());
        g.observe_package(msg(BridgeKind::Returned, a, new.clone()))
            .unwrap();
        assert!(g.require_returned().is_err());
        g.require_prefix_returned().unwrap();
        assert!(g
            .observe_package(msg(BridgeKind::Request, a, old.clone()))
            .is_err());
        assert!(g
            .observe_package(msg(BridgeKind::Request, b, new.clone()))
            .is_err());
        g.observe_package(msg(BridgeKind::Request, b, old.clone()))
            .unwrap();
        assert!(g
            .observe_package(msg(BridgeKind::Returned, a, old.clone()))
            .is_err());
        g.observe_package(msg(BridgeKind::Returned, b, old.clone()))
            .unwrap();
        g.require_returned().unwrap();
        for p in [new, old] {
            assert!(g.observe_package(msg(BridgeKind::Request, a, p)).is_err());
        }
    }
}
#[test]fn actual_python_record_parses_exact_real_old_source_facts_only(){let b=include_bytes!("/tmp/fc-round80-controlled-repair/abi2-upgrade-implementation-first/canonical-codec-first/predecessor-format-fixture.bin");let r=broker::published_host::predecessor::parse(b).unwrap();assert_eq!(r.target,2);assert_eq!(r.template_bytes,714372);assert_eq!(r.payload().unwrap().payload().entries.len(),14);assert_eq!(r.payload().unwrap().payload().product,"9E50831D-7811-5039-8BC3-4934647448D8");assert_eq!(r.payload().unwrap().payload().version,"0.1.0");}
}
