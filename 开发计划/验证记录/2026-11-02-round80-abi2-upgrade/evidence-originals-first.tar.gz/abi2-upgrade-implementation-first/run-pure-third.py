from pathlib import Path
import json,subprocess,time,hashlib
R=Path('/tmp/fc-round80-controlled-repair');W=R/'checkout-abi2-upgrade-first';O=R/'abi2-upgrade-implementation-first';B=W/'crates/fc-windows/src/installer_lifecycle/broker'
wrapper=O/'pure-third.rs';exe=O/'pure-third'
s='mod installer_lifecycle {\n#[derive(Debug,PartialEq,Eq)]pub enum LifecycleError {Invalid,Unsettled}\npub type Result<T> = std::result::Result<T,LifecycleError>;\npub const INSTALL_FAMILY:&str="99378807-098D-5F04-8D4D-F181DFA218D5";\npub mod broker {\n'
for name in ['manifest','carrier','payload_manifest','published_host']:s+='#[path='+json.dumps(str(B/(name+'.rs')))+']pub mod '+name+';\n'
g=(W/'crates/fc-windows/src/installer_lifecycle/guard_contract.rs').read_text();g='\n'.join(l for l in g.splitlines()if not l.startswith('//!'));g=g.replace('pub(crate) mod v2;','#[path='+json.dumps(str(W/'crates/fc-windows/src/installer_lifecycle/guard_contract/v2.rs'))+']pub(crate) mod v2;');s+='}\nmod guard_contract {'+g+'}\n'
owner=(W/'crates/fc-windows/src/installer_lifecycle/native/broker/controlled_owner.rs').read_text();assoc=owner[owner.index('struct GuardAssociation {'):owner.index('fn pipe_name(',owner.index('struct GuardAssociation {'))];a=owner.index('    #[test]\n    fn upgrade_two_tickets_');z=owner.index('    #[test]',a+15);test=owner[a:z]
s+='mod exact_guard_association {use super::{LifecycleError,Result};use super::guard_contract::{Nonce,Bridge,BridgeKind,v2};use v2::ObservedPackage;'+assoc+test+'}\n'
s+='#[test]fn actual_python_record_parses_exact_real_old_source_facts_only(){let b=include_bytes!('+json.dumps(str(O/'canonical-codec-first/predecessor-format-fixture.bin'))+');let r=broker::published_host::predecessor::parse(b).unwrap();assert_eq!(r.target,2);assert_eq!(r.template_bytes,714372);assert_eq!(r.payload().unwrap().payload().entries.len(),14);assert_eq!(r.payload().unwrap().payload().product,"9E50831D-7811-5039-8BC3-4934647448D8");assert_eq!(r.payload().unwrap().payload().version,"0.1.0");}\n}\n';wrapper.write_text(s);r=[]
for name,cmd in [('pure-compile-third',['rustc','--edition=2021','--test',str(wrapper),'-o',str(exe)]),('pure-tests-third',[str(exe),'--nocapture'])]:
 start=time.monotonic();p=subprocess.run(cmd,capture_output=True,timeout=90);(O/(name+'.stdout.log')).write_bytes(p.stdout);(O/(name+'.stderr.log')).write_bytes(p.stderr);r.append(dict(name=name,argv=cmd,actualExit=p.returncode,parentReaped=True,seconds=time.monotonic()-start))
 if p.returncode:break
(O/'pure-checks-third.json').write_text(json.dumps({'scope':'Actual included format/contract modules and exact extracted GuardAssociation/test only; no native API or new authority','checks':r,'wrapperSha256':hashlib.sha256(wrapper.read_bytes()).hexdigest()},indent=2)+'\n');print(json.dumps(r))
