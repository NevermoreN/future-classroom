//! Local test-only wire; not a production CLI or installed trust constructor.
use std::{io::Write, process::{Command,Stdio}};
#[derive(Debug, PartialEq, Eq)]pub enum LifecycleError { Invalid }
pub type Result<T> = std::result::Result<T,LifecycleError>;
const MAX_ROWS:usize=72;
#[path="/tmp/fc-round80-controlled-repair/checkout-abi2-upgrade-first/crates/fc-windows/src/installer_lifecycle/native/broker/maintenance/schema.rs"]mod schema;
#[path="/tmp/fc-round80-controlled-repair/checkout-abi2-upgrade-first/crates/fc-windows/src/installer_lifecycle/native/broker/maintenance/logical.rs"]mod logical;
fn take<'a>(b:&mut &'a [u8],n:usize)-> &'a[u8]{assert!(b.len()>=n);let (a,z)=b.split_at(n);*b=z;a}
fn number(b:&mut &[u8])->usize{u32::from_le_bytes(take(b,4).try_into().unwrap())as usize}
fn text(b:&mut &[u8])->String{let n=number(b);assert!(n<=4096);String::from_utf8(take(b,n).to_vec()).unwrap()}
fn bytes(hash:&str)->[u8;32]{std::array::from_fn(|i|u8::from_str_radix(&hash[2*i..2*i+2],16).unwrap())}
fn digest(b:&[u8])->[u8;32]{
 let mut child=Command::new("sha256sum").stdin(Stdio::piped()).stdout(Stdio::piped()).spawn().unwrap();
 child.stdin.take().unwrap().write_all(b).unwrap();let out=child.wait_with_output().unwrap();assert!(out.status.success());bytes(&String::from_utf8(out.stdout).unwrap()[..64])
}
fn main(){
 let path=std::env::args().nth(1).expect("test-only capture input");let input=std::fs::read(path).unwrap();let mut b=input.as_slice();assert_eq!(take(&mut b,b"FCDB-CAPTURE-v1\0".len()),b"FCDB-CAPTURE-v1\0");assert_eq!(number(&mut b),31);
 let mut all=logical::DOMAIN.to_vec();let mut total=0;
 for table in schema::TABLES{
  assert_eq!(schema::table(table.name).unwrap().query,format!("SELECT * FROM `{}`",table.name));
  assert_eq!(text(&mut b),table.name);assert_eq!(number(&mut b),table.columns.len());
  for (name,kind)in table.columns{assert_eq!(text(&mut b),*name);assert_eq!(text(&mut b),*kind);}
  let count=number(&mut b);assert!(count<=72);let mut hashes=Vec::new();
  for _ in 0..count{
   let mut row=Vec::new();
   for (_,kind)in table.columns{
    let null=take(&mut b,1)[0];assert!(null<=1);row.extend(logical::null(null==1));if null==1{continue}
    match kind.as_bytes()[0].to_ascii_lowercase(){
     b'i'=>{let n=i32::from_le_bytes(take(&mut b,4).try_into().unwrap());row.extend(logical::integer(n).unwrap());}
     b's'|b'l'|b'v'=>{let n=number(&mut b);assert!(n<=64*1024*1024);let data=take(&mut b,n);if kind.as_bytes()[0].to_ascii_lowercase()!=b'v'{assert!(std::str::from_utf8(data).is_ok());}row.extend(logical::length(n).unwrap());row.extend(data);}
     _=>panic!("type"),
    }
   }
   hashes.push(digest(&row));
  }
  hashes.sort_unstable();all.extend(logical::table_header(table,count).unwrap());for hash in hashes{all.extend(hash);}total+=count;
 }
 assert!(b.is_empty());let hash=digest(&all);let hex:String=hash.iter().map(|v|format!("{v:02x}")).collect();println!("tables=31;rows={total};canonicalBytes={};logicalSHA256={hex}",all.len());
 std::fs::write(std::env::args().nth(2).expect("test-only canonical output"),all).unwrap();
}
