# Closed publication bytes and evidence boundary

The private native path consumes `Binary.FcPublishedPredecessor` only from the
original pinned, whole-MSI-sealed current source. A parsed record is format data;
only native current-SID registration/cache capture and all comparisons construct
`VerifiedUpgradePlan`. No runtime path/hash/CLI record constructor exists. The old
compile-time empty host registry is separate and is not an Upgrade escape hatch.
The immutable normal carrier and guard must already support both releases before
U1 is built; U2 reuses exactly those bytes. Runtime does not compile its own hash
into the carrier. The builder binds a separately reviewed old normal producer,
full input inventory, exact old MSI, canonical template, guard and envelope. The
current 738d old null-Summary package is a **codec sample only**, not a publishable
predecessor or a successful installed-cache observation.

## Logical database SHA-256 grammar, v1

The native CNG consumer is maintenance/database.rs; its pure byte prefixes live
in maintenance/logical.rs and its exact supported schemas in maintenance/schema.rs.
No normalized case, Unicode normalization, text decimal integer conversion or
SQL returned-row ordering is used.

1. Reject missing/extra ordinary tables. The set is the exact 31 sorted table
   names in schema.rs, with exact ordinal column names and case-sensitive MSI
   column type strings (uppercase nullability is significant). Queries are fixed
   source strings; no database-supplied identifier is interpolated into SQL.
   Reject any row in the fixed `_Storages` query. Installed `Transforms` must be
   empty and native `MsiEnumPatchesExW` must report no patches. The initial Upgrade
   predecessor has exactly the three Binary names guard/template/payload, and the
   successor exactly those plus `FcPublishedPredecessor`. No fifth or unknown name.
2. For every row, concatenate its columns in schema ordinal order. A null field
   contributes byte `01` only. A non-null field starts byte `00`, followed by:
   - integer (`i`/`I`): signed i32 two's complement little endian, rejecting the
     MSI NULL integer sentinel -2147483648;
   - string (`s`/`S`/`l`/`L`): UTF-8 byte length as u32 little endian then exactly
     that many UTF-8 bytes, no terminator (native UTF-16 conversion is strict);
   - stream (`v`/`V`): complete stream byte length as u32 little endian then all
     bytes. Native code reads exactly 16 KiB chunks and verifies EOF; no filename
     or source/cache physical container hash is substituted.
3. SHA-256 each complete row encoding. Sort the resulting 32-byte digests using
   unsigned byte lexical order, retaining duplicate digest occurrences.
4. Start the outer SHA with ASCII `FC-SAME-SOURCE-DB-v1` followed by one NUL.
   For each of the 31 table names in sorted ordinal ASCII order, append:
   u32LE UTF-8 table-name byte length + name; then, for each fixed column,
   u32LE column-name length + name + u32LE exact type-string length + type;
   finally u32LE row count + all sorted 32-byte row digests. There is no table
   count or column count in this outer grammar: those come from the closed
   schema. An empty table still contributes its full schema and zero row count.
5. PackageCode is checked separately as Summary property9, VT_LPSTR/30, exact
   38-character braced canonical GUID; Product/Upgrade/version properties are
   checked independently. Summary and physical CAB/container bytes are not
   silently called equal merely because this logical digest matches.

Bounds stay native: <=72 rows per ordinary table, <=4096 UTF-16 units per string,
<=64 MiB per stream/MSI/image, <=64 combined native live controls, original
8 owner slots, 256 close receipt window with checked table-boundary checkpoints,
8192 maximum native MSI closes, original 120-second absolute deadline. Known
read errors close original handles once; unknown/failed close keeps the original
Box/claim/handles to physical exit. MSIHANDLEs use MsiViewClose/MsiCloseHandle;
no CloseHandle or retry-to-success substitution.

## FCPRED2 record, format1 / carrier ABI2

Header248 bytes, followed by exactly one complete FCPM2 envelope; no tail:

| Offset | Bytes | Content |
| --- | --- | --- |
|0|8|`FCPRED2\0`|
|8|2|u16LE format1|
|10|2|u16LE carrier ABI2|
|12|1|target1 reviewed Win7 MSVC, target2 explicitly DEV GNU|
|13|3|zero (normal non-test profile / reserved)|
|16|20|old source commit bytes|
|36|32|old full compiler input inventory SHA|
|68|32|old normal producer report SHA|
|100|32|old complete **source** MSI SHA, never a cache SHA|
|132|32|old canonical carrier template SHA|
|164|32|old guard DLL SHA|
|196|32|old logical database SHA defined above|
|228|4|u32LE canonical template bytes|
|232|4|u32LE envelope bytes|
|236|12|zero|
|248|N|exact old FCPM2 envelope including Package/Product/family/version/raw ledger|

All provenance digests and commit must be nonzero; no unknown target/profile,
reserved byte, truncation or extra tail. Template bytes196..64MiB; envelope maximum
88+32768. Python `encode_format` only creates these bytes. Rust parser negative
cases remain the authority for accepting this format, not for issuing permission.
The builder must confirm actual old normal provenance rather than accepting an
arbitrary JSON record merely because this encoder can represent it.

## Actual local evidence

`capture-second.json`: libmsi opens actual 738d source READONLY, extracts typed
null/integer/string/stream values, validates exact31 schemas. `rust-interop-third.json`:
actual Rust logical.rs/schema.rs encodes the captured typed rows; Python and Rust
outer preimages are byte-identical8398 bytes, SHA438d29ad1d6b09c86deb7e2c76a355ca4a04f51986a046ca3e1c0c22bc75a166.
Linux sha256sum hashes the Rust emitted row bytes; this does not stand in for
Windows CNG execution. Native cached MSI equality, real dual tickets, Upgrade,
rollback and immutable final U1/U2 normal artifacts remain NOT_RUN here.
Raw capture includes embedded binary bytes and stays outside repository/archive;
only source identities and text reports are candidates for later evidence.

Primary API sources: Microsoft `_Storages` table
https://learn.microsoft.com/en-us/windows/win32/msi/-storages-table ; GNOME libmsi
headers https://raw.githubusercontent.com/GNOME/msitools/master/include/libmsi-database.h ,
https://raw.githubusercontent.com/GNOME/msitools/master/include/libmsi-query.h ,
https://raw.githubusercontent.com/GNOME/msitools/master/include/libmsi-record.h ,
https://raw.githubusercontent.com/GNOME/msitools/master/include/libmsi-types.h .
