from pathlib import Path
import runpy,json,hashlib,time,traceback
D=Path(__file__).resolve().parent;R=D.parent.parent;W=R/'checkout-abi2-upgrade-first';M=runpy.run_path(str(D/'capture-fixed-msi.py'))
P=R/'abi2-maintenance-dev-product-package-first';report=json.loads((P/'report.json').read_bytes());schemaPath=W/'crates/fc-windows/src/installer_lifecycle/native/broker/maintenance/schema.rs'
start=time.monotonic();out={'status':'FAIL_LOCAL_ONLY','Windows':'NOT_RUN','permission':'NONE_CAPTURED_SOURCE_NOT_CACHE_NOT_UPGRADE_AUTHORITY','sourceMsi':report['msi'],'schemaRustSha256':hashlib.sha256(schemaPath.read_bytes()).hexdigest()}
try:
 schema=M['schema_from_rust'](schemaPath.read_text());tables=M['capture'](P/report['msi']['path'],report['msi']['sha256'],schema)
 sig,facts,canonical=M['signature'](tables);wire=M['capture_wire'](tables)
 (D/'actual-source-capture.bin').write_bytes(wire);(D/'actual-source-canonical.bin').write_bytes(canonical)
 out.update(status='PASS_LIBMSI_READONLY_SOURCE_CANONICAL_CAPTURE_ONLY',logicalSha256=sig,tables=facts,wire={'bytes':len(wire),'sha256':hashlib.sha256(wire).hexdigest()},canonical={'bytes':len(canonical),'sha256':hashlib.sha256(canonical).hexdigest()})
except Exception as e:out.update(errorType=type(e).__name__,traceback=traceback.format_exc())
out['seconds']=time.monotonic()-start;(D/'capture-third.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['tables']}));raise SystemExit(0 if out['status'].startswith('PASS') else 1)
