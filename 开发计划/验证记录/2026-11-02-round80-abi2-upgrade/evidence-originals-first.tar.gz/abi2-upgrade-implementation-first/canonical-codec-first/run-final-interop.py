from pathlib import Path
import subprocess,time,json,hashlib,runpy,copy,sys
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=D.parent.parent;W=R/'checkout-abi2-upgrade-first';B=W/'crates/fc-windows/src/installer_lifecycle/native/broker/maintenance'
def fact(p):b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
sources=[D/'rust-interop.rs',B/'schema.rs',B/'logical.rs',D/'capture-fixed-msi.py',D/'predecessor-codec.py'];before=[fact(p)for p in sources];out={'status':'FAIL_LOCAL_ONLY','Windows':'NOT_RUN','checks':[],'sourceBefore':before}
for name,cmd in [('rust-compile-final',['rustc','--edition','2021','-D','warnings',str(D/'rust-interop.rs'),'-o',str(D/'rust-interop')]),('rust-actual-interop-final',[str(D/'rust-interop'),str(D/'actual-source-capture.bin'),str(D/'rust-canonical.bin')]),('rust-pure-compile-final',['rustc','--edition','2021','--test',str(D/'rust-interop.rs'),'-o',str(D/'rust-pure-tests')]),('rust-pure-run-final',[str(D/'rust-pure-tests')])]:
 t=time.monotonic();p=subprocess.run(cmd,capture_output=True,timeout=90);(D/(name+'.stdout.log')).write_bytes(p.stdout);(D/(name+'.stderr.log')).write_bytes(p.stderr);out['checks'].append(dict(name=name,argv=cmd,actualExit=p.returncode,originalParentReaped=True,seconds=time.monotonic()-t,stdoutSha256=hashlib.sha256(p.stdout).hexdigest(),stderrSha256=hashlib.sha256(p.stderr).hexdigest()))
 if p.returncode:break
else:
 b=(D/'rust-canonical.bin').read_bytes();assert b==(D/'actual-source-canonical.bin').read_bytes();out.update(status='PASS_RUST_PYTHON_ACTUAL_SOURCE_CANONICAL_BYTE_INTEROP_ONLY',bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),nativeCngAndCache='NOT_RUN')
out['sourceAfter']=[fact(p)for p in sources];out['sourceUnchanged']=out['sourceAfter']==before
codec=runpy.run_path(str(D/'predecessor-codec.py'));carrier=runpy.run_path(str(R/'checkout-abi2-maintenance-dev-package-first/scripts/installer-carrier-format.py'));record=json.loads((D/'predecessor-format-first.json').read_bytes());meta=record['meta'];envelope=(D/'predecessor-format-fixture.bin').read_bytes()[248:];assert codec['encode_format'](meta,envelope,carrier['parse_payload_manifest'])==(D/'predecessor-format-fixture.bin').read_bytes()
reject=[]
for key,value in [('target',0),('target',3),('target',True),('source_commit','0'*40),('template_bytes',195),('template_bytes',64*1024*1024+1)]+[(k,'0'*64)for k in codec['DIGEST_KEYS']]:
 m=copy.deepcopy(meta);m[key]=value
 try:codec['encode_format'](m,envelope,carrier['parse_payload_manifest'])
 except (AssertionError,ValueError):reject.append(key)
 else:raise AssertionError('ENCODER_NEGATIVE_NOT_REJECTED')
for bad in [b'',envelope[:-1],envelope+b'\0']:
 try:codec['encode_format'](meta,bad,carrier['parse_payload_manifest'])
 except (AssertionError,ValueError):reject.append('envelope')
 else:raise AssertionError('ENVELOPE_NEGATIVE_NOT_REJECTED')
out['predecessorEncoder']={'actualOldSamplePositive':1,'negative':len(reject),'actualUpgradeAuthority':'NOT_GRANTED'}
out['artifactIdentities']=[fact(p)for p in [D/'rust-interop',D/'rust-pure-tests',D/'actual-source-capture.bin',D/'actual-source-canonical.bin',D/'rust-canonical.bin',D/'predecessor-format-fixture.bin']]
out['localLibraryIdentities']=[fact(p.resolve())for p in [R/'inner-guard-probe-tools-first/root/usr/lib/x86_64-linux-gnu/libmsi-1.0.so.0',R/'inner-guard-probe-tools-first/root/usr/lib/x86_64-linux-gnu/libgsf-1.so.114']]
(D/'rust-interop-final.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['sourceBefore','sourceAfter','artifactIdentities','localLibraryIdentities']}))
