# Pure observation-config validation shared with root's PS51 binding negatives.
# No API call, compilation, file access, mutation or installation permission.
function Assert-FcFixedProductConfig {
    param($Config)
    if($null-eq$Config){throw 'CONFIG_REQUIRED'}
    if($Config.status-cne'BOUND_GNU_ABI2_UPGRADE_CHAIN_INPUTS_NOT_RELEASE' -or $Config.sourceGit-cne'6eb6ec099b6b14e78b280df5df526545c8e04ecc' -or $Config.target-cne'i686-pc-windows-gnu' -or $Config.family-cne'99378807-098D-5F04-8D4D-F181DFA218D5'){throw 'EXACT_BOUND_CONFIG_SOURCE'}
    if($Config.registryMarkerKey-cne'Software\FutureClassroom\Installer\Components' -or $Config.runKey-cne'Software\Microsoft\Windows\CurrentVersion\Run' -or $Config.runValue-cne'FutureClassroom' -or $Config.registryView-cne'Registry32' -or @($Config.fixedDestinationKnownFolderSuffix).Count-ne2 -or $Config.fixedDestinationKnownFolderSuffix[0]-cne'Programs' -or $Config.fixedDestinationKnownFolderSuffix[1]-cne'FutureClassroom'){throw 'FIXED_OBSERVATION_CONSTANTS_REQUIRED'}
    if(-not(($Config.productCode-ceq'{D420EDE5-0584-5FDC-8DE8-F25905018A0A}' -and $Config.version-ceq'0.2.0') -or ($Config.productCode-ceq'{9E239183-E743-5E6A-8ACE-EB4B8F7511F6}' -and $Config.version-ceq'0.3.0'))){throw 'FIXED_PRODUCT_VERSION_PAIR'}
}
# Dot-source only defines this function. All product observation is explicit.
function Measure-FcProductState {
    [CmdletBinding()]
    param($Config,[string]$Expected,[Parameter(Mandatory=$true)][string]$SourceRoot)
    try {
        Assert-FcFixedProductConfig -Config $Config
        if ($Expected -cne 'Present' -and $Expected -cne 'Absent') { throw 'EXPECTED_PRESENT_OR_ABSENT_LABEL' }
        if ($null -eq $Config) { throw 'CONFIG_REQUIRED' }
        if ($Config.status -cne 'BOUND_GNU_ABI2_UPGRADE_CHAIN_INPUTS_NOT_RELEASE' -or
            $Config.sourceGit -cne '6eb6ec099b6b14e78b280df5df526545c8e04ecc' -or
            $Config.target -cne 'i686-pc-windows-gnu' -or
            $Config.family -cne '99378807-098D-5F04-8D4D-F181DFA218D5' -or
            $Config.registryMarkerKey -cne 'Software\FutureClassroom\Installer\Components' -or
            $Config.runKey -cne 'Software\Microsoft\Windows\CurrentVersion\Run' -or
            $Config.runValue -cne 'FutureClassroom' -or $Config.registryView -cne 'Registry32' -or
            @($Config.fixedDestinationKnownFolderSuffix).Count -ne 2 -or
            $Config.fixedDestinationKnownFolderSuffix[0] -cne 'Programs' -or
            $Config.fixedDestinationKnownFolderSuffix[1] -cne 'FutureClassroom') { throw 'EXACT_BOUND_CONFIG_SCOPE' }
        if(-not(($Config.productCode-ceq'{D420EDE5-0584-5FDC-8DE8-F25905018A0A}' -and $Config.version-ceq'0.2.0') -or ($Config.productCode-ceq'{9E239183-E743-5E6A-8ACE-EB4B8F7511F6}' -and $Config.version-ceq'0.3.0'))){throw 'EXACT_U1_PRODUCT_VERSION'}
        foreach ($name in @('productCode','family','version','expectedUserSid','sourceGit')) {
            if ($Config.$name -isnot [string]) { throw 'CONFIG_STRING_TYPES_REQUIRED' }
        }
        $rows=@($Config.payloads)
        if ($rows.Count -ne 14) { throw 'PAYLOAD_ROW_BOUND' }
        $paths=[Collections.Generic.List[string]]::new()
        $sizes=[Collections.Generic.List[long]]::new()
        $hashes=[Collections.Generic.List[string]]::new()
        $components=[Collections.Generic.List[string]]::new()
        foreach ($row in $rows) {
            if ($row.path -isnot [string] -or $row.sha256 -isnot [string] -or $row.component_guid -isnot [string] -or
                ($row.size -isnot [Int32] -and $row.size -isnot [Int64])) { throw 'TYPED_PAYLOAD_ROW_REQUIRED' }
            $paths.Add($row.path);$sizes.Add([long]$row.size);$hashes.Add($row.sha256);$components.Add($row.component_guid)
        }
        if ($null -eq ('Fc80ProductState' -as [type])) {
            $source=Get-Content -LiteralPath (Join-Path $SourceRoot 'ProductState.cs') -Raw -Encoding UTF8
            Add-Type -TypeDefinition $source -Language CSharp -ErrorAction Stop
        }
        return ,([Fc80ProductState]::Measure($Config.sourceGit,$Config.productCode,$Config.family,$Config.version,
            $Config.expectedUserSid,$paths.ToArray(),$sizes.ToArray(),$hashes.ToArray(),$components.ToArray(),$Expected))
    } catch {
        $e=$_.Exception;while ($null -ne $e.InnerException) { $e=$e.InnerException }
        return @{status='FAIL_CONFIG_OR_INSTRUMENTATION';expected=$Expected;stateClassification='UNKNOWN_OR_MISMATCH';
            healthyPresent=$false;knownAbsent=$false;matchesExpected=$false;mutations=$false;
            coordinationGate='NOT_MEASURED_BY_THIS_MODULE';observations=@{};
            phaseErrors=@(@{phase='configOrCompile';exceptionType=$e.GetType().FullName;hresult=$e.HResult;
                win32Error=$(if($e -is [ComponentModel.Win32Exception]){$e.NativeErrorCode}else{$null});
                code='CONFIG_OR_INSTRUMENTATION_FAILURE_NO_ABSENCE_INFERENCE'});
            scope='No Windows compilation/runtime PASS inferred; caller preserves this typed failure.'}
    }
}
