"""Read-only qualification for the final normal ABI2 DEV package.

This is test preparation. It never compiles, installs or authorizes an MSI.
The transport separately requires explicit final manifest hashes and a freeze.
"""
from pathlib import Path
import hashlib
import json
import re
import runpy

R = Path('/tmp/fc-round80-controlled-repair')
VALIDATOR = Path('/tmp/fc-round80-controlled-repair/checkout-abi2-upgrade-normal-first/scripts/package-abi2-upgrade-dev.py')
VALIDATOR_SHA = '14502c75cae59e33ae19d74d3a40901756878d378d6e5fd4de0fe926df717c79'
PACKAGE = Path('/tmp/fc-round80-controlled-repair/abi2-upgrade-u1-dev-product-package-first')
EVIDENCE = Path('/tmp/fc-round80-controlled-repair/abi2-upgrade-u1-normal-producer-first/evidence.json')


def need(value, message):
    if not value:
        raise AssertionError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def fact(path):
    path = Path(path)
    need(path.is_absolute() and path.resolve() == path and path.is_relative_to(R)
         and path.is_file() and not path.is_symlink(), 'Exact owned input file')
    raw = path.read_bytes()
    need(len(raw) <= 96 * 1024 * 1024, 'Bounded input')
    return dict(path=str(path), bytes=len(raw), sha256=sha(raw))


def verify(c, source):
    need(c['guardABI'] == 2 and c['normalProfileTest'] is False
         and c['formalCI'] is False
         and c['lifecycleMode'] == 'ABI2_UPGRADE_CAPABLE_NORMAL_GNU_DEV',
         'Only normal GNU ABI2 same-package maintenance DEV')
    need(c['expectedUserSid'] == 'S-1-5-21-3896111207-1867804362-1971593122-1001',
         'Only authorized deployment SID')
    need(fact(VALIDATOR)['sha256'] == VALIDATOR_SHA
         and c['normalValidator'] == fact(VALIDATOR), 'Pinned normal validator')
    need(c['normalEvidence'] == fact(EVIDENCE)
         and c['sourceEvidenceSha256'] == fact(EVIDENCE)['sha256'],
         'Exact final maintenance build evidence')
    evidence = json.loads(EVIDENCE.read_bytes())
    need(evidence['lifecycle_mode'] == c['lifecycleMode'],
         'Actual producer explicitly binds maintenance source')
    source_root = Path(c['sourceRoot'])
    normal = runpy.run_path(str(VALIDATOR))['admit_normal_inputs'](
        source_root, EVIDENCE, c['sourceEvidenceSha256'])
    need(normal['status'] == 'PASS_NORMAL_GNU_ABI2_DEV_SOURCE_AND_THREE_ARTIFACTS_ONLY'
         and normal['target'] == c['target'] == 'i686-pc-windows-gnu'
         and normal['baseGit'] == c['sourceGit'] == source['sourceBase'],
         'Actual normal source base; overlay proven by full inventory')
    need(c['packageBuilder'] == fact(VALIDATOR)
         and c['commonPackageBuilder'] == fact(source_root / 'scripts/package-abi2-controlled-dev.py')
         and normal['builder']['sha256'] == c['commonPackageBuilder']['sha256'],
         'Exact source builder')
    final_admission = runpy.run_path(str(VALIDATOR))[
        'admit_normal_inputs'](source_root, EVIDENCE, c['sourceEvidenceSha256'])
    need(final_admission['status'] == normal['status']
         and final_admission['normalArtifacts'] == normal['normalArtifacts'],
         'Final builder independently closes same three normal artifacts')
    maintenance = final_admission['upgradeSourceBinding']
    receipt_path = EVIDENCE.parent / evidence['upgrade_source']['path']
    need(receipt_path.resolve().parent == EVIDENCE.parent
         and receipt_path.name == 'upgrade-source.json'
         and fact(receipt_path)['bytes'] == evidence['upgrade_source']['bytes']
         and fact(receipt_path)['sha256'] == evidence['upgrade_source']['sha256'],
         'Actual maintenance source receipt bytes')
    receipt = json.loads(receipt_path.read_bytes())
    need(receipt['status'] == 'FROZEN_UPGRADE_SOURCE_OVERLAY_BOUND'
         and receipt['sourceRoot'] == str(source_root)
         and receipt['lifecycleMode'] == c['lifecycleMode']
         and maintenance['lifecycleMode'] == c['lifecycleMode']
         and maintenance['originalFreeze'] == receipt['originalFreeze']
         and maintenance['sourceCount'] == len(receipt['sources']) == 18
         and maintenance['retainedBaseSourceCount'] == len(receipt['retainedBaseSources']) == 8,
         'Maintenance provenance is source-bound, not only a report label')
    need(receipt['originalFreeze'] == fact(receipt['originalFreeze']['path']),
         'Exact original frozen maintenance implementation')
    before = EVIDENCE.parent / evidence['inputs_before']['path']
    after = EVIDENCE.parent / evidence['inputs_after']['path']
    need(sha(before.read_bytes()) == evidence['inputs_before']['sha256']
         and before.read_bytes() == after.read_bytes()
         and source['sources'] == json.loads(before.read_bytes()),
         'Exact complete source overlay before and after actual builds')
    report = PACKAGE / 'report.json'
    need(c['packageReport'] == fact(report), 'Pinned final package report')
    package = json.loads(report.read_bytes())
    need(package['status'] == 'PASS_NORMAL_GNU_ABI2_UPGRADE_CAPABLE_DEV_STATIC_BUNDLE_NATIVE_NOT_RUN'
         and package['scope'] == 'NORMAL_GNU_ABI2_UPGRADE_CAPABLE_STATIC_BUNDLE_ONLY_NOT_FORMAL_MSVC'
         and package['formalCI'] is False and package['normalProfileTest'] is False
         and package['installation'] == 'NOT_RUN'
         and package['lifecycleMode'] == c['lifecycleMode']
         and package['sourceRoot'] == str(source_root)
         and package['sourceBase'] == c['sourceGit']
         and package['sourceEvidenceSha256'] == c['sourceEvidenceSha256'],
         'Actual final static bundle with maintenance source')
    need(c['sourceGit'] == '6eb6ec099b6b14e78b280df5df526545c8e04ecc' and len(source['sources']) == 595
         and c['version'] == '0.2.0' and c['productCode'] == '{D420EDE5-0584-5FDC-8DE8-F25905018A0A}'
         and c['packageCode'] == '5F6CF7E9-71B0-4197-BDD7-66B12F088E95', 'Exact U1 batch')
    need(c['productCode'] == '{' + package['productCode'] + '}',
         'Canonical braced native ProductCode matches unbraced envelope identity')
    for key in ('packageCode', 'version', 'payloads'):
        need(package[key] == c[key], 'Exact package identity and all payloads: ' + key)
    need(re.fullmatch(r'[0-9A-F]{8}(?:-[0-9A-F]{4}){3}-[0-9A-F]{12}', c['packageCode'])
         and c['packageCode'] != '00000000-0000-0000-0000-000000000000',
         'Actual nonzero Summary PackageCode')
    for key, leaf in (('setup', 'Setup.exe'), ('msi', 'FutureClassroom.msi')):
        need(fact(PACKAGE / leaf) == c[key]
             and package[key]['bytes'] == c[key]['bytes']
             and package[key]['sha256'] == c[key]['sha256'], 'Exact final ' + key)
    need(package['binaryReadback'] == 'ALL_THREE_EXACT'
         and package['payloadReadback'] == 'ALL_FOURTEEN_EXACT'
         and package['onlyExternal32HoleFilled'] is True
         and package['msiContract']['guardABI'] == 2
         and package['msiContract']['packageCode'] == c['packageCode'],
         'Complete static MSI readbacks and ABI2 contract')
    need(package['msiContract']['transaction_sequence'] == {'CostFinalize':1000,'InstallValidate':1400,'FcControlledInnerGuard':1499,'InstallInitialize':1500,'RemoveExistingProducts':1501,'InstallExecute':6500,'InstallFinalize':6600}
         and package['msiContract']['binaryStreams'] == ['FcControlledGuardDll','FcGuardClientTemplate','FcPayloadManifest'], 'Exact U1 Upgrade-capable sequence and three Binary schema; no predecessor record')
    codec = runpy.run_path(str(source_root / 'scripts/installer-carrier-format.py'))
    helper = Path(normal['normalArtifacts']['lifecycle-compile']['path'])
    template = codec['make_carrier_template'](helper.read_bytes())
    need(package['template']['bytes'] == len(template)
         and package['template']['sha256'] == sha(template)
         and package['template']['hole'] == helper.stat().st_size + 16
         and package['template']['canonicalZero32'] is True
         and package['template']['normalPrefixExact'] is True,
         'Template rebuilt from actual unchanged normal helper')
    codec['verify_carrier_binding'](template, (PACKAGE / 'Setup.exe').read_bytes(),
                                    (PACKAGE / 'FutureClassroom.msi').read_bytes())
    need(set(normal['normalArtifacts']) == {'product-compile', 'lifecycle-compile',
                                           'guard-library-compile'}, 'Three normal artifacts')
    return normal
