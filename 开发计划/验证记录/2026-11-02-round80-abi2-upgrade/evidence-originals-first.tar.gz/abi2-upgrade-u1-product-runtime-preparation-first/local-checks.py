#!/usr/bin/env python3
"""Local qualification only: no Windows process, SSH, install, publication or Cargo."""
from pathlib import Path
import runpy,json,hashlib,copy,subprocess,sys,time
P=Path(__file__).resolve().parent;R=P.parent

def fact(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def main():
 started=time.monotonic();g=runpy.run_path(str(P/'run-controlled-product.py'));v=runpy.run_path(str(P/'verify-normal-package.py'));a=P/'inputs/artifact-manifest.json';s=P/'inputs/source-manifest.json';c,af,sf=g['bind'](a,fact(a)['sha256'],s,fact(s)['sha256']);source=json.loads(s.read_bytes());rejected=[]
 changes=[('wrong_product',lambda c:c.update(productCode='{9E50831D-7811-5039-8BC3-4934647448D8}')),('bare_product',lambda c:c.update(productCode=c['productCode'][1:-1])),('wrong_version',lambda c:c.update(version='0.1.0')),('wrong_base',lambda c:c.update(sourceGit='d9dacefb481678a2f1c12cf8371fa6567820547d')),('wrong_profile',lambda c:c.update(normalProfileTest=True)),('formal_claim',lambda c:c.update(formalCI=True)),('legacy_mode',lambda c:c.update(lifecycleMode='ABI2_SAME_PACKAGE_MAINTENANCE_NORMAL_GNU_DEV')),('wrong_guard',lambda c:c.update(guardABI=1)),('wrong_evidence',lambda c:c.update(sourceEvidenceSha256='1'*64)),('wrong_package',lambda c:c.update(packageCode='5D9FD88F-DD1B-4CD3-97D3-A75C4420C246')),('wrong_template_source',lambda c:c['setup'].update(sha256='1'*64)),('wrong_ledger',lambda c:c['payloads'][0].update(sha256='1'*64)),('wrong_builder',lambda c:c['packageBuilder'].update(sha256='1'*64)),('wrong_sid',lambda c:c.update(expectedUserSid='S-1-5-21-1-2-3-1001'))]
 for name,change in changes:
  bad=copy.deepcopy(c);change(bad)
  try:v['verify'](bad,source)
  except (AssertionError,KeyError,ValueError):rejected.append(name)
  else:raise AssertionError('DID_NOT_REJECT_'+name)
 # Actual historical phase shape is only a parser replay; it is not U1 execution.
 history=R/'abi2-summary-output-product-runtime-first/report.json';j=json.loads(history.read_bytes())['phase'];assert g['admission'](j);phase_rejected=[]
 changes=[('missing_phase',lambda j:j['phases'].pop()),('wrong_verb',lambda j:j['phases'][1].update(verb='install')),('owner_unknown',lambda j:j.update(ownerUnknown=True)),('pending_present',lambda j:j['finallyCoordination'].update(pendingKnownAbsent=False)),('namespace_present',lambda j:j['finallyCoordination'].update(namespaceKnownAbsent=False)),('cache_left',lambda j:j['uninstalledCache'].update(allObservedAbsent=False)),('damaged_not_repaired',lambda j:j['repaired'].update(healthyPresent=False)),('unknown_close',lambda j:j['phases'][0]['directOriginalFinal'][0].update(CheckedClose=False)),('nonzero_B',lambda j:j['phases'][0]['client'].update(exitCode=1603)),('nonzero_G',lambda j:j['phases'][0]['observerFinal']['Processes'][0].update(ActualExitCode=1603)),('late_parent',lambda j:j['phases'][0]['client'].update(actualExit=False)),('missing_guardian',lambda j:j['phases'][0]['observerFinal'].update(Processes=[])),('budget',lambda j:j.update(originalBudgetExceeded=True))]
 for name,change in changes:
  bad=copy.deepcopy(j);change(bad);assert not g['admission'](bad),name;phase_rejected.append(name)
 ps=(P/'sources/ProductState.ps1').read_text();cs=(P/'sources/ProductState.cs').read_text();native=(P/'sources/Invoke-ControlledProduct.ps1').read_text();pre=(P/'sources/ReadOnlyPreflightFunction.ps1').read_text();runner=(P/'run-controlled-product.py').read_text()
 for text in (ps,cs,native,pre):assert c['productCode'] in text and '0.2.0' in text and c['sourceGit'] in text
 assert '$PSScriptRoot' not in ps and '-SourceRoot $ScratchRoot' in native and 'EXACT_REVIEWED_MEMORY_RUNNER' in runner
 assert ". (Join-Path $ScratchRoot" not in native and "& (Join-Path $c.root 'Invoke-ControlledProduct.ps1')" not in runner
 assert 'eachClientMaximumMilliseconds=150000' in native and 'setupInternalSeconds=120' in native and 'wholeMilliseconds=600000' in native
 result=subprocess.run([sys.executable,str(P/'run-controlled-product.py')],capture_output=True,timeout=10);assert result.returncode==0 and json.loads(result.stdout)['Windows']=='NOT_RUN'
 return dict(status='PASS_LOCAL_REAL_U1_NORMAL3_STATIC_BIND_AND_REJECTION_CHECKS_WINDOWS_NOT_RUN',artifact=af,source=sf,sourceCount=len(source['sources']),actualConfigurationRejections=rejected,historicalPhaseParserRejections=phase_rejected,historicalParserReplayOnly=fact(history),historicalIsU1Evidence=False,exactNativeInstrumentConstants=True,verifiedBytesMemoryScriptLoading=True,defaultExit=result.returncode,defaultStdout=result.stdout.decode(),budgetSeconds=dict(client=150,internal=120,whole=600),elapsedSeconds=time.monotonic()-started)
if __name__=='__main__':print(json.dumps(main(),ensure_ascii=False,indent=2))
