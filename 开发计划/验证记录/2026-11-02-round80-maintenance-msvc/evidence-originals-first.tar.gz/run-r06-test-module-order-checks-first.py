from pathlib import Path
import os,subprocess,time,json,hashlib,runpy
R=Path('/tmp/fc-round80-controlled-repair');W=R/'checkout-r06-test-module-order-first';D=R/'r06-test-module-order-first';report=dict(status='RUNNING',operations=[])
def inv():return runpy.run_path(str(W/'scripts/package-controlled-dev.py'))['source_inventory'](W)
report['sourceBefore']=inv();env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(R/'carrier-abi2-target-first'),CARGO_BUILD_JOBS='2',PYTHONDONTWRITEBYTECODE='1')
commands=[('presentation-tests',['cargo','test','--locked','--offline','-p','fc-presentation','--lib']),('presentation-all-clippy',['cargo','clippy','--locked','--offline','-p','fc-presentation','--all-targets','--','-D','warnings']),('workspace-gnu-all-clippy',['cargo','clippy','--locked','--offline','--workspace','--all-targets','--target','i686-pc-windows-gnu','--','-D','warnings']),('format',['cargo','fmt','--all','--','--check']),('architecture',['python3','scripts/check-architecture.py']),('diff',['git','diff','--check'])]
for name,argv in commands:
 t=time.monotonic()
 with (D/(name+'.stdout.log')).open('xb')as so,(D/(name+'.stderr.log')).open('xb')as se:
  child=subprocess.Popen(argv,cwd=W,env=env,stdout=so,stderr=se);code=child.wait(timeout=900)
 report['operations'].append(dict(name=name,argv=argv,actualExit=code,originalReaped=child.poll()is not None,seconds=time.monotonic()-t))
 (D/'checks-first.json').write_text(json.dumps(report,indent=2)+'\n');print(name,code,flush=True)
 if code:break
report['sourceAfter']=inv();report['sourceUnchanged']=report['sourceBefore']==report['sourceAfter'];report['status']='PASS'if len(report['operations'])==len(commands)and all(x['actualExit']==0 for x in report['operations'])and report['sourceUnchanged']else'FAIL_RETAIN_ORIGINALS';(D/'checks-first.json').write_text(json.dumps(report,indent=2)+'\n');print(report['status'],flush=True);raise SystemExit(0 if report['status']=='PASS'else 1)
