from pathlib import Path
import subprocess,json,time,hashlib
R=Path('/tmp/fc-round80-controlled-repair');W=R/'checkout-inner-guard-abi2-first';O=R/'inner-guard-abi2-implementation-first';B=W/'crates/fc-windows/src/installer_lifecycle/broker'
wrapper=O/'pure-second.rs';exe=O/'pure-second'
s='mod installer_lifecycle {\n#[derive(Debug,PartialEq,Eq)]pub enum LifecycleError {Invalid}\npub type Result<T> = std::result::Result<T,LifecycleError>;\npub const INSTALL_FAMILY:&str="99378807-098D-5F04-8D4D-F181DFA218D5";\npub mod broker {\n'
for name in ['manifest','carrier','payload_manifest','published_host']:s+='#[path='+json.dumps(str(B/(name+'.rs')))+']pub mod '+name+';\n'
g=(W/'crates/fc-windows/src/installer_lifecycle/guard_contract.rs').read_text();g='\n'.join(l for l in g.splitlines() if not l.startswith('//!'));g=g.replace('pub(crate) mod v2;','#[path='+json.dumps(str(W/'crates/fc-windows/src/installer_lifecycle/guard_contract/v2.rs'))+']pub(crate) mod v2;');s+='}\nmod guard_contract {'+g+'}\nmod native {mod inner_guard {#[path='+json.dumps(str(W/'crates/fc-windows/src/installer_lifecycle/native/inner_guard/carrier_image.rs'))+']mod carrier_image;}}}\n';wrapper.write_text(s);r=[]
try:
 for name,cmd in [('pure-compile-second',['rustc','--edition=2021','--test',str(wrapper),'-o',str(exe)]),('pure-tests-second',[str(exe),'--nocapture'])]:
  start=time.monotonic();p=subprocess.run(cmd,capture_output=True,timeout=60);(O/(name+'.stdout.log')).write_bytes(p.stdout);(O/(name+'.stderr.log')).write_bytes(p.stderr);r.append(dict(name=name,argv=cmd,actualExit=p.returncode,parentReaped=True,seconds=time.monotonic()-start));
  if p.returncode:break
finally:
 (O/'pure-checks-second.json').write_text(json.dumps(r,indent=2)+'\n');wrapper.unlink(missing_ok=True);exe.unlink(missing_ok=True)
print(json.dumps(r))
