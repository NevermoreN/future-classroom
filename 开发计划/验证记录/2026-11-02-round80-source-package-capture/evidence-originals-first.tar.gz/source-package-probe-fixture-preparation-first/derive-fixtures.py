#!/usr/bin/env python3
"""Default inert. DEV readonly source-reader test inputs, never an installable normal bundle."""
from pathlib import Path
import argparse,hashlib,json,os,re,runpy,shutil,struct,subprocess,time
R=Path('/tmp/fc-round80-controlled-repair');P=R/'source-package-probe-fixture-preparation-first';C=R/'a470-msvc-product-package-first';V=P/'vendor/scripts'
TOOLS=R/'inner-guard-probe-tools-first/tools.json';CHILD_ENV=R/'inner-guard-probe-tools-first/child-environment.json'
TOOLS_SHA='d82866321cc565890c38b494f7dd2ae6afa2fed8d4ae55270d7c4e931562099d';ENV_SHA='d0b2d946aba5c21d94713c6e17cfa90a5c85c74dfa00d2336d4cbf88f05b37a0'
REPORT_SHA='f6b5265bf94dd0b88cd493a6a731a82cfe297cd991e7505d5ca5b811099eb6e5';MSI_SHA='bfa908c58450016ad219e372a0c47dd13d9d71a68270e9cdbf2b9c6fc3b52fdc'
PACKAGE='C1223EE2-A1BD-4B75-BD1D-9B25B1A372B5';PRODUCT='9E50831D-7811-5039-8BC3-4934647448D8';VERSION='0.1.0'
PE_SHA='b7bc5c77a8434058453f3f64e742c0e3d4eb6d32eba0ad9898d558cbb1127bd5';PE_BYTES=3678208
MODULE='installer_lifecycle::native::broker::source_package::native_probe::'
TESTS={'positive':MODULE+'actual_fixed_source_capture_closes_all_msi_before_begin','bad-seal':MODULE+'sibling_msi_seal_mismatch_rejects_before_begin','bad-template':MODULE+'sibling_template_outside_digest_hole_rejects_before_begin'}
MAX=64*1024*1024

def need(v,m):
 if not v:raise AssertionError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def raw(x):return (json.dumps(x,indent=2)+'\n').encode()
def read(p,maximum=MAX):
 p=Path(p);need(p.is_absolute()and p.is_relative_to(R)and p.resolve()==p,'EXACT_R_REGULAR')
 for q in(p,*p.parents):
  if q==R or q.is_relative_to(R):need(not q.is_symlink(),'NO_SYMLINK')
 need(p.is_file()and 0<=p.stat().st_size<=maximum,'BOUNDED_REGULAR');b=p.read_bytes();need(len(b)==p.stat().st_size,'STABLE_SIZE');return b
def fact(p):b=read(p);return dict(path=str(p),bytes=len(b),sha256=sha(b))
def vendor():
 m=json.loads(read(P/'materials-first.json'))
 for r in m['sourceFiles']:
  b=read(P/r['path']);need(len(b)==r['bytes']and sha(b)==r['sha256'],'EXACT_UNMODIFIED_SOURCE_CODECS')
 return runpy.run_path(str(V/'package-msi-candidate.py')),runpy.run_path(str(V/'installer-carrier-format.py'))
def patch_test_pe(b):
 need(len(b)==PE_BYTES and sha(b)==PE_SHA,'EXACT_FINAL_GNU_CFGTEST_PE')
 pe=struct.unpack_from('<I',b,60)[0];optional=pe+24;need(b[:2]==b'MZ'and b[pe:pe+4]==b'PE\0\0'and struct.unpack_from('<H',b,pe+4)[0]==0x14c and struct.unpack_from('<H',b,optional)[0]==0x10b,'GNU_PE32_I386')
 need(struct.unpack_from('<II',b,pe+12)==(0,0),'COMPILER_STRIPPED_SYMBOLS_NO_STATIC_TAIL_TRIMMING')
 need(struct.unpack_from('<H',b,optional+68)[0]==3 and struct.unpack_from('<HH',b,optional+48)==(4,0),'ONLY_DECLARED_CONSOLE4_0_TO_GUI6_1_TEST_HEADER_PATCH')
 out=bytearray(b);struct.pack_into('<H',out,optional+68,2);struct.pack_into('<HH',out,optional+48,6,1)
 allowed=set(range(optional+48,optional+52))|set(range(optional+68,optional+70));changed=[i for i,(a,z)in enumerate(zip(b,out))if a!=z];need(changed and set(changed)<=allowed,'ONLY_TWO_HEADER_FIELDS_NO_PE_CODE_TRIM_OR_REWRITE')
 return bytes(out),dict(optionalHeader=optional,changedByteOffsets=changed,allowedByteOffsets=sorted(allowed),sourceSubsystem=3,targetSubsystem=2,sourceVersion=[4,0],targetVersion=[6,1],sourceSha256=sha(b),patchedSha256=sha(bytes(out)),normalHelperOrOfficialArtifact=False)

def qualify_producer(expected_sha):
    base=R/'source-package-probe-implementation-first';report_path=base/'producer-report-third.json';freeze_path=base/'freeze-first.json'
    need(expected_sha=='87d77fcc01804087f6ce074e348f21a170ad655de17a0b29c539cfd0884f5c07'and fact(report_path)['sha256']==expected_sha,'EXACT_CO_FINAL_THIRD_PRODUCER')
    need(fact(freeze_path)['sha256']=='1adf6729449e50e05451a5229d10249e20da0e497ec35858ca7c9d4e169d6355','CO_FINAL_SOURCE_FREEZE')
    frozen=json.loads(read(freeze_path))
    for row in frozen['files']:
        source=Path(row['path']);need(source.is_relative_to(base)and fact(source)==row,'ALL_FROZEN_CO_REPORT_SOURCE_AND_LOG_BYTES')
    report=json.loads(read(report_path));need(report['status']=='PASS_FROZEN_GNU_CFGTEST_COMPILER_ONLY'and report['sourceBase']=='a4702b56bff66da5f5cbe74551d8751eb33fa520'and report['target']=='i686-pc-windows-gnu','TEST_ONLY_GNU_COMPILER_SCOPE')
    need(report['normalProductProvenance']is False and report['nativeExecution']=='NOT_RUN'and report['features']==['default']and report['defaultFeatureDefinition']==[]and report['compiledScope']=='ENV_UNSET_DEFAULT_OFF'and report['profileOverride']=={'CARGO_PROFILE_RELEASE_STRIP':'symbols'},'NEVER_NORMAL_HELPER_OR_OFFICIAL_CI_PROVENANCE')
    need(report['sourceBefore']==report['sourceAfter']and report['sourceUnchanged']and len(report['sourceBefore'])==report['sourceInputCount']==477,'477_ACTUAL_BEFORE_AFTER_SOURCE_INPUTS')
    source_root=R/'checkout-source-package-probe-first'
    for row in report['sourceBefore']:
        name=row['path'];need(isinstance(name,str)and not name.startswith('/')and ':'not in name and'\\'not in name and all(x not in('','.','..')for x in name.split('/')),'CANONICAL_COMPILER_SOURCE_MEMBER')
        raw_source=read(source_root/name);need(len(raw_source)==row['bytes']and sha(raw_source)==row['sha256'],'FINAL_COMPILER_INPUT_UNCHANGED')
    need(len(report['checks'])==6 and all(x['actualExit']==0 and x['parentReaped']for x in report['checks']),'REAL_COMPILER_CLIPPY_AND_CHECKS_RETURNED0')
    need(report['checks'][1]['argv']==['cargo','test','--locked','--offline','--release','--target','i686-pc-windows-gnu','-p','fc-windows','--lib','--no-run','--message-format=json'],'ACTUAL_TEST_BUILD_COMMAND')
    metadata=json.loads(read(base/'metadata-third.stdout.log'));package=next(p for p in metadata['packages']if p['name']=='fc-windows');need(package['manifest_path']==str(source_root/'crates/fc-windows/Cargo.toml')and package['features']['default']==[],'REAL_PACKAGE_METADATA_DEFAULT_EMPTY')
    events=[json.loads(line)for line in read(base/'test-build-third.stdout.log').splitlines()if line.strip()];artifacts=[x for x in events if x.get('reason')=='compiler-artifact'and x.get('target',{}).get('name')=='fc_windows'and x.get('profile',{}).get('test')is True and x.get('executable')]
    need(len(artifacts)==1 and artifacts[0]==report['compilerArtifact'],'UNIQUE_ACTUAL_COMPILER_TEST_ARTIFACT');artifact=artifacts[0]
    need(artifact['package_id']==package['id']and artifact['features']==['default']and artifact['profile']['test']is True and artifact['profile']['opt_level']=='3'and artifact['target']['src_path']==str(source_root/'crates/fc-windows/src/lib.rs'),'REAL_TEST_PROFILE_SOURCE_BINDING')
    copied=base/'artifact-third/fc_windows.exe';need(fact(copied)==report['testExecutable']and report['testExecutable']['sha256']==PE_SHA and report['testExecutable']['bytes']==PE_BYTES,'FINAL_PRESERVED_PE_IDENTITY');original=Path(artifact['executable']);need(original.parent==R/'source-package-probe-target-first/i686-pc-windows-gnu/release/deps'and read(original)==read(copied),'COMPILER_OUTPUT_EQUAL_PRESERVED_ORIGINAL')
    body=(source_root/'crates/fc-windows/src/installer_lifecycle/native/broker/source_package/native_probe.rs').read_text()
    need(all(name.rsplit('::',1)[-1]in body for name in TESTS.values())and body.count('#[ignore')==3,'EXACT_THREE_IGNORED_NATIVE_TEST_INTERFACES')
    return dict(report=fact(report_path),freeze=fact(freeze_path),testExecutable=fact(copied),compilerStdout=fact(base/'test-build-third.stdout.log'),metadata=fact(base/'metadata-third.stdout.log'),sourceRows=477,profileTest=True,features=['default'],defaultFeatureDefinition=[],strip='symbols',normalOrCI=False),read(copied)

def derive(output,producer_sha):
 producer,pe=qualify_producer(producer_sha);m,codec=vendor();material=json.loads(read(P/'materials-first.json'))
 canonical=read(C/'FutureClassroom.msi');report=read(C/'report.json');need(sha(canonical)==MSI_SHA and sha(report)==REPORT_SHA,'FIXED_OFFICIAL_A470_NORMAL_MSI_MATERIAL');original=json.loads(report)
 legacy=read(P/'legacy-payload-body.bin');original_template=read(C/'lifecycle/guard-client-template.exe');need(sha(original_template)=='a1f0b70a7791266ee371e08021045d58b8db055f92b4ea92735f7effeb6cdd93','EXACT_ORIGINAL_TEMPLATE');body_len=struct.unpack_from('<I',original_template,len(original_template)-20)[0];need(legacy==original_template[-20-body_len:-20],'RAW_BODY_EXACT_FROM_ORIGINAL_TEMPLATE_NOT_REENCODED');envelope=read(P/'payload-envelope-v2.bin');parsed=codec['parse_payload_manifest'](envelope)
 expected={x['path']:dict(bytes=x['size'],sha256=x['sha256'],component_guid=x['component_guid'])for x in original['payloads']}
 need(len(expected)==14 and envelope[88:]==legacy and parsed['entries']==expected and parsed['package']==PACKAGE and parsed['product']==PRODUCT and parsed['version']==VERSION,'EXACT_ORIGINAL14_RAW_MANIFEST_BODY_NO_REENCODING')
 prefix,header=patch_test_pe(pe);template=codec['make_carrier_template'](prefix);need(codec['parse_carrier_template'](template)==prefix and template[-116:-84]==bytes(32),'CANONICAL_ZERO32_TEST_TEMPLATE')
 hole=len(prefix)+16;bad_template=bytearray(template);safe=struct.unpack_from('<I',prefix,60)[0]+8;need(safe<hole and safe>=64,'SAFE_COFF_TIMESTAMP_BYTE_OUTSIDE_DIGEST');bad_template[safe]^=1;bad_template=bytes(bad_template);codec['parse_carrier_template'](bad_template);need([i for i,(a,b)in enumerate(zip(template,bad_template))if a!=b]==[safe],'ONLY_ONE_EMBEDDED_TEMPLATE_TIMESTAMP_BYTE')
 toolsraw=read(TOOLS);envraw=read(CHILD_ENV);need(sha(toolsraw)==TOOLS_SHA and sha(envraw)==ENV_SHA,'FIXED_PRIVATE_TOOLS_AND_CHILD_ENV');tools=json.loads(toolsraw);childenv=json.loads(envraw);need(set(childenv)=={'LD_LIBRARY_PATH','LC_ALL','GIO_USE_VFS','GSETTINGS_BACKEND'},'FIXED_CHILD_ENV_KEYS')
 toolfacts=json.loads(read(P/'tools-readonly-check-first.json'))['tools']
 for r in toolfacts:
  if r['tool']in('msibuild','msiinfo','msiextract'):need(fact(Path(r['path']))=={k:r[k]for k in('path','bytes','sha256')},'ACTUAL_PINNED_PRIVATE_TOOL')
 output=Path(output);need(output.is_absolute()and output.parent==R and output.resolve()==output and not output.exists(),'NEW_OWNED_OUTPUT_ONLY');output.mkdir();(output/'.owner').write_text('runtime-review-owned-source-package-probe-fixtures/v1\n');(output/'work').mkdir();(output/'cases').mkdir();started=time.monotonic();deadline=started+180;env=os.environ.copy();env.update(childenv)
 result=dict(status='FAIL_RETAIN_ORIGINALS',scope='DEV_BEFORE_BEGIN_READONLY_SOURCE_READER_INPUTS_NEVER_NORMAL_OR_INSTALLABLE_PRODUCT',producer=producer,canonical=material['canonical'],headerPatch=header,rawManifest=material['legacyRawBody'],payloadEnvelope=material['v2Envelope'],commands=[],cases={},budgetSeconds=180,Windows='NOT_RUN',installation='NOT_AUTHORIZED_NOT_RUN',newNormalOrFormalCI='NOT_GRANTED',originalPackageCode=PACKAGE)
 def run(label,argv,cwd):
  left=deadline-time.monotonic();need(left>0,'ORIGINAL_STATIC_180_BUDGET');so=output/(label+'.stdout.log');se=output/(label+'.stderr.log');row=dict(label=label,argv=list(map(str,argv)),actualExit=None,parentReaped=False,timedOut=False);result['commands'].append(row);t=time.monotonic()
  with so.open('xb')as out,se.open('xb')as err:
   try:
    p=subprocess.run(argv,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=min(60,left));row.update(actualExit=p.returncode,parentReaped=True)
   except subprocess.TimeoutExpired:row.update(parentReaped=True,timedOut=True);raise
   finally:row['seconds']=time.monotonic()-t
  need(so.stat().st_size<=MAX and se.stat().st_size<=16*1024*1024,'BOUNDED_TOOL_OUTPUT');row.update(stdout=fact(so),stderr=fact(se));need(row['actualExit']==0,'TOOL_ACTUAL0_'+label);return so.read_bytes()
 def info(label,*args):return run(label,[tools['msiinfo']['path'],*map(str,args)],output)
 def streams(label,msi):
  names=info(label+'-streams','streams',msi).decode().splitlines();need(len(names)==len(set(names))and len(names)<=128,'EXACT_FINITE_STREAM_NAMES');return {n:info(label+'-stream-'+str(i),'extract',msi,n)for i,n in enumerate(names)}
 def extract14(label,msi):
  dest=output/'extracted'/label;dest.mkdir(parents=True);run(label+'-extract14',[tools['msiextract']['path'],'-C',str(dest),str(msi)],output);mains=list(dest.rglob('fc-bootstrap.exe'));need(len(mains)==1,'ONE_EXTRACTED_PRODUCT_ROOT');root=mains[0].parent;actual={}
  for p in dest.rglob('*'):
   need(not p.is_symlink(),'NO_EXTRACTED_LINK')
   if p.is_file():need(p.is_relative_to(root),'NO_PAYLOAD_ESCAPE');b=read(p);actual[p.relative_to(root).as_posix()]=dict(bytes=len(b),sha256=sha(b),component_guid=expected[p.relative_to(root).as_posix()]['component_guid'])
  need(actual==expected,'ALL14_EXTRACTED_PAYLOAD_BYTES_UNCHANGED');return actual
 try:
  original_summary=info('original-summary','suminfo',C/'FutureClassroom.msi');need(PACKAGE.encode()in original_summary,'ACTUAL_ORIGINAL_PACKAGE_CODE');tables=info('original-tables','tables',C/'FutureClassroom.msi').decode().splitlines();need(len(tables)==len(set(tables))and len(tables)<=128 and all(re.fullmatch('[A-Za-z_][A-Za-z0-9_]{0,71}',n)for n in tables),'BOUND_CANONICAL_TABLE_NAMES');exports={n:info('original-table-'+n,'export',C/'FutureClassroom.msi',n)for n in tables};original_streams=streams('original',C/'FutureClassroom.msi')
  binary=m['idt_rows'](exports['Binary'],'Binary');need(all(row['Data']=='Binary.'+row['Name']for row in binary),'FIXED_BINARY_IMPORT_LEAFS');need({r['Name']for r in binary}=={'FcControlledGuardDll','FcGuardClientTemplate'}and original_streams['Binary.FcGuardClientTemplate']==read(C/'lifecycle/guard-client-template.exe')and original_streams['Binary.FcControlledGuardDll']==read(C/'lifecycle/fc_windows.dll'),'ORIGINAL_BINARY_SOURCE_EXACT')
  new_binary=exports['Binary']+b'FcPayloadManifest\tBinary.FcPayloadManifest\n'
  for case,tpl in [('positive',template),('bad-template',bad_template)]:
   casepath=output/'cases'/case;casepath.mkdir();msi=casepath/'FutureClassroom.msi';msi.write_bytes(canonical);work=output/'work'/case;work.mkdir();(work/'Binary').mkdir();(work/'Binary.idt').write_bytes(new_binary)
   for row in binary:
    name=row['Name'];data=tpl if name=='FcGuardClientTemplate'else original_streams['Binary.'+name];(work/'Binary'/row['Data']).write_bytes(data)
   (work/'Binary/Binary.FcPayloadManifest').write_bytes(envelope);run(case+'-replace-only-binary',[tools['msibuild']['path'],str(msi),'-q','DROP TABLE `Binary`','-i','Binary.idt'],work)
   need(info(case+'-summary','suminfo',msi)==original_summary,'ALL_SUMMARY_AND_PACKAGE_UNCHANGED');actual_tables=info(case+'-tables','tables',msi).decode().splitlines();need(set(actual_tables)==set(tables)and len(actual_tables)==len(tables),'COMPLETE_TABLE_MEMBERSHIP_UNCHANGED')
   for name in tables:
    got=info(case+'-table-'+name,'export',msi,name)
    if name=='Binary':need(sorted(m['idt_rows'](got,name),key=lambda r:r['Name'])==sorted(m['idt_rows'](new_binary,name),key=lambda r:r['Name']),'ONLY_NEW_PAYLOAD_BINARY_ROW_AND_TEMPLATE_DATA_CHANGED')
    else:need(got==exports[name],'ORIGINAL_TABLE_BYTES_'+name)
   got=streams(case,msi);need(set(got)==set(original_streams)|{'Binary.FcPayloadManifest'},'ONLY_EXPECTED_STREAM_ADD')
   for name,data in original_streams.items():need(got[name]==(tpl if name=='Binary.FcGuardClientTemplate'else data),'ALL_ORIGINAL_STREAMS_EXCEPT_TEMPLATE_EXACT')
   need(got['Binary.FcPayloadManifest']==envelope,'ORIGINAL_RAW_BODY_IN_V2_ENVELOPE_EXACT');ledger=extract14(case,msi)
   sealed=codec['bind_carrier_template'](template,read(msi));codec['verify_carrier_binding'](template,sealed,read(msi));(casepath/'SourceProbe.exe').write_bytes(sealed)
   result['cases'][case]=dict(test=TESTS[case],exe=fact(casepath/'SourceProbe.exe'),msi=fact(msi),embeddedTemplate=dict(bytes=len(tpl),sha256=sha(tpl)),payloads=ledger,onlyBinaryRowsChanged=True,originalPropertiesSummaryCASequence=True,originalPackageCode=PACKAGE,wholeMsiSealCorrect=True)
  positive=output/'cases/positive';bad=output/'cases/bad-seal';bad.mkdir();shutil.copyfile(positive/'FutureClassroom.msi',bad/'FutureClassroom.msi');badpe=bytearray(read(positive/'SourceProbe.exe'));badpe[hole]^=1;need(bytes(badpe[hole:hole+32])!=bytes(32),'NEGATIVE_SEAL_NOT_ZERO_FORMAT_SENTINEL');(bad/'SourceProbe.exe').write_bytes(badpe);need([i for i,(a,z)in enumerate(zip(read(positive/'SourceProbe.exe'),badpe))if a!=z]==[hole],'BADSEAL_EXACT_ONE_DIGEST_BYTE');result['cases']['bad-seal']=dict(test=TESTS['bad-seal'],exe=fact(bad/'SourceProbe.exe'),msi=fact(bad/'FutureClassroom.msi'),msiBytesEqualPositive=True,onlyDigestByteFlipped=hole,wholeMsiSealCorrect=False)
  try:codec['verify_carrier_binding'](template,read(bad/'SourceProbe.exe'),read(bad/'FutureClassroom.msi'))
  except ValueError:pass
  else:raise AssertionError('BADSEAL_MUST_FAIL_ONLY_BINDING')
  try:codec['verify_carrier_binding'](bad_template,read(output/'cases/bad-template/SourceProbe.exe'),read(output/'cases/bad-template/FutureClassroom.msi'))
  except ValueError:pass
  else:raise AssertionError('OUTSIDE_HOLE_TEMPLATE_MUST_FAIL_FULL_IMAGE_COMPARE')
  need(read(C/'FutureClassroom.msi')==canonical and read(C/'report.json')==report,'CANONICAL_ORIGINALS_UNCHANGED');result.update(status='PASS_DEV_STATIC_THREE_SOURCE_PACKAGE_PROBE_FIXTURES_NATIVE_NOT_RUN',template=dict(bytes=len(template),sha256=sha(template),digestHole=hole),badTemplateOnlyTimestampByte=safe,all14PayloadsPreserved=True,canonicalUnchanged=True,negativeTests='Seal mismatch before DB;template mismatch after validwholeMSIseal;each fixedexactignoredfulltest only',toolsManifest=dict(path=str(TOOLS),sha256=TOOLS_SHA),codecSourceSha256=sha(read(V/'installer-carrier-format.py')))
 except Exception as e:result.update(errorType=type(e).__name__,error=str(e));raise
 finally:result['elapsedSeconds']=time.monotonic()-started;(output/'report.json').write_bytes(raw(result))
 return result

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');ap.add_argument('--producer-sha256');ap.add_argument('--output-dir',type=Path);a=ap.parse_args()
 if not a.execute:print(json.dumps(dict(status='PREPARED_NOT_EXECUTED_STATIC_FIXTURE_DERIVER',Windows=False,tools=False)));return
 need(re.fullmatch('[0-9a-f]{64}',a.producer_sha256 or '')and a.output_dir,'EXACT_FROZEN_PRODUCER_AND_NEW_OUTPUT_REQUIRED');r=derive(a.output_dir,a.producer_sha256);print(json.dumps(dict(status=r['status'],output=str(a.output_dir))))
if __name__=='__main__':main()
