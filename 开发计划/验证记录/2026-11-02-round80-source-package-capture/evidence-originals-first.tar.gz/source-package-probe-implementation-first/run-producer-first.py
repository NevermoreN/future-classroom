from pathlib import Path
import os,json,hashlib,subprocess,time,shutil
R=Path('/tmp/fc-round80-controlled-repair');W=R/'checkout-source-package-probe-first';O=R/'source-package-probe-implementation-first';T=R/'source-package-probe-target-first'
def identity(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
files=sorted([str(p.relative_to(W)) for p in (W/'crates').rglob('*') if p.is_file() and (p.suffix=='.rs' or p.name=='Cargo.toml')]+['.cargo/config.toml','Cargo.toml','Cargo.lock','rust-toolchain.toml'])
def inventory():return [dict(path=p,**{k:v for k,v in identity(W/p).items()if k!='path'})for p in files]
r=dict(status='RUNNING_LOCAL_GNU_CFGTEST_COMPILER_ONLY',sourceBase='a4702b56bff66da5f5cbe74551d8751eb33fa520',sourceBefore=inventory(),checks=[],target='i686-pc-windows-gnu',features=[],compiledScope='ENV_UNSET_DEFAULT_OFF',profileOverride=dict(CARGO_PROFILE_RELEASE_STRIP='symbols'),nativeExecution='NOT_RUN',normalProductProvenance=False)
env=os.environ.copy();env.pop('FC_OWNED_REMOVAL_SCOPE_HEX',None);env['CARGO_TARGET_DIR']=str(T);env['CARGO_BUILD_JOBS']='2';env['CARGO_PROFILE_RELEASE_STRIP']='symbols'
commands=[('metadata',['cargo','metadata','--locked','--offline','--format-version=1','--no-deps']),('test-build',['cargo','test','--locked','--offline','--release','--target','i686-pc-windows-gnu','-p','fc-windows','--lib','--no-run','--message-format=json']),('clippy',['cargo','clippy','--locked','--offline','--release','--target','i686-pc-windows-gnu','-p','fc-windows','--tests','--','-D','warnings']),('fmt',['rustfmt','--edition','2021','--check','--config','skip_children=true','crates/fc-windows/src/installer_lifecycle/native/broker/source_package.rs','crates/fc-windows/src/installer_lifecycle/native/broker/source_package/native_probe.rs']),('architecture',['python3','scripts/check-architecture.py']),('diff',['git','diff','--check'])]
for name,cmd in commands:
 t=time.monotonic()
 with (O/(name+'.stdout.log')).open('xb')as so,(O/(name+'.stderr.log')).open('xb')as se:
  p=subprocess.Popen(cmd,cwd=W,env=env,stdout=so,stderr=se);code=p.wait(timeout=900)
 r['checks'].append(dict(name=name,argv=cmd,actualExit=code,parentReaped=True,seconds=time.monotonic()-t))
 if code:break
 if name=='test-build':
  objects=[json.loads(line)for line in(O/'test-build.stdout.log').read_text().splitlines()if line.startswith('{')]
  artifacts=[a for a in objects if a.get('reason')=='compiler-artifact'and a.get('executable')and a['target']['name']=='fc_windows'and a['profile']['test']]
  assert len(artifacts)==1 and artifacts[0]['features']==[]
  r['compilerArtifact']=artifacts[0];exe=Path(artifacts[0]['executable']);assert 0<exe.stat().st_size<=64*1024*1024
  D=O/'artifact';D.mkdir();dst=D/'fc_windows.exe';shutil.copyfile(exe,dst);r['testExecutable']=identity(dst)
r['sourceAfter']=inventory();r['sourceUnchanged']=r['sourceBefore']==r['sourceAfter'];r['sourceInputCount']=len(files)
r['status']='PASS_FROZEN_GNU_CFGTEST_COMPILER_ONLY'if r['sourceUnchanged']and len(r['checks'])==len(commands)and all(c['actualExit']==0 for c in r['checks'])else'FAIL_LOCAL_COMPILER_CHECK'
(O/'producer-report.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k]for k in ['status','checks','sourceUnchanged','sourceInputCount']}));print(json.dumps(r.get('testExecutable')))
