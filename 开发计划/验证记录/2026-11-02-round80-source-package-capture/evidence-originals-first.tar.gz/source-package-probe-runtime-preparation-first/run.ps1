
CheckRoot $c.root;$root=$c.root
[void](Inventory $root)
foreach($x in $c.inputs){$f=Fact (Join-Path $root $x.name);if($f.bytes-ne$x.bytes-or$f.sha256-cne$x.sha256){throw 'INPUT_BYTES'}}
$oldTemp=$env:TEMP;$oldTmp=$env:TMP;$clock=[Diagnostics.Stopwatch]::StartNew();$capture=$null;$p=$null;$returned=$true
$r=@{status='FAIL_RETAIN';cases=@();originalWholeSeconds=600;captureSourceOnlyProcessMethods=$true;scope='THREE_FIXED_IGNORED_CFGTEST_BEFORE_BEGIN_READONLY';normalProductOrFormalCI='NOT_GRANTED';installation='NOT_AUTHORIZED_NOT_RUN';cleanup='ROOT_DOWNLOAD_THEN_EXACT_DELETE_REQUIRED'}
try{
 $env:TEMP=Join-Path $root 'compiler-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP)
 try{Add-Type -Path (Join-Path $root 'Capture.cs') -ErrorAction Stop}finally{$env:TEMP=$oldTemp;$env:TMP=$oldTmp}
 $capture=[Fc79Capture]::new()
 $env:TEMP=Join-Path $root 'test-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP)
 foreach($s in $c.cases){
  $exe=Join-Path $root ('cases\'+$s.name+'\SourceProbe.exe')
  if($clock.ElapsedMilliseconds-ge600000){throw 'WHOLE_BUDGET'}
  $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$exe;$info.Arguments='--exact '+$s.test+' --ignored --nocapture --test-threads=1';$info.WorkingDirectory=[IO.Path]::GetDirectoryName($exe);$info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
  $p=[Diagnostics.Process]::new();$p.StartInfo=$info;$case=@{name=$s.name;argv=$info.Arguments;originalSeconds=150;actualExit=$false;exitCode=$null};$r.cases+=,$case
  $case.startedWholeMilliseconds=$clock.ElapsedMilliseconds;$case.originalDeadlineWholeMilliseconds=[Math]::Min(600000,$case.startedWholeMilliseconds+150*1000)
  if(-not$p.Start()){throw 'START'};$returned=$false;$case.pid=$p.Id;$case.creation=$p.StartTime.ToUniversalTime().ToFileTimeUtc()
  $stdout=$p.StandardOutput.ReadToEndAsync();$stderr=$p.StandardError.ReadToEndAsync()
  $case.original=$capture.HoldStartedClient($p.Handle,[uint32]$p.Id,[long]$case.creation,$exe,$s.exeSha,$c.sid)
  $left=[int]($case.originalDeadlineWholeMilliseconds-$clock.ElapsedMilliseconds)
  if($left-le0-or-not$p.WaitForExit($left)){throw 'ORIGINAL_TEST_PARENT_UNKNOWN_RETAIN_NO_KILL'}
  $returned=$true;$p.Refresh();$case.actualExit=$true;$case.exitCode=$p.ExitCode
  if(-not[Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($stdout,$stderr),[int][Math]::Max(0,$case.originalDeadlineWholeMilliseconds-$clock.ElapsedMilliseconds))){throw 'ORIGINAL_PIPES_UNKNOWN'}
  $case.stdout=$stdout.Result;$case.stderr=$stderr.Result;[void]$capture.Snapshot()
  if($case.original.Wait-ne0-or-not$case.original.ExitKnown-or$case.original.ExitCode-ne$case.exitCode){throw 'ORIGINAL_TEST_RETURN_MISMATCH'}
  $case.endedWholeMilliseconds=$clock.ElapsedMilliseconds
  $p.Dispose();$p=$null;if($case.exitCode-ne0){throw 'NATIVE_TEST_FAILURE'}
  if($case.endedWholeMilliseconds-gt$case.originalDeadlineWholeMilliseconds){throw 'ORIGINAL_TEST_DEADLINE_EXCEEDED'}
 }
 $r.status='PASS_THREE_EXACT_SOURCE_PACKAGE_CFGTEST_PROCESSES_WIN11_ONLY'
}catch{$r.error=$_.Exception.Message}finally{
 $env:TEMP=$oldTemp;$env:TMP=$oldTmp
 if($null-ne$p-and$returned){$p.Dispose()}
 if($null-ne$capture){try{$r.originalObjects=@($capture.FinishAndClose())}catch{$r.status='FAIL_RETAIN';$r.closeError=$_.Exception.Message}}
 $r.originalParentReturned=$returned;$r.elapsedMilliseconds=$clock.ElapsedMilliseconds
 if($clock.ElapsedMilliseconds-ge600000){$r.status='FAIL_RETAIN';$r.budgetExceeded=$true}
 [IO.File]::WriteAllText((Join-Path $root 'native-result.json'),($r|ConvertTo-Json -Depth 30),[Text.UTF8Encoding]::new($false))
}
$r|ConvertTo-Json -Depth 30 -Compress
if($r.status-cne'PASS_THREE_EXACT_SOURCE_PACKAGE_CFGTEST_PROCESSES_WIN11_ONLY'){exit 1}
