"""Three fixed before-Begin readonly SourceReader cfgtests. Default inert. Root sole executor."""
import argparse,base64,hashlib,json,os,re,runpy,secrets,shutil,subprocess,time
from pathlib import Path
E=Path('/tmp/fc-round80-controlled-repair')
BASE=E/'native-reference-first/run-negative-msi-r79-third.py'
CAP=E/'native-reference-first/Capture.cs'
SID='S-1-5-21-3896111207-1867804362-1971593122-1001'
BOOT='[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()))'
COMMON='$ErrorActionPreference=\'Stop\';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)\nfunction RootPath {return Join-Path ([IO.Path]::GetFullPath($env:TEMP)) (\'FutureClassroom-r80-source-package-probe-\'+$c.nonce)}\nfunction Fact($p){$a=[IO.File]::GetAttributes($p);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0 -or ($a-band[IO.FileAttributes]::Directory)-ne0){throw \'REGULAR_NO_REPARSE\'};return @{bytes=[long]([IO.FileInfo]::new($p).Length);sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}\nfunction CheckRoot($root){if($root-cne$c.root -or [IO.Path]::GetFileName($root)-cne(\'FutureClassroom-r80-source-package-probe-\'+$c.nonce)){throw \'EXACT_ROOT\'};$a=[IO.File]::GetAttributes($root);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0){throw \'ROOT_REPARSE\'};if([IO.File]::ReadAllText((Join-Path $root \'.owner\'))-cne"future-classroom-owned-r80-source-package-probe-runtime/v1`n"){throw \'OWNER_MARKER\'};$acl=[IO.Directory]::GetAccessControl($root);if(-not$acl.AreAccessRulesProtected -or $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-cne$c.sid){throw \'EXACT_PROTECTED_OWNER\'};$rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));if($rules.Count-ne2 -or @($rules|Where-Object{$_.IdentityReference.Value-notin@($c.sid,\'S-1-5-18\') -or $_.AccessControlType-ne\'Allow\' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count){throw \'ONLY_USER_SYSTEM_DACL\'}}\nfunction Inventory($root){CheckRoot $root;$files=@();$dirs=@();$q=[Collections.Generic.Queue[string]]::new();$q.Enqueue($root);while($q.Count){$dir=$q.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){$a=[IO.File]::GetAttributes($p);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0){throw \'INVENTORY_REPARSE\'};$rel=$p.Substring($root.Length+1).Replace(\'\\\',\'/\');if(($a-band[IO.FileAttributes]::Directory)-ne0){$dirs+=$rel;$q.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256}};if($files.Count-gt128 -or $dirs.Count-gt16){throw \'INVENTORY_BOUND\'}}};return @{files=$files;directories=$dirs}}\n'
CREATE='\n$w=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$w.User;if($sid.Value-cne$c.sid){throw \'SID\'}}finally{$w.Dispose()}\n$root=RootPath;try{[void][IO.File]::GetAttributes($root);throw \'ROOT_EXISTS\'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}\n$cursor=[IO.Path]::GetDirectoryName($root);while($cursor){if(([IO.File]::GetAttributes($cursor)-band[IO.FileAttributes]::ReparsePoint)-ne0){throw \'ANCESTOR_REPARSE\'};$cursor=[IO.Path]::GetDirectoryName($cursor)}\n[void][IO.Directory]::CreateDirectory($root);$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false);foreach($s in @($sid,[Security.Principal.SecurityIdentifier]::new(\'S-1-5-18\'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($s,\'FullControl\',\'ContainerInherit,ObjectInherit\',\'None\',\'Allow\'))};[IO.Directory]::SetAccessControl($root,$acl)\n[IO.File]::WriteAllText((Join-Path $root \'.owner\'),"future-classroom-owned-r80-source-package-probe-runtime/v1`n",[Text.UTF8Encoding]::new($false));$c.root=$root;CheckRoot $root;@{root=$root;status=\'CREATED\'}|ConvertTo-Json -Compress\n'
RUN="\nCheckRoot $c.root;$root=$c.root\n[void](Inventory $root)\nforeach($x in $c.inputs){$f=Fact (Join-Path $root $x.name);if($f.bytes-ne$x.bytes-or$f.sha256-cne$x.sha256){throw 'INPUT_BYTES'}}\n$oldTemp=$env:TEMP;$oldTmp=$env:TMP;$clock=[Diagnostics.Stopwatch]::StartNew();$capture=$null;$p=$null;$returned=$true\n$r=@{status='FAIL_RETAIN';cases=@();originalWholeSeconds=600;captureSourceOnlyProcessMethods=$true;scope='THREE_FIXED_IGNORED_CFGTEST_BEFORE_BEGIN_READONLY';normalProductOrFormalCI='NOT_GRANTED';installation='NOT_AUTHORIZED_NOT_RUN';cleanup='ROOT_DOWNLOAD_THEN_EXACT_DELETE_REQUIRED'}\ntry{\n $env:TEMP=Join-Path $root 'compiler-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP)\n try{Add-Type -Path (Join-Path $root 'Capture.cs') -ErrorAction Stop}finally{$env:TEMP=$oldTemp;$env:TMP=$oldTmp}\n $capture=[Fc79Capture]::new()\n $env:TEMP=Join-Path $root 'test-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP)\n foreach($s in $c.cases){\n  $exe=Join-Path $root ('cases\\'+$s.name+'\\SourceProbe.exe')\n  if($clock.ElapsedMilliseconds-ge600000){throw 'WHOLE_BUDGET'}\n  $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$exe;$info.Arguments='--exact '+$s.test+' --ignored --nocapture --test-threads=1';$info.WorkingDirectory=[IO.Path]::GetDirectoryName($exe);$info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true\n  $p=[Diagnostics.Process]::new();$p.StartInfo=$info;$case=@{name=$s.name;argv=$info.Arguments;originalSeconds=150;actualExit=$false;exitCode=$null};$r.cases+=,$case\n  $case.startedWholeMilliseconds=$clock.ElapsedMilliseconds;$case.originalDeadlineWholeMilliseconds=[Math]::Min(600000,$case.startedWholeMilliseconds+150*1000)\n  if(-not$p.Start()){throw 'START'};$returned=$false;$case.pid=$p.Id;$case.creation=$p.StartTime.ToUniversalTime().ToFileTimeUtc()\n  $stdout=$p.StandardOutput.ReadToEndAsync();$stderr=$p.StandardError.ReadToEndAsync()\n  $case.original=$capture.HoldStartedClient($p.Handle,[uint32]$p.Id,[long]$case.creation,$exe,$s.exeSha,$c.sid)\n  $left=[int]($case.originalDeadlineWholeMilliseconds-$clock.ElapsedMilliseconds)\n  if($left-le0-or-not$p.WaitForExit($left)){throw 'ORIGINAL_TEST_PARENT_UNKNOWN_RETAIN_NO_KILL'}\n  $returned=$true;$p.Refresh();$case.actualExit=$true;$case.exitCode=$p.ExitCode\n  if(-not[Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($stdout,$stderr),[int][Math]::Max(0,$case.originalDeadlineWholeMilliseconds-$clock.ElapsedMilliseconds))){throw 'ORIGINAL_PIPES_UNKNOWN'}\n  $case.stdout=$stdout.Result;$case.stderr=$stderr.Result;[void]$capture.Snapshot()\n  if($case.original.Wait-ne0-or-not$case.original.ExitKnown-or$case.original.ExitCode-ne$case.exitCode){throw 'ORIGINAL_TEST_RETURN_MISMATCH'}\n  $case.endedWholeMilliseconds=$clock.ElapsedMilliseconds\n  $p.Dispose();$p=$null;if($case.exitCode-ne0){throw 'NATIVE_TEST_FAILURE'}\n  if($case.endedWholeMilliseconds-gt$case.originalDeadlineWholeMilliseconds){throw 'ORIGINAL_TEST_DEADLINE_EXCEEDED'}\n }\n $r.status='PASS_THREE_EXACT_SOURCE_PACKAGE_CFGTEST_PROCESSES_WIN11_ONLY'\n}catch{$r.error=$_.Exception.Message}finally{\n $env:TEMP=$oldTemp;$env:TMP=$oldTmp\n if($null-ne$p-and$returned){$p.Dispose()}\n if($null-ne$capture){try{$r.originalObjects=@($capture.FinishAndClose())}catch{$r.status='FAIL_RETAIN';$r.closeError=$_.Exception.Message}}\n $r.originalParentReturned=$returned;$r.elapsedMilliseconds=$clock.ElapsedMilliseconds\n if($clock.ElapsedMilliseconds-ge600000){$r.status='FAIL_RETAIN';$r.budgetExceeded=$true}\n [IO.File]::WriteAllText((Join-Path $root 'native-result.json'),($r|ConvertTo-Json -Depth 30),[Text.UTF8Encoding]::new($false))\n}\n$r|ConvertTo-Json -Depth 30 -Compress\nif($r.status-cne'PASS_THREE_EXACT_SOURCE_PACKAGE_CFGTEST_PROCESSES_WIN11_ONLY'){exit 1}\n"
OWNED="$a=@(Get-CimInstance Win32_Process -ErrorAction Stop|Where-Object {$_.ExecutablePath -and $_.ExecutablePath.StartsWith($c.root+'\\',[StringComparison]::OrdinalIgnoreCase)});@{count=$a.Count}|ConvertTo-Json -Compress"
INVENTORY='Inventory $c.root|ConvertTo-Json -Depth 12 -Compress'
DELETE="CheckRoot $c.root;$now=Inventory $c.root;if($now.files.Count-ne$c.inventory.files.Count -or $now.directories.Count-ne$c.inventory.directories.Count){throw 'MEMBERSHIP_CHANGED'};foreach($row in $now.files){$old=@($c.inventory.files|Where-Object{$_.path-ceq$row.path});if($old.Count-ne1 -or $old[0].bytes-ne$row.bytes -or $old[0].sha256-cne$row.sha256){throw 'ORIGINAL_FILE_BYTES_CHANGED'}};foreach($dir in $now.directories){if($dir-cnotin$c.inventory.directories){throw 'DIRECTORY_CHANGED'}}\nforeach($row in $now.files){if($row.path-cne'.owner'){[IO.File]::Delete((Join-Path $c.root ($row.path.Replace('/','\\'))))}};foreach($dir in @($now.directories|Sort-Object Length -Descending)){[IO.Directory]::Delete((Join-Path $c.root ($dir.Replace('/','\\'))),$false)};[IO.File]::Delete((Join-Path $c.root '.owner'));[IO.Directory]::Delete($c.root,$false)\ntry{[void][IO.File]::GetAttributes($c.root);throw 'ROOT_STILL_EXISTS'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}\n@{status='REMOVED_EXACT_SOURCE_PACKAGE_PROBE_RUNTIME_ROOT';nonce=$c.nonce;knownAbsent=$true}|ConvertTo-Json -Compress\n"

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fact(p):
 p=Path(p);assert p.is_file() and not p.is_symlink();return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def exact_freeze(root,expected):
 f=root/'freeze-first.json';assert sha(f)==expected;j=json.loads(f.read_bytes())
 actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
 assert actual=={x['path'] for x in j['files']}|{'freeze-first.json'},'EXACT_FROZEN_MEMBERSHIP_REQUIRED'
 for x in j['files']:
  p=root/x['path'];assert p.is_file() and not p.is_symlink() and p.stat().st_size==x['bytes'] and sha(p)==x['sha256']
 return fact(f)
def qualify(stdout,row,fixture):
 name=row['test'];assert len(re.findall(r'^running 1 test\r?$',stdout,re.M))==1
 starts=re.findall(r'^test ([^\s]+) \.\.\.',stdout,re.M);assert starts==[name],('EXACT_SINGLE_PARENT_TEST_REQUIRED',starts)
 summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',stdout,re.M)
 assert len(summaries)==1 and summaries[0][:5]==('ok','1','0','0','0')
 markers=re.findall(r'SOURCE_PACKAGE_NATIVE_[^\r\n]+',stdout)
 if row['name']=='positive':expected='SOURCE_PACKAGE_NATIVE_CAPTURE_OK abi=2 payloads=14 msiCloses=10 sourceSha='+fixture['msi']['sha256']+' templateSha='+fixture['embeddedTemplate']['sha256']+' claims=0'
 elif row['name']=='bad-seal':expected='SOURCE_PACKAGE_NATIVE_SEAL_REJECT_OK claims=0'
 else:assert row['name']=='bad-template';expected='SOURCE_PACKAGE_NATIVE_TEMPLATE_REJECT_OK claims=0'
 assert markers==[expected],('EXACT_COMPILED_ASSERTION_MARKER_REQUIRED',markers,expected)
 assert 'FAILED' not in stdout
 return dict(exactTest=name,passed=1,failed=0,ignored=0,marker=expected,authority='ORIGINAL_PARENT_EXIT0_AND_CHECKED_CLOSE_PLUS_FROZEN_TEST_ASSERTIONS',beforeBeginOnly=True)
def main():
 a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');a.add_argument('--validate-inputs-only',action='store_true');a.add_argument('--preparation-freeze-sha256');a.add_argument('--output-dir',type=Path);v=a.parse_args()
 if not v.execute and not v.validate_inputs_only:print('{"status":"NOT_RUN"}');return
 assert not(v.execute and v.validate_inputs_only)
 prep=Path(__file__).resolve().parent;pins=json.loads((prep/'qualification-pins.json').read_bytes());prep_input=exact_freeze(prep,v.preparation_freeze_sha256)
 assert (E/'.owner').read_bytes()==b'future-classroom-owned-r80-controlled-repair/v1\n'
 assert sha(BASE)=='da74f0058deac86507b712075904556780be6b262b18acb82415da6725c6e202' and sha(CAP)=='e74300d27694e46fde2e8113cfeee47ffd3f11f9172f01c5621fa2ba5fdcab5a'
 fixtures=E/'source-package-probe-fixtures-first';fixture_freeze=exact_freeze(fixtures,pins['fixtureFreezeSha256']);report=fixtures/'report.json';assert sha(report)==pins['fixtureReportSha256'];fr=json.loads(report.read_bytes())
 assert fr['status']=='PASS_DEV_STATIC_THREE_SOURCE_PACKAGE_PROBE_FIXTURES_NATIVE_NOT_RUN' and fr['Windows']=='NOT_RUN' and fr['all14PayloadsPreserved'] and fr['canonicalUnchanged']
 producer=E/'source-package-probe-implementation-first/producer-report-third.json';assert sha(producer)=='87d77fcc01804087f6ce074e348f21a170ad655de17a0b29c539cfd0884f5c07'
 producer_freeze=fact(producer.parent/'freeze-first.json')
 assert producer_freeze['sha256']=='1adf6729449e50e05451a5229d10249e20da0e497ec35858ca7c9d4e169d6355'
 producer_doc=json.loads(producer.read_bytes());assert producer_doc['sourceUnchanged'] and producer_doc['sourceBefore']==producer_doc['sourceAfter'] and len(producer_doc['sourceBefore'])==477
 assert producer_doc['status']=='PASS_FROZEN_GNU_CFGTEST_COMPILER_ONLY' and producer_doc['features']==['default'] and producer_doc['defaultFeatureDefinition']==[] and producer_doc['normalProductProvenance'] is False
 finalpe=Path(producer_doc['testExecutable']['path']);assert fact(finalpe)==producer_doc['testExecutable'] and sha(finalpe)=='b7bc5c77a8434058453f3f64e742c0e3d4eb6d32eba0ad9898d558cbb1127bd5'
 controller_input=fact(Path(__file__).resolve());fixture_inputs=[fact(BASE),fact(CAP)]
 rows=[]
 for name in ('positive','bad-seal','bad-template'):
  x=fr['cases'][name]
  for kind,leaf in [('exe','SourceProbe.exe'),('msi','FutureClassroom.msi')]:assert fact(fixtures/'cases'/name/leaf)==x[kind]
  rows.append(dict(name=name,test=x['test'],exeSha=x['exe']['sha256']))
 assert len(set(x['test'] for x in rows))==3 and all(x['test'].startswith('installer_lifecycle::native::broker::source_package::native_probe::') for x in rows)
 def verify_inputs():
  assert fact(Path(__file__).resolve())==controller_input and fact(prep/'freeze-first.json')==prep_input
  exact_freeze(prep,v.preparation_freeze_sha256);exact_freeze(fixtures,pins['fixtureFreezeSha256'])
  assert [fact(BASE),fact(CAP)]==fixture_inputs and sha(producer)==pins['producerSha256'] and fact(finalpe)==producer_doc['testExecutable']
 verify_inputs()
 if v.validate_inputs_only:
  print(json.dumps(dict(status='PASS_LOCAL_THREE_FIXED_CFGTEST_FIXTURE_QUALIFICATION_NATIVE_NOT_RUN',cases=rows,fixtureReport=fact(report),producer=fact(producer),role='TEST_PROFILE_DERIVED_GUI_ABI2_NEVER_NORMAL_OR_OFFICIAL_CI')));return
 assert v.output_dir==E/'source-package-probe-runtime-first' and not v.output_dir.exists();out=v.output_dir;out.mkdir();(out/'.owner').write_text('future-classroom-owned-source-package-probe-runtime-local/v1\n')
 r=dict(status='STARTED',scope='THREE_BEFORE_BEGIN_READONLY_SOURCE_CAPTURE_TESTS',newNormalProductOrFormalCI='NOT_GRANTED',installedProductState='NO_INSTALL_OR_PRODUCT_MUTATION_AUTHORIZED',WindowsOS='WIN11_ONLY_WHEN_ACTUAL',producer=fact(producer),producerFreeze=producer_freeze,fixtureReport=fact(report),fixtureFreeze=fixture_freeze,controllerInput=controller_input,preparationFreeze=prep_input,fixtureInputs=fixture_inputs,operations=[],cleanup='NOT_RUN',outerSeconds=900)
 c=dict(nonce=secrets.token_hex(16),sid=SID,root=None,cases=rows);start=time.monotonic()
 def save():(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
 def call(label,cmd,feed=None,limit=30):
  begin=time.monotonic();left=900-(begin-start);assert left>0
  child=subprocess.Popen(cmd,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE);timed=False
  try:stdout,stderr=child.communicate(feed,timeout=min(left,limit))
  except subprocess.TimeoutExpired:timed=True;child.kill();stdout,stderr=child.communicate()
  so=out/(label+'.stdout.log');se=out/(label+'.stderr.log');so.write_bytes(stdout);se.write_bytes(stderr)
  r['operations'].append(dict(name=label,argv=cmd,actualReturnCode=child.returncode,originalLocalReaped=True,remoteOriginalReturnUnknown=timed,budgetExceeded=timed,elapsedSeconds=time.monotonic()-begin,stdout=fact(so),stderr=fact(se)));save()
  assert not timed and child.returncode==0,(label,child.returncode,'REMOTE_UNKNOWN_RETAIN' if timed else 'ACTUAL_NONZERO');return stdout
 def remote(label,script,limit=30):
  feed=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+COMMON+script).encode()
  return call(label,['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','future-classroom-win11','powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(BOOT.encode('utf-16-le')).decode()],feed,limit)
 try:
  c['root']=json.loads(remote('create',CREATE))['root'];r['windowsRoot']=c['root'];save()
  upload=out/'upload';upload.mkdir();shutil.copytree(fixtures/'cases',upload/'cases');shutil.copyfile(CAP,upload/'Capture.cs')
  c['inputs']=[dict(name=p.relative_to(upload).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(upload.rglob('*')) if p.is_file()]
  assert len(c['inputs'])==7
  for p in sorted(upload.iterdir()):call('upload-'+p.name,['scp','-q','-r','-o','BatchMode=yes',str(p),'future-classroom-win11:'+c['root'].replace('\\','/')+'/'],limit=60)
  native=json.loads(remote('run',RUN,600));r['native']=native
  assert native['originalParentReturned'] is True and native['status']=='PASS_THREE_EXACT_SOURCE_PACKAGE_CFGTEST_PROCESSES_WIN11_ONLY'
  assert len(native['cases'])==3 and [x['name'] for x in native['cases']]==[x['name']for x in rows]
  r['qualifiedCases']=[]
  for case,row in zip(native['cases'],rows):
   assert case['argv']=='--exact '+row['test']+' --ignored --nocapture --test-threads=1' and case['actualExit'] and case['exitCode']==0
   r['qualifiedCases'].append(dict(name=row['name'],**qualify(case['stdout'],row,fr['cases'][row['name']])))
  assert len(native['originalObjects'])==3 and all(x['CheckedClose'] and x['Wait']==0 and x['ExitKnown'] and x['ExitCode']==0 for x in native['originalObjects'])
  owned=json.loads(remote('owned-processes',OWNED));r['ownedProcessReadback']=owned;assert owned['count']==0
  inv=json.loads(remote('inventory',INVENTORY));r['inventory']=inv
  for item in c['inputs']:
   actual=[x for x in inv['files']if x['path']==item['name']];assert len(actual)==1 and actual[0]['bytes']==item['bytes'] and actual[0]['sha256']==item['sha256']
  save();download=out/'download';download.mkdir();call('download',['scp','-q','-r','-o','BatchMode=yes','future-classroom-win11:'+c['root'].replace('\\','/'),str(download)],limit=60)
  local=download/Path(c['root'].replace('\\','/')).name;verify_inputs();helper=runpy.run_path(str(BASE));helper['verify_download'](local,inv)
  assert json.loads((local/'native-result.json').read_bytes())==native
  r['downloadVerified']=True;r['downloadCounts']=dict(files=len(inv['files']),directories=len(inv['directories']))
  c['inventory']=inv;verify_inputs();assert json.loads(remote('owned-processes-before-delete',OWNED))['count']==0
  r['delete']=json.loads(remote('delete',DELETE));assert r['delete']['knownAbsent'] is True;r['cleanup']='PASS_EXACT_DOWNLOADED_OWNED_SCRATCH_ONLY';r['status']='PASS_THREE_FIXED_SOURCE_PACKAGE_CFGTESTS_BEFORE_BEGIN_WIN11_ONLY'
 except Exception as error:r.update(status='FAIL_RETAIN_ORIGINALS',errorType=type(error).__name__,error=str(error))
 r['elapsedSeconds']=time.monotonic()-start
 if r['elapsedSeconds']>=900:r['status']='FAIL_OUTER_ORIGINAL_BUDGET_EXCEEDED';r['outerBudgetExceeded']=True
 try:verify_inputs();r['sourceArtifactsAndControllerUnchanged']=True
 except Exception:r['sourceArtifactsAndControllerUnchanged']=False;r['status']='FAIL_SOURCE_ARTIFACT_CHANGED'
 save();print(json.dumps(dict(status=r['status'],report=str(out/'report.json'),sha256=sha(out/'report.json'),error=r.get('error'))));raise SystemExit(0 if r['status'].startswith('PASS_')else 1)
if __name__=='__main__':main()
