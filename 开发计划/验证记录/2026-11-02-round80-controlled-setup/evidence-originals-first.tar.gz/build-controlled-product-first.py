"""Root-owned normal GNU producer for a frozen, local controlled-MSI candidate."""
from pathlib import Path
import hashlib
import json
import os
import runpy
import signal
import subprocess
import time

ROOT = Path('/tmp/fc-round80-controlled-repair')
WORK = ROOT / 'checkout-52d6392-first'
OUT = ROOT / 'controlled-product-producer-first'
TARGET = 'i686-pc-windows-gnu'
TARGET_DIR = ROOT / 'target-first'
assert (ROOT / '.owner').read_bytes() == b'future-classroom-owned-r80-controlled-repair/v1\n'
assert not OUT.exists()
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK) == b''
HEAD = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
assert HEAD == 'c50882df40b86248e3e2d4e404d0fbe8e43e30a9'
dev = runpy.run_path(str(WORK / 'scripts/package-controlled-dev.py'))
OUT.mkdir()
(OUT / '.owner').write_text('future-classroom-owned-controlled-product-producer/v1\n')


def fact(path):
    data = path.read_bytes()
    return {'path': str(path.relative_to(OUT)), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


before = dev['source_inventory'](WORK)
(OUT / 'inputs-before.json').write_text(json.dumps(before, indent=2) + '\n')
env = os.environ.copy()
env.pop('CARGO_ENCODED_RUSTFLAGS', None)
scoped_env = {
    'CARGO_BUILD_JOBS': '2',
    'CARGO_TARGET_DIR': str(TARGET_DIR),
    'CARGO_TARGET_I686_PC_WINDOWS_GNU_LINKER': 'i686-w64-mingw32-gcc',
    'RUSTFLAGS': '-C target-feature=+crt-static -C link-arg=-Wl,--major-subsystem-version,6,--minor-subsystem-version,1',
}
env.update(scoped_env)
report = {'status': 'STARTED', 'target': TARGET, 'source_root': str(WORK),
          'source_head': HEAD, 'formal_ci': False, 'environment': scoped_env,
          'removed_environment_keys': ['CARGO_ENCODED_RUSTFLAGS'],
          'runtime': 'NOT_RUN', 'commands': [],
          'producer_script': {'path': str(Path(__file__)),
                              'sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}}


def save():
    (OUT / 'evidence.json').write_text(json.dumps(report, indent=2) + '\n')


def invoke(name, argv, budget):
    started = time.monotonic()
    process = subprocess.Popen(argv, cwd=WORK, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, start_new_session=True)
    timed_out = False
    try:
        stdout, stderr = process.communicate(timeout=budget)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            stdout, stderr = process.communicate(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            stdout, stderr = process.communicate()
    output = OUT / (name + '.stdout.jsonl')
    errors = OUT / (name + '.stderr.log')
    output.write_bytes(stdout)
    errors.write_bytes(stderr)
    row = {'name': name, 'argv': argv, 'actual_exit': process.returncode,
           'parent_reaped': process.poll() is not None, 'timed_out': timed_out,
           'seconds': time.monotonic() - started, 'original_budget_seconds': budget,
           'stdout': fact(output), 'stderr': fact(errors)}
    if process.returncode != 0 or timed_out:
        report['failed_command'] = row
        report['status'] = 'FAIL_RETAIN_ORIGINALS'
        save()
        raise SystemExit(1)
    return row, stdout


save()
metadata_argv = ['cargo', 'metadata', '--offline', '--locked', '--no-deps', '--format-version', '1']
row, raw = invoke('metadata', metadata_argv, 60)
metadata = json.loads(raw)
assert metadata['workspace_root'] == str(WORK)
assert metadata['target_directory'] == str(TARGET_DIR)
report['metadata_command'] = row
report['metadata'] = row['stdout']
report['inputs_before'] = fact(OUT / 'inputs-before.json')
save()
phases = [('product-compile', 'fc-bootstrap', 'fc-bootstrap', 'fc-bootstrap.exe'),
          ('lifecycle-compile', 'fc-bootstrap', 'fc-installer-lifecycle', 'fc-installer-lifecycle.exe'),
          ('guard-library-compile', 'fc-windows', 'fc_windows', 'fc_windows.dll')]
(OUT / 'artifacts').mkdir()
for name, package, target_name, leaf in phases:
    argv = ['cargo', 'build', '--release', '--offline', '--locked', '-p', package]
    argv += ['--lib'] if name == 'guard-library-compile' else ['--bin', target_name]
    argv += ['--target', TARGET, '--target-dir', str(TARGET_DIR), '--message-format=json']
    row, raw = invoke(name, argv, 900)
    messages = [json.loads(line) for line in raw.splitlines() if line.startswith(b'{')]
    selected = [message for message in messages if message.get('reason') == 'compiler-artifact'
                and message.get('target', {}).get('name') == target_name
                and message.get('profile', {}).get('test') is False]
    assert len(selected) == 1
    message = selected[0]
    filenames = ([path for path in message['filenames'] if Path(path).name == leaf]
                 if name == 'guard-library-compile' else [message['executable']])
    assert len(filenames) == 1
    artifact = Path(filenames[0])
    assert artifact.parent == TARGET_DIR / TARGET / 'release' and artifact.name == leaf
    assert artifact.is_file() and not artifact.is_symlink()
    data = artifact.read_bytes()
    assert 0 < len(data) <= 32 * 1024 * 1024
    copy = OUT / 'artifacts' / leaf
    copy.write_bytes(data)
    row['artifact'] = fact(copy)
    report['commands'].append(row)
    assert before == dev['source_inventory'](WORK)
    save()
    print(json.dumps({'phase': name, 'actual_exit': row['actual_exit'],
                      'seconds': row['seconds'], 'artifact': row['artifact']}), flush=True)
after = dev['source_inventory'](WORK)
assert before == after
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == HEAD
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK) == b''
(OUT / 'inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
report['inputs_after'] = fact(OUT / 'inputs-after.json')
report['status'] = 'DEV_FROZEN_NORMAL_BUILD_ONLY'
save()
print(json.dumps({'status': report['status'], 'source_head': HEAD,
                  'input_count': len(before), 'evidence': fact(OUT / 'evidence.json')}), flush=True)
