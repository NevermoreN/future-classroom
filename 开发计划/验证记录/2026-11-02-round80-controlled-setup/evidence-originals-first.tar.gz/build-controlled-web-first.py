"""Build an owned teacher-Web copy for the next controlled product fixture."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

ROOT = Path('/tmp/fc-round80-controlled-repair')
WORK = ROOT / 'checkout-52d6392-first'
OUT = ROOT / 'controlled-web-first'
assert not OUT.exists()
assert (ROOT / '.owner').read_bytes() == b'future-classroom-owned-r80-controlled-repair/v1\n'
OUT.mkdir()
(OUT / '.owner').write_text('future-classroom-owned-r80-controlled-web/v1\n')
source_base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
names = subprocess.check_output(['git', 'ls-files', '-z', '--', 'web'], cwd=WORK).decode().split('\0')
names = sorted(name for name in names if name)
assert names and all(name.startswith('web/') for name in names)


def fact(path, name):
    assert path.is_file() and not path.is_symlink()
    data = path.read_bytes()
    return {'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


before = [fact(WORK / name, name) for name in names]
for name in names:
    data = (WORK / name).read_bytes()
    assert subprocess.check_output(['git', 'show', source_base + ':' + name], cwd=WORK) == data
    target = OUT / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
report = {'status': 'STARTED', 'purpose': 'NEXT_CONTROLLED_PRODUCT_FIXTURE_WEB_BUILD_ONLY',
          'sourceBaseAtCopy': source_base, 'originalInputs': before, 'operations': [],
          'runtime': 'NOT_RUN', 'productionAdmission': False}


def save():
    (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')


save()
for label, command in [('dependencies', ['npm', 'ci', '--offline', '--no-audit', '--no-fund']),
                       ('build', ['npm', 'run', 'build'])]:
    started = time.monotonic()
    child = subprocess.Popen(command, cwd=OUT / 'web', stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = child.communicate(timeout=300)
    (OUT / (label + '.stdout.log')).write_bytes(stdout)
    (OUT / (label + '.stderr.log')).write_bytes(stderr)
    report['operations'].append({'label': label, 'argv': command, 'actualExit': child.returncode,
                                 'originalParentReaped': child.poll() is not None,
                                 'seconds': time.monotonic() - started})
    if child.returncode != 0:
        report['status'] = 'FAIL_RETAIN_ORIGINALS'
        save()
        raise SystemExit(child.returncode)
    save()
after = [fact(WORK / name, name) for name in names]
assert before == after
dist = OUT / 'web/dist'
report['outputs'] = [fact(path, str(path.relative_to(dist))) for path in sorted(dist.rglob('*')) if path.is_file()]
report['generatedLicense'] = fact(OUT / 'web/THIRD-PARTY-NOTICES.txt', 'THIRD-PARTY-NOTICES.txt')
report['originalWorktreeInputsUnchanged'] = True
report['status'] = 'PASS_OWNED_WEB_BUILD_ONLY_NOT_PRODUCT_MSI_RUNTIME'
save()
print(json.dumps({'status': report['status'], 'outputCount': len(report['outputs']),
                  'report': str(OUT / 'report.json')}))
