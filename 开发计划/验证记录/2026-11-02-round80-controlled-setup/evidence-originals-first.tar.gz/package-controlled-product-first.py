"""Root-only invocation of the frozen DEV packager, with captured real exit."""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import time

ROOT = Path('/tmp/fc-round80-controlled-repair')
WORK = ROOT / 'checkout-52d6392-first'
PRODUCER = ROOT / 'controlled-product-producer-first'
TOOLS = ROOT / 'inner-guard-probe-tools-first'
RECEIPT = ROOT / 'root-controlled-product-package-first.json'

assert (ROOT / '.owner').read_bytes() == b'future-classroom-owned-r80-controlled-repair/v1\n'
assert not RECEIPT.exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == 'c50882df40b86248e3e2d4e404d0fbe8e43e30a9'
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=WORK) == b''

def fact(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

evidence = PRODUCER / 'evidence.json'
assert json.loads(evidence.read_text())['status'] == 'DEV_FROZEN_NORMAL_BUILD_ONLY'
web = ROOT / 'controlled-web-first/report.json'
assert fact(web)['sha256'] == '706673da7a6ee05299b04f76b0cfe14329d5842417740bd2be0c4430ae0da41c'
tools = json.loads((TOOLS / 'tools.json').read_text())
for key, row in tools.items():
    assert fact(Path(row['path']))['sha256'] == row['sha256'], key
environment = json.loads((TOOLS / 'child-environment.json').read_text())
assert set(environment) == {'LD_LIBRARY_PATH', 'LC_ALL', 'GIO_USE_VFS', 'GSETTINGS_BACKEND'}
assert environment['LD_LIBRARY_PATH'] == str(TOOLS / 'root/usr/lib/x86_64-linux-gnu')
env = os.environ.copy()
env.update(environment)
argv = ['python3', '-B', str(WORK / 'scripts/package-controlled-dev.py'), '--execute',
        '--source-root', str(WORK), '--evidence', str(evidence), '--evidence-sha256', fact(evidence)['sha256'],
        '--web-report', str(web), '--web-report-sha256', fact(web)['sha256'],
        '--web-dist', str(ROOT / 'controlled-web-first/web/dist'),
        '--input-dir', str(ROOT / 'controlled-product-input-first'),
        '--output-dir', str(ROOT / 'controlled-product-package-first')]
for key in ('wixl', 'msibuild', 'msiinfo', 'msiextract', 'objdump'):
    argv += ['--' + key, tools[key]['path']]
argv += ['--msibuild-sha256', tools['msibuild']['sha256']]
started = time.monotonic()
process = subprocess.Popen(argv, cwd=WORK, env=env, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, start_new_session=True)
timed_out = False
try:
    stdout, stderr = process.communicate(timeout=300)
except subprocess.TimeoutExpired:
    timed_out = True
    os.killpg(process.pid, signal.SIGTERM)
    try:
        stdout, stderr = process.communicate(timeout=10)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        stdout, stderr = process.communicate()
out = ROOT / 'root-controlled-product-package-first.stdout.log'
err = ROOT / 'root-controlled-product-package-first.stderr.log'
out.write_bytes(stdout)
err.write_bytes(stderr)
report = {'status': 'PASS_STATIC_PACKAGE_ONLY_NOT_PRODUCT_RUNTIME' if process.returncode == 0 and not timed_out else 'FAIL_RETAIN_ORIGINALS',
          'actual_exit': process.returncode, 'parent_reaped': process.poll() is not None,
          'timed_out': timed_out, 'seconds': time.monotonic() - started,
          'original_budget_seconds': 300, 'argv': argv, 'environment': environment,
          'evidence': fact(evidence), 'web_report': fact(web),
          'producer_script': fact(Path(__file__)), 'stdout': fact(out), 'stderr': fact(err)}
package = ROOT / 'controlled-product-package-first/report.json'
if package.exists():
    report['package_report'] = fact(package)
RECEIPT.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report), flush=True)
raise SystemExit(0 if process.returncode == 0 and not timed_out else 1)
