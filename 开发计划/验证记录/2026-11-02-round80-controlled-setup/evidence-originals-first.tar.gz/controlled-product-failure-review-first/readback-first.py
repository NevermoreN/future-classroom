#!/usr/bin/env python3
"""Finite readback of the already downloaded failed product run. No Windows or source writes."""
from pathlib import Path
import hashlib,json,re
R=Path('/tmp/fc-round80-controlled-repair');D=R/'controlled-product-failure-review-first';O=R/'controlled-product-runtime-first'
REPORT_SHA='5ef468302208d1061aa6e9f197686017af66b90c7890ea703646feee207a66ab'
def sha(b):return hashlib.sha256(b).hexdigest()
def raw(j):return (json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode()
def identity(p):
 assert p.is_file() and not p.is_symlink() and p.resolve()==p
 b=p.read_bytes();return {'path':str(p.relative_to(R)),'bytes':len(b),'sha256':sha(b)}
def singleton(v):
 if isinstance(v,dict):return [v]
 assert isinstance(v,list) and len(v)==1 and isinstance(v[0],dict)
 return v
report=O/'report.json';b=report.read_bytes();assert sha(b)==REPORT_SHA;j=json.loads(b);phase=j['phase']
root=O/'download'/j['windowsRoot'].replace('\\','/').rsplit('/',1)[-1]
expected=j['inventory'];actual=[];dirs=[]
for p in sorted(root.rglob('*')):
 assert not p.is_symlink()
 if p.is_dir():dirs.append(p.relative_to(root).as_posix())
 else:
  data=p.read_bytes();actual.append({'path':p.relative_to(root).as_posix(),'bytes':len(data),'sha256':sha(data)})
assert len(actual)==31 and {x['path']:(x['bytes'],x['sha256']) for x in actual}=={x['path']:(x['bytes'],x['sha256']) for x in expected['files']} and set(dirs)==set(expected['directories'])
assert json.loads((root/'product-result.json').read_bytes())==phase and j['downloadVerified']
outer_path=R/'root-controlled-product-runtime-operation-first.json';outer=json.loads(outer_path.read_bytes());assert outer['actualExit']==1 and outer['originalParentReaped']
ops=[]
for op in j['operations']:
 assert op['originalLocalParentReaped'] and not op['remoteReturnUnknown']
 for key in ('stdout','stderr'):
  row=op[key];p=O/row['path'];data=p.read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256']
 ops.append({'label':op['label'],'actualExit':op['actualExit'],'originalLocalParentReaped':True})
assert next(x for x in ops if x['label']=='03-three-phase')['actualExit']==0
facts=[];excerpts=[]
for p in phase['phases']:
 direct=singleton(p['directOriginalFinal']);obs=p['observerFinal'];assert len(direct)==1
 allreturned=all(x['Wait']==0 and x['ExitKnown'] and x['CheckedClose'] and x['CloseAttempted'] and x['Status']=='HELD_ORIGINAL_IDENTITY' for x in direct)
 observed=obs['Processes'];allreturned=allreturned and obs['Closed'] and not obs['Errors'] and all(x['ActualWait']==0 and x['ActualExitCode'] is not None and x['ExitStatus']=='ACTUAL_ORIGINAL_GET_EXIT_CODE' and x['CloseStatus']=='CHECKED_CLOSE_SUCCESS' for x in observed)
 assert allreturned and all(x['Attempted'] and x['Success'] and not x['Unknown'] for x in p['directNativeCloses'])
 gs=[x for x in observed if x['Role']=='owned-guardian'];assert len(gs)==1
 rows=[]
 for logrow in p['msiLogs']['files']:
  local=root/Path(logrow['path'].replace('\\','/')).parent.name/Path(logrow['path'].replace('\\','/')).name
  data=local.read_bytes();assert len(data)==logrow['bytes'] and sha(data)==logrow['sha256'];text=data.decode('utf-16') if data.startswith((b'\xff\xfe',b'\xfe\xff')) else data.decode('utf-8-sig')
  selected=[]
  for i,line in enumerate(text.splitlines()):
   if re.search(r'(?:Action (?:start|ended)[^\r\n]*(?:FcControlledInnerGuard|InstallFinalize)|MainEngineThread is returning [0-9]+|Removal success or error status: [0-9]+|Installation success or error status: [0-9]+|User cancel requested)',line):
    assert len(line)<=2048 and not any(ord(c)<32 and c!='\t' for c in line);selected.append({'line':i+1,'text':line})
  returns=[int(x) for x in re.findall(r'MainEngineThread is returning ([0-9]+)',text)]
  rows.append({'log':identity(local),'mainEngineThreadReturnCodes':returns,'guardActionSucceededField':p['msiLogs']['guardActionNameObserved']});excerpts.append({'phase':p['name'],'log':identity(local),'selectedLines':selected})
 facts.append({'name':p['name'],'clientExit':p['client']['exitCode'],'clientOriginal':{'pid':direct[0]['Pid'],'creation':direct[0]['Creation'],'wait':direct[0]['Wait'],'exitKnown':direct[0]['ExitKnown'],'exitCode':direct[0]['ExitCode'],'checkedClose':direct[0]['CheckedClose']},'guardianOriginal':{'pid':gs[0]['Pid'],'creation':gs[0]['CreationFiletime'],'wait':gs[0]['ActualWait'],'exitCode':gs[0]['ActualExitCode'],'checkedClose':gs[0]['CloseStatus']},'allObservedOriginalControlsPhysicallyReturned':allreturned,'businessExitZero':p['client']['exitCode']==0,'originalKnownControlsReturnedLabel':p['knownControlsReturned'],'originalCapturedObjectsReturnedLabel':p['capturedObjectsReturned'],'directOriginalFinalRawShape':type(p['directOriginalFinal']).__name__,'logs':rows,'postPhaseProcessObservationPresent':'postPhaseProcesses' in p})
assert [x['clientExit'] for x in facts]==[0,0,1603]
health={}
for key in ('installed','damaged','repaired','finallyProduct'):
 v=phase[key];files=v['observations']['files']['files'];health[key]={'healthyPresent':v['healthyPresent'],'runAbsent':v['runAbsent'],'fileCount':len(files),'allObservedFilesExact':all(x['status']=='EXACT' for x in files),'paths':[x['path'] for x in files]}
findings=[{'id':'CTRL-EXIT-PROPAGATION','kind':'observed telemetry defect','evidence':'Invoke-ControlledProduct.ps1 ends exit1 on failure, but nested invocation and BOOT do not explicitly propagate LASTEXITCODE; actual03 outer PowerShell0, raw phase FAIL. Python still returned1 and retained scratch.','minimalFutureCorrection':'In a new preparation only, explicitly propagate nested script LASTEXITCODE through both invocation and BOOT. No old receipt rewrite.','doesNotExplain':'Actual MSI1602 or Setup/G1603; those remain product/native failure.'},{'id':'CTRL-KNOWN-NONZERO-RETURN','kind':'physical return and native success conflated','evidence':'All three original direct clients plus captured G objects were signaled and checked closed; uninstall actual known1603 nevertheless sets capturedObjectsReturned=false, knownControlsReturned=false and ownerUnknown=true.','minimalFutureCorrection':'Separate physicalReturnKnown and businessExitZero; keep nonzero failure and retained Pending/settlement status. Return-known does not mean transaction settled.','doesNotAuthorize':'No clearing Pending, retirement, new Install, synthetic End, or retry permission.'},{'id':'CTRL-SINGLETON-SHAPE','kind':'latent false rejection on full-success path','evidence':'All three actual directOriginalFinal raw values are JSON objects, not arrays, due PowerShell single-element pipeline enumeration; Python phase_returned accepts only list length1. Current first/second successful phases therefore would fail full-success cleanup classifier.','minimalFutureCorrection':'Emit a fixed array in new PowerShell preparation and accept exactly one object or one-element list for this named legacy field; never relax cardinality or native cap checks.','effect':'Safe retention false-negative, not an unsafe cleanup or product cancellation cause.'}]
result={'status':'FROZEN_FINITE_READBACK_ORIGINAL_PRODUCT_FAIL_RETAINED','originalReport':identity(report),'outerOriginal':identity(outer_path),'outerActualExit':outer['actualExit'],'outerSeconds':outer['seconds'],'completeDownloadedFiles':31,'completeDownloadIdentityReadback':True,'operations':ops,'phaseFacts':facts,'healthSnapshots':health,'originalFailure':{'status':phase['status'],'failureCode':phase['failureCode'],'ownerUnknown':phase['ownerUnknown'],'instrumentUnknown':phase['instrumentUnknown'],'cleanup':phase['cleanup']},'pendingObservation':phase['finallyCoordination'],'controllerFindings':findings,'currentLiveObservation':'NOT_PERFORMED; root reports no active test process, but no new Windows query is made or synthesized here.','settlementAuthority':'NONE. Physical process return, healthy14 state and log return1602 do not settle retained Pending. Original session remains FAIL.','futureIndependentCleanupFactsNeeded':['A current, exact, authorized native admission/read-only recovery result for retained Pending is not present in this31-file snapshot. Without it no product/gate cleanup authority follows.','Current product/14files/marker/Run/registration, actual LocalPackage/source identities and exact own-process absence must be independently established for any future bounded operation. These old snapshots are evidence, not live permission.','Any independent test teardown must have a separate explicit contract protecting real data and retaining original FAIL; it must not pretend native End, remove guard or edit Pending/cache/registry by hand. This report grants no such route.'],'actions':{'WindowsContacted':False,'originalsChanged':False,'worktreeReadOrWritten':False,'pendingOrGateMutated':False,'cleanupExecuted':False}}
(D/'download-readback-first.json').write_bytes(raw({'status':'PASS_EXACT_31_DOWNLOADED_ORIGINALS_READBACK','report':identity(report),'files':actual,'directories':dirs,'phaseResultEqualsOriginalStdout':True}))
(D/'log-excerpts-first.json').write_bytes(raw({'status':'EXACT_BOUNDED_DECODED_LOG_EXCERPTS_NOT_NEW_RUNTIME','logs':excerpts}))
(D/'review-first.json').write_bytes(raw(result))
print(json.dumps({'status':result['status'],'downloadFiles':31,'findings':3,'reviewSha256':sha((D/'review-first.json').read_bytes()),'rawOriginalUnchanged':sha(report.read_bytes())==REPORT_SHA,'WindowsContacted':False}))
