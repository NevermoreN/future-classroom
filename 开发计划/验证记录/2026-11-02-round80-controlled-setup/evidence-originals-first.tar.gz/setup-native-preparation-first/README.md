默认只输出 NOT_RUN。仅 root 可在真实 Windows PS AST 检查后执行：

    python3 /tmp/fc-round80-controlled-repair/setup-native-preparation-first/run-native.py --execute --producer FINAL_REPORT --producer-sha256 EXACT_SHA --inventory FINAL_INVENTORY --inventory-sha256 EXACT_SHA

准入要求最终实际 GNU fc-windows test --no-run 报告 PASS、原编译父进程已归还、前后460项Rust/Cargo输入一致、sourceBase d2dd16bb25ce5d9a8b7e61546a167a1dd61e5e96、唯一同源普通测试EXE字节与SHA和compiler-artifact闭合。当前全部源码测试名65且唯一，controlled6已包含在65里。

只核Rust/Cargo编译闭包与控制器/固定原进程捕获fixture，不以整个Git dirty清单或独立Python/CI文件限制并发开发；本范围不验证Python/CI、包来源或实际Setup/Type1 MSI桥，不能据此放行MSI。原进程对象Wait/GetExit/checkedClose、嵌套harness资格、完整下载字节核对和精确自有scratch清理保留。预算保持150/300/600/900秒。新namespace r80-setup-native，输出setup-native-runtime-first；未知原件保留。

本准备仅纯样本和静态检查通过，最终producer参数在执行时核验；未执行Windows、SSH或Cargo。Win7/Win10实际NOT_RUN，生产MSI桥NOT_EXERCISED。
