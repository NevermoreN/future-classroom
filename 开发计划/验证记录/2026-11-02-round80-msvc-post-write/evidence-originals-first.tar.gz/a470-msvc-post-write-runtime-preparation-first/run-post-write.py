#!/usr/bin/env python3
"""Default-inert, root-only transport for official MSVC product plus GNU diagnostic-witness post-write five-Setup rollback test."""
from pathlib import Path
import argparse,base64,hashlib,json,math,re,shutil,subprocess,time,uuid
R=Path('/tmp/fc-round80-controlled-repair');P=R/'a470-msvc-post-write-runtime-preparation-first';S=P/'sources'
HOST='future-classroom-win11';OWNER='future-classroom-owned-r80-a470-msvc-post-write-runtime/v1\n'
SOURCE_NAMES=['Capture.cs','GateRetirement.cs','ProcessObserver.cs','ProductState.cs','ProductState.ps1','ReadOnlyPreflightFunction.ps1','Invoke-ControlledProduct.ps1','PostWriteDamage.cs']
BOOT="[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()));$ok=$?;$code=Get-Variable -Name LASTEXITCODE -ErrorAction SilentlyContinue;if($null-ne$code){exit ([int]$code.Value)};if($ok){exit 0};exit 1"
COMMON=r'''$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Need([bool]$v,[string]$code){if(-not$v){throw $code}}
function Fact([string]$p){$f=Get-Item -LiteralPath $p -Force;Need (-not$f.PSIsContainer -and ($f.Attributes-band1024)-eq0) 'REGULAR_NO_REPARSE';return @{bytes=[long]$f.Length;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function RootPath {return Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) ('Temp\FutureClassroom-r80-a470-msvc-post-write-'+$c.nonce)}
function CheckRoot([string]$root){Need ($root-ceq$c.root -and $root-ceq(RootPath)) 'EXACT_NONCE_ROOT';$a=[IO.File]::GetAttributes($root);Need (($a-band1024)-eq0 -and ($a-band16)-ne0) 'REGULAR_ROOT';Need ([IO.File]::ReadAllText((Join-Path $root '.owner'))-ceq"future-classroom-owned-r80-a470-msvc-post-write-runtime/v1`n") 'OWNER';$acl=[IO.Directory]::GetAccessControl($root);Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq$c.sid) 'PROTECTED_ROOT_OWNER';$rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($rules.Count-eq2 -and @($rules|Where-Object{$_.IdentityReference.Value-cnotin@($c.sid,'S-1-5-18') -or $_.AccessControlType-ne'Allow' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count-eq0) 'ONLY_USER_SYSTEM_DACL'}
function Inventory([string]$root){CheckRoot $root;$files=@();$dirs=@();$q=[Collections.Generic.Queue[string]]::new();$q.Enqueue($root);while($q.Count){$dir=$q.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){$a=[IO.File]::GetAttributes($p);Need (($a-band1024)-eq0) 'NO_INVENTORY_REPARSE';$rel=$p.Substring($root.Length+1).Replace('\','/');if(($a-band16)-ne0){$dirs+=$rel;$q.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256}};Need ($files.Count-le256 -and $dirs.Count-le32) 'INVENTORY_BOUNDS'}};return @{files=$files;directories=$dirs}}
'''
CREATE=r'''$start=[Diagnostics.Stopwatch]::GetTimestamp();$frequency=[Diagnostics.Stopwatch]::Frequency
Need ($PSVersionTable.PSVersion.Major-eq5 -and $PSVersionTable.PSVersion.Minor-eq1 -and [IntPtr]::Size-eq8) 'PS51_X64'
$who=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$who.User;Need ($sid.Value-ceq$c.sid) 'CURRENT_SID'}finally{$who.Dispose()}
$before=Measure-FcBeforePreflight -Config $c.plan;Need ($before.status-ceq'PASS_BEFORE_KNOWN_ABSENCE_ONLY_NOT_EXECUTION_ADMISSION') 'ALL_KNOWN_ABSENT_BEFORE_ROOT'
$root=RootPath;try{[void][IO.File]::GetAttributes($root);throw 'ROOT_ALREADY_PRESENT'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
$cursor=[IO.Path]::GetDirectoryName($root);while($cursor){$a=[IO.File]::GetAttributes($cursor);Need (($a-band1024)-eq0 -and ($a-band16)-ne0) 'ORIGINAL_NONREPARSE_ANCESTORS';$cursor=[IO.Path]::GetDirectoryName($cursor)}
[void][IO.Directory]::CreateDirectory($root);$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false);foreach($s in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($s,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))};[IO.Directory]::SetAccessControl($root,$acl);[IO.File]::WriteAllText((Join-Path $root '.owner'),"future-classroom-owned-r80-a470-msvc-post-write-runtime/v1`n",[Text.UTF8Encoding]::new($false));$c.root=$root;CheckRoot $root
@{status='CREATED_ONLY_OWNED_GNU_DEV_PRODUCT_RUNTIME_ROOT';root=$root;sid=$c.sid;nonce=$c.nonce;before=$before;originalStartQpc=$start;originalFrequency=$frequency}|ConvertTo-Json -Depth 18 -Compress
'''
INVOKE=r'''CheckRoot $c.root
& (Join-Path $c.root 'Invoke-ControlledProduct.ps1') -Execute -ScratchRoot $c.root -ExpectedConfigSha256 $c.configSha256 -ExpectedInputsManifestSha256 $c.inputsSha256 -OriginalStartQpc $c.startQpc -OriginalFrequency $c.frequency
$code=Get-Variable -Name LASTEXITCODE -ErrorAction SilentlyContinue;Need ($null-ne$code) 'NESTED_RUNNER_EXIT_CODE_REQUIRED';exit ([int]$code.Value)
'''
INVENTORY=r'''CheckRoot $c.root;Inventory $c.root|ConvertTo-Json -Depth 12 -Compress'''
DELETE=r'''CheckRoot $c.root;$now=Inventory $c.root;Need ($now.files.Count-eq$c.inventory.files.Count -and $now.directories.Count-eq$c.inventory.directories.Count) 'EXACT_DOWNLOADED_MEMBERSHIP';foreach($row in $now.files){$old=@($c.inventory.files|Where-Object{$_.path-ceq$row.path});Need ($old.Count-eq1 -and $old[0].bytes-eq$row.bytes -and $old[0].sha256-ceq$row.sha256) 'ALL_DOWNLOADED_BYTES_STILL_EXACT'};foreach($dir in $now.directories){Need ($dir-cin$c.inventory.directories) 'EXACT_DIRECTORY_SET'}
foreach($row in $now.files){if($row.path-cne'.owner'){[IO.File]::Delete((Join-Path $c.root ($row.path.Replace('/','\'))))}};foreach($dir in @($now.directories|Sort-Object Length -Descending)){[IO.Directory]::Delete((Join-Path $c.root ($dir.Replace('/','\'))),$false)};[IO.File]::Delete((Join-Path $c.root '.owner'));[IO.Directory]::Delete($c.root,$false)
try{[void][IO.File]::GetAttributes($c.root);throw 'ROOT_STILL_PRESENT'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
@{status='REMOVED_EXACT_DOWNLOADED_GNU_DEV_PRODUCT_ROOT';knownAbsent=$true;nonce=$c.nonce}|ConvertTo-Json -Compress
'''
def need(v,m):
 if not v:raise AssertionError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def rawjson(j):return (json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode()
def fact(p):
 p=Path(p);need(p.is_absolute() and p.resolve()==p and p.is_relative_to(R) and p.is_file() and not p.is_symlink(),'EXACT_R80_REGULAR_INPUT')
 need(not any(x in p.parts for x in ('checkout-52d6392-first','target-first','target','deps','__pycache__')),'NO_ACTIVE_SOURCE_OR_TARGET_READ')
 b=p.read_bytes();need(len(b)<=96*1024*1024,'BOUNDED_ROOT_INPUT');return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def bind(artifact_path,artifact_sha,source_path,source_sha):
 af=fact(artifact_path);sf=fact(source_path);need(af['sha256']==artifact_sha and sf['sha256']==source_sha,'EXPLICIT_SOURCE_ARTIFACT_SHA')
 c=json.loads(Path(artifact_path).read_bytes());source=json.loads(Path(source_path).read_bytes())
 need(c['status']=='BOUND_MSVC_WIN7_TARGET_CONTROLLED_PRODUCT_INPUTS_NOT_RELEASE' and c['target']=='i686-win7-windows-msvc' and c['family']=='99378807-098D-5F04-8D4D-F181DFA218D5','CLOSED_OFFICIAL_MSVC_PRODUCT_SCOPE')
 need(re.fullmatch('[0-9a-f]{40}',c['sourceGit']) and re.fullmatch(r'\{[0-9A-F]{8}(?:-[0-9A-F]{4}){3}-[0-9A-F]{12}\}',c['productCode']) and re.fullmatch(r'S-1-5-21-(?:[0-9]+-){3}[0-9]+',c['expectedUserSid']),'EXACT_TYPED_SOURCE_PRODUCT_USER')
 need(c['guardAction']=='FcControlledInnerGuard','ROOT_BOUND_ACTUAL_GUARD_ACTION')
 need(isinstance(source,dict) and set(source)=={'sourceBase','sources'} and source['sourceBase']==c['sourceGit'] and isinstance(source['sources'],list) and 0<len(source['sources'])<=1024,'EXACT_SOURCE_MANIFEST_SCHEMA')
 source_seen=set();source_total=0
 for row in source['sources']:
  need(isinstance(row,dict) and set(row)=={'path','bytes','sha256'},'EXACT_SOURCE_ROW');name=row['path'];need(isinstance(name,str) and 0<len(name)<=512 and ':' not in name and '\\' not in name and not name.startswith('/') and all(v not in ('','.','..') for v in name.split('/')) and name not in source_seen and not any(ord(v)<32 for v in name),'CANONICAL_SOURCE_ROW');source_seen.add(name);need(type(row['bytes']) is int and 0<=row['bytes']<=16*1024*1024 and re.fullmatch('[0-9a-f]{64}',row['sha256']),'SOURCE_ROW_IDENTITY');source_total+=row['bytes']
 need(source_total<=256*1024*1024,'SOURCE_MANIFEST_TOTAL_BOUND')
 need(c['sourceManifest']['bytes']==sf['bytes'] and c['sourceManifest']['sha256']==sf['sha256'],'ARTIFACT_BINDS_EXACT_SOURCE_MANIFEST')
 need(isinstance(c['payloads'],list) and len(c['payloads'])==14,'EXACT_FOURTEEN_PAYLOADS');names=set();components=set();total=0
 for row in c['payloads']:
  p=row['path'];need(isinstance(p,str) and p and p not in names and '\\' not in p and ':' not in p and not p.startswith('/') and all(x not in ('','.','..') for x in p.split('/')),'CLOSED_PAYLOAD_RELATIVE');names.add(p)
  need(type(row['size']) is int and 0<=row['size']<=30*1024*1024 and re.fullmatch('[0-9a-f]{64}',row['sha256']),'PAYLOAD_SIZE_SHA');total+=row['size'];g=row['component_guid'];need(re.fullmatch(r'[0-9A-F]{8}(?:-[0-9A-F]{4}){3}-[0-9A-F]{12}',g) and g not in components,'EXACT_COMPONENT_GUID');components.add(g)
 need(total<=30*1024*1024 and 'LICENSE' in names,'ORIGINAL_TOTAL_AND_LICENSE')
 for key in ('setup','msi'):
  got=fact(c[key]['path']);need(got['bytes']==c[key]['bytes'] and got['sha256']==c[key]['sha256'] and got['bytes']>0,'EXACT_FINAL_'+key.upper())
 need(c['sourceGit']=='a4702b56bff66da5f5cbe74551d8751eb33fa520' and c['packageReport']['sha256']=='f6b5265bf94dd0b88cd493a6a731a82cfe297cd991e7505d5ca5b811099eb6e5','FIXED_OFFICIAL_A470_MSVC_CANONICAL')
 need(artifact_sha=='5c3048fe132543abbf6ed1da57f1e60d76d758583951fb1be10fe5dbe91776aa' and source_sha=='837191c4c731aadc96f185dc1a4a34957d5d7d6499b52d580549b0394695f3a1','FIXED_OFFICIAL_MSVC_BINDINGS')
 mi_path=R/'a470-msvc-product-input-first/manifest.json';need(fact(mi_path)['sha256']=='60821498b9899c15efc9197835d6cd690de532ef93808df0c015355960f657eb','FIXED_618_RAW_SOURCE_AND_NORMAL_MSVC_PROVENANCE')
 mi=json.loads(mi_path.read_bytes());need(source['sources']==mi['sourceRawInventory'] and len(source['sources'])==618 and all(row['compilerArtifact']['profile']['test'] is False and row['compilerArtifact']['features']==['default'] for row in mi['normalArtifacts']),'ALL_CI_RAW_INPUTS_AND_NORMAL_NONTEST_DEFAULT')
 for row in mi['sourceRawInventory']:
  data=(Path(mi['sourceRoot'])/row['path']).read_bytes();need(len(data)==row['bytes'] and sha(data)==row['sha256'],'EXACT_CURRENT_MATERIALIZED_RAW_SOURCE')
 canonical=json.loads(Path(c['packageReport']['path']).read_bytes());need(fact(c['packageReport']['path'])==c['packageReport'] and canonical['status']=='PASS' and canonical['controlled_inner'] is True and canonical['development_fixture_only'] is False and canonical['target']=='i686-win7-windows-msvc' and canonical['payloads']==c['payloads'],'EXACT_OFFICIAL_CANONICAL_PRODUCT')
 derivation=R/'a470-msvc-post-write-package-first/derivation-report.json';review=R/'a470-msvc-post-write-operation-first/static-review.json'
 need(fact(derivation)['sha256']=='3dd79dd9438c7f800ad647d5c411e49ae9f622b57f39212449fb7b6ab93aeb50' and fact(review)['sha256']=='ac3094856828fbc87e3c50a51d1cc82ae34b073e9c2b8c53a1171529c54d2cb3','ACTUAL_FIXED_A470_DERIVATION_AND_STATIC_DELTA')
 staticfreeze=R/'a470-msvc-post-write-operation-first/freeze-first.json';need(fact(staticfreeze)['sha256']=='77db14b607d29017bd0b89ae559c19e8204fe779e6656b5481857ebff5bf6227','FROZEN_ALL_ACTUAL85_TOOL_OUTPUTS')
 for row in json.loads(staticfreeze.read_bytes())['files']:need(fact(row['path'])==row,'UNCHANGED_ACTUAL_DERIVATION_SOURCE_LOGS_AND_OUTPUTS')
 d=json.loads(derivation.read_bytes());v=json.loads(review.read_bytes())
 need(d['status']=='PASS_DEV_POST_WRITE_FIXTURE_DERIVATION_ONLY_NOT_RUNTIME_OR_FORMAL_CONTRACT' and d['canonical_report_sha256']==c['packageReport']['sha256'] and d['payloads_unchanged']==14 and d['canonical_unchanged'] is True and d['summary_unchanged'] is True and d['guard_type1_1499_condition1_unchanged'] is True and len(d['commands'])==85 and all(x['actual_exit']==0 and x['parent_reaped'] is True and x['timed_out'] is False for x in d['commands']),'ACTUAL_EXACT85_DERIVATION_CLOSURE')
 need(d['canonical_product_source']['sourceSha']==c['sourceGit'] and d['canonical_product_source']['target']==c['target'] and d['auxiliary_witness_source']=='DEDICATED_GNU_C_DIAGNOSTIC_DLL_ONLY_NOT_PRODUCT_OR_PERMISSION','SEPARATE_MSVC_PRODUCT_AND_GNU_TEST_WITNESS')
 c['forced']={'setup':v['setup'],'msi':v['msi'],'derivationReport':fact(derivation),'staticReview':fact(review),'sameOriginalTemplateAndPayloads':True,'samePackageCodeDiagnosticFixtureOnly':True}
 for key in ('setup','msi'):
  got=fact(c['forced'][key]['path']);need(got==c['forced'][key] and got['sha256']==d[key]['sha256'] and got['bytes']==d[key]['bytes'],'FINAL_FORCED_BUNDLE_BYTES')
 c['nativeTerminalEvidencePolicy']='FIXED_SOURCE_G0_AND_PENDING_ABSENCE_INFERENCE_NOT_DIRECT_BEGIN_END_RETURN'
 c.update(registryMarkerKey='Software\\FutureClassroom\\Installer\\Components',runKey='Software\\Microsoft\\Windows\\CurrentVersion\\Run',runValue='FutureClassroom',registryView='Registry32',fixedDestinationKnownFolderSuffix=['Programs','FutureClassroom'])
 return c,af,sf

def remote(script,c):
 feed=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;\n"+COMMON+script).encode()
 command='powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand '+base64.b64encode(BOOT.encode('utf-16-le')).decode()
 return ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8',HOST,command],feed

def validate_inventory(j):
 need(isinstance(j,dict) and isinstance(j['files'],list) and isinstance(j['directories'],list) and len(j['files'])<=256 and len(j['directories'])<=32,'FINITE_INVENTORY');need(sum(x['bytes'] for x in j['files'])<=256*1024*1024,'FINITE_TOTAL_CAPTURE_BYTES')
 seen=set()
 for row in j['files']:
  p=row['path'];need(isinstance(p,str) and p and ':' not in p and '\\' not in p and not p.startswith('/') and all(x not in ('','.','..') for x in p.split('/')) and p not in seen,'SAFE_INVENTORY_FILE');seen.add(p);need(type(row['bytes']) is int and 0<=row['bytes']<=96*1024*1024 and re.fullmatch('[0-9a-f]{64}',row['sha256']),'INVENTORY_IDENTITY')
 for p in j['directories']:need(isinstance(p,str) and p and ':' not in p and '\\' not in p and not p.startswith('/') and all(x not in ('','.','..') for x in p.split('/')) and p not in seen,'SAFE_INVENTORY_DIR');seen.add(p)

def phase_returned(x,expected,plan):
 if not isinstance(x,dict):return False
 client=x.get('client',{});raw=x.get('directOriginalFinal',[]);caps=[raw] if isinstance(raw,dict) else raw;obs=x.get('observerFinal',{});bundle=plan.get('forced') if x.get('bundle')=='forced' else plan
 if not (client.get('started') is True and client.get('actualExit') is True and type(client.get('exitCode')) is int and client['exitCode']==expected and client.get('pipesComplete') is True and client.get('timedOut') is False and x.get('expectedBusinessExitObserved') is True and x.get('knownControlsReturned') is True and isinstance(caps,list) and len(caps)==1 and obs.get('Closed') is True and obs.get('Errors')==[]):return False
 cap=caps[0]
 if not (cap.get('Status')=='HELD_ORIGINAL_IDENTITY' and type(cap.get('Wait')) is int and cap['Wait']==0 and cap.get('ExitKnown') is True and type(cap.get('ExitCode')) is int and cap['ExitCode']==expected and cap.get('CheckedClose') is True and cap.get('CloseAttempted') is True and cap.get('Pid')==client.get('pid') and cap.get('Creation')==client.get('creationFiletime') and cap.get('Sha256')==bundle['setup']['sha256'] and cap.get('Sid')==plan['expectedUserSid']):return False
 facts=obs.get('Processes')
 if not isinstance(facts,list):return False
 guardians=[f for f in facts if f.get('Role')=='owned-guardian']
 if len(guardians)!=1:return False
 g=guardians[0]
 if not (g.get('ParentPid')==client['pid'] and g.get('ParentCreationFiletime')==client['creationFiletime'] and g.get('ParentLink')=='ORIGINAL_SETUP_PARENT_INSTANCE_FACT_NOT_SESSION_AUTHORITY'):return False
 for f in facts:
  role=f.get('Role');actual=0 if role=='owned-guardian' else expected
  if not (role in ('owned-guardian','setup-'+x['verb']) and f.get('IdentityStatus')=='ORIGINAL_QUERY_SYNC_HANDLE_EXACT_IMAGE_BYTES_USER' and type(f.get('ActualWait')) is int and f['ActualWait']==0 and type(f.get('ActualExitCode')) is int and f['ActualExitCode']==actual and f.get('CloseStatus')=='CHECKED_CLOSE_SUCCESS' and f.get('Sha256')==bundle['setup']['sha256'] and f.get('Sid')==plan['expectedUserSid']):return False
 logs=x.get('msiLogs',{})
 return logs.get('guardActionNameObserved') is True and (logs.get('postWriteSequenceObserved') is True if expected==1603 else logs.get('installFinalizeObserved') is True) and x.get('postPhaseProcesses',{}).get('knownZero') is True and x.get('terminalEvidence',{}).get('classification')=='INFERRED_FROM_FIXED_SOURCE_NATIVE_CODE_G0_AND_PENDING_ABSENT_NOT_DIRECT_API_RECEIPT'

def admission(j,plan):
 if not isinstance(j,dict):return False
 phases=j.get('phases',[]);expected=[('forced-fresh-install','install','forced',1603),('canonical-install','install','canonical',0),('forced-damaged-repair','repair','forced',1603),('canonical-final-repair','repair','canonical',0),('canonical-uninstall','uninstall','canonical',0)]
 return j.get('status')=='PASS_MSVC_PRODUCT_GNU_WITNESS_WIN11_DEV_POST_WRITE_FRESH_AND_DAMAGED_ROLLBACK_CANONICAL_CLEANUP' and j.get('cleanup')=='PASS_CANONICAL_UNINSTALL_ORIGINAL_GATE_RETIRED' and j.get('ownerUnknown') is False and j.get('instrumentUnknown') is False and j.get('originalBudgetExceeded') is False and j.get('finallyProduct',{}).get('knownAbsent') is True and j.get('finallyCoordination',{}).get('namespaceKnownAbsent') is True and j.get('finallyCoordination',{}).get('pendingKnownAbsent') is True and j.get('damagedPreimageRestored') is True and j.get('freshRollbackAbsent',{}).get('knownAbsent') is True and j.get('licenseDamage',{}).get('checkedClose') is True and j.get('probeDamage',{}).get('checkedClose') is True and j.get('damagedRollbackProbe',{}).get('checkedClose') is True and j.get('repaired',{}).get('healthyPresent') is True and j.get('uninstalledCache',{}).get('allObservedAbsent') is True and isinstance(phases,list) and len(phases)==5 and all((v.get('name'),v.get('verb'),v.get('bundle'),v.get('expectedBusinessExit'))==e and phase_returned(v,e[3],plan) for v,e in zip(phases,expected))


def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');ap.add_argument('--artifact-manifest');ap.add_argument('--artifact-manifest-sha256');ap.add_argument('--source-manifest');ap.add_argument('--source-manifest-sha256');ap.add_argument('--report');ap.add_argument('--preparation-freeze-sha256');a=ap.parse_args()
 if not a.execute:print(json.dumps({'status':'PREPARED_NOT_EXECUTED','Windows':'NOT_RUN','product':'NOT_RUN'}));return 0
 need(all([a.artifact_manifest,a.artifact_manifest_sha256,a.source_manifest,a.source_manifest_sha256,a.report,a.preparation_freeze_sha256]),'EXPLICIT_FINAL_MANIFESTS_HASHES_AND_REPORT')
 need((R/'.owner').read_bytes()==b'future-classroom-owned-r80-controlled-repair/v1\n' and (P/'.owner').read_bytes()==b'future-classroom-owned-r80-a470-msvc-post-write-preparation/v1\n','LOCAL_OWNERS')
 freeze_path=P/'freeze-first.json';freeze_raw=freeze_path.read_bytes();need(sha(freeze_raw)==a.preparation_freeze_sha256,'ROOT_PINNED_PREPARATION_FREEZE');freeze=json.loads(freeze_raw)
 for row in freeze['files']:
  p=P/row['path'];got=fact(p);need(got['bytes']==row['bytes'] and got['sha256']==row['sha256'],'EXACT_REVIEWED_PREPARATION_SOURCE')
 plan,af,sf=bind(a.artifact_manifest,a.artifact_manifest_sha256,a.source_manifest,a.source_manifest_sha256)
 report=Path(a.report);D=report.parent;need(report.is_absolute() and D.resolve()==D and D.parent==R and not D.exists() and report.name.endswith('.json'),'NEW_RESULT_ROOT')
 D.mkdir();(D/'.owner').write_bytes(b'future-classroom-owned-r80-a470-msvc-post-write-result/v1\n');upload=D/'upload';upload.mkdir();nonce=uuid.uuid4().hex
 for name in SOURCE_NAMES:shutil.copyfile(S/name,upload/name)
 shutil.copyfile(plan['setup']['path'],upload/'canonical-Setup.exe');shutil.copyfile(plan['msi']['path'],upload/'canonical-FutureClassroom.msi');shutil.copyfile(plan['forced']['setup']['path'],upload/'forced-Setup.exe');shutil.copyfile(plan['forced']['msi']['path'],upload/'forced-FutureClassroom.msi');shutil.copyfile(plan['forced']['derivationReport']['path'],upload/'derivation-report.json');shutil.copyfile(plan['forced']['staticReview']['path'],upload/'post-write-static-review.json');shutil.copyfile(a.artifact_manifest,upload/'artifact-manifest.json');shutil.copyfile(a.source_manifest,upload/'source-manifest.json')
 c=dict(plan);c.update(runtimeNonce=nonce,runtimeRootName='FutureClassroom-r80-a470-msvc-post-write-'+nonce,artifactManifestSha256=af['sha256']);configraw=rawjson(c);(upload/'runtime-config.json').write_bytes(configraw)
 inputs={'files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(upload.iterdir())]};inputraw=rawjson(inputs);(upload/'runtime-inputs.json').write_bytes(inputraw)
 start=time.monotonic();ops=[];outcome={'status':'FAIL_OR_UNKNOWN_RETAIN_ORIGINALS','scope':'MSVC_PRODUCT_GNU_WITNESS_WIN11_DEV_POST_WRITE_ROLLBACK_NOT_RELEASE','sourceManifest':sf,'artifactManifest':af,'nonce':nonce,'operations':ops,'runtime':'NOT_RUN','cleanup':'NOT_RUN','sourceDeletion':False};rc=1
 def save():report.write_bytes(rawjson(outcome))
 def call(label,argv,feed=None,maximum=180):
  left=600-(time.monotonic()-start);need(left>0,'ROOT_ORIGINAL_WHOLE_600_EXHAUSTED');budget=min(maximum,left);row={'label':label,'argv':argv,'budgetSeconds':budget,'actualExit':None,'originalLocalParentReaped':False,'remoteReturnUnknown':True};ops.append(row)
  if feed is not None:(D/(label+'.stdin.ps1')).write_bytes(feed)
  with (D/(label+'.stdout.log')).open('xb') as out,(D/(label+'.stderr.log')).open('xb') as err:
   proc=subprocess.Popen(argv,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=out,stderr=err);row['originalLocalPid']=proc.pid
   try:proc.communicate(feed,timeout=budget);row.update(actualExit=proc.returncode,originalLocalParentReaped=True,remoteReturnUnknown=False)
   except subprocess.TimeoutExpired:row['status']='ROOT_TRANSPORT_TIMEOUT_REMOTE_OWNER_UNKNOWN_NO_WINDOWS_KILL';save();raise RuntimeError('ORIGINAL_TRANSPORT_TIMEOUT_RETAIN')
  row['elapsedWholeSeconds']=time.monotonic()-start
  for key in ('stdout','stderr'):
   p=D/(label+'.'+key+'.log');row[key]={'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
  save();return row,(D/(label+'.stdout.log')).read_bytes()
 try:
  transport={'nonce':nonce,'sid':plan['expectedUserSid'],'plan':plan,'root':None}
  args,feed=remote((S/'ReadOnlyPreflightFunction.ps1').read_text()+CREATE,transport);op,b=call('01-create',args,feed,30);need(op['actualExit']==0,'CREATE_ACTUAL0');created=json.loads(b.decode('utf-8-sig'));root=created['root'];transport.update(root=root,startQpc=created['originalStartQpc'],frequency=created['originalFrequency'],configSha256=sha(configraw),inputsSha256=sha(inputraw));outcome['create']=created;outcome['windowsRoot']=root
  scp=['scp','-q','-o','BatchMode=yes']+[str(p) for p in sorted(upload.iterdir())]+[HOST+':'+root.replace('\\','/')+'/'];op,_=call('02-upload',scp,maximum=45);need(op['actualExit']==0,'UPLOAD_ACTUAL0')
  args,feed=remote(INVOKE,transport);op,b=call('03-five-setup-post-write-rollback',args,feed,maximum=600);outcome['runtimeActualExit']=op['actualExit'];outcome['runtime']='ACTUAL_ORIGINAL_PS_RETURNED';phase=json.loads(b.decode('utf-8-sig'));outcome['phase']=phase
  args,feed=remote(INVENTORY,transport);op,b=call('04-inventory',args,feed,30);need(op['actualExit']==0,'INVENTORY_ACTUAL0');inventory=json.loads(b.decode('utf-8-sig'));validate_inventory(inventory);outcome['inventory']=inventory
  download=D/'download';download.mkdir();op,_=call('05-download',['scp','-q','-r','-o','BatchMode=yes',HOST+':'+root.replace('\\','/'),str(download)],maximum=60);need(op['actualExit']==0,'DOWNLOAD_ACTUAL0');local=download/Path(root.replace('\\','/')).name
  got=[];dirs=[]
  for p in local.rglob('*'):
   need(not p.is_symlink(),'DOWNLOADED_NO_LINK');rel=p.relative_to(local).as_posix()
   if p.is_dir():dirs.append(rel)
   else:got.append({'path':rel,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
  need({x['path']:(x['bytes'],x['sha256']) for x in got}=={x['path']:(x['bytes'],x['sha256']) for x in inventory['files']} and set(dirs)==set(inventory['directories']),'COMPLETE_DOWNLOADED_BYTE_REPLAY');outcome['downloadVerified']=True
  need(json.loads((local/'product-result.json').read_bytes())==phase,'ORIGINAL_RESULT_DOWNLOAD_EXACT')
  if op['actualExit']==0 and outcome['runtimeActualExit']==0 and admission(phase,plan):
   transport['inventory']=inventory;args,feed=remote(DELETE,transport);op,b=call('06-delete-downloaded-root',args,feed,30);need(op['actualExit']==0,'EXACT_DELETE_ACTUAL0');deleted=json.loads(b.decode('utf-8-sig'));need(deleted['knownAbsent'],'EXACT_ROOT_ABSENT');outcome['cleanup']=deleted;outcome['status']='PASS_MSVC_PRODUCT_GNU_WITNESS_WIN11_DEV_POST_WRITE_ROLLBACK_CLOSURE_AND_EXACT_SCRATCH_CLEANUP';rc=0
  else:outcome['cleanup']='RETAIN_ORIGINAL_FAILURE_OR_UNKNOWN_NO_SCRATCH_DELETE'
 except Exception as e:outcome['failureType']=type(e).__name__;outcome['failureCode']=str(e) if re.fullmatch('[A-Z0-9_]+',str(e)) else 'LOCAL_TRANSPORT_OR_DECODE_FAILURE_RETAIN'
 finally:outcome['elapsedSeconds']=time.monotonic()-start;outcome['originalWholeBudgetExceeded']=outcome['elapsedSeconds']>=600;save()
 if outcome['originalWholeBudgetExceeded']:rc=1
 print(json.dumps({'status':outcome['status'],'report':str(report),'reportSha256':sha(report.read_bytes()),'cleanup':outcome['cleanup']}));return rc
if __name__=='__main__':raise SystemExit(main())
