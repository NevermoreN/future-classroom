from pathlib import Path
import hashlib,json,re
R=Path("/tmp/fc-round80-controlled-repair")
def need(v,m):
 if not v:raise AssertionError(m)

def sha(b):return hashlib.sha256(b).hexdigest()

def rawjson(j):return (json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode()

def fact(p):
 p=Path(p);need(p.is_absolute() and p.resolve()==p and p.is_relative_to(R) and p.is_file() and not p.is_symlink(),'EXACT_R80_REGULAR_INPUT')
 need(not any(x in p.parts for x in ('checkout-52d6392-first','target-first','target','deps','__pycache__')),'NO_ACTIVE_SOURCE_OR_TARGET_READ')
 b=p.read_bytes();need(len(b)<=96*1024*1024,'BOUNDED_ROOT_INPUT');return {'path':str(p),'bytes':len(b),'sha256':sha(b)}

def validate_inventory(j):
 need(isinstance(j,dict) and isinstance(j['files'],list) and isinstance(j['directories'],list) and len(j['files'])<=256 and len(j['directories'])<=32,'FINITE_INVENTORY');need(sum(x['bytes'] for x in j['files'])<=256*1024*1024,'FINITE_TOTAL_CAPTURE_BYTES')
 seen=set()
 for row in j['files']:
  p=row['path'];need(isinstance(p,str) and p and ':' not in p and '\\' not in p and not p.startswith('/') and all(x not in ('','.','..') for x in p.split('/')) and p not in seen,'SAFE_INVENTORY_FILE');seen.add(p);need(type(row['bytes']) is int and 0<=row['bytes']<=96*1024*1024 and re.fullmatch('[0-9a-f]{64}',row['sha256']),'INVENTORY_IDENTITY')
 for p in j['directories']:need(isinstance(p,str) and p and ':' not in p and '\\' not in p and not p.startswith('/') and all(x not in ('','.','..') for x in p.split('/')) and p not in seen,'SAFE_INVENTORY_DIR');seen.add(p)

def phase_returned(x):
 if not isinstance(x,dict):return False
 client=x.get('client',{});raw_caps=x.get('directOriginalFinal',[]);caps=[raw_caps] if isinstance(raw_caps,dict) else raw_caps;obs=x.get('observerFinal',{})
 if not (isinstance(client,dict) and client.get('started') is True and client.get('actualExit') is True and type(client.get('exitCode')) is int and client['exitCode']==0 and client.get('pipesComplete') is True and client.get('timedOut') is False and x.get('knownControlsReturned') is True and isinstance(caps,list) and len(caps)==1 and isinstance(caps[0],dict) and isinstance(obs,dict) and obs.get('Closed') is True and obs.get('Errors')==[]):return False
 cap=caps[0]
 if not (cap.get('Status')=='HELD_ORIGINAL_IDENTITY' and type(cap.get('Wait')) is int and cap['Wait']==0 and cap.get('ExitKnown') is True and type(cap.get('ExitCode')) is int and cap['ExitCode']==0 and cap.get('CheckedClose') is True and cap.get('CloseAttempted') is True and cap.get('Pid')==client.get('pid') and cap.get('Creation')==client.get('creationFiletime')):return False
 processes=obs.get('Processes')
 if not isinstance(processes,list):return False
 return all(isinstance(f,dict) and f.get('IdentityStatus')=='ORIGINAL_QUERY_SYNC_HANDLE_EXACT_IMAGE_BYTES_USER' and type(f.get('ActualWait')) is int and f['ActualWait']==0 and type(f.get('ActualExitCode')) is int and f['ActualExitCode']==0 and f.get('CloseStatus')=='CHECKED_CLOSE_SUCCESS' for f in processes)
