from pathlib import Path
import ast,copy,json,runpy,subprocess,sys
sys.dont_write_bytecode=True
P=Path('/tmp/fc-round80-controlled-repair/owned-removal-cleanup-preparation-first');ns=runpy.run_path(str(P/'run-owned-removal-cleanup.py'));actual=Path('/tmp/fc-round80-controlled-repair/owned-removal-runtime-first/report.json');j=json.loads(actual.read_bytes());cases=[]
def test(name,fn,want):
 try:v=fn();good=v is not False
 except (AssertionError,KeyError,ValueError,TypeError):good=False
 assert good==want,name;cases.append({'case':name,'expectedAccepted':want,'actualAccepted':good})
test('actual_recovery_metadata_and_full_local_two_nonce_byte_replay',lambda:ns['bind'](str(actual),'a252752d124c4053db9c618135c0b5c2b326ec655e96419de6ac4ac87fc36b2c'),True)
for name,mut in [('status_only_forgery_missing_native',lambda v:v['phase'].pop('nativeAudit')),('known_nonzero_B_not_unknown_or_success',lambda v:v['phase']['phases'][0]['client'].update(exitCode=1603)),('pending_still_present',lambda v:v['phase']['finallyCoordination'].update(pendingKnownAbsent=False)),('product_not_fully_absent',lambda v:v['phase']['finallyProduct'].update(knownAbsent=False)),('old_end_reclassified',lambda v:v.update(oldEnd='SETTLED')),('native_audit_wrong_stage',lambda v:v['phase']['nativeAudit'].update(stage='Removed')),('new_phase_end_not_zero',lambda v:v['phase']['nativeAudit']['phases'][1].update(end=1603)),('original_cap_close_unknown',lambda v:v['phase']['phases'][0]['directOriginalFinal'][0].update(CheckedClose=False)),('transport_03_known_nonzero',lambda v:next(x for x in v['operations'] if x['label']=='03-single-explicit-removal').update(actualExit=1)),('transport_unreaped',lambda v:next(x for x in v['operations'] if x['label']=='03-single-explicit-removal').update(originalLocalParentReaped=False)),('download_not_verified',lambda v:v.update(downloadVerified=False)),('original_budget_expired',lambda v:v.update(originalWholeBudgetExceeded=True)),('false_is_not_exit_zero',lambda v:next(x for x in v['operations'] if x['label']=='03-single-explicit-removal').update(actualExit=False))]:
 v=copy.deepcopy(j);mut(v);test(name,lambda value=v:ns['core_recovery'](value),False)
test('explicit_wrong_report_hash',lambda:ns['bind'](str(actual),'0'*64),False)
bad={'files':[{'path':'../outside','bytes':1,'sha256':'1'*64}],'directories':[]};test('inventory_parent_escape',lambda:ns['validate_inventory'](bad),False)
for p in P.rglob('*.py'):ast.parse(p.read_bytes(),filename=p.name)
r=subprocess.run([sys.executable,'-B',str(P/'run-owned-removal-cleanup.py')],stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert r.returncode==0 and json.loads(r.stdout)['status']=='PREPARED_NOT_EXECUTED';(P/'local-default.stdout.log').write_bytes(r.stdout);(P/'local-default.stderr.log').write_bytes(r.stderr)
print(json.dumps({'status':'PASS_LOCAL_BOUND_CLEANUP_PREPARATION_ONLY','caseCount':len(cases),'cases':cases,'defaultActualExit':r.returncode,'pythonAST':'PASS','Windows':'NOT_RUN','PowerShell51AST':'NOT_RUN_ROOT_ONLY','cleanup':'NOT_RUN','Cargo':'NOT_RUN'}))
