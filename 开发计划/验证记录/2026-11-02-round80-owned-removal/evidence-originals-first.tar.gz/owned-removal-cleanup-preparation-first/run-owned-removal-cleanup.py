#!/usr/bin/env python3
"""Default inert, finite two-nonce and exact empty-gate cleanup after proven removal."""
from pathlib import Path
import argparse,ast,base64,hashlib,json,re,runpy,subprocess,sys,time
sys.dont_write_bytecode=True
R=Path('/tmp/fc-round80-controlled-repair');P=R/'owned-removal-cleanup-preparation-first';S=P/'sources';HOST='future-classroom-win11'
ns=runpy.run_path(str(P/'transport-support.py'));need,sha,fact,rawjson,validate_inventory,phase_returned=[ns[k] for k in ['need','sha','fact','rawjson','validate_inventory','phase_returned']]
ad={ 'phase_returned':phase_returned};exec(compile((P/'recovery-admission.py').read_bytes(),'<frozen-finite-recovery-admission>','exec'),ad);admission=ad['admission']
OLD=R/'controlled-product-runtime-first/report.json';OLD_SHA='5ef468302208d1061aa6e9f197686017af66b90c7890ea703646feee207a66ab';OLD_INV_SHA='3dbdb252b9a6d100bea93f7123de7e86cb8b3948921f39b9cec64befe5c65b17'
BOOT="[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()));$ok=$?;$code=Get-Variable -Name LASTEXITCODE -ErrorAction SilentlyContinue;if($null-ne$code){exit ([int]$code.Value)};if($ok){exit 0};exit 1"
SCRIPT=r'''$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$clock=[Diagnostics.Stopwatch]::StartNew();$result=[ordered]@{status='FAIL_OR_UNKNOWN_RETAIN_REMAINDER';oldEnd='UNKNOWN_UNCHANGED';newRecovery='ROOT_BOUND_ACTUAL_PASS_ALREADY_DOWNLOADED';gateRetirementAttempted=$false;rootsDeleted=@();mutations='ONLY_EXACT_TEST_GATE_AND_TWO_TEST_NONCES';WindowsSSH='PRESERVED';Run='READONLY_ABSENCE_ONLY';systemCache='NO_OPERATIONS'};$ok=$false
function Need([bool]$v,[string]$m){if(-not$v){throw $m}}
function Budget {Need ($clock.ElapsedMilliseconds-lt600000) 'ORIGINAL_600S_BUDGET'}
function Known([string]$p){try{$a=[IO.File]::GetAttributes($p);return @{path=$p;status='KNOWN_PRESENT';directory=(($a-band16)-ne0);reparse=(($a-band1024)-ne0)}}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-is[IO.FileNotFoundException]-or$e-is[IO.DirectoryNotFoundException]){return @{path=$p;status='KNOWN_ABSENT'}};throw}}
function Check-Root($root){Budget;Need ($root.nonce-cmatch'^[0-9a-f]{32}$') 'EXACT_NONCE';$local=[Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData);$leaf=$(if($root.kind-ceq'old'){'FutureClassroom-r80-controlled-product-'}elseif($root.kind-ceq'new'){'FutureClassroom-r80-owned-removal-'}else{throw 'EXACT_OLD_OR_NEW'});Need ($root.path-ceq(Join-Path $local ('Temp\'+$leaf+$root.nonce))) 'EXACT_FIXED_NONCE_KNOWNFOLDER';$cursor=$root.path;while($cursor){$a=[IO.File]::GetAttributes($cursor);Need (($a-band1024)-eq0 -and ($a-band16)-ne0) 'NONREPARSE_DIRECTORY_CHAIN';$cursor=[IO.Path]::GetDirectoryName($cursor)}
 Need ([IO.File]::ReadAllText((Join-Path $root.path '.owner'))-ceq$root.owner) 'ORIGINAL_NONCE_OWNER';$acl=[IO.Directory]::GetAccessControl($root.path);Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq$c.sid) 'PROTECTED_NONCE_USER';$aces=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($aces.Count-eq2 -and @($aces|Where-Object{$_.IdentityReference.Value-cnotin@($c.sid,'S-1-5-18') -or $_.AccessControlType-ne'Allow' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count-eq0) 'ONLY_NONCE_USER_SYSTEM_DACL';Need (@($aces|Where-Object{$_.IdentityReference.Value-ceq$c.sid}).Count-eq1 -and @($aces|Where-Object{$_.IdentityReference.Value-ceq'S-1-5-18'}).Count-eq1) 'EXACT_TWO_DISTINCT_NONCE_TRUSTEES'
}
function Inventory($root){Check-Root $root;$files=@();$dirs=@();$q=[Collections.Generic.Queue[string]]::new();$q.Enqueue($root.path);while($q.Count){Budget;$dir=$q.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){$a=[IO.File]::GetAttributes($p);Need (($a-band1024)-eq0) 'NO_REPARSE_MEMBER';$rel=$p.Substring($root.path.Length+1).Replace('\','/');if(($a-band16)-ne0){$dirs+=$rel;$q.Enqueue($p)}else{$f=Get-Item -LiteralPath $p -Force;Need ($f.Length-le100663296) 'FINITE_FILE';$files+=@{path=$rel;bytes=[long]$f.Length;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}};Need ($files.Count-le256 -and $dirs.Count-le32) 'FINITE_MEMBERS'}};return @{files=$files;directories=$dirs}}
function Exact-Inventory($root){$now=Inventory $root;Need ($now.files.Count-eq$root.inventory.files.Count -and $now.directories.Count-eq$root.inventory.directories.Count) 'EXACT_DOWNLOADED_MEMBER_COUNT';foreach($row in $now.files){$old=@($root.inventory.files|Where-Object{$_.path-ceq$row.path});Need ($old.Count-eq1 -and $old[0].bytes-eq$row.bytes -and $old[0].sha256-ceq$row.sha256) 'EXACT_ALL_DOWNLOADED_FILE_BYTES'};foreach($dir in $now.directories){Need ($dir-cin$root.inventory.directories) 'EXACT_DOWNLOADED_DIRECTORY_SET'};return $now}
function Own-Processes {Budget;$owned=@();$unknown=@();$images=@(($c.roots[0].path+'\Setup.exe'),($c.roots[1].path+'\Setup.exe'),(Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) 'Programs\FutureClassroom\fc-bootstrap.exe'));foreach($p in @(Get-CimInstance Win32_Process -Filter "Name='Setup.exe' OR Name='fc-bootstrap.exe'" -ErrorAction Stop)){if([string]::IsNullOrEmpty($p.ExecutablePath)){$unknown+=@{pid=$p.ProcessId;name=$p.Name}}elseif($p.ExecutablePath-iin$images){$owned+=@{pid=$p.ProcessId;image=$p.ExecutablePath;created=[string]$p.CreationDate}}};return @{owned=$owned;unknown=$unknown;knownZero=($owned.Count-eq0 -and $unknown.Count-eq0);commandsRead=$false}}
function Absent-Product {Budget;$v=Measure-FcProductState -Config $c.productConfig -Expected 'Absent';Need ($v.status-ceq'PASS_READONLY_EXPECTED_ABSENT' -and $v.knownAbsent-eq$true -and $v.runAbsent-eq$true) 'INDEPENDENT_FULL_PRODUCT_FILES_COMPONENTS_MARKERS_RUN_ABSENT';return $v}
function Delete-Exact($root){[void](Exact-Inventory $root);Need (Own-Processes).knownZero 'NO_LIVE_OWN_PROCESS_BEFORE_NONCE_DELETE';Budget;foreach($f in $root.inventory.files){if($f.path-cne'.owner'){Budget;[IO.File]::Delete((Join-Path $root.path ($f.path.Replace('/','\'))))}};foreach($dir in @($root.inventory.directories|Sort-Object Length -Descending)){Budget;[IO.Directory]::Delete((Join-Path $root.path ($dir.Replace('/','\'))),$false)};Budget;[IO.File]::Delete((Join-Path $root.path '.owner'));[IO.Directory]::Delete($root.path,$false);$v=Known $root.path;Need ($v.status-ceq'KNOWN_ABSENT') 'NONCE_POST_KNOWN_ABSENT';return $v}
try {
 Need ($PSVersionTable.PSVersion.Major-eq5 -and $PSVersionTable.PSVersion.Minor-eq1 -and [IntPtr]::Size-eq8) 'FRESH_PS51_X64';$who=[Security.Principal.WindowsIdentity]::GetCurrent();try{Need ($who.User.Value-ceq$c.sid) 'SAME_FIXED_USER'}finally{$who.Dispose()}
 Need (@($c.roots).Count-eq2 -and $c.roots[0].kind-ceq'old' -and $c.roots[1].kind-ceq'new' -and $c.roots[0].path-cne$c.roots[1].path) 'EXACT_TWO_ROOTS';$before=@();foreach($root in $c.roots){$before+=,@{kind=$root.kind;inventory=(Exact-Inventory $root)}};$result['beforeInventories']=$before
 # Compiler scratch stays within an already downloaded owned subdirectory. Any
 # residue is rejected by a second full inventory before native gate mutation.
 $temp=Join-Path $c.roots[1].path 'instrument-temp';Need ('instrument-temp'-cin$c.roots[1].inventory.directories) 'ORIGINAL_DOWNLOADED_INSTRUMENT_TEMP';$env:TEMP=$temp;$env:TMP=$temp
 foreach($source in $c.instruments){Budget;$bytes=[Convert]::FromBase64String($source.base64);$hash=[Security.Cryptography.SHA256]::Create();try{$digest=[BitConverter]::ToString($hash.ComputeHash($bytes)).Replace('-','').ToLowerInvariant()}finally{$hash.Dispose()};Need ($bytes.Length-eq$source.bytes -and $digest-ceq$source.sha256) 'EXACT_FROZEN_INSTRUMENT_BYTES';$text=[Text.UTF8Encoding]::new($false,$true).GetString($bytes);if($source.name-ceq'ProductState.ps1'){. ([ScriptBlock]::Create($text))}else{Add-Type -TypeDefinition $text -Language CSharp -ErrorAction Stop}}
 foreach($root in $c.roots){[void](Exact-Inventory $root)};$own=Own-Processes;$result['beforeOwnProcesses']=$own;Need $own.knownZero 'NO_RELATED_LIVE_OR_UNKNOWN_PROCESS';$result['beforeProduct']=Absent-Product
 $pending=Join-Path $c.gateFacts[0] 'pending.v1';Need ((Known $pending).status-ceq'KNOWN_ABSENT') 'OLD_PENDING_NOT_ABSENT_NO_DELETE_OR_RECOVERY';$snapshot=[FcR76GateRetirement]::Capture($c.sid);$facts=@($snapshot.Facts());Need ($facts.Count-eq6) 'NATIVE_GATE_FACT_COUNT';for($i=0;$i-lt6;$i++){Need ($facts[$i]-ceq$c.gateFacts[$i]) 'ORIGINAL_COMPILED_ROOT_GATE_ID_AND_ACL'};$result['gateCaptureFacts']=$facts
 Budget;Need (Own-Processes).knownZero 'NO_LIVE_OWNER_BEFORE_RETIRE';$result.gateRetirementAttempted=$true;$retired=[FcR76GateRetirement]::Retire($snapshot);Need ($retired-ceq'DISPOSITION_AND_CHECKED_CLOSE_ONLY_REQUIRE_EXTERNAL_ABSENCE_READBACK') 'FIXED_NATIVE_RETIRE_RETURN';$result['nativeGateRetirement']=@{return=$retired;closeEvidence='ALL_CHECKED_BY_FIXED_NATIVE_RETURNING_CODE_PATH_NOT_SYNTHETIC_PER_HANDLE_RECEIPTS';pendingDeletedByController=$false};$gateAbsent=Known $c.gateFacts[0];Need ($gateAbsent.status-ceq'KNOWN_ABSENT') 'ORIGINAL_GATE_NAMESPACE_POST_KNOWN_ABSENT';$result['gateKnownAbsent']=$gateAbsent
 $result['afterGateProduct']=Absent-Product;foreach($root in $c.roots){[void](Exact-Inventory $root)}
 foreach($root in $c.roots){$result.rootsDeleted+=,@{kind=$root.kind;readback=(Delete-Exact $root)}}
 $result['finalOwnProcesses']=Own-Processes;Need $result.finalOwnProcesses.knownZero 'FINAL_NO_OWN_PROCESS';$result['finalProduct']=Absent-Product;$result['finalGate']=Known $c.gateFacts[0];Need ($result.finalGate.status-ceq'KNOWN_ABSENT') 'FINAL_GATE_ABSENT';Budget;$ok=$true;$result.status='PASS_EXACT_OWNED_REMOVAL_TWO_NONCES_AND_ORIGINAL_EMPTY_GATE_CLEANED'
}catch{$result['failureType']=$_.Exception.GetType().FullName;$result['failureCode']=$(if($_.Exception.Message-cmatch'^[A-Z0-9_]+$'){$_.Exception.Message}else{'NATIVE_READBACK_OR_EXACT_CLEANUP_FAILURE_RETAIN_REMAINDER'})}
finally{$result['elapsedMilliseconds']=$clock.ElapsedMilliseconds;$result['originalBudgetExceeded']=($clock.ElapsedMilliseconds-ge600000);if($result.originalBudgetExceeded){$ok=$false;$result.status='FAIL_ORIGINAL_CLEANUP_BUDGET'};foreach($root in $c.roots){try{$result[('finalPath_'+$root.kind)]=Known $root.path}catch{$ok=$false;$result['finalReadbackUnknown']=$true}}}
$result|ConvertTo-Json -Depth 24 -Compress
if(-not$ok){exit 1};exit 0
'''
def source_fact(p):
 row=fact(p);return {'name':p.name,'bytes':row['bytes'],'sha256':row['sha256'],'base64':base64.b64encode(p.read_bytes()).decode()}

def replay(report,root,expected_owner):
 inv=report['inventory'];validate_inventory(inv);need(report['downloadVerified'] is True,'ORIGINAL_DOWNLOAD_VERIFIED')
 need(isinstance(report['nonce'],str) and re.fullmatch('[0-9a-f]{32}',report['nonce']),'EXACT_REPORT_NONCE')
 need(report['windowsRoot'].endswith('\\'+root+report['nonce']),'CLOSED_REPORT_WINDOWS_ROOT')
 local=Path(report['_localReport']).parent/'download'/(root+report['nonce']);need(local.is_dir() and local.resolve()==local and not local.is_symlink(),'EXACT_LOCAL_DOWNLOAD_ROOT')
 actual=[];dirs=[]
 for p in local.rglob('*'):
  need(not p.is_symlink(),'NO_LOCAL_DOWNLOAD_SYMLINK');rel=p.relative_to(local).as_posix()
  if p.is_dir():dirs.append(rel)
  else:got=fact(p);actual.append({'path':rel,'bytes':got['bytes'],'sha256':got['sha256']})
 need({v['path']:(v['bytes'],v['sha256']) for v in actual}=={v['path']:(v['bytes'],v['sha256']) for v in inv['files']} and set(dirs)==set(inv['directories']),'COMPLETE_LOCAL_DOWNLOAD_BYTE_REPLAY')
 need((local/'.owner').read_text()==expected_owner,'EXACT_DOWNLOADED_OWNER')
 return local

def core_recovery(j):
 need(j['status']=='PASS_GNU_WIN11_EXPLICIT_REMOVAL_COMPLETE_DOWNLOAD_OLD_END_UNKNOWN' and type(j['runtimeActualExit']) is int and j['runtimeActualExit']==0 and j['downloadVerified'] is True and type(j['elapsedSeconds']) in (int,float) and 0<=j['elapsedSeconds']<600 and j['originalWholeBudgetExceeded'] is False and j['oldEnd']=='UNKNOWN_UNCHANGED' and admission(j['phase']),'ACTUAL_RECOVERY_CORE_FACTS_NOT_STATUS_ONLY')
 ops={v['label']:v for v in j['operations']};need(len(ops)==len(j['operations']) and all(type(ops[n]['actualExit']) is int and ops[n]['actualExit']==0 and ops[n]['originalLocalParentReaped'] is True and ops[n]['remoteReturnUnknown'] is False for n in ['01-create','02-upload','03-single-explicit-removal','04-inventory','05-download']),'ACTUAL_ROOT_TRANSPORTS_AND_COMPLETE_DOWNLOAD')

def bind(recovery_path,recovery_sha):
 f=fact(recovery_path);need(f['sha256']==recovery_sha,'ROOT_BOUND_ACTUAL_RECOVERY_REPORT');new=json.loads(Path(recovery_path).read_bytes());core_recovery(new);new['_localReport']=str(recovery_path);newlocal=replay(new,'FutureClassroom-r80-owned-removal-','future-classroom-owned-r80-owned-removal-runtime/v1\n');need(json.loads((newlocal/'removal-result.json').read_bytes())==new['phase'],'ORIGINAL_DOWNLOADED_RESULT_EQUALS_PHASE')
 need(fact(OLD)['sha256']==OLD_SHA,'EXACT_ORIGINAL_FAIL_REPORT');old=json.loads(OLD.read_bytes());old['_localReport']=str(OLD);need(old['status']=='FAIL_OR_UNKNOWN_RETAIN_ORIGINALS' and len(old['inventory']['files'])==30 and len(old['inventory']['directories'])==4 and sha((json.dumps(old['inventory'],sort_keys=True,separators=(',',':'))+'\n').encode())==OLD_INV_SHA,'FIXED_OLD_30_FILE_FOUR_DIR_SNAPSHOT');oldlocal=replay(old,'FutureClassroom-r80-controlled-product-','future-classroom-owned-r80-controlled-product-runtime/v1\n')
 dpath=R/'explicit-removal-preparation-second/scope.json';need(fact(dpath)['sha256']=='5b72a272f0a19acc234acf900fe7b51faf871c9ca08003f5115904b1c2c6fcee','EXACT_OLD_DESIGN');design=json.loads(dpath.read_bytes());need(old['windowsRoot']==design['windowsRoot'] and old['nonce']==design['testNonce'],'EXACT_OLD_TEST_NONCE')
 audit=newlocal/'explicit-removal-audit.v1';auditfact=fact(audit);a=new['phase']['nativeAudit'];need(auditfact['bytes']==a['bytes'] and auditfact['sha256']==a['sha256'],'EXACT_DOWNLOADED_NATIVE_AUDIT_BYTES');text=audit.read_bytes().decode('ascii');lines=text.splitlines();need(text.endswith('\n') and len(lines)==15 and lines[0]=='FC-EXPLICIT-REMOVAL-AUDIT/v1' and all(ord(c)==10 or 32<=ord(c)<=126 for c in text),'STRICT_NATIVE_AUDIT_LINES');values=dict(line.split('=',1) for line in lines[1:]);need(len(values)==14 and values['stage']=='RemovalAuthorized' and values['oldDisposition']=='UNKNOWN' and values['runtimeReport']==OLD_SHA and values['packageReport']==design['package']['sha256'] and values['oldImage']==design['originalSetup']['sha256'],'AUDIT_EXACT_OLD_BOUND_SOURCE_AND_UNKNOWN_DISPOSITION')
 phasepat=r'pid:([1-9][0-9]*);creation:([1-9][0-9]*);thread:([1-9][0-9]*);begin:0;transaction:([1-9][0-9]*);install:0;end:0;outcome:Commit;guardReturned:0;phaseControls:0;originalThreadExit:0;originalProcessExit:0'
 for n in [1,2]:need(re.fullmatch(phasepat,values['newPhase'+str(n)]) is not None,'TWO_NATIVE_AUDIT_TERMINALS')
 config=json.loads((oldlocal/'artifact-manifest.json').read_bytes());need(config['sourceGit']==design['originalSourceGit'] and config['payloads']==design['originalPayload14'] and config['expectedUserSid']==design['sid'],'ORIGINAL_PAYLOAD_PRODUCT_OBSERVATION_CONFIG');config.update(registryMarkerKey='Software\\FutureClassroom\\Installer\\Components',runKey='Software\\Microsoft\\Windows\\CurrentVersion\\Run',runValue='FutureClassroom',registryView='Registry32',fixedDestinationKnownFolderSuffix=['Programs','FutureClassroom'])
 roots=[{'kind':'old','path':old['windowsRoot'],'nonce':old['nonce'],'owner':'future-classroom-owned-r80-controlled-product-runtime/v1\n','inventory':old['inventory']},{'kind':'new','path':new['windowsRoot'],'nonce':new['nonce'],'owner':'future-classroom-owned-r80-owned-removal-runtime/v1\n','inventory':new['inventory']}]
 need(roots[0]['path']!=roots[1]['path'],'DISTINCT_OLD_NEW_NONCES')
 return {'sid':design['sid'],'roots':roots,'gateFacts':design['originalCoordinationFacts'],'productConfig':config,'instruments':[source_fact(S/n) for n in ['ProductState.cs','ProductState.ps1','GateRetirement.cs']]},{'recoveryReport':f,'oldReport':fact(OLD),'oldInventoryCanonicalSha256':OLD_INV_SHA,'newAudit':auditfact,'localDownloadReplay':'PASS_BOTH_COMPLETE_ORIGINALS','oldEnd':'UNKNOWN_UNCHANGED'}

def remote(c):
 feed=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;\n"+SCRIPT).encode();cmd='powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand '+base64.b64encode(BOOT.encode('utf-16-le')).decode();return ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8',HOST,cmd],feed

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');ap.add_argument('--recovery-report');ap.add_argument('--recovery-report-sha256');ap.add_argument('--preparation-freeze-sha256');ap.add_argument('--report');a=ap.parse_args()
 if not a.execute:print(json.dumps({'status':'PREPARED_NOT_EXECUTED','recoverySuccess':'NOT_ASSUMED','Windows':'NOT_RUN','cleanup':'NOT_RUN'}));return 0
 need(all([a.recovery_report,a.recovery_report_sha256,a.preparation_freeze_sha256,a.report]),'EXPLICIT_ROOT_RECOVERY_AND_FROZEN_INPUTS');need((R/'.owner').read_bytes()==b'future-classroom-owned-r80-controlled-repair/v1\n' and (P/'.owner').read_bytes()==b'future-classroom-owned-r80-owned-removal-cleanup-preparation/v1\n','OWNED_LOCAL_ROOTS');f=P/'freeze-first.json';need(sha(f.read_bytes())==a.preparation_freeze_sha256,'ROOT_PINNED_CLEANUP_FREEZE')
 for row in json.loads(f.read_bytes())['files']:
  got=fact(P/row['path']);need(got['bytes']==row['bytes'] and got['sha256']==row['sha256'],'EXACT_FROZEN_CLEANUP_SOURCE')
 c,binding=bind(a.recovery_report,a.recovery_report_sha256);report=Path(a.report);D=report.parent;need(report.is_absolute() and D.resolve()==D and D.parent==R and not D.exists() and report.name.endswith('.json'),'NEW_LOCAL_CLEANUP_RESULT_ROOT');D.mkdir();(D/'.owner').write_bytes(b'future-classroom-owned-r80-owned-removal-cleanup-result/v1\n');args,feed=remote(c);(D/'01-cleanup.stdin.ps1').write_bytes(feed)
 result={'status':'FAIL_OR_UNKNOWN_RETAIN_REMAINDER','binding':binding,'oldEnd':'UNKNOWN_UNCHANGED','actualExit':None,'originalLocalParentReaped':False,'remoteReturnUnknown':True,'argv':args,'budgetSeconds':600,'noRetry':True};start=time.monotonic();rc=1
 try:
  with (D/'01-cleanup.stdout.log').open('xb') as out,(D/'01-cleanup.stderr.log').open('xb') as err:
   proc=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=out,stderr=err);result['originalLocalPid']=proc.pid
   try:proc.communicate(feed,timeout=600);result.update(actualExit=proc.returncode,originalLocalParentReaped=True,remoteReturnUnknown=False)
   except subprocess.TimeoutExpired:raise RuntimeError('TRANSPORT_TIMEOUT_NO_REMOTE_KILL_OR_RETRY')
  raw=(D/'01-cleanup.stdout.log').read_bytes();j=json.loads(raw.decode('utf-8-sig'));result['phase']=j
  need(proc.returncode==0 and j['status']=='PASS_EXACT_OWNED_REMOVAL_TWO_NONCES_AND_ORIGINAL_EMPTY_GATE_CLEANED' and j['originalBudgetExceeded'] is False and j['oldEnd']=='UNKNOWN_UNCHANGED' and j['finalGate']['status']=='KNOWN_ABSENT' and len(j['rootsDeleted'])==2 and all(v['readback']['status']=='KNOWN_ABSENT' for v in j['rootsDeleted']) and all(j['finalPath_'+k]['status']=='KNOWN_ABSENT' for k in ['old','new']) and j['finalOwnProcesses']['knownZero'] is True and j['finalProduct']['knownAbsent'] is True,'ACTUAL_CLEANUP_CORE_NOT_STATUS_ONLY');result['status']='PASS_EXACT_EMPTY_GATE_AND_BOTH_DOWNLOADED_NONCES_CLEANED';rc=0
 except Exception as e:result['failureType']=type(e).__name__;result['failureCode']=str(e) if re.fullmatch('[A-Z0-9_]+',str(e)) else 'TRANSPORT_NATIVE_OR_EXACT_READBACK_FAILURE_RETAIN_REMAINDER'
 finally:
  result['elapsedSeconds']=time.monotonic()-start;result['originalWholeBudgetExceeded']=result['elapsedSeconds']>=600
  for label in ['stdout','stderr']:
   p=D/('01-cleanup.'+label+'.log');result[label]={'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
  if result['originalWholeBudgetExceeded']:rc=1
  report.write_bytes(rawjson(result))
 print(json.dumps({'status':result['status'],'report':str(report),'sha256':sha(report.read_bytes())}));return rc
if __name__=='__main__':raise SystemExit(main())
