#!/usr/bin/env python3
"""Local fixed evidence binding only. No Windows, no compilation or execution."""
import base64, hashlib, json, os, pathlib, struct
R=pathlib.Path('/tmp/fc-round80-controlled-repair')
OUT=pathlib.Path(__file__).resolve().parent
EXPECTED={
 'controlled-product-runtime-first/report.json':'5ef468302208d1061aa6e9f197686017af66b90c7890ea703646feee207a66ab',
 'controlled-product-package-first/report.json':'6af236d4087f68383ecaea38981bc3b2cf1b7ea7ec0b69cc7fe5e6f2c3e3d943',
 'pending-readonly-retrieval-first/report.json':'8a51d4c50426fded71da57455243142c8a9858ec005d3ee701c76515e83ff78f',
 'explicit-removal-preparation-second/scope.json':'5b72a272f0a19acc234acf900fe7b51faf871c9ca08003f5115904b1c2c6fcee',
}
def load(name):
 b=(R/name).read_bytes(); assert hashlib.sha256(b).hexdigest()==EXPECTED[name], name
 return json.loads(b)
def write(name,b):
 fd=os.open(OUT/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'wb') as f:f.write(b)
def main():
 runtime=load('controlled-product-runtime-first/report.json')
 package=load('controlled-product-package-first/report.json')
 snapshot=load('pending-readonly-retrieval-first/report.json')['originalNativeSnapshot']['capture']
 scope=load('explicit-removal-preparation-second/scope.json')
 assert snapshot['Status']=='PASS_READONLY_PINNED_PENDING_SNAPSHOT_ONLY'
 assert snapshot['SameHandleBytesEqual'] and snapshot['SameHandleMetadataEqual'] and not snapshot['CloseUnknown']
 assert all(x['Success'] and not x['Unknown'] for x in snapshot['NativeReturns'])
 pending=base64.b64decode(snapshot['BytesBase64'],validate=True)
 assert len(pending)==106 and hashlib.sha256(pending).hexdigest()=='6b385a9577182edeb9abc51bfa3d317386f0f070c126fd545534d1c437f9459d'
 assert snapshot['ParsedOperationTag']==5 and snapshot['ParsedSid']==scope['sid']
 sid=pending[-28:];assert sid==bytes([1,5,0,0,0,0,0,5])+b''.join(struct.pack('<I',n) for n in [21,3896111207,1867804362,1971593122,1001])
 setup=(R/'controlled-product-package-first/Setup.exe').read_bytes()
 assert hashlib.sha256(setup).hexdigest()==scope['originalSetup']['sha256']
 assert setup[-16:]==b'FCLIFE73-END-v1\0'
 n=struct.unpack('<I',setup[-20:-16])[0];manifest=setup[-20-n:-20]
 assert n==1396 and hashlib.sha256(manifest).hexdigest()==package['lifecycle_binary']['manifest_sha256']
 assert manifest[:8]==b'FCLM73\0\0' and struct.unpack('<HH',manifest[8:12])==(1,14)
 # Bind the complete bytes from the original pinned-hash Setup, rather than a
 # reconstructed subset. Exact payload14 is checked again by the Rust parser.
 b=bytearray(b'FC-OWNED-REMOVAL\0v1\0')
 for name in list(EXPECTED)[:3]:b.extend(bytes.fromhex(EXPECTED[name]))
 b.extend(bytes.fromhex(scope['originalSetup']['sha256']))
 b.extend(struct.pack('<H',len(sid)));b.extend(sid)
 for role in ['RootBefore','GateBefore','PendingBefore']:
  v=snapshot[role];assert v['Identity']==snapshot[role.replace('Before','After')]['Identity']
  b.extend(struct.pack('<IQQ',int(v['Volume'],16),int(v['FileId'],16),v['CreationFiletime']))
 b.extend(struct.pack('<H',len(pending)));b.extend(pending)
 for p in scope['originalTerminatedProcessReceipts']:
  assert p['ActualWait']==0 and p['ActualExitCode']==1603 and p['CloseStatus']=='CHECKED_CLOSE_SUCCESS'
  assert p['Sha256']==scope['originalSetup']['sha256'] and p['Sid']==scope['sid']
  b.extend(struct.pack('<IQIIB',p['Pid'],p['CreationFiletime'],p['ActualWait'],p['ActualExitCode'],1))
 b.extend(struct.pack('<I',len(manifest)));b.extend(manifest)
 assert len(b)<=40960
 encoded=b.hex().encode('ascii');assert len(encoded)<=81920
 write('scope.bin',b);write('scope.hex',encoded)
 receipt={'status':'LOCAL_BUILD_BOUND_SCOPE_ONLY_NOT_EXECUTION_OR_OLD_END','inputs':EXPECTED,'scopeBytes':len(b),'scopeSha256':hashlib.sha256(b).hexdigest(),'envBytes':len(encoded),'envSha256':hashlib.sha256(encoded).hexdigest(),'envName':'FC_OWNED_REMOVAL_SCOPE_HEX','manifestBytes':len(manifest),'manifestSha256':hashlib.sha256(manifest).hexdigest(),'pendingBytes':len(pending),'pendingSha256':snapshot['Sha256'],'oldEnd':'UNKNOWN_UNCHANGED','sameBoot':'DIAGNOSTIC_NOT_ASSERTED','newTransactions':'NOT_EXECUTED','oldPayload':'ORIGINAL_C508_COMPLETE14_REQUIRED','externalAuthority':'PERSISTENT_USER_TEST_AND_COMPLETE_OWNED_CLEANUP_AUTHORIZATION'}
 write('scope-binding.json',(json.dumps(receipt,indent=2)+'\n').encode());print(json.dumps({k:receipt[k] for k in ['status','scopeBytes','scopeSha256','envBytes','envSha256']}))
if __name__=='__main__':main()
