"""Bounded local structure/classification checks only; never starts remote tools."""
from pathlib import Path
import copy,json,runpy,sys,ast,hashlib,subprocess
sys.dont_write_bytecode=True
P=Path('/tmp/fc-round80-controlled-repair/owned-removal-runtime-preparation-first');ns=runpy.run_path(str(P/'run-owned-removal.py'));R=ns['R'];results=[]
def check(name,call,want):
 try:out=call();passed=out is not False
 except (AssertionError,KeyError,TypeError,ValueError):passed=False
 assert passed==want,name;results.append({'case':name,'expectedAccepted':want,'actualAccepted':passed})
fixed=ns['fixed_inputs']();old=json.loads((R/'controlled-product-bindings-first/artifact-manifest.json').read_bytes());c=copy.deepcopy(old);c.update(status='BOUND_GNU_DEV_OWNED_REMOVAL_FIXTURE_NOT_RELEASE',sourceGit=ns['AUX_SOURCE'],auxiliarySourceGit=ns['AUX_SOURCE'],payloadSourceGit=ns['OLD_SOURCE'],compiledScope={'bytes':fixed['scope']['scopeBytes'],'sha256':fixed['scope']['scopeSha256'],'envBytes':fixed['scope']['envBytes'],'envSha256':fixed['scope']['envSha256']},scopeBinding=ns['fact'](ns['SCOPE_BINDING']),beforeSnapshot=ns['fact'](ns['BEFORE_SNAPSHOT']))
# Deliberately synthetic artifact identity. Used only by pure validate_config;
# never accepted by bind, read as a binary, or described as a real fixture.
c['setup']['sha256']='8'*64;c['msi']['sha256']='9'*64;source={'sourceBase':ns['AUX_SOURCE'],'sources':[{'path':'crates/fixture-only-not-a-product.rs','bytes':1,'sha256':'1'*64}]};sf={'bytes':123,'sha256':'2'*64};c['sourceManifest']=dict(sf)
def validate(value,src=None):return ns['validate_config'](value,source if src is None else src,sf,fixed)
check('pure_structural_fixture_synthetic_no_binary_or_execution',lambda:validate(copy.deepcopy(c)),True)
for name,mut in [('old_normal_artifact',lambda x:x.update(status=old['status'])),('wrong_aux_source',lambda x:x.update(auxiliarySourceGit=ns['OLD_SOURCE'])),('wrong_payload_source',lambda x:x.update(payloadSourceGit=ns['AUX_SOURCE'])),('wrong_user',lambda x:x.update(expectedUserSid='S-1-5-21-1-2-3-1001')),('changed_version',lambda x:x.update(version='9.9.9')),('changed14_byte',lambda x:x['payloads'][0].update(size=99)),('missing_payload',lambda x:x['payloads'].pop()),('changed_scope',lambda x:x['compiledScope'].update(sha256='0'*64)),('runtime_scope_substitution',lambda x:x['scopeBinding'].update(path='/tmp/untrusted.json')),('different_old_snapshot',lambda x:x['beforeSnapshot'].update(sha256='0'*64)),('old_setup_identity',lambda x:x['setup'].update(sha256=old['setup']['sha256'])),('bad_source_manifest_binding',lambda x:x['sourceManifest'].update(bytes=0))]:
 value=copy.deepcopy(c);mut(value);check(name,lambda v=value:validate(v),False)
bad=copy.deepcopy(source);bad['sources'][0]['path']='../wrong';check('source_parent_traversal',lambda:validate(copy.deepcopy(c),bad),False)
original=json.loads((R/'controlled-product-runtime-first/report.json').read_bytes());phase=copy.deepcopy(original['phase']['phases'][0]);phase['verb']='owned-test-remove';phase['directOriginalFinal']=[phase['directOriginalFinal']] if isinstance(phase['directOriginalFinal'],dict) else phase['directOriginalFinal'];phase['postPhaseProcesses']={'knownZero':True}
# All observed original handles must return; an empty observer is honestly a miss,
# while actual two-G success is separately required from native audit + B + Absent.
phase['observerFinal']['Processes']=[]
j={'status':'PASS_GNU_WIN11_EXPLICIT_OWNED_FIXTURE_REMOVAL_OLD_END_UNKNOWN','oldEnd':'UNKNOWN_UNCHANGED','ownerUnknown':False,'instrumentUnknown':False,'originalBudgetExceeded':False,'phases':[phase],'nativeAudit':{'oldEnd':'UNKNOWN_UNCHANGED','stage':'RemovalAuthorized','oldDisposition':'UNKNOWN','phases':[{'begin':0,'install':0,'end':0,'outcome':'Commit'},{'begin':0,'install':0,'end':0,'outcome':'Commit'}]},'finallyProduct':{'knownAbsent':True},'finallyCoordination':{'pendingKnownAbsent':True},'finallyOwnProcesses':{'knownZero':True},'afterCache':{'allObservedAbsent':True}}
check('core_admission_with_honest_external_observer_miss',lambda:ns['admission'](j),True)
for name,mut in [('known_nonzero_B_physical_return_not_success',lambda x:x['phases'][0]['client'].update(exitCode=1603)),('captured_close_unknown',lambda x:x['phases'][0]['directOriginalFinal'][0].update(CheckedClose=False)),('old_end_forged_zero',lambda x:x.update(oldEnd='0')),('pending_still_present',lambda x:x['finallyCoordination'].update(pendingKnownAbsent=False)),('partial_native_terminal',lambda x:x['nativeAudit']['phases'].pop()),('native_end_unknown',lambda x:x['nativeAudit']['phases'][1].update(end=1603)),('audit_authorization_not_deleted',lambda x:x['finallyProduct'].update(knownAbsent=False)),('bool_native_return_not_int',lambda x:x['nativeAudit']['phases'][0].update(begin=False)),('budget_expired',lambda x:x.update(originalBudgetExceeded=True))]:
 value=copy.deepcopy(j);mut(value);check(name,lambda v=value:ns['admission'](v),False)
for p in P.rglob('*.py'):ast.parse(p.read_bytes(),filename=p.name)
run=subprocess.run([sys.executable,'-B',str(P/'run-owned-removal.py')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False);assert run.returncode==0 and json.loads(run.stdout)['status']=='PREPARED_NOT_EXECUTED';(P/'local-default.stdout.log').write_bytes(run.stdout);(P/'local-default.stderr.log').write_bytes(run.stderr)
print(json.dumps({'status':'PASS_LOCAL_PREPARATION_CHECKS_ONLY','cases':results,'caseCount':len(results),'pythonAST':'PASS','defaultActualExit':run.returncode,'PowerShell51AST':'NOT_RUN_ROOT_ONLY','CSharpCompilation':'NOT_RUN','Windows':'NOT_RUN','syntheticIdentities':'Pure validate_config only; no product fixture artifacts read or created.'},ensure_ascii=False))
