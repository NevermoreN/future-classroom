#!/usr/bin/env python3
"""Root-only default-inert fixed owned fixture removal. No automatic cleanup."""
from pathlib import Path
import argparse,base64,hashlib,json,re,runpy,shutil,subprocess,sys,time,uuid
sys.dont_write_bytecode=True
R=Path('/tmp/fc-round80-controlled-repair');P=R/'owned-removal-runtime-preparation-first';S=P/'sources'
HOST='future-classroom-win11';OWNER='future-classroom-owned-r80-owned-removal-runtime/v1\n'
SUPPORT=runpy.run_path(str(P/'transport-support.py'))
need,sha,rawjson,fact,validate_inventory,phase_returned=[SUPPORT[k] for k in ['need','sha','rawjson','fact','validate_inventory','phase_returned']]
SOURCE_NAMES=['Capture.cs','ProcessObserver.cs','ProductState.cs','ProductState.ps1','PendingSnapshot.cs','Invoke-OwnedRemoval.ps1']
AUX_SOURCE='33c11f5e41cce727746aeb5b5801b0e87eaf0f41';OLD_SOURCE='c50882df40b86248e3e2d4e404d0fbe8e43e30a9'
SCOPE_BINDING=R/'owned-removal-implementation-first/scope-binding.json';SCOPE_SHA='00a16aba5e3c744509c40001395a5d9dc9b98f7def518bbe0b34ca41ddf299af'
BEFORE_SNAPSHOT=R/'pending-readonly-retrieval-first/report.json';BEFORE_SHA='8a51d4c50426fded71da57455243142c8a9858ec005d3ee701c76515e83ff78f'
DESIGN=R/'explicit-removal-preparation-second/scope.json';DESIGN_SHA='5b72a272f0a19acc234acf900fe7b51faf871c9ca08003f5115904b1c2c6fcee'
BOOT="[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()));$ok=$?;$code=Get-Variable -Name LASTEXITCODE -ErrorAction SilentlyContinue;if($null-ne$code){exit ([int]$code.Value)};if($ok){exit 0};exit 1"
COMMON=r'''$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Need([bool]$v,[string]$code){if(-not$v){throw $code}}
function Fact([string]$p){$f=Get-Item -LiteralPath $p -Force;Need (-not$f.PSIsContainer -and ($f.Attributes-band1024)-eq0) 'REGULAR_NO_REPARSE';return @{bytes=[long]$f.Length;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function RootPath {return Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) ('Temp\FutureClassroom-r80-owned-removal-'+$c.nonce)}
function CheckRoot([string]$root){Need ($root-ceq$c.root -and $root-ceq(RootPath)) 'EXACT_NONCE_ROOT';$a=[IO.File]::GetAttributes($root);Need (($a-band1024)-eq0 -and ($a-band16)-ne0) 'REGULAR_ROOT';Need ([IO.File]::ReadAllText((Join-Path $root '.owner'))-ceq"future-classroom-owned-r80-owned-removal-runtime/v1`n") 'OWNER';$acl=[IO.Directory]::GetAccessControl($root);Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq$c.sid) 'PROTECTED_ROOT_OWNER';$rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($rules.Count-eq2 -and @($rules|Where-Object{$_.IdentityReference.Value-cnotin@($c.sid,'S-1-5-18') -or $_.AccessControlType-ne'Allow' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count-eq0) 'ONLY_USER_SYSTEM_DACL'}
function Inventory([string]$root){CheckRoot $root;$files=@();$dirs=@();$q=[Collections.Generic.Queue[string]]::new();$q.Enqueue($root);while($q.Count){$dir=$q.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){$a=[IO.File]::GetAttributes($p);Need (($a-band1024)-eq0) 'NO_INVENTORY_REPARSE';$rel=$p.Substring($root.Length+1).Replace('\','/');if(($a-band16)-ne0){$dirs+=$rel;$q.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256}};Need ($files.Count-le256 -and $dirs.Count-le32) 'INVENTORY_BOUNDS'}};return @{files=$files;directories=$dirs}}
'''
CREATE=r'''$start=[Diagnostics.Stopwatch]::GetTimestamp();$frequency=[Diagnostics.Stopwatch]::Frequency
Need ($PSVersionTable.PSVersion.Major-eq5 -and $PSVersionTable.PSVersion.Minor-eq1 -and [IntPtr]::Size-eq8) 'PS51_X64'
$who=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$who.User;Need ($sid.Value-ceq$c.sid) 'CURRENT_SID'}finally{$who.Dispose()}
$root=RootPath;try{[void][IO.File]::GetAttributes($root);throw 'ROOT_ALREADY_PRESENT'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
$cursor=[IO.Path]::GetDirectoryName($root);while($cursor){$a=[IO.File]::GetAttributes($cursor);Need (($a-band1024)-eq0 -and ($a-band16)-ne0) 'ORIGINAL_NONREPARSE_ANCESTORS';$cursor=[IO.Path]::GetDirectoryName($cursor)}
[void][IO.Directory]::CreateDirectory($root);$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false);foreach($s in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($s,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))};[IO.Directory]::SetAccessControl($root,$acl);[IO.File]::WriteAllText((Join-Path $root '.owner'),"future-classroom-owned-r80-owned-removal-runtime/v1`n",[Text.UTF8Encoding]::new($false));$c.root=$root;CheckRoot $root
@{status='CREATED_ONLY_NEW_OWNED_REMOVAL_TRANSPORT_SCRATCH_NO_OLD_STATE_MUTATION';root=$root;sid=$c.sid;nonce=$c.nonce;originalStartQpc=$start;originalFrequency=$frequency}|ConvertTo-Json -Depth 12 -Compress
'''
INVOKE=r'''CheckRoot $c.root
& (Join-Path $c.root 'Invoke-OwnedRemoval.ps1') -Execute -ScratchRoot $c.root -ExpectedConfigSha256 $c.configSha256 -ExpectedInputsManifestSha256 $c.inputsSha256 -OriginalStartQpc $c.startQpc -OriginalFrequency $c.frequency
$code=Get-Variable -Name LASTEXITCODE -ErrorAction SilentlyContinue;Need ($null-ne$code) 'NESTED_RUNNER_EXIT_CODE_REQUIRED';exit ([int]$code.Value)
'''
INVENTORY=r'''CheckRoot $c.root;Inventory $c.root|ConvertTo-Json -Depth 12 -Compress'''
def fixed_inputs():
 out={}
 for label,p,digest in [('scope',SCOPE_BINDING,SCOPE_SHA),('snapshot',BEFORE_SNAPSHOT,BEFORE_SHA),('design',DESIGN,DESIGN_SHA)]:
  got=fact(p);need(got['sha256']==digest,'FROZEN_OLD_'+label.upper());out[label]=json.loads(p.read_bytes())
 return out

def validate_config(c,source,sf,fixed):
 need(isinstance(c,dict) and c['status']=='BOUND_GNU_DEV_OWNED_REMOVAL_FIXTURE_NOT_RELEASE' and c['target']=='i686-pc-windows-gnu','CLOSED_FEATURE_DEV_FIXTURE')
 d=fixed['design'];s=fixed['scope'];snapshot=fixed['snapshot']['originalNativeSnapshot']['capture']
 need(c['sourceGit']==c['auxiliarySourceGit']==AUX_SOURCE and c['payloadSourceGit']==OLD_SOURCE and c['family']==d['family'] and c['productCode']==d['product'] and c['expectedUserSid']==d['sid'] and c['guardAction']=='FcControlledInnerGuard' and c['version']=='0.1.0','EXACT_OLD_TARGET_NEW_AUX_AUTHORITY')
 need(c['payloads']==d['originalPayload14'] and len(c['payloads'])==14,'COMPLETE_ORDERED_ORIGINAL_C508_PAYLOAD14')
 need(c['compiledScope']=={'bytes':s['scopeBytes'],'sha256':s['scopeSha256'],'envBytes':s['envBytes'],'envSha256':s['envSha256']},'EXACT_COMPILED_SCOPE_FACT_NOT_RUNTIME_AUTHORITY')
 for key,path,digest in [('scopeBinding',SCOPE_BINDING,SCOPE_SHA),('beforeSnapshot',BEFORE_SNAPSHOT,BEFORE_SHA)]:
  row=c[key];need(row==fact(path) and row['sha256']==digest,'EXACT_'+key.upper())
 need(isinstance(source,dict) and set(source)=={'sourceBase','sources'} and source['sourceBase']==AUX_SOURCE and isinstance(source['sources'],list) and 0<len(source['sources'])<=1024,'EXACT_SOURCE_MANIFEST_SCHEMA')
 names=set();total=0
 for row in source['sources']:
  need(set(row)=={'path','bytes','sha256'},'SOURCE_ROW_SCHEMA');p=row['path'];need(isinstance(p,str) and 0<len(p)<=512 and ':' not in p and '\\' not in p and not p.startswith('/') and all(x not in ('','.','..') for x in p.split('/')) and not any(ord(x)<32 for x in p) and p not in names,'CANONICAL_SOURCE_ROW');names.add(p);need(type(row['bytes']) is int and 0<=row['bytes']<=16*1024*1024 and re.fullmatch('[0-9a-f]{64}',row['sha256']),'SOURCE_IDENTITY');total+=row['bytes']
 need(total<=256*1024*1024 and c['sourceManifest']=={'bytes':sf['bytes'],'sha256':sf['sha256']},'EXACT_FULL_FROZEN_SOURCE_MANIFEST')
 for key in ['setup','msi']:
  row=c[key];need(isinstance(row,dict) and set(row)=={'path','bytes','sha256'} and type(row['bytes']) is int and 0<row['bytes']<=64*1024*1024 and re.fullmatch('[0-9a-f]{64}',row['sha256']),'TYPED_FIXTURE_ARTIFACT')
 need(c['setup']['sha256']!=d['originalSetup']['sha256'] and c['msi']['sha256']!=d['sourceMsi']['sha256'],'NEW_FEATURE_AUXILIARY_NOT_OLD_NORMAL_PACKAGE')
 # This copied fact is evidence for before/readback only. It is never sent to Setup argv/environment.
 pending=snapshot['PendingBefore'];old=d['originalTerminatedProcessReceipts'];scope_ids=[int(pending['Volume'],16),int(pending['FileId'],16),pending['CreationFiletime']]
 c=dict(c);c['beforeEvidence']={'gateFacts':d['originalCoordinationFacts'],'pendingIdentity':pending['Identity'],'pendingBytes':snapshot['CompleteBytes'],'pendingSha256':snapshot['Sha256'],'pendingBase64':snapshot['BytesBase64'],'pendingHex':base64.b64decode(snapshot['BytesBase64'],validate=True).hex(),'runtimeReportSha256':d['runtime']['sha256'],'packageReportSha256':d['package']['sha256'],'oldImageSha256':d['originalSetup']['sha256'],'oldPending':', '.join(str(x) for x in scope_ids),'oldB':str(old[0]['Pid'])+','+str(old[0]['CreationFiletime'])+';wait=0;exit=1603;checkedClose=1','oldG':str(old[1]['Pid'])+','+str(old[1]['CreationFiletime'])+';wait=0;exit=1603;checkedClose=1'}
 c.update(registryMarkerKey='Software\\FutureClassroom\\Installer\\Components',runKey='Software\\Microsoft\\Windows\\CurrentVersion\\Run',runValue='FutureClassroom',registryView='Registry32',fixedDestinationKnownFolderSuffix=['Programs','FutureClassroom'])
 return c

def bind(ap,ah,sp,sh):
 af=fact(ap);sf=fact(sp);need(af['sha256']==ah and sf['sha256']==sh,'EXPLICIT_FINAL_MANIFEST_SHA')
 c=validate_config(json.loads(Path(ap).read_bytes()),json.loads(Path(sp).read_bytes()),sf,fixed_inputs())
 for key in ['setup','msi']:need(fact(c[key]['path'])==c[key],'EXACT_FINAL_'+key.upper())
 return c,af,sf

def remote(script,c):
 feed=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;\n"+COMMON+script).encode();cmd='powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand '+base64.b64encode(BOOT.encode('utf-16-le')).decode()
 return ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8',HOST,cmd],feed

def admission(j):
 if not isinstance(j,dict):return False
 phases=j.get('phases');audit=j.get('nativeAudit',{});native=audit.get('phases');coord=j.get('finallyCoordination',{})
 return j.get('status')=='PASS_GNU_WIN11_EXPLICIT_OWNED_FIXTURE_REMOVAL_OLD_END_UNKNOWN' and j.get('oldEnd')=='UNKNOWN_UNCHANGED' and j.get('ownerUnknown') is False and j.get('instrumentUnknown') is False and j.get('originalBudgetExceeded') is False and isinstance(phases,list) and len(phases)==1 and phases[0].get('verb')=='owned-test-remove' and phase_returned(phases[0]) and phases[0].get('postPhaseProcesses',{}).get('knownZero') is True and j.get('finallyProduct',{}).get('knownAbsent') is True and coord.get('pendingKnownAbsent') is True and j.get('finallyOwnProcesses',{}).get('knownZero') is True and j.get('afterCache',{}).get('allObservedAbsent') is True and audit.get('oldEnd')=='UNKNOWN_UNCHANGED' and audit.get('stage')=='RemovalAuthorized' and audit.get('oldDisposition')=='UNKNOWN' and isinstance(native,list) and len(native)==2 and all(all(type(p.get(k)) is int and p[k]==0 for k in ['begin','install','end']) and p.get('outcome')=='Commit' for p in native)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');ap.add_argument('--artifact-manifest');ap.add_argument('--artifact-manifest-sha256');ap.add_argument('--source-manifest');ap.add_argument('--source-manifest-sha256');ap.add_argument('--report');ap.add_argument('--preparation-freeze-sha256');a=ap.parse_args()
 if not a.execute:print(json.dumps({'status':'PREPARED_NOT_EXECUTED','Windows':'NOT_RUN','oldPending':'NOT_TOUCHED','cleanup':'NOT_AUTOMATIC'}));return 0
 need(all([a.artifact_manifest,a.artifact_manifest_sha256,a.source_manifest,a.source_manifest_sha256,a.report,a.preparation_freeze_sha256]),'EXPLICIT_ROOT_FINAL_INPUTS')
 need((R/'.owner').read_bytes()==b'future-classroom-owned-r80-controlled-repair/v1\n' and (P/'.owner').read_bytes()==b'future-classroom-owned-r80-owned-removal-runtime-preparation/v1\n','LOCAL_OWNERS')
 fr=P/'freeze-first.json';need(sha(fr.read_bytes())==a.preparation_freeze_sha256,'ROOT_PINNED_PREPARATION_FREEZE')
 for row in json.loads(fr.read_bytes())['files']:
  got=fact(P/row['path']);need(got['bytes']==row['bytes'] and got['sha256']==row['sha256'],'EXACT_PREPARATION_BYTES')
 plan,af,sf=bind(a.artifact_manifest,a.artifact_manifest_sha256,a.source_manifest,a.source_manifest_sha256)
 report=Path(a.report);D=report.parent;need(report.is_absolute() and D.resolve()==D and D.parent==R and not D.exists() and report.name.endswith('.json'),'NEW_RESULT_ROOT')
 D.mkdir();(D/'.owner').write_bytes(b'future-classroom-owned-r80-owned-removal-runtime-result/v1\n');upload=D/'upload';upload.mkdir();nonce=uuid.uuid4().hex
 for name in SOURCE_NAMES:shutil.copyfile(S/name,upload/name)
 shutil.copyfile(plan['setup']['path'],upload/'Setup.exe');shutil.copyfile(plan['msi']['path'],upload/'FutureClassroom.msi');shutil.copyfile(a.artifact_manifest,upload/'artifact-manifest.json');shutil.copyfile(a.source_manifest,upload/'source-manifest.json')
 c=dict(plan);c.update(runtimeNonce=nonce,runtimeRootName='FutureClassroom-r80-owned-removal-'+nonce,artifactManifestSha256=af['sha256']);configraw=rawjson(c);(upload/'runtime-config.json').write_bytes(configraw)
 inputs={'files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(upload.iterdir())]};inputraw=rawjson(inputs);(upload/'runtime-inputs.json').write_bytes(inputraw)
 start=time.monotonic();ops=[];outcome={'status':'FAIL_OR_UNKNOWN_RETAIN_ALL_ORIGINALS','scope':'GNU_WIN11_EXPLICIT_OWNED_FIXTURE_REMOVAL_NOT_PRODUCTION_RECOVERY','sourceManifest':sf,'artifactManifest':af,'nonce':nonce,'operations':ops,'runtime':'NOT_RUN','cleanup':'NO_AUTOMATIC_SCRATCH_GATE_OR_OLD_NONCE_DELETION','oldEnd':'UNKNOWN_UNCHANGED'};rc=1
 def save():report.write_bytes(rawjson(outcome))
 def call(label,argv,feed=None,maximum=180):
  left=600-(time.monotonic()-start);need(left>0,'ROOT_ORIGINAL_WHOLE_600_EXHAUSTED');budget=min(maximum,left);row={'label':label,'argv':argv,'budgetSeconds':budget,'actualExit':None,'originalLocalParentReaped':False,'remoteReturnUnknown':True};ops.append(row)
  if feed is not None:(D/(label+'.stdin.ps1')).write_bytes(feed)
  with (D/(label+'.stdout.log')).open('xb') as out,(D/(label+'.stderr.log')).open('xb') as err:
   proc=subprocess.Popen(argv,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=out,stderr=err);row['originalLocalPid']=proc.pid
   try:proc.communicate(feed,timeout=budget);row.update(actualExit=proc.returncode,originalLocalParentReaped=True,remoteReturnUnknown=False)
   except subprocess.TimeoutExpired:row['status']='ROOT_TRANSPORT_TIMEOUT_REMOTE_OWNER_UNKNOWN_NO_WINDOWS_KILL';save();raise RuntimeError('ORIGINAL_TRANSPORT_TIMEOUT_RETAIN')
  row['elapsedWholeSeconds']=time.monotonic()-start
  for key in ['stdout','stderr']:
   p=D/(label+'.'+key+'.log');row[key]={'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
  save();return row,(D/(label+'.stdout.log')).read_bytes()
 try:
  t={'nonce':nonce,'sid':plan['expectedUserSid'],'root':None};args,feed=remote(CREATE,t);op,b=call('01-create',args,feed,30);need(op['actualExit']==0,'CREATE_ACTUAL0');created=json.loads(b.decode('utf-8-sig'));root=created['root'];t.update(root=root,startQpc=created['originalStartQpc'],frequency=created['originalFrequency'],configSha256=sha(configraw),inputsSha256=sha(inputraw));outcome['create']=created;outcome['windowsRoot']=root
  op,_=call('02-upload',['scp','-q','-o','BatchMode=yes']+[str(p) for p in sorted(upload.iterdir())]+[HOST+':'+root.replace('\\','/')+'/'],maximum=45);need(op['actualExit']==0,'UPLOAD_ACTUAL0')
  args,feed=remote(INVOKE,t);op,b=call('03-single-explicit-removal',args,feed,maximum=420);outcome['runtimeActualExit']=op['actualExit'];outcome['runtime']='ACTUAL_ORIGINAL_PS_RETURNED';phase=json.loads(b.decode('utf-8-sig'));outcome['phase']=phase
  args,feed=remote(INVENTORY,t);op,b=call('04-inventory',args,feed,30);need(op['actualExit']==0,'INVENTORY_ACTUAL0');inventory=json.loads(b.decode('utf-8-sig'));validate_inventory(inventory);outcome['inventory']=inventory
  download=D/'download';download.mkdir();op,_=call('05-download',['scp','-q','-r','-o','BatchMode=yes',HOST+':'+root.replace('\\','/'),str(download)],maximum=60);need(op['actualExit']==0,'DOWNLOAD_ACTUAL0');local=download/Path(root.replace('\\','/')).name;got=[];dirs=[]
  for p in local.rglob('*'):
   need(not p.is_symlink(),'DOWNLOADED_NO_LINK');rel=p.relative_to(local).as_posix()
   if p.is_dir():dirs.append(rel)
   else:got.append({'path':rel,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
  need({x['path']:(x['bytes'],x['sha256']) for x in got}=={x['path']:(x['bytes'],x['sha256']) for x in inventory['files']} and set(dirs)==set(inventory['directories']),'COMPLETE_DOWNLOADED_BYTE_REPLAY');outcome['downloadVerified']=True;need(json.loads((local/'removal-result.json').read_bytes())==phase,'ORIGINAL_RESULT_DOWNLOAD_EXACT')
  if outcome['runtimeActualExit']==0 and admission(phase):outcome['status']='PASS_GNU_WIN11_EXPLICIT_REMOVAL_COMPLETE_DOWNLOAD_OLD_END_UNKNOWN';rc=0
 except Exception as e:outcome['failureType']=type(e).__name__;outcome['failureCode']=str(e) if re.fullmatch('[A-Z0-9_]+',str(e)) else 'LOCAL_TRANSPORT_OR_DECODE_FAILURE_RETAIN'
 finally:outcome['elapsedSeconds']=time.monotonic()-start;outcome['originalWholeBudgetExceeded']=outcome['elapsedSeconds']>=600;save()
 if outcome['originalWholeBudgetExceeded']:rc=1
 print(json.dumps({'status':outcome['status'],'report':str(report),'reportSha256':sha(report.read_bytes()),'cleanup':outcome['cleanup']}));return rc
if __name__=='__main__':raise SystemExit(main())
