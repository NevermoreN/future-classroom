// TEST-ONLY READ-ONLY INSTRUMENT. No process suspend/terminate, writes, hooks,
// transaction calls, authority packets, or production role invocation.
// Derived exact sealed-Setup observer; no old four-role coverage requirement.
// Captured controls must return; an unobserved fast G remains NOT_OBSERVED.
// Add-Type with System.Management before the one reviewed Setup client starts.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Management;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

public sealed class Fc80SetupObserver {
    [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint a,bool inherit,uint pid);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetProcessTimes(IntPtr h,out long c,out long x,out long k,out long u);
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool QueryFullProcessImageName(IntPtr h,uint f,StringBuilder p,ref uint n);
    [DllImport("kernel32.dll",SetLastError=true)] static extern uint WaitForSingleObject(IntPtr h,uint ms);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetExitCodeProcess(IntPtr h,out uint code);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool CloseHandle(IntPtr h);
    [DllImport("advapi32.dll",SetLastError=true)] static extern bool OpenProcessToken(IntPtr h,uint access,out IntPtr token);
    [DllImport("advapi32.dll",SetLastError=true)] static extern bool GetTokenInformation(IntPtr t,int kind,IntPtr b,uint n,out uint needed);
    [DllImport("shell32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr CommandLineToArgvW(string s,out int n);
    [DllImport("kernel32.dll")] static extern IntPtr LocalFree(IntPtr h);
    // TEST-ONLY native metadata for the authorized native x64 Windows 11
    // observer. No new API enters either normal product or Win7 target code.
    [DllImport("ntdll.dll",ExactSpelling=true)] static extern int NtQueryInformationProcess(IntPtr process,int informationClass,IntPtr data,uint bytes,out uint returnedBytes);
    [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr LocalAlloc(uint flags,UIntPtr bytes);
    [DllImport("kernel32.dll",SetLastError=true)] static extern uint GetProcessId(IntPtr process);
    [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool IsWow64Process2(IntPtr process,out ushort processMachine,out ushort nativeMachine);
    [StructLayout(LayoutKind.Sequential)] struct NativeUnicodeString { public ushort Length,MaximumLength; public IntPtr Buffer; }
    [StructLayout(LayoutKind.Sequential)] struct NativeBasicInformation {
        public int ExitStatus;public IntPtr PebBaseAddress;public UIntPtr AffinityMask;public int BasePriority;
        public UIntPtr UniqueProcessId,InheritedFromUniqueProcessId;
    }
    const int NativeCommandCapacity=65552; // one fixed allocation: 16-byte US + bounded UTF16, no resizing/retry
    const uint Access=0x101000; // PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE
    public sealed class Fact {
        public string CaptureSource,IdentityStatus,Image,Sha256,Sid,Role,CommandStatus,ParentLink;
        public uint Pid,ParentPid; public uint? Transaction; public long CreationFiletime,ParentCreationFiletime;
        public string ParentImage,ParentSid,WaitStatus,ExitStatus,CloseStatus;
        public uint? ActualWait,ActualExitCode; public string[] ExactCandidateArgv;
        public string NativeCommandStatus,NativeCommandBufferFreeStatus,NativeBasicStatus,NativeBasicBufferFreeStatus,ParentPidSource,WmiSupplementStatus;
        public int? NativeCommandNtStatus,NativeBasicNtStatus;
        public uint? NativeCommandReturnLength,NativeBasicReturnLength,NativeBasicPid,NativeBasicParentPid;
        public ushort? NativeCommandLength,NativeCommandMaximumLength;
        public ulong? NativeCommandBufferOffset;
        public uint? AtOriginalOpenWait,AtAuthenticatedCaptureWait;
        public long ArrivalElapsedTicks,OriginalOpenElapsedTicks,AuthenticatedElapsedTicks,MetadataCompleteElapsedTicks;
        internal IntPtr Held;
    }
    public sealed class Report {
        public string Scope="ORIGINAL_HELD_PROCESS_FACTS_NOT_PRODUCT_SETTLEMENT";
        public string NativeMetadataScope="WIN11_NATIVE_X64_TEST_ONLY_CLASS60_AND_PBI_NOT_PRODUCT_OR_WIN7_REQUIREMENT";
        public long StopwatchFrequency=Stopwatch.Frequency;public int ObserverPointerBytes=IntPtr.Size;
        public bool WmiStarted,MissesPossible=true,Closed;
        public string[] Errors,MetadataWarnings,CaptureWarnings; public Fact[] Processes;
    }
    readonly object sync=new object(), lifetime=new object();int activeCaptures;readonly List<Fact> facts=new List<Fact>();readonly List<string> errors=new List<string>();
    readonly List<string> metadataWarnings=new List<string>(),captureWarnings=new List<string>();
    readonly string expectedHash,user,fixedFile,installer,expectedImage;readonly int expectedBytes;
    readonly long startFiletime;readonly Stopwatch clock=Stopwatch.StartNew();readonly int limitMs;
    ManagementEventWatcher watcher;Timer timer;bool closed,stopping,wmiStarted,closeFault;int polling;
    static void Need(bool v,string s) { if(!v) throw new InvalidOperationException(s); }
    static Exception Error(string s) { return new Win32Exception(Marshal.GetLastWin32Error(),s); }
    static string Hex(byte[] b) { return BitConverter.ToString(b).Replace("-","").ToLowerInvariant(); }
    void RecordError(string s) { if(errors.Count<64) errors.Add(s); }
    void MetadataWarning(string s) { if(metadataWarnings.Count<64)metadataWarnings.Add(s); }
    void CaptureWarning(string s) { if(captureWarnings.Count<64)captureWarnings.Add(s); }
    void Close(ref IntPtr h,string stage) {
        if(h==IntPtr.Zero)return;IntPtr original=h;h=IntPtr.Zero;
        if(!CloseHandle(original)) { closeFault=true;throw Error(stage+":unknown_close_never_retry"); }
    }
    static long Creation(IntPtr h) { long c,x,k,u;if(!GetProcessTimes(h,out c,out x,out k,out u))throw Error("creation");return c; }
    static string Image(IntPtr h) {
        StringBuilder b=new StringBuilder(32768);uint n=32768;
        if(!QueryFullProcessImageName(h,0,b,ref n))throw Error("image");return b.ToString();
    }
    string Sid(IntPtr h) {
        IntPtr t=IntPtr.Zero,b=IntPtr.Zero;
        try {
            if(!OpenProcessToken(h,8,out t))throw Error("token_query");uint n;
            GetTokenInformation(t,1,IntPtr.Zero,0,out n);int e=Marshal.GetLastWin32Error();
            Need(e==122&&n>=IntPtr.Size&&n<=4096,"bounded_token_user");b=Marshal.AllocHGlobal((int)n);
            if(!GetTokenInformation(t,1,b,n,out n))throw Error("token_user");
            return new SecurityIdentifier(Marshal.ReadIntPtr(b)).Value;
        } finally { if(b!=IntPtr.Zero)Marshal.FreeHGlobal(b);Close(ref t,"token"); }
    }
    string Hash(string image) {
        // Does not block MSI image retirement: all normal sharing allowed; exact
        // bytes are compared to the final read-back embedded helper overlay image.
        using(FileStream f=new FileStream(image,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete)) {
            Need(f.Length==expectedBytes,"candidate_image_length");
            using(SHA256 s=SHA256.Create())return Hex(s.ComputeHash(f));
        }
    }
    string[] Argv(string command) {
        int n;IntPtr b=CommandLineToArgvW(command,out n);if(b==IntPtr.Zero)throw Error("argv");
        try { Need(n>=1&&n<=6,"bounded_helper_argv");string[] r=new string[n];
            for(int j=0;j<n;j++) { r[j]=Marshal.PtrToStringUni(Marshal.ReadIntPtr(b,j*IntPtr.Size));Need(r[j]!=null&&r[j].Length<=32768,"bounded_arg"); }return r;
        } finally { if(LocalFree(b)!=IntPtr.Zero) { closeFault=true;throw new InvalidOperationException("argv_LocalFree_unknown"); } }
    }
    void FreeNative(ref IntPtr allocation,string stage) {
        if(allocation==IntPtr.Zero)return;IntPtr original=allocation;allocation=IntPtr.Zero;
        if(LocalFree(original)!=IntPtr.Zero){closeFault=true;throw Error(stage+":UNKNOWN_LOCALFREE_NEVER_RETRY");}
    }
    void MetadataDeadline() { Need(clock.ElapsedMilliseconds<=limitMs,"ORIGINAL_METADATA_DEADLINE_EXPIRED"); }
    string NativeCommand(Fact f) {
        IntPtr buffer=IntPtr.Zero;f.NativeCommandStatus="UNKNOWN_NOT_COMPLETED";f.NativeCommandBufferFreeStatus="NOT_ALLOCATED";
        try {
            MetadataDeadline();Need(Creation(f.Held)==f.CreationFiletime&&GetProcessId(f.Held)==f.Pid,"SAME_ORIGINAL_COMMAND_OBJECT");
            buffer=LocalAlloc(0x40,new UIntPtr((uint)NativeCommandCapacity));if(buffer==IntPtr.Zero)throw Error("native_command_LocalAlloc");
            f.NativeCommandBufferFreeStatus="OWNED_NOT_YET_RETURNED";
            uint returned;int status=NtQueryInformationProcess(f.Held,60,buffer,NativeCommandCapacity,out returned);
            f.NativeCommandNtStatus=status;f.NativeCommandReturnLength=returned;
            Need(status==0,"CLASS60_NONZERO_STATUS_UNKNOWN_NO_RETRY");
            Need(returned>=16&&returned<=NativeCommandCapacity,"CLASS60_RETURN_LENGTH_BOUNDED");
            NativeUnicodeString value=(NativeUnicodeString)Marshal.PtrToStructure(buffer,typeof(NativeUnicodeString));
            f.NativeCommandLength=value.Length;f.NativeCommandMaximumLength=value.MaximumLength;
            Need(value.Length>0&&(value.Length&1)==0&&(value.MaximumLength&1)==0&&value.Length<=value.MaximumLength&&value.Length<=65532,"CLASS60_UNICODE_LENGTH_BOUNDED_EVEN");
            long signedBase=buffer.ToInt64(),signedPointer=value.Buffer.ToInt64();
            Need(signedBase>0&&signedPointer>=signedBase,"CLASS60_LOCAL_BUFFER_POINTER_NOT_REMOTE");
            ulong offset=(ulong)(signedPointer-signedBase);f.NativeCommandBufferOffset=offset;
            Need(offset>=16&&offset<=returned&&value.MaximumLength<=returned-offset,"CLASS60_ENTIRE_MAXIMUM_WITHIN_RETURNED_LOCAL_BUFFER");
            byte[] bytes=new byte[value.Length];Marshal.Copy(value.Buffer,bytes,0,bytes.Length);
            string command=new UnicodeEncoding(false,false,true).GetString(bytes);
            Need(command.Length>=1&&command.Length<=32766&&command.IndexOf('\0')<0&&command.IndexOf('\r')<0&&command.IndexOf('\n')<0,"CLASS60_STRICT_UTF16_CLOSED_COMMAND");
            Need(Creation(f.Held)==f.CreationFiletime&&GetProcessId(f.Held)==f.Pid,"SAME_ORIGINAL_COMMAND_OBJECT_AFTER_COPY");
            MetadataDeadline();f.NativeCommandStatus="SUCCESS_VALIDATED_UTF16";return command;
        } finally {
            if(buffer!=IntPtr.Zero)try{FreeNative(ref buffer,"native_command");f.NativeCommandBufferFreeStatus="CHECKED_LOCALFREE_SUCCESS";}
            catch{f.NativeCommandBufferFreeStatus="UNKNOWN_LOCALFREE_NOT_RETRIED";throw;}
        }
    }
    void NativeParentPid(Fact f) {
        IntPtr buffer=IntPtr.Zero;f.NativeBasicStatus="UNKNOWN_NOT_COMPLETED";f.NativeBasicBufferFreeStatus="NOT_ALLOCATED";
        try {
            MetadataDeadline();Need(Creation(f.Held)==f.CreationFiletime&&GetProcessId(f.Held)==f.Pid,"SAME_ORIGINAL_BASIC_OBJECT");
            buffer=LocalAlloc(0x40,new UIntPtr(48));if(buffer==IntPtr.Zero)throw Error("native_basic_LocalAlloc");
            f.NativeBasicBufferFreeStatus="OWNED_NOT_YET_RETURNED";
            uint returned;int status=NtQueryInformationProcess(f.Held,0,buffer,48,out returned);
            f.NativeBasicNtStatus=status;f.NativeBasicReturnLength=returned;
            Need(status==0&&returned==48,"BASIC_EXACT_STATUS_AND_RETURN_LENGTH");
            NativeBasicInformation value=(NativeBasicInformation)Marshal.PtrToStructure(buffer,typeof(NativeBasicInformation));
            ulong actual=value.UniqueProcessId.ToUInt64(),parent=value.InheritedFromUniqueProcessId.ToUInt64();
            Need(actual==f.Pid&&parent>0&&parent<=UInt32.MaxValue&&parent!=actual,"BASIC_ORIGINAL_PID_AND_BOUNDED_PARENT");
            Need(Creation(f.Held)==f.CreationFiletime&&GetProcessId(f.Held)==f.Pid,"SAME_ORIGINAL_BASIC_OBJECT_AFTER_COPY");
            MetadataDeadline();f.NativeBasicPid=(uint)actual;f.NativeBasicParentPid=(uint)parent;f.ParentPid=(uint)parent;
            f.NativeBasicStatus="EXACT_ORIGINAL_HANDLE_BASIC_INFORMATION";f.ParentPidSource="ORIGINAL_HANDLE_PBI_CLASS0";
        } finally {
            if(buffer!=IntPtr.Zero)try{FreeNative(ref buffer,"native_basic");f.NativeBasicBufferFreeStatus="CHECKED_LOCALFREE_SUCCESS";}
            catch{f.NativeBasicBufferFreeStatus="UNKNOWN_LOCALFREE_NOT_RETRIED";throw;}
        }
    }
    void ApplyCommand(Fact f,string command,string source) {
        Need(command.Length<=32768,"bounded_original_command");string[] a=Argv(command);
        Need(String.Equals(a[0],f.Image,StringComparison.OrdinalIgnoreCase),"original_argv0_image");
        string role="UNKNOWN";uint txn;
        if(a.Length==2&&a[1]=="owned-guardian")role="owned-guardian";
        else if(a.Length==2&&a[1]=="owned-test-remove")role="setup-owned-test-remove";
        else if(a.Length==2&&a[1]=="broker")role="broker";
        else if(a.Length==3&&(a[2]=="guardian"||a[2]=="supervisor")&&UInt32.TryParse(a[1],NumberStyles.None,CultureInfo.InvariantCulture,out txn)&&txn!=0){role=a[2];f.Transaction=txn;}
        f.Role=role;f.ExactCandidateArgv=a;f.CommandStatus=source;
    }
    // WMI is a real creation-matched fallback only after authentication and a
    // bounded original-handle native attempt. Never read an engine's CLI.
    static ManagementObjectCollection GetRows(ManagementObjectSearcher q) { q.Options.Timeout=TimeSpan.FromSeconds(2);return q.Get(); }
    void WmiFallback(Fact f,bool needCommand,bool needParent) {
        f.WmiSupplementStatus="UNKNOWN_NO_CREATION_MATCHED_WMI_INSTANCE";
        string columns=needCommand?"ProcessId,ParentProcessId,CreationDate,CommandLine":"ProcessId,ParentProcessId,CreationDate";
        MetadataDeadline();
        using(ManagementObjectSearcher q=new ManagementObjectSearcher("SELECT "+columns+" FROM Win32_Process WHERE ProcessId="+f.Pid.ToString(CultureInfo.InvariantCulture)))
        using(ManagementObjectCollection rows=GetRows(q)) {
            foreach(ManagementObject m in rows) using(m) {
                string d=m["CreationDate"] as string;if(d==null)continue;
                long c=ManagementDateTimeConverter.ToDateTime(d).ToUniversalTime().ToFileTimeUtc();if(Math.Abs(c-f.CreationFiletime)>9)continue;
                MetadataDeadline();uint parent=Convert.ToUInt32(m["ParentProcessId"],CultureInfo.InvariantCulture);
                Need(Creation(f.Held)==f.CreationFiletime&&GetProcessId(f.Held)==f.Pid,"SAME_ORIGINAL_WMI_FALLBACK_OBJECT");
                if(f.ParentPid!=0&&f.ParentPid!=parent){f.ParentPid=0;f.ParentPidSource="UNKNOWN_NATIVE_WMI_CONFLICT";f.Role="UNKNOWN";f.CommandStatus="UNKNOWN_METADATA_CONFLICT";throw new InvalidOperationException("NATIVE_WMI_PARENT_CONFLICT");}
                if(needParent){Need(parent>0&&parent!=f.Pid,"WMI_BOUNDED_PARENT");f.ParentPid=parent;f.ParentPidSource="CREATION_MATCHED_WMI_PARENT_FACT_ONLY";}
                if(needCommand){string cmd=m["CommandLine"] as string;if(cmd==null)continue;ApplyCommand(f,cmd,"EXACT_CREATION_MATCHED_WMI_FACT_ONLY");}
                f.WmiSupplementStatus="ACTUAL_CREATION_MATCHED_WMI_FALLBACK_FACT_ONLY";break;
            }
        }
    }
    void Command(Fact f) {
        f.CommandStatus="UNKNOWN_NO_ORIGINAL_COMMAND";f.Role="UNKNOWN";f.ParentPidSource="UNKNOWN";
        f.WmiSupplementStatus="NOT_REQUESTED_NATIVE_COMMAND_AND_PARENT_COMPLETE";
        try {string command=NativeCommand(f);ApplyCommand(f,command,"EXACT_ORIGINAL_HANDLE_NT_CLASS60_FACT_ONLY");}
        catch(Exception e){MetadataWarning("native_command:"+f.Pid+":"+e.GetType().Name+":"+e.Message);}
        if(closeFault)return;
        try {NativeParentPid(f);}catch(Exception e){MetadataWarning("native_basic:"+f.Pid+":"+e.GetType().Name+":"+e.Message);}
        if(closeFault)return;
        // Valid native bytes with an invalid/unknown argv never grant authority
        // for a different WMI argv. That candidate's role remains UNKNOWN.
        bool needCommand=f.NativeCommandStatus!="SUCCESS_VALIDATED_UTF16";
        bool needParent=f.ParentPid==0;
        if(needCommand||needParent)try{WmiFallback(f,needCommand,needParent);}
        catch(Exception e){MetadataWarning("wmi_fallback:"+f.Pid+":"+e.GetType().Name+":"+e.Message);}
        f.MetadataCompleteElapsedTicks=clock.ElapsedTicks;
    }
    void Parent(Fact f) {
        f.ParentLink="UNKNOWN";
        if(f.ParentPid==0)return;
        foreach(Fact old in facts) if(old.Pid==f.ParentPid&&old.CreationFiletime<=f.CreationFiletime&&((old.Role=="begin"&&f.Role=="broker")||(old.Role=="supervisor"&&f.Role=="guardian"))) {
            if(old.Held==IntPtr.Zero)continue;long c,x,k,u;uint w=WaitForSingleObject(old.Held,0);
            if(!GetProcessTimes(old.Held,out c,out x,out k,out u) || c!=old.CreationFiletime || (w!=0&&w!=258) || (w==0&&x<f.CreationFiletime))continue;
            f.ParentCreationFiletime=old.CreationFiletime;f.ParentImage=old.Image;f.ParentSid=old.Sid;f.ParentLink=f.Role=="broker"?"HELD_ORIGINAL_BEGIN_INSTANCE":"HELD_ORIGINAL_SUPERVISOR_INSTANCE";return;
        }
        IntPtr h=OpenProcess(Access,false,f.ParentPid);if(h==IntPtr.Zero)return;
        try {
            long c=Creation(h);string image=Image(h),sid=Sid(h);
            Need(c<=f.CreationFiletime,"parent_born_after_child");
            string win=Environment.GetFolderPath(Environment.SpecialFolder.Windows);
            bool engine=String.Equals(image,Path.Combine(win,@"System32\msiexec.exe"),StringComparison.OrdinalIgnoreCase)||String.Equals(image,Path.Combine(win,@"SysWOW64\msiexec.exe"),StringComparison.OrdinalIgnoreCase);
            if(f.Role=="owned-guardian"&&String.Equals(image,expectedImage,StringComparison.OrdinalIgnoreCase)&&sid==user){
                f.ParentCreationFiletime=c;f.ParentImage=image;f.ParentSid=sid;f.ParentLink="ORIGINAL_SETUP_PARENT_INSTANCE_FACT_NOT_SESSION_AUTHORITY";
            }
            else if((f.Role=="begin"||f.Role=="supervisor")&&engine&&(sid==user||sid=="S-1-5-18")) {
                f.ParentCreationFiletime=c;f.ParentImage=image;f.ParentSid=sid;f.ParentLink="ORIGINAL_ENGINE_INSTANCE_FACT_NOT_SESSION_ID";
            }
        } finally { Close(ref h,"parent_query"); }
    }
    void Capture(uint pid,string source) {
        // Called immediately from ProcessStartTrace callback; original OpenProcess
        // occurs before slow hash/WMI work. Shared service is never a candidate.
        long arrivalTicks=clock.ElapsedTicks;
        lock(lifetime) { if(stopping||closed)return;activeCaptures++; }
        IntPtr h=IntPtr.Zero;
        try {
            h=OpenProcess(Access,false,pid);if(h==IntPtr.Zero)return;
            long openTicks=clock.ElapsedTicks;uint initialWait=WaitForSingleObject(h,0);
            lock(sync) {
                if(closed||stopping||clock.ElapsedMilliseconds>limitMs||closeFault)return;
                long c=Creation(h);if(c<startFiletime)return;
                foreach(Fact old in facts)if(old.Pid==pid&&old.CreationFiletime==c)return;
                string image=Image(h);
                if(!String.Equals(image,expectedImage,StringComparison.OrdinalIgnoreCase))return;
                string hash=Hash(image);if(hash!=expectedHash)return;
                string sid=Sid(h);if(sid!=user)return;
                Need(facts.Count<32,"bounded_original_candidate_count");
                Fact f=new Fact();f.Pid=pid;f.CreationFiletime=c;f.Image=image;f.Sha256=hash;f.Sid=sid;f.CaptureSource=source;f.IdentityStatus="ORIGINAL_QUERY_SYNC_HANDLE_EXACT_IMAGE_BYTES_USER";
                f.ArrivalElapsedTicks=arrivalTicks;f.OriginalOpenElapsedTicks=openTicks;f.AtOriginalOpenWait=initialWait;f.AtAuthenticatedCaptureWait=WaitForSingleObject(h,0);f.AuthenticatedElapsedTicks=clock.ElapsedTicks;
                f.Held=h;h=IntPtr.Zero;facts.Add(f);
                try { Command(f);Parent(f); } catch(Exception e) { MetadataWarning("candidate_metadata:"+pid+":"+e.GetType().Name+":"+e.Message); }
            }
        } catch(Exception e) { lock(sync){if(closeFault)RecordError("capture_close_fault:"+pid+":"+e.GetType().Name+":"+e.Message);else CaptureWarning("capture_not_authenticated:"+pid+":"+e.GetType().Name+":"+e.Message);} }
        finally { try { try { Close(ref h,"uncaptured_original"); } catch(Exception e) { lock(sync)RecordError(e.Message); } } finally { lock(lifetime) { activeCaptures--;Monitor.PulseAll(lifetime); } } }
    }
    void Poll(object ignored) {
        if(closed||stopping||clock.ElapsedMilliseconds>limitMs||Interlocked.Exchange(ref polling,1)!=0)return;
        try {
            // Names only, then original-handle image/hash/token filtering; no foreign CLI.
            Process[] ps=Process.GetProcesses();
            foreach(Process p in ps) using(p) {
                try { if(String.Equals(p.ProcessName,"Setup",StringComparison.OrdinalIgnoreCase))Capture((uint)p.Id,"10MS_FIXED_SETUP_NAME_POLL"); }
                catch(Exception e) { lock(sync)CaptureWarning("poll_candidate_not_authenticated:"+e.GetType().Name); }
            }
        } catch(Exception e) { lock(sync)CaptureWarning("poll_enumeration_not_coverage_authority:"+e.GetType().Name); }
        finally { Interlocked.Exchange(ref polling,0); }
    }
    public Fc80SetupObserver(string setupImage,string embeddedImageSha256,int embeddedImageBytes,string expectedUserSid,int phaseMaximumMs) {
        ushort ownMachine,nativeMachine;
        Need(IntPtr.Size==8&&Environment.Is64BitProcess&&IsWow64Process2(GetCurrentProcess(),out ownMachine,out nativeMachine)&&ownMachine==0&&nativeMachine==0x8664,"WIN11_TEST_OBSERVER_NATIVE_AMD64_CALLER_ONLY");
        Need(Marshal.SizeOf(typeof(NativeUnicodeString))==16&&Marshal.OffsetOf(typeof(NativeUnicodeString),"Buffer").ToInt32()==8&&Marshal.SizeOf(typeof(NativeBasicInformation))==48&&Marshal.OffsetOf(typeof(NativeBasicInformation),"UniqueProcessId").ToInt32()==32&&Marshal.OffsetOf(typeof(NativeBasicInformation),"InheritedFromUniqueProcessId").ToInt32()==40,"CHECKED_NATIVE_X64_QUERY_LAYOUTS");
        Need(Regex.IsMatch(embeddedImageSha256??"",@"\A[0-9a-f]{64}\z")&&embeddedImageBytes>0&&embeddedImageBytes<=40*1024*1024,"explicit_actual_overlay_identity");
        Need(phaseMaximumMs>0&&phaseMaximumMs<=150000,"phase_original_finite_budget");
        using(WindowsIdentity own=WindowsIdentity.GetCurrent())Need(own.User.Value==expectedUserSid,"observer_original_user");
        Need(Path.IsPathRooted(setupImage)&&Path.GetFullPath(setupImage)==setupImage&&Path.GetFileName(setupImage)=="Setup.exe","EXACT_FIXED_SETUP_PATH");expectedImage=setupImage;expectedHash=embeddedImageSha256;expectedBytes=embeddedImageBytes;user=expectedUserSid;limitMs=phaseMaximumMs;startFiletime=DateTime.UtcNow.ToFileTimeUtc();
        installer=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),"Installer");
        fixedFile=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),@"Programs\FutureClassroom\fc-bootstrap.exe");
        watcher=new ManagementEventWatcher(new WqlEventQuery("SELECT * FROM Win32_ProcessStartTrace WHERE ProcessName = 'Setup.exe'"));
        watcher.EventArrived+=delegate(object sender,EventArrivedEventArgs e) {
            try { Capture(Convert.ToUInt32(e.NewEvent["ProcessID"],CultureInfo.InvariantCulture),"PROCESS_START_TRACE"); }
            catch(Exception x) { lock(sync)CaptureWarning("wmi_callback_not_coverage_authority:"+x.GetType().Name); }
        };
        try { watcher.Start();wmiStarted=true;timer=new Timer(Poll,null,0,10); }
        catch { watcher.Dispose();throw; } // caller MUST abort before msiexec if setup fails
    }
    void Refresh(Fact f) {
        if(f.Held==IntPtr.Zero)return;
        uint w=WaitForSingleObject(f.Held,0);f.ActualWait=w;
        if(w==0) {
            uint exit;if(!GetExitCodeProcess(f.Held,out exit)) { f.ExitStatus="UNKNOWN_GET_EXIT_ERROR_"+Marshal.GetLastWin32Error();return; }
            f.WaitStatus="ORIGINAL_OBJECT_SIGNALED";f.ActualExitCode=exit;f.ExitStatus="ACTUAL_ORIGINAL_GET_EXIT_CODE";
        } else { f.WaitStatus=w==258?"ORIGINAL_OBJECT_STILL_RUNNING":"UNKNOWN_WAIT_ERROR_"+Marshal.GetLastWin32Error();f.ExitStatus="UNKNOWN"; }
    }
    public Report Snapshot() { lock(sync) {
        foreach(Fact f in facts)Refresh(f);
        Report r=new Report();r.WmiStarted=wmiStarted;r.Closed=closed;r.Errors=errors.ToArray();r.MetadataWarnings=metadataWarnings.ToArray();r.CaptureWarnings=captureWarnings.ToArray();r.Processes=facts.ToArray();return r;
    } }
    public Report FinishAndClose() {
        lock(lifetime)stopping=true;
        if(timer!=null) { timer.Change(Timeout.Infinite,Timeout.Infinite);timer.Dispose();timer=null; }
        // Stop watcher before taking sync, so a callback cannot deadlock Stop.
        try { if(watcher!=null) { watcher.Stop();watcher.Dispose();watcher=null; } }
        catch(Exception e) { lock(sync)RecordError("watcher_stop:"+e.GetType().Name); }
        lock(lifetime) {
            while(activeCaptures!=0) {
                int remaining=limitMs-(int)clock.ElapsedMilliseconds;
                if(remaining<=0)throw new InvalidOperationException("UNKNOWN_CALLBACKS_NOT_DRAINED_RETAIN_HELD_HANDLES");
                Monitor.Wait(lifetime,Math.Min(remaining,5000));
            }
        }
        lock(sync) {
            // Relink only already captured original facts before closing any handle.
            // No late PID disappearance, WMI command guess, or replacement handle
            // can turn a missing role into known original coverage.
            if(!closed)foreach(Fact f in facts) if(f.ParentLink=="UNKNOWN") {
                try { Parent(f); }catch(Exception e){MetadataWarning("final_parent:"+f.Pid+":"+e.GetType().Name+":"+e.Message);}
            }
            if(!closed)foreach(Fact f in facts) { Refresh(f);try { Close(ref f.Held,"original_process");f.CloseStatus="CHECKED_CLOSE_SUCCESS"; }catch(Exception e) { f.CloseStatus="UNKNOWN_CLOSE_NOT_RETRIED";RecordError(e.Message); } }
            if(closeFault)RecordError("CHECKED_NATIVE_CLOSE_OR_FREE_FAILED");
            closed=true;Report r=new Report();r.WmiStarted=wmiStarted;r.Closed=closed;r.Errors=errors.ToArray();r.MetadataWarnings=metadataWarnings.ToArray();r.CaptureWarnings=captureWarnings.ToArray();r.Processes=facts.ToArray();return r;
        }
    }
}
