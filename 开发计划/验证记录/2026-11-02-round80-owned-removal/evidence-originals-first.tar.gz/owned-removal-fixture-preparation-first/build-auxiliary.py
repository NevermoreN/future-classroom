"""Default inert, root-only separate DEV feature helper+DLL compiler producer."""
import argparse, json, os, signal, subprocess, time
from common import *

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--execute', action='store_true')
    p.add_argument('--source-sha')
    p.add_argument('--inventory', type=Path)
    p.add_argument('--inventory-sha256')
    p.add_argument('--output-name')
    a = p.parse_args()
    if not a.execute:
        print(json.dumps({'status': 'PREPARED_NOT_RUN', 'cargo': 'NOT_RUN', 'windows': 'NOT_CONTACTED', 'formal_ci': False, 'payloadProductRecompiled': False}))
        return 0
    need(a.source_sha and a.inventory and a.inventory_sha256 and a.output_name, 'all explicit compiler bindings')
    need(re.fullmatch('owned-removal-auxiliary-[a-z0-9-]{1,64}', a.output_name), 'new owned output name')
    need(read(R / '.owner') == b'future-classroom-owned-r80-controlled-repair/v1\n', 'R ownership')
    before = source_check(a.source_sha, a.inventory, a.inventory_sha256)
    encoded = scope()
    builder = load_builder()
    fixed_payload(builder)
    out = R / a.output_name
    out.mkdir()
    (out / '.owner').write_text('future-classroom-owned-removal-auxiliary/v1\n')
    (out / 'artifacts').mkdir()
    (out / 'inputs-before.json').write_bytes(before)

    def localfact(path):
        x = fact(path)
        x['path'] = str(path.relative_to(out))
        return x
    report = {'status': 'FAIL_RETAIN_ORIGINALS', 'formal_ci': False, 'features': [FEATURE], 'source_root': str(W), 'source_head': a.source_sha, 'inventory_sha256': a.inventory_sha256, 'target': TARGET, 'scope': {'bytes': len(encoded), 'sha256': sha(encoded.encode()), 'name': 'FC_OWNED_REMOVAL_SCOPE_HEX'}, 'runtime': 'NOT_RUN', 'productionAdmission': False, 'product_payload': 'ORIGINAL_C508_COMPLETE14_NOT_RECOMPILED', 'commands': [], 'producer': fact(Path(__file__)), 'controllerCommon': fact(HERE / 'common.py'), 'packagingDependencies': TOOL_PINS, 'inputs_before': localfact(out / 'inputs-before.json')}
    env = os.environ.copy()
    removed = ['CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER']
    for k in removed:
        env.pop(k, None)
    scoped = {'CARGO_BUILD_JOBS': '2', 'CARGO_TARGET_DIR': str(R / 'target-first'), 'CARGO_TARGET_I686_PC_WINDOWS_GNU_LINKER': 'i686-w64-mingw32-gcc', 'RUSTFLAGS': '-C target-feature=+crt-static -C link-arg=-Wl,--major-subsystem-version,6,--minor-subsystem-version,1'}
    env.update(scoped)
    env['FC_OWNED_REMOVAL_SCOPE_HEX'] = encoded
    report['environment'] = scoped
    report['removed_environment_keys'] = removed

    def save():
        (out / 'evidence.json').write_text(json.dumps(report, indent=2) + '\n')

    def invoke(name, argv, budget):
        start = time.monotonic()
        child = subprocess.Popen(argv, cwd=W, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
        expired = False
        try:
            stdout, stderr = child.communicate(timeout=budget)
        except subprocess.TimeoutExpired:
            expired = True
            try:
                os.killpg(child.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                stdout, stderr = child.communicate(timeout=10)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                stdout, stderr = child.communicate()
        log = out / (name + '.stdout.jsonl')
        err = out / (name + '.stderr.log')
        log.write_bytes(stdout)
        err.write_bytes(stderr)
        row = {'name': name, 'argv': argv, 'actual_exit': child.returncode, 'parent_reaped': child.poll() is not None, 'timed_out': expired, 'seconds': time.monotonic() - start, 'budget_seconds': budget, 'stdout': localfact(log), 'stderr': localfact(err)}
        return (row, stdout)
    save()
    try:
        for name, argv in [('cargo-version', ['cargo', '--version']), ('rustc-version', ['rustc', '-Vv']), ('linker-version', ['i686-w64-mingw32-gcc', '--version'])]:
            row, _ = invoke(name, argv, 15)
            report.setdefault('tool_commands', []).append(row)
            save()
            need(row['actual_exit'] == 0 and (not row['timed_out']), 'actual tool version')
        row, raw = invoke('metadata', ['cargo', 'metadata', '--offline', '--locked', '--no-deps', '--format-version', '1'], 60)
        report['metadata_command'] = row
        save()
        need(row['actual_exit'] == 0 and (not row['timed_out']), 'actual metadata completion')
        metadata = json.loads(raw)
        need(metadata['workspace_root'] == str(W) and metadata['target_directory'] == str(R / 'target-first'), 'same workspace metadata')
        for phase in ROLES:
            row, raw = invoke(phase, command(phase, R / 'target-first'), 900)
            report['commands'].append(row)
            save()
            need(row['actual_exit'] == 0 and row['parent_reaped'] and (not row['timed_out']), 'actual compiler completion')
            _, _, binary = select_artifact(phase, raw, metadata, R / 'target-first')
            copy = out / 'artifacts' / ROLES[phase][2]
            copy.write_bytes(binary)
            row['artifact'] = localfact(copy)
            source_check(a.source_sha, a.inventory, a.inventory_sha256)
            need(scope() == encoded, 'scope unchanged')
            save()
        source_check(a.source_sha, a.inventory, a.inventory_sha256)
        need(scope() == encoded, 'scope unchanged')
        (out / 'inputs-after.json').write_bytes(before)
        report['inputs_after'] = localfact(out / 'inputs-after.json')
        report['sourceUnchanged'] = True
        report['status'] = 'DEV_OWNED_REMOVAL_AUXILIARY_BUILD_ONLY'
        save()
        admit_auxiliary(out / 'evidence.json', sha(read(out / 'evidence.json')), a.source_sha, a.inventory, a.inventory_sha256)
    except BaseException as e:
        report['status'] = 'FAIL_RETAIN_ORIGINALS'
        report['error'] = type(e).__name__ + ': ' + str(e)
        report['sourceUnchanged'] = rows() == json.loads(before)['sources']
        save()
        raise
    print(json.dumps({'status': report['status'], 'evidence': fact(out / 'evidence.json'), 'runtime': 'NOT_RUN'}))
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
