"""Fixed local preparation helpers. Importing performs no build or mutation."""
from pathlib import Path
import hashlib, json, re, runpy, struct, subprocess
R = Path('/tmp/fc-round80-controlled-repair')
W = R / 'checkout-52d6392-first'
HERE = Path(__file__).resolve().parent
TARGET = 'i686-pc-windows-gnu'
FEATURE = 'owned-test-removal'
FIXTURE_SOURCE = '33c11f5e41cce727746aeb5b5801b0e87eaf0f41'
FIXTURE_INVENTORY = 'f1d27c86e910ab6e0d8f1f45d299a00fce569a8d24f73e84de90086f906bfe23'
SCOPE = R / 'owned-removal-implementation-first/scope.hex'
SCOPE_SHA = '5107d3664ab101faf10bf44dd71789ed51d0addf7f7e62ff217dac62c8ccf34b'
OLD = R / 'controlled-product-package-first'
OLD_REPORT_SHA = '6af236d4087f68383ecaea38981bc3b2cf1b7ea7ec0b69cc7fe5e6f2c3e3d943'
OLD_SOURCE = 'c50882df40b86248e3e2d4e404d0fbe8e43e30a9'
ROLES = {'lifecycle-compile': ('fc-bootstrap', 'fc-installer-lifecycle', 'fc-installer-lifecycle.exe', 'crates/fc-bootstrap/src/bin/fc-installer-lifecycle.rs'), 'guard-library-compile': ('fc-windows', 'fc_windows', 'fc_windows.dll', 'crates/fc-windows/src/lib.rs')}

def need(ok, label):
    if not ok:
        raise ValueError(label)

def sha(b):
    return hashlib.sha256(b).hexdigest()

def read(p, limit=64 * 1024 * 1024):
    p = Path(p)
    need(p.is_file() and (not p.is_symlink()) and (0 <= p.stat().st_size <= limit), 'bounded regular file ' + str(p))
    return p.read_bytes()

def fact(p):
    b = read(p)
    return {'path': str(p), 'bytes': len(b), 'sha256': sha(b)}

def relative(root, name):
    need(isinstance(name, str) and name and (not name.startswith('/')) and (':' not in name) and ('\\' not in name) and all((x not in ('', '.', '..') for x in name.split('/'))), 'safe member')
    return root / name

def bound(root, row):
    need(set(row) == {'path', 'bytes', 'sha256'}, 'exact member fact')
    p = relative(root, row['path'])
    f = fact(p)
    need(f['bytes'] == row['bytes'] and f['sha256'] == row['sha256'], 'original byte fact ' + row['path'])
    return p

def rows():
    paths = sorted({*W.glob('crates/**/*.rs'), *W.glob('crates/**/Cargo.toml'), W / 'Cargo.toml', W / 'Cargo.lock', *W.glob('.cargo/*'), *W.glob('rust-toolchain*')})
    return [{'path': str(p.relative_to(W)), 'bytes': len(read(p)), 'sha256': sha(read(p))} for p in paths if p.is_file()]

def source_check(head, inventory, pin):
    need(head == FIXTURE_SOURCE and pin == FIXTURE_INVENTORY, 'exact approved source/inventory pins')
    raw = read(inventory)
    need(sha(raw) == pin, 'frozen inventory SHA')
    data = json.loads(raw)
    need(data['sourceBase'] == head and rows() == data['sources'], 'complete Rust/Cargo/toolchain inputs')
    need(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, timeout=10, text=True).strip() == head, 'actual HEAD')
    return raw

def scope():
    b = read(SCOPE, 81920)
    need(len(b) == 3576 and sha(b) == SCOPE_SHA and re.fullmatch(b'[0-9a-f]+', b), 'fixed compile scope bytes')
    need(len(bytes.fromhex(b.decode())) == 1788 and sha(bytes.fromhex(b.decode())) == 'e30eb74388fda4aab20e3953a568b601889bb5a26f25960fa36e4574829dfacf', 'fixed decoded scope')
    return b.decode('ascii')

def load_builder():
    for name, pin in TOOL_PINS.items():
        need(sha(read(W / name)) == pin, 'frozen package dependency ' + name)
    b = runpy.run_path(str(W / 'scripts/package-msi-candidate.py'))
    b['configure_source_root'](W)
    return b

def fixed_payload(builder):
    report_raw = read(OLD / 'report.json')
    need(sha(report_raw) == OLD_REPORT_SHA, 'original package report')
    report = json.loads(report_raw)
    need(report['source_checkout']['head'] == OLD_SOURCE and report['payload_extraction'] == 'EXACT_BYTES_MATCH' and (len(report['payloads']) == 14), 'original proven complete14')
    payload = {}
    for row in report['payloads']:
        data = read(relative(OLD / 'payload', row['path']), 30 * 1024 * 1024)
        need(len(data) == row['size'] and sha(data) == row['sha256'] and (row['component_guid'] == builder['component_code'](row['path'])), 'original payload bytes/GUID')
        payload[row['path']] = data
    need(read(W / 'packaging/CONTROLLED-MSI-CANDIDATE.md') == payload['MSI-CANDIDATE.txt'], 'original instruction bytes still exact')
    setup = read(OLD / 'Setup.exe')
    need(sha(setup) == report['setup']['sha256'], 'original Setup')
    n = struct.unpack('<I', setup[-20:-16])[0]
    manifest = setup[-20 - n:-20]
    need(sha(manifest) == report['lifecycle_binary']['manifest_sha256'], 'original complete FCLM73')
    need(builder['lifecycle_manifest'](report['source_manifest']['version'], payload) == manifest, 'all14 raw manifest exact')
    source = Path(report['source_zip']['path'])
    raw = read(source)
    need(sha(raw) == report['source_zip']['sha256'] and len(raw) == report['source_zip']['size'], 'original source ZIP')
    need(sha(read(OLD / 'FutureClassroom.msi')) == report['msi']['sha256'], 'original MSI unchanged')
    summary = read(OLD / 'msi-summary.stdout.log')
    old_summary = [x for x in report['commands'] if x['name'] == 'msi-summary']
    need(len(old_summary) == 1 and sha(summary) == old_summary[0]['stdout']['sha256'], 'original summary')
    return (report, payload, manifest, source, raw, package_code(summary))

def package_code(summary):
    found = re.findall(b'^Revision number \\(UUID\\): \\{([0-9A-F]{8}(?:-[0-9A-F]{4}){3}-[0-9A-F]{12})\\}\\r?$', summary, re.M)
    need(len(found) == 1, 'actual PackageCode summary')
    return found[0].decode()
TOOL_PINS = {'scripts/package-msi-candidate.py': 'aa1984c82abcaf9df339da5422dbbe6988ee68f04a33c02aff60565117719e47', 'scripts/package-probe.py': 'bf8339c74b958ae15fb63e04cf135fb13e633694d34453858768267a773ec940', 'scripts/audit-pe.py': '6e3669be5cbf697d87502ba4f3c632f33020659ad4117dcea5f616e0d182c5cb', 'scripts/controlled-setup-seal.py': '935d679cbb0704ab079eddcc38581dd9e01e6eb02e8f2d7f596204fb8ff0aaae', 'packaging/CONTROLLED-MSI-CANDIDATE.md': '5995cd920d173e401a7767f2a86974d28b65b0927e866882aa39a8227d9d7634'}

def command(phase, target_dir):
    package, target, leaf, _ = ROLES[phase]
    a = ['cargo', 'build', '--release', '--offline', '--locked', '-p', package]
    a += ['--lib'] if phase == 'guard-library-compile' else ['--bin', target]
    return a + ['--features', FEATURE, '--target', TARGET, '--target-dir', str(target_dir), '--message-format=json']

def select_artifact(phase, raw, metadata, target_dir):
    package_name, target, leaf, src = ROLES[phase]
    packages = [p for p in metadata['packages'] if p['name'] == package_name and p['id'] in metadata['workspace_members']]
    need(len(packages) == 1, 'one workspace package')
    p = packages[0]
    need(p['source'] is None and p['manifest_path'] == str(W / 'crates' / package_name / 'Cargo.toml'), 'exact workspace package')
    messages = [json.loads(line) for line in raw.splitlines() if line.startswith(b'{')]
    selected = [m for m in messages if m.get('reason') == 'compiler-artifact' and m.get('package_id') == p['id'] and (m.get('target', {}).get('name') == target)]
    need(len(selected) == 1, 'one actual original artifact')
    m = selected[0]
    targets = [t for t in p['targets'] if t['name'] == target]
    need(len(targets) == 1 and m['target'] == targets[0] and (targets[0]['src_path'] == str(W / src)), 'original same-metadata target')
    need(m['manifest_path'] == p['manifest_path'] and m['profile']['test'] is False and (m['profile']['opt_level'] != '0') and (set(m['features']) == {'default', FEATURE}), 'feature non-test optimized artifact')
    if phase == 'guard-library-compile':
        need(set(m['target']['crate_types']) == {'rlib', 'cdylib'} and m['executable'] is None, 'actual cdylib')
        files = [Path(f) for f in m['filenames'] if Path(f).name == leaf]
    else:
        need(m['target']['kind'] == ['bin'] and m['target']['crate_types'] == ['bin'], 'normal binary target')
        files = [Path(m['executable'])]
    need(len(files) == 1 and files[0].name == leaf and (files[0].parent == target_dir / TARGET / 'release'), 'original target release location')
    data = read(files[0], 32 * 1024 * 1024)
    need(data, 'nonempty compiled bytes')
    need(data[:2] == b'MZ' and len(data) >= 64, 'PE image')
    pe = struct.unpack_from('<I', data, 60)[0]
    need(pe + 96 <= len(data) and data[pe:pe + 4] == b'PE\x00\x00' and (struct.unpack_from('<H', data, pe + 4)[0] == 332) and (struct.unpack_from('<H', data, pe + 24)[0] == 267), 'x86 PE32')
    if phase == 'lifecycle-compile':
        need(struct.unpack_from('<H', data, pe + 92)[0] == 2, 'GUI helper subsystem')
    return (m, files[0], data)

def admit_auxiliary(path, pin, head, inventory, inventory_pin):
    need(sha(read(path)) == pin, 'exact original auxiliary producer SHA')
    data = json.loads(read(path))
    root = path.parent
    need(data['status'] == 'DEV_OWNED_REMOVAL_AUXILIARY_BUILD_ONLY' and data['source_head'] == head and (data['formal_ci'] is False) and (data['features'] == [FEATURE]) and (data['runtime'] == 'NOT_RUN'), 'separate DEV auxiliary provenance')
    source_check(head, inventory, inventory_pin)
    need(data['producer'] == fact(HERE / 'build-auxiliary.py') and data['controllerCommon'] == fact(HERE / 'common.py') and (data['packagingDependencies'] == TOOL_PINS), 'exact producer/controller/package inputs')
    need(data['scope'] == {'bytes': 3576, 'sha256': SCOPE_SHA, 'name': 'FC_OWNED_REMOVAL_SCOPE_HEX'} and scope(), 'compiled scope identity')
    need(data['inventory_sha256'] == inventory_pin and data['sourceUnchanged'] is True, 'compiler source closure')
    before = read(bound(root, data['inputs_before']))
    after = read(bound(root, data['inputs_after']))
    need(before == after and sha(before) == inventory_pin and (json.loads(before)['sources'] == rows()), 'original before/after entire compiler input closure')
    need(data['metadata_command']['actual_exit'] == 0 and data['metadata_command']['parent_reaped'] is True and (data['metadata_command']['timed_out'] is False), 'metadata actual completion')
    mc = data['metadata_command']
    need(mc['argv'] == ['cargo', 'metadata', '--offline', '--locked', '--no-deps', '--format-version', '1'], 'closed metadata argv')
    metadata = json.loads(read(bound(root, mc['stdout'])))
    bound(root, mc['stderr'])
    target_dir = R / 'target-first'
    need(metadata['version'] == 1 and metadata['workspace_root'] == str(W) and (metadata['target_directory'] == str(target_dir)), 'metadata original location')
    need(len(data['commands']) == 2 and {x['name'] for x in data['commands']} == set(ROLES), 'exactly two auxiliary compiler phases')
    artifacts = {}
    for c in data['commands']:
        need(c['actual_exit'] == 0 and type(c['actual_exit']) is int and (c['parent_reaped'] is True) and (c['timed_out'] is False) and (c['argv'] == command(c['name'], target_dir)), 'actual fixed compiler completion')
        _, _, binary = select_artifact(c['name'], read(bound(root, c['stdout'])), metadata, target_dir)
        bound(root, c['stderr'])
        copy = bound(root, c['artifact'])
        need(read(copy) == binary, 'copied bytes equal actual selected output')
        artifacts[c['name']] = binary
    return (data, artifacts)
