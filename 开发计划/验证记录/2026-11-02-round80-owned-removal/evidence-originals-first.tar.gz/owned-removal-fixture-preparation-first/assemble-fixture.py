"""Default inert assembly of a separate DEV explicit-removal fixture, no runtime."""
import argparse, json, os
from types import SimpleNamespace
from common import *
TOOLS = R / 'inner-guard-probe-tools-first'
TOOLS_SHA = 'd82866321cc565890c38b494f7dd2ae6afa2fed8d4ae55270d7c4e931562099d'
ENV_SHA = 'd0b2d946aba5c21d94713c6e17cfa90a5c85c74dfa00d2336d4cbf88f05b37a0'
BINDING = R / 'owned-removal-implementation-first/scope-binding.json'
BINDING_SHA = '00a16aba5e3c744509c40001395a5d9dc9b98f7def518bbe0b34ca41ddf299af'
SNAPSHOT = R / 'pending-readonly-retrieval-first/report.json'
SNAPSHOT_SHA = '8a51d4c50426fded71da57455243142c8a9858ec005d3ee701c76515e83ff78f'

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--execute', action='store_true')
    p.add_argument('--source-sha')
    p.add_argument('--inventory', type=Path)
    p.add_argument('--inventory-sha256')
    p.add_argument('--producer', type=Path)
    p.add_argument('--producer-sha256')
    p.add_argument('--output-name')
    a = p.parse_args()
    if not a.execute:
        print(json.dumps({'status': 'PREPARED_NOT_RUN', 'assembly': 'NOT_RUN', 'windows': 'NOT_CONTACTED', 'normalReleaseAdmission': False}))
        return 0
    need(all([a.source_sha, a.inventory, a.inventory_sha256, a.producer, a.producer_sha256, a.output_name]), 'all explicit source/producer pins')
    need(re.fullmatch('owned-removal-package-[a-z0-9-]{1,64}', a.output_name), 'new owned package output name')
    need(read(R / '.owner') == b'future-classroom-owned-r80-controlled-repair/v1\n', 'R ownership')
    builder = load_builder()
    old, payload, original_manifest, source, raw, old_code = fixed_payload(builder)
    producer, artifacts = admit_auxiliary(a.producer, a.producer_sha256, a.source_sha, a.inventory, a.inventory_sha256)
    need(sha(read(BINDING)) == BINDING_SHA and sha(read(SNAPSHOT)) == SNAPSHOT_SHA, 'original scope/snapshot reports')
    binding = json.loads(read(BINDING))
    snap = json.loads(read(SNAPSHOT))['originalNativeSnapshot']['capture']
    need(binding['scopeBytes'] == 1788 and binding['scopeSha256'] == 'e30eb74388fda4aab20e3953a568b601889bb5a26f25960fa36e4574829dfacf' and (binding['envBytes'] == 3576) and (binding['envSha256'] == SCOPE_SHA), 'exact compiled scope mapping')
    need(sha(read(TOOLS / 'tools.json')) == TOOLS_SHA and sha(read(TOOLS / 'child-environment.json')) == ENV_SHA, 'reviewed original packaging tool/environment manifests')
    tools = json.loads(read(TOOLS / 'tools.json'))
    environment = json.loads(read(TOOLS / 'child-environment.json'))
    need(set(environment) == {'LD_LIBRARY_PATH', 'LC_ALL', 'GIO_USE_VFS', 'GSETTINGS_BACKEND'} and environment['LD_LIBRARY_PATH'] == str(TOOLS / 'root/usr/lib/x86_64-linux-gnu'), 'fixed local packaging environment')
    for key, row in tools.items():
        need(sha(read(Path(row['path']))) == row['sha256'], 'original packaging tool ' + key)
    provenance = {'source_sha': a.source_sha, 'current_inputs_verified': len(json.loads(read(a.inventory))['sources']), 'result_sha256': a.producer_sha256, 'target': TARGET, 'development_fixture_only': True, 'formal_ci': False, 'profile_test': False, 'features': [FEATURE], 'artifact_role': 'SEPARATE_OWNED_REMOVAL_AUXILIARY_NOT_NORMAL_RELEASE', 'payload_source_sha': OLD_SOURCE, 'compiled_scope_env_sha256': SCOPE_SHA}
    out = R / a.output_name
    need(not out.exists(), 'output must not exist')
    args = SimpleNamespace(controlled=True, output_dir=out, msibuild_sha256=tools['msibuild']['sha256'], **{k: Path(tools[k]['path']) for k in ('wixl', 'msibuild', 'msiinfo', 'msiextract', 'objdump')})
    previous = {k: os.environ.get(k) for k in environment}
    os.environ.update(environment)
    try:
        report = builder['assemble'](args, raw, source, old['source_manifest'], dict(payload), artifacts['lifecycle-compile'], provenance, artifacts['guard-library-compile'])
        need(report['status'] == 'PASS' and report['payloads'] == old['payloads'] and (report['msi_contract']['payload_files'] == 14) and (report['payload_extraction'] == 'EXACT_BYTES_MATCH'), 'full original14 MSI extraction closure')
        need(report['authoring']['product_code'] == old['authoring']['product_code'] and report['authoring']['upgrade_code'] == old['authoring']['upgrade_code'], 'unchanged product/family')
        helper = read(out / 'lifecycle/fc-installer-lifecycle.exe')
        prefix, records = builder['parse_lifecycle_image'](helper)
        need(prefix == artifacts['lifecycle-compile'] and helper[-20 - len(original_manifest):-20] == original_manifest, 'new auxiliary prefix plus original raw complete manifest')
        new_code = package_code(read(out / 'msi-summary.stdout.log'))
        need(new_code != old_code, 'new PackageCode must differ from original')
        seal = runpy.run_path(str(W / 'scripts/controlled-setup-seal.py'))
        template = read(out / 'lifecycle/guard-client-template.exe')
        setup = read(out / 'Setup.exe')
        msi = read(out / 'FutureClassroom.msi')
        seal['verify_setup_template_binding'](template, setup, msi)
        need(template == seal['make_setup_template'](helper), 'exact new helper/template closure')
        source_check(a.source_sha, a.inventory, a.inventory_sha256)
        need(scope() == read(SCOPE).decode(), 'scope unchanged after assembly')
        mapping = {'status': 'BOUND_GNU_DEV_OWNED_REMOVAL_FIXTURE_NOT_RELEASE', 'target': TARGET, 'family': old['authoring']['upgrade_code'], 'productCode': '{' + old['authoring']['product_code'] + '}', 'version': old['source_manifest']['version'], 'expectedUserSid': snap['ParsedSid'], 'sourceGit': a.source_sha, 'auxiliarySourceGit': a.source_sha, 'payloadSourceGit': OLD_SOURCE, 'sourceManifest': {k: fact(a.inventory)[k] for k in ('bytes', 'sha256')}, 'payloads': old['payloads'], 'setup': fact(out / 'Setup.exe'), 'msi': fact(out / 'FutureClassroom.msi'), 'guardAction': 'FcControlledInnerGuard', 'compiledScope': {'bytes': binding['scopeBytes'], 'sha256': binding['scopeSha256'], 'envBytes': binding['envBytes'], 'envSha256': binding['envSha256']}, 'beforeSnapshot': fact(SNAPSHOT), 'scopeBinding': fact(BINDING), 'auxiliaryProducer': fact(a.producer), 'staticPackageReport': fact(out / 'report.json'), 'oldPackageReport': fact(OLD / 'report.json'), 'packageCode': {'original': old_code, 'fixture': new_code, 'different': True}, 'authorityMapping': {'externalSource': 'PERSISTENT_USER_OWNED_TEST_AND_COMPLETE_CLEANUP_AUTHORIZATION', 'runtimeArguments': ['owned-test-remove'], 'source': 'COMPILE_BOUND_SCOPE_ONLY_NO_MANIFEST_RUNTIME_PERMISSION', 'oldDisposition': 'UNKNOWN_UNCHANGED', 'oldPayload': 'EXACT_ORIGINAL_C508_COMPLETE14', 'newAuxiliary': 'FIXTURE_FEATURE_HELPER_DLL_TEMPLATE_NEW_PACKAGECODE', 'normalReleaseAdmission': False}, 'runtime': 'NOT_RUN', 'productionAdmission': False}
        (out / 'recovery-fixture.json').write_text(json.dumps(mapping, indent=2) + '\n')
        (out / 'recovery-assembly-receipt.json').write_text(json.dumps({'status': 'PASS_STATIC_DEV_FIXTURE_ONLY', 'runtime': 'NOT_RUN', 'controller': fact(Path(__file__)), 'controllerCommon': fact(HERE / 'common.py'), 'sourceInputs': fact(a.inventory), 'auxiliaryProducer': fact(a.producer), 'compiledScope': mapping['compiledScope'], 'originalPendingAndProduct': 'NOT_CONTACTED', 'artifactManifest': fact(out / 'recovery-fixture.json')}, indent=2) + '\n')
    except BaseException as e:
        if out.is_dir():
            (out / 'recovery-assembly-failure.json').write_text(json.dumps({'status': 'FAIL_RETAIN_ORIGINALS', 'error': type(e).__name__ + ': ' + str(e), 'runtime': 'NOT_RUN'}, indent=2) + '\n')
        raise
    finally:
        for k, v in previous.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
    print(json.dumps({'status': mapping['status'], 'manifest': fact(out / 'recovery-fixture.json'), 'runtime': 'NOT_RUN'}))
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
