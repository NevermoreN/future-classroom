"""Local deterministic file qualification, never Cargo/MSI/Windows execution."""
import json, subprocess, sys
from common import *

def main():
    for p in HERE.glob('*.py'):
        compile(read(p), str(p), 'exec')
    need(read(R / '.owner') == b'future-classroom-owned-r80-controlled-repair/v1\n', 'R ownership')
    inventory = R / 'owned-removal-fixture-inputs-first.json'
    raw = source_check(FIXTURE_SOURCE, inventory, FIXTURE_INVENTORY)
    need(len(json.loads(raw)['sources']) == 462, 'complete462 source closure')
    builder = load_builder()
    old, payload, manifest, source, zip_raw, old_code = fixed_payload(builder)
    encoded = scope()
    for phase in ROLES:
        argv = command(phase, R / 'target-first')
        need(argv.count('--features') == 1 and argv[argv.index('--features') + 1] == FEATURE and ('--release' in argv) and ('--locked' in argv) and ('--offline' in argv) and ('--tests' not in argv) and ('test' not in argv), 'closed compiler intent')
        need(not ('--bin' in argv and argv[argv.index('--bin') + 1] == 'fc-bootstrap'), 'never compile payload product')
    defaults = []
    for leaf in ['build-auxiliary.py', 'assemble-fixture.py']:
        child = subprocess.run([sys.executable, '-B', str(HERE / leaf)], capture_output=True, check=True, timeout=10)
        value = json.loads(child.stdout)
        need(value['status'] == 'PREPARED_NOT_RUN', 'default inert')
        defaults.append(value)
    report = {'status': 'PASS_DETERMINISTIC_LOCAL_PRECHECK_ONLY', 'sourceBase': FIXTURE_SOURCE, 'inventory': fact(inventory), 'inputCount': 462, 'scopeEnvBytes': len(encoded), 'scopeEnvSha256': sha(encoded.encode()), 'originalPayloadFiles': len(payload), 'originalPayloadTotalBytes': sum(map(len, payload.values())), 'originalRawManifestBytes': len(manifest), 'originalRawManifestSha256': sha(manifest), 'originalPackageCode': old_code, 'defaultEntries': defaults, 'cargo': 'NOT_RUN', 'assembly': 'NOT_RUN', 'Windows': 'NOT_CONTACTED', 'producerOutputCreated': False, 'normalAdmissionChanged': False}
    out = HERE / 'precheck-result.json'
    encoded = (json.dumps(report, indent=2) + '\n').encode()
    if out.exists():
        need(read(out) == encoded, 'deterministic precheck replay')
    else:
        out.write_bytes(encoded)
    print(json.dumps(report))
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
