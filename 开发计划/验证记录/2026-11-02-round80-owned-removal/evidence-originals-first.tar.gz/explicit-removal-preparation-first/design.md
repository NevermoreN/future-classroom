# 显式异常移除候选：保留旧 unknown，完成新的真实移除

本目录只有本地只读分析和实施候选，没有修改 W、Windows、MSI、Pending 或权限。`scope.json` 从已冻结的真实失败报告及包报告提取本轮产品、14 件、SID、原 B/G 终止收据，未把缺失字段补成成功。当前不是执行许可，更不是 P5 全部恢复验收通过。

## 权限来源与既有合同

用户已持续授权本机测试及测试后完全清理；本轮 root 另外明确要求准备独立显式恢复/移除。这是此次移除我们新装测试产品的外部授权，不能把它解释成旧事务已结束。旧操作结果永久记录 UNKNOWN；原 B/G 实际退出1603、文件健康及新 Begin0 都不能改成旧 End0。

计划 `开发计划/04-开发阶段与任务步骤.md:121` 的 P5-03 明确要求“升级/恢复/卸载”，122 行要求清理测试残留；`09-Rust构建验证与发布门槛.md:89` 限定只清本项目创建项、不删除教师正式资料/其他服务。没有发现“任何显式恢复都禁止”的需求。需要补的是实现契约，而非重复向用户索取已给的测试权限。

普通合同保持原样：

- `native.rs Resources::open` 最后无条件调用 `absent_pending()`，所有普通启动/维护遇 Pending 继续拒绝。
- `controlled.rs MaintenanceDraft::arm` 只在原 G 真实 Begin0 后以 CREATE_NEW 创建原 tag5 Pending；不接管旧记录。
- `MaintenanceOwner::try_release`、`record_controlled_settlement` 及 `Resources::clear_pending` 是原操作的结算合同；不能拿新 G 的收据填进去结算旧 OperationId。

新增的显式移除应是独立类型、独立结果，不是给上述接口加 `ignore_pending` 或 `recovered=true`。本轮先以精确的自有测试证据实例化该类型；后续生产 P5 的确认界面、持久化生产者证据、重启后恢复另行实现/验证，不声称已经覆盖。

## 当前已有与缺失事实

已有报告 SHA `5ef46830…`：首装0、缺 LICENSE 后修复0；卸载时原 B37196/创建134380456451547673、G9528/创建134380456452000970 均真实 Wait0、Exit1603、checkedClose，产品14件仍健康。报告中的观察范围仅当前 SID；不扩大为其他用户或学校资料已核查。

原 Pending **只有存在记录，没有 inode 或完整字节**。`scope.json` 明确标 UNBOUND，不能拿 gate 的 file ID 代替 Pending ID。Pending v1 字节包含 family、nonce、操作 tag、SID，不包含原 B/G/线程身份；两类证据必须外部绑定，不能声称从 Pending 解析出原 G。旧外部观察器没有直接取得 G 的原线程句柄，也不补造其线程返回码。

实施前先做一次有限、只读的现场捕获：固定当前 SID、原协调目录和 gate 原对象/ACL，OPEN_EXISTING 原 gate 独占，打开 Pending 原对象，核 regular/nonreparse/single-link/protected ACL，读长度1..4096的完整字节，记录 volume+fileIndex+creation、SHA及原字节；不改写、不删除。捕获同一启动周期的可靠证据，并与旧进程创建时间绑定；重启或无法确定同一周期即拒绝。该捕获本身不产生移除许可，不调用 MSI。活 owner、gate busy、未知记录格式、错误 SID/family/tag、未知产品上下文均拒绝。

## 最少私有接口

1. `ExplicitRemovalAuthorization`：只能由受信任的内部授权构造器创建。本轮编入冻结的 `OwnedFixtureScope`（两个原报告 SHA、确切产品/14文件与 GUID、SID、beforeAbsent、Pending 原对象与字节、旧原对象终止收据、启动周期）。所有事实再经原生现场重核；不接受 CLI 路径/hash/PID/nonce/结果、任意 JSON 或 caller bool 作权限。普通三个 Setup 请求不创建这个类型。
2. `RecoveryDraft::open(identity, authorization, deadline)`：抽取 native 内部“打开/核实原 namespace 与 gate”原语，普通 `Resources::open` 仍追加 absent_pending。恢复分支用 OPEN_EXISTING，持**同一个原 gate**及 Pending 的 READ/DELETE 原句柄，禁止 write/delete sharing；核原 inode/ACL/字节。旧 Pending 从此一直存在且不改写。未取得新 G Begin0 前仍是无 Run 权限的 Draft。
3. `RecoveryRemovalOwner::run_phase`：真实原 CreateProcess process+hThread、同 sealed B/G 镜像、原 pipe 认证、实际 Begin0 后才 arm 本次恢复内存状态；不创建/伪造普通 MaintenanceOwner，不改旧 OperationId，不制造 Join0。复用现 G 的固定源、Type1 guard、一次 Request/Ack、首个 Init 后 Returned、同步 API、实际 End 和原线程/进程结算。返回 native-private `RecoveryPhaseTerminal`，外部不能填返回码。只允许下述固定阶段，禁止任意操作/属性。
4. `finish_removed(RecoveryAbsentProof)`：仅接受新移除的真实完整证明。先实际归还全部新 producer/source/effect 控制，持 gate/旧 Pending/祖先 pins；将旧原字节和 UNKNOWN 处置连同新终态写入固定 CREATE_NEW 审计文件，flush+读回+checked close。再重核旧 Pending 原 inode/原字节，按 held handle 删除**本轮被授权处置的旧负向记录**，核缺失后最后归还 gate。独立结果为 `RemovedUnderExplicitRecovery { old: Unknown, new: ActualTerminal }`，不是旧操作 Released。

删除 Pending 的物理原语可复用，但权限包装必须独立于 `clear_pending` 的旧 owner 结算接口；不得先删 Pending 再去调用普通 `run_setup` 获得新许可。正常入口和正常 Pending 拒绝测试都必须保留。

## 固定阶段与缓存模板依赖

修复回调后的新 G 前缀与旧缓存 `FcGuardClientTemplate` 不同；直接用新 G 对旧缓存卸载可能在真正模板比较处被拒绝。不能仅因 source SHA 已绑定就宣称解决了 activeDB/cache。

第一候选固定最多两个阶段、同一个独占恢复 owner、同一原120秒 deadline：

1. **SourceRefresh**：新原 G1 Begin0，固定 sealed 新 source，`REINSTALL=ALL REINSTALLMODE=vamus`。调用前必须同时绑定现有旧14件健康前像与固定新 source 的完整14件目标、相同产品/组件路径集合；不准混入未知文件、其他产品、Run 或业务资料。实际 Type1 必须从 activeDB 读到匹配 G1 的完整零槽模板，实际 DLL/来源由同源构建和日志/受控读回核实。新 API 返回0、EndCommit0、事件/control close0、原 G1线程/进程退出0、完整目标 Present 后才进入下一阶段。`v` 是调用形态，不代替上述证据。
2. **Remove**：新的原 G2（不是替换旧 unknown 的 G），实际 Begin0；同一固定 source 仅 `REMOVE=ALL` 和既有 quiet 字串，不混 REINSTALL=ALL。正常 guard、首个后继 Init、实际 Install0→EndCommit0→原 event/control close0→G2原线程/进程退出0；完整产品/context/related family、全部14组件路径、精确树/marker 缺失和 Run 未改证明完成，才允许上述旧负向记录处置。

两个 G 各自只有一次 Run/Install/registration，不能在同一个 G 里复用已退役 Context。G1 的所有原 cap 实际归还后才登记 G2，不能把 G2 当 G1 未归还时的 replacement。新 owner 只占原一个 Resources slot；固定最多2个顺序 G、同一120秒、64 handles/8 slots、4096 Pending、30MiB前像预算不增加。旧 Pending 是耐久负状态，另有固定审计记录不是第二个可授予生产许可的 Pending。

若确认一次固定 source uninstall 确实加载新 activeDB/template，可后续审计减少 SourceRefresh 阶段；本候选不先假定这一点。若 SourceRefresh 仍取旧模板，则实际拒绝并停止，不自动改条件、修缓存注册、切 API 或循环重试。必须调整受控 MSI 来源策略再准备新候选。

新正常产品与 helper/DLL/source 仍须各自真实 provenance；若为清理保留旧14字节而单独更新辅助工具，必须明确这是独立恢复候选的受控旧/新实物映射，不能冒充同源正式发布包。旧/新14清单不一致时普通 SameManifest 不适用；恢复类型必须明确审核两份完整清单，不能拿新 helper 的 manifest 静默接管旧产品。

## 失败与清理顺序

任一阶段 Begin失败、缺 guard、重复授权、deadline、实际 End非0、原 G/thread 未归还、close未知、外来文件/注册、证明失败：停止，不删除/改写旧 Pending。已知 native 安装失败仅在其真实 Rollback0、完整实际前像和原 G0/控制归还后可记“本次恢复尝试失败且已回滚”；这仍不处置旧 unknown。任何新 unknown 必须另留审计和同一 owner，后续候选不能忽略这次新失败而仅重用旧终止收据。

只有新正式移除完整闭合后，才处理自有协调记录及本轮临时文件。原协调目录和 gate 的删除另外核其最初 file ID、ACL、beforeAbsent、仅预期项、无未知新 owner，按持有原对象/受控清单清理；出现任何新项停止，不递归删除未知物。旧/新 MSI 缓存和注册只交由真实 MSI 正式卸载，不手工删内部键/缓存文件。

旧 FAIL、旧 Pending原字节、两阶段实际 API/进程证据先完整下载并逐字节校验，再按精确 inventory 清理自有 scratch。保留 SSH 服务、公钥和仓库外私钥；不启动普通桌面，不初始化/枚举/删除学校资料。原 before 对学校资料未查询，因此不能输出“已比对全部学校资料前像”；只记录执行路径未触碰其范围。

## 有限验证门槛

先实现并本地验证：普通启动/三请求仍拒旧 Pending；错误 Pending inode/一字节变化/坏 schema/错 SID/重启/活 owner 均无 Run；原 gate 未取得或新 Begin非0不能 arm；普通 caller 不能创建 recovery auth；G1 未归还不能换 G2；新 terminal/effects/close 缺任一项不删旧 record；删除操作只作用 held 原对象。再在当前 Win11 对这一已装自有产品实际 SourceRefresh→正式移除，逐项留下真实返回和下载证据。Win7/Win10实机、生产崩溃/重启恢复、升级、一般用户授权交互仍各自 NOT_RUN/未完成。
