"""Compile a frozen controlled-guard candidate without running its artifacts."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import signal
import subprocess
import time

ROOT = Path('/tmp/fc-round80-controlled-repair')
WORK = ROOT / 'checkout-52d6392-first'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def inputs():
    paths = sorted({*WORK.glob('crates/**/*.rs'), *WORK.glob('crates/**/Cargo.toml'),
                    WORK / 'Cargo.toml', WORK / 'Cargo.lock',
                    *WORK.glob('.cargo/*'), *WORK.glob('rust-toolchain*')})
    return [{'path': str(path.relative_to(WORK)), 'bytes': path.stat().st_size,
             'sha256': digest(path.read_bytes())}
            for path in paths if path.is_file() and not path.is_symlink()]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=['tests', 'library', 'helper', 'clippy'], required=True)
    parser.add_argument('--inventory', type=Path, required=True)
    parser.add_argument('--feature', choices=['owned-test-removal'])
    parser.add_argument('--inventory-sha256', required=True)
    parser.add_argument('--output-name', required=True)
    args = parser.parse_args()
    assert (ROOT / '.owner').read_bytes() == b'future-classroom-owned-r80-controlled-repair/v1\n'
    assert args.output_name.startswith('guard-') and '/' not in args.output_name
    output = ROOT / args.output_name
    assert not output.exists()
    raw = args.inventory.read_bytes()
    assert digest(raw) == args.inventory_sha256
    frozen = json.loads(raw)
    before = inputs()
    assert before == frozen['sources']
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
    assert head == frozen['sourceBase']
    command = ['cargo', 'clippy' if args.mode == 'clippy' else
               'test' if args.mode == 'tests' else 'build',
               '--release', '--offline', '--locked', '-p',
               'fc-bootstrap' if args.mode == 'helper' else 'fc-windows']
    if args.mode in ('tests', 'clippy'):
        command += ['--all-targets']
    elif args.mode == 'library':
        command += ['--lib']
    else:
        command += ['--bin', 'fc-installer-lifecycle']
    if args.feature:
        command += ['--features', args.feature]
    command += ['--target', 'i686-pc-windows-gnu', '--target-dir',
                str(ROOT / 'target-first'), '--message-format=json-render-diagnostics']
    if args.mode == 'tests':
        command += ['--no-run']
    elif args.mode == 'clippy':
        command += ['--', '-D', 'warnings']
    output.mkdir()
    env = os.environ.copy()
    env['CARGO_BUILD_JOBS'] = '2'
    env.pop('FC_OWNED_REMOVAL_SCOPE_HEX', None)
    env.pop('CARGO_ENCODED_RUSTFLAGS', None)
    env['RUSTFLAGS'] = '-C target-feature=+crt-static -C link-arg=-Wl,--major-subsystem-version,6,--minor-subsystem-version,1'
    env['CARGO_TARGET_I686_PC_WINDOWS_GNU_LINKER'] = 'i686-w64-mingw32-gcc'
    start = time.monotonic()
    process = subprocess.Popen(command, cwd=WORK, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, start_new_session=True)
    expired = False
    try:
        stdout, stderr = process.communicate(timeout=900)
    except subprocess.TimeoutExpired:
        expired = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            stdout, stderr = process.communicate(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            stdout, stderr = process.communicate()
    (output / 'cargo.stdout.jsonl').write_bytes(stdout)
    (output / 'cargo.stderr.log').write_bytes(stderr)
    artifacts = {}
    for line in stdout.splitlines():
        try:
            item = json.loads(line)
        except (ValueError, UnicodeDecodeError):
            continue
        if item.get('reason') != 'compiler-artifact':
            continue
        for filename in item.get('filenames', []):
            path = Path(filename)
            if path.suffix.lower() not in ('.exe', '.dll'):
                continue
            data = path.read_bytes()
            artifacts[str(path)] = {'path': str(path), 'bytes': len(data),
                                    'sha256': digest(data),
                                    'test': item['profile']['test'], 'target': item['target']}
    after = inputs()
    passed = process.returncode == 0 and not expired and before == after
    report = {'status': 'PASS_FROZEN_LOCAL_COMPILER_CHECK_ONLY' if passed else 'FAIL',
              'mode': args.mode, 'actualExit': process.returncode,
              'originalParentReaped': process.poll() is not None,
              'seconds': time.monotonic() - start, 'budgetSeconds': 900,
              'budgetExceeded': expired, 'argv': command, 'sourceBase': head,
              'frozenInventorySha256': args.inventory_sha256,
              'sourcesBefore': before, 'sourcesAfter': after,
              'sourceUnchanged': before == after, 'outputs': list(artifacts.values()),
              'runtime': 'NOT_RUN', 'productionAdmission': False,
              'feature': args.feature, 'compiledScopeEnvironment': 'ABSENT_NO_REMOVAL_AUTHORIZATION',
              'scopedRustflags': env['RUSTFLAGS']}
    (output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({key: report[key] for key in
                      ('status', 'mode', 'actualExit', 'seconds', 'sourceUnchanged')}))
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
