"""Parse frozen controller PowerShell in memory; never run its original bodies."""
from pathlib import Path
import argparse
import base64
import hashlib
import json
import runpy
import subprocess
import time

R = Path('/tmp/fc-round80-controlled-repair')
P = R / 'pending-readonly-preparation-first'
ap = argparse.ArgumentParser()
ap.add_argument('--freeze-sha256', required=True)
a = ap.parse_args()
freeze_raw = (P / 'freeze-first.json').read_bytes()
assert hashlib.sha256(freeze_raw).hexdigest() == a.freeze_sha256
freeze = json.loads(freeze_raw)
for row in freeze['files']:
    raw = (P / row['path']).read_bytes()
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
ns = runpy.run_path(str(P / 'run-pending-snapshot.py'))
chunks = {'boot.ps1': ns['BOOT']}
for name in ('CREATE', 'CAPTURE', 'INVENTORY', 'DELETE'):
    chunks[name.lower() + '.ps1'] = ns['COMMON'] + ns[name]
for path in sorted((P / 'sources').glob('*.ps1')):
    chunks['sources/' + path.name] = path.read_text()
raw_json = json.dumps(chunks, ensure_ascii=False).replace("'", "''")
script = ("$ErrorActionPreference='Stop';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);$chunks='" + raw_json + "'|ConvertFrom-Json;"
          "$rows=@();foreach($p in $chunks.PSObject.Properties){$t=$null;$e=$null;"
          "[void][Management.Automation.Language.Parser]::ParseInput([string]$p.Value,[ref]$t,[ref]$e);"
          "$rows+=@{name=$p.Name;errors=@($e|ForEach-Object {$_.Message})}};"
          "@{status='ACTUAL_PS51_AST_ONLY';rows=$rows;mutations='NONE'}|ConvertTo-Json -Depth 10 -Compress;"
          "if(@($rows|Where-Object {$_.errors.Count}).Count){exit 1}")
feed = script.encode('utf-8')
boot = '[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()))'
command = 'powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand ' + base64.b64encode(boot.encode('utf-16-le')).decode()
argv = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8', 'future-classroom-win11', command]
stem = R / 'root-pending-snapshot-ps-parse-first'
assert not stem.with_suffix('.json').exists()
Path(str(stem) + '.stdin.ps1').write_bytes(feed)
started = time.monotonic()
proc = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
stdout, stderr = proc.communicate(feed, timeout=30)
Path(str(stem) + '.stdout.log').write_bytes(stdout)
Path(str(stem) + '.stderr.log').write_bytes(stderr)
report = {'actualExit': proc.returncode, 'originalParentReaped': proc.poll() is not None,
          'seconds': time.monotonic() - started, 'preparationFreezeSha256': a.freeze_sha256,
          'mutations': 'NONE', 'scope': 'ONLY_POWERSHELL_PARSER_NOT_SCRIPT_OR_PRODUCT_EXECUTION'}
if proc.returncode == 0:
    report['native'] = json.loads(stdout.decode('utf-8-sig'))
Path(str(stem) + '.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report), flush=True)
raise SystemExit(proc.returncode)
