$c='{"nonce":"2949bb6b89d645d09547c3b8d1ff88b6","sid":"S-1-5-21-3896111207-1867804362-1971593122-1001","root":"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r80-pending-capture-2949bb6b89d645d09547c3b8d1ff88b6","inventory":{"directories":["compiler"],"files":[{"path":".owner","sha256":"33a44685dcf3b4930e779b7e157d7b28e1b2c35c10d2bf93433111bd6fd329e9","bytes":51},{"path":"pending-snapshot.json","sha256":"0102d927f120cbf79feb3c722c47840dbcda1ea0650cefd3feb4c1593693abd0","bytes":9917},{"path":"PendingSnapshot.cs","sha256":"04b8183284ac4c870fda69ac0a3ae4c207438e726328bbd2a463e769187c6a38","bytes":13891},{"path":"PendingSnapshot.dll","sha256":"0a7cddfb3e1076eb607d7f6d19d21f435d9e6fbfd92ac91eca36a07b3bd5fbdb","bytes":14848}]}}'|ConvertFrom-Json;
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Need([bool]$v,[string]$e){if(-not$v){throw $e}}
function Fact([string]$p){$f=Get-Item -LiteralPath $p -Force;Need (-not$f.PSIsContainer -and ($f.Attributes-band1024)-eq0) 'NO_REPARSE_FILE';@{bytes=[long]$f.Length;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function RootPath {Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) ('Temp\FutureClassroom-r80-pending-capture-'+$c.nonce)}
function CheckRoot {
 Need ($c.nonce-cmatch'^[0-9a-f]{32}$' -and $c.root-ceq(RootPath)) 'ONLY_NEW_CAPTURE_NONCE_ROOT'
 $who=[Security.Principal.WindowsIdentity]::GetCurrent();try{Need ($who.User.Value-ceq$c.sid) 'SAME_AUTHORIZED_USER'}finally{$who.Dispose()}
 $cursor=$c.root;while($cursor){$a=[IO.File]::GetAttributes($cursor);Need (($a-band1024)-eq0 -and ($a-band16)-ne0) 'NONREPARSE_DIRECTORY_CHAIN';$cursor=[IO.Path]::GetDirectoryName($cursor)}
 Need ([IO.File]::ReadAllText((Join-Path $c.root '.owner'))-ceq"future-classroom-owned-pending-readonly-capture/v1`n") 'EXACT_NEW_OWNER'
 $acl=[IO.Directory]::GetAccessControl($c.root);Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq$c.sid) 'PROTECTED_CAPTURE_OWNER'
 $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($rules.Count-eq2 -and @($rules|Where-Object{$_.IdentityReference.Value-cnotin@($c.sid,'S-1-5-18') -or $_.AccessControlType-ne'Allow' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count-eq0) 'ONLY_CAPTURE_USER_SYSTEM_FULLCONTROL'
}
function Inventory {
 CheckRoot;$files=@();$directories=@();$q=[Collections.Generic.Queue[string]]::new();$q.Enqueue($c.root)
 while($q.Count){$directory=$q.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($directory)){$a=[IO.File]::GetAttributes($p);Need (($a-band1024)-eq0) 'NO_CAPTURE_REPARSE';$rel=$p.Substring($c.root.Length+1).Replace('\','/');if(($a-band16)-ne0){$directories+=$rel;$q.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256}};Need ($files.Count-le64 -and $directories.Count-le8) 'CAPTURE_INVENTORY_BOUNDS'}}
 $total=[long]0;foreach($row in $files){$total+=[long]$row.bytes};Need ($total-le32MB) 'CAPTURE_TOTAL_BOUND';@{files=$files;directories=$directories}
}
CheckRoot
# Only compiler commands containing this exact random nonce can be returned.
$own=@(Get-CimInstance -Query ("SELECT ProcessId,Name FROM Win32_Process WHERE Name='csc.exe' AND CommandLine LIKE '%"+$c.nonce+"%'") -OperationTimeoutSec 5 -ErrorAction Stop);Need ($own.Count-eq0) 'NO_OWN_CAPTURE_CSC_PROCESS'
$now=Inventory;Need ($now.files.Count-eq$c.inventory.files.Count -and $now.directories.Count-eq$c.inventory.directories.Count) 'EXACT_CAPTURE_MEMBERS'
foreach($row in $now.files){$old=@($c.inventory.files|Where-Object{$_.path-ceq$row.path});Need ($old.Count-eq1 -and $old[0].bytes-eq$row.bytes -and $old[0].sha256-ceq$row.sha256) 'EXACT_DOWNLOADED_CAPTURE_BYTES'};foreach($dir in $now.directories){Need ($dir-cin$c.inventory.directories) 'EXACT_CAPTURE_DIRECTORY'}
foreach($row in $now.files){if($row.path-cne'.owner'){[IO.File]::Delete((Join-Path $c.root ($row.path.Replace('/','\'))))}};foreach($dir in @($now.directories|Sort-Object Length -Descending)){[IO.Directory]::Delete((Join-Path $c.root ($dir.Replace('/','\'))),$false)};[IO.File]::Delete((Join-Path $c.root '.owner'));[IO.Directory]::Delete($c.root,$false)
try{[void][IO.File]::GetAttributes($c.root);throw 'CAPTURE_NONCE_STILL_PRESENT'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
@{status='EXACT_NEW_CAPTURE_NONCE_REMOVED';knownAbsent=$true;originalProductGatePendingTouched=$false}|ConvertTo-Json -Compress
