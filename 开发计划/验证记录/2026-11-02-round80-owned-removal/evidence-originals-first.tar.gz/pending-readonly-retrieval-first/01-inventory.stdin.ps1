$c='{"nonce":"2949bb6b89d645d09547c3b8d1ff88b6","sid":"S-1-5-21-3896111207-1867804362-1971593122-1001","root":"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r80-pending-capture-2949bb6b89d645d09547c3b8d1ff88b6"}'|ConvertFrom-Json;
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Need([bool]$v,[string]$e){if(-not$v){throw $e}}
function Fact([string]$p){$f=Get-Item -LiteralPath $p -Force;Need (-not$f.PSIsContainer -and ($f.Attributes-band1024)-eq0) 'NO_REPARSE_FILE';@{bytes=[long]$f.Length;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function RootPath {Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) ('Temp\FutureClassroom-r80-pending-capture-'+$c.nonce)}
function CheckRoot {
 Need ($c.nonce-cmatch'^[0-9a-f]{32}$' -and $c.root-ceq(RootPath)) 'ONLY_NEW_CAPTURE_NONCE_ROOT'
 $who=[Security.Principal.WindowsIdentity]::GetCurrent();try{Need ($who.User.Value-ceq$c.sid) 'SAME_AUTHORIZED_USER'}finally{$who.Dispose()}
 $cursor=$c.root;while($cursor){$a=[IO.File]::GetAttributes($cursor);Need (($a-band1024)-eq0 -and ($a-band16)-ne0) 'NONREPARSE_DIRECTORY_CHAIN';$cursor=[IO.Path]::GetDirectoryName($cursor)}
 Need ([IO.File]::ReadAllText((Join-Path $c.root '.owner'))-ceq"future-classroom-owned-pending-readonly-capture/v1`n") 'EXACT_NEW_OWNER'
 $acl=[IO.Directory]::GetAccessControl($c.root);Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq$c.sid) 'PROTECTED_CAPTURE_OWNER'
 $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($rules.Count-eq2 -and @($rules|Where-Object{$_.IdentityReference.Value-cnotin@($c.sid,'S-1-5-18') -or $_.AccessControlType-ne'Allow' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count-eq0) 'ONLY_CAPTURE_USER_SYSTEM_FULLCONTROL'
}
function Inventory {
 CheckRoot;$files=@();$directories=@();$q=[Collections.Generic.Queue[string]]::new();$q.Enqueue($c.root)
 while($q.Count){$directory=$q.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($directory)){$a=[IO.File]::GetAttributes($p);Need (($a-band1024)-eq0) 'NO_CAPTURE_REPARSE';$rel=$p.Substring($c.root.Length+1).Replace('\','/');if(($a-band16)-ne0){$directories+=$rel;$q.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256}};Need ($files.Count-le64 -and $directories.Count-le8) 'CAPTURE_INVENTORY_BOUNDS'}}
 $total=[long]0;foreach($row in $files){$total+=[long]$row.bytes};Need ($total-le32MB) 'CAPTURE_TOTAL_BOUND';@{files=$files;directories=$directories}
}
CheckRoot;Inventory|ConvertTo-Json -Depth 12 -Compress