"""Retrieve the completed native snapshot and clean only its owned temp root."""
from pathlib import Path
import base64
import hashlib
import json
import runpy
import subprocess
import time

R = Path('/tmp/fc-round80-controlled-repair')
P = R / 'pending-readonly-preparation-first'
D = R / 'pending-readonly-retrieval-first'
old_report = R / 'pending-readonly-runtime-first/report.json'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def fact(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': sha(raw)}

assert not D.exists()
assert fact(P / 'freeze-first.json')['sha256'] == '886727fc2556a257c2c5865876958e83c6cf7e6e20dcf97814f4484f323d822f'
for row in json.loads((P / 'freeze-first.json').read_bytes())['files']:
    assert fact(P / row['path']) == {k: row[k] for k in ('bytes', 'sha256')}
assert fact(old_report)['sha256'] == 'd4cf8e4b8f23133fb6f096c8083e336f2f9419dc2e0baf558c820acc056bd232'
old = json.loads(old_report.read_bytes())
snapshot = old['snapshot']
cap = snapshot['capture']
assert old['status'] == 'FAIL_OR_UNKNOWN_RETAIN_NEW_CAPTURE_NONCE'
assert cap['Status'] == 'PASS_READONLY_PINNED_PENDING_SNAPSHOT_ONLY'
assert cap['SameHandleBytesEqual'] and cap['SameHandleMetadataEqual'] and not cap['CloseUnknown']
assert all(x['Attempted'] and x['Success'] and not x['Unknown'] for x in cap['NativeReturns'])
ns = runpy.run_path(str(P / 'run-pending-snapshot.py'))
common = ns['COMMON']
before = "Need (($files|Measure-Object bytes -Sum).Sum-le32MB) 'CAPTURE_TOTAL_BOUND'"
after = "$total=[long]0;foreach($row in $files){$total+=[long]$row.bytes};Need ($total-le32MB) 'CAPTURE_TOTAL_BOUND'"
assert common.count(before) == 1
common = common.replace(before, after)
binding = ns['origin']()
nonce = '2949bb6b89d645d09547c3b8d1ff88b6'
c = {'nonce': nonce, 'sid': binding['gateFacts'][1], 'root': old['windowsRoot']}
assert c['root'].endswith('FutureClassroom-r80-pending-capture-' + nonce)
D.mkdir()
(D / '.owner').write_text('future-classroom-owned-pending-readonly-retrieval/v1\n')
start = time.monotonic()
report = {'status': 'STARTED_RETRIEVAL_NOT_NEW_CAPTURE', 'originalCaptureReport': fact(old_report),
          'originalCaptureOperationRemains': 'FAIL_INVENTORY0', 'originalNativeSnapshot': 'PASS_READONLY_ONLY',
          'originalEnd': 'UNKNOWN_UNCHANGED', 'operations': [], 'oldProductGatePendingMutated': False}

def save():
    (D / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

def call(label, argv, feed=None, maximum=30):
    left = 90 - (time.monotonic() - start)
    assert left > 0
    if feed is not None:
        (D / (label + '.stdin.ps1')).write_bytes(feed)
    proc = subprocess.Popen(argv, stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = proc.communicate(feed, timeout=min(left, maximum))
    (D / (label + '.stdout.log')).write_bytes(out)
    (D / (label + '.stderr.log')).write_bytes(err)
    report['operations'].append({'label': label, 'actualExit': proc.returncode,
        'originalLocalParentReaped': proc.poll() is not None, 'argv': argv,
        'stdout': fact(D / (label + '.stdout.log')), 'stderr': fact(D / (label + '.stderr.log'))})
    save()
    assert proc.returncode == 0, label
    return out

def remote(label, body):
    feed = ("$c='" + json.dumps(c, separators=(',', ':')).replace("'", "''") + "'|ConvertFrom-Json;\n" + common + body).encode()
    argv = ['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8', ns['HOST'],
            'powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand ' + base64.b64encode(ns['BOOT'].encode('utf-16-le')).decode()]
    return call(label, argv, feed)

try:
    chunks = json.dumps({'inventory': common + ns['INVENTORY'], 'delete': common + ns['DELETE']}).replace("'", "''")
    parser = ("$chunks='" + chunks + "'|ConvertFrom-Json;$rows=@();foreach($p in $chunks.PSObject.Properties){$t=$null;$e=$null;"
        "[void][Management.Automation.Language.Parser]::ParseInput([string]$p.Value,[ref]$t,[ref]$e);$rows+=@{name=$p.Name;errors=@($e|ForEach-Object {$_.Message})}};"
        "$rows|ConvertTo-Json -Depth 8 -Compress;if(@($rows|Where-Object {$_.errors.Count}).Count){exit 1}")
    report['nativeParser'] = json.loads(remote('00-ast-only', parser).decode('utf-8-sig'))
    inventory = json.loads(remote('01-inventory', ns['INVENTORY']).decode('utf-8-sig'))
    ns['validate_inventory'](inventory)
    report['inventory'] = inventory
    download = D / 'download'
    download.mkdir()
    call('02-download', ['scp', '-q', '-r', '-o', 'BatchMode=yes', ns['HOST'] + ':' + c['root'].replace('\\', '/'), str(download)])
    tree = download / Path(c['root'].replace('\\', '/')).name
    files, directories = {}, set()
    for path in tree.rglob('*'):
        assert not path.is_symlink()
        relative = path.relative_to(tree).as_posix()
        if path.is_dir():
            directories.add(relative)
        else:
            files[relative] = fact(path)
    assert files == {x['path']: {k: x[k] for k in ('bytes', 'sha256')} for x in inventory['files']}
    assert directories == set(inventory['directories'])
    assert json.loads((tree / 'pending-snapshot.json').read_bytes()) == snapshot
    assert fact(tree / 'PendingSnapshot.cs') == snapshot['source']
    assert fact(tree / 'PendingSnapshot.dll') == snapshot['assembly']
    report['downloadVerified'] = True
    report['originalNativeSnapshot'] = snapshot
    c['inventory'] = inventory
    report['cleanup'] = json.loads(remote('03-exact-capture-nonce-cleanup', ns['DELETE']).decode('utf-8-sig'))
    assert report['cleanup']['knownAbsent'] and not report['cleanup']['originalProductGatePendingTouched']
    report['status'] = 'PASS_RETRIEVAL_AND_EXACT_CAPTURE_NONCE_CLEANUP_ORIGINAL_OPERATION_REMAINS_FAIL'
except BaseException as error:
    report['status'] = 'FAIL_RETRIEVAL_RETAIN_ORIGINALS'
    report['failure'] = type(error).__name__ + ':' + str(error)
    raise
finally:
    report['elapsedSeconds'] = time.monotonic() - start
    save()
    print(json.dumps({'status': report['status'], 'reportSha256': fact(D / 'report.json')['sha256']}), flush=True)
