#!/usr/bin/env python3
"""Root-only independent fixture transport. Default inert; not product authority.
Only exact controlled-owner build/source closure admitted. No production authority.
"""
import argparse,base64,datetime,hashlib,json
from pathlib import Path,PureWindowsPath
import re,runpy,subprocess,time
E=Path('/tmp/fc-round80-controlled-repair')
PROTOTYPE=E/'inner-guard-probe-second'
SOURCE_DIR=PROTOTYPE
BASE=PROTOTYPE/'reference/compile-only.py'
BASE_SHA='3b3aa837646c78157c0c8ce1d5d44f4325f8bcdd34f4fc59e85c801b555a4783'
NAMES={'.owner','spec.json','Owner.exe','Guard.dll','payload.txt','healthy.msi','early-fail.msi','build-report.json','Capture.cs','Invoke-Probe.ps1'}
DIRS=('compiler-temp','readback-compiler-temp','effect')
PARENT_PS=r'''
function Parent-State {
 $base=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry32);$key=$null
 try{
  $key=$base.OpenSubKey('Software\FutureClassroomTest',$false)
  if($null-eq $key){return @{status='KNOWN_ABSENT';key='Software\FutureClassroomTest';view='Registry32'}}
  $values=@($key.GetValueNames());$subkeys=@($key.GetSubKeyNames());Need ($values.Count-le 64 -and $subkeys.Count-le 128) 'PARENT_SNAPSHOT_BOUND'
  $acl=$key.GetAccessControl([Security.AccessControl.AccessControlSections]::Owner -bor [Security.AccessControl.AccessControlSections]::Access)
  @{status='PRESENT';key='Software\FutureClassroomTest';view='Registry32';ownerSid=$acl.GetOwner([Security.Principal.SecurityIdentifier]).Value;securityDescriptor=$acl.GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]::Owner -bor [Security.AccessControl.AccessControlSections]::Access);valueNames=@($values|Sort-Object);subkeyNames=@($subkeys|Sort-Object)}
 }finally{if($null-ne $key){$key.Dispose()};$base.Dispose()}
}
'''
INVENTORY_PS=r'''
function Inventory {
 Root-Check;$files=@();$dirs=@();$total=0L;$queue=[Collections.Generic.Queue[string]]::new();$queue.Enqueue($c.root)
 while($queue.Count){$dir=$queue.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){
  $attrs=[IO.File]::GetAttributes($p);Need (($attrs-band[IO.FileAttributes]::ReparsePoint)-eq 0) 'INVENTORY_REPARSE'
  $rel=$p.Substring($c.root.Length+1).Replace('\','/')
  if(($attrs-band[IO.FileAttributes]::Directory)-ne 0){$top=($rel-split '/')[0];Need ($top-cin @('compiler-temp','readback-compiler-temp','effect')) 'ONLY_OWN_FIXTURE_SUBDIRECTORIES';$dirs+=$rel;$queue.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256};$total+=$f.bytes}
  Need ($files.Count-le 256 -and $dirs.Count-le 32 -and $total-le 67108864) 'RUNTIME_INVENTORY_BOUND'
 }}
 @{files=$files;directories=$dirs}
}
'''
READBACK_PS=r'''
Root-Check
$item=@($c.manifest.files|Where-Object path -CEQ 'Capture.cs');Need ($item.Count-eq 1 -and (Fact (Join-Path $c.root 'Capture.cs')).sha256-ceq $item[0].sha256) 'FROZEN_READONLY_CAPTURE_SOURCE'
$beforeTemp=$env:TEMP;$beforeTmp=$env:TMP
try{$env:TEMP=Join-Path $c.root 'readback-compiler-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP);Add-Type -Path (Join-Path $c.root 'Capture.cs') -ErrorAction Stop}finally{$env:TEMP=$beforeTemp;$env:TMP=$beforeTmp}
$product=[Fc79Capture]::Product($c.spec.productCode,$c.spec.upgradeCode,$c.sid)
$components=[Fc79Capture]::Components($c.spec.productCode,$c.spec.componentId,$c.sid)
$registry=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry32);$key=$null
try{$key=$registry.OpenSubKey($c.spec.registryKey,$false);$markerAbsent=($null-eq $key)}finally{if($null-ne $key){$key.Dispose()};$registry.Dispose()}
$effect=[Fc79Capture]::Absence($c.spec.effectDir.TrimEnd('\'));$paths=@()
foreach($path in $c.paths){$paths+=@{path=$path;fact=[Fc79Capture]::Absence($path)}}
$parent=Parent-State
$known=(@($product.registrations).Count-eq 0 -and @($product.related).Count-eq 0 -and $product.localPackageRc-eq 1605 -and $components.allUnknownStates-eq $true -and $markerAbsent -and $effect.status-ceq 'KNOWN_ABSENT')
@{status='ACTUAL_READONLY_FIXTURE_AND_EXACT_SYSTEM_PATH_FACTS';product=$product;components=$components;markerKnownAbsent=$markerAbsent;effect=$effect;fixtureKnownAbsent=$known;registryParent=$parent;paths=$paths;msiExecuted=$false;sharedServiceKilled=$false}|ConvertTo-Json -Depth 30 -Compress
'''

ZERO_PS=r'''
Root-Check;$own=@();$foreign=0
foreach($row in @(Get-CimInstance Win32_Process -Filter "Name='Owner.exe' OR Name='csc.exe'")){
 Need ($null-ne $row.ExecutablePath -and $null-ne $row.CommandLine) 'PROCESS_METADATA_UNKNOWN_RETAIN'
 if($row.ExecutablePath.StartsWith($c.root+'\',[StringComparison]::OrdinalIgnoreCase) -or $row.CommandLine.IndexOf($c.root,[StringComparison]::OrdinalIgnoreCase)-ge 0){$own+=@{pid=$row.ProcessId;image=$row.ExecutablePath}}else{$foreign++}
}
Need ($own.Count-eq 0) 'OWN_PROCESS_LIVE_RETAIN'
@{status='ACTUAL_ZERO_OWN_PROCESSES';ownCount=$own.Count;foreignIgnored=$foreign;sharedKilled=$false}|ConvertTo-Json -Compress
'''

def need(ok,s):
 if not ok:raise ValueError(s)
def sha(b):return hashlib.sha256(b).hexdigest()
def fact(p):
 need(p.is_file() and not p.is_symlink(),'Original regular file');b=p.read_bytes();need(len(b)<=32*1024*1024,'Bounded local file');return {'bytes':len(b),'sha256':sha(b)}
def owned(p):
 need(p.is_absolute() and p.resolve()==p and p.is_relative_to(E),'Canonical owned R79 local path');return p
def inventory_identity(v):
 need(set(v)=={'files','directories'} and len(v['files'])<=256 and len(v['directories'])<=32,'Inventory shape/bound')
 files={};total=0
 for row in v['files']:
  need(set(row)=={'path','bytes','sha256'},'Exact file fields');rel=row['path'];need(isinstance(rel,str) and rel and ':' not in rel and '\\' not in rel and all(x not in ('','.','..') for x in rel.split('/')) and rel not in files,'Safe unique file path')
  need(type(row['bytes']) is int and 0<=row['bytes']<=16777216 and re.fullmatch('[0-9a-f]{64}',row['sha256']),'File size/hash');files[rel]=(row['bytes'],row['sha256']);total+=row['bytes']
 need(total<=67108864 and len(set(v['directories']))==len(v['directories']),'Inventory total/unique dirs')
 for rel in v['directories']:need(rel and ':' not in rel and '\\' not in rel and all(x not in ('','.','..') for x in rel.split('/')) and rel.split('/')[0] in DIRS and rel not in files,'Only owned fixture directories')
 return files,set(v['directories'])
def returned(x):
 return isinstance(x,dict) and x.get('Kind')=='process' and x.get('Status')=='HELD_ORIGINAL_IDENTITY' and type(x.get('Pid')) is int and x['Pid']>0 and type(x.get('Creation')) is int and x['Creation']>0 and type(x.get('Wait')) is int and x.get('Wait')==0 and x.get('ExitKnown') is True and type(x.get('ExitCode')) is int and x.get('CheckedClose') is True and x.get('CloseAttempted') is True
def validate_phase(r,spec,helper_sha):
 need(r['status']=='PASS_REAL_BEGIN_INSTALL_END_CLOSE_AND_PHYSICAL_EXIT_NOT_PRODUCTION_AUTHORITY' and r['authority']=='NO_PRODUCTION_AUTHORITY' and r['errors']==[],'Original complete phase PASS only')
 need((r['wholeSeconds'],r['nativeSeconds'],r['finallyReserveSeconds'])==(600,120,180) and type(r['elapsedMilliseconds']) is int and r['elapsedMilliseconds']<600000,'Original600/120/180')
 need(r['nativeCloseUnknown'] is False and r['originalOwnerReturned'] is True and r['ownedCommitOutstanding'] is False and r['before']['knownAbsent'] is True and r['afterFinally']['knownAbsent'] is True,'Returned caps and absence')
 cases=r['cases'];need([x['name'] for x in cases]==['healthy-rollback','early-fail-rollback'],'Exact2 original cases')
 caps=r['originalCaps'];need(len(caps)==4 and all(x['CheckedClose'] is True and x['CloseAttempted'] is True and x['ExitKnown'] is True and x['Wait']==0 for x in caps),'4 original caps checked return')
 need(r['nativeCloseFacts'] and all(x['Attempted'] is True and x['Success'] is True and x['Unknown'] is False and x['LastError']==0 for x in r['nativeCloseFacts']),'Actual native closes')
 for index,case in enumerate(cases):
  process=case['originalProcess'];thread=case['originalThread'];need(returned(process) and process['ExitCode']==case['actualExit']==0 and process['Sha256']==helper_sha and process['Sid']==spec['expectedUserSid'],'Original G actual return')
  need(thread['Kind']=='thread' and thread['Status']=='HELD_ORIGINAL_IDENTITY' and thread['Pid']==process['Pid'] and thread['Tid']>0 and thread['Creation']>0 and thread['Wait']==0 and thread['ExitKnown'] is True and thread['CheckedClose'] is True and thread['CloseAttempted'] is True and thread['ExitCode']==0,'Original G thread physical return')
  need(case['nativeReturnsComplete'] is True and case['apiSuccessful'] is True and 0<=case['elapsedMilliseconds']<120000 and case['before']['knownAbsent'] is True and case['after']['knownAbsent'] is True,'Original120s and both rollback absences')
  rows=case['api'];need([x['sequence'] for x in rows]==list(range(1,len(rows)+1)) and all(x['pid']==process['Pid'] and x['tid']==x['originalTid']==thread['Tid'] and x['threadCreation']==thread['Creation'] and x['clockValid'] is True for x in rows),'Same original API thread')
  def one(stage):
   found=[x for x in rows if x['stage']==stage];need(len(found)==1,'Actual one '+stage);return found[0]
  begin=one('BEGIN_RETURN');install=one('INSTALL_RETURN');end=one('END_RETURN');close=one('TRANSACTION_ID_NO_INSTALL_HANDLE_CLOSE');event=one('CHANGE_EVENT_CLOSE_RETURN')
  need(begin['attempted'] is True and begin['return']==0 and begin['object']>0 and install['attempted'] is True and install['return']==(0 if index==0 else 1603) and end['attempted'] is True and end['return']==0 and close['attempted'] is False and close['return']==4294967295 and event['attempted'] is True and event['return']==0,'Actual Begin Install End event; no extra transaction-ID Close')
  need(begin['sequence']<install['sequence']<end['sequence']<close['sequence']<event['sequence'] and begin['object']==install['object']==end['object']==close['object'],'Actual original transaction order')
  one('END_ROLLBACK_ENTER')
  ui=one('SET_UI_PREVIOUS_LEVEL');logging=one('LOG_ENABLE_RETURN');handler=one('EXTERNAL_UI_RECORD_SET_RETURN');previous=one('PREVIOUS_EXTERNAL_CALLBACK_NULL')
  need(ui['attempted'] is True and logging['attempted'] is True and logging['return']==0 and handler['attempted'] is True and handler['return']==0 and previous['return']==0 and ui['sequence']<logging['sequence']<handler['sequence']<begin['sequence'],'Quiet log and actual record registration before Begin')
  change=one('BEGIN_CHANGE_EVENT');need(change['object']>0 and change['object']==event['object'],'Original acquired event checkedclose')
  need(one('EXTERNAL_UI_RECORD_DISABLE_RETURN')['return']==0 and one('CALLBACK_FILE_CLOSE_RETURN')['return']==0 and one('ALL_API_CALLS_RETURNED')['return']==0,'Actual callback unregister and journal closure')
 return {'status':'PASS_ORIGINAL_CONTROLLED_OWNER_API_AND_PHYSICAL_RETURNS','authority':'NO_PRODUCTION_AUTHORITY','caseCount':2}
def qualify_probe(download,phase,spec):
 proofs=[]
 for index,case in enumerate(phase['cases']):
  name=case['name'];guard=json.loads((download/(name+'.guard.json')).read_bytes())
  need(guard['nonce']==spec['nonce'] and guard['mode']==('OK' if index==0 else 'FAIL') and guard['hInstall']>0 and guard['pid']>0 and guard['tid']>0 and guard['productRc']==0 and guard['productValid'] is True,'Actual Type1 hInstall and product')
  need(guard['createdRecord']>0 and guard['formatRc']==0 and guard['fieldRc']==0 and guard['messageAttempted'] is True and type(guard['messageReturn']) is int and guard['messageReturn']>=0 and guard['recordCloseAttempted'] is True and guard['recordCloseReturn']==0 and guard['intendedReturn']==(0 if index==0 else 1603) and guard['authority']=='NONE','Actual self-created record message and checkedclose')
  raw=(download/(name+'.callbacks.jsonl')).read_bytes();need(raw.endswith(b'\n') and len(raw)<=8388608,'Complete bounded callback journal')
  callbacks=[json.loads(x) for x in raw.splitlines()];need(callbacks and len(callbacks)<=20000 and [x['sequence'] for x in callbacks]==list(range(1,len(callbacks)+1)),'Actual ordered callbacks')
  for row in callbacks:
   need(row['pid']==case['originalProcess']['Pid'] and row['originalTid']==case['originalThread']['Tid'] and row['tid']>0 and row['record']>0 and row['borrowedRecordClosed'] is False and row['clockValid'] is True and row['callbackReturn']==1,'Borrowed callback belongs to actual G; no assumed callback thread')
   need(0<=row['fieldCount']<=65535 and len(row['fields'])==min(row['fieldCount'],8)+1,'Bounded copied record fields')
  def field(row,i):
   hits=[x for x in row['fields'] if x['index']==i];need(len(hits)==1,'One record field');f=hits[0];v=f['utf16Hex'];need(re.fullmatch('(?:[0-9a-f]{4})*',v) is not None,'UTF16 units')
   return ''.join(chr(int(v[j:j+4],16)) for j in range(0,len(v),4)),f
  info=[];successors=[]
  prefix='FC80|nonce='+spec['nonce']+'|mode='+('OK' if index==0 else 'FAIL')+'|stage=INFO|'
  for row in callbacks:
   if row['fieldCount']<1:continue
   text,f=field(row,1)
   if (row['messageType']&0xff000000)==0x04000000 and text.startswith('FC80|'):
    need(text.startswith(prefix) and f['return']==0 and f['requiredChars']==len(text),'Exact complete nonce INFO')
    need('|caPid='+str(guard['pid'])+'|caTid='+str(guard['tid'])+'|hInstall='+str(guard['hInstall'])+'|valid=1' in text,'Actual CA diagnostic identity copied in original G')
    info.append(row)
   if (row['messageType']&0xff000000)==0x08000000 and text=='InstallInitialize':
    need(f['return']==0 and f['requiredChars']==len(text),'Complete typed action field');successors.append(row)
  need(len(info)==1,'Exactly one real nonce INFO forwarded in quiet mode')
  need((len(successors)==1 and successors[0]['sequence']>info[0]['sequence']) if index==0 else len(successors)==0,'Successor follows returned guard0; guard1603 has no successor')
  log=decode_log((download/(name+'-msi.log')).read_bytes());need(re.search(r'Action ended .*ProbeGuard\. Return value '+('1' if index==0 else '3')+r'\.',log) is not None,'Actual engine guard action return')
  proofs.append({'case':name,'guard':guard,'infoSequence':info[0]['sequence'],'callbackThreadIds':sorted({x['tid'] for x in callbacks}),'successorSequences':[x['sequence'] for x in successors],'callbackCount':len(callbacks),'scope':'API_FACTS_ONLY_NOT_PERMISSION_OR_PRODUCTION_AUTHORITY'})
 return proofs

def parent_preserved(before,after):
 if before['status']=='KNOWN_ABSENT':return after['status']=='KNOWN_ABSENT'
 return before['status']==after['status']=='PRESENT' and before['ownerSid']==after['ownerSid'] and before['securityDescriptor']==after['securityDescriptor'] and set(before['valueNames'])==set(after['valueNames']) and set(before['subkeyNames'])==set(after['subkeyNames'])
def decode_log(data):
 need(len(data)<=8388608,'Bounded original MSI log')
 if data[:2]==b'\xff\xfe':return data.decode('utf-16','strict')
 if data[:2]==b'\xfe\xff':return data.decode('utf-16','strict')
 return data.decode('utf-8-sig','strict')
def collect_exact_paths(r,logs,spec):
 paths={};temp=PureWindowsPath(spec['windowsRoot']).parent
 def add(value,basis):
  p=PureWindowsPath(value)
  need(str(p)==value and p.is_absolute() and p.parent in (PureWindowsPath('C:\\Windows\\Installer'),temp) and re.fullmatch(r'(?:MSI[0-9a-f]+\.tmp|[0-9a-f]+\.msi)',p.name,re.I) and not any(x in value for x in ('\0','\r','\n','"')),'Exact own Installer/TEMP path only')
  paths.setdefault(str(p),set()).add(basis)
 for name,text in logs.items():
  for line in text.splitlines():
   for marker,pattern in [('cache',r"Package we're running from ==> (.+)$"),('script',r'Running Script:\s*(.+)$'),('dll',r'Invoking remote custom action\. DLL:\s*(.+?),\s*Entrypoint:')]:
    m=re.search(pattern,line,re.I)
    if m:add(m.group(1).strip(),name+':'+marker)
 need(1<=len(paths)<=64 and any(any(v.endswith(':cache') for v in origins) for origins in paths.values()),'Original exact cache/log evidence required')
 return [{'path':p,'basis':sorted(v)} for p,v in sorted(paths.items())]

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--validate-inputs-only',action='store_true');p.add_argument('--prototype-freeze',type=Path);p.add_argument('--prototype-freeze-sha256');p.add_argument('--stage-dir',type=Path);p.add_argument('--manifest-sha256');p.add_argument('--output-dir',type=Path);a=p.parse_args()
 need(not(a.execute and a.validate_inputs_only),'ChooseexecuteORvalidate')
 if not a.execute and not a.validate_inputs_only:print(json.dumps({'status':'PREPARED_NOT_RUN','Windows':'NOT_CONTACTED','productionAuthority':'NONE'}));return 0
 need(all((a.prototype_freeze,a.prototype_freeze_sha256,a.stage_dir,a.manifest_sha256,a.output_dir)),'All explicit arguments')
 need((E/'.owner').read_bytes()==b'future-classroom-owned-r80-controlled-repair/v1\n','OwnedR80root')
 need(fact(BASE)['sha256']==BASE_SHA,'Exact archived base transport')
 base=runpy.run_path(str(BASE));transport_identity=fact(Path(__file__).resolve());freeze_path=owned(a.prototype_freeze)
 need(freeze_path.parent==PROTOTYPE and fact(freeze_path)['sha256']==a.prototype_freeze_sha256,'Explicit probe source freeze')
 freeze=json.loads(freeze_path.read_text());need(freeze['status']=='PREPARED_API_PROBE_ONLY_WINDOWS_NOT_RUN','Source-only freeze')
 def sources():
  need(fact(Path(__file__).resolve())==transport_identity and fact(BASE)['sha256']==BASE_SHA,'Transport unchanged')
  for row in freeze['files']:
   rel=row['path'];need(rel and not rel.startswith('/') and ':' not in rel and '\\' not in rel and all(x not in ('','.','..') for x in rel.split('/')),'Safe frozen relative path')
   need(fact(PROTOTYPE/rel)=={k:row[k] for k in ('bytes','sha256')},'Actual source freeze byte')
 sources();stage=owned(a.stage_dir);need(stage.parent.parent==E and stage.name=='stage' and stage.is_dir() and not stage.is_symlink(),'Fresh produced stage under R')
 need({x.name for x in stage.iterdir()}==NAMES|{'runtime-inputs.json'} and all(x.is_file() and not x.is_symlink() for x in stage.iterdir()),'Exact flat stage')
 manifest_path=stage/'runtime-inputs.json';need(fact(manifest_path)['sha256']==a.manifest_sha256,'Explicit manifest');manifest=json.loads(manifest_path.read_bytes())
 need(manifest['status']=='PREPARED_RUNTIME_NOT_RUN' and len(manifest['files'])==10 and {x['path'] for x in manifest['files']}==NAMES,'Stage input closure')
 for row in manifest['files']:need(fact(stage/row['path'])=={k:row[k] for k in ('bytes','sha256')},'Actual stage byte')
 spec=json.loads((stage/'spec.json').read_bytes());need(fact(stage/'spec.json')['sha256']==manifest['specSha256'],'Actual spec')
 need(spec['expectedUserSid']==base['SID'] and spec['sourceGit']=='b7e4c938ab8ff391e2ad6c1d681e074881118c0a' and re.fullmatch('[0-9a-f]{32}',spec['nonce']) and spec['rootName']=='FutureClassroom-r80-ui-record-probe-'+spec['nonce'] and spec['windowsRoot']==str(PureWindowsPath('C:/Users/Elior/AppData/Local/Temp')/spec['rootName']),'Fresh private source and namespace')
 need(spec['effectDir']==str(PureWindowsPath(spec['windowsRoot'])/'effect')+'\\' and spec['registryKey']=='Software\\FutureClassroomTest\\Round80-Probe-'+spec['nonce'] and spec['marker']=='future-classroom-owned-r80-ui-record-probe/v1\n','Closed private effects')
 need((spec['wholeSeconds'],spec['nativeSeconds'],spec['clientSeconds'],spec['finallyReserveSeconds'],spec['maximumHandles'],spec['maximumOwners'])==(600,120,120,180,64,8),'Budgets unchanged')
 ids=[spec[k] for k in ('productCode','upgradeCode','componentId')];need(len(set(ids))==3 and all(re.fullmatch(r'\{[0-9A-F]{8}(?:-[0-9A-F]{4}){3}-[0-9A-F]{12}\}',x) for x in ids),'Fresh distinct GUIDs')
 for name,row in spec['sources'].items():need(fact(SOURCE_DIR/name)==row,'Actual producer source byte')
 for name in ('Capture.cs','Invoke-Probe.ps1'):need(fact(stage/name)==spec['sources'][name],'Runtime source byte')
 build=json.loads((stage/'build-report.json').read_bytes());need(fact(stage/'build-report.json')['sha256']==manifest['buildReportSha256'] and build['status']=='PASS_STATIC_ONLY_WINDOWS_NOT_RUN' and build['windows']=='NOT_RUN' and build['spec']==fact(stage/'spec.json') and build['sourcesUnchanged'] is True and build['toolsUnchanged'] is True,'Actual local build provenance')
 need(build['commands'] and all(type(x['actualExit']) is int and x['actualExit']==0 and x['parentReaped'] is True for x in build['commands']),'Actual all producer tools exit0')
 for name,key in [('Owner.exe','owner'),('Guard.dll','observer'),('payload.txt','payload')]:need(fact(stage/name)==build[key],'Produced PE/payload byte')
 for name,target in [('healthy','Fc80GuardOk'),('early-fail','Fc80GuardFail')]:
  case=build['cases'][name];need(fact(stage/(name+'.msi'))==case['msi'] and 'MsiEmbeddedChainer' not in case['tables'],'Actual private MSI')
  need(case['tables']['CustomAction']==[{'Action':'ProbeGuard','Type':'1','Source':'ObserverDll','Target':target}],'One synchronous immediate Type1')
  seq=case['tables']['InstallExecuteSequence'];need([x for x in seq if x['Action']=='ProbeGuard']==[{'Action':'ProbeGuard','Condition':'NOT Installed','Sequence':'1499'}] and any(x['Action']=='InstallInitialize' and x['Sequence']=='1500' for x in seq),'Exact guard and successor sequence')
 need(build['cases']['healthy']['packageCode']!=build['cases']['early-fail']['packageCode'],'Distinct package codes')
 # Reuse only archived constants, adapted to fresh explicit nonce. No old main runs.
 for name in ('COMMON','CREATE','DELETE'):
  base[name]=base[name].replace('FutureClassroom-r79-early-terminal-','FutureClassroom-r80-ui-record-probe-').replace('future-classroom-owned-r79-early-terminal-fixture/v1','future-classroom-owned-r80-ui-record-probe/v1')
 out=owned(a.output_dir);need(out.parent==E and not out.exists(),'Fresh direct owned result directory')
 if a.validate_inputs_only:print(json.dumps({'status':'PASS_API_PROBE_LOCAL_INPUT_ADMISSION_ONLY','Windows':'NOT_CONTACTED','manifest':fact(manifest_path),'sourceFreeze':fact(freeze_path)}));return 0
 out.mkdir();(out/'.owner').write_text('future-classroom-owned-r80-ui-record-probe-result/v1\n')
 rp=out/'runtime-operation.json';report={'status':'RUNNING_FIXTURE_ONLY','productionAuthority':'NONE','transport':{'path':str(Path(__file__).resolve()),**transport_identity},'baseTransport':{'path':str(BASE),**fact(BASE)},'phaseSeconds':600,'clientSeconds':120,'finallyReserveSeconds':180,'latestNewClientStartCutoffSeconds':300,'outerTransportSeconds':900,'sourceFreeze':{'path':str(freeze_path),**fact(freeze_path)},'stageManifest':{'path':str(manifest_path),**fact(manifest_path)},'spec':fact(stage/'spec.json'),'operations':[],'cleanup':'NOT_RUN','startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 c={'root':spec['windowsRoot'],'nonce':spec['nonce'],'sid':base['SID'],'spec':spec,'manifest':manifest,'specSha256':manifest['specSha256'],'manifestSha256':a.manifest_sha256};report['remoteRoot']=c['root']
 common=base['COMMON'].split('function Inventory {')[0]+PARENT_PS+INVENTORY_PS
 start=time.monotonic();phase_natural=False;phase=None;download_ok=False;inventory=None
 def save():rp.write_text(json.dumps(report,indent=2)+'\n')
 def call(label,args,feed=None,limit=15):
  remaining=900-(time.monotonic()-start);need(remaining>0,'Original outer transport clock');proc=None;stdout=b'';stderr=b'';code=None;timed=False;began=time.monotonic()
  try:
   proc=subprocess.Popen(args,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   try:stdout,stderr=proc.communicate(feed,timeout=min(remaining,limit))
   except subprocess.TimeoutExpired:timed=True;proc.kill();stdout,stderr=proc.communicate() # only local ssh/scp; no remote kill
   code=proc.returncode
  finally:
   row={'label':label,'argv':args,'actualLocalExit':code,'localParentReaped':bool(proc and proc.poll() is not None),'remoteReturnKnown':code is not None and not timed,'timedOut':timed,'seconds':time.monotonic()-began}
   for ext,data in [('stdin.ps1',feed),('stdout.log',stdout),('stderr.log',stderr)]:
    if data is not None:q=out/(label+'.'+ext);q.write_bytes(data);row[ext]={'path':q.name,**fact(q)}
   report['operations'].append(row);save()
  need(not timed and code is not None,'Remote original return UNKNOWN; retain and stop');return code,stdout
 def ps(label,body,config=None,limit=15):
  cfg=c if config is None else config;feed=("$c='"+json.dumps(cfg,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+common+body).encode()
  cmd='powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand '+base64.b64encode(base['BOOT'].encode('utf-16-le')).decode();return call(label,['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8',base['HOST'],cmd],feed,limit)
 save()
 try:
  create=base['CREATE'].replace("@{status='PASS_CREATED_ONLY_PROTECTED_COMPILE_ROOT';root=$c.root;nonce=$c.nonce;sid=$c.sid}","@{status='PASS_CREATED_ONLY_PROTECTED_FIXTURE_RUNTIME_ROOT';root=$c.root;nonce=$c.nonce;sid=$c.sid;registryParentBefore=$parentBefore}")
  prefix="$who=[Security.Principal.WindowsIdentity]::GetCurrent();try{Need ($who.User.Value-ceq $c.sid) 'EXACT_USER_BEFORE_PARENT_QUERY'}finally{$who.Dispose()};$parentBefore=Parent-State;"
  code,raw=ps('01-before-parent-and-create',prefix+create);need(code==0,'Actual fresh protected root create0');before=json.loads(raw.decode('utf-8-sig'));need(before['status']=='PASS_CREATED_ONLY_PROTECTED_FIXTURE_RUNTIME_ROOT' and before['root']==c['root'],'Actual exact runtime root');report['before']=before
  files=[x for x in sorted(stage.iterdir()) if x.name!='.owner'];need(len(files)==10,'Ten uploads excluding remotely created marker')
  code,_=call('02-upload-actual-stage',['scp','-q','-o','BatchMode=yes','-o','ConnectTimeout=8',*[str(x) for x in files],base['HOST']+':'+c['root'].replace('\\','/')+'/'],limit=60);need(code==0,'Actual stage SCP0')
  run="Root-Check;& (Join-Path $c.root 'Invoke-Probe.ps1') -Execute -Root $c.root -ManifestSha256 $c.manifestSha256"
  code,raw=ps('03-original-fixture-phase',run,limit=620);need(code in (0,90),'Actual controlled phase parent code0/90; SSH255 remains UNKNOWN');phase_natural=True;phase=json.loads(raw.decode('utf-8-sig'));report['phase']=phase;report['phaseParentExit']=code
  try:report['originalControlProof']=validate_phase(phase,spec,build['owner']['sha256']);need(code==0,'Original phase parent must be actual0 for PASS')
  except Exception as error:report['phaseQualificationError']=str(error)
 except Exception as error:report.update(status='FAIL_FIXTURE_TRANSPORT_OR_PHASE_RETAIN',errorType=type(error).__name__,error=str(error))
 # Never query/delete after an unknown original phase SSH return. On known
 # failed parent return, raw file capture is read-only and never grants cleanup.
 if phase_natural:
  try:
   code,raw=ps('04-readonly-original-inventory','Inventory|ConvertTo-Json -Depth 30 -Compress');need(code==0,'Actual original inventory0');inventory=json.loads(raw);inventory_identity(inventory);report['inventory']=inventory
   download=out/'download';download.mkdir()
   for dname in sorted(inventory['directories'],key=lambda x:(x.count('/'),x)):(download/dname).mkdir(parents=True,exist_ok=True)
   for i,row in enumerate(inventory['files']):
    target=download/row['path'];target.parent.mkdir(parents=True,exist_ok=True);remote=base['HOST']+':'+(c['root']+'\\'+row['path'].replace('/','\\')).replace('\\','/')
    code,_=call('05-download-'+str(i).zfill(3),['scp','-q','-o','BatchMode=yes','-o','ConnectTimeout=8',remote,str(target)],limit=15);need(code==0 and fact(target)=={k:row[k] for k in ('bytes','sha256')},'Original captured byte/SHA')
   code,raw=ps('06-second-readonly-inventory','Inventory|ConvertTo-Json -Depth 30 -Compress');need(code==0 and inventory_identity(json.loads(raw))==inventory_identity(inventory),'Captured original inventory stable after download');download_ok=True;report['downloadVerified']=True
   need(json.loads((download/'probe-result.json').read_text())==phase,'Original phase JSON file equals actual original stdout facts')
   need('phaseQualificationError' not in report and report.get('originalControlProof',{}).get('status')=='PASS_ORIGINAL_CONTROLLED_OWNER_API_AND_PHYSICAL_RETURNS','Failed phase always retained even if capture complete')
   logs={p.name:decode_log(p.read_bytes()) for p in sorted(download.glob('*-msi.log'))};need(len(logs)==2,'Two exact original G MSI logs')
   report['apiProbeFacts']=qualify_probe(download,phase,spec)
   exact=collect_exact_paths(phase,logs,spec);report['derivedExactSystemPaths']=exact
   code,raw=ps('07-independent-final-readonly',READBACK_PS,{**c,'paths':[x['path'] for x in exact]},limit=45);need(code==0,'Actual readonly final parent0');readback=json.loads(raw);report['finalReadOnly']=readback
   need(readback['status']=='ACTUAL_READONLY_FIXTURE_AND_EXACT_SYSTEM_PATH_FACTS' and readback['fixtureKnownAbsent'] is True and {x['path'] for x in readback['paths']}=={x['path'] for x in exact} and len(readback['paths'])==len(exact) and all(x['fact']['status']=='KNOWN_ABSENT' for x in readback['paths']),'Exact original helper/DLL/cache/RunningScript and fixture absence')
   need(parent_preserved(before['registryParentBefore'],readback['registryParent']),'Registry parent changed or newly-created parent retained; no silent/manual deletion')
   # Readback Add-Type has its own owned compile files. Capture the complete
   # extended inventory too; never remove any undownloaded new compiler artifact.
   code,raw=ps('08-after-readonly-compiler-inventory','Inventory|ConvertTo-Json -Depth 30 -Compress');need(code==0,'Actual extended inventory0');extended=json.loads(raw);inventory_identity(extended)
   old_by={x['path']:x for x in inventory['files']};new_by={x['path']:x for x in extended['files']}
   need(all(new_by.get(k)==v for k,v in old_by.items()),'Original artifacts unchanged after readonly')
   for dname in sorted(extended['directories'],key=lambda x:(x.count('/'),x)):(download/dname).mkdir(parents=True,exist_ok=True)
   for i,row in enumerate(extended['files']):
    if row['path'] in old_by:continue
    need(row['path'].startswith('readback-compiler-temp/'),'Only final reader-owned compiler artifacts added');target=download/row['path'];target.parent.mkdir(parents=True,exist_ok=True);remote=base['HOST']+':'+(c['root']+'\\'+row['path'].replace('/','\\')).replace('\\','/')
    code,_=call('09-download-readback-'+str(i),['scp','-q','-o','BatchMode=yes','-o','ConnectTimeout=8',remote,str(target)],limit=15);need(code==0 and fact(target)=={k:row[k] for k in ('bytes','sha256')},'Original readback compiler artifact captured')
   sources();code,raw=ps('10-final-stable-inventory','Inventory|ConvertTo-Json -Depth 30 -Compress');need(code==0 and inventory_identity(json.loads(raw))==inventory_identity(extended),'Exact final inventory stable')
   code,raw=ps('10b-zero-own-processes',ZERO_PS);need(code==0,'Actual zero own helper/compiler parent0');report['zeroOwnProcesses']=json.loads(raw);need(report['zeroOwnProcesses']['ownCount']==0,'No live owned process')
   code,raw=ps('11-exact-downloaded-root-delete',base['DELETE'].replace('PASS_REMOVED_EXACT_DOWNLOADED_COMPILE_ROOT','PASS_REMOVED_EXACT_DOWNLOADED_RUNTIME_ROOT'),{**c,'inventory':extended});need(code==0,'Actual exact cleanup parent0');cleanup=json.loads(raw);need(cleanup['status']=='PASS_REMOVED_EXACT_DOWNLOADED_RUNTIME_ROOT' and cleanup['knownAbsent'] is True,'Exact nonce root known absent')
   report['cleanup']=cleanup;report['finalInventory']=extended;report['status']='PASS_FINITE_QUIET_TYPE1_INFO_AND_SUCCESSOR_API_PROBE_NOT_PRODUCTION_AUTHORITY'
  except Exception as error:report.update(status='FAIL_FIXTURE_CAPTURE_OR_QUALIFICATION_RETAIN',errorType=type(error).__name__,error=str(error),partialDownloadMayExist=True)
 report['elapsedSeconds']=time.monotonic()-start;report['originalPhaseNaturalReturn']=phase_natural;report['downloadVerified']=download_ok;save()
 print(json.dumps({'status':report['status'],'report':str(rp),'sha256':fact(rp)['sha256'],'remoteRoot':c['root'],'cleanup':report['cleanup']}));return 0 if report['status'].startswith('PASS_') else 1
if __name__=='__main__':raise SystemExit(main())
