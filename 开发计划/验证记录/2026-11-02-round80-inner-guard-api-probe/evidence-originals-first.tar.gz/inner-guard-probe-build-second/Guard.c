#ifndef UNICODE
#define UNICODE
#endif
#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0601
#include <windows.h>
#include <msi.h>
#include <msiquery.h>
#include <stdio.h>
#include <wchar.h>
#include "owner_config.h"
/* Probe only: hInstall is supplied by the actual Type1 invocation. No B, pipe,
 * Pending, permission property, inherited numeric handle or authority is used. */
static UINT probe(MSIHANDLE install,BOOL fail) {
 WCHAR product[64];DWORD chars=64;
 UINT product_rc=MsiGetPropertyW(install,L"ProductCode",product,&chars);
 BOOL valid=product_rc==ERROR_SUCCESS&&wcscmp(product,FC_OWNER_PRODUCT)==0;
 MSIHANDLE record=MsiCreateRecord(1);
 WCHAR message[512];int formatted=swprintf(message,512,L"FC80|nonce=%ls|mode=%ls|stage=INFO|caPid=%lu|caTid=%lu|hInstall=%lu|valid=%u",FC_OWNER_NONCE_W,fail?L"FAIL":L"OK",GetCurrentProcessId(),GetCurrentThreadId(),(unsigned long)install,valid?1u:0u);
 UINT format_rc=record?MsiRecordSetStringW(record,0,L"[1]"):ERROR_INVALID_HANDLE;
 UINT field_rc=record&&formatted>0&&formatted<512?MsiRecordSetStringW(record,1,message):ERROR_INVALID_DATA;
 int message_rc=-2147483647;
 if(record&&valid&&format_rc==0&&field_rc==0)message_rc=MsiProcessMessage(install,INSTALLMESSAGE_INFO,record);
 /* Only this self-created record is closed. Actual returned value preserved. */
 UINT record_close=record?MsiCloseHandle(record):ERROR_INVALID_HANDLE;
 BOOL good=valid&&record!=0&&format_rc==0&&field_rc==0&&record_close==0&&message_rc>=0;
 UINT intended=good&&!fail?ERROR_SUCCESS:ERROR_INSTALL_FAILURE;
 WCHAR path[1024];int pn=swprintf(path,1024,L"%ls\\%ls.guard.json",FC_OWNER_ROOT,fail?L"early-fail-rollback":L"healthy-rollback");
 HANDLE file=pn>0&&pn<1024?CreateFileW(path,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,NULL):INVALID_HANDLE_VALUE;
 if(file==INVALID_HANDLE_VALUE)return ERROR_INSTALL_FAILURE;
 char text[2048];DWORD written=0;
 int n=snprintf(text,sizeof(text),"{\"nonce\":\"%s\",\"mode\":\"%s\",\"pid\":%lu,\"tid\":%lu,\"hInstall\":%lu,\"productRc\":%u,\"productValid\":%s,\"createdRecord\":%lu,\"formatRc\":%u,\"fieldRc\":%u,\"messageAttempted\":%s,\"messageReturn\":%d,\"recordCloseAttempted\":%s,\"recordCloseReturn\":%u,\"intendedReturn\":%u,\"authority\":\"NONE\"}\n",FC_OWNER_NONCE,fail?"FAIL":"OK",GetCurrentProcessId(),GetCurrentThreadId(),(unsigned long)install,product_rc,valid?"true":"false",(unsigned long)record,format_rc,field_rc,message_rc!=-2147483647?"true":"false",message_rc,record?"true":"false",record_close,intended);
 BOOL output=n>0&&(size_t)n<sizeof(text)&&WriteFile(file,text,(DWORD)n,&written,NULL)&&written==(DWORD)n&&FlushFileBuffers(file);
 BOOL closed=CloseHandle(file);
 return output&&closed?intended:ERROR_INSTALL_FAILURE;
}
__declspec(dllexport) UINT __stdcall Fc80GuardOk(MSIHANDLE install){return probe(install,FALSE);}
__declspec(dllexport) UINT __stdcall Fc80GuardFail(MSIHANDLE install){return probe(install,TRUE);}
