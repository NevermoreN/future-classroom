#define FC79_NONCE L"5b8e765e944a41308b9efca5d617d096"
#define FC79_PRODUCT L"{D650EB28-2D9A-4D8A-A071-3E172A9C40E5}"
#define FC79_EFFECT_DIR L"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r80-ui-record-probe-5b8e765e944a41308b9efca5d617d096\\effect\\"
