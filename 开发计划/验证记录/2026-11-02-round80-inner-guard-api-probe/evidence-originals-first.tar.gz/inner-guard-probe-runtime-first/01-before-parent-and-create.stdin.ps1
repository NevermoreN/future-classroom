$c='{"root":"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r80-ui-record-probe-5b8e765e944a41308b9efca5d617d096","nonce":"5b8e765e944a41308b9efca5d617d096","sid":"S-1-5-21-3896111207-1867804362-1971593122-1001","spec":{"schemaVersion":1,"status":"PREPARED_NOT_RUN","nonce":"5b8e765e944a41308b9efca5d617d096","rootName":"FutureClassroom-r80-ui-record-probe-5b8e765e944a41308b9efca5d617d096","windowsRoot":"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r80-ui-record-probe-5b8e765e944a41308b9efca5d617d096","effectDir":"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r80-ui-record-probe-5b8e765e944a41308b9efca5d617d096\\effect\\","marker":"future-classroom-owned-r80-ui-record-probe/v1\n","expectedUserSid":"S-1-5-21-3896111207-1867804362-1971593122-1001","registryKey":"Software\\FutureClassroomTest\\Round80-Probe-5b8e765e944a41308b9efca5d617d096","wholeSeconds":600,"nativeSeconds":120,"clientSeconds":120,"finallyReserveSeconds":180,"maximumHandles":64,"maximumOwners":8,"sourceGit":"b7e4c938ab8ff391e2ad6c1d681e074881118c0a","scope":"ONLY_QUIET_TYPE1_MESSAGE_AND_SUCCESSOR_CALLBACK_API_FACTS_NOT_AUTHORITY","sources":{"Owner.c":{"bytes":11286,"sha256":"610cc55e331176c96cac2fa5635bf9cbf5db7e307ef03c139d6fd74eb1b44352"},"Guard.c":{"bytes":2934,"sha256":"74cf37d56b960a3d055d377ba485f3a8131861f22ae8fe80e64238879bbfdafd"},"Capture.cs":{"bytes":11335,"sha256":"cd2f47598504deef0a2721a6d61d3cf95a8e93aa6146e4fadeb8744f4e924580"},"Invoke-Probe.ps1":{"bytes":10888,"sha256":"72b1e83c7cb3a0c61f558fc8788e0d273b153148ce87c69c39cf43b289090442"},"build-probe-second.py":{"bytes":15295,"sha256":"15c5e7578116843dd55442c95fc292ce7a7aebf2e5b942cfc5f7026004f102a8"},"reference/fixture-original.py":{"bytes":24097,"sha256":"6e1c8520ac799af57ed0b9a440cb3e855c6629cead01a4a6d18b1279a438360a"}},"productCode":"{D650EB28-2D9A-4D8A-A071-3E172A9C40E5}","upgradeCode":"{9E0B9A57-6CAE-4598-B3F2-19C728B7CE1A}","componentId":"{AB3AA019-2EC1-4A80-A29A-090C6E47DBF7}"},"manifest":{"status":"PREPARED_RUNTIME_NOT_RUN","specSha256":"fbca3a0b29ba867a1a22487ace91607cd51b7e9adfebb49c5bdc29881401b4a3","buildReportSha256":"b9ce6fb68af13209a625afce5256a358ece12ec7099583523bc2d216b6945375","files":[{"path":".owner","bytes":46,"sha256":"9246f5672b7ef6ec21f87b3d62e70baad75baf3a4f542ebc5ec3374087b78709"},{"path":"Capture.cs","bytes":11335,"sha256":"cd2f47598504deef0a2721a6d61d3cf95a8e93aa6146e4fadeb8744f4e924580"},{"path":"Guard.dll","bytes":266300,"sha256":"520a9c281ea39068a1fcc66de456af58a4cdb59e64e3767cc2a071b84d27cac4"},{"path":"Invoke-Probe.ps1","bytes":10888,"sha256":"72b1e83c7cb3a0c61f558fc8788e0d273b153148ce87c69c39cf43b289090442"},{"path":"Owner.exe","bytes":300027,"sha256":"375f3ce00a6d3d13670479aa4217f8c8a954487269af83e2472e699fdff0a0ca"},{"path":"build-report.json","bytes":66688,"sha256":"b9ce6fb68af13209a625afce5256a358ece12ec7099583523bc2d216b6945375"},{"path":"early-fail.msi","bytes":280576,"sha256":"7f66d546a234413cf2e5fe4bcac6c95b3f769871fb6ee7765234fce761afef0d"},{"path":"healthy.msi","bytes":280576,"sha256":"1c105482c7fdf6e60e55e7fda6ff863a47999632228f7a9c0f7fbacbc733ead4"},{"path":"payload.txt","bytes":75,"sha256":"7c820c67b81d58159dc64b674f31cf74296b9adaec5612a1cffd48dc523a585d"},{"path":"spec.json","bytes":1999,"sha256":"fbca3a0b29ba867a1a22487ace91607cd51b7e9adfebb49c5bdc29881401b4a3"}]},"specSha256":"fbca3a0b29ba867a1a22487ace91607cd51b7e9adfebb49c5bdc29881401b4a3","manifestSha256":"fac37d0612d2be9951e3ef9fbaea3c5aa8687c37e203a5dd446da5b285edf6de"}'|ConvertFrom-Json;
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Need([bool]$v,[string]$s){if(-not $v){throw $s}}
function Absent([string]$p){try{[void][IO.File]::GetAttributes($p);return $false}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-is [IO.FileNotFoundException] -or $e-is [IO.DirectoryNotFoundException]){return $true};throw}}
function Fact([string]$p){$a=[IO.File]::GetAttributes($p);Need (-not($a-band[IO.FileAttributes]::ReparsePoint) -and -not($a-band[IO.FileAttributes]::Directory)) 'REGULAR_NONREPARSE';$size=[long]([IO.FileInfo]::new($p).Length);Need ($size-ge 0 -and $size-le 16777216) 'FILE_BOUND';@{bytes=$size;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function Root-Check {
 Need ($PSVersionTable.PSVersion.Major-eq 5 -and [IntPtr]::Size-eq 8) 'DESKTOP_PS51_X64'
 Need ([IO.Path]::GetFullPath($c.root)-ceq $c.root -and [IO.Path]::GetFileName($c.root)-ceq ('FutureClassroom-r80-ui-record-probe-'+$c.nonce)) 'CLOSED_ROOT'
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent();try{Need ($identity.User.Value-ceq $c.sid) 'EXPECTED_CURRENT_USER'}finally{$identity.Dispose()}
 $cursor=$c.root;while($cursor){$a=[IO.File]::GetAttributes($cursor);Need (($a-band[IO.FileAttributes]::ReparsePoint)-eq 0 -and ($a-band[IO.FileAttributes]::Directory)-ne 0) 'DIRECTORY_NO_REPARSE';$cursor=[IO.Path]::GetDirectoryName($cursor)}
 Need ([IO.File]::ReadAllText((Join-Path $c.root '.owner'))-ceq "future-classroom-owned-r80-ui-record-probe/v1`n") 'OWNER_MARKER'
 $acl=[IO.Directory]::GetAccessControl($c.root);Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq $c.sid) 'PROTECTED_OWNER'
 $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($rules.Count-eq 2) 'TWO_ACES'
 $who=@($rules|ForEach-Object {$_.IdentityReference.Value}|Sort-Object -Unique);Need ($who.Count-eq 2 -and $c.sid-in $who -and 'S-1-5-18'-in $who) 'USER_AND_SYSTEM'
 foreach($r in $rules){Need ($r.AccessControlType-eq 'Allow' -and ($r.FileSystemRights-band [Security.AccessControl.FileSystemRights]::FullControl)-eq [Security.AccessControl.FileSystemRights]::FullControl) 'EXACT_ALLOW_FULLCONTROL'}
}

function Parent-State {
 $base=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry32);$key=$null
 try{
  $key=$base.OpenSubKey('Software\FutureClassroomTest',$false)
  if($null-eq $key){return @{status='KNOWN_ABSENT';key='Software\FutureClassroomTest';view='Registry32'}}
  $values=@($key.GetValueNames());$subkeys=@($key.GetSubKeyNames());Need ($values.Count-le 64 -and $subkeys.Count-le 128) 'PARENT_SNAPSHOT_BOUND'
  $acl=$key.GetAccessControl([Security.AccessControl.AccessControlSections]::Owner -bor [Security.AccessControl.AccessControlSections]::Access)
  @{status='PRESENT';key='Software\FutureClassroomTest';view='Registry32';ownerSid=$acl.GetOwner([Security.Principal.SecurityIdentifier]).Value;securityDescriptor=$acl.GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]::Owner -bor [Security.AccessControl.AccessControlSections]::Access);valueNames=@($values|Sort-Object);subkeyNames=@($subkeys|Sort-Object)}
 }finally{if($null-ne $key){$key.Dispose()};$base.Dispose()}
}

function Inventory {
 Root-Check;$files=@();$dirs=@();$total=0L;$queue=[Collections.Generic.Queue[string]]::new();$queue.Enqueue($c.root)
 while($queue.Count){$dir=$queue.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){
  $attrs=[IO.File]::GetAttributes($p);Need (($attrs-band[IO.FileAttributes]::ReparsePoint)-eq 0) 'INVENTORY_REPARSE'
  $rel=$p.Substring($c.root.Length+1).Replace('\','/')
  if(($attrs-band[IO.FileAttributes]::Directory)-ne 0){$top=($rel-split '/')[0];Need ($top-cin @('compiler-temp','readback-compiler-temp','effect')) 'ONLY_OWN_FIXTURE_SUBDIRECTORIES';$dirs+=$rel;$queue.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256};$total+=$f.bytes}
  Need ($files.Count-le 256 -and $dirs.Count-le 32 -and $total-le 67108864) 'RUNTIME_INVENTORY_BOUND'
 }}
 @{files=$files;directories=$dirs}
}
$who=[Security.Principal.WindowsIdentity]::GetCurrent();try{Need ($who.User.Value-ceq $c.sid) 'EXACT_USER_BEFORE_PARENT_QUERY'}finally{$who.Dispose()};$parentBefore=Parent-State;
Need ($c.nonce-cmatch '^[0-9a-f]{32}$' -and $c.sid-cmatch '^S-1-5-21-') 'NONCE_SID'
$identity=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$identity.User;Need ($sid.Value-ceq $c.sid) 'EXACT_USER'}finally{$identity.Dispose()}
$expected=Join-Path ([IO.Path]::GetFullPath($env:TEMP)) ('FutureClassroom-r80-ui-record-probe-'+$c.nonce)
Need ($expected-ceq $c.root) 'SPEC_ROOT_MUST_EQUAL_ACTUAL_USER_TEMP_ROOT'
Need (Absent $c.root) 'PREEXISTING_ROOT_REFUSED'
$cursor=[IO.Path]::GetDirectoryName($c.root);while($cursor){Need (([IO.File]::GetAttributes($cursor)-band[IO.FileAttributes]::ReparsePoint)-eq 0) 'NO_ANCESTOR_REPARSE';$cursor=[IO.Path]::GetDirectoryName($cursor)}
[void][IO.Directory]::CreateDirectory($c.root)
$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false)
foreach($who in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($who,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))}
[IO.Directory]::SetAccessControl($c.root,$acl)
$owner=[Text.UTF8Encoding]::new($false).GetBytes("future-classroom-owned-r80-ui-record-probe/v1`n")
$f=[IO.File]::Open((Join-Path $c.root '.owner'),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);try{$f.Write($owner,0,$owner.Length);$f.Flush($true)}finally{$f.Dispose()}
Root-Check
@{status='PASS_CREATED_ONLY_PROTECTED_FIXTURE_RUNTIME_ROOT';root=$c.root;nonce=$c.nonce;sid=$c.sid;registryParentBefore=$parentBefore}|ConvertTo-Json -Compress
