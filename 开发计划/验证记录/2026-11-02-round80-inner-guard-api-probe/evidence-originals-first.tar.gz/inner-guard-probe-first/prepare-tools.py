#!/usr/bin/env python3
"""Explicit root-only private 7-deb reconstruction. Default inert; no global install."""
import argparse,hashlib,json,os,subprocess,time,shutil
from pathlib import Path
HERE=Path(__file__).resolve().parent
R=HERE.parent
MARKER=b'future-classroom-owned-r80-inner-guard-probe-first/v1\n'
def need(v,s):
 if not v:raise ValueError(s)
def fact(p):
 need(p.is_file() and not p.is_symlink(),'regular '+str(p));b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def main():
 p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');p.add_argument('--output',type=Path);a=p.parse_args()
 if not a.execute:print(json.dumps({'status':'PREPARED_NOT_RUN','globalInstallation':False}));return
 need((HERE/'.owner').read_bytes()==MARKER,'owned probe');need(a.output and a.output.is_absolute() and a.output.resolve()==a.output and a.output.parent==R and not a.output.exists(),'fresh direct R output')
 out=a.output;out.mkdir();(out/'.owner').write_text('future-classroom-owned-r80-private-msi-tools/v1\n');(out/'packages').mkdir();(out/'root').mkdir();(out/'wrappers').mkdir()
 cfg=json.loads((HERE/'reference/msi-tools-input-first.json').read_bytes());need(len(cfg['packages'])==7,'7 fixed packages')
 report={'status':'FAIL_RETAIN_ORIGINALS','globalInstallation':False,'windows':'NOT_RUN','commands':[],'packages':[],'tools':[]};start=time.monotonic()
 def run(label,argv,env=None,allowed=(0,)):
  left=900-(time.monotonic()-start);need(left>0,'900s tools budget');s=time.monotonic();v=subprocess.run(argv,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=min(120,left),check=False)
  for ext,b in [('stdout',v.stdout),('stderr',v.stderr)]:need(len(b)<=16777216,'log bound');(out/(label+'.'+ext)).write_bytes(b)
  report['commands'].append({'label':label,'argv':argv,'actualExit':v.returncode,'parentReaped':True,'seconds':time.monotonic()-s});need(v.returncode in allowed,'actual command '+label);return v.stdout
 try:
  for item in cfg['packages']:
   leaf=Path(item['officialRepositoryPath']).name;q=out/'packages'/leaf
   url=item['transferBase']+item['officialRepositoryPath'];need(url.startswith('https://mirrors.edge.kernel.org/ubuntu/pool/'),'fixed HTTPS repository')
   run('download-'+item['name'],['curl','--fail','--location','--proto','=https','--connect-timeout','15','--max-time','120','--output',str(q),url])
   need(fact(q)=={'bytes':item['bytes'],'sha256':item['sha256']},'exact archived package '+item['name'])
   fields=run('fields-'+item['name'],['dpkg-deb','--field',str(q),'Package','Version','Architecture']);need(('Package: '+item['name']+'\n').encode() in fields and ('Version: '+item['version']+'\n').encode() in fields,'actual package identity')
   run('extract-'+item['name'],['dpkg-deb','-x',str(q),str(out/'root')]);report['packages'].append(item)
  env=os.environ.copy()
  for k in ('LD_PRELOAD','LD_AUDIT','GIO_EXTRA_MODULES','GIO_MODULE_DIR'):env.pop(k,None)
  env.update(LD_LIBRARY_PATH=str(out/'root/usr/lib/x86_64-linux-gnu'),LC_ALL='C',GIO_USE_VFS='local',GSETTINGS_BACKEND='memory')
  for expected in cfg['expectedTools']:
   q=out/'root/usr/bin'/expected['name'];need(fact(q)=={k:expected[k] for k in ('bytes','sha256')},'exact archived tool');report['tools'].append({'name':expected['name'],'path':str(q),**fact(q)})
   listing=run('ldd-'+expected['name'],['ldd',str(q)],env);need(b'not found' not in listing,'all runtime libraries resolved')
   if expected['name']=='msibuild':run('usage-msibuild',[str(q)],env,(1,))
   else:need(b'0.103' in run('version-'+expected['name'],[str(q),'--version'],env),'actual tool version')
  wrapper=out/'wrappers/wixl';wrapper.write_text('#!/usr/bin/env python3\nimport os,sys\nfrom pathlib import Path\nr=Path('+repr(str(out))+')\nassert (r/".owner").read_bytes()==b"future-classroom-owned-r80-private-msi-tools/v1\\n"\ne=os.environ.copy()\nfor k in ("LD_PRELOAD","LD_AUDIT","GIO_EXTRA_MODULES","GIO_MODULE_DIR"):e.pop(k,None)\ne.update(LD_LIBRARY_PATH=str(r/"root/usr/lib/x86_64-linux-gnu"),LC_ALL="C",GIO_USE_VFS="local",GSETTINGS_BACKEND="memory")\np=r/"root/usr/bin/wixl"\nos.execve(p,[str(p),"--wxidir",str(r/"root/usr/share/wixl-0.103/include"),"--extdir",str(r/"root/usr/share/wixl-0.103/ext")]+sys.argv[1:],e)\n');wrapper.chmod(0o700)
  need(run('wrapper-version',[str(wrapper)])==b'0.103\n','actual wrapper version')
  tools={x['name']:{'path':x['path'],'sha256':x['sha256']} for x in report['tools']};tools['wixl']={'path':str(wrapper),'sha256':fact(wrapper)['sha256']}
  for name,binary in [('gcc','i686-w64-mingw32-gcc'),('objdump','i686-w64-mingw32-objdump')]:
   q=Path(shutil.which(binary) or '');need(q.is_absolute(),'existing global cross tool only');tools[name]={'path':str(q),'sha256':fact(q)['sha256']}
  (out/'tools.json').write_text(json.dumps(tools,indent=2)+'\n');(out/'child-environment.json').write_text(json.dumps({k:env[k] for k in ('LD_LIBRARY_PATH','LC_ALL','GIO_USE_VFS','GSETTINGS_BACKEND')},indent=2)+'\n')
  report['status']='PASS_LOCAL_PRIVATE_TOOLS_ONLY_WINDOWS_NOT_RUN'
 finally:(out/'tools-report.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'status':report['status'],'output':str(out),'tools':fact(out/'tools.json')}))
if __name__=='__main__':main()
