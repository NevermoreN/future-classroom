# One-shot local text derivation helper; no remote actions or historical execution.
from pathlib import Path
r=Path(__file__).resolve().parent
s=(r/'reference/run-controlled-owner-third.py').read_text()
s=s.replace("E=Path('/tmp/fc-round79-msi-maintenance')","E=Path('/tmp/fc-round80-controlled-repair')")
s=s.replace("PROTOTYPE=E/'controlled-owner-append-preparation-first'","PROTOTYPE=E/'inner-guard-probe-first'")
s=s.replace("BASE=E/'early-terminal-transport-preparation-fifth/compile-only.py'","BASE=PROTOTYPE/'reference/compile-only.py'")
s=s.replace("'EarlyTerminal.dll'","'Guard.dll'").replace("'Invoke-ControlledOwner.ps1'","'Invoke-Probe.ps1'")
a=s.index('def validate_phase(');b=s.index('\ndef parent_preserved',a)
s=s[:a]+'''def validate_phase(r,spec,helper_sha):
 need(r['status']=='PASS_REAL_BEGIN_INSTALL_END_CLOSE_AND_PHYSICAL_EXIT_NOT_PRODUCTION_AUTHORITY' and r['authority']=='NO_PRODUCTION_AUTHORITY' and r['errors']==[],'Original complete phase PASS only')
 need((r['wholeSeconds'],r['nativeSeconds'],r['finallyReserveSeconds'])==(600,120,180) and type(r['elapsedMilliseconds']) is int and r['elapsedMilliseconds']<600000,'Original600/120/180')
 need(r['nativeCloseUnknown'] is False and r['originalOwnerReturned'] is True and r['ownedCommitOutstanding'] is False and r['before']['knownAbsent'] is True and r['afterFinally']['knownAbsent'] is True,'Returned caps and absence')
 cases=r['cases'];need([x['name'] for x in cases]==['healthy-rollback','early-fail-rollback'],'Exact2 original cases')
 caps=r['originalCaps'];need(len(caps)==4 and all(x['CheckedClose'] is True and x['CloseAttempted'] is True and x['ExitKnown'] is True and x['Wait']==0 for x in caps),'4 original caps checked return')
 need(r['nativeCloseFacts'] and all(x['Attempted'] is True and x['Success'] is True and x['Unknown'] is False and x['LastError']==0 for x in r['nativeCloseFacts']),'Actual native closes')
 for index,case in enumerate(cases):
  process=case['originalProcess'];thread=case['originalThread'];need(returned(process) and process['ExitCode']==case['actualExit']==0 and process['Sha256']==helper_sha and process['Sid']==spec['expectedUserSid'],'Original G actual return')
  need(thread['Kind']=='thread' and thread['Status']=='HELD_ORIGINAL_IDENTITY' and thread['Pid']==process['Pid'] and thread['Tid']>0 and thread['Creation']>0 and thread['Wait']==0 and thread['ExitKnown'] is True and thread['CheckedClose'] is True and thread['CloseAttempted'] is True and thread['ExitCode']==0,'Original G thread physical return')
  need(case['nativeReturnsComplete'] is True and case['apiSuccessful'] is True and 0<=case['elapsedMilliseconds']<120000 and case['before']['knownAbsent'] is True and case['after']['knownAbsent'] is True,'Original120s and both rollback absences')
  rows=case['api'];need([x['sequence'] for x in rows]==list(range(1,len(rows)+1)) and all(x['pid']==process['Pid'] and x['tid']==x['originalTid']==thread['Tid'] and x['threadCreation']==thread['Creation'] and x['clockValid'] is True for x in rows),'Same original API thread')
  def one(stage):
   found=[x for x in rows if x['stage']==stage];need(len(found)==1,'Actual one '+stage);return found[0]
  begin=one('BEGIN_RETURN');install=one('INSTALL_RETURN');end=one('END_RETURN');close=one('TRANSACTION_ID_NO_INSTALL_HANDLE_CLOSE');event=one('CHANGE_EVENT_CLOSE_RETURN')
  need(begin['attempted'] is True and begin['return']==0 and begin['object']>0 and install['attempted'] is True and install['return']==(0 if index==0 else 1603) and end['attempted'] is True and end['return']==0 and close['attempted'] is False and close['return']==4294967295 and event['attempted'] is True and event['return']==0,'Actual Begin Install End event; no extra transaction-ID Close')
  need(begin['sequence']<install['sequence']<end['sequence']<close['sequence']<event['sequence'] and begin['object']==install['object']==end['object']==close['object'],'Actual original transaction order')
  one('END_ROLLBACK_ENTER')
  ui=one('SET_UI_PREVIOUS_LEVEL');logging=one('LOG_ENABLE_RETURN');handler=one('EXTERNAL_UI_RECORD_SET_RETURN');previous=one('PREVIOUS_EXTERNAL_CALLBACK_NULL')
  need(ui['attempted'] is True and logging['attempted'] is True and logging['return']==0 and handler['attempted'] is True and handler['return']==0 and previous['return']==0 and ui['sequence']<logging['sequence']<handler['sequence']<begin['sequence'],'Quiet log and actual record registration before Begin')
  change=one('BEGIN_CHANGE_EVENT');need(change['object']>0 and change['object']==event['object'],'Original acquired event checkedclose')
  need(one('EXTERNAL_UI_RECORD_DISABLE_RETURN')['return']==0 and one('CALLBACK_FILE_CLOSE_RETURN')['return']==0 and one('ALL_API_CALLS_RETURNED')['return']==0,'Actual callback unregister and journal closure')
 return {'status':'PASS_ORIGINAL_CONTROLLED_OWNER_API_AND_PHYSICAL_RETURNS','authority':'NO_PRODUCTION_AUTHORITY','caseCount':2}
def qualify_probe(download,phase,spec):
 proofs=[]
 for index,case in enumerate(phase['cases']):
  name=case['name'];guard=json.loads((download/(name+'.guard.json')).read_bytes())
  need(guard['nonce']==spec['nonce'] and guard['mode']==('OK' if index==0 else 'FAIL') and guard['hInstall']>0 and guard['pid']>0 and guard['tid']>0 and guard['productRc']==0 and guard['productValid'] is True,'Actual Type1 hInstall and product')
  need(guard['createdRecord']>0 and guard['formatRc']==0 and guard['fieldRc']==0 and guard['messageAttempted'] is True and type(guard['messageReturn']) is int and guard['messageReturn']>=0 and guard['recordCloseAttempted'] is True and guard['recordCloseReturn']==0 and guard['intendedReturn']==(0 if index==0 else 1603) and guard['authority']=='NONE','Actual self-created record message and checkedclose')
  raw=(download/(name+'.callbacks.jsonl')).read_bytes();need(raw.endswith(b'\\n') and len(raw)<=8388608,'Complete bounded callback journal')
  callbacks=[json.loads(x) for x in raw.splitlines()];need(callbacks and len(callbacks)<=20000 and [x['sequence'] for x in callbacks]==list(range(1,len(callbacks)+1)),'Actual ordered callbacks')
  for row in callbacks:
   need(row['pid']==case['originalProcess']['Pid'] and row['originalTid']==case['originalThread']['Tid'] and row['tid']>0 and row['record']>0 and row['borrowedRecordClosed'] is False and row['clockValid'] is True and row['callbackReturn']==1,'Borrowed callback belongs to actual G; no assumed callback thread')
   need(0<=row['fieldCount']<=65535 and len(row['fields'])==min(row['fieldCount'],8)+1,'Bounded copied record fields')
  def field(row,i):
   hits=[x for x in row['fields'] if x['index']==i];need(len(hits)==1,'One record field');f=hits[0];v=f['utf16Hex'];need(re.fullmatch('(?:[0-9a-f]{4})*',v) is not None,'UTF16 units')
   return ''.join(chr(int(v[j:j+4],16)) for j in range(0,len(v),4)),f
  info=[];successors=[]
  prefix='FC80|nonce='+spec['nonce']+'|mode='+('OK' if index==0 else 'FAIL')+'|stage=INFO|'
  for row in callbacks:
   if row['fieldCount']<1:continue
   text,f=field(row,1)
   if (row['messageType']&0xff000000)==0x04000000 and text.startswith('FC80|'):
    need(text.startswith(prefix) and f['return']==0 and f['requiredChars']==len(text),'Exact complete nonce INFO')
    need('|caPid='+str(guard['pid'])+'|caTid='+str(guard['tid'])+'|hInstall='+str(guard['hInstall'])+'|valid=1' in text,'Actual CA diagnostic identity copied in original G')
    info.append(row)
   if (row['messageType']&0xff000000)==0x08000000 and text=='InstallInitialize':
    need(f['return']==0 and f['requiredChars']==len(text),'Complete typed action field');successors.append(row)
  need(len(info)==1,'Exactly one real nonce INFO forwarded in quiet mode')
  need((len(successors)==1 and successors[0]['sequence']>info[0]['sequence']) if index==0 else len(successors)==0,'Successor follows returned guard0; guard1603 has no successor')
  log=decode_log((download/(name+'-msi.log')).read_bytes());need(re.search(r'Action ended .*ProbeGuard\\. Return value '+('1' if index==0 else '3')+r'\\.',log) is not None,'Actual engine guard action return')
  proofs.append({'case':name,'guard':guard,'infoSequence':info[0]['sequence'],'callbackThreadIds':sorted({x['tid'] for x in callbacks}),'successorSequences':[x['sequence'] for x in successors],'callbackCount':len(callbacks),'scope':'API_FACTS_ONLY_NOT_PERMISSION_OR_PRODUCTION_AUTHORITY'})
 return proofs
''' +s[b:]
# Replace old history-specific input admission with closure of this new source set.
a=s.index(" need((E/'.owner')");b=s.index(" out=owned(a.output_dir)",a)
s=s[:a]+''' need((E/'.owner').read_bytes()==b'future-classroom-owned-r80-controlled-repair/v1\\n','OwnedR80root')
 need(fact(BASE)['sha256']==BASE_SHA,'Exact archived base transport')
 base=runpy.run_path(str(BASE));transport_identity=fact(Path(__file__).resolve());freeze_path=owned(a.prototype_freeze)
 need(freeze_path.parent==PROTOTYPE and fact(freeze_path)['sha256']==a.prototype_freeze_sha256,'Explicit probe source freeze')
 freeze=json.loads(freeze_path.read_text());need(freeze['status']=='PREPARED_API_PROBE_ONLY_WINDOWS_NOT_RUN','Source-only freeze')
 def sources():
  need(fact(Path(__file__).resolve())==transport_identity and fact(BASE)['sha256']==BASE_SHA,'Transport unchanged')
  for row in freeze['files']:
   rel=row['path'];need(rel and not rel.startswith('/') and ':' not in rel and '\\\\' not in rel and all(x not in ('','.','..') for x in rel.split('/')),'Safe frozen relative path')
   need(fact(PROTOTYPE/rel)=={k:row[k] for k in ('bytes','sha256')},'Actual source freeze byte')
 sources();stage=owned(a.stage_dir);need(stage.parent.parent==E and stage.name=='stage' and stage.is_dir() and not stage.is_symlink(),'Fresh produced stage under R')
 need({x.name for x in stage.iterdir()}==NAMES|{'runtime-inputs.json'} and all(x.is_file() and not x.is_symlink() for x in stage.iterdir()),'Exact flat stage')
 manifest_path=stage/'runtime-inputs.json';need(fact(manifest_path)['sha256']==a.manifest_sha256,'Explicit manifest');manifest=json.loads(manifest_path.read_bytes())
 need(manifest['status']=='PREPARED_RUNTIME_NOT_RUN' and len(manifest['files'])==10 and {x['path'] for x in manifest['files']}==NAMES,'Stage input closure')
 for row in manifest['files']:need(fact(stage/row['path'])=={k:row[k] for k in ('bytes','sha256')},'Actual stage byte')
 spec=json.loads((stage/'spec.json').read_bytes());need(fact(stage/'spec.json')['sha256']==manifest['specSha256'],'Actual spec')
 need(spec['expectedUserSid']==base['SID'] and spec['sourceGit']=='b7e4c938ab8ff391e2ad6c1d681e074881118c0a' and re.fullmatch('[0-9a-f]{32}',spec['nonce']) and spec['rootName']=='FutureClassroom-r80-ui-record-probe-'+spec['nonce'] and spec['windowsRoot']==str(PureWindowsPath('C:/Users/Elior/AppData/Local/Temp')/spec['rootName']),'Fresh private source and namespace')
 need(spec['effectDir']==str(PureWindowsPath(spec['windowsRoot'])/'effect')+'\\\\' and spec['registryKey']=='Software\\\\FutureClassroomTest\\\\Round80-Probe-'+spec['nonce'] and spec['marker']=='future-classroom-owned-r80-ui-record-probe/v1\\n','Closed private effects')
 need((spec['wholeSeconds'],spec['nativeSeconds'],spec['clientSeconds'],spec['finallyReserveSeconds'],spec['maximumHandles'],spec['maximumOwners'])==(600,120,120,180,64,8),'Budgets unchanged')
 ids=[spec[k] for k in ('productCode','upgradeCode','componentId')];need(len(set(ids))==3 and all(re.fullmatch(r'\\{[0-9A-F]{8}(?:-[0-9A-F]{4}){3}-[0-9A-F]{12}\\}',x) for x in ids),'Fresh distinct GUIDs')
 for name,row in spec['sources'].items():need(fact(SOURCE_DIR/name)==row,'Actual producer source byte')
 for name in ('Capture.cs','Invoke-Probe.ps1'):need(fact(stage/name)==spec['sources'][name],'Runtime source byte')
 build=json.loads((stage/'build-report.json').read_bytes());need(fact(stage/'build-report.json')['sha256']==manifest['buildReportSha256'] and build['status']=='PASS_STATIC_ONLY_WINDOWS_NOT_RUN' and build['windows']=='NOT_RUN' and build['spec']==fact(stage/'spec.json') and build['sourcesUnchanged'] is True and build['toolsUnchanged'] is True,'Actual local build provenance')
 need(build['commands'] and all(type(x['actualExit']) is int and x['actualExit']==0 and x['parentReaped'] is True for x in build['commands']),'Actual all producer tools exit0')
 for name,key in [('Owner.exe','owner'),('Guard.dll','observer'),('payload.txt','payload')]:need(fact(stage/name)==build[key],'Produced PE/payload byte')
 for name,target in [('healthy','Fc80GuardOk'),('early-fail','Fc80GuardFail')]:
  case=build['cases'][name];need(fact(stage/(name+'.msi'))==case['msi'] and 'MsiEmbeddedChainer' not in case['tables'],'Actual private MSI')
  need(case['tables']['CustomAction']==[{'Action':'ProbeGuard','Type':'1','Source':'ObserverDll','Target':target}],'One synchronous immediate Type1')
  seq=case['tables']['InstallExecuteSequence'];need([x for x in seq if x['Action']=='ProbeGuard']==[{'Action':'ProbeGuard','Condition':'NOT Installed','Sequence':'1499'}] and any(x['Action']=='InstallInitialize' and x['Sequence']=='1500' for x in seq),'Exact guard and successor sequence')
 need(build['cases']['healthy']['packageCode']!=build['cases']['early-fail']['packageCode'],'Distinct package codes')
 # Reuse only archived constants, adapted to fresh explicit nonce. No old main runs.
 for name in ('COMMON','CREATE','DELETE'):
  base[name]=base[name].replace('FutureClassroom-r79-early-terminal-','FutureClassroom-r80-ui-record-probe-').replace('future-classroom-owned-r79-early-terminal-fixture/v1','future-classroom-owned-r80-ui-record-probe/v1')
''' + s[b:]
s=s.replace("'controlled-owner-result.json'","'probe-result.json'").replace("'Invoke-ControlledOwner.ps1'","'Invoke-Probe.ps1'")
s=s.replace("need(len(logs)==4,'Four exact owner MSI logs')","need(len(logs)==2,'Two exact original G MSI logs')")
a=s.index("   for case in phase['cases']:",s.index("logs={p.name:"));b=s.index("   if (download/'finally-uninstall.log')",a)
s=s[:a]+"   report['apiProbeFacts']=qualify_probe(download,phase,spec)\n"+s[b:]
s=s.replace("'PASS_FINITE_CONTROLLED_BEGIN_INSTALL_END_CAPTURE_CLEANUP_NOT_PRODUCTION_AUTHORITY'","'PASS_FINITE_QUIET_TYPE1_INFO_AND_SUCCESSOR_API_PROBE_NOT_PRODUCTION_AUTHORITY'")
s=s.replace("print(json.dumps({'status':'PASS_ORIGINAL_CONTROLLED_OWNER_LOCAL_INPUT_ADMISSION_ONLY'","print(json.dumps({'status':'PASS_API_PROBE_LOCAL_INPUT_ADMISSION_ONLY'")
# Need read-only zero own G/compiler before exact deletion, never a shared-host kill.
s=s.replace("   code,raw=ps('11-exact-downloaded-root-delete',", "   code,raw=ps('10b-zero-own-processes',ZERO_PS);need(code==0,'Actual zero own helper/compiler parent0');report['zeroOwnProcesses']=json.loads(raw);need(report['zeroOwnProcesses']['ownCount']==0,'No live owned process')\n   code,raw=ps('11-exact-downloaded-root-delete',")
pos=s.index('\ndef need(ok,s):')
s=s[:pos]+'''\nZERO_PS=r\x27\x27\x27
Root-Check;$own=@();$foreign=0
foreach($row in @(Get-CimInstance Win32_Process -Filter "Name='Owner.exe' OR Name='csc.exe'")){
 Need ($null-ne $row.ExecutablePath -and $null-ne $row.CommandLine) 'PROCESS_METADATA_UNKNOWN_RETAIN'
 if($row.ExecutablePath.StartsWith($c.root+'\\',[StringComparison]::OrdinalIgnoreCase) -or $row.CommandLine.IndexOf($c.root,[StringComparison]::OrdinalIgnoreCase)-ge 0){$own+=@{pid=$row.ProcessId;image=$row.ExecutablePath}}else{$foreign++}
}
Need ($own.Count-eq 0) 'OWN_PROCESS_LIVE_RETAIN'
@{status='ACTUAL_ZERO_OWN_PROCESSES';ownCount=$own.Count;foreignIgnored=$foreign;sharedKilled=$false}|ConvertTo-Json -Compress
\x27\x27\x27
''' +s[pos:]
(r/'run-probe.py').write_text(s)
