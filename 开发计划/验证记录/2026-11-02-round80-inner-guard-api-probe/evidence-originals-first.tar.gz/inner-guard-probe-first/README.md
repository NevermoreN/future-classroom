本目录只准备 Win11 原生 API 事实探针，尚未运行。只由 root 执行 Windows/编译/打包；无生产权限或 B/G pipe 结论。

1. root 先完成 prepare-tools.py（已冻结）及若有必要的最小恢复，取得 canonical 6tools.json 与 child-environment.json。
2. 按 execution-plan-first.json producerArgv 执行 build-probe.py，保存实际 producer 退出和 build-report。源码 producer-freeze-first 已冻结，禁止原地改写。
3. 对新源码 Invoke-Probe.ps1 及 run-probe.py 构造的六组 PS 原生 AST 做 memory-only 解析。run-probe.py 默认不联系 Windows；--validate-inputs-only 只核本地实际 source/build/MSI 闭包。
4. 取 freeze-first.json 与实际 stage/runtime-inputs.json 的 SHA，代入执行计划 commonArgv；先 --validate-inputs-only，返回0后 root 执行同参数 --execute。
5. 两场景依次 healthy-rollback、early-fail-rollback。每个 G 原 process/thread cap 在 ACK 前取得，Begin/Install/End 全在原线程；callback 实际 tid 单独记录。Guard hInstall 是真实 Type1 参数，仅其自建 record 被 checked-close；回调 record 从不关闭。
6. 资格要求原 G 回调精确 nonce INFO、normal 后继 InstallInitialize ACTIONSTART、negative actual1603/no successor、实际 End0/eventclose0/原 cap 全已归还。完整原件下载与独立只读清理检查后仅删自有 nonce scratch。失败或 UNKNOWN 保留，不改成 PASS。

API 链接：
- https://learn.microsoft.com/en-us/windows/win32/api/msi/nf-msi-msisetexternaluirecord
- https://learn.microsoft.com/en-us/windows/win32/api/msi/nc-msi-installui_handler_record
- https://learn.microsoft.com/en-us/windows/win32/api/msiquery/nf-msiquery-msiprocessmessage
- https://learn.microsoft.com/en-us/windows/win32/msi/custom-action-type-1

原 R79 archive 仅定向复制 reference-provenance.json 中11件源，未解包其余归档；Capture.cs 字节不变。reference 历史脚本不直接作为操作入口；derive-transport.py 是初始文本派生原件，最终 run-probe.py 已另做有限 delta，勿重跑派生工具。
