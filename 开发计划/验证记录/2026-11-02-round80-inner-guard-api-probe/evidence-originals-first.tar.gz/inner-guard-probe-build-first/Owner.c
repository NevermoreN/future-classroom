#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0601
#include <windows.h>
#include <msi.h>
#include <msiquery.h>
#include <shellapi.h>
#include <stdio.h>
#include <wchar.h>
#include <string.h>
#include "owner_config.h"

/* Test-only original API owner. No Pending, gate, Join, production receipt,
 * callback-derived authority, cancellation kill, retry-close or shared-host wait. */
static HANDLE journal = INVALID_HANDLE_VALUE;
static DWORD original_thread;
static BOOL journal_ok = TRUE;
static ULONGLONG started;
static const WCHAR *scenario;
static unsigned number;
static ULONGLONG thread_creation;
static BOOL emit(const char *stage, UINT rc, BOOL attempted, ULONGLONG object) {
    LARGE_INTEGER q, f; char text[1024]; DWORD written=0;
    BOOL clock_ok=QueryPerformanceCounter(&q)&&QueryPerformanceFrequency(&f);
    int n=snprintf(text,sizeof(text),"{\"sequence\":%u,\"stage\":\"%s\",\"attempted\":%s,\"return\":%u,\"object\":%llu,\"pid\":%lu,\"tid\":%lu,\"originalTid\":%lu,\"threadCreation\":%llu,\"qpc\":%lld,\"frequency\":%lld,\"clockValid\":%s}\n",++number,stage,attempted?"true":"false",rc,object,GetCurrentProcessId(),GetCurrentThreadId(),original_thread,thread_creation,clock_ok?q.QuadPart:0,clock_ok?f.QuadPart:0,clock_ok?"true":"false");
    if(!clock_ok||GetCurrentThreadId()!=original_thread||n<=0||(size_t)n>=sizeof(text)||!WriteFile(journal,text,(DWORD)n,&written,NULL)||written!=(DWORD)n||!FlushFileBuffers(journal))journal_ok=FALSE;
    return journal_ok;
}
/* Borrow hRecord only for this callback. Preserve actual thread rather than
 * assuming callback dispatch equals the original Begin/Install/End thread. */
static HANDLE callback_file=INVALID_HANDLE_VALUE;
static CRITICAL_SECTION callback_lock;
static BOOL callback_ok=TRUE;
static unsigned callback_number;
static int WINAPI external_record(LPVOID context,UINT kind,MSIHANDLE record) {
    (void)context;
    EnterCriticalSection(&callback_lock);
    LARGE_INTEGER q,f;BOOL clocks=QueryPerformanceCounter(&q)&&QueryPerformanceFrequency(&f);
    UINT count=MsiRecordGetFieldCount(record),limit=count>8?8:count;
    char text[20000];int used=snprintf(text,sizeof(text),"{\"sequence\":%u,\"pid\":%lu,\"tid\":%lu,\"originalTid\":%lu,\"messageType\":%u,\"record\":%u,\"fieldCount\":%u,\"qpc\":%lld,\"frequency\":%lld,\"clockValid\":%s,\"borrowedRecordClosed\":false,\"fields\":[",++callback_number,GetCurrentProcessId(),GetCurrentThreadId(),original_thread,kind,record,count,clocks?q.QuadPart:0,clocks?f.QuadPart:0,clocks?"true":"false");
    BOOL good=clocks&&used>0&&(size_t)used<sizeof(text);
    for(UINT i=0;good&&i<=limit;i++) {
        WCHAR b[257]={0};DWORD length=257;UINT rc=MsiRecordGetStringW(record,i,b,&length);
        int n=snprintf(text+used,sizeof(text)-(size_t)used,"%s{\"index\":%u,\"return\":%u,\"requiredChars\":%lu,\"utf16Hex\":\"",i?",":"",i,rc,length);
        if(n<=0||(size_t)n>=sizeof(text)-(size_t)used){good=FALSE;break;}used+=n;
        /* Truncation remains explicit for unrelated installer INFO. Target INFO
         * and InstallInitialize must be complete in the Python qualification. */
        size_t copied=0;while(copied<256&&b[copied]) {
            n=snprintf(text+used,sizeof(text)-(size_t)used,"%04x",(unsigned)b[copied++]);
            if(n!=4||(size_t)n>=sizeof(text)-(size_t)used){good=FALSE;break;}used+=n;
        }
        if(!good)break;
        n=snprintf(text+used,sizeof(text)-(size_t)used,"\"}");if(n!=2||(size_t)n>=sizeof(text)-(size_t)used){good=FALSE;break;}used+=n;
    }
    if(good){int n=snprintf(text+used,sizeof(text)-(size_t)used,"],\"callbackReturn\":1}\n");if(n<=0||(size_t)n>=sizeof(text)-(size_t)used)good=FALSE;else used+=n;}
    DWORD written=0;
    if(!good||!WriteFile(callback_file,text,(DWORD)used,&written,NULL)||written!=(DWORD)used||!FlushFileBuffers(callback_file))callback_ok=FALSE;
    LeaveCriticalSection(&callback_lock);
    return IDOK; /* Message handled only; never a permission token. */
}
static BOOL path(WCHAR *out,const WCHAR *suffix) {
    int n=swprintf(out,1024,L"%ls\\%ls%ls",FC_OWNER_ROOT,scenario,suffix);
    return n>0&&n<1024;
}
static BOOL ack(void) {
    WCHAR p[1024]; if(!path(p,L".capture-ack"))return FALSE;
    while(GetTickCount64()-started<2000) {
        HANDLE h=CreateFileW(p,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_FLAG_OPEN_REPARSE_POINT,NULL);
        if(h!=INVALID_HANDLE_VALUE) {
            BY_HANDLE_FILE_INFORMATION info;char b[64];DWORD n=0;
            BOOL valid=GetFileInformationByHandle(h,&info)&&!(info.dwFileAttributes&(FILE_ATTRIBUTE_DIRECTORY|FILE_ATTRIBUTE_REPARSE_POINT))&&info.nNumberOfLinks==1&&ReadFile(h,b,sizeof(b),&n,NULL)&&n==sizeof(FC_OWNER_NONCE)-1&&memcmp(b,FC_OWNER_NONCE,n)==0;
            BOOL closed=CloseHandle(h);DWORD err=closed?0:GetLastError();emit("ACK_HANDLE_CLOSE",err,TRUE,(ULONGLONG)(ULONG_PTR)h);
            return valid&&closed&&journal_ok;
        }
        DWORD e=GetLastError();if(e!=ERROR_FILE_NOT_FOUND&&e!=ERROR_PATH_NOT_FOUND)return FALSE;
        Sleep(5);
    }
    return FALSE;
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE previous,LPWSTR command,int show) {
    (void)instance;(void)previous;(void)command;(void)show;
    int count=0;LPWSTR *args=CommandLineToArgvW(GetCommandLineW(),&count);
    if(args==NULL||count!=2)return 70;
    WCHAR mode[32];if(wcslen(args[1])>=32){LocalFree(args);return 71;}wcscpy(mode,args[1]);
    if(LocalFree(args)!=NULL)return 72;
    if(wcscmp(mode,L"early-fail-rollback")&&wcscmp(mode,L"healthy-rollback"))return 73;
    scenario=mode;original_thread=GetCurrentThreadId();started=GetTickCount64();
    WCHAR p[1024];if(!path(p,L".jsonl"))return 74;
    journal=CreateFileW(p,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,NULL);
    if(journal==INVALID_HANDLE_VALUE)return 75;
    InitializeCriticalSection(&callback_lock);
    if(!path(p,L".callbacks.jsonl")){CloseHandle(journal);return 75;}
    callback_file=CreateFileW(p,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,NULL);
    if(callback_file==INVALID_HANDLE_VALUE){CloseHandle(journal);return 75;}
    FILETIME a,b,c,d,ta,tb,tc,td;BOOL times=GetProcessTimes(GetCurrentProcess(),&a,&b,&c,&d)&&GetThreadTimes(GetCurrentThread(),&ta,&tb,&tc,&td);
    thread_creation=times?(((ULONGLONG)ta.dwHighDateTime<<32)|ta.dwLowDateTime):0;
    ULONGLONG creation=times?(((ULONGLONG)a.dwHighDateTime<<32)|a.dwLowDateTime):0;
    emit("IDENTITY_PROCESS_CREATION",times?0:GetLastError(),TRUE,creation);
    if(!times||!journal_ok||!ack())goto failed_before_begin;
    HMODULE msi=GetModuleHandleW(L"msi.dll");
    typedef UINT (WINAPI *BeginFn)(LPCWSTR,DWORD,MSIHANDLE*,HANDLE*);
    typedef UINT (WINAPI *EndFn)(DWORD);
    BeginFn begin_fn=NULL;EndFn end_fn=NULL;
    FARPROC proc=msi?GetProcAddress(msi,"MsiBeginTransactionW"):NULL;
    if(sizeof(proc)!=sizeof(begin_fn))goto failed_before_begin;
    memcpy(&begin_fn,&proc,sizeof(proc));proc=msi?GetProcAddress(msi,"MsiEndTransaction"):NULL;memcpy(&end_fn,&proc,sizeof(proc));
    if(begin_fn==NULL||end_fn==NULL)goto failed_before_begin;
    WCHAR log[1024];if(!path(log,L"-msi.log"))goto failed_before_begin;
    INSTALLUILEVEL previous_ui=MsiSetInternalUI(INSTALLUILEVEL_NONE,NULL);
    emit("SET_UI_PREVIOUS_LEVEL",previous_ui,TRUE,0);
    UINT logging=MsiEnableLogW(INSTALLLOGMODE_VERBOSE|INSTALLLOGMODE_EXTRADEBUG|INSTALLLOGMODE_INFO|INSTALLLOGMODE_ERROR|INSTALLLOGMODE_WARNING|INSTALLLOGMODE_ACTIONSTART|INSTALLLOGMODE_ACTIONDATA|INSTALLLOGMODE_COMMONDATA,log,INSTALLLOGATTRIBUTES_APPEND|INSTALLLOGATTRIBUTES_FLUSHEACHLINE);
    emit("LOG_ENABLE_RETURN",logging,TRUE,0);
    if(logging!=0||!journal_ok)goto failed_before_begin;
    INSTALLUI_HANDLER_RECORD previous_record=NULL;
    UINT ui_record=MsiSetExternalUIRecord(external_record,INSTALLLOGMODE_INFO|INSTALLLOGMODE_ACTIONSTART,NULL,&previous_record);
    emit("EXTERNAL_UI_RECORD_SET_RETURN",ui_record,TRUE,0);
    emit("PREVIOUS_EXTERNAL_CALLBACK_NULL",previous_record==NULL?0:1,FALSE,0);
    if(ui_record!=0||previous_record!=NULL||!journal_ok)goto failed_before_begin;
    MSIHANDLE transaction=0;HANDLE change=NULL;
    UINT begin=begin_fn(L"FutureClassroom R80 private UI record API probe",0,&transaction,&change);
    emit("BEGIN_RETURN",begin,TRUE,transaction);emit("BEGIN_CHANGE_EVENT",0,FALSE,(ULONGLONG)(ULONG_PTR)change);
    UINT install=0xffffffffu,end=0xffffffffu;BOOL change_close=TRUE;
    BOOL commit=FALSE;
    if(begin==ERROR_SUCCESS) {
        if(transaction==0||change==NULL){emit("BEGIN_OUTPUT_INVALID_NO_INSTALL",ERROR_INVALID_HANDLE,FALSE,transaction);goto rollback;}
        /* Before this point there has been no install API. The caller actually
         * owns Begin; hInstall or an inherited numeric ID is never substituted. */
        if(journal_ok&&GetTickCount64()-started<120000) {
            emit("INSTALL_ENTER",0,FALSE,transaction);
            install=MsiInstallProductW(wcscmp(mode,L"early-fail-rollback")==0?FC_OWNER_EARLY_MSI:FC_OWNER_HEALTHY_MSI,L"REBOOT=ReallySuppress MSIRESTARTMANAGERCONTROL=DisableShutdown");
            emit("INSTALL_RETURN",install,TRUE,transaction);
        }
rollback:;
        /* This is an experiment: End's actual value is recorded, never assumed
         * zero after a 1603 install. No retry and no synthesized Join0. */
        UINT state=commit&&install==ERROR_SUCCESS&&journal_ok?MSITRANSACTIONSTATE_COMMIT:MSITRANSACTIONSTATE_ROLLBACK;
        emit(state==MSITRANSACTIONSTATE_COMMIT?"END_COMMIT_ENTER":"END_ROLLBACK_ENTER",0,FALSE,transaction);
        end=end_fn(state);emit("END_RETURN",end,TRUE,transaction);
    }
    /* Begin's value identifies the external transaction. End is the documented
     * transaction-ending operation. This prototype never treats that ID as an
     * acquired local installation handle needing an additional MsiCloseHandle.
     * The old experiment's actual close6 remains a failure, not a success. */
    emit("TRANSACTION_ID_NO_INSTALL_HANDLE_CLOSE",0xffffffffu,FALSE,transaction);
    if(begin==ERROR_SUCCESS&&change!=NULL) {change_close=CloseHandle(change);DWORD e=change_close?0:GetLastError();emit("CHANGE_EVENT_CLOSE_RETURN",e,TRUE,(ULONGLONG)(ULONG_PTR)change);}
    else emit("CHANGE_EVENT_NOT_ACQUIRED",0,FALSE,0);
    UINT disable=MsiSetExternalUIRecord(NULL,0,NULL,NULL);emit("EXTERNAL_UI_RECORD_DISABLE_RETURN",disable,TRUE,0);
    BOOL callback_close=CloseHandle(callback_file);emit("CALLBACK_FILE_CLOSE_RETURN",callback_close?0:GetLastError(),TRUE,0);
    DeleteCriticalSection(&callback_lock);
    emit("ALL_API_CALLS_RETURNED",callback_ok?0:1,FALSE,0);
    BOOL before_close=journal_ok;BOOL file_close=CloseHandle(journal);
    /* Return 0 means all native return values were captured and owned resources
     * checked returned, not that InstallProduct succeeded or End was zero. */
    return before_close&&file_close&&change_close&&callback_close&&callback_ok&&disable==0&&(begin==0?(transaction!=0&&end==0):(transaction==0&&change==NULL))?0:76;
failed_before_begin:
    emit("NO_BEGIN_NO_INSTALL",0,FALSE,0);
    {BOOL cb=CloseHandle(callback_file);DeleteCriticalSection(&callback_lock);BOOL closed=CloseHandle(journal);return closed&&cb?77:78;}
}
