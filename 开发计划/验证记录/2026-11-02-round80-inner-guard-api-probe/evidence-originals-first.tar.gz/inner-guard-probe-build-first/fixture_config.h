#define FC79_NONCE L"5795480a06de445995bd85b125128988"
#define FC79_PRODUCT L"{CB6A5ADF-5231-48CF-BF5C-F10E78573EA8}"
#define FC79_EFFECT_DIR L"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r80-ui-record-probe-5795480a06de445995bd85b125128988\\effect\\"
