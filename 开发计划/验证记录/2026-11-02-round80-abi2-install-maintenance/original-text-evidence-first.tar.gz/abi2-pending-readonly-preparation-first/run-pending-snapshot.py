#!/usr/bin/env python3
"""Root-only read-only Pending transport; default performs no remote action."""
from pathlib import Path
import argparse,base64,hashlib,json,re,shutil,subprocess,time,uuid

R=Path('/tmp/fc-round80-controlled-repair');P=R/'abi2-pending-readonly-preparation-first'
HOST='future-classroom-win11'
ORIGINAL=R/'abi2-maintenance-product-runtime-first/report.json'
ORIGINAL_SHA='ce2c2c06782f03b160186335ace47ec25d33d201a400270878c580296bba82ef'
OWNER='future-classroom-owned-pending-readonly-capture/v1\n'
BOOT='[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()))'
COMMON=r'''$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Need([bool]$v,[string]$e){if(-not$v){throw $e}}
function Fact([string]$p){$f=Get-Item -LiteralPath $p -Force;Need (-not$f.PSIsContainer -and ($f.Attributes-band1024)-eq0) 'NO_REPARSE_FILE';@{bytes=[long]$f.Length;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function RootPath {Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) ('Temp\FutureClassroom-r80-abi2-pending-capture-'+$c.nonce)}
function CheckRoot {
 Need ($c.nonce-cmatch'^[0-9a-f]{32}$' -and $c.root-ceq(RootPath)) 'ONLY_NEW_CAPTURE_NONCE_ROOT'
 $who=[Security.Principal.WindowsIdentity]::GetCurrent();try{Need ($who.User.Value-ceq$c.sid) 'SAME_AUTHORIZED_USER'}finally{$who.Dispose()}
 $cursor=$c.root;while($cursor){$a=[IO.File]::GetAttributes($cursor);Need (($a-band1024)-eq0 -and ($a-band16)-ne0) 'NONREPARSE_DIRECTORY_CHAIN';$cursor=[IO.Path]::GetDirectoryName($cursor)}
 Need ([IO.File]::ReadAllText((Join-Path $c.root '.owner'))-ceq"future-classroom-owned-pending-readonly-capture/v1`n") 'EXACT_NEW_OWNER'
 $acl=[IO.Directory]::GetAccessControl($c.root);Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq$c.sid) 'PROTECTED_CAPTURE_OWNER'
 $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($rules.Count-eq2 -and @($rules|Where-Object{$_.IdentityReference.Value-cnotin@($c.sid,'S-1-5-18') -or $_.AccessControlType-ne'Allow' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count-eq0) 'ONLY_CAPTURE_USER_SYSTEM_FULLCONTROL'
}
function Inventory {
 CheckRoot;$files=@();$directories=@();$q=[Collections.Generic.Queue[string]]::new();$q.Enqueue($c.root)
 while($q.Count){$directory=$q.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($directory)){$a=[IO.File]::GetAttributes($p);Need (($a-band1024)-eq0) 'NO_CAPTURE_REPARSE';$rel=$p.Substring($c.root.Length+1).Replace('\','/');if(($a-band16)-ne0){$directories+=$rel;$q.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256}};Need ($files.Count-le64 -and $directories.Count-le8) 'CAPTURE_INVENTORY_BOUNDS'}}
 Need (($files|Measure-Object bytes -Sum).Sum-le32MB) 'CAPTURE_TOTAL_BOUND';@{files=$files;directories=$directories}
}
'''
CREATE=r'''Need ($PSVersionTable.PSVersion.Major-eq5 -and [IntPtr]::Size-eq8) 'AUTHORIZED_PS51_X64'
$who=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$who.User;Need ($sid.Value-ceq$c.sid) 'ORIGINAL_USER'}finally{$who.Dispose()}
$root=RootPath;try{[void][IO.File]::GetAttributes($root);throw 'NEW_ROOT_ALREADY_EXISTS'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
$parent=[IO.Path]::GetDirectoryName($root);while($parent){$a=[IO.File]::GetAttributes($parent);Need (($a-band1024)-eq0 -and ($a-band16)-ne0) 'ORIGINAL_NONREPARSE_CAPTURE_ANCESTORS';$parent=[IO.Path]::GetDirectoryName($parent)}
[void][IO.Directory]::CreateDirectory($root);$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false);foreach($s in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($s,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))};[IO.Directory]::SetAccessControl($root,$acl);[IO.File]::WriteAllText((Join-Path $root '.owner'),"future-classroom-owned-pending-readonly-capture/v1`n",[Text.UTF8Encoding]::new($false));$c.root=$root;CheckRoot
@{status='CREATED_ONLY_NEW_CAPTURE_NONCE';root=$root;sid=$c.sid}|ConvertTo-Json -Compress
'''
CAPTURE=r'''CheckRoot
$source=Join-Path $c.root 'PendingSnapshot.cs';Need ((Fact $source).sha256-ceq$c.sourceSha256) 'FROZEN_CSHARP_SOURCE'
$compiler=Join-Path $c.root 'compiler';Need (-not[IO.Directory]::Exists($compiler)) 'NEW_COMPILER_SUBDIRECTORY';[void][IO.Directory]::CreateDirectory($compiler)
$oldTemp=$env:TEMP;$oldTmp=$env:TMP;$assembly=Join-Path $c.root 'PendingSnapshot.dll'
try{$env:TEMP=$compiler;$env:TMP=$compiler;Add-Type -Path $source -OutputAssembly $assembly -ErrorAction Stop;Add-Type -Path $assembly -ErrorAction Stop
 $snapshot=[Fc80Abi2PendingSnapshot]::Capture([string[]]@($c.gateFacts))
 $boot=@{status='NOT_QUERIED';sameBoot='NOT_ASSERTED';oldBootIdentity='NOT_CAPTURED_IN_ORIGINAL_REPORT'}
 try{$os=Get-CimInstance -ClassName Win32_OperatingSystem -Property LastBootUpTime -OperationTimeoutSec 5 -ErrorAction Stop;$b=$os.LastBootUpTime.ToUniversalTime();$boot=@{status='CURRENT_BOOT_WMI_DIAGNOSTIC_ONLY';lastBootUtc=$b.ToString('o');lastBootFiletime=$b.ToFileTimeUtc();sameBoot='NOT_ASSERTED';oldBootIdentity='NOT_CAPTURED_IN_ORIGINAL_REPORT'}}catch{$boot=@{status='CURRENT_BOOT_QUERY_UNKNOWN';errorType=$_.Exception.GetType().FullName;sameBoot='NOT_ASSERTED';oldBootIdentity='NOT_CAPTURED_IN_ORIGINAL_REPORT'}}
 $result=@{status='RETURNED_READONLY_CAPTURE_NOT_RECOVERY';originalReportSha256=$c.originalReportSha256;capture=$snapshot;bootDiagnostic=$boot;source=Fact $source;assembly=Fact $assembly;originalEnd='UNKNOWN_UNCHANGED';restoreOrDeleteAuthorized=$false}
 $raw=$result|ConvertTo-Json -Depth 18 -Compress;[IO.File]::WriteAllText((Join-Path $c.root 'pending-snapshot.json'),$raw,[Text.UTF8Encoding]::new($false));$raw
}finally{$env:TEMP=$oldTemp;$env:TMP=$oldTmp}
'''
INVENTORY=r'''CheckRoot;Inventory|ConvertTo-Json -Depth 12 -Compress'''
DELETE=r'''CheckRoot
# Only compiler commands containing this exact random nonce can be returned.
$own=@(Get-CimInstance -Query ("SELECT ProcessId,Name FROM Win32_Process WHERE Name='csc.exe' AND CommandLine LIKE '%"+$c.nonce+"%'") -OperationTimeoutSec 5 -ErrorAction Stop);Need ($own.Count-eq0) 'NO_OWN_CAPTURE_CSC_PROCESS'
$now=Inventory;Need ($now.files.Count-eq$c.inventory.files.Count -and $now.directories.Count-eq$c.inventory.directories.Count) 'EXACT_CAPTURE_MEMBERS'
foreach($row in $now.files){$old=@($c.inventory.files|Where-Object{$_.path-ceq$row.path});Need ($old.Count-eq1 -and $old[0].bytes-eq$row.bytes -and $old[0].sha256-ceq$row.sha256) 'EXACT_DOWNLOADED_CAPTURE_BYTES'};foreach($dir in $now.directories){Need ($dir-cin$c.inventory.directories) 'EXACT_CAPTURE_DIRECTORY'}
foreach($row in $now.files){if($row.path-cne'.owner'){[IO.File]::Delete((Join-Path $c.root ($row.path.Replace('/','\'))))}};foreach($dir in @($now.directories|Sort-Object Length -Descending)){[IO.Directory]::Delete((Join-Path $c.root ($dir.Replace('/','\'))),$false)};[IO.File]::Delete((Join-Path $c.root '.owner'));[IO.Directory]::Delete($c.root,$false)
try{[void][IO.File]::GetAttributes($c.root);throw 'CAPTURE_NONCE_STILL_PRESENT'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
@{status='EXACT_NEW_CAPTURE_NONCE_REMOVED';knownAbsent=$true;originalProductGatePendingTouched=$false}|ConvertTo-Json -Compress
'''
def need(v,e):
 if not v:raise ValueError(e)
def sha(b):return hashlib.sha256(b).hexdigest()
def rawjson(j):return (json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode()
def fact(path):
 path=Path(path);need(path.is_absolute() and path.resolve()==path and path.is_file() and not path.is_symlink(),'EXACT_LOCAL_REGULAR_FILE')
 b=path.read_bytes();need(len(b)<=4*1024*1024,'FINITE_LOCAL_INPUT');return {'bytes':len(b),'sha256':sha(b)}
def origin():
 need(fact(ORIGINAL)['sha256']==ORIGINAL_SHA,'EXACT_ORIGINAL_FAILURE')
 outer=json.loads(ORIGINAL.read_bytes());j=outer['phase'];need(outer['downloadVerified'] and j['finallyProduct']['knownAbsent'] is True,'PRODUCT_ACTUALLY_ABSENT')
 need(j['ownerUnknown'] is False and j['instrumentUnknown'] is False and len(j['phases'])==1,'ONE_COMPLETED_FAILED_INSTALL')
 phase=j['phases'][0];need(phase['client']['exitCode']==1603 and phase['observerFinal']['Closed'] is True and phase['observerFinal']['Errors']==[],'KNOWN_ORIGINAL_PROCESS_RETURN')
 objects=phase['observerFinal']['Processes'];need(len(objects)==2 and {x['Role']for x in objects}=={'setup-install','owned-guardian'},'EXACT_ORIGINAL_B_G')
 for x in objects:need(x['ActualWait']==0 and x['ActualExitCode']==1603 and x['CloseStatus']=='CHECKED_CLOSE_SUCCESS','ACTUAL_TERMINAL_ORIGINAL_CAPABILITIES')
 root=j['finallyCoordination']['root']['path'].replace('\\\\','\\')
 facts=[root,'S-1-5-21-3896111207-1867804362-1971593122-1001',None,None,None,None]
 return {'originalReport':{'path':str(ORIGINAL),**fact(ORIGINAL)},'gateFacts':facts,'gateFactScope':'ONLY_FIXED_ROOT_AND_CURRENT_SID_KNOWN; FOUR_FILE_ID_ACL_VALUES_CAPTURED_CURRENT_NOT_PRETENDED_ORIGINAL','originalObjects':objects,'originalEnd':'UNKNOWN_UNCHANGED','captureOnlyNoRecoveryAuthority':True}

def remote(c,script):
 text="$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;\n"+COMMON+script
 return ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8',HOST,'powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand '+base64.b64encode(BOOT.encode('utf-16-le')).decode()],text.encode()
def validate_inventory(j):
 need(isinstance(j,dict) and len(j['files'])<=64 and len(j['directories'])<=8 and sum(x['bytes'] for x in j['files'])<=32*1024*1024,'FINITE_NEW_NONCE_INVENTORY')
 seen=set()
 for x in j['files']:
  p=x['path'];need(isinstance(p,str) and p and not p.startswith('/') and ':' not in p and '\\' not in p and all(a not in ('','.','..') for a in p.split('/')) and p not in seen,'EXACT_SAFE_NEW_MEMBER');seen.add(p)
  need(type(x['bytes']) is int and 0<=x['bytes']<=16*1024*1024 and re.fullmatch('[0-9a-f]{64}',x['sha256']),'NEW_MEMBER_FACT')
 for p in j['directories']:need(isinstance(p,str) and p and not p.startswith('/') and ':' not in p and '\\' not in p and all(a not in ('','.','..') for a in p.split('/')) and p not in seen,'SAFE_NEW_DIR');seen.add(p)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');ap.add_argument('--output-dir',type=Path);ap.add_argument('--preparation-freeze-sha256');a=ap.parse_args()
 if not a.execute:print(json.dumps({'status':'PREPARED_NOT_RUN','Windows':'NOT_CONTACTED','oldEnd':'UNKNOWN_UNCHANGED'}));return 0
 need(a.output_dir and a.preparation_freeze_sha256,'EXPLICIT_OUTPUT_AND_FROZEN_SOURCES')
 freeze_path=P/'freeze-first.json';need(fact(freeze_path)['sha256']==a.preparation_freeze_sha256,'EXACT_PREPARATION_FREEZE');freeze=json.loads(freeze_path.read_bytes())
 for row in freeze['files']:need(fact(P/row['path'])=={k:row[k] for k in ('bytes','sha256')},'EXACT_FROZEN_PREPARATION_SOURCE')
 binding=origin();need(json.loads((P/'original-binding-first.json').read_bytes())==binding,'EXACT_FROZEN_ORIGINAL_EVIDENCE')
 d=a.output_dir.absolute();need(d.parent==R and not d.exists(),'NEW_OWNED_RESULT_ONLY');d.mkdir();(d/'.owner').write_text('future-classroom-owned-pending-readonly-result/v1\n');upload=d/'upload';upload.mkdir();shutil.copyfile(P/'PendingSnapshot.cs',upload/'PendingSnapshot.cs')
 nonce=uuid.uuid4().hex;c={'nonce':nonce,'sid':binding['gateFacts'][1],'gateFacts':binding['gateFacts'],'root':None,'sourceSha256':fact(upload/'PendingSnapshot.cs')['sha256'],'originalReportSha256':ORIGINAL_SHA}
 result={'status':'FAIL_OR_UNKNOWN_RETAIN_NEW_CAPTURE_NONCE','operations':[],'originalEvidence':binding,'originalEnd':'UNKNOWN_UNCHANGED','recoveryOrDeletePermission':False,'scope':'READONLY_PENDING_FILE_FACTS_ONLY'};start=time.monotonic();report=d/'report.json'
 def save():report.write_bytes(rawjson(result))
 def call(label,argv,feed=None,maximum=60):
  remaining=180-(time.monotonic()-start);need(remaining>0,'INDEPENDENT_CAPTURE180_EXHAUSTED');budget=min(maximum,remaining);row={'label':label,'argv':argv,'budgetSeconds':budget,'actualExit':None,'originalLocalParentReaped':False,'remoteReturnUnknown':True};result['operations'].append(row)
  if feed is not None:(d/(label+'.stdin.ps1')).write_bytes(feed)
  with (d/(label+'.stdout.log')).open('xb') as out,(d/(label+'.stderr.log')).open('xb') as err:
   child=subprocess.Popen(argv,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=out,stderr=err);row['originalLocalPid']=child.pid
   try:child.communicate(feed,timeout=budget);row.update(actualExit=child.returncode,originalLocalParentReaped=True,remoteReturnUnknown=child.returncode==255)
   except subprocess.TimeoutExpired:save();raise RuntimeError('LOCAL_TRANSPORT_TIMEOUT_REMOTE_UNKNOWN_RETAIN_NO_KILL')
  for name in ('stdout','stderr'):row[name]={'path':label+'.'+name+'.log',**fact(d/(label+'.'+name+'.log'))}
  save();return row,(d/(label+'.stdout.log')).read_bytes()
 try:
  op,b=call('01-create',*remote(c,CREATE),maximum=25);need(op['actualExit']==0,'CREATE0');created=json.loads(b.decode('utf-8-sig'));c['root']=created['root'];result['windowsRoot']=c['root']
  op,_=call('02-upload',['scp','-q','-o','BatchMode=yes',str(upload/'PendingSnapshot.cs'),HOST+':'+c['root'].replace('\\','/')+'/PendingSnapshot.cs'],maximum=25);need(op['actualExit']==0,'UPLOAD0')
  op,b=call('03-capture',*remote(c,CAPTURE),maximum=60);result['captureRemoteExit']=op['actualExit'];need(op['actualExit']==0,'CAPTURE_RETURNED0');snapshot=json.loads(b.decode('utf-8-sig'));result['snapshot']=snapshot
  op,b=call('04-inventory',*remote(c,INVENTORY),maximum=20);need(op['actualExit']==0,'INVENTORY0');inventory=json.loads(b.decode('utf-8-sig'));validate_inventory(inventory);result['inventory']=inventory
  download=d/'download';download.mkdir();op,_=call('05-download',['scp','-q','-r','-o','BatchMode=yes',HOST+':'+c['root'].replace('\\','/'),str(download)],maximum=35);need(op['actualExit']==0,'DOWNLOAD0');tree=download/Path(c['root'].replace('\\','/')).name
  found={x.relative_to(tree).as_posix():fact(x) for x in tree.rglob('*') if x.is_file()};need(found=={x['path']:{k:x[k] for k in ('bytes','sha256')} for x in inventory['files']},'EVERY_NEW_NONCE_DOWNLOADED_EXACT_BYTES');result['downloadVerified']=True
  need(json.loads((tree/'pending-snapshot.json').read_bytes())==snapshot,'RAW_CAPTURE_EQUALS_ORIGINAL_STDOUT')
  # Only the new compiler/output nonce is eligible for exact test cleanup.
  c['inventory']=inventory;op,b=call('06-exact-new-nonce-cleanup',*remote(c,DELETE),maximum=25);need(op['actualExit']==0,'EXACT_NEW_NONCE_CLEANUP0');result['cleanup']=json.loads(b.decode('utf-8-sig'))
  cap=snapshot['capture'];result['status']='PASS_READONLY_PENDING_SNAPSHOT_DOWNLOADED_NEW_NONCE_CLEANED' if cap['Status']=='PASS_READONLY_PINNED_PENDING_SNAPSHOT_ONLY' and cap['CloseUnknown'] is False else 'CAPTURE_FAILED_OR_UNKNOWN_ORIGINALS_RETAINED_NEW_NONCE_CLEANED'
  return 0 if result['status'].startswith('PASS_') else 1
 except BaseException as error:result['error']=type(error).__name__+':'+str(error);raise
 finally:result['elapsedSeconds']=time.monotonic()-start;save()
if __name__=='__main__':raise SystemExit(main())
