$c='{"nonce":"0e2f6f1447174003bbea1a18fa054f02","sid":"S-1-5-21-3896111207-1867804362-1971593122-1001","gateFacts":["C:\\Users\\Elior\\AppData\\Local\\FutureClassroom-Installer-99378807-098D-5F04-8D4D-F181DFA218D5","S-1-5-21-3896111207-1867804362-1971593122-1001",null,null,null,null],"root":null,"sourceSha256":"7b7750234fcfe333e2c76494239a87e70c68cb8bb9752f2e77b5e4b18e5bcc59","originalReportSha256":"ce2c2c06782f03b160186335ace47ec25d33d201a400270878c580296bba82ef"}'|ConvertFrom-Json;
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Need([bool]$v,[string]$e){if(-not$v){throw $e}}
function Fact([string]$p){$f=Get-Item -LiteralPath $p -Force;Need (-not$f.PSIsContainer -and ($f.Attributes-band1024)-eq0) 'NO_REPARSE_FILE';@{bytes=[long]$f.Length;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function RootPath {Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) ('Temp\FutureClassroom-r80-abi2-pending-capture-'+$c.nonce)}
function CheckRoot {
 Need ($c.nonce-cmatch'^[0-9a-f]{32}$' -and $c.root-ceq(RootPath)) 'ONLY_NEW_CAPTURE_NONCE_ROOT'
 $who=[Security.Principal.WindowsIdentity]::GetCurrent();try{Need ($who.User.Value-ceq$c.sid) 'SAME_AUTHORIZED_USER'}finally{$who.Dispose()}
 $cursor=$c.root;while($cursor){$a=[IO.File]::GetAttributes($cursor);Need (($a-band1024)-eq0 -and ($a-band16)-ne0) 'NONREPARSE_DIRECTORY_CHAIN';$cursor=[IO.Path]::GetDirectoryName($cursor)}
 Need ([IO.File]::ReadAllText((Join-Path $c.root '.owner'))-ceq"future-classroom-owned-pending-readonly-capture/v1`n") 'EXACT_NEW_OWNER'
 $acl=[IO.Directory]::GetAccessControl($c.root);Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq$c.sid) 'PROTECTED_CAPTURE_OWNER'
 $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($rules.Count-eq2 -and @($rules|Where-Object{$_.IdentityReference.Value-cnotin@($c.sid,'S-1-5-18') -or $_.AccessControlType-ne'Allow' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count-eq0) 'ONLY_CAPTURE_USER_SYSTEM_FULLCONTROL'
}
function Inventory {
 CheckRoot;$files=@();$directories=@();$q=[Collections.Generic.Queue[string]]::new();$q.Enqueue($c.root)
 while($q.Count){$directory=$q.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($directory)){$a=[IO.File]::GetAttributes($p);Need (($a-band1024)-eq0) 'NO_CAPTURE_REPARSE';$rel=$p.Substring($c.root.Length+1).Replace('\','/');if(($a-band16)-ne0){$directories+=$rel;$q.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256}};Need ($files.Count-le64 -and $directories.Count-le8) 'CAPTURE_INVENTORY_BOUNDS'}}
 Need (($files|Measure-Object bytes -Sum).Sum-le32MB) 'CAPTURE_TOTAL_BOUND';@{files=$files;directories=$directories}
}
Need ($PSVersionTable.PSVersion.Major-eq5 -and [IntPtr]::Size-eq8) 'AUTHORIZED_PS51_X64'
$who=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$who.User;Need ($sid.Value-ceq$c.sid) 'ORIGINAL_USER'}finally{$who.Dispose()}
$root=RootPath;try{[void][IO.File]::GetAttributes($root);throw 'NEW_ROOT_ALREADY_EXISTS'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
$parent=[IO.Path]::GetDirectoryName($root);while($parent){$a=[IO.File]::GetAttributes($parent);Need (($a-band1024)-eq0 -and ($a-band16)-ne0) 'ORIGINAL_NONREPARSE_CAPTURE_ANCESTORS';$parent=[IO.Path]::GetDirectoryName($parent)}
[void][IO.Directory]::CreateDirectory($root);$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false);foreach($s in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($s,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))};[IO.Directory]::SetAccessControl($root,$acl);[IO.File]::WriteAllText((Join-Path $root '.owner'),"future-classroom-owned-pending-readonly-capture/v1`n",[Text.UTF8Encoding]::new($false));$c.root=$root;CheckRoot
@{status='CREATED_ONLY_NEW_CAPTURE_NONCE';root=$root;sid=$c.sid}|ConvertTo-Json -Compress
