"""Derive a new exact normal-build runtime preparation; never execute Windows."""
from pathlib import Path
import json,hashlib,shutil,runpy
R=Path('/tmp/fc-round80-controlled-repair');A=R/'abi2-maintenance-product-runtime-preparation-first';P=R/'abi2-summary-output-product-runtime-preparation-first';E=R/'abi2-summary-output-normal-producer-first/evidence.json';K=R/'abi2-summary-output-product-package-first';W=R/'checkout-abi2-summary-output-production-second'
def fact(p):p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
assert not P.exists();assert fact(E)['sha256']=='ee430d8f06b1485c2f53121da9eff277157f1773e4b5de1ca8d1163f8fadfcd0';pkg=json.loads((K/'report.json').read_bytes());ev=json.loads(E.read_bytes());assert ev['status']=='DEV_FROZEN_NORMAL_BUILD_ONLY'and len(ev['commands'])==3 and all(x['actual_exit']==0 and x['parent_reaped']and not x['timed_out']for x in ev['commands']);assert pkg['status']=='PASS_NORMAL_GNU_ABI2_DEV_STATIC_BUNDLE_NATIVE_NOT_RUN'
P.mkdir();(P/'.owner').write_text('future-classroom-owned-r80-abi2-summary-output-product-runtime-preparation-first/v1\n');shutil.copytree(A/'sources',P/'sources');(P/'inputs').mkdir()
for n in ['run-controlled-product.py','verify-normal-package.py']:
 s=(A/n).read_text().replace('abi2-maintenance-product-runtime-preparation-first','abi2-summary-output-product-runtime-preparation-first').replace('abi2-maintenance-dev-product-package-first','abi2-summary-output-product-package-first').replace('abi2-maintenance-dev-normal-producer-first','abi2-summary-output-normal-producer-first');(P/n).write_text(s)
before=E.parent/ev['inputs_before']['path'];after=E.parent/ev['inputs_after']['path'];assert before.read_bytes()==after.read_bytes();src=dict(sourceBase=ev['source_head'],sources=json.loads(before.read_bytes()));save(P/'inputs/source-manifest.json',src)
c=json.loads((A/'inputs/artifact-manifest.json').read_bytes());c.update(sourceRoot=str(W),sourceEvidenceSha256=fact(E)['sha256'],normalEvidence=fact(E),packageBuilder=fact(W/'scripts/package-abi2-controlled-dev.py'),packageReport=fact(K/'report.json'),productCode='{'+pkg['productCode']+'}',setup=fact(K/'Setup.exe'),msi=fact(K/'FutureClassroom.msi'),sourceManifest=fact(P/'inputs/source-manifest.json'))
for key in ['packageCode','version','artifactVersion','payloads']:c[key]=pkg[key]
c['scope']='Normal GNU DEV only; d9 base plus exact 588-source overlay and four nonnull Summary output fixes; copied Git pointer is readonly base lookup, no clean-tree or independent branch claim';save(P/'inputs/artifact-manifest.json',c)
ns=runpy.run_path(str(P/'run-controlled-product.py'));bound,af,sf=ns['bind'](str(P/'inputs/artifact-manifest.json'),fact(P/'inputs/artifact-manifest.json')['sha256'],str(P/'inputs/source-manifest.json'),fact(P/'inputs/source-manifest.json')['sha256'])
save(P/'binding-first.json',dict(status='PASS_LOCAL_ACTUAL_NEW_NORMAL3_AND_STATIC_PACKAGE_QUALIFICATION_NATIVE_NOT_RUN',artifact=af,source=sf,sourceCount=len(src['sources']),normalEvidence=fact(E),packageReport=fact(K/'report.json'),oldRuntimeFailure=fact(R/'abi2-maintenance-product-runtime-first/report.json'),fixedSummaryDiagnostic=fact(R/'abi2-ca-diagnostic-runtime-third/report.json')))
chunks=[]
for key in ['CREATE','INVOKE','INVENTORY','DELETE']:
 script=ns['COMMON']+ns[key]
 if key=='CREATE':script=(P/'sources/ReadOnlyPreflightFunction.ps1').read_text()+script
 chunks.append(dict(name=key,text=script))
for n in ['ProductState.ps1','ReadOnlyPreflightFunction.ps1','Invoke-ControlledProduct.ps1']:chunks.append(dict(name=n,text=(P/'sources'/n).read_text()))
save(P/'ps-ast-chunks-first.json',dict(chunks=chunks));save(P/'derivation-first.json',dict(status='PREPARED_NATIVE_NOT_RUN',originalPreparationFreeze=fact(A/'freeze-first.json'),sourceHelpers='All seven original helper files byte-identical; new manifest/evidence inputs only',newNormalEvidence=fact(E),newPackage=fact(K/'report.json'),newSourceRoot=str(W)))
files=[dict(path=p.relative_to(P).as_posix(),bytes=p.stat().st_size,sha256=fact(p)['sha256'])for p in sorted(P.rglob('*'))if p.is_file()];save(P/'freeze-first.json',dict(status='FROZEN_NORMAL_SUMMARY_OUTPUT_FIX_RUNTIME_PREPARATION_NOT_RUN',files=files));print(json.dumps(dict(preparationFreeze=fact(P/'freeze-first.json'),artifact=af,source=sf)))
