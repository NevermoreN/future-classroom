from pathlib import Path
import re,json,uuid,hashlib,copy
P=Path(__file__).resolve().parent;R=P.parent;F=R/'abi2-absent-recovery-fixture-fourth/recovery-fixture.json'
c=json.loads(F.read_bytes());text=(P/'sources/ProductState.cs').read_text()
constants=dict(re.findall(r'const string (Source|Product|Family|Version) = "([^"]+)";',text));assert set(constants)=={'Source','Product','Family','Version'}
assert 'Require(source==Source&&family==Family&&product==Product&&version==Version&&GuidText(product,false),"EXACT_SOURCE_FAMILY_PRODUCT_GUID");' in text
assert 'Require(product==Product&&GuidText(product,false),"EXACT_FIXED_ABI2_PRODUCT");return "{"+Product+"}";' in text
assert text.count('product=NativeProduct(product);')==3 and 'GuidText(product,true)' not in text
assert constants=={'Source':c['sourceGit'],'Product':c['productCode'],'Family':c['family'],'Version':c['version']}
def qualifies(v):return v['sourceGit']==constants['Source'] and v['productCode']==constants['Product'] and v['family']==constants['Family'] and v['version']==constants['Version'] and v['productCode']==str(uuid.UUID(v['productCode'])).upper()
assert qualifies(c);rejected=0
for key in ['sourceGit','productCode','family','version']:
 b=copy.deepcopy(c);b[key]='0'*40 if key=='sourceGit' else '0.0.0' if key=='version' else '00000000-0000-0000-0000-000000000000';assert not qualifies(b);rejected+=1
b=copy.deepcopy(c);b['productCode']='{'+b['productCode']+'}';assert not qualifies(b);rejected+=1
rows=c['payloads'];assert len(rows)==14 and sum(v['size']for v in rows)<=30*1024*1024
assert len(set(v['path'].lower()for v in rows))==14 and len(set(v['component_guid']for v in rows))==14
for row in rows:
 assert row['component_guid']==str(uuid.UUID(row['component_guid'])).upper() and re.fullmatch('[0-9a-f]{64}',row['sha256'])
 assert 0<=row['size']<=30*1024*1024
assert re.fullmatch(r'S-1-5-21-(?:[0-9]+-){3}[0-9]+',c['expectedUserSid'])
assert sum(1 for line in text.splitlines()if 'public static void Validate(' in line)==1
out={'status':'PASS_LOCAL_EXACT_CSHARP_CONFIG_AND_NATIVE_GUID_CALLSITE_STATIC_CHECK_ONLY','csharp':{'bytes':len(text.encode()),'sha256':hashlib.sha256(text.encode()).hexdigest()},'fixtureManifest':{'path':str(F),'sha256':hashlib.sha256(F.read_bytes()).hexdigest()},'constants':constants,'actualManifestPositive':1,'negativeExactIdentityCases':rejected,'originalPayload14Checks':True,'nativeGuidShape':'Internal NativeProduct produces braces after exact bare product check; each LocalPackage/Registration/Components caller converts once.','CSharpCompilation':'NOT_RUN_IN_LOCAL_LINUX_NO_CSHARP_COMPILER','Windows':'NOT_RUN'}
(P/'csharp-binding-first.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
