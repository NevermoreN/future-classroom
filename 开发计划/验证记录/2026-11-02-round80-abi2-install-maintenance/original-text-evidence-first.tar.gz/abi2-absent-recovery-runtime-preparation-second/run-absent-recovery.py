#!/usr/bin/env python3
"""Root-only default-inert fixed owned fixture removal. No automatic cleanup."""
from pathlib import Path
import argparse,base64,hashlib,json,re,runpy,shutil,subprocess,sys,time,uuid
sys.dont_write_bytecode=True
R=Path('/tmp/fc-round80-controlled-repair');P=R/'abi2-absent-recovery-runtime-preparation-second';S=P/'sources'
HOST='future-classroom-win11';OWNER='future-classroom-owned-r80-abi2-absent-recovery-runtime/v1\n'
SUPPORT=runpy.run_path(str(P/'transport-support.py'))
need,sha,rawjson,fact,validate_inventory,phase_returned=[SUPPORT[k] for k in ['need','sha','rawjson','fact','validate_inventory','phase_returned']]
SOURCE_NAMES=['Capture.cs','ProcessObserver.cs','ProductState.cs','ProductState.ps1','PendingSnapshot.cs','Invoke-OwnedRemoval.ps1']
AUX_SOURCE='a4702b56bff66da5f5cbe74551d8751eb33fa520'
SCOPE_BINDING=R/'abi2-absent-recovery-implementation-first/scope-binding.json';SCOPE_SHA='7fb39c84acbba0ce5cb6b30395c708c1a579a67a5215e51c2bf24d0a45d7ecb2'
BEFORE_SNAPSHOT=R/'abi2-pending-readonly-retrieval-first/report.json';BEFORE_SHA='9f8e75360e25e7d69bb537765c549a59a83279f15278fb944659ad6699b24ab9'
OLD_PACKAGE=R/'abi2-maintenance-dev-product-package-first/report.json';OLD_PACKAGE_SHA='7876e08aaf32827ac3d4f413732eee7c8857e93bc7a2b1e87685853e63b9481e'
CURRENT_READONLY=R/'abi2-maintenance-failure-current-readonly-first/report.json';CURRENT_SHA='41bd0256624d00b1a3dac23e2bd8225ee39ee5adfa77420586e410bcad52ebae'
BOOT="[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()));$ok=$?;$code=Get-Variable -Name LASTEXITCODE -ErrorAction SilentlyContinue;if($null-ne$code){exit ([int]$code.Value)};if($ok){exit 0};exit 1"
COMMON=r'''$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Need([bool]$v,[string]$code){if(-not$v){throw $code}}
function Fact([string]$p){$f=Get-Item -LiteralPath $p -Force;Need (-not$f.PSIsContainer -and ($f.Attributes-band1024)-eq0) 'REGULAR_NO_REPARSE';return @{bytes=[long]$f.Length;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function RootPath {return Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) ('Temp\FutureClassroom-r80-abi2-absent-recovery-'+$c.nonce)}
function CheckRoot([string]$root){Need ($root-ceq$c.root -and $root-ceq(RootPath)) 'EXACT_NONCE_ROOT';$a=[IO.File]::GetAttributes($root);Need (($a-band1024)-eq0 -and ($a-band16)-ne0) 'REGULAR_ROOT';Need ([IO.File]::ReadAllText((Join-Path $root '.owner'))-ceq"future-classroom-owned-r80-abi2-absent-recovery-runtime/v1`n") 'OWNER';$acl=[IO.Directory]::GetAccessControl($root);Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq$c.sid) 'PROTECTED_ROOT_OWNER';$rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($rules.Count-eq2 -and @($rules|Where-Object{$_.IdentityReference.Value-cnotin@($c.sid,'S-1-5-18') -or $_.AccessControlType-ne'Allow' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count-eq0) 'ONLY_USER_SYSTEM_DACL'}
function Inventory([string]$root){CheckRoot $root;$files=@();$dirs=@();$q=[Collections.Generic.Queue[string]]::new();$q.Enqueue($root);while($q.Count){$dir=$q.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){$a=[IO.File]::GetAttributes($p);Need (($a-band1024)-eq0) 'NO_INVENTORY_REPARSE';$rel=$p.Substring($root.Length+1).Replace('\','/');if(($a-band16)-ne0){$dirs+=$rel;$q.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256}};Need ($files.Count-le256 -and $dirs.Count-le32) 'INVENTORY_BOUNDS'}};return @{files=$files;directories=$dirs}}
'''
CREATE=r'''$start=[Diagnostics.Stopwatch]::GetTimestamp();$frequency=[Diagnostics.Stopwatch]::Frequency
Need ($PSVersionTable.PSVersion.Major-eq5 -and $PSVersionTable.PSVersion.Minor-eq1 -and [IntPtr]::Size-eq8) 'PS51_X64'
$who=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$who.User;Need ($sid.Value-ceq$c.sid) 'CURRENT_SID'}finally{$who.Dispose()}
$root=RootPath;try{[void][IO.File]::GetAttributes($root);throw 'ROOT_ALREADY_PRESENT'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
$cursor=[IO.Path]::GetDirectoryName($root);while($cursor){$a=[IO.File]::GetAttributes($cursor);Need (($a-band1024)-eq0 -and ($a-band16)-ne0) 'ORIGINAL_NONREPARSE_ANCESTORS';$cursor=[IO.Path]::GetDirectoryName($cursor)}
[void][IO.Directory]::CreateDirectory($root);$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false);foreach($s in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($s,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))};[IO.Directory]::SetAccessControl($root,$acl);[IO.File]::WriteAllText((Join-Path $root '.owner'),"future-classroom-owned-r80-abi2-absent-recovery-runtime/v1`n",[Text.UTF8Encoding]::new($false));$c.root=$root;CheckRoot $root
@{status='CREATED_ONLY_NEW_OWNED_REMOVAL_TRANSPORT_SCRATCH_NO_OLD_STATE_MUTATION';root=$root;sid=$c.sid;nonce=$c.nonce;originalStartQpc=$start;originalFrequency=$frequency}|ConvertTo-Json -Depth 12 -Compress
'''
INVOKE=r'''CheckRoot $c.root
Need ((Fact (Join-Path $c.root 'Invoke-OwnedRemoval.ps1')).sha256-ceq$c.runnerSha256) 'PINNED_RUNNER_BEFORE_SCRIPTBLOCK'
& ([ScriptBlock]::Create([IO.File]::ReadAllText((Join-Path $c.root 'Invoke-OwnedRemoval.ps1'),[Text.Encoding]::UTF8))) -Execute -ScratchRoot $c.root -ExpectedConfigSha256 $c.configSha256 -ExpectedInputsManifestSha256 $c.inputsSha256 -OriginalStartQpc $c.startQpc -OriginalFrequency $c.frequency
$code=Get-Variable -Name LASTEXITCODE -ErrorAction SilentlyContinue;Need ($null-ne$code) 'NESTED_RUNNER_EXIT_CODE_REQUIRED';exit ([int]$code.Value)
'''
INVENTORY=r'''CheckRoot $c.root;Inventory $c.root|ConvertTo-Json -Depth 12 -Compress'''
def fixed_inputs():
 out={}
 for label,p,digest in [('scope',SCOPE_BINDING,SCOPE_SHA),('snapshot',BEFORE_SNAPSHOT,BEFORE_SHA),('package',OLD_PACKAGE,OLD_PACKAGE_SHA),('current',CURRENT_READONLY,CURRENT_SHA)]:
  got=fact(p);need(got['sha256']==digest,'FROZEN_OLD_'+label.upper());out[label]=json.loads(p.read_bytes())
 return out

def validate_config(c,source,sf,fixed):
 need(isinstance(c,dict) and c['status']=='BOUND_GNU_DEV_ABI2_ABSENT_RECOVERY_AUX_COMPILED_SCOPE_NOT_RELEASE' and c['target']=='i686-pc-windows-gnu','CLOSED_ABSENT_FEATURE_DEV_FIXTURE')
 old=fixed['package'];binding=fixed['scope'];snapshot=fixed['snapshot']['originalNativeSnapshot']['capture']
 need(c['sourceGit']==c['auxiliarySourceGit']==AUX_SOURCE and c['family']=='99378807-098D-5F04-8D4D-F181DFA218D5' and c['productCode']==old['productCode'] and c['version']==old['version'] and c['expectedUserSid']==snapshot['ParsedSid'] and c['guardABI']==2,'EXACT_ABI2_OLD_TARGET_NEW_AUX_AUTHORITY')
 need(c['initialState']=='ABSENT' and c['expectedNativeTransactions']==1 and c['installApi']=='NOT_CALLED' and c['guardApi']=='NOT_CALLED' and c['oldEnd']=='UNKNOWN','ONE_EMPTY_TRANSACTION_ONLY')
 need(c['payloads']==old['payloads'] and len(c['payloads'])==14,'COMPLETE_ORDERED_ORIGINAL_ABI2_PAYLOAD14')
 need(c['compiledScope']=={'bytes':binding['scope']['bytes'],'sha256':binding['scope']['sha256'],'envBytes':binding['compiledEnv']['bytes'],'envSha256':binding['compiledEnv']['sha256']},'EXACT_COMPILED_SCOPE_METADATA_ONLY')
 for key,path,digest in [('scopeBinding',SCOPE_BINDING,SCOPE_SHA),('beforeSnapshot',BEFORE_SNAPSHOT,BEFORE_SHA)]:need(c[key]==fact(path) and c[key]['sha256']==digest,'EXACT_'+key.upper())
 need(set(source)=={'sourceBase','sources'} and source['sourceBase']==AUX_SOURCE and len(source['sources'])==483,'EXACT_RUST_SOURCE_SCOPE')
 names=set()
 for row in source['sources']:
  need(set(row)=={'path','bytes','sha256'} and row['path'] not in names and re.fullmatch('[0-9a-f]{64}',row['sha256']) and type(row['bytes'])is int and 0<=row['bytes']<=16777216,'SOURCE_IDENTITY');names.add(row['path']);need(not row['path'].startswith('/') and ':' not in row['path'] and '\\' not in row['path'] and all(v not in ('','.','..')for v in row['path'].split('/')),'CANONICAL_SOURCE_PATH')
 need(c['sourceManifest']=={'bytes':sf['bytes'],'sha256':sf['sha256']},'FULL_FROZEN_SOURCE_MANIFEST')
 for key in ['setup','msi']:need(set(c[key])=={'path','bytes','sha256'} and 0<c[key]['bytes']<=67108864 and re.fullmatch('[0-9a-f]{64}',c[key]['sha256']),'FIXTURE_ARTIFACT_IDENTITY')
 need(c['setup']['sha256']!=old['setup']['sha256'] and c['msi']['sha256']!=old['msi']['sha256'],'EXPLICIT_NEW_AUXILIARY_NOT_OLD_NORMAL')
 pending=snapshot['PendingBefore'];root=snapshot['RootBefore'];gate=snapshot['GateBefore'];oldprocs=binding['oldOriginalProcesses'];scope_ids=[int(pending['Volume'],16),int(pending['FileId'],16),pending['CreationFiletime']]
 c=dict(c);c['beforeEvidence']={'gateFacts':[root['Path'],snapshot['ParsedSid'],root['Identity'],gate['Identity'],root['OwnerDaclSddl'],gate['OwnerDaclSddl']],'pendingIdentity':pending['Identity'],'pendingBytes':snapshot['CompleteBytes'],'pendingSha256':snapshot['Sha256'],'pendingBase64':snapshot['BytesBase64'],'pendingHex':base64.b64decode(snapshot['BytesBase64'],validate=True).hex(),'runtimeReportSha256':binding['sources']['runtime']['sha256'],'packageReportSha256':binding['sources']['package']['sha256'],'oldImageSha256':binding['oldImage']['sha256'],'oldPending':', '.join(str(v)for v in scope_ids),'oldB':str(oldprocs[0]['Pid'])+','+str(oldprocs[0]['CreationFiletime'])+';wait=0;exit=1603;checkedClose=1','oldG':str(oldprocs[1]['Pid'])+','+str(oldprocs[1]['CreationFiletime'])+';wait=0;exit=1603;checkedClose=1'}
 current=fixed['current'];cur=current['native'];need(current['status']=='PASS_READONLY_FACTS_ONLY' and current['actualExit']==0 and current['originalReaped'] is True and cur['mutations'] is False and cur['originalEnd']=='UNKNOWN_UNCHANGED' and cur['ownProcessCount']==0 and cur['sid']==c['expectedUserSid'],'FROZEN_READONLY_CURRENT_NOT_OLD_SETTLEMENT')
 paths=cur['derivedInstallerPaths'];need(len(paths)==2 and all(v['status']=='KNOWN_ABSENT' for v in paths),'FROZEN_EXACT_OLD_INSTALLER_PATHS_ABSENT')
 c['oldExactInstallerPaths']=[v['path'] for v in paths];need(c['oldExactInstallerPaths']==[r'C:\Windows\Installer\363d1665.msi',r'C:\Windows\Installer\MSI178E.tmp'],'FIXED_ORIGINAL_LOG_DERIVED_PATHS_ONLY');c['currentReadonlyEvidence']=fact(CURRENT_READONLY)
 c.update(registryMarkerKey=r'Software\FutureClassroom\Installer\Components',runKey=r'Software\Microsoft\Windows\CurrentVersion\Run',runValue='FutureClassroom',registryView='Registry32',fixedDestinationKnownFolderSuffix=['Programs','FutureClassroom'])
 return c

def bind(ap,ah,sp,sh):
 af=fact(ap);sf=fact(sp);need(af['sha256']==ah and sf['sha256']==sh,'EXPLICIT_FINAL_MANIFEST_SHA')
 c=validate_config(json.loads(Path(ap).read_bytes()),json.loads(Path(sp).read_bytes()),sf,fixed_inputs())
 for key in ['setup','msi']:need(fact(c[key]['path'])==c[key],'EXACT_FINAL_'+key.upper())
 return c,af,sf

def remote(script,c):
 feed=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;\n"+COMMON+script).encode();cmd='powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand '+base64.b64encode(BOOT.encode('utf-16-le')).decode()
 return ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8',HOST,cmd],feed

def admission(j):
 if not isinstance(j,dict):return False
 phases=j.get('phases');audit=j.get('nativeAudit',{});empty=audit.get('empty',{});coord=j.get('finallyCoordination',{})
 return j.get('status')=='PASS_GNU_WIN11_ABI2_ABSENT_RECOVERY_OLD_END_UNKNOWN' and j.get('oldEnd')=='UNKNOWN_UNCHANGED' and j.get('ownerUnknown')is False and j.get('instrumentUnknown')is False and j.get('originalBudgetExceeded')is False and isinstance(phases,list)and len(phases)==1 and phases[0].get('verb')=='owned-test-remove' and phase_returned(phases[0]) and phases[0].get('postPhaseProcesses',{}).get('knownZero')is True and j.get('finallyProduct',{}).get('knownAbsent')is True and coord.get('pendingKnownAbsent')is True and j.get('finallyOwnProcesses',{}).get('knownZero')is True and j.get('afterCache',{}).get('allObservedAbsent')is True and audit.get('oldEnd')=='UNKNOWN_UNCHANGED' and audit.get('stage')=='RemovalAuthorized' and audit.get('oldDisposition')=='UNKNOWN' and type(empty.get('begin'))is int and empty['begin']==0 and type(empty.get('end'))is int and empty['end']==0 and type(empty.get('transaction'))is int and empty['transaction']>0 and empty.get('install')=='NOT_CALLED' and empty.get('guard')=='NOT_CALLED' and empty.get('numericOrigin')=='AUTHENTICATED_ORIGINAL_G_FCO1_VALUES_ZERO_CHECKED_BY_NATIVE_B' and audit.get('oldEndSynthesized')is False and audit.get('directGApiStdoutTelemetry')=='NOT_SERIALIZED' and j.get('oldExactInstallerPathsAbsent')is True and j.get('finallyProduct',{}).get('runAbsent')is True and j.get('finallyProduct',{}).get('status')=='PASS_READONLY_EXPECTED_ABSENT'

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');ap.add_argument('--artifact-manifest');ap.add_argument('--artifact-manifest-sha256');ap.add_argument('--source-manifest');ap.add_argument('--source-manifest-sha256');ap.add_argument('--report');ap.add_argument('--preparation-freeze-sha256');a=ap.parse_args()
 if not a.execute:print(json.dumps({'status':'PREPARED_NOT_EXECUTED','Windows':'NOT_RUN','oldPending':'NOT_TOUCHED','cleanup':'NOT_AUTOMATIC'}));return 0
 need(all([a.artifact_manifest,a.artifact_manifest_sha256,a.source_manifest,a.source_manifest_sha256,a.report,a.preparation_freeze_sha256]),'EXPLICIT_ROOT_FINAL_INPUTS')
 need((R/'.owner').read_bytes()==b'future-classroom-owned-r80-controlled-repair/v1\n' and (P/'.owner').read_bytes()==b'future-classroom-owned-r80-owned-removal-runtime-preparation/v1\n','LOCAL_OWNERS')
 fr=P/'freeze-first.json';need(sha(fr.read_bytes())==a.preparation_freeze_sha256,'ROOT_PINNED_PREPARATION_FREEZE')
 for row in json.loads(fr.read_bytes())['files']:
  got=fact(P/row['path']);need(got['bytes']==row['bytes'] and got['sha256']==row['sha256'],'EXACT_PREPARATION_BYTES')
 plan,af,sf=bind(a.artifact_manifest,a.artifact_manifest_sha256,a.source_manifest,a.source_manifest_sha256)
 report=Path(a.report);D=report.parent;need(report.is_absolute() and D.resolve()==D and D.parent==R and not D.exists() and report.name.endswith('.json'),'NEW_RESULT_ROOT')
 D.mkdir();(D/'.owner').write_bytes(b'future-classroom-owned-r80-abi2-absent-recovery-runtime-result/v1\n');upload=D/'upload';upload.mkdir();nonce=uuid.uuid4().hex
 for name in SOURCE_NAMES:shutil.copyfile(S/name,upload/name)
 shutil.copyfile(plan['setup']['path'],upload/'Setup.exe');shutil.copyfile(plan['msi']['path'],upload/'FutureClassroom.msi');shutil.copyfile(a.artifact_manifest,upload/'artifact-manifest.json');shutil.copyfile(a.source_manifest,upload/'source-manifest.json')
 c=dict(plan);c.update(runtimeNonce=nonce,runtimeRootName='FutureClassroom-r80-abi2-absent-recovery-'+nonce,artifactManifestSha256=af['sha256']);configraw=rawjson(c);(upload/'runtime-config.json').write_bytes(configraw)
 inputs={'files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(upload.iterdir())]};inputraw=rawjson(inputs);(upload/'runtime-inputs.json').write_bytes(inputraw)
 start=time.monotonic();ops=[];outcome={'status':'FAIL_OR_UNKNOWN_RETAIN_ALL_ORIGINALS','scope':'GNU_WIN11_ABI2_ABSENT_RECOVERY_NOT_GENERAL_RECOVERY','sourceManifest':sf,'artifactManifest':af,'nonce':nonce,'operations':ops,'runtime':'NOT_RUN','cleanup':'NO_AUTOMATIC_SCRATCH_GATE_OR_OLD_NONCE_DELETION','oldEnd':'UNKNOWN_UNCHANGED'};rc=1
 def save():report.write_bytes(rawjson(outcome))
 def call(label,argv,feed=None,maximum=180):
  left=600-(time.monotonic()-start);need(left>0,'ROOT_ORIGINAL_WHOLE_600_EXHAUSTED');budget=min(maximum,left);row={'label':label,'argv':argv,'budgetSeconds':budget,'actualExit':None,'originalLocalParentReaped':False,'remoteReturnUnknown':True};ops.append(row)
  if feed is not None:(D/(label+'.stdin.ps1')).write_bytes(feed)
  with (D/(label+'.stdout.log')).open('xb') as out,(D/(label+'.stderr.log')).open('xb') as err:
   proc=subprocess.Popen(argv,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=out,stderr=err);row['originalLocalPid']=proc.pid
   try:proc.communicate(feed,timeout=budget);row.update(actualExit=proc.returncode,originalLocalParentReaped=True,remoteReturnUnknown=False)
   except subprocess.TimeoutExpired:row['status']='ROOT_TRANSPORT_TIMEOUT_REMOTE_OWNER_UNKNOWN_NO_WINDOWS_KILL';save();raise RuntimeError('ORIGINAL_TRANSPORT_TIMEOUT_RETAIN')
  row['elapsedWholeSeconds']=time.monotonic()-start
  for key in ['stdout','stderr']:
   p=D/(label+'.'+key+'.log');row[key]={'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
  save();return row,(D/(label+'.stdout.log')).read_bytes()
 try:
  t={'nonce':nonce,'sid':plan['expectedUserSid'],'root':None};args,feed=remote(CREATE,t);op,b=call('01-create',args,feed,30);need(op['actualExit']==0,'CREATE_ACTUAL0');created=json.loads(b.decode('utf-8-sig'));root=created['root'];t.update(root=root,startQpc=created['originalStartQpc'],frequency=created['originalFrequency'],configSha256=sha(configraw),inputsSha256=sha(inputraw),runnerSha256=sha((upload/'Invoke-OwnedRemoval.ps1').read_bytes()));outcome['create']=created;outcome['windowsRoot']=root
  op,_=call('02-upload',['scp','-q','-o','BatchMode=yes']+[str(p) for p in sorted(upload.iterdir())]+[HOST+':'+root.replace('\\','/')+'/'],maximum=45);need(op['actualExit']==0,'UPLOAD_ACTUAL0')
  args,feed=remote(INVOKE,t);op,b=call('03-single-explicit-removal',args,feed,maximum=420);outcome['runtimeActualExit']=op['actualExit'];outcome['runtime']='ACTUAL_ORIGINAL_PS_RETURNED';phase=json.loads(b.decode('utf-8-sig'));outcome['phase']=phase
  args,feed=remote(INVENTORY,t);op,b=call('04-inventory',args,feed,30);need(op['actualExit']==0,'INVENTORY_ACTUAL0');inventory=json.loads(b.decode('utf-8-sig'));validate_inventory(inventory);outcome['inventory']=inventory
  download=D/'download';download.mkdir();op,_=call('05-download',['scp','-q','-r','-o','BatchMode=yes',HOST+':'+root.replace('\\','/'),str(download)],maximum=60);need(op['actualExit']==0,'DOWNLOAD_ACTUAL0');local=download/Path(root.replace('\\','/')).name;got=[];dirs=[]
  for p in local.rglob('*'):
   need(not p.is_symlink(),'DOWNLOADED_NO_LINK');rel=p.relative_to(local).as_posix()
   if p.is_dir():dirs.append(rel)
   else:got.append({'path':rel,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
  need({x['path']:(x['bytes'],x['sha256']) for x in got}=={x['path']:(x['bytes'],x['sha256']) for x in inventory['files']} and set(dirs)==set(inventory['directories']),'COMPLETE_DOWNLOADED_BYTE_REPLAY');outcome['downloadVerified']=True;need(json.loads((local/'removal-result.json').read_bytes())==phase,'ORIGINAL_RESULT_DOWNLOAD_EXACT')
  if outcome['runtimeActualExit']==0 and admission(phase):outcome['status']='PASS_GNU_WIN11_ABI2_ABSENT_RECOVERY_COMPLETE_DOWNLOAD_OLD_END_UNKNOWN';rc=0
 except Exception as e:outcome['failureType']=type(e).__name__;outcome['failureCode']=str(e) if re.fullmatch('[A-Z0-9_]+',str(e)) else 'LOCAL_TRANSPORT_OR_DECODE_FAILURE_RETAIN'
 finally:outcome['elapsedSeconds']=time.monotonic()-start;outcome['originalWholeBudgetExceeded']=outcome['elapsedSeconds']>=600;save()
 if outcome['originalWholeBudgetExceeded']:rc=1
 print(json.dumps({'status':outcome['status'],'report':str(report),'reportSha256':sha(report.read_bytes()),'cleanup':outcome['cleanup']}));return rc
if __name__=='__main__':raise SystemExit(main())
