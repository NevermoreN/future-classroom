from pathlib import Path
import ast,hashlib,json,shutil,subprocess,runpy,difflib
R=Path('/tmp/fc-round80-controlled-repair');old=R/'abi2-ca-diagnostic-runtime-preparation-second';new=R/'abi2-ca-diagnostic-runtime-preparation-third';assert not new.exists();new.mkdir();(new/'.owner').write_text('future-classroom-owned-abi2-ca-diagnostic-runtime-preparation-third/v1\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for leaf in ['ProductState.ps1','ProductState.cs','Capture.cs']:shutil.copyfile(old/leaf,new/leaf)
s=(old/'run-diagnostic.py').read_text().replace('abi2-ca-diagnostic-package-third','abi2-ca-diagnostic-package-fourth').replace('e28704559d9c95425a34488e9d07a68f28852571957efdb74082d87811c18e92','25b9c45b0e8737776afd2f0cf91aef9e7cee04227d7419f57071be34d357f257').replace("abi2-ca-diagnostic-runtime-second'","abi2-ca-diagnostic-runtime-third'")
insert=''' assert observations[0]['stage']=='run_start'and observations[0]['errorClass']=='OK'
 # Actual fixed ActiveDB Summary result, never a grant or an input assertion.
 def unique(stage):
  items=[v for v in observations if v['stage']==stage];assert len(items)==1,stage;return items[0]
 active=unique('abi2_active_database');opened=unique('abi2_summary_open');summary=unique('abi2_summary_property9')
 assert active['codeHex']=='00000000'and active['detail']>0 and opened['codeHex']=='00000000'and opened['detail']>0
 assert summary['codeHex']=='00000000'and summary['detail']==(30<<32)|38
 formatted=unique('package_format');accept=unique('prepare_accept');message=unique('message');receive=unique('receive');drain=unique('finish_cancel_drain')
 assert all(v['errorClass']=='OK' for v in [formatted,accept,message,drain])and receive['errorClass']!='OK'
 assert opened['sequence']<summary['sequence']<formatted['sequence']<accept['sequence']<message['sequence']<receive['sequence']<drain['sequence']
 assert not any(v['stage']in ['peer_image','template_matches']for v in observations)
 assert all(v['codeHex']=='00000000'for v in observations if v['stage']in ['close_msi','close_view'])
 assert all(v['errorClass']=='OK'for v in observations if v['stage']in ['finish_msi','finish_kernel','finish_module'])
'''
needle=" assert observations[0]['stage']=='run_start'and observations[0]['errorClass']=='OK'\n";assert s.count(needle)==1;s=s.replace(needle,insert)
s=s.replace("return dict(nativeResult=x,observations=observations,authority=", "return dict(nativeResult=x,observations=observations,summaryProperty9=dict(actualReturn=0,actualType=30,actualChars=38),packageFormatSucceeded=True,noGrantStillRejected=True,authority=")
s=s.replace("PASS_EXPECTED_DIRECT_INNER_1603_STAGE_OBSERVATIONS_WIN11_ONLY_NOT_INSTALL_SUCCESS","PASS_FIXED_SUMMARY_PROPERTY9_AND_NO_GRANT_DIRECT_INNER_1603_WIN11_ONLY")
ast.parse(s);(new/'run-diagnostic.py').write_text(s)
chunks=json.loads((old/'ps-ast-chunks-second.json').read_bytes());(new/'ps-ast-chunks-third.json').write_text(json.dumps(chunks,indent=2)+'\n');assert (new/'ps-ast-chunks-third.json').read_bytes()==(old/'ps-ast-chunks-second.json').read_bytes()
# Verify Python boolean precedence for the expected packed type/count value.
assert ((30<<32)|38)==128849018918
p=subprocess.run(['python3',str(new/'run-diagnostic.py')],capture_output=True);assert p.returncode==0 and json.loads(p.stdout)=={'status':'NOT_RUN'}
checks=dict(status='PASS_LOCAL_SUMMARY_OUTPUT_FIX_STATIC_RUNTIME_PREPARATION_NOT_NATIVE',defaultInertActualExit=p.returncode,AST='PASS_PYTHON',all6PSChunksByteEqualPreviousActualPassed=True,previousPreparationFreezeSha256=sha(old/'freeze-first.json'),producerSha256='508e84e22d2e8eaed0398f6c48b72c08c52e1156219fe069e2f05ba2c42a650a',packageSha256='25b9c45b0e8737776afd2f0cf91aef9e7cee04227d7419f57071be34d357f257',productionPatchFreezeSha256='8a23e5cbbec87750c0360677033cf8df2470ae96322dd67d42ed9729f0120aa1',newNativeAssertions=['ActiveDB nonzero','Summary open0','property9 actual0/VT30/chars38','package_format succeeds','prepareaccept/message succeeds','receive denies no grant','MSI1603/noInit','checked original return0','before/afterAbsent'],budgets='UNCHANGED_150_CLIENT_600_REMOTE_900_OUTER',Windows='ROOT_ONLY_NOT_RUN',oldPending='NOT_ACCESSED')
(new/'local-checks-third.json').write_text(json.dumps(checks,indent=2)+'\n')
(new/'execution-plan-third.json').write_text(json.dumps(dict(scope='FIXED_SUMMARY_PROPERTY9_NO_GRANT_STILL_NEGATIVE',PSAST=str(new/'ps-ast-chunks-third.json'),WindowsExecutor='ROOT_ONLY',execute=['python3',str(new/'run-diagnostic.py'),'--execute','--preparation-freeze-sha256','<ACTUAL_FREEZE_SHA>','--output-dir',str(R/'abi2-ca-diagnostic-runtime-third')],normalProduct=False,repairOrRecovery=False,oldPending='NOT_ACCESSED'),indent=2)+'\n')
files=[dict(path=p.relative_to(new).as_posix(),bytes=p.stat().st_size,sha256=sha(p))for p in sorted(new.rglob('*'))if p.is_file()];(new/'freeze-first.json').write_text(json.dumps(dict(files=files),indent=2)+'\n');print(json.dumps(dict(freezeSha256=sha(new/'freeze-first.json'),files=len(files),localChecksSha256=sha(new/'local-checks-third.json'))))
