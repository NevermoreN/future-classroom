from pathlib import Path
import base64,hashlib,json,subprocess,time
R=Path('/tmp/fc-round80-controlled-repair');P=R/'abi2-ca-diagnostic-runtime-preparation-first'
def sha(b):return hashlib.sha256(b).hexdigest()
f=P/'freeze-first.json';assert sha(f.read_bytes())=='6e11c69610a472b4dc35b59b34ebdb5b16817abb0b36658adfea7d1819833690'
d=json.loads(f.read_bytes())
for row in d['files']:
 b=(P/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
chunks=[dict(name=x['name'],text=x['script']) for x in json.loads((P/'ps-ast-chunks-first.json').read_bytes())];assert len(chunks)==5
payload=json.dumps(chunks).replace("'","''")
feed="$ErrorActionPreference='Stop';$chunks='"+payload+"'|ConvertFrom-Json;$rows=@();foreach($p in $chunks){$t=$null;$e=$null;[void][Management.Automation.Language.Parser]::ParseInput([string]$p.text,[ref]$t,[ref]$e);$rows+=@{name=$p.name;errors=@($e|ForEach-Object {$_.Message})}};@{status='ACTUAL_PS51_AST_ONLY';rows=$rows;mutations='NONE'}|ConvertTo-Json -Depth 10 -Compress;if(@($rows|Where-Object {$_.errors.Count}).Count){exit 1}"
boot="[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()))"
argv=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','future-classroom-win11','powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(boot.encode('utf-16-le')).decode()]
q=R/'root-ca-diagnostic-ps-parse-first';assert not q.with_suffix('.json').exists();q.with_suffix('.stdin.ps1').write_text(feed)
t=time.monotonic();p=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);out,err=p.communicate(feed.encode(),timeout=45)
q.with_suffix('.stdout.log').write_bytes(out);q.with_suffix('.stderr.log').write_bytes(err)
native=json.loads(out.decode('utf-8-sig'));assert len(native['rows'])==5
report=dict(status='PASS' if p.returncode==0 else 'FAIL',actualExit=p.returncode,originalReaped=p.poll() is not None,elapsedSeconds=time.monotonic()-t,native=native,preparationFreezeSha256=sha(f.read_bytes()),stdoutSha256=sha(out),stderrSha256=sha(err))
q.with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));raise SystemExit(p.returncode)
