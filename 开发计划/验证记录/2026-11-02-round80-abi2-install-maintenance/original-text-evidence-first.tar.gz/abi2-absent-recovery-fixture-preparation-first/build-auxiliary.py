"""Explicit local auxiliary compiler, inert by default. Never Windows or normal-release admission."""
from pathlib import Path
import json,hashlib,subprocess,os,time,shutil,sys,struct
R=Path('/tmp/fc-round80-controlled-repair');W=R/'checkout-abi2-absent-recovery-first';O=R/'abi2-absent-recovery-auxiliary-producer-first';I=R/'abi2-absent-recovery-implementation-first';T=R/'abi2-absent-recovery-auxiliary-target-first';TARGET='i686-pc-windows-gnu'
def sha(b):return hashlib.sha256(b).hexdigest()
def fact(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def inventory():
 paths=sorted([p for p in(W/'crates').rglob('*')if p.is_file()and(p.suffix=='.rs'or p.name=='Cargo.toml')]+[W/n for n in ['.cargo/config.toml','Cargo.toml','Cargo.lock','rust-toolchain.toml']])
 return dict(sourceBase=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),sources=[dict(path=str(p.relative_to(W)),bytes=p.stat().st_size,sha256=sha(p.read_bytes()))for p in paths])
def main():
 if sys.argv[1:]!=['--execute']:print(json.dumps(dict(status='NOT_RUN_DEFAULT_INERT',Windows='NOT_CONTACTED',scope='AUX_COMPILED_SCOPE_NOT_NORMAL')));return
 assert not O.exists();O.mkdir();(O/'artifacts').mkdir();before=inventory();assert len(before['sources'])==483
 freeze=fact(I/'freeze-first.json');assert freeze['sha256']=='4d092a3c03e12b3262bfbc6a3615ed3483025c5c6a33553081b856161342b28c'
 for row in json.loads((I/'freeze-first.json').read_text())['source']:assert fact(W/row['relativePath'])['sha256']==row['sha256']
 scope=(I/'scope.hex').read_bytes();assert len(scope)==3578 and sha(scope)=='59be5a8b2b82315b754e18be5aad57df5594052fa0315d099562f6175a4939ef'
 env=os.environ.copy();removed=['CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER']
 for k in removed:env.pop(k,None)
 settings={'CARGO_BUILD_JOBS':'2','CARGO_PROFILE_RELEASE_STRIP':'symbols','CARGO_TARGET_DIR':str(T),'CARGO_TARGET_I686_PC_WINDOWS_GNU_LINKER':'i686-w64-mingw32-gcc','RUSTFLAGS':'-C target-feature=+crt-static -C link-arg=-Wl,--major-subsystem-version,6,--minor-subsystem-version,1'}
 env.update(settings);env['FC_OWNED_REMOVAL_SCOPE_HEX']=scope.decode('ascii');report=dict(status='FAIL_RETAIN_ORIGINALS',sourceRoot=str(W),sourceBase=before['sourceBase'],sourceFreeze=freeze,compilerInputs=483,feature='owned-test-removal',profile='AUX_COMPILED_SCOPE_NONTEST_RELEASE_NOT_NORMAL',compiledScope=dict(bytes=1789,sha256='42a5442720830c68d3339fd6b7afc997c13438705d1e7c8b6864462586732934',envBytes=len(scope),envSha256=sha(scope)),environment=settings,removedEnvironmentKeys=removed,scopeBinding=fact(I/'scope-binding.json'),commands=[],runtime='NOT_RUN',guardInvocation='NOT_CALLED_BY_ABSENT_RECOVERY')
 (O/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
 def save():(O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 def call(label,argv,budget=900):
  at=time.monotonic()
  with(O/(label+'.stdout.jsonl')).open('xb')as so,(O/(label+'.stderr.log')).open('xb')as se:
   child=subprocess.Popen(argv,cwd=W,env=env,stdout=so,stderr=se);code=child.wait(timeout=budget)
  row=dict(label=label,argv=argv,actualExit=code,originalParentReaped=True,seconds=time.monotonic()-at,stdout=fact(O/(label+'.stdout.jsonl')),stderr=fact(O/(label+'.stderr.log')));report['commands'].append(row);save();assert code==0
  return row
 save()
 try:
  meta=call('metadata',['cargo','metadata','--offline','--locked','--no-deps','--format-version','1'],60);metadata=json.loads(Path(meta['stdout']['path']).read_bytes());assert metadata['workspace_root']==str(W)and metadata['target_directory']==str(T)
  for label,pkg,target,leaf,kind in [('helper','fc-bootstrap','fc-installer-lifecycle','fc-installer-lifecycle.exe','bin'),('aux-dll','fc-windows','fc_windows','fc_windows.dll','lib')]:
   argv=['cargo','build','--release','--offline','--locked','-p',pkg]+(['--bin',target]if kind=='bin'else['--lib'])+['--features','owned-test-removal','--target',TARGET,'--message-format=json']
   row=call(label,argv);messages=[json.loads(b)for b in Path(row['stdout']['path']).read_bytes().splitlines()if b.startswith(b'{')]
   package=next(p for p in metadata['packages']if p['name']==pkg);hits=[m for m in messages if m.get('reason')=='compiler-artifact'and m['package_id']==package['id']and m['target']['name']==target];assert len(hits)==1;m=hits[0]
   assert m['profile']['test'] is False and m['profile']['opt_level']!='0' and set(m['features'])=={'default','owned-test-removal'}
   path=Path(m['executable'])if kind=='bin'else next(Path(v)for v in m['filenames']if Path(v).name==leaf)
   assert path==T/TARGET/'release'/leaf;data=path.read_bytes();assert 0<len(data)<=32*1024*1024
   if kind=='lib':assert set(m['target']['crate_types'])=={'rlib','cdylib'} and m['executable']is None
   else:assert m['target']['kind']==['bin'] and m['target']['crate_types']==['bin']
   q=O/'artifacts'/leaf;q.write_bytes(data);row.update(artifact=fact(q),compilerArtifact=m)
   assert inventory()==before and (I/'scope.hex').read_bytes()==scope;save()
  after=inventory();(O/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');assert after==before
  report.update(status='PASS_AUX_COMPILED_SCOPE_FEATURE_BUILD_ONLY_NOT_NORMAL',sourceUnchanged=True,inputsBefore=fact(O/'inputs-before.json'),inputsAfter=fact(O/'inputs-after.json'));save()
 except BaseException as error:report.update(error=type(error).__name__+': '+str(error),sourceUnchanged=inventory()==before);save();raise
 print(json.dumps(dict(status=report['status'],report=fact(O/'report.json'))))
if __name__=='__main__':main()
