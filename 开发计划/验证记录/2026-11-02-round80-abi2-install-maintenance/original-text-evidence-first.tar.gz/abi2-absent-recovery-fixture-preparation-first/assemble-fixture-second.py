"""Default-inert local ABI2 AUX_COMPILED_SCOPE fixture; never installs anything."""
from pathlib import Path
import json,hashlib,subprocess,os,sys,uuid,runpy,shutil,re,struct,time
sys.dont_write_bytecode=True
R=Path('/tmp/fc-round80-controlled-repair');P=Path(__file__).resolve().parent;OLD=R/'abi2-maintenance-dev-product-package-first';AUX=R/'abi2-absent-recovery-auxiliary-producer-first';I=R/'abi2-absent-recovery-implementation-first';O=R/'abi2-absent-recovery-fixture-second';TOOLS=R/'inner-guard-probe-tools-first/root/usr/bin';CODEC=R/'checkout-abi2-maintenance-dev-package-first/scripts/installer-carrier-format.py'
def sha(b):return hashlib.sha256(b).hexdigest()
def fact(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def main():
 if sys.argv[1:]!=['--execute']:print(json.dumps(dict(status='NOT_RUN_DEFAULT_INERT',scope='AUX_COMPILED_SCOPE_ABI2_EMPTY_TRANSACTION_ONLY',Windows='NOT_CONTACTED')));return
 assert not O.exists();O.mkdir();env=os.environ.copy();env.pop('FC_OWNED_REMOVAL_SCOPE_HEX',None);env['LD_LIBRARY_PATH']=str(TOOLS.parent/'lib/x86_64-linux-gnu')
 assert sha((OLD/'report.json').read_bytes())=='7876e08aaf32827ac3d4f413732eee7c8857e93bc7a2b1e87685853e63b9481e';old=json.loads((OLD/'report.json').read_text());aux=json.loads((AUX/'report.json').read_text());assert aux['status']=='PASS_AUX_COMPILED_SCOPE_FEATURE_BUILD_ONLY_NOT_NORMAL' and aux['sourceUnchanged']is True and aux['guardInvocation']=='NOT_CALLED_BY_ABSENT_RECOVERY'
 assert sha(CODEC.read_bytes())==old['codecSha256'];codec=runpy.run_path(str(CODEC));commands=[];report=dict(status='FAIL_RETAIN_ORIGINALS',scope='AUX_COMPILED_SCOPE_ABI2_ABSENT_EMPTY_TRANSACTION_ONLY_NOT_NORMAL_NOT_RELEASE',normalAdmission=False,install='FORBIDDEN_NOT_RUN',guardInvocation='FORBIDDEN_NOT_RUN',sourcePackage=fact(OLD/'report.json'),auxiliaryProducer=fact(AUX/'report.json'),scopeBinding=fact(I/'scope-binding.json'),codec=fact(CODEC),commands=commands)
 def save():(O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 def call(label,tool,args,cwd=O,binary=False):
  at=time.monotonic();proc=subprocess.run([str(TOOLS/tool)]+[str(x)for x in args],cwd=cwd,env=env,capture_output=True,timeout=60);so=O/(label+'.stdout.log');se=O/(label+'.stderr.log');
  if not binary:so.write_bytes(proc.stdout)
  se.write_bytes(proc.stderr);commands.append(dict(label=label,argv=[str(TOOLS/tool)]+[str(x)for x in args],actualExit=proc.returncode,originalParentReaped=True,seconds=time.monotonic()-at,stdout=(dict(bytes=len(proc.stdout),sha256=sha(proc.stdout),retained=False,kind='BINARY_IDENTITY_ONLY')if binary else fact(so)),stderr=fact(se),tool=fact(TOOLS/tool)));save();assert proc.returncode==0,(label,proc.returncode);return proc.stdout
 def streams(msi,prefix):
  names=call(prefix+'-streams','msiinfo',['streams',msi]).decode().splitlines();assert len(set(names))==len(names) and all('/'not in n and '\\'not in n for n in names)
  out={}
  for i,name in enumerate(names):out[name]=call(prefix+'-stream-'+str(i),'msiinfo',['extract',msi,name],binary=True)
  return out
 save()
 try:
  oldmsi=OLD/'FutureClassroom.msi';assert fact(oldmsi)['sha256']==old['msi']['sha256'];src=streams(oldmsi,'old');before_summary=call('old-summary','msiinfo',['suminfo',oldmsi]);before_tables=call('old-tables','msiinfo',['tables',oldmsi]).splitlines()
  helper=AUX/'artifacts/fc-installer-lifecycle.exe';normal=helper.read_bytes();template=codec['make_carrier_template'](normal);assert codec['parse_carrier_template'](template)==normal
  (O/'guard-client-template.exe').write_bytes(template);original_envelope=src['Binary.FcPayloadManifest'];parsed=codec['parse_payload_manifest'](original_envelope);body=original_envelope[88:];assert sha(body)==old['payloadManifest']['rawBodySha256']
  package=str(uuid.uuid4()).upper();envelope=codec['make_payload_manifest'](package,body);(O/'payload-manifest.bin').write_bytes(envelope)
  msi=O/'FutureClassroom.msi';shutil.copyfile(oldmsi,msi)
  call('copy-summary9','msibuild',[msi,'-s','FutureClassroom MSI candidate','FutureClassroom','Intel;1033','{'+package+'}'])
  call('copy-stream-replacements','msibuild',[msi,'-a','Binary.FcGuardClientTemplate',O/'guard-client-template.exe','-a','Binary.FcPayloadManifest',O/'payload-manifest.bin'])
  after_summary=call('new-summary','msiinfo',['suminfo',msi]);after_tables=call('new-tables','msiinfo',['tables',msi]).splitlines();assert before_tables==after_tables
  strip=lambda b:[l for l in b.splitlines()if not l.startswith(b'Revision number (UUID):')];assert strip(before_summary)==strip(after_summary)
  hits=re.findall(rb'^Revision number \(UUID\): \{([0-9A-F-]{36})\}\r?$',after_summary,re.M);assert hits==[package.encode()] and package!=old['packageCode']
  new=streams(msi,'new');assert set(new)==set(src)
  changed=sorted(k for k in src if src[k]!=new[k]);assert changed==['\x05SummaryInformation','Binary.FcGuardClientTemplate','Binary.FcPayloadManifest']
  assert new['Binary.FcGuardClientTemplate']==template and new['Binary.FcPayloadManifest']==envelope and new['Binary.FcControlledGuardDll']==src['Binary.FcControlledGuardDll']
  # All ordinary table bytes, including Component/File/Registry/sequence, exact.
  for index,name in enumerate(before_tables):
   table=name.decode();
   if table=='_SummaryInformation':continue
   a=O/('table-old-'+str(index));b=O/('table-new-'+str(index));a.mkdir();b.mkdir();aa=call('old-table-'+str(index),'msiinfo',['export',oldmsi,table],a);bb=call('new-table-'+str(index),'msiinfo',['export',msi,table],b);assert aa==bb
  setup=codec['bind_carrier_template'](template,msi.read_bytes());assert codec['verify_carrier_binding'](template,setup,msi.read_bytes())==normal;(O/'Setup.exe').write_bytes(setup)
  extracted=O/'extracted';extracted.mkdir();call('payload-extract','msiextract',['-C',extracted,msi]);found=[p for p in extracted.rglob('*')if p.is_file()];assert len(found)==14
  payload=[]
  for row in old['payloads']:
   hits=[p for p in found if p.relative_to(extracted).as_posix().endswith('/'+row['path'])];assert len(hits)==1;v=fact(hits[0]);assert v['bytes']==row['size'] and v['sha256']==row['sha256'];payload.append(dict(path=row['path'],bytes=v['bytes'],sha256=v['sha256']))
  shutil.rmtree(extracted)
  # Temporary exported stream files are identities only in the retained report.
  for p in list(O.iterdir()):
   if p.is_dir()and p.name.startswith(('table-old-','table-new-')):shutil.rmtree(p)
  report.update(status='PASS_AUX_COMPILED_SCOPE_ABI2_STATIC_ONLY_NOT_RUN',sourcePackageCode=old['packageCode'],packageCode=package,msi=fact(msi),setup=fact(O/'Setup.exe'),canonicalTemplate=fact(O/'guard-client-template.exe'),helper=fact(helper),auxiliaryDll=fact(AUX/'artifacts/fc_windows.dll'),auxiliaryDllEmbedded=False,guardDllPreserved=sha(src['Binary.FcControlledGuardDll']),all14Unchanged=payload,ordinaryTablesExact=True,summaryOnlyRevisionChanged=True,changedStreams=changed,originalEnvelopeBodySha=sha(body),sourceMsiNewSHA=sha(msi.read_bytes()),template32HoleOnly=True,rawPEHeaderModified=False,compiledScope=aux['compiledScope'],scopeEnvOutput='METADATA_ONLY_NOT_RAW_HEX')
  save()
  binding=json.loads((I/'scope-binding.json').read_text());manifest=dict(status='BOUND_GNU_DEV_ABI2_ABSENT_RECOVERY_AUX_COMPILED_SCOPE_NOT_RELEASE',target='i686-pc-windows-gnu',family='99378807-098D-5F04-8D4D-F181DFA218D5',guardABI=2,sourceGit=aux['sourceBase'],auxiliarySourceGit=aux['sourceBase'],sourceManifest=dict(bytes=fact(AUX/'inputs-before.json')['bytes'],sha256=fact(AUX/'inputs-before.json')['sha256']),productCode=old['productCode'],packageCode=package,version=old['version'],expectedUserSid=binding['oldOriginalProcesses'][0]['Sid'],guardAction='FcControlledInnerGuard',payloads=old['payloads'],setup=report['setup'],msi=report['msi'],compiledScope=aux['compiledScope'],scopeBinding=fact(I/'scope-binding.json'),beforeSnapshot=binding['sources']['snapshot'],oldRuntime=binding['sources']['runtime'],oldPackage=binding['sources']['package'],authorityMapping=fact(O/'report.json'),initialState='ABSENT',expectedNativeTransactions=1,installApi='NOT_CALLED',guardApi='NOT_CALLED',oldEnd='UNKNOWN')
  (O/'recovery-fixture.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(dict(status=report['status'],report=fact(O/'report.json'),artifactManifest=fact(O/'recovery-fixture.json'))))
 except BaseException as error:report.update(error=type(error).__name__+': '+str(error));save();raise
if __name__=='__main__':main()
