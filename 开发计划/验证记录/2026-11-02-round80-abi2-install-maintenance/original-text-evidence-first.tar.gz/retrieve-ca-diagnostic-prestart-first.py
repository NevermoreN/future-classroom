"""Retrieve a known pre-start failure; delete only the byte-verified owned nonce."""
import base64,hashlib,json,runpy,subprocess,time
from pathlib import Path
R=Path('/tmp/fc-round80-controlled-repair');P=R/'abi2-ca-diagnostic-runtime-preparation-first';D=R/'abi2-ca-diagnostic-prestart-retrieval-first'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fact(p):return dict(bytes=Path(p).stat().st_size,sha256=sha(p))
assert not D.exists();ns=runpy.run_path(str(P/'run-diagnostic.py'));ns['checkfreeze'](P,'6e11c69610a472b4dc35b59b34ebdb5b16817abb0b36658adfea7d1819833690')
op=R/'abi2-ca-diagnostic-runtime-first/report.json';assert sha(op)=='3871504d25bb8e2debd1a7deb6e78f812dc53d6c044c046a150b917d8f8f4672';old=json.loads(op.read_bytes());native=old['native']
assert old['status']=='FAIL_RETAIN_ORIGINALS' and native['originalParentReturned'] and 'pid' not in native and 'originalObjects' not in native
assert 'ProductState.ps1' in native['error'] and '禁止运行脚本' in native['error'];assert [x['name']for x in old['operations']][-1]=='run'
nonce='0e910ad50442165011ada09d96cf562e';c=dict(root=old['windowsRoot'],nonce=nonce,sid='S-1-5-21-3896111207-1867804362-1971593122-1001');assert c['root'].endswith('FutureClassroom-r80-ca-diagnostic-'+nonce)
D.mkdir();(D/'.owner').write_text('future-classroom-owned-ca-diagnostic-prestart-retrieval/v1\n');t=time.monotonic();r=dict(status='STARTED_RETRIEVAL_ONLY',originalReport=fact(op),originalRemains='FAIL_PRESTART_SCRIPT_POLICY',beginEnd='NOT_CALLED',oldPending='NOT_ACCESSED',operations=[])
def save():(D/'report.json').write_text(json.dumps(r,indent=2)+'\n')
def call(label,argv,feed=None):
 left=120-(time.monotonic()-t);assert left>0
 if feed is not None:(D/(label+'.stdin.ps1')).write_bytes(feed)
 p=subprocess.Popen(argv,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE);so,se=p.communicate(feed,timeout=min(left,45))
 for k,b in [('stdout',so),('stderr',se)]:(D/(label+'.'+k+'.log')).write_bytes(b)
 r['operations'].append(dict(name=label,actualExit=p.returncode,localOriginalReaped=p.poll() is not None,stdout=fact(D/(label+'.stdout.log')),stderr=fact(D/(label+'.stderr.log'))));save();assert p.returncode==0;return so

def remote(label,body):
 feed=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+ns['COMMON']+body).encode()
 return call(label,['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','future-classroom-win11','powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(ns['BOOT'].encode('utf-16-le')).decode()],feed)
try:
 chunks=json.dumps([dict(name=k,text=ns['COMMON']+ns[k])for k in ['OWNED','INVENTORY','DELETE']]).replace("'","''")
 parser="$chunks='"+chunks+"'|ConvertFrom-Json;$rows=@();foreach($p in $chunks){$t=$null;$e=$null;[void][Management.Automation.Language.Parser]::ParseInput([string]$p.text,[ref]$t,[ref]$e);$rows+=@{name=$p.name;errors=@($e|ForEach-Object {$_.Message})}};$rows|ConvertTo-Json -Depth 8 -Compress;if(@($rows|Where-Object {$_.errors.Count}).Count){exit 1}"
 r['actualPsAst']=json.loads(remote('00-ast',parser));r['ownedBefore']=json.loads(remote('01-owned',ns['OWNED']));assert r['ownedBefore']['count']==0
 inv=json.loads(remote('02-inventory',ns['INVENTORY']));assert len(inv['files'])<=128 and sum(x['bytes']for x in inv['files'])<=64*1024*1024;r['inventory']=inv;save()
 down=D/'download';down.mkdir();call('03-download',['scp','-q','-r','-o','BatchMode=yes','future-classroom-win11:'+c['root'].replace('\\','/'),str(down)]);local=down/Path(c['root'].replace('\\','/')).name
 helper=R/'native-reference-first/run-negative-msi-r79-third.py';assert sha(helper)=='da74f0058deac86507b712075904556780be6b262b18acb82415da6725c6e202';runpy.run_path(str(helper))['verify_download'](local,inv)
 assert json.loads((local/'native-result.json').read_bytes())==native
 for leaf in ['Capture.cs','ProductState.cs','ProductState.ps1']:assert (local/leaf).read_bytes()==(P/leaf).read_bytes()
 r['downloadVerified']=True;c['inventory']=inv;r['ownedBeforeDelete']=json.loads(remote('04-owned-before-delete',ns['OWNED']));assert r['ownedBeforeDelete']['count']==0
 r['cleanup']=json.loads(remote('05-delete',ns['DELETE']));assert r['cleanup']['knownAbsent'];r['status']='PASS_PRESTART_ORIGINAL_RETRIEVAL_AND_EXACT_NONCE_CLEANUP_ORIGINAL_REMAINS_FAIL'
except BaseException as e:r.update(status='FAIL_RETAIN_ORIGINALS',error=type(e).__name__+':'+str(e));raise
finally:r['elapsedSeconds']=time.monotonic()-t;save();print(json.dumps(dict(status=r['status'],reportSha256=sha(D/'report.json'))))
