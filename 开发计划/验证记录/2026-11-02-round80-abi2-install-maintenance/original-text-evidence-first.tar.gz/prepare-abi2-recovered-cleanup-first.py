from pathlib import Path
import ast,hashlib,json,runpy,shutil,re
R=Path('/tmp/fc-round80-controlled-repair');P=R/'abi2-recovered-cleanup-preparation-first';assert not P.exists();P.mkdir();(P/'.owner').write_text('future-classroom-owned-abi2-recovered-cleanup-preparation/v1\n');S=P/'sources';S.mkdir()
old=R/'owned-removal-cleanup-preparation-first';module=runpy.run_path(str(old/'run-owned-removal-cleanup.py'));script=module['SCRIPT']
for leaf in ['ProductState.ps1','ProductState.cs']:shutil.copyfile(R/'abi2-ca-diagnostic-runtime-preparation-second'/leaf,S/leaf)
shutil.copyfile(R/'abi2-maintenance-product-runtime-preparation-first/sources/GateRetirement.cs',S/'GateRetirement.cs')
script=script.replace("newRecovery='ROOT_BOUND_ACTUAL_PASS_ALREADY_DOWNLOADED'","newRecovery='ABI2_ABSENT_SCOPED_NEW_EMPTY_ROLLBACK_KNOWN_RETURN_OLD_END_UNKNOWN'").replace("ONLY_EXACT_TEST_GATE_AND_TWO_TEST_NONCES","ONLY_EXACT_ORIGINAL_EMPTY_GATE_AND_THREE_DOWNLOADED_TEST_NONCES").replace("systemCache='NO_OPERATIONS'","systemCache='EXACT_LOG_DERIVED_PATHS_READONLY_ABSENCE_ONLY'")
oldleaf="$leaf=$(if($root.kind-ceq'old'){'FutureClassroom-r80-controlled-product-'}elseif($root.kind-ceq'new'){'FutureClassroom-r80-owned-removal-'}else{throw 'EXACT_OLD_OR_NEW'})"
newleaf="$leaf=$(if($root.kind-ceq'old-normal'){'FutureClassroom-r80-abi2-maintenance-controlled-product-'}elseif($root.kind-ceq'recovery-first'-or$root.kind-ceq'recovery-second'){'FutureClassroom-r80-abi2-absent-recovery-'}else{throw 'EXACT_THREE_BOUND_ROOT_KINDS'})";assert oldleaf in script;script=script.replace(oldleaf,newleaf)
# Check every original leaf again immediately before its nonrecursive deletion.
script=script.replace("Budget;[IO.File]::Delete((Join-Path $root.path ($f.path.Replace('/','\\'))))","Budget;$leaf=Join-Path $root.path ($f.path.Replace('/','\\'));$a=[IO.File]::GetAttributes($leaf);Need (($a-band1024)-eq0-and($a-band16)-eq0) 'DELETE_LEAF_REGULAR_NONREPARSE';Need ((Get-Item -LiteralPath $leaf -Force).Length-eq$f.bytes-and(Get-FileHash -LiteralPath $leaf -Algorithm SHA256).Hash.ToLowerInvariant()-ceq$f.sha256) 'DELETE_LEAF_ORIGINAL_BYTES';[IO.File]::Delete($leaf)")
start=script.index('function Own-Processes ');end=script.index('function Absent-Product ',start)
script=script[:start]+r'''function Own-Processes {
 Budget;$owned=@();$unknown=@();$prefixes=@($c.roots|ForEach-Object{$_.path+'\'});$product=Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) 'Programs\FutureClassroom\fc-bootstrap.exe'
 foreach($p in @(Get-CimInstance Win32_Process -ErrorAction Stop)){
  $related=$false
  if(-not[string]::IsNullOrEmpty($p.ExecutablePath)){foreach($prefix in $prefixes){if($p.ExecutablePath.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)){$related=$true}};if($p.ExecutablePath-ieq$product){$related=$true}}
  elseif($p.Name-in@('Setup.exe','fc-bootstrap.exe','csc.exe')){$unknown+=@{pid=$p.ProcessId;name=$p.Name}}
  if($p.Name-ieq'csc.exe'){
   if([string]::IsNullOrEmpty($p.CommandLine)){$unknown+=@{pid=$p.ProcessId;name=$p.Name}}
   else{foreach($prefix in $prefixes){if($p.CommandLine.IndexOf($prefix,[StringComparison]::OrdinalIgnoreCase)-ge0){$related=$true}}}
  }
  if($related){$owned+=@{pid=$p.ProcessId;name=$p.Name;image=$p.ExecutablePath}}
 }
 return @{owned=$owned;unknown=$unknown;knownZero=($owned.Count-eq0-and$unknown.Count-eq0);commandContentsRetained=$false;scope='EXACT_THREE_OWNED_ROOT_PREFIXES_PRODUCT_IMAGE_AND_THEIR_CSC_ONLY'}
}
function Exact-System-Absence {Budget;$rows=@();foreach($path in $c.systemPaths){Need ($path-cmatch'^C:\\Windows\\Installer\\[A-Za-z0-9]{1,64}\.(msi|tmp)$') 'EXACT_LOG_DERIVED_SYSTEM_FILE_ONLY';$v=Known $path;Need ($v.status-ceq'KNOWN_ABSENT') 'SYSTEM_CACHE_OR_DLL_PRESENT_READONLY_NO_DELETE';$rows+=,$v};return ,$rows}
''' + script[end:]
script=script.replace("-Config $c.productConfig -Expected 'Absent'","-Config $c.productConfig -Expected 'Absent' -SourceRoot $c.roots[2].path")
oldneed="Need (@($c.roots).Count-eq2 -and $c.roots[0].kind-ceq'old' -and $c.roots[1].kind-ceq'new' -and $c.roots[0].path-cne$c.roots[1].path) 'EXACT_TWO_ROOTS'"
newneed="Need (@($c.roots).Count-eq3-and$c.roots[0].kind-ceq'old-normal'-and$c.roots[1].kind-ceq'recovery-first'-and$c.roots[2].kind-ceq'recovery-second'-and@($c.roots.path|Select-Object -Unique).Count-eq3) 'EXACT_THREE_ROOTS'";assert oldneed in script;script=script.replace(oldneed,newneed).replace("$c.roots[1].path 'instrument-temp'","$c.roots[2].path 'instrument-temp'").replace("$c.roots[1].inventory.directories","$c.roots[2].inventory.directories")
script=script.replace("$result['beforeProduct']=Absent-Product","$result['beforeProduct']=Absent-Product;$result['beforeExactSystemPaths']=Exact-System-Absence")
script=script.replace("$result['finalProduct']=Absent-Product;","$result['finalProduct']=Absent-Product;$result['finalExactSystemPaths']=Exact-System-Absence;")
script=script.replace('PASS_EXACT_OWNED_REMOVAL_TWO_NONCES_AND_ORIGINAL_EMPTY_GATE_CLEANED','PASS_ABI2_RECOVERED_THREE_NONCES_AND_ORIGINAL_EMPTY_GATE_CLEANED_OLD_END_UNKNOWN')
(P/'cleanup-first.ps1').write_text(script)
(P/'ps-ast-chunks-first.json').write_text(json.dumps([dict(name='CLEANUP',script=script),dict(name='PRODUCT_STATE_FUNCTION',script=(S/'ProductState.ps1').read_text())],indent=2)+'\n')
