from pathlib import Path
import json,hashlib,ast,subprocess
R=Path('/tmp/fc-round80-controlled-repair');P=R/'abi2-absent-recovery-runtime-preparation-first';PF=R/'abi2-absent-recovery-fixture-preparation-first';F=R/'abi2-absent-recovery-fixture-fourth';A=R/'abi2-absent-recovery-auxiliary-producer-first'
def fact(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,v):
 assert not p.exists(),p
 p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
producer=json.loads((A/'report.json').read_bytes());package=json.loads((F/'report.json').read_bytes());manifest=json.loads((F/'recovery-fixture.json').read_bytes())
assert producer['status']=='PASS_AUX_COMPILED_SCOPE_FEATURE_BUILD_ONLY_NOT_NORMAL' and producer['sourceUnchanged'] is True and producer['compilerInputs']==483
assert producer['inputsBefore']['sha256']==producer['inputsAfter']['sha256']==manifest['sourceManifest']['sha256']
assert all(x['actualExit']==0 and x['originalParentReaped']is True for x in producer['commands'])
assert package['status']=='PASS_AUX_COMPILED_SCOPE_ABI2_STATIC_ONLY_NOT_RUN' and all(x['actualExit']==0 and x['originalParentReaped']is True for x in package['commands'])
assert package['all14Unchanged']==[{'path':v['path'],'bytes':v['size'],'sha256':v['sha256']}for v in manifest['payloads']]
assert package['ordinaryTablesExact'] and package['summaryOnlyRevisionChanged'] and package['template32HoleOnly'] and package['auxiliaryDllEmbedded'] is False and package['rawPEHeaderModified'] is False
assert package['changedStreams']==[chr(5)+'SummaryInformation','Binary.FcGuardClientTemplate','Binary.FcPayloadManifest']
for k in ['setup','msi']:assert fact(Path(manifest[k]['path']))==manifest[k]
assert package['compiledScope']==manifest['compiledScope']==producer['compiledScope']
for p in list(P.glob('*.py'))+list(PF.glob('*.py')):ast.parse(p.read_text())
reuse=[];old=R/'owned-removal-runtime-preparation-first'
for n in ['Capture.cs','ProcessObserver.cs','ProductState.cs','PendingSnapshot.cs']:
 a=P/'sources'/n;b=old/'sources'/n;assert a.read_bytes()==b.read_bytes();reuse.append({'source':fact(b),'copy':fact(a),'equal':True})
assert (P/'transport-support.py').read_bytes()==(old/'transport-support.py').read_bytes();reuse.append({'source':fact(old/'transport-support.py'),'copy':fact(P/'transport-support.py'),'equal':True})
write(P/'provenance-first.json',{'status':'LOCAL_SOURCE_AND_ARTIFACT_QUALIFICATION_ONLY_WINDOWS_NOT_RUN','producer':fact(A/'report.json'),'fixtureReport':fact(F/'report.json'),'fixtureManifest':fact(F/'recovery-fixture.json'),'sourceManifest':fact(A/'inputs-before.json'),'readOnlyCurrent':fact(R/'abi2-maintenance-failure-current-readonly-first/report.json'),'reusedExactSources':reuse,'modifiedPS':['Invoke-OwnedRemoval.ps1: absent one-transaction semantics; checked bytes ScriptBlock invocation','ProductState.ps1: explicit SourceRoot only; in-memory definition load'],'sourceScope':'483 Rust/Cargo inputs; auxiliary feature NONTEST profile. Old payload14 original normal bytes. No normal release qualification.','scopeRaw':'NOT_COPIED_NOT_UPLOADED; metadata identity only','numericAuthority':'Authenticated original G FCO1 fields checked by B and native return branch audit; not direct G API stdout; old End UNKNOWN.','cleanup':'Controller downloads all bytes; retains scratch/gate for root exact cleanup; never kill or hand-delete Pending/cache/system paths.'})
q=subprocess.run(['python3',str(P/'run-absent-recovery.py')],capture_output=True);assert q.returncode==0
write(P/'default-inert-first.json',{'actualExit':q.returncode,'originalParentReaped':True,'stdout':q.stdout.decode(),'stderr':q.stderr.decode(),'Windows':'NOT_RUN'})
write(P/'entrypoints-first.json',{'runtimeArgv':['python3',str(P/'run-absent-recovery.py'),'--execute','--artifact-manifest',str(F/'recovery-fixture.json'),'--artifact-manifest-sha256',fact(F/'recovery-fixture.json')['sha256'],'--source-manifest',str(A/'inputs-before.json'),'--source-manifest-sha256',fact(A/'inputs-before.json')['sha256'],'--preparation-freeze-sha256','<EXACT_SHA256_OF_THIS_PREPARATION_FREEZE>','--report',str(R/'abi2-absent-recovery-runtime-first/report.json')],'PS51_AST_INPUTS':fact(P/'ps-ast-chunks-third.json'),'Windows':'ROOT_ONLY_NOT_RUN','outMustNotExist':str(R/'abi2-absent-recovery-runtime-first')})
assert not (R/'abi2-absent-recovery-runtime-first').exists()
for d,selected,extra in [
 (PF,sorted(PF.glob('*.py')),{'status':'FROZEN_LOCAL_EXECUTED_PRODUCER_AND_DERIVATION_SCRIPTS','producer':fact(A/'report.json'),'successfulFixture':fact(F/'report.json'),'oldFailureDirectories':[str(R/f'abi2-absent-recovery-fixture-{x}') for x in ['first','second','third']]}),
 (F,[F/'report.json',F/'recovery-fixture.json',F/'auxiliary-pe-extent-audit-first.json'],{'status':'FROZEN_AUX_STATIC_FIXTURE_WINDOWS_NOT_RUN','artifactIdentities':[manifest['setup'],manifest['msi'],package['canonicalTemplate'],package['helper'],package['auxiliaryDll']],'rawScope':'IDENTITY_ONLY_NOT_INCLUDED'})]:
 rows=[]
 for p in selected:
  f=fact(p);f['path']=str(p.relative_to(d));rows.append(f)
 write(d/'freeze-first.json',{**extra,'files':rows})
rows=[]
for p in sorted([*P.glob('*'),*P.joinpath('sources').glob('*')]):
 if not p.is_file():continue
 f=fact(p);f['path']=str(p.relative_to(P));rows.append(f)
write(P/'freeze-first.json',{'status':'FROZEN_PREPARED_NOT_WINDOWS_PARSED_NOT_EXECUTED','files':rows,'preparationScope':'One default-off ABI2 absent recovery auxiliary; 1 empty transaction, no Install/CA. Original End UNKNOWN.','expectedPSChunks':5,'localPureAdmissions':{'positive':1,'negative':38},'sourceUnchanged':True,'sourceManifest':fact(A/'inputs-before.json'),'artifactManifest':fact(F/'recovery-fixture.json')})
print(json.dumps({'runtimePreparationFreeze':fact(P/'freeze-first.json'),'fixturePreparationFreeze':fact(PF/'freeze-first.json'),'fixtureFreeze':fact(F/'freeze-first.json'),'artifactManifest':fact(F/'recovery-fixture.json'),'sourceManifest':fact(A/'inputs-before.json'),'psChunks':fact(P/'ps-ast-chunks-third.json')}))
