from pathlib import Path
import runpy,json,copy,hashlib,subprocess
P=Path(__file__).resolve().parent;R=P.parent;M=runpy.run_path(str(P/'run-absent-recovery.py'))
a=R/'abi2-absent-recovery-fixture-fourth/recovery-fixture.json';s=R/'abi2-absent-recovery-auxiliary-producer-first/inputs-before.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
c,af,sf=M['bind'](a,sha(a),s,sha(s));assert c['initialState']=='ABSENT' and c['expectedNativeTransactions']==1
base={'status':'PASS_GNU_WIN11_ABI2_ABSENT_RECOVERY_OLD_END_UNKNOWN','oldEnd':'UNKNOWN_UNCHANGED','ownerUnknown':False,'instrumentUnknown':False,'originalBudgetExceeded':False,'finallyProduct':{'knownAbsent':True,'runAbsent':True,'status':'PASS_READONLY_EXPECTED_ABSENT'},'finallyCoordination':{'pendingKnownAbsent':True},'finallyOwnProcesses':{'knownZero':True},'afterCache':{'allObservedAbsent':True},'oldExactInstallerPathsAbsent':True,'nativeAudit':{'oldEnd':'UNKNOWN_UNCHANGED','stage':'RemovalAuthorized','oldDisposition':'UNKNOWN','oldEndSynthesized':False,'directGApiStdoutTelemetry':'NOT_SERIALIZED','empty':{'begin':0,'end':0,'transaction':7,'install':'NOT_CALLED','guard':'NOT_CALLED','numericOrigin':'AUTHENTICATED_ORIGINAL_G_FCO1_VALUES_ZERO_CHECKED_BY_NATIVE_B'}},'phases':[{'verb':'owned-test-remove','client':{'started':True,'actualExit':True,'exitCode':0,'pipesComplete':True,'timedOut':False,'pid':10,'creationFiletime':11},'knownControlsReturned':True,'directOriginalFinal':[{'Status':'HELD_ORIGINAL_IDENTITY','Wait':0,'ExitKnown':True,'ExitCode':0,'CheckedClose':True,'CloseAttempted':True,'Pid':10,'Creation':11}],'observerFinal':{'Closed':True,'Errors':[],'Processes':[{'IdentityStatus':'ORIGINAL_QUERY_SYNC_HANDLE_EXACT_IMAGE_BYTES_USER','ActualWait':0,'ActualExitCode':0,'CloseStatus':'CHECKED_CLOSE_SUCCESS'}]},'postPhaseProcesses':{'knownZero':True}}]}
assert M['admission'](base)
cases=[]
def bad(path,value):
 x=copy.deepcopy(base);v=x
 for k in path[:-1]:v=v[k]
 v[path[-1]]=value;assert not M['admission'](x),path;cases.append({'path':path,'value':value})
for path in [['ownerUnknown'],['instrumentUnknown'],['originalBudgetExceeded']]:bad(path,True)
for key in ['knownAbsent','runAbsent']:bad(['finallyProduct',key],False)
for path in [['finallyCoordination','pendingKnownAbsent'],['finallyOwnProcesses','knownZero'],['afterCache','allObservedAbsent'],['oldExactInstallerPathsAbsent']]:bad(path,False)
for key in ['begin','end']:
 for val in [False,True,1,1603,None]:bad(['nativeAudit','empty',key],val)
for val in [False,0,-1,None]:bad(['nativeAudit','empty','transaction'],val)
for key in ['install','guard']:bad(['nativeAudit','empty',key],0)
bad(['nativeAudit','directGApiStdoutTelemetry'],'DIRECT_API0');bad(['nativeAudit','oldEndSynthesized'],True);bad(['nativeAudit','empty','numericOrigin'],'SYNTHETIC_EXIT0');bad(['oldEnd'],'0')
for key in ['actualExit','pipesComplete']:bad(['phases',0,'client',key],False)
bad(['phases',0,'client','exitCode'],1603);bad(['phases',0,'directOriginalFinal',0,'CheckedClose'],False);bad(['phases',0,'observerFinal','Processes',0,'ActualWait'],258);bad(['phases',0,'postPhaseProcesses','knownZero'],False)
bad(['phases'],[]);bad(['phases'],base['phases']*2)
# Render only; no SSH/process execution. Root later runs PS51 AST on these exact bytes.
chunks=[]
for name in ['CREATE','INVOKE','INVENTORY']:
 argv,feed=M['remote'](M[name],{'nonce':'0'*32,'sid':c['expectedUserSid'],'root':None});p=P/(name.lower()+'-ast.ps1');p.write_bytes(feed);chunks.append({'name':name,'path':str(p),'bytes':len(feed),'sha256':sha(p)})
for name in ['Invoke-OwnedRemoval.ps1','ProductState.ps1']:
 p=P/'sources'/name;chunks.append({'name':name,'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
(P/'ps-ast-chunks-first.json').write_text(json.dumps({'status':'PREPARED_NOT_WINDOWS_PARSED','chunks':chunks},indent=2)+'\n')
(P/'local-checks-first.json').write_text(json.dumps({'status':'PASS_LOCAL_PURE_QUALIFICATION_ONLY','artifactBinding':af,'sourceBinding':sf,'positiveAdmission':1,'negativeAdmissions':len(cases),'cases':cases,'Windows':'NOT_RUN','sourceScope':'Synthetic qualification sample only; no native API claims'},indent=2)+'\n')
print(json.dumps({'status':'PASS_LOCAL_PURE_ONLY','positive':1,'negative':len(cases),'psChunks':len(chunks)}))
