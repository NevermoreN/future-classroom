from pathlib import Path
import shutil,json,hashlib,difflib
R=Path('/tmp/fc-round80-controlled-repair');P=R/'abi2-summary-output-fix-second';assert not P.exists();P.mkdir();(P/'.owner').write_text('future-classroom-owned-abi2-summary-output-fix/v1\n')
paths=['crates/fc-windows/src/installer_lifecycle/native/inner_guard/abi2.rs','crates/fc-windows/src/installer_lifecycle/native/broker/source_package/database.rs','crates/fc-windows/src/installer_lifecycle/native/broker/maintenance/database.rs','crates/fc-windows/src/installer_lifecycle/native/broker/installed_release/cached_database.rs']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for old,new in [('checkout-abi2-maintenance-dev-package-first','checkout-abi2-summary-output-production-second'),('checkout-abi2-ca-diagnostic-second','checkout-abi2-ca-diagnostic-fourth')]:
 w=R/new;assert not w.exists();shutil.copytree(R/old,w)
 rows=[];patch=[]
 for rel in paths:
  p=w/rel;before=p.read_text();marker='        let (mut kind, mut integer) = (0, 0);'if 'cached_database'not in rel and 'maintenance/database'not in rel else('        let (mut kind, mut value) = (0, 0);'if 'maintenance/database'in rel else'        let mut integer = 0;')
  assert before.count('MsiSummaryInfoGetPropertyW(')==1 and before.count(marker)==1
  after=before.replace(marker,marker+'\n        // Even a string Summary property requires non-null output storage.\n        let mut file_time = windows::Win32::Foundation::FILETIME::default();')
  # Only this Summary API's fifth argument; never alter unrelated optional INPUTS.
  at=after.index('MsiSummaryInfoGetPropertyW(');end=after.index('        };',at);call=after[at:end];assert call.count('                None,')==1;after=after[:at]+call.replace('                None,','                Some(&mut file_time),',1)+after[end:]
  p.write_text(after);rows.append(dict(path=rel,before=sha(R/old/rel),after=sha(p)));patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 if 'production'in new:
  (P/'production-only.patch').write_text(''.join(patch))
  for rel in paths:
   q=P/'source'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/rel,q)
  (P/'production-source-first.json').write_text(json.dumps(dict(baseSourceRoot=str(R/old),normalEvidenceSha256='189bc7c06f2e6ca8b9d9109f02d732baa324c52095ce30e9a866b004413b2ed4',newSourceRoot=str(w),changes=rows,scope='FOUR_MSISUMMARY_OUTPUT_ADDRESSES_ONLY_NO_DIAGNOSTIC_FEATURE',Windows='NOT_RUN'),indent=2)+'\n')
(P/'sources.json').write_text(json.dumps(paths,indent=2)+'\n')
script=(R/'abi2-ca-diagnostic-preparation-first/build-diagnostic-second.py').read_text().replace("checkout-abi2-ca-diagnostic-second'","checkout-abi2-ca-diagnostic-fourth'").replace("abi2-ca-diagnostic-producer-second'","abi2-ca-diagnostic-producer-fourth'")
(P/'build-diagnostic-fourth.py').write_text(script)
