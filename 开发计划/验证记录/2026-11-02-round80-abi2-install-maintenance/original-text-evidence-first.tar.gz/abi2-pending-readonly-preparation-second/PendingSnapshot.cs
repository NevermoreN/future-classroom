// READ-ONLY TEST INSTRUMENT. No MSI, registry, delete, recovery or settlement API.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;

public static class Fc80Abi2PendingSnapshot {
    const uint Query=0x80, ReadControl=0x20000, Read=0x80000000, Existing=3, Flags=0x02200000;
    const string Leaf="FutureClassroom-Installer-99378807-098D-5F04-8D4D-F181DFA218D5";
    [StructLayout(LayoutKind.Sequential)] struct Info {
        public uint Attributes, CreationLow, CreationHigh, AccessLow, AccessHigh;
        public uint WriteLow, WriteHigh, Volume, SizeHigh, SizeLow, Links, IndexHigh, IndexLow;
    }
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr CreateFile(string p,uint a,uint s,IntPtr sa,uint d,uint f,IntPtr t);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetFileInformationByHandle(IntPtr h,out Info i);
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern uint GetFinalPathNameByHandle(IntPtr h,System.Text.StringBuilder p,uint n,uint f);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetFileSizeEx(IntPtr h,out long size);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool SetFilePointerEx(IntPtr h,long distance,out long position,uint method);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool ReadFile(IntPtr h,byte[] b,uint n,out uint got,IntPtr overlapped);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool CloseHandle(IntPtr h);
    [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr LocalFree(IntPtr p);
    [DllImport("kernel32.dll")] public static extern ulong GetTickCount64();
    [DllImport("advapi32.dll")] static extern uint GetSecurityInfo(IntPtr h,int type,uint flags,out IntPtr owner,out IntPtr group,out IntPtr dacl,out IntPtr sacl,out IntPtr sd);
    [DllImport("advapi32.dll")] static extern uint GetSecurityDescriptorLength(IntPtr sd);
    public sealed class NativeReturn {
        public string Role;public long OriginalHandle,ReturnValue;public bool Attempted,Success,Unknown;public int LastError;
    }
    public sealed class FileFact {
        public string Role,Path,Identity,Volume,FileId,CreationHex,CreationUtc,OwnerDaclSddl,SecurityDescriptorBase64,FinalPath;
        public ulong CreationFiletime,WriteFiletime,Bytes;public uint Links,Attributes;
    }
    public sealed class CaptureResult {
        public string Status="FAIL_OR_UNKNOWN_READONLY",Scope="FIRST_CURRENT_ABI2_PENDING_OBSERVATION_NOT_ORIGINAL_FILE_ID_OR_RECOVERY_AUTHORITY",Error;
        public bool Mutations=false,OriginalEndKnown=false,SameHandleBytesEqual=false,SameHandleMetadataEqual=false,CloseUnknown=false;
        public string OriginalEnd="UNKNOWN_UNCHANGED",BytesBase64,Sha256,CurrentUtc;
        public long CurrentUtcFiletime;public ulong CurrentTickCount64;public int CompleteBytes;
        public string SchemaDiagnostic="NOT_READ",ParsedFamily,ParsedNonce,ParsedSid;public int ParsedOperationTag=-1;public bool SchemaContainsPidOrBootIdentity=false;
        public string BootIdentity="UNKNOWN_NOT_CAPTURED_IN_OLD_REPORT",SameBoot="NOT_ASSERTED",PendingAclStatus="NOT_CHECKED";
        public FileFact RootBefore,GateBefore,PendingBefore,PendingAfter,GateAfter,RootAfter;
        public List<NativeReturn> NativeReturns=new List<NativeReturn>();
    }
    sealed class Cap { public IntPtr Handle;public string Role;public bool CloseAttempted; }
    static void Need(bool b,string code) { if(!b)throw new InvalidOperationException(code); }
    static Exception Win(string code) { return new Win32Exception(Marshal.GetLastWin32Error(),code); }
    static Cap Open(List<Cap> caps,string role,string path,uint access,uint share) {
        IntPtr h=CreateFile(path,access,share,IntPtr.Zero,Existing,Flags,IntPtr.Zero);
        if(h==new IntPtr(-1))throw Win("NONBLOCKING_OPEN_EXISTING:"+role);
        Cap c=new Cap();c.Handle=h;c.Role=role;caps.Add(c);return c;
    }
    static void Close(CaptureResult result,Cap cap) {
        if(cap.CloseAttempted)return;cap.CloseAttempted=true;
        NativeReturn row=new NativeReturn();row.Role=cap.Role;row.OriginalHandle=cap.Handle.ToInt64();row.Attempted=true;result.NativeReturns.Add(row);
        row.Success=CloseHandle(cap.Handle);row.ReturnValue=row.Success?1:0;row.LastError=row.Success?0:Marshal.GetLastWin32Error();row.Unknown=!row.Success;
        if(row.Success)cap.Handle=IntPtr.Zero;else result.CloseUnknown=true;
    }
    static string Security(CaptureResult result,IntPtr h,out string raw) {
        IntPtr owner,group,dacl,sacl,sd;raw=null;
        uint e=GetSecurityInfo(h,1,5,out owner,out group,out dacl,out sacl,out sd);
        if(e!=0)throw new Win32Exception((int)e,"GetSecurityInfo_OWNER_DACL");
        try {
            uint n=GetSecurityDescriptorLength(sd);Need(n>=20&&n<=8192,"BOUNDED_OWNER_DACL");
            byte[] b=new byte[n];Marshal.Copy(sd,b,0,(int)n);raw=Convert.ToBase64String(b);
            RawSecurityDescriptor s=new RawSecurityDescriptor(b,0);
            return s.GetSddlForm(AccessControlSections.Owner|AccessControlSections.Access);
        } finally {
            NativeReturn row=new NativeReturn();row.Role="security_descriptor_LocalFree";row.OriginalHandle=sd.ToInt64();row.Attempted=true;
            IntPtr returned=LocalFree(sd);row.ReturnValue=returned.ToInt64();row.Success=returned==IntPtr.Zero;row.LastError=row.Success?0:Marshal.GetLastWin32Error();row.Unknown=!row.Success;result.NativeReturns.Add(row);
            if(!row.Success){result.CloseUnknown=true;throw new InvalidOperationException("LOCALFREE_UNKNOWN_NO_RETRY");}
        }
    }
    static FileFact Inspect(CaptureResult result,Cap c,string path,bool directory) {
        Info i;if(!GetFileInformationByHandle(c.Handle,out i))throw Win("HANDLE_INFO:"+c.Role);
        Need((i.Attributes&0x400)==0&&((i.Attributes&16)!=0)==directory,"NO_REPARSE_EXACT_TYPE:"+c.Role);
        System.Text.StringBuilder final=new System.Text.StringBuilder(4096);
        uint n=GetFinalPathNameByHandle(c.Handle,final,(uint)final.Capacity,0);
        Need(n>4&&n<4096&&final.ToString().StartsWith(@"\\?\",StringComparison.Ordinal),"BOUNDED_FINAL_DOS_PATH:"+c.Role);
        string actual=final.ToString().Substring(4);
        Need(String.Equals(actual.TrimEnd('\\'),path.TrimEnd('\\'),StringComparison.OrdinalIgnoreCase),"HANDLE_PATH_MATCH:"+c.Role);
        FileFact f=new FileFact();f.Role=c.Role;f.Path=path;f.FinalPath=final.ToString();f.Volume=i.Volume.ToString("x8");
        f.FileId=i.IndexHigh.ToString("x8")+i.IndexLow.ToString("x8");f.CreationHex=i.CreationHigh.ToString("x8")+i.CreationLow.ToString("x8");
        f.Identity=f.Volume+":"+f.FileId+":"+f.CreationHex;f.CreationFiletime=((ulong)i.CreationHigh<<32)|i.CreationLow;
        f.CreationUtc=DateTime.FromFileTimeUtc((long)f.CreationFiletime).ToString("o");f.WriteFiletime=((ulong)i.WriteHigh<<32)|i.WriteLow;
        f.Bytes=((ulong)i.SizeHigh<<32)|i.SizeLow;f.Links=i.Links;f.Attributes=i.Attributes;
        f.OwnerDaclSddl=Security(result,c.Handle,out f.SecurityDescriptorBase64);return f;
    }
    static bool Same(FileFact a,FileFact b) {
        return a.Identity==b.Identity&&a.Bytes==b.Bytes&&a.Links==b.Links&&a.Attributes==b.Attributes&&a.WriteFiletime==b.WriteFiletime&&a.OwnerDaclSddl==b.OwnerDaclSddl&&a.FinalPath==b.FinalPath;
    }
    static byte[] ReadComplete(Cap c) {
        long size,position;if(!GetFileSizeEx(c.Handle,out size))throw Win("PENDING_SIZE");Need(size>=0&&size<=4096,"PENDING_LE4096");
        if(!SetFilePointerEx(c.Handle,0,out position,0))throw Win("OWN_HANDLE_SEEK_ONLY");Need(position==0,"ZERO_READ_POSITION");
        byte[] b=new byte[4097];uint got;
        if(!ReadFile(c.Handle,b,4097,out got,IntPtr.Zero))throw Win("PENDING_READ_COMPLETE");
        Need(got==(uint)size,"FULL_BYTES_EOF_SIZE_MATCH");
        uint extra;byte[] eof=new byte[1];if(!ReadFile(c.Handle,eof,1,out extra,IntPtr.Zero))throw Win("PENDING_EOF");Need(extra==0,"PENDING_EOF_ZERO");
        byte[] exact=new byte[(int)got];Buffer.BlockCopy(b,0,exact,0,(int)got);return exact;
    }
    static void Diagnose(CaptureResult result,byte[] bytes,string user) {
        if(bytes.Length==0){result.SchemaDiagnostic="EMPTY_INVALID_PENDING_NO_AUTHORITY";return;}
        try {
            byte[] magic=System.Text.Encoding.ASCII.GetBytes("FC-INSTALL-PENDING\0v1\0");
            byte[] family=System.Text.Encoding.ASCII.GetBytes("99378807-098D-5F04-8D4D-F181DFA218D5");
            int at=0;foreach(byte b in magic){Need(at<bytes.Length&&bytes[at++]==b,"BAD_MAGIC");}
            foreach(byte b in family){Need(at<bytes.Length&&bytes[at++]==b,"BAD_FAMILY");}
            Need(at<bytes.Length&&bytes[at++]==0&&at+19<=bytes.Length,"TRUNCATED_FIELDS");
            byte[] nonce=new byte[16];Buffer.BlockCopy(bytes,at,nonce,0,16);at+=16;bool nonzero=false;foreach(byte b in nonce)if(b!=0)nonzero=true;Need(nonzero,"ZERO_NONCE");
            int tag=bytes[at++];Need(tag>=1&&tag<=5,"BAD_TAG");int length=bytes[at]|(bytes[at+1]<<8);at+=2;
            Need(length>=8&&length<=68&&at+length==bytes.Length&&bytes[at+1]<=15&&length==8+4*bytes[at+1],"SID_LENGTH_OR_TRAILING");
            SecurityIdentifier sid=new SecurityIdentifier(bytes,at);Need(sid.Value==user,"SID_MISMATCH");
            result.ParsedFamily=System.Text.Encoding.ASCII.GetString(family);result.ParsedNonce=BitConverter.ToString(nonce).Replace("-","").ToLowerInvariant();result.ParsedSid=sid.Value;result.ParsedOperationTag=tag;
            result.SchemaDiagnostic="CANONICAL_V1_BYTES_ONLY_NO_OWNER_LIVENESS_END_OR_RECOVERY_AUTHORITY";
        } catch(Exception error) { result.SchemaDiagnostic="INVALID_OR_MISMATCH_V1:"+error.Message; }
    }
    public static CaptureResult Capture(string[] expected) {
        CaptureResult result=new CaptureResult();List<Cap> caps=new List<Cap>();
        try {
            Need(expected!=null&&expected.Length==6,"EXACT_SIX_ORIGINAL_GATE_FACTS");
            string sid;using(WindowsIdentity identity=WindowsIdentity.GetCurrent())sid=identity.User.Value;
            Need(sid==expected[1],"ORIGINAL_CURRENT_SID");
            string local=Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string root=Path.Combine(local,Leaf),gate=Path.Combine(root,"gate.lock"),pending=Path.Combine(root,"pending.v1");
            Need(root==expected[0]&&root.Length<2048&&root.Length>3&&root[1]==':'&&!root.StartsWith(@"\\",StringComparison.Ordinal),"FIXED_KNOWNFOLDER_FAMILY_ROOT");
            List<string> ancestors=new List<string>();string p=Path.GetDirectoryName(root);
            while(p!=null){ancestors.Add(p);p=Path.GetDirectoryName(p);}ancestors.Reverse();Need(ancestors.Count<=48,"ANCESTOR_CAP_BOUND");
            foreach(string parent in ancestors){Cap a=Open(caps,"ancestor",parent,Query|ReadControl,3);Inspect(result,a,parent,true);}
            Cap d=Open(caps,"familyroot",root,Query|ReadControl,3);
            result.RootBefore=Inspect(result,d,root,true);if(String.IsNullOrEmpty(expected[2])){expected[2]=result.RootBefore.Identity;expected[4]=result.RootBefore.OwnerDaclSddl;}Need(result.RootBefore.Identity==expected[2]&&result.RootBefore.OwnerDaclSddl==expected[4],"ORIGINAL_ROOT_ID_CREATION_ACL");
            // Share0 is the same nonblocking exclusive-open gate. No byte is written.
            Cap g=Open(caps,"exclusive_gate",gate,Query|ReadControl,0);
            result.GateBefore=Inspect(result,g,gate,false);if(String.IsNullOrEmpty(expected[3])){expected[3]=result.GateBefore.Identity;expected[5]=result.GateBefore.OwnerDaclSddl;}
            Need(result.GateBefore.Identity==expected[3]&&result.GateBefore.OwnerDaclSddl==expected[5]&&result.GateBefore.Bytes==0&&result.GateBefore.Links==1,"ORIGINAL_GATE_ID_CREATION_ACL_EMPTY_SINGLELINK");
            Cap f=Open(caps,"pending_readonly",pending,Read|Query|ReadControl,1);
            result.PendingBefore=Inspect(result,f,pending,false);Need(result.PendingBefore.Bytes<=4096&&result.PendingBefore.Links==1,"PENDING_BOUNDED_SINGLELINK");
            result.PendingAclStatus=result.PendingBefore.OwnerDaclSddl==expected[5]?"EXACT_ORIGINAL_PROTECTED_LEAF_OWNER_DACL":"MISMATCH_NO_AUTHORITY";
            Need(result.PendingAclStatus=="EXACT_ORIGINAL_PROTECTED_LEAF_OWNER_DACL","PENDING_EXACT_GATE_LEAF_PROTECTED_OWNER_DACL");
            byte[] first=ReadComplete(f);Diagnose(result,first,sid);result.BytesBase64=Convert.ToBase64String(first);result.CompleteBytes=first.Length;
            using(SHA256Managed hash=new SHA256Managed())result.Sha256=BitConverter.ToString(hash.ComputeHash(first)).Replace("-","").ToLowerInvariant();
            result.PendingAfter=Inspect(result,f,pending,false);byte[] second=ReadComplete(f);
            result.SameHandleBytesEqual=Convert.ToBase64String(first)==Convert.ToBase64String(second);
            FileFact last=Inspect(result,f,pending,false);result.SameHandleMetadataEqual=Same(result.PendingBefore,result.PendingAfter)&&Same(result.PendingAfter,last);
            result.PendingAfter=last;Need(result.SameHandleBytesEqual&&result.SameHandleMetadataEqual,"SAME_PENDING_HANDLE_TWO_READS_STABLE");
            result.GateAfter=Inspect(result,g,gate,false);result.RootAfter=Inspect(result,d,root,true);
            Need(Same(result.GateBefore,result.GateAfter)&&Same(result.RootBefore,result.RootAfter),"HELD_GATE_ROOT_STABLE");
            result.Status="PASS_READONLY_PINNED_PENDING_SNAPSHOT_ONLY";
        } catch(Exception error) { result.Error=error.GetType().FullName+":"+error.Message; }
        finally {
            for(int i=caps.Count-1;i>=0;i--)Close(result,caps[i]);
            if(result.CloseUnknown)result.Status="FAIL_NATIVE_RELEASE_UNKNOWN_RETAIN";
            result.CurrentTickCount64=GetTickCount64();DateTime now=DateTime.UtcNow;result.CurrentUtc=now.ToString("o");result.CurrentUtcFiletime=now.ToFileTimeUtc();
        }
        return result;
    }
}
