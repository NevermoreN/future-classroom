"""Read-only ABI2 normal DEV source/artifact admission; no CLI or compilation."""
from pathlib import Path
import hashlib
import json
import runpy


def admit_normal_inputs(source_root: Path, evidence: Path, evidence_sha256: str) -> dict:
    """Exact frozen mixed-source ledger, three real normal Cargo artifacts/PEs.

    Caller separately pins this validator and the package builder from the final
    report. source_base is only the Git base, never a clean-tree/source claim.
    This admits static DEV provenance only, not a runtime installer permission.
    """
    source_root=Path(source_root).absolute();evidence=Path(evidence).absolute()
    module=runpy.run_path(str(source_root/'scripts/package-abi2-controlled-dev.py'))
    module['B']['configure_source_root'](source_root)
    data, artifacts, provenance=module['DEV']['admit'](evidence,evidence_sha256,source_root)
    need=module['NEED']
    need(data['environment']['CARGO_PROFILE_RELEASE_STRIP']=='symbols'
         and 'FC_OWNED_REMOVAL_SCOPE_HEX'in data['removed_environment_keys'], 'Normal stripped default source without compiled test-removal scope')
    need(set(artifacts)=={'product-compile','lifecycle-compile','guard-library-compile'},'Exactly three normal artifacts')
    extent={role:module['extent'](raw,role=='guard-library-compile')for role,(_,raw)in artifacts.items()}
    rows={role:{'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'profileTest':False,'extent':extent[role]}for role,(path,raw)in artifacts.items()}
    return dict(status='PASS_NORMAL_GNU_ABI2_DEV_SOURCE_AND_THREE_ARTIFACTS_ONLY',source_root=str(source_root),baseGit=data['source_head'],sourceEvidenceSha256=evidence_sha256,sourceInventory=provenance['source_inventory_sha256'],sourceInputCount=provenance['current_inputs_verified'],target='i686-pc-windows-gnu',formalCI=False,normalProfileTest=False,normalArtifacts=rows,builder={'path':str(source_root/'scripts/package-abi2-controlled-dev.py'),'sha256':hashlib.sha256((source_root/'scripts/package-abi2-controlled-dev.py').read_bytes()).hexdigest()},Windows='NOT_RUN',runtimeAuthority='NOT_GRANTED')
