"""Pure ABI2 DEV authoring/PE-boundary rejections; no compiler or MSI execution."""
from pathlib import Path
import runpy
import struct
import unittest
import xml.etree.ElementTree as ET
HERE = Path(__file__).resolve().parent
D = runpy.run_path(str(HERE/'package-abi2-controlled-dev.py'))
F = runpy.run_path(str(HERE/'test-installer-carrier-format.py'))

class Abi2DevTests(unittest.TestCase):
    def test_authoring_adds_exact_third_binary_and_explicit_package(self):
        raw = D['authoring']('0.1.0', sorted(D['B']['LIFECYCLE_REQUIRED']), '12345678-1234-1234-1234-123456789ABC')
        root = ET.fromstring(raw); ns = '{'+D['B']['WIX_NS']+'}'; p=root.find(ns+'Product')
        self.assertEqual(p.find(ns+'Package').get('Id'), '12345678-1234-1234-1234-123456789ABC')
        rows={x.get('Id'):x.get('SourceFile')for x in p.findall(ns+'Binary')}
        self.assertEqual(set(rows),set(D['BINARY_NAMES']))
        self.assertEqual(rows['FcPayloadManifest'],'lifecycle/payload-manifest.bin')
        self.assertFalse(p.findall(ns+'MsiEmbeddedChainer'))
    def test_package_identity_cannot_be_arbitrary_text(self):
        for value in ('', 'x', '12345678-1234-1234-1234-123456789abc'):
            with self.assertRaises(ValueError):D['authoring']('0.1.0',[],value)
    def test_normal_extent_rejects_symbols_overlay_and_malformed_sections(self):
        pe=F['structural_pe']();self.assertTrue(D['extent'](pe)['parsedExtentEqualsFileLength'])
        for raw in (pe+b'COFFTAIL',pe[:-1]):
            with self.assertRaises(ValueError):D['extent'](raw)
        raw=bytearray(pe);struct.pack_into('<II',raw,140,1024,1)
        with self.assertRaises(ValueError):D['extent'](bytes(raw))
        raw=bytearray(pe);struct.pack_into('<II',raw,392,512,1024)
        with self.assertRaises(ValueError):D['extent'](bytes(raw))
    def test_final_contract_requires_exact_v2_binary_before_shared_structural_checks(self):
        for rows in ([],['FcControlledGuardDll','FcGuardClientTemplate'],list(D['BINARY_NAMES'])+['Extra']):
            raw=('Name\tData\r\ns72\tv0\r\nBinary\tName\r\n'+''.join(x+'\tBinary.'+x+'\r\n'for x in rows)).encode()
            with self.assertRaises(ValueError):D['validate_contract'](b'',{'Binary':raw},'0.1.0',{},'12345678-1234-1234-1234-123456789ABC')

if __name__=='__main__':unittest.main()
