from pathlib import Path
import ast,hashlib,json,subprocess,difflib,runpy
R=Path('/tmp/fc-round80-controlled-repair');P=Path(__file__).resolve().parent;W=R/'checkout-abi2-ca-diagnostic-second';Q=R/'abi2-ca-diagnostic-runtime-preparation-first';O=R/'abi2-ca-diagnostic-producer-second';K=R/'abi2-ca-diagnostic-package-third'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def row(p,base):return dict(path=p.relative_to(base).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
def freeze(d):
 f=d/'freeze-first.json';assert not f.exists();x=dict(files=[row(p,d)for p in sorted(d.rglob('*'))if p.is_file()]);f.write_text(json.dumps(x,indent=2)+'\n');return dict(path=str(f),sha256=sha(f),files=len(x['files']))
normal=R/'checkout-abi2-maintenance-dev-package-first';before=json.loads((O/'report.json').read_bytes())['sourceBefore'];actual=[row(p,W)for p in sorted(W.rglob('*'))if p.is_file()and p.name!='.owner'];assert [dict(path=x['path'],bytes=x['bytes'],sha256=x['sha256'])for x in before]==actual
allowed={'crates/fc-windows/Cargo.toml','crates/fc-windows/src/installer_lifecycle/native/inner_guard.rs','crates/fc-windows/src/installer_lifecycle/native/inner_guard/abi2.rs','crates/fc-windows/src/installer_lifecycle/native/inner_guard/diagnostic.rs'}
old=json.loads((R/'abi2-maintenance-dev-normal-producer-first/inputs-before.json').read_bytes());print(type(old).__name__)
# Original producer's input rows use path relative to its actual source root.
if isinstance(old,dict):old=old.get('files',old.get('inputs',old))
changes=[];diff=[]
for x in before:
 q=W/x['path'];n=normal/x['path']
 if not n.exists()or sha(q)!=sha(n):
  assert x['path']in allowed;changes.append(x['path']);diff.extend(difflib.unified_diff(n.read_text().splitlines(True)if n.exists()else[],q.read_text().splitlines(True),fromfile='normal/'+x['path'],tofile='diagnostic/'+x['path']))
assert set(changes)==allowed
(P/'diagnostic-source-delta.patch').write_text(''.join(diff));(P/'source-freeze-first.json').write_text(json.dumps(dict(sourceRoot=str(W),normalInputs=588,diagnosticInputs=len(actual),onlyChanged=changes,files=actual),indent=2)+'\n')
checks=[]
for d in [P,Q]:
 for p in d.glob('*.py'):ast.parse(p.read_bytes(),filename=str(p));checks.append(dict(path=str(p),AST='PASS'))
for script in [P/'build-diagnostic-first.py',P/'build-diagnostic-second.py',P/'derive-diagnostic-first.py',P/'derive-diagnostic-second.py',P/'derive-diagnostic-third.py',Q/'run-diagnostic.py']:
 p=subprocess.run(['python3',str(script)],stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert p.returncode==0 and json.loads(p.stdout)=={'status':'NOT_RUN'};checks.append(dict(path=str(script),defaultInertActualExit=p.returncode,stdout=p.stdout.decode(),stderr=p.stderr.decode()))
# Static native facts do not assert a Windows or an actual MSI runtime result.
r=dict(status='PASS_LOCAL_COMPILER_STATIC_DERIVATION_AND_INERT_SOURCE_CHECKS_ONLY',producerSha256=sha(O/'report.json'),packageSha256=sha(K/'report.json'),checks=checks,sourceChanges=changes,originalDefaultFeature=[],diagnosticFeature=['ca-stage-diagnostics','default'],normalProduct=False,normalGuardUntouched=True,noPermissionFromDiagnosticText=True,resources='ORIGINAL_ONE_CLAIM_64_TOTAL_HANDLE_LEDGER_NO_SECOND_OWNER_OR_WORKER',boundedObservation='ONE_REUSED_MSI_RECORD_MAX256',finalObserverClose='ACTUAL_CHECKED_BUT_NOT_SERIALIZED_AFTER_LAST_RECORD_CLOSE',finalClaimRelease='ACTUAL_CHECKED_NOT_SERIALIZED',oldEnd='UNKNOWN',oldPending='NOT_ACCESSED',Windows='NOT_RUN')
(P/'local-checks-first.json').write_text(json.dumps(r,indent=2)+'\n')
(Q/'execution-plan-first.json').write_text(json.dumps(dict(scope='TEST_ONLY_DIRECT_INNER_EXPECTED1603',compileProducer=str(O/'report.json'),derivedPackage=str(K/'report.json'),PSAST=str(Q/'ps-ast-chunks-first.json'),execute=['python3',str(Q/'run-diagnostic.py'),'--execute','--preparation-freeze-sha256','<ACTUAL_FREEZE_SHA>','--output-dir',str(R/'abi2-ca-diagnostic-runtime-first')],WindowsExecutor='ROOT_ONLY',nativeClient150s=True,remote600s=True,outer900s=True,oldPending='NOT_ACCESSED',BeginEnd='NOT_CALLED_OLD_UNKNOWN_RETAINED',noGlobalCleanup=True),indent=2)+'\n')
for d in [O,K,Q,P]:print(json.dumps(freeze(d)))
