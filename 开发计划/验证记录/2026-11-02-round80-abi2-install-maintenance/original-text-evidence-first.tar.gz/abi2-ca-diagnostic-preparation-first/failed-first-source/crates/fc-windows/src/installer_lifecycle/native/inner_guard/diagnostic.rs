//! Explicit DEV-only observations. FCGD2 is never a grant or a settlement.
//! One record stays in the original GuardState MSI ledger until final cleanup.
use super::*;

impl GuardState {
    pub(super) fn diagnostic_begin(&mut self, install: MSIHANDLE) -> Result<()> {
        self.room(1)?;
        let record = self.register_msi(unsafe { MsiCreateRecord(1) }, false)?;
        self.diagnostic_record = Some(record);
        self.diagnostic_install = install; // borrowed invocation; never closed
        self.diagnostic_emit("run_start", "OK", 0, 0);
        Ok(())
    }
    pub(super) fn diagnostic_emit(
        &mut self,
        stage: &'static str,
        class: &str,
        code: u32,
        detail: u64,
    ) {
        let Some(record) = self.diagnostic_record else {
            self.diagnostic_failed = true;
            return;
        };
        if self.diagnostic_sequence >= 256 {
            self.diagnostic_failed = true;
            return;
        }
        self.diagnostic_sequence += 1;
        let value = format!(
            "FCGD2:seq={};stage={stage};class={class};code={code:08x};detail={detail}",
            self.diagnostic_sequence
        );
        let format = HSTRING::from("[1]");
        let text = HSTRING::from(value);
        let zero = unsafe { MsiRecordSetStringW(record, 0, &format) };
        let one = unsafe { MsiRecordSetStringW(record, 1, &text) };
        if zero != 0 || one != 0 {
            self.diagnostic_failed = true;
            return;
        }
        let ui = unsafe { MsiProcessMessage(self.diagnostic_install, INSTALLMESSAGE_INFO, record) };
        if ui < 0 {
            self.diagnostic_failed = true;
        }
        // UI values are observations only and never set nonce/grant/accepted.
    }
    pub(super) fn diagnostic_result<T>(&mut self, stage: &'static str, result: &Result<T>) {
        match result {
            Ok(_) => self.diagnostic_emit(stage, "OK", 0, 0),
            Err(LifecycleError::Native(code)) => {
                self.diagnostic_emit(stage, "NATIVE_HRESULT", code.0 as u32, 0)
            }
            Err(error) => self.diagnostic_emit(stage, &format!("{error:?}"), 0, 0),
        }
    }
    pub(super) fn diagnostic_api(&mut self, stage: &'static str, code: u32, detail: u64) {
        self.diagnostic_emit(stage, "MSI_RAW", code, detail);
    }
}
