from pathlib import Path
import hashlib,json,runpy,shutil,ast
R=Path('/tmp/fc-round80-controlled-repair');P=R/'abi2-ca-diagnostic-runtime-preparation-first';assert not P.exists();P.mkdir();(P/'.owner').write_text('future-classroom-owned-abi2-ca-diagnostic-runtime-preparation/v1\n')
old=runpy.run_path(str(R/'source-package-probe-runtime-preparation-first/run-probe.py'));path=R/'abi2-maintenance-product-runtime-preparation-first/sources'
for leaf in ['ProductState.ps1','ProductState.cs']:shutil.copyfile(path/leaf,P/leaf)
shutil.copyfile(R/'native-reference-first/Capture.cs',P/'Capture.cs')
common=old['COMMON'].replace('r80-source-package-probe-','r80-ca-diagnostic-').replace('r80-source-package-probe-runtime/','r80-ca-diagnostic-runtime/')
create=old['CREATE'].replace('r80-source-package-probe-','r80-ca-diagnostic-').replace('r80-source-package-probe-runtime/','r80-ca-diagnostic-runtime/')
delete=old['DELETE'].replace('SOURCE_PACKAGE_PROBE_RUNTIME_ROOT','CA_DIAGNOSTIC_RUNTIME_ROOT')
run=r'''
CheckRoot $c.root;$root=$c.root
foreach($x in $c.inputs){$f=Fact (Join-Path $root $x.name);if($f.bytes-ne$x.bytes-or$f.sha256-cne$x.sha256){throw 'INPUT_BYTES'}}
$clock=[Diagnostics.Stopwatch]::StartNew();$oldTemp=$env:TEMP;$oldTmp=$env:TMP;$capture=$null;$p=$null;$returned=$true
$r=@{status='FAIL_RETAIN';originalWholeSeconds=600;beginEnd='NOT_CALLED_NO_SETTLEMENT_INFERENCE';oldPending='NOT_OPENED_OR_CHANGED';noSetupOrGuardian=$true;cleanup='ROOT_DOWNLOAD_THEN_EXACT_DELETE_ONLY';originalClientSeconds=150}
try{
 $env:TEMP=Join-Path $root 'compiler-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP)
 Add-Type -Path (Join-Path $root 'Capture.cs') -ErrorAction Stop
 . (Join-Path $root 'ProductState.ps1')
 $r.before=Measure-FcProductState $c.product 'Absent'
 if(-not$r.before.knownAbsent-or-not$r.before.matchesExpected){throw 'PRODUCT_BEFORE_NOT_KNOWN_ABSENT'}
 $capture=[Fc79Capture]::new();$exe=Join-Path $root 'DirectDiagnostic.exe'
 $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$exe;$info.WorkingDirectory=$root;$info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
 $p=[Diagnostics.Process]::new();$p.StartInfo=$info
 $r.startedWholeMilliseconds=$clock.ElapsedMilliseconds;$r.originalDeadlineWholeMilliseconds=[Math]::Min(600000,$r.startedWholeMilliseconds+150000)
 if(-not$p.Start()){throw 'START'};$returned=$false;$r.pid=$p.Id;$r.creation=$p.StartTime.ToUniversalTime().ToFileTimeUtc()
 $stdout=$p.StandardOutput.ReadToEndAsync();$stderr=$p.StandardError.ReadToEndAsync()
 $r.original=$capture.HoldStartedClient($p.Handle,[uint32]$p.Id,[long]$r.creation,$exe,$c.exeSha,$c.sid)
 [IO.File]::WriteAllText((Join-Path $root 'capture-ack'),"FCGD2-CAPTURED`r`n",[Text.UTF8Encoding]::new($false))
 $left=[int]($r.originalDeadlineWholeMilliseconds-$clock.ElapsedMilliseconds)
 if($left-le0-or-not$p.WaitForExit($left)){throw 'ORIGINAL_CLIENT_UNKNOWN_NO_KILL'}
 $returned=$true;$p.Refresh();$r.actualExit=$true;$r.exitCode=$p.ExitCode
 if(-not[Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($stdout,$stderr),[int][Math]::Max(0,$r.originalDeadlineWholeMilliseconds-$clock.ElapsedMilliseconds))){throw 'ORIGINAL_PIPES_UNKNOWN'}
 $r.stdout=$stdout.Result;$r.stderr=$stderr.Result;[void]$capture.Snapshot()
 if($r.original.Wait-ne0-or-not$r.original.ExitKnown-or$r.original.ExitCode-ne$r.exitCode){throw 'ORIGINAL_CLIENT_RETURN_MISMATCH'}
 $p.Dispose();$p=$null;$r.endedWholeMilliseconds=$clock.ElapsedMilliseconds
 $r.after=Measure-FcProductState $c.product 'Absent'
 if(-not$r.after.knownAbsent-or-not$r.after.matchesExpected){throw 'PRODUCT_AFTER_NOT_KNOWN_ABSENT'}
 if($r.exitCode-ne0){throw 'DIAGNOSTIC_EXPECTATION_FAILED_RETAIN'}
 if($r.endedWholeMilliseconds-gt$r.originalDeadlineWholeMilliseconds){throw 'ORIGINAL_CLIENT_DEADLINE_EXCEEDED'}
 $r.status='PASS_DIRECT_INNER_EXPECTED_REJECTION_OBSERVATION_ONLY'
}catch{$r.error=$_.Exception.Message}finally{
 $env:TEMP=$oldTemp;$env:TMP=$oldTmp
 if($null-ne$p-and$returned){$p.Dispose()}
 if($null-ne$capture){try{$r.originalObjects=@($capture.FinishAndClose())}catch{$r.status='FAIL_RETAIN';$r.closeError=$_.Exception.Message}}
 $r.originalParentReturned=$returned;$r.elapsedMilliseconds=$clock.ElapsedMilliseconds
 if($clock.ElapsedMilliseconds-ge600000){$r.status='FAIL_RETAIN';$r.budgetExceeded=$true}
 [IO.File]::WriteAllText((Join-Path $root 'native-result.json'),($r|ConvertTo-Json -Depth 45),[Text.UTF8Encoding]::new($false))
}
$r|ConvertTo-Json -Depth 45 -Compress
# Transport success is distinct from native diagnostic status. The root must
# download known-returned raw observations even on a diagnostic expectation FAIL.
'''
constants=dict(BOOT=old['BOOT'],COMMON=common,CREATE=create,RUN=run,OWNED=old['OWNED'],INVENTORY=old['INVENTORY'],DELETE=delete)
source='''"""Explicit test-only direct CA observation. Default inert. Root is sole Windows executor."""\nimport argparse,base64,hashlib,json,os,re,runpy,secrets,shutil,subprocess,time\nfrom pathlib import Path\nR=Path('/tmp/fc-round80-controlled-repair')\n'''
for k,v in constants.items():source+=k+'='+repr(v)+'\n'
source+='\n'+(R/'abi2-ca-diagnostic-preparation-first/runtime-body.py').read_text();ast.parse(source);(P/'run-diagnostic.py').write_text(source)
chunks=[dict(name=k,script=common+v)for k,v in constants.items()if k in ['CREATE','RUN','OWNED','INVENTORY','DELETE']]
(P/'ps-ast-chunks-first.json').write_text(json.dumps(chunks,indent=2)+'\n')
