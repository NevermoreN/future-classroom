"""Explicit observation-feature CA DLL only. Default inert. No Git/Windows."""
from pathlib import Path
import argparse,json,hashlib,os,subprocess,time,signal,shutil
R=Path('/tmp/fc-round80-controlled-repair');W=R/'checkout-abi2-ca-diagnostic-first';O=R/'abi2-ca-diagnostic-producer-first';T=R/'abi2-ca-diagnostic-target-first'
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def inv():return [dict(path=str(p.relative_to(W)),bytes=p.stat().st_size,sha256=digest(p))for p in sorted(W.rglob('*'))if p.is_file()and p.name!='.owner']
def main():
 a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');v=a.parse_args()
 if not v.execute:print('{"status":"NOT_RUN"}');return
 assert not O.exists();O.mkdir();(O/'.owner').write_text('future-classroom-owned-abi2-ca-diagnostic-producer/v1\n');before=inv();(O/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
 env=os.environ.copy()
 for k in list(env):
  if k.startswith('FC_OWNED_REMOVAL'):del env[k]
 env.pop('CARGO_ENCODED_RUSTFLAGS',None);scoped=dict(CARGO_TARGET_DIR=str(T),CARGO_BUILD_JOBS='2',CARGO_PROFILE_RELEASE_STRIP='symbols',CARGO_TARGET_I686_PC_WINDOWS_GNU_LINKER='i686-w64-mingw32-gcc',RUSTFLAGS='-C target-feature=+crt-static -C link-arg=-Wl,--major-subsystem-version,6,--minor-subsystem-version,1');env.update(scoped)
 r=dict(status='STARTED_DIAGNOSTIC_NOT_NORMAL',sourceRoot=str(W),sourceKind='EXACT_NORMAL588_OWNED_COPY_PLUS_EXPLICIT_OBSERVER_FEATURE_NO_GIT',sourceBefore=before,environment=scoped,normalArtifact=False,Windows='NOT_RUN',commands=[])
 def fact(p):p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=digest(p))
 def save():(O/'report.json').write_text(json.dumps(r,indent=2)+'\n')
 save()
 for name,argv in [('metadata',['cargo','metadata','--locked','--offline','--no-deps','--format-version','1']),('default-check',['cargo','check','--locked','--offline','--release','--target','i686-pc-windows-gnu','-p','fc-windows','--lib']),('diagnostic-build',['cargo','build','--locked','--offline','--release','--target','i686-pc-windows-gnu','-p','fc-windows','--lib','--features','ca-stage-diagnostics','--message-format=json']),('diagnostic-clippy',['cargo','clippy','--locked','--offline','--release','--target','i686-pc-windows-gnu','-p','fc-windows','--lib','--features','ca-stage-diagnostics','--','-D','warnings'])]:
  start=time.monotonic();p=subprocess.Popen(argv,cwd=W,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);timed=False
  try:so,se=p.communicate(timeout=900)
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(p.pid,signal.SIGTERM)
   try:so,se=p.communicate(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);so,se=p.communicate()
  (O/(name+'.stdout.log')).write_bytes(so);(O/(name+'.stderr.log')).write_bytes(se);r['commands'].append(dict(name=name,argv=argv,actualExit=p.returncode,parentReaped=True,timedOut=timed,seconds=time.monotonic()-start,stdout=fact(O/(name+'.stdout.log')),stderr=fact(O/(name+'.stderr.log'))));save()
  if p.returncode or timed:r['status']='FAIL_RETAIN_ORIGINALS';save();print(se.decode()[-6000:]);raise SystemExit(1)
  if name=='diagnostic-build':
   messages=[json.loads(line)for line in so.splitlines()if line.startswith(b'{')];selected=[x for x in messages if x.get('reason')=='compiler-artifact'and x.get('target',{}).get('name')=='fc_windows'];assert len(selected)==1 and selected[0]['profile']['test'] is False and selected[0]['features']==['ca-stage-diagnostics','default'];m=selected[0];original=Path(next(p for p in m['filenames']if Path(p).name=='fc_windows.dll'));assert original==T/'i686-pc-windows-gnu/release/fc_windows.dll';copy=O/'fc_windows_diagnostic.dll';shutil.copyfile(original,copy);r.update(compilerArtifact=m,diagnosticDll=fact(copy),originalCompilerDll=fact(original));save()
  assert inv()==before;print(name,p.returncode,flush=True)
 after=inv();assert after==before;r.update(status='PASS_EXPLICIT_FEATURE_DIAGNOSTIC_CA_COMPILER_ONLY_NOT_NORMAL_NOT_NATIVE',sourceAfter=after,sourceUnchanged=True);save();print(json.dumps(dict(status=r['status'],report=fact(O/'report.json'))))
if __name__=='__main__':main()
