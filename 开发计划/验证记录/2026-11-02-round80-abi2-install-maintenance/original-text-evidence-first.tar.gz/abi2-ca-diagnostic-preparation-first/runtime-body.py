def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fact(p):
 p=Path(p);assert p.is_file()and not p.is_symlink();return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def checkfreeze(prep,pin):
 f=prep/'freeze-first.json';assert sha(f)==pin;x=json.loads(f.read_bytes());files={p.relative_to(prep).as_posix()for p in prep.rglob('*')if p.is_file()};assert files=={r['path']for r in x['files']}|{'freeze-first.json'}
 for row in x['files']:assert fact(prep/row['path'])==dict(path=str(prep/row['path']),bytes=row['bytes'],sha256=row['sha256'])
 return fact(f)
def qualify(native):
 assert native['status']=='PASS_DIRECT_INNER_EXPECTED_REJECTION_OBSERVATION_ONLY'and native['originalParentReturned']and native['actualExit']and native['exitCode']==0
 assert native['before']['knownAbsent']and native['after']['knownAbsent']and native['before']['matchesExpected']and native['after']['matchesExpected']
 assert len(native['originalObjects'])==1 and all(x['CheckedClose']and x['Wait']==0 and x['ExitKnown']and x['ExitCode']==0 for x in native['originalObjects'])
 assert native['original']['CheckedClose']and native['original']['Wait']==0 and native['original']['ExitKnown']and native['original']['ExitCode']==0
 stdout=native['stdout'];matches=re.findall(r'^FC_DIRECT_RESULT (\{[^\r\n]+\})\r?$',stdout,re.M);assert len(matches)==1;x=json.loads(matches[0]);assert x['expectedNegative']and x['installReturn']==1603 and x['logEnable']==x['uiSet']==x['uiUnset']==x['logDisable']==0 and x['previousNull']and x['removedOwnCallback']and x['restoredPreviousUi']and x['callbackOk']and x['initializeCount']==0 and not x['borrowedRecordClosed']and x['beginEnd']=='NOT_CALLED'
 rows=re.findall(r'^FC_DIRECT_OBSERVATION pid=(\d+) tid=(\d+) originalTid=(\d+) record=(\d+) field1rc=(\d+) FCGD2:seq=(\d+);stage=([a-zA-Z0-9_]+);class=([^;\r\n]+);code=([0-9a-f]{8});detail=(\d+)\r?$',stdout,re.M)
 assert len(rows)==x['diagnosticCount']and 0<len(rows)<=256
 observations=[]
 for index,row in enumerate(rows,1):
  pid,tid,original,record,rc,seq,stage,cl,code,detail=row;assert int(pid)==native['pid']and int(record)>0 and int(rc)==0 and int(seq)==index
  observations.append(dict(sequence=index,stage=stage,errorClass=cl,codeHex=code,detail=int(detail),pid=int(pid),tid=int(tid),originalTid=int(original),borrowedRecordClosed=False))
 assert observations[0]['stage']=='run_start'and observations[0]['errorClass']=='OK'
 assert len(re.findall(r'^FC_DIRECT_ACK_CLOSE ok=1 error=0\r?$',stdout,re.M))==1
 return dict(nativeResult=x,observations=observations,authority='NONE_DIAGNOSTIC_TEXT_ONLY',beginEnd='NOT_CALLED_OLD_END_STILL_UNKNOWN',productBeforeAfter='KNOWN_ABSENT',originalProcess='REAL_EXIT0_CHECKED_CLOSE')
def main():
 a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');a.add_argument('--validate-inputs-only',action='store_true');a.add_argument('--preparation-freeze-sha256');a.add_argument('--output-dir',type=Path);v=a.parse_args()
 if not v.execute and not v.validate_inputs_only:print('{"status":"NOT_RUN"}');return
 assert not(v.execute and v.validate_inputs_only);prep=Path(__file__).resolve().parent;pf=checkfreeze(prep,v.preparation_freeze_sha256)
 pr=R/'abi2-ca-diagnostic-package-third/report.json';assert sha(pr)=='e28704559d9c95425a34488e9d07a68f28852571957efdb74082d87811c18e92';pkg=json.loads(pr.read_bytes());assert pkg['status']=='PASS_TEST_ONLY_CA_STREAM_REPLACEMENT_STATIC_NOT_NATIVE'and pkg['allTablesExact']and pkg['allSummaryExact']and pkg['allOtherStreamsExact']and pkg['all14PayloadsExact']and pkg['guardOnlyChanged']and pkg['canonicalUnchanged']
 msi=Path(pkg['msi']['path']);exe=Path(pkg['directObserver']['path']);assert fact(msi)==pkg['msi']and fact(exe)==pkg['directObserver']
 producer=Path(pkg['diagnosticProducer']['path']);assert fact(producer)==pkg['diagnosticProducer'];pdoc=json.loads(producer.read_bytes());assert pdoc['sourceUnchanged']and pdoc['sourceBefore']==pdoc['sourceAfter']and pdoc['status']=='PASS_EXPLICIT_FEATURE_DIAGNOSTIC_CA_COMPILER_ONLY_NOT_NORMAL_NOT_NATIVE'
 normalfile=R/'abi2-maintenance-product-runtime-preparation-first/inputs/artifact-manifest.json';assert sha(normalfile)=='c5377c6378d70fc1cab1a5ffbe24a226ee3e7ad59166a7fecdd244e60b7620b5';product=json.loads(normalfile.read_bytes());assert product['payloads']==[{k:x[k]for k in ['path','size','sha256','component_guid']}for x in pkg['payloads']]
 product.update(registryMarkerKey='Software\\FutureClassroom\\Installer\\Components',runKey='Software\\Microsoft\\Windows\\CurrentVersion\\Run',runValue='FutureClassroom',registryView='Registry32',fixedDestinationKnownFolderSuffix=['Programs','FutureClassroom'])
 def verify():checkfreeze(prep,v.preparation_freeze_sha256);assert fact(msi)==pkg['msi']and fact(exe)==pkg['directObserver']and fact(producer)==pkg['diagnosticProducer']and sha(pr)=='e28704559d9c95425a34488e9d07a68f28852571957efdb74082d87811c18e92'
 verify()
 if v.validate_inputs_only:print(json.dumps(dict(status='PASS_LOCAL_TEST_DIAGNOSTIC_INPUTS_ONLY_NATIVE_NOT_RUN',packageReport=fact(pr),diagnosticProducer=fact(producer),expectedNative1603=True,defaultOff=True,oldPending='NOT_ACCESSED',beginEnd='NOT_CALLED')));return
 assert v.output_dir==R/'abi2-ca-diagnostic-runtime-first'and not v.output_dir.exists();out=v.output_dir;out.mkdir();(out/'.owner').write_text('future-classroom-owned-abi2-ca-diagnostic-runtime-local/v1\n')
 c=dict(nonce=secrets.token_hex(16),sid='S-1-5-21-3896111207-1867804362-1971593122-1001',root=None,exeSha=pkg['directObserver']['sha256'],product=product)
 r=dict(status='STARTED_TEST_DIAGNOSTIC',scope='DIRECT_INNER_EXPECTED_NEGATIVE_OBSERVATION_NOT_NORMAL_NOT_RECOVERY',oldPending='NOT_OPENED_OR_CHANGED_BY_CONTROLLER',oldEnd='UNKNOWN',beginEnd='NOT_CALLED',packageReport=fact(pr),diagnosticProducer=fact(producer),preparationFreeze=pf,operations=[],cleanup='NOT_RUN',outerSeconds=900);start=time.monotonic()
 def save():(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
 def call(label,argv,feed=None,limit=30):
  begin=time.monotonic();left=900-(begin-start);assert left>0
  p=subprocess.Popen(argv,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE);timed=False
  try:so,se=p.communicate(feed,timeout=min(left,limit))
  except subprocess.TimeoutExpired:timed=True;p.kill();so,se=p.communicate()
  op=dict(name=label,argv=argv,actualExit=p.returncode,localOriginalReaped=True,remoteOriginalUnknown=timed,seconds=time.monotonic()-begin)
  for name,data in [('stdout',so),('stderr',se)]:q=out/(label+'.'+name+'.log');q.write_bytes(data);op[name]=fact(q)
  r['operations'].append(op);save();assert not timed and p.returncode==0,(label,p.returncode,'REMOTE_UNKNOWN_RETAIN'if timed else'ACTUAL_NONZERO');return so
 def remote(label,script,limit=30):
  feed=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+COMMON+script).encode();return call(label,['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','future-classroom-win11','powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(BOOT.encode('utf-16-le')).decode()],feed,limit)
 try:
  c['root']=json.loads(remote('create',CREATE))['root'];r['windowsRoot']=c['root'];save();upload=out/'upload';upload.mkdir()
  for src,leaf in [(msi,'FutureClassroom.msi'),(exe,'DirectDiagnostic.exe')]+[(prep/x,x)for x in ['Capture.cs','ProductState.cs','ProductState.ps1']]:shutil.copyfile(src,upload/leaf)
  c['inputs']=[dict(name=p.name,bytes=p.stat().st_size,sha256=sha(p))for p in sorted(upload.iterdir())]
  for p in sorted(upload.iterdir()):call('upload-'+p.name,['scp','-q','-o','BatchMode=yes',str(p),'future-classroom-win11:'+c['root'].replace('\\','/')+'/'],limit=60)
  native=json.loads(remote('run',RUN,600));r['native']=native;save()
  # Even expectation failure is downloaded if the original client has really
  # returned and its original cap is checked closed. No rerun or kill.
  assert native['originalParentReturned']and len(native['originalObjects'])==1 and all(x['CheckedClose']and x['Wait']==0 and x['ExitKnown']for x in native['originalObjects'])
  owned=json.loads(remote('owned-processes',OWNED));r['ownedProcessReadback']=owned;assert owned['count']==0
  inv=json.loads(remote('inventory',INVENTORY));r['inventory']=inv;save()
  for x in c['inputs']:
   same=[q for q in inv['files']if q['path']==x['name']];assert len(same)==1 and same[0]['bytes']==x['bytes']and same[0]['sha256']==x['sha256']
  down=out/'download';down.mkdir();call('download',['scp','-q','-r','-o','BatchMode=yes','future-classroom-win11:'+c['root'].replace('\\','/'),str(down)],limit=60);local=down/Path(c['root'].replace('\\','/')).name
  helper=R/'native-reference-first/run-negative-msi-r79-third.py';assert sha(helper)=='da74f0058deac86507b712075904556780be6b262b18acb82415da6725c6e202';runpy.run_path(str(helper))['verify_download'](local,inv);assert json.loads((local/'native-result.json').read_bytes())==native;r['downloadVerified']=True;r['downloadCounts']=dict(files=len(inv['files']),directories=len(inv['directories']));save()
  r['qualified']=qualify(native)
  raw=(local/'direct-msi.log').read_bytes();log=raw.decode('utf-16')if raw.startswith((b'\xff\xfe',b'\xfe\xff'))else raw.decode('utf-8-sig',errors='strict')
  assert re.search(r'Action ended[^\r\n]*FcControlledInnerGuard\. Return value 3\.',log)and not re.search(r'Action start[^\r\n]*InstallInitialize\.',log);r['actualLog']=dict(**fact(local/'direct-msi.log'),guardActionReturn3=True,installInitializeActionStart=False,diagnosticTextAuthority=False)
  verify();c['inventory']=inv;assert json.loads(remote('owned-processes-before-delete',OWNED))['count']==0;r['delete']=json.loads(remote('delete',DELETE));assert r['delete']['knownAbsent'];r['cleanup']='PASS_EXACT_NEW_OWNED_SCRATCH_ONLY';r['status']='PASS_EXPECTED_DIRECT_INNER_1603_STAGE_OBSERVATIONS_WIN11_ONLY_NOT_INSTALL_SUCCESS'
 except Exception as e:r.update(status='FAIL_RETAIN_ORIGINALS',errorType=type(e).__name__,error=str(e))
 r['elapsedSeconds']=time.monotonic()-start
 if r['elapsedSeconds']>=900:r['status']='FAIL_ORIGINAL_OUTER_BUDGET_EXCEEDED'
 try:verify();r['inputsUnchanged']=True
 except Exception:r['status']='FAIL_FROZEN_INPUT_CHANGED';r['inputsUnchanged']=False
 save();print(json.dumps(dict(status=r['status'],report=fact(out/'report.json'),error=r.get('error'))));raise SystemExit(0 if r['status'].startswith('PASS_')else 1)
if __name__=='__main__':main()
