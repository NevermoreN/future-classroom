#define UNICODE
#define _UNICODE
#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0601
#include <windows.h>
#include <msi.h>
#include <msiquery.h>
#include <stdio.h>
#include <wchar.h>
#include <string.h>
/* DEV observation only: fixed siblings, no Setup/B/G, no Pending or registry API.
 * Borrowed external-UI hRecord is never closed. INFO is never a grant. */
static CRITICAL_SECTION lock;
static unsigned observed, initialize_count;
static BOOL callback_ok=TRUE;
static DWORD original_tid;
static int WINAPI callback(LPVOID context,UINT kind,MSIHANDLE record) {
    (void)context;
    WCHAR text[512]={0};DWORD length=512;
    UINT rc=MsiRecordGetStringW(record,1,text,&length);
    EnterCriticalSection(&lock);
    if(kind==INSTALLMESSAGE_ACTIONSTART && rc==0 && wcscmp(text,L"InstallInitialize")==0) initialize_count++;
    if(kind==INSTALLMESSAGE_INFO && rc==0 && wcsncmp(text,L"FCGD2:",6)==0) {
        if(length>=512 || observed>=256)callback_ok=FALSE;
        else {
            char ascii[512];BOOL good=TRUE;
            for(DWORD i=0;i<length;i++){if(text[i]<32||text[i]>126){good=FALSE;break;}ascii[i]=(char)text[i];}
            if(good){ascii[length]=0;printf("FC_DIRECT_OBSERVATION pid=%lu tid=%lu originalTid=%lu record=%lu field1rc=%u %s\n",GetCurrentProcessId(),GetCurrentThreadId(),original_tid,(unsigned long)record,rc,ascii);fflush(stdout);observed++;}else callback_ok=FALSE;
        }
    }
    LeaveCriticalSection(&lock);
    return IDOK; /* Fixed message handling, never authorization. */
}
static BOOL path(WCHAR *out,const WCHAR *leaf) {
    DWORD n=GetModuleFileNameW(NULL,out,1024);if(n==0||n>=1024)return FALSE;
    WCHAR *slash=wcsrchr(out,L'\\');if(!slash)return FALSE;slash[1]=0;
    return wcslen(out)+wcslen(leaf)<1024 && wcscat(out,leaf)!=NULL;
}
static BOOL wait_capture(void){
    WCHAR p[1024];if(!path(p,L"capture-ack"))return FALSE;
    ULONGLONG start=GetTickCount64();
    while(GetTickCount64()-start<3000){
        HANDLE h=CreateFileW(p,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_FLAG_OPEN_REPARSE_POINT,NULL);
        if(h!=INVALID_HANDLE_VALUE){char b[32]={0};DWORD n=0;BY_HANDLE_FILE_INFORMATION i;
            BOOL good=GetFileInformationByHandle(h,&i)&&!(i.dwFileAttributes&(FILE_ATTRIBUTE_REPARSE_POINT|FILE_ATTRIBUTE_DIRECTORY))&&i.nNumberOfLinks==1&&ReadFile(h,b,sizeof(b),&n,NULL)&&n==16&&memcmp(b,"FCGD2-CAPTURED\r\n",16)==0;
            BOOL closed=CloseHandle(h);printf("FC_DIRECT_ACK_CLOSE ok=%u error=%lu\n",closed?1U:0U,closed?0UL:GetLastError());fflush(stdout);return good&&closed;
        }
        DWORD e=GetLastError();if(e!=ERROR_FILE_NOT_FOUND&&e!=ERROR_PATH_NOT_FOUND)return FALSE;Sleep(5);
    }return FALSE;
}
int main(void){
    WCHAR msi[1024],log[1024];original_tid=GetCurrentThreadId();InitializeCriticalSection(&lock);
    if(!path(msi,L"FutureClassroom.msi")||!path(log,L"direct-msi.log")||!wait_capture()){DeleteCriticalSection(&lock);return 70;}
    INSTALLUILEVEL old=MsiSetInternalUI(INSTALLUILEVEL_NONE,NULL);
    UINT logrc=MsiEnableLogW(INSTALLLOGMODE_FATALEXIT|INSTALLLOGMODE_ERROR|INSTALLLOGMODE_WARNING|INSTALLLOGMODE_USER|INSTALLLOGMODE_INFO|INSTALLLOGMODE_RESOLVESOURCE|INSTALLLOGMODE_OUTOFDISKSPACE|INSTALLLOGMODE_ACTIONSTART|INSTALLLOGMODE_ACTIONDATA|INSTALLLOGMODE_COMMONDATA|INSTALLLOGMODE_PROPERTYDUMP|INSTALLLOGMODE_VERBOSE,log,INSTALLLOGATTRIBUTES_APPEND|INSTALLLOGATTRIBUTES_FLUSHEACHLINE);
    INSTALLUI_HANDLER_RECORD prev=NULL,removed=NULL;
    UINT setrc=MsiSetExternalUIRecord(callback,INSTALLLOGMODE_INFO|INSTALLLOGMODE_ACTIONSTART,NULL,&prev);
    UINT install=0xffffffffU;
    if(logrc==0&&setrc==0&&prev==NULL)install=MsiInstallProductW(msi,L"REBOOT=ReallySuppress MSIRESTARTMANAGERCONTROL=DisableShutdown");
    UINT unset=MsiSetExternalUIRecord(NULL,0,NULL,&removed);
    UINT logoff=MsiEnableLogW(0,NULL,0);
    INSTALLUILEVEL restored=MsiSetInternalUI(old,NULL);
    BOOL good=logrc==0&&setrc==0&&prev==NULL&&install==1603&&unset==0&&removed==callback&&logoff==0&&restored==INSTALLUILEVEL_NONE&&callback_ok&&observed>0&&initialize_count==0;
    printf("FC_DIRECT_RESULT {\"logEnable\":%u,\"uiSet\":%u,\"previousNull\":%s,\"installReturn\":%u,\"uiUnset\":%u,\"removedOwnCallback\":%s,\"logDisable\":%u,\"restoredPreviousUi\":%s,\"diagnosticCount\":%u,\"initializeCount\":%u,\"callbackOk\":%s,\"expectedNegative\":%s,\"beginEnd\":\"NOT_CALLED\",\"borrowedRecordClosed\":false}\n",logrc,setrc,prev==NULL?"true":"false",install,unset,removed==callback?"true":"false",logoff,restored==INSTALLUILEVEL_NONE?"true":"false",observed,initialize_count,callback_ok?"true":"false",good?"true":"false");
    fflush(stdout);DeleteCriticalSection(&lock);return good?0:71;
}
