"""DEV-only direct-inner diagnostic MSI. Only guard Binary stream changes. Inert by default."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,time
R=Path('/tmp/fc-round80-controlled-repair');P=Path(__file__).resolve().parent;O=R/'abi2-ca-diagnostic-package-third'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fact(p):p=Path(p);assert p.is_file()and not p.is_symlink();return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def main():
 a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');v=a.parse_args()
 if not v.execute:print('{"status":"NOT_RUN"}');return
 toolsfile=R/'inner-guard-probe-tools-first/tools.json';envfile=toolsfile.parent/'child-environment.json'
 assert sha(toolsfile)=='d82866321cc565890c38b494f7dd2ae6afa2fed8d4ae55270d7c4e931562099d'and sha(envfile)=='d0b2d946aba5c21d94713c6e17cfa90a5c85c74dfa00d2336d4cbf88f05b37a0'
 tools=json.loads(toolsfile.read_bytes());env=os.environ.copy();env.update(json.loads(envfile.read_bytes()))
 for t in tools.values():assert sha(t['path'])==t['sha256']
 original_report=R/'abi2-maintenance-dev-product-package-first/report.json';assert sha(original_report)=='7876e08aaf32827ac3d4f413732eee7c8857e93bc7a2b1e87685853e63b9481e';canonical=json.loads(original_report.read_bytes());source=original_report.parent/canonical['msi']['path'];assert sha(source)=='738d12561c539626332982b23ea36ee45c753d1379264f0ba98a3fa25d88a036'
 producer=R/'abi2-ca-diagnostic-producer-second/report.json';assert sha(producer)=='b67fd099cf5f69403693c7b99eb3a1775f36e9908c5210efa0e8ed61ef71427b';pr=json.loads(producer.read_bytes());assert pr['status']=='PASS_EXPLICIT_FEATURE_DIAGNOSTIC_CA_COMPILER_ONLY_NOT_NORMAL_NOT_NATIVE' and pr['sourceBefore']==pr['sourceAfter']and pr['sourceUnchanged'];dll=Path(pr['diagnosticDll']['path']);assert fact(dll)==pr['diagnosticDll']
 assert not O.exists();O.mkdir();(O/'.owner').write_text('future-classroom-owned-abi2-ca-diagnostic-package/v1\n');msi=O/'FutureClassroom.msi';shutil.copyfile(source,msi)
 r=dict(status='STARTED_TEST_DERIVATION',normalProduct=False,formalCI=False,Windows='NOT_RUN',purpose='DIRECT_INNER_EXPECTED_1603_OBSERVATION_ONLY_NO_TRANSACTION_OR_RECOVERY_AUTHORITY',canonicalReport=fact(original_report),canonicalMsi=fact(source),diagnosticProducer=fact(producer),diagnosticDll=fact(dll),commands=[])
 def save():(O/'report.json').write_text(json.dumps(r,indent=2)+'\n')
 def call(label,argv,cwd=O):
  start=time.monotonic();p=subprocess.run([str(x)for x in argv],env=env,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120);so=O/(label+'.stdout.log');se=O/(label+'.stderr.log');so.write_bytes(p.stdout);se.write_bytes(p.stderr);r['commands'].append(dict(name=label,argv=[str(x)for x in argv],actualExit=p.returncode,reaped=True,seconds=time.monotonic()-start,stdout=fact(so),stderr=fact(se)));save();assert p.returncode==0,(label,p.stderr.decode(errors='replace'));return p.stdout
 def info(label,which,*args):return call(label,[tools['msiinfo']['path'],which,*args])
 try:
  tables=info('before-tables','tables',source).decode().splitlines();streams=info('before-streams','streams',source).decode().splitlines();assert 'Binary.FcControlledGuardDll'in streams and len(set(streams))==len(streams)
  oldsummary=info('before-summary','suminfo',source);oldtables={t:info('before-table-'+str(i),'export',source,t)for i,t in enumerate(tables)}
  oldstreams={s:info('before-stream-'+str(i),'extract',source,s)for i,s in enumerate(streams)}
  call('replace-only-guard',[tools['msibuild']['path'],msi,'-a','Binary.FcControlledGuardDll',dll])
  assert info('after-tables','tables',msi).decode().splitlines()==tables and info('after-streams','streams',msi).decode().splitlines()==streams
  assert info('after-summary','suminfo',msi)==oldsummary
  for i,t in enumerate(tables):assert info('after-table-'+str(i),'export',msi,t)==oldtables[t],t
  unchanged=[]
  for i,s in enumerate(streams):
   value=info('after-stream-'+str(i),'extract',msi,s)
   if s=='Binary.FcControlledGuardDll':assert value==dll.read_bytes()
   else:assert value==oldstreams[s],s;unchanged.append(dict(stream=s,bytes=len(value),sha256=hashlib.sha256(value).hexdigest()))
  dest=O/'extracted';dest.mkdir();call('extract-14',[tools['msiextract']['path'],'-C',dest,msi]);files={q.relative_to(dest).as_posix():q for q in dest.rglob('*')if q.is_file()};assert len(files)==14
  payloads=[]
  for x in canonical['payloads']:
   matches=[q for rel,q in files.items()if rel=='Programs/FutureClassroom/'+x['path']];assert len(matches)==1;f=fact(matches[0]);assert f['bytes']==x['size']and f['sha256']==x['sha256'];payloads.append(dict(**x,extracted=f))
  # Explicit diagnostic launcher is auxiliary test code, never normal helper.
  exe=O/'DirectDiagnostic.exe';call('compile-direct-observer',[tools['gcc']['path'],'-std=c11','-Os','-Wall','-Wextra','-Werror','-municode' if False else '-mconsole',P/'DirectDiagnostic.c','-o',exe,'-Wl,--major-subsystem-version,6,--minor-subsystem-version,1','-lmsi'])
  exports=call('diagnostic-dll-exports',[tools['objdump']['path'],'-p',dll]);assert b'FcControlledInnerGuard'in exports
  r.update(status='PASS_TEST_ONLY_CA_STREAM_REPLACEMENT_STATIC_NOT_NATIVE',msi=fact(msi),directObserver=fact(exe),directObserverSource=fact(P/'DirectDiagnostic.c'),allTablesExact=True,allSummaryExact=True,allOtherStreamsExact=True,unchangedStreams=unchanged,guardOnlyChanged=True,payloads=payloads,all14PayloadsExact=True,setup='NOT_DERIVED_CHANGED_MSI_INTENTIONALLY_HAS_NO_SEALED_SETUP',packageCode=canonical['packageCode'],oldPending='NOT_ACCESSED',canonicalUnchanged=sha(source)==r['canonicalMsi']['sha256']);save()
 except BaseException as e:r.update(status='FAIL_RETAIN_ORIGINALS',errorType=type(e).__name__,error=str(e));save();raise
 print(json.dumps(dict(status=r['status'],report=fact(O/'report.json'))))
if __name__=='__main__':main()
