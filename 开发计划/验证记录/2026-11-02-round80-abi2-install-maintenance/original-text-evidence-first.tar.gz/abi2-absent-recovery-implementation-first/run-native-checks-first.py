from pathlib import Path
import os,subprocess,json,hashlib,time
R=Path('/tmp/fc-round80-controlled-repair');W=R/'checkout-abi2-absent-recovery-first';O=R/'abi2-absent-recovery-implementation-first';T=R/'abi2-absent-recovery-target-first'
files=['crates/fc-windows/src/installer_lifecycle/native/broker/controlled_owner/recovery.rs', 'crates/fc-windows/src/installer_lifecycle/native/broker/controlled_owner/recovery/scope.rs', 'crates/fc-windows/src/installer_lifecycle/native/broker/controlled_owner/recovery/absent.rs']
compilefiles=sorted([str(p.relative_to(W)) for p in (W/'crates').rglob('*') if p.is_file() and (p.suffix=='.rs' or p.name=='Cargo.toml')]+['.cargo/config.toml','Cargo.toml','Cargo.lock','rust-toolchain.toml'])
def inputs():return [dict(path=p,bytes=len((b:=(W/p).read_bytes())),sha256=hashlib.sha256(b).hexdigest())for p in compilefiles]
def inv():return [dict(path=p,bytes=len((b:=(W/p).read_bytes())),sha256=hashlib.sha256(b).hexdigest())for p in files]
r=dict(sourceBefore=inv(),compilerInputsBefore=inputs(),checks=[]);env=os.environ.copy();env['CARGO_TARGET_DIR']=str(T);env['CARGO_BUILD_JOBS']='2';env.pop('FC_OWNED_REMOVAL_SCOPE_HEX',None)
for name,cmd in [('gnu-check-first',['cargo','check','--locked','--offline','--target','i686-pc-windows-gnu','-p','fc-windows','--tests','--features','owned-test-removal']),('clippy-first',['cargo','clippy','--locked','--offline','--target','i686-pc-windows-gnu','-p','fc-windows','--tests','--features','owned-test-removal','--','-D','warnings']),('fmt-first',['rustfmt','--edition','2021','--check','--config','skip_children=true']+files),('architecture-first',['python3','scripts/check-architecture.py']),('diff-first',['git','diff','--check'])]:
 t=time.monotonic()
 with(O/(name+'.stdout.log')).open('xb')as so,(O/(name+'.stderr.log')).open('xb')as se:
  p=subprocess.Popen(cmd,cwd=W,env=env,stdout=so,stderr=se);exit=p.wait(timeout=900)
 r['checks'].append(dict(name=name,argv=cmd,actualExit=exit,parentReaped=True,seconds=time.monotonic()-t,targetDir=str(T)))
 if exit:break
r['compilerInputsAfter']=inputs();r['compilerInputsUnchanged']=r['compilerInputsBefore']==r['compilerInputsAfter'];r['sourceAfter']=inv();r['sourceUnchanged']=r['sourceBefore']==r['sourceAfter'];(O/'native-checks-first.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(dict(checks=r["checks"],sourceUnchanged=r["sourceUnchanged"],compilerInputsUnchanged=r["compilerInputsUnchanged"])))
