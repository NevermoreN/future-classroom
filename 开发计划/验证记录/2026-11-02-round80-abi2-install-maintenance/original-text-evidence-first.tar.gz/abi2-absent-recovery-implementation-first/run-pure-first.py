from pathlib import Path
import subprocess,json,hashlib,time
R=Path('/tmp/fc-round80-controlled-repair');W=R/'checkout-abi2-absent-recovery-first';O=R/'abi2-absent-recovery-implementation-first';B=W/'crates/fc-windows/src/installer_lifecycle'
def block(text,start):
 i=text.index(start);a=text.index('{',i);depth=1;j=a+1
 while depth:
  depth+=(text[j]=='{')-(text[j]=='}');j+=1
 return text[i:j]
scope=(B/'native/broker/controlled_owner/recovery/scope.rs').read_text();obj=block(scope,'impl ObjectId {');scope=scope.replace(obj,'').replace('use super::*;','use crate::installer_lifecycle::{LifecycleError,Result,INSTALL_FAMILY,broker::manifest::{self,Manifest}};\nconst MAX_PENDING_BYTES:usize=4096;')
co=(B/'native/broker/controlled_owner.rs').read_text();ab=(B/'native/broker/controlled_owner/recovery/absent.rs').read_text();msg=block(co,'struct Message {')+'\n'+block(co,'impl Message {');terminal=block(ab,'fn terminal(');test=block(ab,'fn empty_recovery_requires_')
source='mod installer_lifecycle {#[derive(Debug,PartialEq,Eq)]pub enum LifecycleError{Invalid,Unsettled} pub type Result<T>=std::result::Result<T,LifecycleError>;pub const INSTALL_FAMILY:&str="99378807-098D-5F04-8D4D-F181DFA218D5";pub mod broker {#[path='+json.dumps(str(B/'broker/manifest.rs'))+']pub mod manifest;}mod scope {\n'+scope+'\n}mod absent {use super::{LifecycleError,Result};const FRAME:usize=32;const HELLO:u8=1;const READY:u8=2;const BEGUN:u8=3;const RUN:u8=4;const INSTALLED:u8=5;const DECIDE:u8=6;const ENDED:u8=7;const ABORT:u8=8;#[derive(Clone,Copy)]'+msg+'\n'+terminal+'\n#[test]'+test+'\n}}'
wrapper=O/'pure-first.rs';exe=O/'pure-first';wrapper.write_text(source);rows=[]
try:
 for name,cmd in [('pure-compile-first',['rustc','--edition=2021','--test',str(wrapper),'-o',str(exe)]),('pure-tests-first',[str(exe),'--nocapture'])]:
  at=time.monotonic();p=subprocess.run(cmd,capture_output=True,timeout=60);(O/(name+'.stdout.log')).write_bytes(p.stdout);(O/(name+'.stderr.log')).write_bytes(p.stderr);rows.append(dict(name=name,argv=cmd,actualExit=p.returncode,parentReaped=True,seconds=time.monotonic()-at));
  if p.returncode:break
finally:
 (O/'pure-checks-first.json').write_text(json.dumps({'checks':rows,'scope':'Actual scope parser minus unrelated native ObjectId.matches; actual Message and terminal functions; no native return/ownership claim'},indent=2)+'\n');wrapper.unlink(missing_ok=True);exe.unlink(missing_ok=True)
print(json.dumps(rows))
