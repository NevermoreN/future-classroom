"""Fixed reviewed fixture binding only; normal/default builds do not consume this.
Default inert. Raw scope files must remain outside Git/archive and never printed.
"""
from pathlib import Path
import json,hashlib,base64,struct,sys
R=Path('/tmp/fc-round80-controlled-repair');O=Path(__file__).resolve().parent
EXPECTED={
 'runtime':(R/'abi2-maintenance-product-runtime-first/report.json','ce2c2c06782f03b160186335ace47ec25d33d201a400270878c580296bba82ef'),
 'package':(R/'abi2-maintenance-dev-product-package-first/report.json','7876e08aaf32827ac3d4f413732eee7c8857e93bc7a2b1e87685853e63b9481e'),
 'snapshot':(R/'abi2-pending-readonly-retrieval-first/report.json','9f8e75360e25e7d69bb537765c549a59a83279f15278fb944659ad6699b24ab9'),
}
def sha(b):return hashlib.sha256(b).hexdigest()
def ident(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def run():
 if sys.argv[1:]!=['--execute']:print(json.dumps(dict(status='NOT_RUN_DEFAULT_INERT',execute='python3 '+str(Path(__file__).resolve())+' --execute')));return
 docs={};ids={}
 for label,(p,expected) in EXPECTED.items():
  b=p.read_bytes();assert sha(b)==expected,(label,'hash');docs[label]=json.loads(b);ids[label]=ident(p)
 rt,pkg,retr=docs['runtime'],docs['package'],docs['snapshot'];cap=retr['originalNativeSnapshot']['capture']
 assert rt['status']=='FAIL_OR_UNKNOWN_RETAIN_ORIGINALS' and rt['phase']['ownerUnknown'] is False
 assert retr['downloadVerified'] is True and retr['cleanup']['knownAbsent'] is True and retr['oldProductGatePendingMutated'] is False
 assert cap['Status']=='PASS' and cap['Mutations'] is False and cap['SameHandleBytesEqual'] is True and cap['SameHandleMetadataEqual'] is True and cap['CloseUnknown'] is False
 pending=base64.b64decode(cap['BytesBase64'],validate=True);assert len(pending)==106 and sha(pending)=='aa9147aed1001da32245d015f6db094b18c4eb64c6e6f17fdf7dc900e6867498' and cap['ParsedOperationTag']==5
 phase=rt['phase']['phases'];assert len(phase)==1 and phase[0]['name']=='install'
 processes=phase[0]['observerFinal']['Processes'];selected=[]
 for role in ['setup-install','owned-guardian']:
  hits=[v for v in processes if v['Role']==role];assert len(hits)==1;v=hits[0]
  assert v['ActualWait']==0 and v['ActualExitCode']==1603 and v['CloseStatus']=='CHECKED_CLOSE_SUCCESS' and v['Sha256']==pkg['setup']['sha256'];selected.append(v)
 sid=cap['ParsedSid'];assert sid==rt['create']['sid']==selected[0]['Sid']==selected[1]['Sid']
 f=sid.split('-');assert f[:2]==['S','1'];authority=int(f[2]);sub=[int(v) for v in f[3:]];sidbytes=bytes([1,len(sub)])+authority.to_bytes(6,'big')+b''.join(struct.pack('<I',v)for v in sub)
 assert pending.endswith(sidbytes) and cap['PendingAclStatus']=='PASS_EXACT_OWNER_PROTECTED_DACL'
 for k in ['msi','setup']:
  p=R/'abi2-maintenance-dev-product-package-first'/pkg[k]['path'];assert ident(p)['sha256']==pkg[k]['sha256'] and ident(p)['bytes']==pkg[k]['bytes']
 envelope=(R/'abi2-maintenance-dev-product-package-first/lifecycle/payload-manifest.bin').read_bytes();assert sha(envelope)==pkg['payloadManifest']['sha256'];body=envelope[88:];assert sha(body)==pkg['payloadManifest']['rawBodySha256']
 # Reconstruct every FCLM73 record from the frozen package report, byte for byte.
 payload=sorted(pkg['payloads'],key=lambda v:v['path']);assert len(payload)==14
 m=b'FCLM73\0\0'+struct.pack('<HH',1,14)+pkg['productCode'].encode()+bytes([len(pkg['version'])])+pkg['version'].encode()
 for e in payload:
  name=e['path'].encode();m+=struct.pack('<H',len(name))+name+struct.pack('<I',e['size'])+bytes.fromhex(e['sha256'])+e['component_guid'].encode()
 assert m==body
 out=b'FC-OWNED-REMOVAL\0v2\0'+bytes([2])+b''.join(bytes.fromhex(ids[k]['sha256'])for k in ['runtime','package','snapshot'])+bytes.fromhex(pkg['setup']['sha256'])+struct.pack('<H',len(sidbytes))+sidbytes
 for key in ['RootBefore','GateBefore','PendingBefore']:
  v=cap[key];assert v['Links']==1;out+=struct.pack('<IQQ',int(v['Volume'],16),int(v['FileId'],16),int(v['CreationHex'],16))
 out+=struct.pack('<H',len(pending))+pending
 for v in selected:out+=struct.pack('<IQIIB',v['Pid'],v['CreationFiletime'],0,1603,1)
 out+=struct.pack('<I',len(body))+body
 assert len(out)<=40*1024;hexbytes=out.hex().encode();(O/'scope.bin').open('xb').write(out);(O/'scope.hex').open('xb').write(hexbytes)
 report=dict(status='BOUND_EXPLICIT_ABSENT_SCOPE_ONLY_NOT_EXECUTED',initialState='ABSENT',oldEnd='UNKNOWN',sameBoot='DIAGNOSTIC_NOT_ASSERTED',currentObjectIdentity='Captured by first later readonly original-handle snapshot, not claimed serialized during failed attempt',authority='User-authorized owned test cleanup plus frozen compiler scope; no runtime hash/path/pid permission',sources=ids,scope=ident(O/'scope.bin'),compiledEnv=ident(O/'scope.hex'),payloads14=payload,sourceMsi=pkg['msi'],oldImage=pkg['setup'],oldOriginalProcesses=[{k:v[k]for k in ['Role','Pid','CreationFiletime','ActualWait','ActualExitCode','CloseStatus','Sha256','Sid']}for v in selected],objectIdentities={k:cap[k]['Identity']for k in ['RootBefore','GateBefore','PendingBefore']},newTransaction='NOT_RUN',rawScopeMustNotBeCommitted=True)
 (O/'scope-binding.json').open('x').write(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],scopeBytes=len(out),scopeSha256=sha(out),envBytes=len(hexbytes),envSha256=sha(hexbytes))))
if __name__=='__main__':run()
