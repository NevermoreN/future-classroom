//! Explicit Absent-start test recovery. Never calls Install/Configure or a CA.
//! New empty Begin/Rollback is not evidence that the old unknown End returned.
use super::*;
#[derive(Clone, Copy)]
pub(super) struct EmptyTerminal {
    pub(super) guardian: GuardianIdentity,
    pub(super) thread: u32,
    pub(super) transaction: u32,
    pub(super) end: u32,
}
fn terminal(ended: Message, transaction: u32) -> Result<()> {
    if transaction == 0
        || ended.kind != ENDED
        || ended.transaction != transaction
        || ended.outcome != 0
        || ended.code != 0
        || ended.thread != 0
        || ended.ticks != 0
    {
        return Err(LifecycleError::Unsettled);
    }
    Ok(())
}
fn components_absent(session: &Session) -> Result<()> {
    for entry in &session.manifest.entries {
        current(session.deadline)?;
        let mut path = [0u16; PATH_LIMIT];
        let mut n = path.len() as u32;
        let state = unsafe {
            MsiGetComponentPathExW(
                &HSTRING::from(format!("{{{}}}", session.manifest.product)),
                &HSTRING::from(format!("{{{}}}", entry.component)),
                None,
                Some(MSIINSTALLCONTEXT_USERUNMANAGED),
                Some(windows::core::PWSTR(path.as_mut_ptr())),
                Some(&mut n),
            )
        };
        if state != INSTALLSTATE_UNKNOWN && state != INSTALLSTATE_ABSENT {
            return Err(LifecycleError::Unsettled);
        }
    }
    current(session.deadline)
}
fn admission(session: &mut Session) -> Result<effects::Admitted> {
    if source_identity(session)?.is_none() {
        return Err(LifecycleError::Invalid);
    }
    let admitted = effects::admit(session)?;
    if admitted.operation() != MaintenanceOperation::Install {
        return Err(LifecycleError::Invalid);
    }
    effects::revalidate(session, &admitted)?;
    components_absent(session)?;
    Ok(admitted)
}
pub(super) fn run(
    session: &mut Session,
    owner: &mut RecoveryRemovalOwner,
) -> Result<RecoveryAbsentProof> {
    if owner.authorization.0.initial != InitialState::Absent || owner.stage != Stage::Captured {
        return Err(LifecycleError::Invalid);
    }
    owner.current()?;
    // Fresh means root/markers/registration/Run all absent. The complete14
    // scope is exact and all fourteen native product-component paths absent.
    let admitted = admission(session)?;
    let pipe = session.server()?;
    let (child, image) = owner.launch(session, 0)?;
    session.accept(pipe)?;
    let peer = session.peer(pipe, true)?;
    if process_identity(peer)? != child.guardian {
        return Err(LifecycleError::Invalid);
    }
    let hello = receive(session, pipe)?;
    if hello.kind != HELLO || hello.thread != child.thread_id {
        return Err(LifecycleError::Invalid);
    }
    let left = session
        .deadline
        .saturating_duration_since(Instant::now())
        .as_millis();
    if left == 0 || left > 120_000 {
        return Err(LifecycleError::Expired);
    }
    let mut ready = Message::new(READY);
    ready.ticks = unsafe { GetTickCount64() }
        .checked_add(left as u64)
        .ok_or(LifecycleError::Invalid)?;
    send(session, pipe, ready)?;
    let began = receive(session, pipe)?;
    owner.begin(0, began)?;
    // Actual original Begin0 exists, but there is never a Run/Install/guard or
    // a new Pending. Revalidate before empty rollback under the held old record.
    effects::revalidate(session, &admitted)?;
    components_absent(session)?;
    owner.current()?;
    let mut abort = Message::new(ABORT);
    abort.transaction = began.transaction;
    send(session, pipe, abort)?;
    let ended = receive(session, pipe)?;
    terminal(ended, began.transaction)?;
    session.release_connection(pipe, peer)?;
    session.resources.close_handle(pipe)?;
    returned_zero(child.process, session.deadline)?;
    loop {
        match owner.resources.guardian_returned() {
            Ok(()) => break,
            Err(LifecycleError::GuardianRunning) => pause(session.deadline)?,
            Err(e) => return Err(e),
        }
    }
    // Exact original controls, including launch and watch copies, return before
    // this independent cleanup can authorize disposition of the old Pending.
    session.resources.close_handle(image)?;
    session.resources.close_handle(child.process)?;
    let thread = owner.resources.handle(Role::GuardianThread)?;
    owner.resources.close_handle(thread)?;
    let process = owner.resources.handle(Role::Guardian)?;
    owner.resources.close_handle(process)?;
    let mut proof = effects::reconcile(session, &admitted, effects::failed_install(&admitted))?;
    proof.check()?;
    components_absent(session)?;
    proof.release()?;
    owner.current()?;
    owner.empty = Some(EmptyTerminal {
        guardian: child.guardian,
        thread: child.thread_id,
        transaction: began.transaction,
        end: ended.code,
    });
    owner.stage = Stage::EmptyCompleted;
    owner.write_audit()?;
    Ok(RecoveryAbsentProof::AbsentEmptyTransaction)
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn empty_recovery_requires_its_own_exact_ended_zero_not_old_install_or_unknown() {
        let mut end = Message::new(ENDED);
        end.transaction = 42;
        terminal(end, 42).unwrap();
        for txn in [0, 41] {
            assert!(terminal(end, txn).is_err());
        }
        for code in [1, 1603, u32::MAX] {
            let mut bad = end;
            bad.code = code;
            assert!(terminal(bad, 42).is_err());
        }
        for outcome in [1, 2, 255] {
            let mut bad = end;
            bad.outcome = outcome;
            assert!(terminal(bad, 42).is_err());
        }
        let mut bad = end;
        bad.kind = INSTALLED;
        assert!(terminal(bad, 42).is_err());
    }
}
