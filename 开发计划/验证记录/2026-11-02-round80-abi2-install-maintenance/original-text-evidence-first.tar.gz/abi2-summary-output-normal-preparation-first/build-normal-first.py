"""Root-owned normal GNU producer for a frozen, local controlled-MSI candidate."""
from pathlib import Path
import argparse
import sys
if '--execute' not in sys.argv:
    print('{"status":"NOT_RUN"}');raise SystemExit(0)
import hashlib
import json
import os
import runpy
import signal
import subprocess
import time

ROOT = Path('/tmp/fc-round80-controlled-repair')
WORK = ROOT / 'checkout-abi2-summary-output-production-second'
OUT = ROOT / 'abi2-summary-output-normal-producer-first'
TARGET = 'i686-pc-windows-gnu'
TARGET_DIR = ROOT / 'abi2-summary-output-normal-target-first'
parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true');parser.add_argument('--maintenance-freeze',type=Path,required=True);parser.add_argument('--maintenance-freeze-sha256',required=True);args=parser.parse_args()
assert ROOT in args.maintenance_freeze.resolve().parents and len(args.maintenance_freeze_sha256)==64
raw_freeze=args.maintenance_freeze.read_bytes();assert hashlib.sha256(raw_freeze).hexdigest()==args.maintenance_freeze_sha256
frozen_maintenance=json.loads(raw_freeze);assert 1<=len(frozen_maintenance['source'])<=32
maintenance_rows=[]
for row in frozen_maintenance['source']:
    original=Path(row['path']);raw=original.read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
    relative=row['relativePath'];assert relative.startswith('crates/') and '..'not in Path(relative).parts and str(original).endswith('/'+relative)
    assert (WORK/relative).read_bytes()==raw
    maintenance_rows.append(dict(path=relative,bytes=len(raw),sha256=row['sha256']))
assert len({x['path']for x in maintenance_rows})==len(maintenance_rows)
assert (ROOT / '.owner').read_bytes() == b'future-classroom-owned-r80-controlled-repair/v1\n'
assert not OUT.exists()
# Mixed frozen source increments are independently bound by full input ledger.
HEAD = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
assert HEAD == 'd9dacefb481678a2f1c12cf8371fa6567820547d'
dev = runpy.run_path(str(WORK / 'scripts/package-controlled-dev.py'))
OUT.mkdir()
(OUT / '.owner').write_text('future-classroom-owned-abi2-dev-normal-producer/v1\n')


def fact(path):
    data = path.read_bytes()
    return {'path': str(path.relative_to(OUT)), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


before = dev['source_inventory'](WORK)
maintenance_binding=dict(status='FROZEN_MAINTENANCE_SOURCE_OVERLAY_BOUND',sourceRoot=str(WORK),lifecycleMode='ABI2_SAME_PACKAGE_MAINTENANCE_NORMAL_GNU_DEV',originalFreeze=dict(path=str(args.maintenance_freeze.resolve()),bytes=len(raw_freeze),sha256=args.maintenance_freeze_sha256),sources=maintenance_rows)
(OUT/'maintenance-source.json').write_text(json.dumps(maintenance_binding,indent=2)+'\n')
(OUT / 'inputs-before.json').write_text(json.dumps(before, indent=2) + '\n')
env = os.environ.copy()
env.pop('CARGO_ENCODED_RUSTFLAGS', None)
env.pop('FC_OWNED_REMOVAL_SCOPE_HEX', None)
for key in list(env):
    if key.startswith('FC_OWNED_REMOVAL'):del env[key]
scoped_env = {
    'CARGO_BUILD_JOBS': '2',
    'CARGO_PROFILE_RELEASE_STRIP': 'symbols',
    'CARGO_TARGET_DIR': str(TARGET_DIR),
    'CARGO_TARGET_I686_PC_WINDOWS_GNU_LINKER': 'i686-w64-mingw32-gcc',
    'RUSTFLAGS': '-C target-feature=+crt-static -C link-arg=-Wl,--major-subsystem-version,6,--minor-subsystem-version,1',
}
env.update(scoped_env)
report = {'status': 'STARTED', 'target': TARGET, 'source_root': str(WORK),
          'source_head': HEAD, 'formal_ci': False, 'environment': scoped_env,
          'removed_environment_keys': ['CARGO_ENCODED_RUSTFLAGS', 'FC_OWNED_REMOVAL_SCOPE_HEX'],
          'runtime': 'NOT_RUN', 'commands': [], 'lifecycle_mode':'ABI2_SAME_PACKAGE_MAINTENANCE_NORMAL_GNU_DEV', 'maintenance_source':fact(OUT/'maintenance-source.json'),
          'producer_script': {'path': str(Path(__file__)),
                              'sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}}


def save():
    (OUT / 'evidence.json').write_text(json.dumps(report, indent=2) + '\n')


def invoke(name, argv, budget):
    started = time.monotonic()
    process = subprocess.Popen(argv, cwd=WORK, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, start_new_session=True)
    timed_out = False
    try:
        stdout, stderr = process.communicate(timeout=budget)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            stdout, stderr = process.communicate(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            stdout, stderr = process.communicate()
    output = OUT / (name + '.stdout.jsonl')
    errors = OUT / (name + '.stderr.log')
    output.write_bytes(stdout)
    errors.write_bytes(stderr)
    row = {'name': name, 'argv': argv, 'actual_exit': process.returncode,
           'parent_reaped': process.poll() is not None, 'timed_out': timed_out,
           'seconds': time.monotonic() - started, 'original_budget_seconds': budget,
           'stdout': fact(output), 'stderr': fact(errors)}
    if process.returncode != 0 or timed_out:
        report['failed_command'] = row
        report['status'] = 'FAIL_RETAIN_ORIGINALS'
        save()
        raise SystemExit(1)
    return row, stdout


save()
metadata_argv = ['cargo', 'metadata', '--offline', '--locked', '--no-deps', '--format-version', '1']
row, raw = invoke('metadata', metadata_argv, 60)
metadata = json.loads(raw)
assert metadata['workspace_root'] == str(WORK)
assert metadata['target_directory'] == str(TARGET_DIR)
report['metadata_command'] = row
report['metadata'] = row['stdout']
report['inputs_before'] = fact(OUT / 'inputs-before.json')
save()
phases = [('product-compile', 'fc-bootstrap', 'fc-bootstrap', 'fc-bootstrap.exe'),
          ('lifecycle-compile', 'fc-bootstrap', 'fc-installer-lifecycle', 'fc-installer-lifecycle.exe'),
          ('guard-library-compile', 'fc-windows', 'fc_windows', 'fc_windows.dll')]
(OUT / 'artifacts').mkdir()
for name, package, target_name, leaf in phases:
    argv = ['cargo', 'build', '--release', '--offline', '--locked', '-p', package]
    argv += ['--lib'] if name == 'guard-library-compile' else ['--bin', target_name]
    argv += ['--target', TARGET, '--target-dir', str(TARGET_DIR), '--message-format=json']
    row, raw = invoke(name, argv, 900)
    messages = [json.loads(line) for line in raw.splitlines() if line.startswith(b'{')]
    selected = [message for message in messages if message.get('reason') == 'compiler-artifact'
                and message.get('target', {}).get('name') == target_name
                and message.get('profile', {}).get('test') is False]
    assert len(selected) == 1
    message = selected[0]
    assert message['features']==['default'] and metadata['packages'][next(i for i,p in enumerate(metadata['packages']) if p['name']==package)]['features'].get('default')==[]
    filenames = ([path for path in message['filenames'] if Path(path).name == leaf]
                 if name == 'guard-library-compile' else [message['executable']])
    assert len(filenames) == 1
    artifact = Path(filenames[0])
    assert artifact.parent == TARGET_DIR / TARGET / 'release' and artifact.name == leaf
    assert artifact.is_file() and not artifact.is_symlink()
    data = artifact.read_bytes()
    assert 0 < len(data) <= 32 * 1024 * 1024
    copy = OUT / 'artifacts' / leaf
    copy.write_bytes(data)
    row['artifact'] = fact(copy)
    report['commands'].append(row)
    assert before == dev['source_inventory'](WORK)
    save()
    print(json.dumps({'phase': name, 'actual_exit': row['actual_exit'],
                      'seconds': row['seconds'], 'artifact': row['artifact']}), flush=True)
after = dev['source_inventory'](WORK)
assert before == after
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == HEAD
# Mixed frozen source increments are independently bound by full input ledger.
(OUT / 'inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
report['inputs_after'] = fact(OUT / 'inputs-after.json')
report['status'] = 'DEV_FROZEN_NORMAL_BUILD_ONLY'
save()
print(json.dumps({'status': report['status'], 'source_head': HEAD,
                  'input_count': len(before), 'evidence': fact(OUT / 'evidence.json')}), flush=True)
