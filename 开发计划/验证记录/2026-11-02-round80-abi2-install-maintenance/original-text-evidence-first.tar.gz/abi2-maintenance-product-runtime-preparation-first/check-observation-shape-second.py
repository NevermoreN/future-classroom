"""Exercise transport admission with a historical receipt; no ABI2 runtime claim."""
from pathlib import Path
import copy
import hashlib
import json
import runpy

P = Path(__file__).resolve().parent
OLD = Path('/tmp/fc-round80-controlled-repair/a470-msvc-product-runtime-second/report.json')
assert hashlib.sha256(OLD.read_bytes()).hexdigest() == '4a1dd14e32be5c8c4519876a5aee534712870dc344fd889291733c48f41c7d7f'
m = runpy.run_path(str(P / 'run-controlled-product.py'))
receipt = json.loads(OLD.read_bytes())['phase']
receipt['status'] = 'PASS_GNU_ABI2_SAME_PACKAGE_MAINTENANCE_WIN11_DEV_CONTROLLED_PRODUCT_INSTALL_LICENSE_REPAIR_UNINSTALL'
assert m['admission'](receipt)
cases = []


def reject(label, mutate):
    changed = copy.deepcopy(receipt)
    mutate(changed)
    assert not m['admission'](changed), label
    cases.append(label)


for flag in ('ownerUnknown', 'instrumentUnknown', 'originalBudgetExceeded'):
    reject(flag, lambda r, k=flag: r.__setitem__(k, True))
reject('uninstall missing', lambda r: r['phases'].pop())
reject('preexisting product retained', lambda r: r['finallyProduct'].__setitem__('knownAbsent', False))
reject('Pending unknown', lambda r: r['finallyCoordination'].__setitem__('pendingKnownAbsent', False))
reject('gate unknown', lambda r: r['finallyCoordination'].__setitem__('namespaceKnownAbsent', False))
reject('repair incomplete', lambda r: r['repaired'].__setitem__('healthyPresent', False))
reject('original cache remains', lambda r: r['uninstalledCache'].__setitem__('allObservedAbsent', False))
reject('damage capability not returned', lambda r: r['licenseDamage'].__setitem__('checkedClose', False))
for phase in range(3):
    for field, value in (('actualExit', False), ('exitCode', 1603), ('pipesComplete', False), ('timedOut', True)):
        reject('phase %s client %s' % (phase, field),
               lambda r, i=phase, k=field, v=value: r['phases'][i]['client'].__setitem__(k, v))
    reject('phase %s owner not returned' % phase,
           lambda r, i=phase: r['phases'][i].__setitem__('knownControlsReturned', False))
    reject('phase %s observer errors' % phase,
           lambda r, i=phase: r['phases'][i]['observerFinal'].__setitem__('Errors', ['unknown']))
for phase in range(3):
    reject('phase %s missing guardian' % phase, lambda r,i=phase: r['phases'][i]['observerFinal'].__setitem__('Processes', [f for f in r['phases'][i]['observerFinal']['Processes'] if f['Role']!='owned-guardian']))
report = dict(status='PASS_LOCAL_OBSERVATION_SHAPE_QUALIFICATION_ONLY',
              historicalReceiptSha256=hashlib.sha256(OLD.read_bytes()).hexdigest(),
              positive=1, rejected=len(cases), negativeCases=cases,
              ABI2Native='NOT_RUN', finalPackageBinding='NOT_TESTED_BY_THIS_SHAPE_CHECK')
(P / 'observation-shape-check-second.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
