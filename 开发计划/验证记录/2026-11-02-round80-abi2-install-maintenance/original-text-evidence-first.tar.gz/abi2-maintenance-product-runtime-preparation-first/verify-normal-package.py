"""Read-only qualification for the final normal ABI2 DEV package.

This is test preparation. It never compiles, installs or authorizes an MSI.
The transport separately requires explicit final manifest hashes and a freeze.
"""
from pathlib import Path
import hashlib
import json
import re
import runpy

R = Path('/tmp/fc-round80-controlled-repair')
VALIDATOR = R / 'abi2-dev-package-preparation-first/validate-normal-inputs-first.py'
VALIDATOR_SHA = 'e4b3025fa0041c3d624b1248e9189c9646f4ca7c8a0bdcf1eeb999bad4b17d96'
PACKAGE = R / 'abi2-maintenance-dev-product-package-first'
EVIDENCE = R / 'abi2-maintenance-dev-normal-producer-first/evidence.json'


def need(value, message):
    if not value:
        raise AssertionError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def fact(path):
    path = Path(path)
    need(path.is_absolute() and path.resolve() == path and path.is_relative_to(R)
         and path.is_file() and not path.is_symlink(), 'Exact owned input file')
    raw = path.read_bytes()
    need(len(raw) <= 96 * 1024 * 1024, 'Bounded input')
    return dict(path=str(path), bytes=len(raw), sha256=sha(raw))


def verify(c, source):
    need(c['guardABI'] == 2 and c['normalProfileTest'] is False
         and c['formalCI'] is False
         and c['lifecycleMode'] == 'ABI2_SAME_PACKAGE_MAINTENANCE_NORMAL_GNU_DEV',
         'Only normal GNU ABI2 same-package maintenance DEV')
    need(c['expectedUserSid'] == 'S-1-5-21-3896111207-1867804362-1971593122-1001',
         'Only authorized deployment SID')
    need(fact(VALIDATOR)['sha256'] == VALIDATOR_SHA
         and c['normalValidator'] == fact(VALIDATOR), 'Pinned normal validator')
    need(c['normalEvidence'] == fact(EVIDENCE)
         and c['sourceEvidenceSha256'] == fact(EVIDENCE)['sha256'],
         'Exact final maintenance build evidence')
    evidence = json.loads(EVIDENCE.read_bytes())
    need(evidence['lifecycle_mode'] == c['lifecycleMode'],
         'Actual producer explicitly binds maintenance source')
    source_root = Path(c['sourceRoot'])
    normal = runpy.run_path(str(VALIDATOR))['admit_normal_inputs'](
        source_root, EVIDENCE, c['sourceEvidenceSha256'])
    need(normal['status'] == 'PASS_NORMAL_GNU_ABI2_DEV_SOURCE_AND_THREE_ARTIFACTS_ONLY'
         and normal['target'] == c['target'] == 'i686-pc-windows-gnu'
         and normal['baseGit'] == c['sourceGit'] == source['sourceBase'],
         'Actual normal source base; overlay proven by full inventory')
    need(c['packageBuilder'] == fact(source_root / 'scripts/package-abi2-controlled-dev.py')
         and normal['builder']['sha256'] == c['packageBuilder']['sha256'],
         'Exact source builder')
    final_admission = runpy.run_path(str(source_root / 'scripts/package-abi2-controlled-dev.py'))[
        'admit_normal_inputs'](source_root, EVIDENCE, c['sourceEvidenceSha256'])
    need(final_admission['status'] == normal['status']
         and final_admission['normalArtifacts'] == normal['normalArtifacts'],
         'Final builder independently closes same three normal artifacts')
    maintenance = final_admission['maintenanceSourceBinding']
    receipt_path = EVIDENCE.parent / evidence['maintenance_source']['path']
    need(receipt_path.resolve().parent == EVIDENCE.parent
         and receipt_path.name == 'maintenance-source.json'
         and fact(receipt_path)['bytes'] == evidence['maintenance_source']['bytes']
         and fact(receipt_path)['sha256'] == evidence['maintenance_source']['sha256'],
         'Actual maintenance source receipt bytes')
    receipt = json.loads(receipt_path.read_bytes())
    need(receipt['status'] == 'FROZEN_MAINTENANCE_SOURCE_OVERLAY_BOUND'
         and receipt['sourceRoot'] == str(source_root)
         and receipt['lifecycleMode'] == c['lifecycleMode']
         and maintenance['lifecycleMode'] == c['lifecycleMode']
         and maintenance['originalFreeze'] == receipt['originalFreeze']
         and maintenance['sourceCount'] == len(receipt['sources']),
         'Maintenance provenance is source-bound, not only a report label')
    need(receipt['originalFreeze'] == fact(receipt['originalFreeze']['path']),
         'Exact original frozen maintenance implementation')
    before = EVIDENCE.parent / evidence['inputs_before']['path']
    after = EVIDENCE.parent / evidence['inputs_after']['path']
    need(sha(before.read_bytes()) == evidence['inputs_before']['sha256']
         and before.read_bytes() == after.read_bytes()
         and source['sources'] == json.loads(before.read_bytes()),
         'Exact complete source overlay before and after actual builds')
    report = PACKAGE / 'report.json'
    need(c['packageReport'] == fact(report), 'Pinned final package report')
    package = json.loads(report.read_bytes())
    need(package['status'] == 'PASS_NORMAL_GNU_ABI2_DEV_STATIC_BUNDLE_NATIVE_NOT_RUN'
         and package['scope'] == 'NORMAL_GNU_ABI2_DEV_STATIC_BUNDLE_ONLY_NOT_FORMAL_MSVC'
         and package['formalCI'] is False and package['normalProfileTest'] is False
         and package['installation'] == 'NOT_RUN'
         and package['lifecycleMode'] == c['lifecycleMode']
         and package['sourceRoot'] == str(source_root)
         and package['sourceBase'] == c['sourceGit']
         and package['sourceEvidenceSha256'] == c['sourceEvidenceSha256'],
         'Actual final static bundle with maintenance source')
    need(c['productCode'] == '{' + package['productCode'] + '}',
         'Canonical braced native ProductCode matches unbraced envelope identity')
    for key in ('packageCode', 'version', 'payloads'):
        need(package[key] == c[key], 'Exact package identity and all payloads: ' + key)
    need(re.fullmatch(r'[0-9A-F]{8}(?:-[0-9A-F]{4}){3}-[0-9A-F]{12}', c['packageCode'])
         and c['packageCode'] != '00000000-0000-0000-0000-000000000000',
         'Actual nonzero Summary PackageCode')
    for key, leaf in (('setup', 'Setup.exe'), ('msi', 'FutureClassroom.msi')):
        need(fact(PACKAGE / leaf) == c[key]
             and package[key]['bytes'] == c[key]['bytes']
             and package[key]['sha256'] == c[key]['sha256'], 'Exact final ' + key)
    need(package['binaryReadback'] == 'ALL_THREE_EXACT'
         and package['payloadReadback'] == 'ALL_FOURTEEN_EXACT'
         and package['onlyExternal32HoleFilled'] is True
         and package['msiContract']['guardABI'] == 2
         and package['msiContract']['packageCode'] == c['packageCode'],
         'Complete static MSI readbacks and ABI2 contract')
    codec = runpy.run_path(str(source_root / 'scripts/installer-carrier-format.py'))
    helper = Path(normal['normalArtifacts']['lifecycle-compile']['path'])
    template = codec['make_carrier_template'](helper.read_bytes())
    need(package['template']['bytes'] == len(template)
         and package['template']['sha256'] == sha(template)
         and package['template']['hole'] == helper.stat().st_size + 16
         and package['template']['canonicalZero32'] is True
         and package['template']['normalPrefixExact'] is True,
         'Template rebuilt from actual unchanged normal helper')
    codec['verify_carrier_binding'](template, (PACKAGE / 'Setup.exe').read_bytes(),
                                    (PACKAGE / 'FutureClassroom.msi').read_bytes())
    need(set(normal['normalArtifacts']) == {'product-compile', 'lifecycle-compile',
                                           'guard-library-compile'}, 'Three normal artifacts')
    return normal
