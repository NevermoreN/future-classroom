"""Read-only admission of five core reports plus original capture/retrieval and all downloads."""
from pathlib import Path
import hashlib,json,re,base64
R=Path('/tmp/fc-round80-controlled-repair');P=Path(__file__).resolve().parent
PINS={'abi2-maintenance-product-runtime-first':'ce2c2c06782f03b160186335ace47ec25d33d201a400270878c580296bba82ef','abi2-absent-recovery-runtime-first':'c90927b0c09b1f9f887abc2d8f33a457c0ad3af0e6c4cc068087748f9c6e6305','abi2-absent-recovery-runtime-second':'740636d9b841890e3bec76cafa72bf8d8f2d2f5028e575e538a20758edcc304e','abi2-ca-diagnostic-runtime-second':'98890ab6ed694f8733bf382ee9e55611d1c7096e6b7c43ec2a1e339e537852ff','abi2-ca-diagnostic-runtime-third':'4db7457e4d3fafdc9f1fef1fd671e6b44cf592bd3650c8c24045e6d872ac8fbf'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fact(p):p=Path(p);assert p.is_file()and not p.is_symlink();return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def replay(leaf):
 p=R/leaf/'report.json';assert sha(p)==PINS[leaf];j=json.loads(p.read_bytes());assert j['downloadVerified']is True;inv=j['inventory'];assert 0<len(inv['files'])<=256 and len(inv['directories'])<=32
 local=p.parent/'download'/j['windowsRoot'].replace('\\','/').split('/')[-1];assert local.is_dir()and not local.is_symlink();files=[];dirs=[]
 for q in sorted(local.rglob('*')):
  assert not q.is_symlink();rel=q.relative_to(local).as_posix()
  if q.is_dir():dirs.append(rel)
  else:f=fact(q);files.append(dict(path=rel,bytes=f['bytes'],sha256=f['sha256']))
 assert {x['path']:(x['bytes'],x['sha256'])for x in files}=={x['path']:(x['bytes'],x['sha256'])for x in inv['files']}and set(dirs)==set(inv['directories'])
 for x in inv['files']:
  rel=x['path'];assert ':'not in rel and '\\'not in rel and all(y not in['','.','..']for y in rel.split('/'))and 0<=x['bytes']<=96*1024*1024 and re.fullmatch('[0-9a-f]{64}',x['sha256'])
 for rel in inv['directories']:assert ':'not in rel and '\\'not in rel and all(y not in['','.','..']for y in rel.split('/'))
 return j,local
def phase_returned(x,expected):
 c=x['client'];assert c['started']and c['actualExit']and c['exitCode']==expected and c['pipesComplete']and not c['timedOut']and x['knownControlsReturned']and not x['directCloseUnknown']and x['capturedObjectsReturned']
 caps=x['directOriginalFinal'];assert len(caps)==1
 for z in caps:assert z['Wait']==0 and z['ExitKnown']and z['ExitCode']==expected and z['CheckedClose']and z['CloseAttempted']and z['Pid']==c['pid']and z['Creation']==c['creationFiletime']
 obs=x['observerFinal'];assert obs['Closed']and obs['Errors']==[];procs=obs['Processes'];assert len(procs)==2 and sum(z['Role']=='owned-guardian'for z in procs)==1
 for z in procs:assert z['IdentityStatus']=='ORIGINAL_QUERY_SYNC_HANDLE_EXACT_IMAGE_BYTES_USER'and z['ActualWait']==0 and z['ActualExitCode']==expected and z['CloseStatus']=='CHECKED_CLOSE_SUCCESS'
def bind():
 loaded={leaf:replay(leaf)for leaf in PINS};old,ol=loaded['abi2-maintenance-product-runtime-first'];f,fl=loaded['abi2-absent-recovery-runtime-first'];good,gl=loaded['abi2-absent-recovery-runtime-second']
 assert old['status']=='FAIL_OR_UNKNOWN_RETAIN_ORIGINALS'and len(old['phase']['phases'])==1 and old['runtimeActualExit']==1;phase_returned(old['phase']['phases'][0],1603)
 assert f['status']=='FAIL_OR_UNKNOWN_RETAIN_ALL_ORIGINALS'and f['runtimeActualExit']==1 and f['phase']['phases']==[] and f['phase']['ownerUnknown']is False and f['phase']['instrumentUnknown']is False
 assert good['runtimeActualExit']==0 and good['phase']['status']=='PASS_GNU_WIN11_ABI2_ABSENT_RECOVERY_OLD_END_UNKNOWN'and good['phase']['oldEnd']=='UNKNOWN_UNCHANGED'and len(good['phase']['phases'])==1;phase_returned(good['phase']['phases'][0],0)
 for j in [old,f,good]:assert j['originalWholeBudgetExceeded']is False and j['phase']['ownerUnknown']is False and j['phase']['instrumentUnknown']is False
 assert good['phase']['finallyProduct']['knownAbsent']and good['phase']['finallyCoordination']['pendingKnownAbsent']and good['phase']['finallyOwnProcesses']['knownZero']
 snap=good['phase']['beforePending'];assert snap['Status']=='PASS_READONLY_PINNED_PENDING_SNAPSHOT_ONLY'and snap['SameHandleMetadataEqual']and not snap['CloseUnknown']
 gate=[]
 for key in ['RootBefore','GateBefore']:
  z=snap[key];after=snap[key.replace('Before','After')];assert z['Identity']==after['Identity']and z['OwnerDaclSddl']==after['OwnerDaclSddl'];gate.append(z)
 # Bind the earlier original capture/retrieval, rather than replacing its
 # identities with a new inferred gate snapshot. Raw Pending never enters config.
 retrieval=R/'abi2-pending-readonly-retrieval-first/report.json';assert sha(retrieval)=='9f8e75360e25e7d69bb537765c549a59a83279f15278fb944659ad6699b24ab9';rj=json.loads(retrieval.read_bytes());capture_report=R/'abi2-pending-readonly-runtime-first/report.json';assert sha(capture_report)=='b4c531ffd784596082ca8e3d776f1f0760400f2d8b6d5ef87cd7cd7f47e9cd51'and rj['originalCaptureReport']['sha256']==sha(capture_report)and rj['downloadVerified']
 cpdirs=list((retrieval.parent/'download').iterdir());assert len(cpdirs)==1;cp=cpdirs[0];actual={}
 for z in cp.rglob('*'):
  assert not z.is_symlink()
  if z.is_file():actual[z.relative_to(cp).as_posix()]=(z.stat().st_size,sha(z))
 assert actual=={z['path']:(z['bytes'],z['sha256'])for z in rj['inventory']['files']}
 original=rj['originalNativeSnapshot']['capture'];assert original['Status']=='PASS_READONLY_PINNED_PENDING_SNAPSHOT_ONLY'and original['SameHandleMetadataEqual']and not original['CloseUnknown']
 for key in ['RootBefore','GateBefore']:
  for field in ['Path','Identity','OwnerDaclSddl']:assert original[key][field]==snap[key][field]
 assert json.loads((cp/'pending-snapshot.json').read_bytes())==rj['originalNativeSnapshot']
 # The first failed recovery captured the same old objects, without a new Setup.
 for key in ['RootBefore','GateBefore']:assert f['phase']['beforePending'][key]['Identity']==snap[key]['Identity']and f['phase']['beforePending'][key]['OwnerDaclSddl']==snap[key]['OwnerDaclSddl']
 sid='S-1-5-21-3896111207-1867804362-1971593122-1001';gatefacts=[gate[0]['Path'],sid,gate[0]['Identity'],gate[1]['Identity'],gate[0]['OwnerDaclSddl'],gate[1]['OwnerDaclSddl']]
 a=good['phase']['nativeAudit'];audit=gl/'explicit-removal-audit.v1';assert fact(audit)['bytes']==a['bytes']and sha(audit)==a['sha256'];lines=audit.read_text('ascii').splitlines();assert lines[0]=='FC-EXPLICIT-REMOVAL-AUDIT/v1';values=dict(x.split('=',1)for x in lines[1:]);assert values['stage']=='RemovalAuthorized'and values['oldDisposition']==values['oldEnd']=='UNKNOWN'and values['runtimeReport']==PINS['abi2-maintenance-product-runtime-first']and values['initialState']=='Absent'
 assert re.fullmatch(r'pid:[1-9][0-9]*;creation:[1-9][0-9]*;thread:[1-9][0-9]*;begin:0;transaction:[1-9][0-9]*;install:NOT_CALLED;guard:NOT_CALLED;emptyRollback:0;eventControls:0;originalThreadExit:0;originalProcessExit:0',values['newEmpty'])
 config=json.loads((ol/'artifact-manifest.json').read_bytes());assert config['productCode']=='{9E50831D-7811-5039-8BC3-4934647448D8}'and len(config['payloads'])==14 and config['sourceGit']=='d9dacefb481678a2f1c12cf8371fa6567820547d'and config['expectedUserSid']==sid
 config.update(registryMarkerKey='Software\\FutureClassroom\\Installer\\Components',runKey='Software\\Microsoft\\Windows\\CurrentVersion\\Run',runValue='FutureClassroom',registryView='Registry32',fixedDestinationKnownFolderSuffix=['Programs','FutureClassroom'])
 roots=[]
 for j,local,kind,prefix in [(old,ol,'old-normal','FutureClassroom-r80-abi2-maintenance-controlled-product-'),(f,fl,'recovery-first','FutureClassroom-r80-abi2-absent-recovery-'),(good,gl,'recovery-second','FutureClassroom-r80-abi2-absent-recovery-')]:
  assert re.fullmatch('[0-9a-f]{32}',j['nonce'])and j['windowsRoot'].endswith('\\'+prefix+j['nonce']);roots.append(dict(kind=kind,path=j['windowsRoot'],nonce=j['nonce'],owner=(local/'.owner').read_text(),inventory=j['inventory']))
 system={};logs=[]
 for leaf in ['abi2-maintenance-product-runtime-first','abi2-ca-diagnostic-runtime-second','abi2-ca-diagnostic-runtime-third']:
  j,local=loaded[leaf]
  for q in local.rglob('*'):
   if not q.is_file()or q.name.casefold()not in ['direct-msi.log','msid1656.log']:continue
   raw=q.read_bytes();text=raw.decode('utf-16')if raw.startswith((b'\xff\xfe',b'\xfe\xff'))else raw.decode('utf-8-sig');found=re.findall(r'(?i)C:\\Windows\\Installer\\[A-Za-z0-9]{1,64}\.(?:msi|tmp)',text);assert found;logs.append(dict(**fact(q),derivedPaths=sorted(set(found))))
   for path in found:system[path.casefold()]=path
 assert len(logs)==3 and len(system)==6
 for z in good['phase']['afterOldInstallerPaths']:assert z['status']=='KNOWN_ABSENT'and z['path'].casefold()in system
 instruments=[]
 for n in ['ProductState.cs','ProductState.ps1','GateRetirement.cs']:
  q=P/'sources'/n;instruments.append(dict(name=n,bytes=q.stat().st_size,sha256=sha(q),base64=base64.b64encode(q.read_bytes()).decode()))
 return dict(sid=sid,roots=roots,gateFacts=gatefacts,productConfig=config,instruments=instruments,systemPaths=sorted(system.values())),dict(status='PASS_LOCAL_REPLAY_SEVEN_ORIGINAL_REPORTS_THREE_SCRATCH_SCOPED_RECOVERY_ORIGINAL_GATE_IDENTITIES',reports=[fact(R/leaf/'report.json')for leaf in PINS]+[fact(capture_report),fact(retrieval)],rootFileCounts=[len(x['inventory']['files'])for x in roots],rootDirectoryCounts=[len(x['inventory']['directories'])for x in roots],systemPathsReadOnly=sorted(system.values()),sourceLogs=logs,oldEnd='UNKNOWN_UNCHANGED',oldFailurePreserved=True,recoveryFirst='NO_SETUP_START_PHASES_EMPTY_NOT_CHECKED_RETURN',recoverySecond='NEW_EMPTY_BEGIN_ROLLBACK_AUDIT_AND_TWO_ORIGINAL_PROCESS_CAPS_KNOWN_RETURN_OLD_END_UNKNOWN',rawScope='NOT_READ_OR_INCLUDED',rawPending='NOT_INCLUDED',gateFactsOrigin='ORIGINAL_CAPTURE_RETRIEVAL_AND_TWO_RECOVERY_CAPTURES_ALL_EXACT_ROOT_GATE_IDS_CREATION_SDDL')
if __name__=='__main__':
 c,r=bind();(P/'binding-first.json').write_text(json.dumps(c,indent=2)+'\n');(P/'local-binding-first.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(dict(status=r['status'],rootCounts=r['rootFileCounts'],systemPaths=len(c['systemPaths']))))
