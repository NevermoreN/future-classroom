"""Root-only exact three-nonce/empty-gate cleanup. No default execution."""
from pathlib import Path
import argparse,base64,hashlib,json,runpy,subprocess,time
R=Path('/tmp/fc-round80-controlled-repair');P=Path(__file__).resolve().parent
BOOT="[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()));$ok=$?;$code=Get-Variable -Name LASTEXITCODE -ErrorAction SilentlyContinue;if($null-ne$code){exit ([int]$code.Value)};if($ok){exit 0};exit 1"
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fact(p):p=Path(p);assert p.is_file()and not p.is_symlink();return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def inputs(pin):
 f=P/'freeze-first.json';assert sha(f)==pin;j=json.loads(f.read_bytes());actual={p.relative_to(P).as_posix()for p in P.rglob('*')if p.is_file()};assert actual=={x['path']for x in j['files']}|{'freeze-first.json'}
 for x in j['files']:assert fact(P/x['path'])==dict(path=str(P/x['path']),bytes=x['bytes'],sha256=x['sha256'])
 mod=runpy.run_path(str(P/'bind-inputs.py'));c,receipt=mod['bind']();assert c==json.loads((P/'binding-first.json').read_bytes())and receipt==json.loads((P/'local-binding-first.json').read_bytes());return c,receipt

def main():
 a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');a.add_argument('--validate-inputs-only',action='store_true');a.add_argument('--preparation-freeze-sha256');a.add_argument('--output-dir',type=Path);v=a.parse_args()
 if not v.execute and not v.validate_inputs_only:print('{"status":"NOT_RUN"}');return
 assert not(v.execute and v.validate_inputs_only);c,binding=inputs(v.preparation_freeze_sha256)
 if v.validate_inputs_only:print(json.dumps(dict(status='PASS_LOCAL_SEVEN_ORIGINAL_REPORTS_FULL_DOWNLOAD_REPLAY_THREE_NONCES_AND_ORIGINAL_GATE_INPUTS_ONLY',fileCounts=binding['rootFileCounts'],systemPaths=len(c['systemPaths']),oldEnd='UNKNOWN_UNCHANGED',Windows='NOT_RUN')));return
 assert v.output_dir==R/'abi2-recovered-cleanup-runtime-first'and not v.output_dir.exists();D=v.output_dir;D.mkdir();(D/'.owner').write_text('future-classroom-owned-abi2-recovered-cleanup-runtime/v1\n')
 script=(P/'cleanup-first.ps1').read_text();feed=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;\n"+script).encode();(D/'cleanup.stdin.ps1').write_bytes(feed)
 argv=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','future-classroom-win11','powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(BOOT.encode('utf-16-le')).decode()]
 result=dict(status='FAIL_OR_UNKNOWN_RETAIN_REMAINDER',binding=binding,preparationFreeze=fact(P/'freeze-first.json'),oldEnd='UNKNOWN_UNCHANGED',actualExit=None,originalLocalParentReaped=False,remoteReturnUnknown=True,argv=argv,newIndependentCleanupSeconds=600,outerSeconds=900,notContinuationOfOld120=True,noRetry=True,systemCache='READONLY_EXACT_SIX_PATHS_NO_DELETE',PendingDeletion='NOT_ALLOWED_OR_ATTEMPTED');start=time.monotonic();code=1
 try:
  with(D/'cleanup.stdout.log').open('xb')as so,(D/'cleanup.stderr.log').open('xb')as se:
   p=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=so,stderr=se);result['originalLocalPid']=p.pid
   try:p.communicate(feed,timeout=600);result.update(actualExit=p.returncode,originalLocalParentReaped=True,remoteReturnUnknown=False)
   except subprocess.TimeoutExpired:raise RuntimeError('TRANSPORT_UNKNOWN_NO_REMOTE_KILL_OR_RETRY')
  j=json.loads((D/'cleanup.stdout.log').read_bytes().decode('utf-8-sig'));result['phase']=j
  assert p.returncode==0 and j['status']=='PASS_ABI2_RECOVERED_THREE_NONCES_AND_ORIGINAL_EMPTY_GATE_CLEANED_OLD_END_UNKNOWN'and not j['originalBudgetExceeded']and j['oldEnd']=='UNKNOWN_UNCHANGED'
  assert j['finalProduct']['knownAbsent']and j['finalProduct']['runAbsent']and j['finalGate']['status']=='KNOWN_ABSENT'and j['finalOwnProcesses']['knownZero']and len(j['rootsDeleted'])==3
  assert all(x['readback']['status']=='KNOWN_ABSENT'for x in j['rootsDeleted'])and all(j['finalPath_'+x]['status']=='KNOWN_ABSENT'for x in ['old-normal','recovery-first','recovery-second'])
  assert j['gateCaptureFacts']==c['gateFacts']and j['nativeGateRetirement']['pendingDeletedByController']is False
  for key in ['beforeExactSystemPaths','finalExactSystemPaths']:assert len(j[key])==6 and {x['path']for x in j[key]}==set(c['systemPaths'])and all(x['status']=='KNOWN_ABSENT'for x in j[key])
  inputs(v.preparation_freeze_sha256);result['status']='PASS_EXACT_THREE_DOWNLOADED_TEST_NONCES_AND_ORIGINAL_EMPTY_GATE_CLEANED_SYSTEM_PATHS_ABSENT_OLD_END_UNKNOWN';code=0
 except Exception as e:result.update(errorType=type(e).__name__,error=str(e))
 result['elapsedSeconds']=time.monotonic()-start;result['newCleanupBudgetExceeded']=result['elapsedSeconds']>=600
 if result['newCleanupBudgetExceeded']:result['status']='FAIL_NEW_INDEPENDENT_CLEANUP_BUDGET_EXCEEDED';code=1
 result['stdout']=fact(D/'cleanup.stdout.log');result['stderr']=fact(D/'cleanup.stderr.log');(D/'report.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],report=fact(D/'report.json'),error=result.get('error'))));raise SystemExit(code)
if __name__=='__main__':main()
