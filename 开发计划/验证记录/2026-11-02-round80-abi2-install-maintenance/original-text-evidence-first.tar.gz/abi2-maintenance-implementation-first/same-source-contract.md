# ABI2 same-source maintenance

Private same-source Repair/Uninstall proof, not PublishedInstalledRelease or Upgrade authorization. Only native CapturedSource and current SID USERUNMANAGED registration create it; no path/hash/property/boolean/CLI permission.

Original B holds Draft and both B and G independently capture before Begin in original deadline. Actual source and native LocalPackage must have exactly the31 fixed supported ordinary tables and exact native column names/types. Every typed null/integer/text/stream value is CNG hashed; sorted row hashes remove physical ordering only. All Binary guard/template/envelope bytes are included. Summary9 PackageCode equals captured source. Extra/missing tables, nonempty native Transforms, or any native ALL-state patch reject. Cache whole SHA binds only its own pinned object before-after, not equality to whole source MSI.

The original Resources claim moves into the stable Reader Box. Known failures close original resources once and release; closeunknown retains that same Box/claim/MSI ledger until exit. Successful close receipt metadata is consumed only between complete tables with the same original DB live. Budgets remain64 combined kernel/CNG/MSI live,8 original owner slots,120 original seconds,256 receipt space,72 rows per table,8192 checked MSI closes,64MiB streams. No source owner/claim restart or unsafe close retry.

After Begin only native registration and original cache object/size/digest are revalidated; no database open. Temporary pins/CNG returned before Run. Install requires native Fresh and no maintenance proof; Repair/Uninstall require native SameManifest plus private same-source proof. The same one-package v2 ticket, actual activeDB guard identity, successor, End, physical G and Present/Absent effects settlement remain. Repair vamus and fixed sealed source REMOVE=ALL are unchanged. Ordinary Pending refusal and legacy path are unchanged.

No native Windows maintenance evidence from this step. Future cross-version Upgrade needs real published predecessor and two-ticket plan; this proof cannot supply either. Root/RR must rebuild same-source normal3 before actual Fresh/Repair/Uninstall.
