//! Native worker integration, with real issuance and Writer publication. The
//! picker itself stays outside the synthetic fixture; no user file is selected.
use super::tests::{drain, lose_worker_reply, ready_management, wait_for, Scratch, SERIAL};
use super::*;
use fc_domain::materials::*;
use fc_ports::{command_window::CommandFamily, MaterialListRequest};
use fc_windows::materials::chooser::SelectedFile;

fn initialized() -> (Scratch, App, MaterialScope) {
    let (scratch, mut app) = ready_management();
    let owner = app.backend.as_ref().unwrap().clone();
    let mut backend = owner.lock().unwrap();
    let lease = app.lease.unwrap();
    let class = ClassId::new(1).unwrap();
    let subject = SubjectId::new(1).unwrap();
    for action in [
        IdentityCommand::CreateClass {
            id: class,
            name: "Synthetic batch class".into(),
        },
        IdentityCommand::PutSubject {
            id: subject,
            name: "Synthetic batch subject".into(),
            enabled: true,
            color: Rgb {
                red: 40,
                green: 80,
                blue: 120,
            },
            expected_revision: None,
        },
        IdentityCommand::UpdateAccount {
            id: lease.principal_id(),
            display_name: "Synthetic batch owner".into(),
            role: Role::GlobalAdmin,
            enabled: true,
            scopes: vec![fc_domain::identity::AssignmentScope {
                class_id: class,
                subject_id: subject,
            }],
        },
    ] {
        let issued = backend
            .issue_native_command(CommandFamily::Identity, Some(lease), SessionPurpose::Manage)
            .unwrap();
        backend
            .begin_command_scope(issued)
            .unwrap()
            .identity(lease, action)
            .unwrap();
    }
    let renewed = backend
        .login(
            voice_management_probe::LOGIN_NAME,
            Password::new(voice_management_probe::PASSWORD_VALUE.into()).unwrap(),
        )
        .unwrap();
    app.state = Arc::new(backend.state().unwrap());
    app.lease = Some(renewed);
    drop(backend);
    app.event(Event::Submit(TO_MATERIALS, FormData::new()))
        .unwrap();
    let scope = MaterialScope {
        teacher_id: renewed.principal_id(),
        subject_id: subject,
    };
    (scratch, app, scope)
}
fn selection(app: &App, name: &str, bytes: &[u8]) -> SelectedFile {
    let dir = app.root.join("quarantine");
    fs::create_dir_all(&dir).unwrap();
    fs::write(dir.join(name), bytes).unwrap();
    SelectedFile::isolated_probe(&app.root, name).unwrap()
}
fn confirm(app: &mut App, scope: MaterialScope, files: Vec<SelectedFile>) {
    app.material_editor
        .as_mut()
        .unwrap()
        .stage_batch(scope, vec![ClassId::new(1).unwrap()], files)
        .unwrap();
    app.material_event(materials_editor::CONFIRM_BATCH, FormData::new())
        .unwrap();
}
fn current(app: &App, scope: MaterialScope) -> MaterialPage {
    app.backend
        .as_ref()
        .unwrap()
        .lock()
        .unwrap()
        .materials(
            app.lease.unwrap(),
            MaterialListRequest {
                scope,
                cursor: None,
            },
        )
        .unwrap()
}
#[test]
fn lost_batch_reply_relogin_current_read_cannot_confirm_but_original_pair_query_can() {
    let _serial = SERIAL.lock().unwrap();
    let (_scratch, mut app, scope) = initialized();
    let first = selection(&app, "first.txt", b"first synthetic material");
    let last = selection(&app, "last.txt", b"last synthetic material");
    confirm(&mut app, scope, vec![first, last]);
    lose_worker_reply(&mut app);
    let original = app.native_command.clone().unwrap();
    let pair = original.snapshot().unwrap();
    let before = current(&app, scope);
    assert_eq!(before.total, 2);
    assert_eq!(before.items[0].display_name, "last.txt");
    assert_eq!(before.items[1].display_name, "first.txt");
    let old_lease = app.lease.unwrap();
    app.lock();
    let owner = app.backend.as_ref().unwrap().clone();
    let new_lease = owner
        .lock()
        .unwrap()
        .login(
            voice_management_probe::LOGIN_NAME,
            Password::new(voice_management_probe::PASSWORD_VALUE.into()).unwrap(),
        )
        .unwrap();
    assert_ne!(new_lease.id(), old_lease.id());
    assert_eq!(new_lease.principal_id(), old_lease.principal_id());
    app.lease = Some(new_lease);
    app.screen = Screen::Home;
    app.event(Event::Submit(TO_MATERIALS, FormData::new()))
        .unwrap();
    let mut form = FormData::new();
    form.insert(
        materials_editor::TEACHER,
        scope.teacher_id.get().to_string(),
    )
    .unwrap();
    form.insert(
        materials_editor::SUBJECT,
        scope.subject_id.get().to_string(),
    )
    .unwrap();
    app.material_event(materials_editor::LOAD, form).unwrap();
    wait_for(&mut app, |app| app.pending.is_none());
    assert!(
        app.native_unknown,
        "a fresh lease and current directory do not prove the original batch result"
    );
    assert_eq!(app.native_command.as_ref(), Some(&original));
    assert!(!app
        .view()
        .actions
        .iter()
        .any(|action| action.id == materials_editor::IMPORT && action.enabled));
    app.material_event(materials_editor::QUERY_BATCH, FormData::new())
        .unwrap();
    wait_for(&mut app, |app| app.pending.is_none());
    assert!(!app.native_unknown);
    assert_eq!(
        original.snapshot(),
        Some(pair),
        "query never issues a replacement ticket"
    );
    assert_eq!(
        current(&app, scope),
        before,
        "history does not append or alter current files"
    );
    assert!(app
        .view()
        .actions
        .iter()
        .any(|action| action.id == materials_editor::DISMISS_BATCH && action.enabled));
    drain(app);
}
#[test]
fn invalid_second_file_keeps_directory_empty_and_reclaims_all_uncommitted_blobs() {
    let _serial = SERIAL.lock().unwrap();
    let (_scratch, mut app, scope) = initialized();
    let first = selection(&app, "valid.txt", b"validated but uncommitted");
    let bad = selection(&app, "broken.png", b"this is not an image");
    let before = current(&app, scope);
    confirm(&mut app, scope, vec![first, bad]);
    wait_for(&mut app, |app| app.pending.is_none());
    assert_eq!(current(&app, scope), before);
    assert!(
        !app.native_unknown,
        "the worker knows it never called the batch Writer"
    );
    assert!(app.status.contains("整批未送交目录写入"));
    let files = fc_windows::materials::files::ControlledFiles::new(&app.root).unwrap();
    let staging = files.directory(&["staging".into()]).unwrap();
    assert!(files.entries(&staging, 128).unwrap().is_empty());
    // Parent ID directories may remain, but no prepared inode can survive.
    fn file_count(path: &std::path::Path) -> usize {
        if !path.exists() {
            return 0;
        }
        fs::read_dir(path)
            .unwrap()
            .map(|entry| {
                let path = entry.unwrap().path();
                if path.is_dir() {
                    file_count(&path)
                } else {
                    1
                }
            })
            .sum()
    }
    assert_eq!(file_count(&app.root.join("teachers")), 0);
    app.material_event(materials_editor::DISMISS_BATCH, FormData::new())
        .unwrap();
    assert!(app
        .view()
        .actions
        .iter()
        .any(|action| action.id == materials_editor::IMPORT && action.enabled));
    drain(app);
}
