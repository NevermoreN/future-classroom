from pathlib import Path
import hashlib,json,os,re,signal,subprocess,time
R=Path('/tmp/fc-round80-controlled-repair');D=Path(__file__).resolve().parent;F=D.parent;S=F/'source';T=F/'host-target';assert T.is_dir() and (T/'.owner').read_text()=='future-classroom-p3-08-host/v1\n';assert json.loads((F/'host-checks/report.json').read_text())['status']=='PASS';tmp=D/'test-temp';tmp.mkdir();(tmp/'.owner').write_text('future-classroom-final-host-fixtures/v1\n');inputs=F/'inputs.json';rows=json.loads(inputs.read_text())['files']
def same():return all((S/r['path']).stat().st_size==r['bytes']and hashlib.sha256((S/r['path']).read_bytes()).hexdigest()==r['sha256']for r in rows)
assert same();started=time.monotonic();deadline=started+3600;env=os.environ.copy();env.pop('RUSTFLAGS',None);env.pop('CARGO_ENCODED_RUSTFLAGS',None);env.pop('FC_OWNED_REMOVAL_SCOPE_HEX',None);env.pop('FC_OWNED_TEST_SCOPE',None);env.update(CARGO_TARGET_DIR=str(T),CARGO_BUILD_JOBS='2',CARGO_TERM_COLOR='never',TMPDIR=str(tmp),TMP=str(tmp),TEMP=str(tmp));report={'status':'RUNNING','scope':'P3-08 atomic batch+native source: actual complete Linux host workspace all-targets harnesses with at most two test threads; not Windows runtime evidence.','inputsSha256':hashlib.sha256(inputs.read_bytes()).hexdigest(),'globalBudgetSeconds':3600,'operations':[],'harnesses':[]}
def save():(D/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,argv,limit):
 available=min(limit,deadline-time.monotonic());assert available>0;start=time.monotonic();timeout=False
 with(D/(label+'.stdout.log')).open('xb')as out,(D/(label+'.stderr.log')).open('xb')as err:
  p=subprocess.Popen(argv,cwd=S,env=env,stdout=out,stderr=err,start_new_session=True)
  try:code=p.wait(timeout=available)
  except subprocess.TimeoutExpired:
   timeout=True
   try:assert os.getpgid(p.pid)==p.pid;os.killpg(p.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   code=p.wait()
 report['operations'].append({'label':label,'argv':argv,'pid':p.pid,'actualExit':code,'timedOut':timeout,'originalReaped':p.poll()is not None,'seconds':time.monotonic()-start});save();print(label,code,flush=True);return code
save();code=run('compile',['cargo','test','--release','--locked','--offline','--workspace','--all-targets','--no-run','--message-format=json'],900)
if code:report.update(status='FAIL_COMPILE_RETAIN_ORIGINALS',sourceAfterEqual=same());save();raise SystemExit(code)
messages=[json.loads(l)for l in(D/'compile.stdout.log').read_text().splitlines()if l.strip()];art=[m for m in messages if m.get('reason')=='compiler-artifact'and m.get('executable')and m['profile']['test']is True];seen=set()
for i,m in enumerate(art):
 p=Path(m['executable']);assert str(p).startswith(str(T)+'/')and p not in seen;seen.add(p);raw=p.read_bytes();assert raw[:4]==b'\x7fELF';row={'target':m['target']['name'],'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'compilerArtifact':m};report['harnesses'].append(row);save();label=f'harness-{i:02}';assert run(label+'-list',[str(p),'--list'],60)==0;listed=[l[:-6]for l in(D/(label+'-list.stdout.log')).read_text().splitlines()if l.endswith(': test')];row['declaredTests']=listed;code=run(label,[str(p),'--test-threads=2'],1800);summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', (D/(label+'.stdout.log')).read_text(errors='replace'),re.M);row['actualExit']=code;row['summaries']=summaries;row['functionalTestCount']=len(listed);row['zeroTestHarness']=len(listed)==0;row['binaryAfterEqual']=hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];assert row['binaryAfterEqual'];save()
 if code==0:assert len(summaries)==1 and int(summaries[0][2])==0 and int(summaries[0][5])==0 and int(summaries[0][1])+int(summaries[0][3])==len(listed)
run('self-check',['cargo','run','--release','--locked','--offline','-p','fc-bootstrap','--','--self-check'],900)
run('clippy',['cargo','clippy','--release','--locked','--offline','--workspace','--all-targets','--','-D','warnings'],900)
report['sourceAfterEqual']=same();report['status']='PASS_FINAL_HOST_WORKSPACE_TESTS_AND_STRICT_CHECKS'if all(o['actualExit']==0 and not o['timedOut']for o in report['operations'])and report['sourceAfterEqual']else'FAIL_RETAIN_ORIGINALS';report['seconds']=time.monotonic()-started;save();print(report['status'],flush=True)
