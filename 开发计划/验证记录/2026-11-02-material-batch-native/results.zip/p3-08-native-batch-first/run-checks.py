from pathlib import Path
import hashlib,json,os,subprocess,sys,time
D=Path(__file__).resolve().parent;S=D/'source';kind=sys.argv[1];assert kind in ('host','gnu');O=D/(kind+'-checks');O.mkdir();T=D/(kind+'-target');T.mkdir();(T/'.owner').write_text('future-classroom-p3-08-'+kind+'/v1\n');rows=json.loads((D/'inputs.json').read_text())['files']
def same():return all((S/r['path']).stat().st_size==r['bytes'] and hashlib.sha256((S/r['path']).read_bytes()).hexdigest()==r['sha256']for r in rows)
assert same();env=os.environ.copy()
for key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','FC_OWNED_REMOVAL_SCOPE_HEX','FC_OWNED_TEST_SCOPE']:env.pop(key,None)
env.update(CARGO_TARGET_DIR=str(T),CARGO_BUILD_JOBS='2'if kind=='host'else'1',CARGO_TERM_COLOR='never')
if kind=='gnu':env['RUSTFLAGS']='-C target-feature=+crt-static -C link-arg=-Wl,--major-subsystem-version,6,--minor-subsystem-version,1'
argv=['cargo','clippy','--release','--locked','--offline']+(['--target','i686-pc-windows-gnu']if kind=='gnu'else[])+['--workspace','--all-targets','--','-D','warnings'];report={'status':'RUNNING','argv':argv,'inputsSha256':hashlib.sha256((D/'inputs.json').read_bytes()).hexdigest(),'scope':'strict compile checks only; tests and Windows runtime not yet run'}
def save():(O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
start=time.monotonic();save()
with(O/'stdout.log').open('xb')as out,(O/'stderr.log').open('xb')as err:
 p=subprocess.Popen(argv,cwd=S,env=env,stdout=out,stderr=err);report['pid']=p.pid;save();code=p.wait()
report.update(status='PASS'if code==0 and same()else'FAIL_RETAIN_ORIGINAL',actualExit=code,seconds=time.monotonic()-start,sourceAfterEqual=same());save();print(json.dumps(report),flush=True)
