from pathlib import Path
import hashlib,json,os,re,signal,subprocess,sys,time
D=Path(__file__).resolve().parent;B=D.parent;S=D/'source';kind=sys.argv[1];assert kind in ('host','gnu');P=B/'p3-08-native-batch-second';prior=json.loads((P/('host-runtime'if kind=='host'else'windows-test-build')/'report.json').read_text());assert prior['status']!='RUNNING';assert kind!='gnu'or prior['status']=='PASS_WINDOWS_TEST_BUILD_ONLY_NOT_RUN';T=B/'p3-08-native-batch-first'/(kind+'-target');assert (T/'.owner').read_text()=='future-classroom-p3-08-'+kind+'/v1\n';O=D/(kind+'-library');O.mkdir();tmp=O/'test-temp';tmp.mkdir();(tmp/'.owner').write_text('future-classroom-p3-08-fixture-'+kind+'/v1\n');rows=json.loads((D/'inputs.json').read_text())['files']
def same():return all((S/r['path']).stat().st_size==r['bytes']and hashlib.sha256((S/r['path']).read_bytes()).hexdigest()==r['sha256']for r in rows)
assert same();env=os.environ.copy()
for key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','FC_OWNED_REMOVAL_SCOPE_HEX','FC_OWNED_TEST_SCOPE']:env.pop(key,None)
env.update(CARGO_TARGET_DIR=str(T),CARGO_BUILD_JOBS='2'if kind=='host'else'1',CARGO_TERM_COLOR='never',TMPDIR=str(tmp),TMP=str(tmp),TEMP=str(tmp))
if kind=='gnu':env['RUSTFLAGS']='-C target-feature=+crt-static -C link-arg=-Wl,--major-subsystem-version,6,--minor-subsystem-version,1'
report={'status':'RUNNING','scope':'S3 fixes ONLY one cfg(test) Backend fixture. Verify affected Bootstrap library; other S2 programs remain independently qualified, no single-source full-suite claim.','inputsSha256':hashlib.sha256((D/'inputs.json').read_bytes()).hexdigest(),'operations':[]}
def save():(O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,argv,limit):
 start=time.monotonic();timeout=False
 with(O/(label+'.stdout.log')).open('xb')as out,(O/(label+'.stderr.log')).open('xb')as err:
  p=subprocess.Popen(argv,cwd=S,env=env,stdout=out,stderr=err,start_new_session=True);report['currentPid']=p.pid;report['currentLabel']=label;save()
  try:code=p.wait(timeout=limit)
  except subprocess.TimeoutExpired:timeout=True;os.killpg(p.pid,signal.SIGKILL);code=p.wait()
 report['operations'].append({'label':label,'argv':argv,'actualExit':code,'timedOut':timeout,'seconds':time.monotonic()-start,'originalReaped':p.poll()is not None});save();print(label,code,flush=True)
 if code or timeout:report.update(status='FAIL_RETAIN_ORIGINALS',sourceAfterEqual=same());save();raise SystemExit(1)
 return code
extra=['--target','i686-pc-windows-gnu']if kind=='gnu'else[]
run('clippy',['cargo','clippy','--release','--locked','--offline',*extra,'-p','fc-bootstrap','--lib','--tests','--','-D','warnings'],900)
run('compile',['cargo','test','--release','--locked','--offline',*extra,'-p','fc-bootstrap','--lib','--no-run','--message-format=json'],1800)
a=[]
for l in(O/'compile.stdout.log').read_text().splitlines():
 m=json.loads(l)
 if m.get('reason')=='compiler-artifact'and m.get('executable')and m['profile']['test']is True and m['target']['name']=='fc_bootstrap':a.append(m)
assert len(a)==1;exe=Path(a[0]['executable']);raw=exe.read_bytes();report['artifact']={'name':'fc_bootstrap','path':str(exe),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'compilerArtifact':a[0]};save()
if kind=='host':
 assert raw[:4]==b'\x7fELF';run('list',[str(exe),'--list'],60);declared=[l[:-6]for l in(O/'list.stdout.log').read_text().splitlines()if l.endswith(': test')];run('tests',[str(exe),'--test-threads=2'],1800);summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', (O/'tests.stdout.log').read_text(errors='replace'),re.M);assert len(summaries)==1 and int(summaries[0][2])==0 and int(summaries[0][5])==0 and int(summaries[0][1])+int(summaries[0][3])==len(declared);report['summaries']=summaries;report['declaredTests']=len(declared)
else:assert raw[:2]==b'MZ'
report['sourceAfterEqual']=same();report['artifactAfterEqual']=hashlib.sha256(exe.read_bytes()).hexdigest()==report['artifact']['sha256'];report['status']='PASS_HOST_BOOTSTRAP_LIBRARY'if kind=='host'else'PASS_WINDOWS_LIBRARY_BUILD_ONLY_NOT_RUN';assert report['sourceAfterEqual']and report['artifactAfterEqual'];save();print(report['status'],flush=True)
