from pathlib import Path
import ast, hashlib, json, subprocess, zipfile, shutil, os, stat
R=Path('/tmp/fc-round80-controlled-repair'); D=R/'p3-08-web-batch-next'; W=Path.cwd(); E=W/'开发计划/验证记录/2026-11-02-material-batch-native'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert (D/'.owner').read_text()=='future-classroom-p3-08-web-batch-next/v1\n'
binding=json.loads((D/'main-integration.json').read_bytes())
for p in binding['codePaths']: assert (W/p).read_bytes()==(D/'source'/p).read_bytes(),p
for x in binding['scripts']: assert sha((W/x['path']).read_bytes())==x['sha256'],x['path']
# Correct the single stale overview; retain all historical phase results below.
p=W/'开发计划/10-实施进度与验证记录.md'; t=p.read_text(); old='教师Web批次正处理真实浏览器前置发现的语音设置保存缺陷，尚未完成批次DOM闭环。'; new='教师Web批次及语音保存修正已在授权Win11完成真实HTTPS浏览器有限闭环，接续批量删除与旧资料迁移。'; assert t.count(old)+t.count(new)==1;p.write_text(t.replace(old,new))
(D/'main-docs.patch').write_bytes(subprocess.check_output(['git','diff','--','开发计划/10-实施进度与验证记录.md','开发计划/13-教师课堂资料API契约.md','开发计划/模块/08-三级权限与教师文件夹打开.md']))
items={}
def add(p,name):
 assert p.is_file() and not p.is_symlink(),str(p)
 b=p.read_bytes();assert len(b)<=5*1024*1024,(str(p),len(b))
 # Evidence is text. Never include payloads, databases, executables or archives.
 try:b.decode('utf-8-sig')
 except UnicodeError:raise AssertionError('non-text evidence: '+str(p))
 assert name not in items;items[name]=(p,b)
def tree(root,prefix):
 for p in sorted(root.rglob('*')):
  if p.is_file() and p.suffix.lower() not in ['.wav','.exe','.zip','.db','.sqlite','.cer','.pfx']: add(p,prefix+'/'+p.relative_to(root).as_posix())
for p in sorted(D.iterdir()):
 if p.is_dir() and (p.name.startswith('checks-') or p.name.startswith('frontend-evidence-') or p.name in ['windows-third','windows-fifth','windows-eighth','compat-helper-fix','main-final-checks']):tree(p,'teacher-web/'+p.name)
for n in ['INTERFACES.md','base-inputs.json','candidate-inputs.json','main-integration.json','main-implementation.patch','main-docs.patch']:
 add(D/n,'teacher-web/'+n)
B=D/'browser-batch-probe'
for p in sorted(B.iterdir()):
 if p.is_file() and p.suffix!='.zip':add(p,'teacher-web/browser/'+p.name)
 elif p.is_dir():tree(p,'teacher-web/browser/'+p.name)
for n in ['p3-08-web-protocol-implementation-first','p3-08-web-aggregate-implementation-first']:tree(R/n,'teacher-web/implementation/'+n)
C=R/'native-batch-msvc-dispatch-first'
for p in sorted(C.iterdir()):
 if p.is_file() and p.suffix!='.zip':add(p,'teacher-web/previous-native-ci/'+p.name)
add(Path(__file__),'teacher-web/finish-teacher-web-batch.py')
# Reuse the prior bounded credential scanner's exact recursive text-view logic.
scanner=R/'root-scan-d13-credential-views-first.py'; mod=ast.parse(scanner.read_text()); keep=[]
for node in mod.body:
 if isinstance(node,(ast.Import,ast.ImportFrom)):keep.append(node)
 elif isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ['patterns','stats','hits'] for t in node.targets):keep.append(node)
 elif isinstance(node,ast.FunctionDef) and node.name=='scan':keep.append(node)
ns={};exec(compile(ast.Module(body=keep,type_ignores=[]),str(scanner),'exec'),ns)
for n,(p,b) in items.items():ns['scan'](b,n)
assert not ns['hits'],[(x['path'],x['rule'])for x in ns['hits']]
prior=(E/'results.zip').read_bytes(); assert sha(prior)=='5fa129dc3d8eaf9af8ef140b9934a0ae37f20a92de4b0d83e25ec71e1fe665ff'
old={}
with zipfile.ZipFile(E/'results.zip') as z:
 for n in z.namelist():assert n not in old;old[n]=z.read(n)
assert len(old)==328 and not set(old)&set(items)
assert len(old)+len(items)+1<=1500
assert sum(map(len,old.values()))+sum(len(x[1]) for x in items.values())<30*1024*1024
out=R/'teacher-web-combined-precleanup.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in old.items():z.writestr(n,b)
 for n,(_,b) in items.items():z.writestr(n,b)
with zipfile.ZipFile(out) as z:
 assert len(z.namelist())==len(old)+len(items)
 for n,b in old.items():assert z.read(n)==b
 for n,(_,b) in items.items():assert z.read(n)==b
index={n:{'original':str(p),'bytes':len(b),'sha256':sha(b)} for n,(p,b) in items.items()}
report={'status':'PASS_PRE_CLEANUP_SOURCE_REPLAY','priorMembers':328,'newMembers':len(items),'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'scannerStats':ns['stats'],'findings':0,'sources':index}
(R/'teacher-web-preservation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='sources'}))
