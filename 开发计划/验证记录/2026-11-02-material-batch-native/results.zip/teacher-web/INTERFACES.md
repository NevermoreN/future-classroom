# P3-08 Web batch implementation contract

Only edit the isolated `source` tree beside this file. Main and immutable S4 are not writable lanes. Root integrates verified changes after the native batch round sync. Preserve the twelve-crate direction, existing single-file clients and all existing permission/command guards.

Product: select 1–20 files, review/reorder/remove before upload, capture scope and allowed classes, upload serially within one bounded group, prepare every file, one atomic Writer COMMIT, show the original batch result independently of the current directory. Last confirmed member gets the newest sequence. No repeated single-file commits. No automatic retry/new command on UNKNOWN, NOT_FOUND, cancellation or expiry. Use clear Chinese product copy without implementation jargon.

## Wire and frontend agreement

All IDs are canonical nonzero decimal strings, tickets use the existing exact C2 grammar. Existing JSON 64KiB limit applies. Normal non-command envelopes use schemaVersion 1; command mutation/results use schemaVersion 2 with mandatory original commandId+commandTicket. Unlisted fields, duplicate IDs, invalid count/format/size/scope are rejected.

- POST `materials/batches/{ownerTeacherId}/{subjectId}`: `{schemaVersion:1,files:[{displayName,bytes}],allowedClassIds:[...]}`. Fixed original manifest 1..20, existing per-file limits. Response `{schemaVersion:1,status:"MATERIAL_BATCH_READY",batchId,expiresInSeconds:300,maxChunkBytes:65536,items:[{uploadId,displayName,bytes}]}`. uploadId equals member resourceVersionId, same as existing single-file semantics. Order and exact names/sizes correlate to request. Classes become immutable with this group.
- POST `materials/batches/{batchId}/files/{uploadId}/bytes`: existing bounded octet streaming transport. Response `{schemaVersion:1,status:"MATERIAL_BATCH_MEMBER_UPLOADED",batchId,uploadId,bytes}`. Only one member transfer at a time per group; all original byte/hash/WIC/PDF/Office checks remain.
- POST `materials/batches/{batchId}/cancel`: `{schemaVersion:1}`. Confirmed response `{schemaVersion:1,status:"MATERIAL_BATCH_CANCELLED",batchId}` only after actual whole-group negative cleanup. Never cancels a saved COMMIT.
- POST `materials/folders/{ownerTeacherId}/{subjectId}/append-batch`: `{schemaVersion:2,commandId,commandTicket,batchId,uploadIds:[...],allowedClassIds:[...]}`. Ordered IDs/classes must equal original confirmed group, all prepared. Acquire one Materials command pair only on explicit append after upload. Response `{schemaVersion:2,status:"BATCH_COMMITTED",commandId,commandTicket,scope,records:[...]}`.
- GET `materials/batch-commands/{ownerTeacherId}/{subjectId}/{commandTicket}/{commandId}`: `{schemaVersion:2,status:"COMMAND_BATCH_RESULT",commandId,commandTicket,state:"COMMITTED",scope,records:[...]}` or same envelope with state NOT_FOUND and scope/records null. Resolve original scope/owner/family/full pair and query historical receipt first; do not require a live upload group for a saved receipt. NOT_FOUND never authorizes replay. Existing Backend `web_material_batch_outcome_window(lease,scope,command_id,ticket)` supplies this.

Frontend verifies every returned record against the original ordered names/sizes/uploadIds/classes, common folder/time, unique IDs/resources, continuous sequences, Published/revision1; uses exact BigInt IDs. History is not a current-page replacement. New batch paths do not replace legacy single endpoints.

## Shared Rust names

Protocol lane owns `MaterialRoute` additions: `BatchUploadCreate { scope }`, `BatchUploadBytes { batch_id:u64, upload_id:u64 }`, `BatchUploadCancel { batch_id:u64 }`, `BatchAppend { scope }`, `BatchWindowCommand { scope, command:CommandReference }`. `post`/body limits include these correctly.

Protocol public DTOs: `BatchFileInput { display_name:String, bytes:u64 }`; `BatchUploadInput { files:Vec<BatchFileInput>, allowed_class_ids:Vec<ClassId> }`; `BatchAppendInput { command_id:CommandId, command_ticket:CommandTicket, batch_id:u64, upload_ids:Vec<u64>, allowed_class_ids:Vec<ClassId> }`. Parsers `batch_upload(body)`, `batch_append(body)`; cancellation reuses strict `cancel(body)`.

Application dispatch calls aggregate lane methods `material_batch_create(backend,lease,scope,input)`, `material_batch_cancel(lease,batch_id)`, `material_batch_append(backend,lease,scope,input)` returning WebResponse, Windows cfg only. History uses existing Backend and protocol serializer. Aggregate lane owns production streaming/worker interception for new bytes/append paths; do not perform preparation under the Backend lock.

Protocol serializers (return existing `Result<Vec<u8>,ProtocolError>`): `BatchReadyMember<'a> { upload_id:u64, display_name:&'a str, bytes:u64 }`; `batch_ready(batch_id, &[BatchReadyMember])`; `batch_member_uploaded(batch_id,upload_id,bytes)`; `batch_cancelled(batch_id)`; `batch_committed(command:CommandReference,scope,records:&[MaterialRecord])`; `batch_command_window(command:CommandReference,outcome:Option<(MaterialScope,&[MaterialRecord])>)`.

Protocol lane supplies a conservative pre-COMMIT wire-size check helper using prepared append metadata and worst-case decimal lengths/folder/sequence envelope, to prevent a successful commit whose 64KiB result can never be encoded. Coordinate exact helper signature with aggregate lane, keeping native core receipt limits unchanged.

## Physical ownership

Keep 2 existing aggregate owners/physical permits and 2 Hub slots. Each private group owns at most20 bounded members and at most one current transfer; keep original file objects/inode/pins, member exact RequestToken, group serial and absolute deadline. No per-member permit replacement or early slot return, no additional pool/thread. Temporary accounting is separate and explicitly bounded at 2×20×50MiB=2000MiB; pictures remain10MiB and all other validators unchanged. Managed originals+Retiring+profile media keep existing independent2GiB Writer check, no invented SQL staging reservation or claim whole directory<=2GiB.

COMMIT-before failure cleans whole uncommitted group. UNKNOWN/cancel/TTL never proves rollback. Failed exact cleanup transfers original group permit and remaining bounded owners to existing quarantine. Existing group IDs are not bearer permissions. Revalidate same original Web lease/scope/current authority at every transition. Original receipt query and actual physical return govern unknown retirement. Startup staging enumeration must accommodate marker+at most40 group members with closed names/ownership checks; never unbounded scan/adopt foreign files.

LockedFile owns file+up to64 ancestor pins, not only one handle.40 prepared pins have a static upper bound2600 handles plus bounded transient overhead; no unrelated installer64 limit applies. Root will measure real Win11 resource/cleanup behavior. Win7/10 actual runtime and Seewo remain NOT_RUN. Avoid unrelated LockedFile optimization.

## Disjoint lanes

- Frontend: `web/src/MaterialsPane.tsx`, `web/src/api/material-{controller,client,protocol}.ts`, existing corresponding tests and styles only if needed. Run locked npm/typecheck/tests/build only in isolated source/web.
- Protocol+dispatch: `crates/fc-protocol/src/web/materials.rs` (child module allowed), `crates/fc-bootstrap/src/web_application/materials.rs`, existing corresponding protocol tests. No Cargo/Windows/Git.
- Aggregate: `crates/fc-bootstrap/src/web_application/{material_files,shared_upload}.rs` (child allowed), `crates/fc-bootstrap/src/web_transfer/{uploads,upload_work,network}.rs`, existing dedicated tests. Own whole file+Hub lifecycle. No Cargo/Windows/Git.
- Root: `web_application.rs`, `web_transfer.rs` or other common reexports/exhaustive matches if needed; final integration, actual Cargo/Windows, cleanup/sync. Report required root edits by exact location; do not touch them independently.
