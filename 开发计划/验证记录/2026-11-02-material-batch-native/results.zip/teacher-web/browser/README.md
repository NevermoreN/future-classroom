# 有限真实浏览器批量测试准备

状态：NOT_RUN。脚本沿用原 G03 的真实普通教师 DOM 配对、同源 HTTPS、隐藏 Edge 独占 Job、私有 stdin、合成全零 WAV、civil-clock 与精确 cleanup。正常产品/Rust/主树没有修改，所有 Windows 操作仅由 root 执行。

## Root 执行入口

把 `TEST_EXE` 指向本次真正同源 GNU normal GUI 产物；不使用 test-profile PE。以下路径均为本独立目录，report 必须尚不存在：

```bash
TEST_EXE=/absolute/path/to/actual-normal-future-classroom.exe
python3 -B /tmp/fc-round80-controlled-repair/p3-08-web-batch-next/browser-batch-probe/windows-teacher-browser-probe.py \
  --execute --ssh-target future-classroom-win11 \
  --exe "$TEST_EXE" \
  --old-web-bundle /tmp/fc-round80-controlled-repair/p3-08-web-batch-next/browser-batch-probe/old-web-bundle.zip \
  --new-web-bundle /tmp/fc-round80-controlled-repair/p3-08-web-batch-next/browser-batch-probe/new-web-bundle.zip \
  --report /tmp/fc-round80-controlled-repair/p3-08-web-batch-next/browser-batch-probe/runtime-first.json
```

不带 `--execute` 返回 DEFAULT_INERT。`SUPPORT` 固定为此目录的 sibling `source/scripts`，原 executable support pins 保留；本副本暂不具备移植后的路径合同。root 未来移入正式 scripts 时应独立记录 SUPPORT 映射差异，不能直接把当前 wholefile 覆盖产品。

## 实际测试顺序

1. 真实旧 bundle 配对普通教师。完整保留原单文件上传取消、无提前提交、再次上传、保存、浏览器下载逐字节校验、删除及当前目录空读回；原 `materials()` 逻辑没有改。
2. 原 CACHE_UPGRADE 原生 action：真 drain、不同正常 bundle、同 HTTPS origin、原身份失效、第二次真实 DOM 配对。不是把两次相同字节称作升级。
3. 原作业、提醒、原 pair UNKNOWN 查询、离线无重放。
4. 新 bundle 真实 multiple 输入选择20个固定合成TXT，移除第20项确认19，再重新选20；通过真实鼠标下移第1项、上移第3项，最终确认顺序02、03、01、04..20。此阶段没有上传或命令 POST。
5. 选择真实任教班级后创建1组，20件串行上传；用真实 Network finish/start 事件核前件完成先于后件开始。全部上传完成前没有发行命令/提交，上传后顺序与班级输入冻结。
6. 点击一次“校验并整批添加”：真实发行1个 Materials pair、1个 append-batch。逐个核原名字、bytes、SHA、uploadId/版本、班级、PUBLISHED/revision1、唯一ID、同folder/time、连续原序号。原单文件先添加/删除留下的历史序号不归零；首序号不写死1。
7. 真实点击查询原批结果，核完整pair/scope/全部20条原记录；再明确读当前目录，核folder revision恰+1、20条全等且倒序，实际DOM顺序最后确认者在前。历史结果不能替换当前目录，也不允许自动再提交。
8. 原语音合成录音/原物理 owner 归还、隔离跨日、真实撤权、原 native/Edge/TLS/certificate/key/owned root cleanup继续执行。20个44B TXT仅放原受保护TLS nonce；全部列入原CAPTURE/RAW_NAMES后才允许清理。

## 本地实际资格及限制

- old-web-copy：main当前68件Web输入与原base逐SHA相同；锁文件离线npm ci、typecheck、正常build/license/budget全部0，输入前后相同。原日志在 sibling `old-web-copy`。
- new包直接使用前端最终353测试通过的dist，没有重复构建。两个ZIP只有标准`web/fc-assets.json`和原manifest声明资产，经既有read_web_package重新逐件核size/SHA；身份见bundle-report.json。
- 本目录仅完成 Python AST、node --check、默认inert检查；无Windows/DOM/API运行通过声明。原128请求、120秒、8MiB/5MiB缓存、65536事件界限均保持，超限会失败关闭。
- Root必须保留实际失败与cleanup结果；前端353 synthetic测试不等于这次实测。Win7/Win10与希沃真机保持NOT_RUN。
