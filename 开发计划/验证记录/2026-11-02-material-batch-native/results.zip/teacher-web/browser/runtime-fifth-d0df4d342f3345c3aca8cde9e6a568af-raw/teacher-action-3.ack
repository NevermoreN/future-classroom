{"type":"ACK","action":"REVOKE","marker":"FutureClassroom-Test-TLS-d0df4d342f3345c3aca8cde9e6a568af","status":"PASS","actualIdentityWrite":true,"teacherLogin":"synthetic-ordinary-teacher"}
