{"type":"ACK","action":"VOICE_SETTLED","marker":"FutureClassroom-Test-TLS-d0df4d342f3345c3aca8cde9e6a568af","status":"PASS","activeJobs":0,"audioOwnerReturned":true}
