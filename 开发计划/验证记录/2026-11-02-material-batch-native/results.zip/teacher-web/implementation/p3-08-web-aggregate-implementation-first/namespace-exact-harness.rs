const MAX_MATERIAL_BATCH_FILES:usize=20;
fn valid_stage_name(name: &str) -> bool {
    let canonical = |s: &str| {
        s.parse::<u64>()
            .ok()
            .filter(|id| *id != 0)
            .is_some_and(|id| s == id.to_string())
    };
    let Some(inner) = name
        .strip_prefix("web-material-")
        .and_then(|s| s.strip_suffix(".part"))
    else {
        return false;
    };
    if let Some(batch) = inner.strip_prefix("batch-") {
        batch
            .split_once('-')
            .is_some_and(|(group, member)| canonical(group) && canonical(member))
    } else {
        canonical(inner)
    }
}
fn valid_stage_set<'a>(names: impl IntoIterator<Item = &'a str>) -> bool {
    let mut groups = std::collections::BTreeMap::<String, usize>::new();
    let mut total = 0usize;
    for name in names {
        if !valid_stage_name(name) {
            return false;
        }
        let body = name
            .strip_prefix("web-material-")
            .and_then(|s| s.strip_suffix(".part"))
            .expect("validated name");
        let (owner, limit) = if let Some(batch) = body.strip_prefix("batch-") {
            let (group, _) = batch.split_once('-').expect("validated batch");
            (format!("b{group}"), MAX_MATERIAL_BATCH_FILES)
        } else {
            (format!("s{body}"), 1)
        };
        let count = groups.entry(owner).or_default();
        *count += 1;
        total += 1;
        if *count > limit || groups.len() > 2 || total > 2 * MAX_MATERIAL_BATCH_FILES {
            return false;
        }
    }
    true
}
#[cfg(test)]
mod namespace_tests {
    use super::*;
    #[test]
    fn startup_accepts_only_two_owned_groups_and_forty_canonical_members() {
        let names = (1..=2)
            .flat_map(|group| {
                (1..=20).map(move |member| format!("web-material-batch-{group}-{member}.part"))
            })
            .collect::<Vec<_>>();
        assert!(valid_stage_set(names.iter().map(String::as_str)));
        for bad in [
            "web-material-batch-01-1.part",
            "web-material-batch-1-0.part",
            "web-material-batch-1-1.part.exe",
            "web-material-batch-1-1-2.part",
            "foreign.txt",
        ] {
            assert!(!valid_stage_set([bad]));
        }
        assert!(!valid_stage_set([
            "web-material-batch-1-1.part",
            "web-material-batch-2-1.part",
            "web-material-batch-3-1.part"
        ]));
        let excess = (1..=21)
            .map(|member| format!("web-material-batch-1-{member}.part"))
            .collect::<Vec<_>>();
        assert!(!valid_stage_set(excess.iter().map(String::as_str)));
        assert!(valid_stage_set([
            "web-material-1.part",
            "web-material-batch-2-1.part"
        ]));
        assert!(!valid_stage_set([
            "web-material-1.part",
            "web-material-2.part",
            "web-material-batch-3-1.part"
        ]));
    }
}
