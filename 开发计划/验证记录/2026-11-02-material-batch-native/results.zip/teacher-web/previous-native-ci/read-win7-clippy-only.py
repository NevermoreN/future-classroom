from pathlib import Path
import hashlib,json,os,signal,subprocess,time,urllib.request,urllib.error,zipfile
D=Path(__file__).resolve().parent
signal.signal(signal.SIGALRM,lambda *_: (_ for _ in ()).throw(TimeoutError('artifact total120s')));signal.alarm(120)
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*a,**k):return None
env=os.environ.copy();env['GIT_TERMINAL_PROMPT']='0'
c=subprocess.run(['git','credential','fill'],input=b'protocol=https\nhost=github.com\n\n',capture_output=True,env=env,timeout=20);assert c.returncode==0
fields=dict(x.split(b'=',1)for x in c.stdout.splitlines()if b'='in x);token=fields[b'password'].decode()
url='https://api.github.com/repos/NevermoreN/future-classroom/actions/artifacts/13137851127/zip'
req=urllib.request.Request(url,headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','User-Agent':'future-classroom-ci-diagnostic'})
try:urllib.request.build_opener(NoRedirect()).open(req,timeout=20);raise RuntimeError('expected signed redirect')
except urllib.error.HTTPError as e:
 assert e.code==302;location=e.headers['Location']
# Signed artifact request receives no Git credential or Authorization header.
p=D/'native-faaa-win7.zip';assert not p.exists()
raw=bytearray()
with urllib.request.urlopen(location,timeout=20)as f:
 while True:
  chunk=f.read(65536)
  if not chunk:break
  raw.extend(chunk);assert len(raw)<=128*1024*1024
assert hashlib.sha256(raw).hexdigest()=='d1c71549beae52c9f8282e3ec03b6e696d074070106da373e074c7dc02efc009'
p.write_bytes(raw);print(json.dumps({'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}),flush=True)
with zipfile.ZipFile(p)as z:
 names=[n for n in z.namelist()if 'clippy'in n.lower()];print(names,flush=True)
 for n in names:
  info=z.getinfo(n);assert info.file_size<=2*1024*1024
  b=z.read(n);out=D/('win7-'+Path(n).name);assert not out.exists();out.write_bytes(b)
  lines=b.decode('utf-8','replace').splitlines()
  for i,line in enumerate(lines):
   if 'error'in line:print('\n'.join(lines[max(0,i-2):min(len(lines),i+12)]),flush=True)
print('CI_DIAGNOSTIC_READ_DONE',flush=True)
