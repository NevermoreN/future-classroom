
#[test]
fn twenty_batch_preserves_atomic_folder_and_desktop_global_revision() {
    use crate::{desktop::DesktopFacts, lesson_context::LessonContextSnapshot, profile::{ProfileSelectionSnapshot, ProfileSelectionReason}};
    let identity = identity();
    let schedule = schedule_fixture(&identity);
    let at = now(30000);
    let context = LessonContextSnapshot::default().observe(&identity, &schedule, at).unwrap();
    let source = context.material_source(&identity, &schedule, class(1), at).unwrap().unwrap();
    let mut state = empty();
    state.folder.revision = Revision::new(1); // A persisted empty folder is one prior operation.
    let global_before = Revision::new(identity.revision.get().max(schedule.revision.get()).max(context.revision.get()) + 1);
    let mut facts = DesktopFacts {
        global_revision: global_before,
        captured_at: at, date_watermark: at.date, clock_rollback: false,
        identity: identity.clone(), schedule, lesson_context: context,
        display: Default::default(),
        profiles: ProfileSelectionSnapshot { reason: ProfileSelectionReason::Missing, ..Default::default() },
        profile_contents: vec![], homework_offset: 0, homework_eligible_total: 0, homework: vec![], reminder: None,
        materials_source: Some(source.clone()), materials_page: None,
    };
    facts.validate().unwrap();
    let appends = (1..=MAX_MATERIAL_BATCH_FILES as u64).map(append).collect::<Vec<_>>();
    let batch = state.append_batch(&appends, &identity, &actor(&identity, 2), at).unwrap();
    facts.global_revision = global_before.next().unwrap(); // One actual atomic Writer operation.
    facts.materials_page = Some(batch.published_page(&identity, &source, None).unwrap());
    eprintln!("global_before={} global_after={} folder_before={} folder_after={} last_sequence={}", global_before.get(),facts.global_revision.get(),state.folder.revision.get(),batch.folder.revision.get(),batch.folder.last_added_sequence);
    assert_eq!(facts.validate(), Ok(()));
    assert_eq!(batch.folder.revision, state.folder.revision.next().unwrap());
    assert_eq!(batch.folder.last_added_sequence, 20);
    assert_eq!(facts.materials_page.as_ref().unwrap().items.iter().map(|r|r.added_sequence).collect::<Vec<_>>(),vec![20,19,18,17,16]);
    // The global relationship remains strict, independently of sequence count.
    facts.materials_page.as_mut().unwrap().folder.revision = facts.global_revision.next().unwrap();
    assert!(facts.validate().is_err());
}
