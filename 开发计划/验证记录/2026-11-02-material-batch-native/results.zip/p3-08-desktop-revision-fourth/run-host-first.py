from pathlib import Path
import hashlib,json,os,re,signal,subprocess,time
D=Path(__file__).resolve().parent;S=D/'source';T=D.parent/'p3-08-native-batch-first/host-target';O=D/'early-desktop-storage';O.mkdir();tmp=O/'test-temp';tmp.mkdir();(tmp/'.owner').write_text('future-classroom-p3-08-desktop-fixture/v1\n')
assert json.loads((D/'host-cache-invalidation/report.json').read_text())['status']=='PASS'
rows=json.loads((D/'inputs.json').read_text())['files']
def same():return all(hashlib.sha256((S/r['path']).read_bytes()).hexdigest()==r['sha256']for r in rows)
assert same();env=os.environ.copy()
for k in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','FC_OWNED_REMOVAL_SCOPE_HEX','FC_OWNED_TEST_SCOPE']:env.pop(k,None)
env.update(CARGO_TARGET_DIR=str(T),CARGO_BUILD_JOBS='2',CARGO_TERM_COLOR='never',TMPDIR=str(tmp),TEMP=str(tmp),TMP=str(tmp))
argv=['cargo','test','--release','--locked','--offline','-p','fc-storage','--lib','low_global_revision_twenty_file_batch_remains_visible_in_real_desktop_facts_and_pages','--','--test-threads=2'];start=time.monotonic();timedout=False
with(O/'stdout.log').open('xb')as out,(O/'stderr.log').open('xb')as err:
 p=subprocess.Popen(argv,cwd=S,env=env,stdout=out,stderr=err,start_new_session=True)
 try:code=p.wait(timeout=900)
 except subprocess.TimeoutExpired:timedout=True;os.killpg(p.pid,signal.SIGKILL);code=p.wait()
stdout=(O/'stdout.log').read_text();summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',stdout,re.M)
r={'status':'PASS'if code==0 and summaries and summaries[0][1:4]==('1','0','0')and same()else'FAIL','actualExit':code,'timedOut':timedout,'originalReaped':p.poll()is not None,'summaries':summaries,'seconds':time.monotonic()-start,'sourceAfterEqual':same(),'scope':'Actual SQLite issued-command twenty-file batch plus real desktop Facts and four cursor pages; counts once in later full suite.'};(O/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
if r['status']!='PASS':raise SystemExit(1)
code=subprocess.call(['python3',str(D/'host-runtime/run.py')]);raise SystemExit(code)
