from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time
D=Path(__file__).resolve().parent;S=D/'source';kind=sys.argv[1];assert kind in ('host','gnu');T=D.parent/'p3-08-native-batch-first'/(kind+'-target');assert (T/'.owner').read_text()=='future-classroom-p3-08-'+kind+'/v1\n'
O=D/(kind+'-cache-invalidation');O.mkdir();env=os.environ.copy();env['CARGO_TARGET_DIR']=str(T)
packages=['fc-domain','fc-ports','fc-runtime','fc-application','fc-storage','fc-security','fc-materials','fc-audio','fc-presentation','fc-protocol','fc-windows','fc-bootstrap']
argv=['cargo','clean','--release']+(['--target','i686-pc-windows-gnu']if kind=='gnu'else[])+[arg for p in packages for arg in ['-p',p]]
start=time.monotonic()
with (O/'stdout.log').open('xb')as out,(O/'stderr.log').open('xb')as err:
 p=subprocess.Popen(argv,cwd=S,env=env,stdout=out,stderr=err,start_new_session=True)
 try:code=p.wait(timeout=120)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
r={'status':'PASS'if code==0 else 'FAIL','argv':argv,'actualExit':code,'originalReaped':p.poll()is not None,'seconds':time.monotonic()-start,'scope':'Only twelve workspace packages in this round owned target; external dependency cache retained. Prevent timestamp-based reuse across source snapshots.'}
(O/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(code)
