from pathlib import Path
import hashlib,json,os,signal,subprocess,time
D=Path(__file__).resolve().parent;F=D.parent;S=F/'source';T=F.parent/'p3-08-native-batch-first/gnu-target';inputs=F/'inputs.json';rows=json.loads(inputs.read_text())['files'];assert (T/'.owner').read_text()=='future-classroom-p3-08-gnu/v1\n'
def same():return all((S/r['path']).stat().st_size==r['bytes']and hashlib.sha256((S/r['path']).read_bytes()).hexdigest()==r['sha256']for r in rows)
assert same();report={'status':'RUNNING','inputsSha256':hashlib.sha256(inputs.read_bytes()).hexdigest(),'sourceScope':'P3-08 fourth immutable source; GUI build after same-input strict checks.','operations':[]}
def save():(D/'report.json').write_text(json.dumps(report,indent=2)+'\n')
env=os.environ.copy();env.pop('CARGO_ENCODED_RUSTFLAGS',None);env.pop('FC_OWNED_REMOVAL_SCOPE_HEX',None);env.pop('FC_OWNED_TEST_SCOPE',None);env.update(CARGO_TARGET_DIR=str(T),CARGO_BUILD_JOBS='1',CARGO_TERM_COLOR='never',RUSTFLAGS='-C target-feature=+crt-static -C link-arg=-Wl,--major-subsystem-version,6,--minor-subsystem-version,1');save()
for label,argv in [('build',['cargo','build','--release','--locked','--offline','--target','i686-pc-windows-gnu','-p','fc-bootstrap','--bin','fc-bootstrap','--message-format=json'])]:
 start=time.monotonic();timeout=False
 with(D/(label+'.stdout.log')).open('xb')as out,(D/(label+'.stderr.log')).open('xb')as err:
  p=subprocess.Popen(argv,cwd=S,env=env,stdout=out,stderr=err,start_new_session=True)
  try:code=p.wait(timeout=900)
  except subprocess.TimeoutExpired:timeout=True;os.killpg(p.pid,signal.SIGKILL);code=p.wait()
 report['operations'].append({'label':label,'argv':argv,'actualExit':code,'timedOut':timeout,'originalReaped':p.poll()is not None,'seconds':time.monotonic()-start});save();print(label,code,flush=True)
 if code:report.update(status='FAIL_RETAIN_ORIGINAL',sourceAfterEqual=same());save();raise SystemExit(code)
 if label=='build':
  messages=[json.loads(l)for l in(D/'build.stdout.log').read_text().splitlines()if l.strip()];a=[x for x in messages if x.get('reason')=='compiler-artifact'and x.get('executable')and x['target']['name']=='fc-bootstrap'and x['profile']['test']is False];assert len(a)==1;p=Path(a[0]['executable']);dest=D/'fc-bootstrap.exe';dest.write_bytes(p.read_bytes());report['executable']={'path':str(dest),'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'compilerArtifact':a[0]};save()
report['sourceAfterEqual']=same();report['status']='PASS_NORMAL_GUI_BUILD'if report['sourceAfterEqual']else'FAIL_SOURCE_CHANGED';save()
