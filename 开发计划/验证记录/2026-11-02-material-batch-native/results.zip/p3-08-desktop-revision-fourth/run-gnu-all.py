from pathlib import Path
import json,subprocess
D=Path(__file__).resolve().parent
assert json.loads((D/'gnu-cache-invalidation/report.json').read_text())['status']=='PASS'
for script,args in [('windows-test-build/run.py',[]),('gnu-product/run.py',[]),('run-checks.py',['gnu'])]:
 code=subprocess.call(['python3',str(D/script),*args])
 if code:raise SystemExit(code)
