from pathlib import Path
import os,signal,subprocess,json,time,hashlib
D=Path(__file__).resolve().parent;F=D.parent;S=F/'source';T=F.parent/'p3-08-native-batch-first/gnu-target';I=F/'inputs.json';rows=json.loads(I.read_text())['files'];assert json.loads((F/'gnu-checks/report.json').read_text())['status']=='PASS';assert (T/'.owner').read_text()=='future-classroom-p3-08-gnu/v1\n'
def same():return all((S/x['path']).stat().st_size==x['bytes'] and hashlib.sha256((S/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in rows)
assert same();env=os.environ.copy()
for key in ['CARGO_ENCODED_RUSTFLAGS','FC_OWNED_REMOVAL_SCOPE_HEX','FC_OWNED_TEST_SCOPE']:env.pop(key,None)
env.update(CARGO_TARGET_DIR=str(T),CARGO_BUILD_JOBS='1',CARGO_TERM_COLOR='never',RUSTFLAGS='-C target-feature=+crt-static -C link-arg=-Wl,--major-subsystem-version,6,--minor-subsystem-version,1');argv=['cargo','test','--release','--locked','--offline','--target','i686-pc-windows-gnu','--workspace','--all-targets','--no-run','--message-format=json'];report={'status':'RUNNING','originalBudgetSeconds':1800,'sourceScope':'P3-08 atomic ordered batch core and native UI, first integrated source','argv':argv,'sourceInputsSha256':hashlib.sha256(I.read_bytes()).hexdigest(),'artifacts':[],'scope':'Only actual compiler test artifacts. Win11 execution follows separately; Win7/Win10 runtime NOT_RUN.'}
def save():(D/'report.json').write_text(json.dumps(report,indent=2)+'\n')
save();started=time.monotonic();timeout=False
with (D/'compile.stdout.log').open('xb') as out,(D/'compile.stderr.log').open('xb') as err:
 child=subprocess.Popen(argv,cwd=S,env=env,stdout=out,stderr=err,start_new_session=True);report['originalPid']=child.pid;save()
 try:code=child.wait(timeout=1800)
 except subprocess.TimeoutExpired:timeout=True;os.killpg(child.pid,signal.SIGKILL);code=child.wait()
report.update(actualExit=code,timedOut=timeout,originalReaped=child.poll() is not None,seconds=time.monotonic()-started,sourceAfterEqual=same())
if code==0 and not timeout:
 seen=set()
 for line in (D/'compile.stdout.log').read_text().splitlines():
  m=json.loads(line)
  if m.get('reason')!='compiler-artifact' or not m.get('executable') or m['profile']['test'] is not True:continue
  p=Path(m['executable']);assert p not in seen and p.suffix=='.exe' and p.is_relative_to(T);seen.add(p);raw=p.read_bytes();assert raw[:2]==b'MZ';report['artifacts'].append({'name':m['target']['name'],'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'compilerArtifact':m})
 assert len(seen)==22,len(seen)
report['status']='PASS_WINDOWS_TEST_BUILD_ONLY_NOT_RUN' if code==0 and not timeout and report['sourceAfterEqual'] else 'FAIL_RETAIN_ORIGINALS';save();print(report['status'],code,flush=True)
