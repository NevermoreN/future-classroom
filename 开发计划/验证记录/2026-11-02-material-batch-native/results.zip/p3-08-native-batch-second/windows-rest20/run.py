from pathlib import Path
import hashlib,json,subprocess,os,signal,time
D=Path(__file__).resolve().parent;F=D.parent;S=F/'source';P=F/'gnu-product';B=F/'windows-test-build';g=json.loads((P/'report.json').read_text());b=json.loads((B/'report.json').read_text());I=F/'inputs.json';rows=json.loads(I.read_text())['files'];assert g['status']=='PASS_NORMAL_GUI_BUILD'and b['status']=='PASS_WINDOWS_TEST_BUILD_ONLY_NOT_RUN'and len(b['artifacts'])==22;assert g['inputsSha256']==b['sourceInputsSha256']==hashlib.sha256(I.read_bytes()).hexdigest()
def same():return all((S/x['path']).stat().st_size==x['bytes']and hashlib.sha256((S/x['path']).read_bytes()).hexdigest()==x['sha256']for x in rows)
assert same();exe=P/'fc-bootstrap.exe';assert hashlib.sha256(exe.read_bytes()).hexdigest()==g['executable']['sha256'];selected=[a for a in b['artifacts']if a['name']not in ('fc-bootstrap','fc_bootstrap')];assert len(selected)==20;transport=[];copies=[]
for i,a in enumerate(selected):
 raw=Path(a['path']).read_bytes();assert len(raw)==a['bytes']and hashlib.sha256(raw).hexdigest()==a['sha256'];dest=D/f"test-{i:02}-{a['name']}.exe";assert not dest.exists();dest.write_bytes(raw);m=dict(a['compilerArtifact']);m['executable']=str(dest);m['filenames']=[str(dest)];transport.append(m);copies.append({'original':a,'alias':str(dest),'sha256':a['sha256']})
meta=D/'transport.jsonl';meta.write_text(''.join(json.dumps(m)+'\n'for m in transport));(D/'transport-proof.json').write_text(json.dumps(copies,indent=2)+'\n');report=D/'report.json';argv=['python3','-B',str(S/'scripts/windows-probe.py'),'--host','elior@192.168.10.212','--identity','/config/.local/share/future-classroom-test-access/win11-192.168.10.212','--exe',str(exe),'--test-metadata',str(meta),'--test-timeout-seconds','900','--report',str(report)];op={'status':'RUNNING','argv':argv,'inputsSha256':g['inputsSha256'],'normalExeSha256':g['executable']['sha256'],'scope':'Actual remaining20 complete S2 Windows harnesses on authorized Win11. Excludes already actualPASS native main239 and known-bad S2Backend test fixture library; S3replacement lib follows independently. Explicit final combination22; never add early/main cases twice.'}
def save():(D/'operation.json').write_text(json.dumps(op,indent=2)+'\n')
save();start=time.monotonic();timeout=False
with(D/'producer.stdout.log').open('xb')as out,(D/'producer.stderr.log').open('xb')as err:
 child=subprocess.Popen(argv,cwd=S,stdout=out,stderr=err,start_new_session=True);op['originalPid']=child.pid;save()
 try:code=child.wait(timeout=2400)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=15)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
r=json.loads(report.read_text())if report.exists()else{};op.update(status='PASS_ACTUAL_CONTROLLER'if code==0 and not timeout and r.get('status')=='PASS'and r.get('cleanup')=='PASS'and same()else'FAIL_RETAIN_ORIGINALS',actualExit=code,timedOut=timeout,originalReaped=child.poll()is not None,seconds=time.monotonic()-start,sourceAfterEqual=same(),originalReportStatus=r.get('status'),cleanup=r.get('cleanup'));save();print(json.dumps({k:v for k,v in op.items()if k!='argv'}),flush=True)
