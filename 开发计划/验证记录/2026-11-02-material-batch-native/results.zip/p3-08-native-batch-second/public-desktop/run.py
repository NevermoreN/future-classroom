from pathlib import Path
import subprocess,os,signal,time,json,hashlib
R=Path('/tmp/fc-round80-controlled-repair');D=Path(__file__).resolve().parent;S=D.parent/'source';P=D.parent/'gnu-product';exe=P/'fc-bootstrap.exe';proof=json.loads((P/'report.json').read_text());assert proof['status']=='PASS_NORMAL_GUI_BUILD';assert hashlib.sha256(exe.read_bytes()).hexdigest()==proof['executable']['sha256'];argv=['python3','-B',str(S/'scripts/windows-probe.py'),'--host','elior@192.168.10.212','--identity','/config/.local/share/future-classroom-test-access/win11-192.168.10.212','--exe',str(exe),'--public-desktop','--report',str(D/'report.json')];op={'status':'RUNNING','argv':argv,'sourceInputsSha256':proof['inputsSha256'],'exeSha256':proof['executable']['sha256'],'scope':'Actual Win11 hidden synthetic public desktop controls/worker/SQLite finite chain on P3-08 second fixed source. Includes corrected credential diagnostic. Foreground untouched; not visible Seewo/PPT/touch acceptance.'};p=D/'operation.json'
def save():p.write_text(json.dumps(op,indent=2)+'\n')
save();start=time.monotonic();timeout=False
with (D/'producer.stdout.log').open('xb') as out,(D/'producer.stderr.log').open('xb') as err:
 child=subprocess.Popen(argv,cwd=S,stdout=out,stderr=err,start_new_session=True);op['originalPid']=child.pid;save()
 try:code=child.wait(timeout=300)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=15)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait()
op.update(status='PASS_ACTUAL_CONTROLLER_EXIT' if code==0 and not timeout else 'FAIL_RETAIN_ORIGINALS',actualExit=code,timedOut=timeout,originalReaped=child.poll() is not None,seconds=time.monotonic()-start);save();print(op['status'],code)
