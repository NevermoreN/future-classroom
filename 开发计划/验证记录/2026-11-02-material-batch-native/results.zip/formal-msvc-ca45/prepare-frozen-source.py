from pathlib import Path
import hashlib,json,subprocess
root=Path(__file__).resolve().parent
assert (root/'.owner').read_text()=='future-classroom-msvc-release-candidate/v1\n'
repo=Path('/workspace/共享/Eliora/未来教室计划')
expected='ca45c461a2f5217ae5efb075f3868d6696786c44'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==expected
dest=root/'source-git'
assert not dest.exists()
operation=subprocess.run(['git','clone','--shared','--no-checkout','--no-hardlinks',str(repo),str(dest)],capture_output=True,timeout=90)
(root/'source-clone.stdout.log').write_bytes(operation.stdout)
(root/'source-clone.stderr.log').write_bytes(operation.stderr)
assert operation.returncode==0
subprocess.run(['git','read-tree',expected],cwd=dest,check=True,timeout=30)
names=subprocess.check_output(['git','ls-tree','-r','--name-only','-z',expected],cwd=repo).decode().split('\0')
rows=[]
for name in names:
    if not name or name.startswith('开发计划/验证记录/'):continue
    relative=Path(name)
    assert not relative.is_absolute() and all(x not in ('','.','..') for x in relative.parts)
    data=subprocess.check_output(['git','show',expected+':'+name],cwd=repo,timeout=20)
    path=dest/relative
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(data)
    rows.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=dest,text=True).strip()==expected
(root/'source-git-materialization.json').write_text(json.dumps(dict(source=expected,scope='Only non-historical Git blobs materialized; full Git index retained; NOT a full clean checkout',files=rows),indent=2)+'\n')
print(json.dumps(dict(source=expected,materialized=len(rows),gitIndexPaths=len(names)-1,historical='Not materialized',actualCloneExit=operation.returncode)))
