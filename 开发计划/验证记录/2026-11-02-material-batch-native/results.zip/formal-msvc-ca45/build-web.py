from pathlib import Path
import hashlib,json,shutil,subprocess,time
root=Path(__file__).resolve().parent
assert (root/'.owner').read_text()=='future-classroom-msvc-release-candidate/v1\n'
source=root/'source-git/web';dest=root/'web-build'
assert not dest.exists()
shutil.copytree(source,dest)
original={str(p.relative_to(dest)):(p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest()) for p in dest.rglob('*') if p.is_file()}
operations=[]
try:
    for name,argv,budget in [('install',['npm','ci','--ignore-scripts','--no-audit','--no-fund'],300),('build',['npm','run','build'],180)]:
        start=time.monotonic()
        with (root/('web-'+name+'.stdout.log')).open('xb') as out,(root/('web-'+name+'.stderr.log')).open('xb') as err:
            proc=subprocess.Popen(argv,cwd=dest,stdout=out,stderr=err)
            try:actual=proc.wait(timeout=budget)
            except subprocess.TimeoutExpired:
                proc.terminate();proc.wait(timeout=20)
                operations.append(dict(name=name,argv=argv,actualExit=proc.returncode,parentReaped=True,timedOut=True))
                raise
        operations.append(dict(name=name,argv=argv,actualExit=actual,parentReaped=True,timedOut=False,elapsedSeconds=time.monotonic()-start))
        assert actual==0,name
        assert all((root/('web-'+name+'.'+channel+'.log')).stat().st_size<=4*1024*1024 for channel in ('stdout','stderr'))
    current={name:((dest/name).stat().st_size,hashlib.sha256((dest/name).read_bytes()).hexdigest()) for name in original}
    assert current==original,'Original Web inputs including generated license differ'
    outputs=[dict(path=str(p.relative_to(dest)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted((dest/'dist').rglob('*')) if p.is_file()]
    report=dict(status='PASS_OWNED_WEB_BUILD_ONLY',source='ca45c461a2f5217ae5efb075f3868d6696786c44',operations=operations,originalInputCount=len(original),originalInputsUnchanged=True,outputs=outputs,normalMSVCProvenance='Separate original CI required',Windows='NOT_RUN')
    print(json.dumps(dict(status=report['status'],operations=operations,outputCount=len(outputs))))
finally:
    if 'report' not in globals():report=dict(status='FAIL_RETAIN_ORIGINALS',operations=operations)
    (root/'web-build-report.json').write_text(json.dumps(report,indent=2)+'\n')
