"""Reproduce only exact observed CI checkout bytes from a pinned Git blob.

This does not relax the package producer's raw-byte comparison or materialize
historical archives. No credential, compiler or product process is involved.
"""
from pathlib import Path
import argparse,hashlib,json,subprocess

def digest(raw):return hashlib.sha256(raw).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--evidence',type=Path,required=True)
    a=p.parse_args();root=Path(__file__).resolve().parent;source=root/'source-git'
    assert (root/'.owner').read_text()=='future-classroom-msvc-release-candidate/v1\n'
    expected='ca45c461a2f5217ae5efb075f3868d6696786c44'
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==expected
    raw=(a.evidence/'input-sha256.json').read_bytes()
    result=json.loads((a.evidence/'result.json').read_bytes())
    assert result['source_sha']==result['dispatch_source_sha']==expected
    assert raw==(a.evidence/'input-sha256-after.json').read_bytes()
    assert digest(raw)==result['input_manifest_sha256']
    inventory=json.loads(raw);seen=set();decisions=[]
    names=subprocess.check_output(['git','ls-files','-z'],cwd=source).decode().split('\0')
    selected={n for n in names if n and not n.startswith('开发计划/验证记录/')}
    assert {r['path'] for r in inventory}==selected
    for row in inventory:
        name=row['path'];relative=Path(name)
        assert name not in seen and set(row)=={'path','bytes','sha256'}
        assert not relative.is_absolute() and all(x not in ('','.','..') for x in relative.parts)
        seen.add(name)
        blob=subprocess.check_output(['git','show',expected+':'+name],cwd=source,timeout=20)
        def fits(data):return len(data)==row['bytes'] and digest(data)==row['sha256']
        if fits(blob):exact=blob;kind='EXACT_GIT_BLOB'
        else:
            assert b'\r\n' not in blob and b'\0' not in blob,'No speculative conversion: '+name
            exact=blob.replace(b'\n',b'\r\n');kind='UNIQUE_LF_TO_CRLF_MATCHES_OBSERVED_CI_SHA256'
            assert fits(exact),'Git blob and single permitted checkout conversion both differ: '+name
        path=source/relative
        assert path.is_file() and not path.is_symlink()
        path.write_bytes(exact)
        assert fits(path.read_bytes())
        decisions.append(dict(path=name,checkoutBytes=len(exact),checkoutSha256=digest(exact),method=kind,gitBlobSha256=digest(blob)))
    out=dict(status='PASS_ORIGINAL_CI_RAW_BYTES_REPRODUCED',source=expected,inputManifestSha256=digest(raw),materialized=len(decisions),trackedPaths=len(names)-1,historical='Git index retained; archive checkout bytes not materialized or asserted',files=decisions)
    (root/'source-ci-binding.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='files'}))
if __name__=='__main__':main()
