"""Append this finite completed text slice to the existing three-file archive.
Original failed CI/runtime results stay failed; no publication or Windows API.
"""
from pathlib import Path
import hashlib,io,json,stat,subprocess,sys,zipfile
sys.dont_write_bytecode=True
R=Path(__file__).resolve().parent
DEST=Path('/workspace/共享/Eliora/未来教室计划/开发计划/验证记录/2026-11-02-material-batch-native')
BASE='ba4345bc38c57a177fa0f7072b935c23f5fd80a723ed32403aa65b8f2850011f'
SCANNER='da2906c450ea8c2ac7d18e358507023f519dbcc6faf1a9ac1abb1ae16af8c30f'
def sha(b):return hashlib.sha256(b).hexdigest()
def encoded(x):return (json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode()
def main():
    assert (R/'.owner').read_text()=='future-classroom-msvc-release-candidate/v1\n'
    stage=R/'archive-stage';assert not stage.exists();stage.mkdir()
    scanner=Path('/workspace/共享/Eliora/未来教室计划/开发计划/验证记录/2026-11-02-round80-password-cng/strict-scanner-original.py').read_bytes()
    assert sha(scanner)==SCANNER
    ns={'__name__':'frozen_finite_msvc_scan'};exec(compile(scanner,'<frozen-scanner>','exec'),ns)
    stats=dict.fromkeys(('textViews','utf16Views','cp936Views','clixmlDecodedViews','decodedBase64Views','jsonContainers','decodedJsonStringViews'),0)
    def scan(raw,label):
        findings=[];ns['credential_scan'](raw,label,stats,findings)
        assert not findings,'Credential scan failed: '+str([(x.get('path'),x.get('kind'))for x in findings])
    names=[x['path']for x in json.loads((R/'archive-selection-draft.json').read_bytes())['originals']]
    names+=['prepare-frozen-source.py','build-web.py','download-ci.py','verify-original-ci.py','bind-ci-source.py',
        'implemented-code.patch','implemented-source-final.json','append-finite-evidence.py',
        'lint-fix-validation/nightly-gnu.stderr.log','lint-fix-validation/stable-gnu.stderr.log']
    names+=['root-validation/'+n+'.stderr.log'for n in ('test-installer-carrier-format.py','test-package-abi2-controlled-dev.py','test-controlled-setup-seal.py','check-msi-candidate.py','check-controlled-msi.py')]
    assert len(names)==len(set(names))
    selected={};rows=[]
    for name in names:
        assert not Path(name).is_absolute() and '..'not in Path(name).parts
        p=R/name;assert p.is_file() and not p.is_symlink() and p.stat().st_size<=8*1024*1024
        raw=p.read_bytes();assert not raw.startswith((b'MZ',b'PK\x03\x04',b'SQLite format 3\0'))
        raw.decode('utf-8-sig','strict')
        member='formal-msvc-ca45/'+name;scan(raw,member);selected[member]=raw
        rows.append(dict(path=name,member=member,bytes=len(raw),sha256=sha(raw)))
    assert json.loads((R/'modern-win11-application-report.json').read_bytes())['status']=='FAIL'
    assert json.loads((R/'modern-win11-library-isolated-report.json').read_bytes())['status']=='PASS'
    assert json.loads((R/'win7-ci/result.json').read_bytes())['status']=='FAILED_OR_INCOMPLETE'
    original=(DEST/'results.zip').read_bytes();assert sha(original)==BASE
    with zipfile.ZipFile(io.BytesIO(original))as z:
        infos=z.infolist();assert len(infos)==1432 and sum(i.file_size for i in infos)==25855194
        old={i.filename:z.read(i)for i in infos};assert len(old)==len(infos)
    assert not(set(old)&set(selected))
    assert len(old)+len(selected)<=1500 and sum(map(len,old.values()))+sum(map(len,selected.values()))<=30*1024*1024
    selection=encoded(dict(scope='Finite completed text only; full official ZIPs, binaries, Git-tree/domain inventories and omitted logs are not fully archived',previousArchiveSha256=BASE,originals=rows))
    selected['formal-msvc-ca45/selection.json']=selection;scan(selection,'selection.json')
    assert len(old)+len(selected)<=1500 and sum(map(len,old.values()))+sum(map(len,selected.values()))<=30*1024*1024
    with zipfile.ZipFile(stage/'results.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for info in infos:z.writestr(info,old[info.filename])
        for name,raw in sorted(selected.items()):z.writestr(name,raw)
    with zipfile.ZipFile(stage/'results.zip')as z:
        assert set(z.namelist())==set(old)|set(selected) and len(z.infolist())==len(old)+len(selected)
        for name,raw in old.items():assert z.read(name)==raw
        for name,raw in selected.items():assert z.read(name)==raw;scan(z.read(name),name)
        assert z.testzip()is None
    zipped=(stage/'results.zip').read_bytes()
    archive=dict(file='results.zip',bytes=len(zipped),sha256=sha(zipped),members=len(old)+len(selected),uncompressedBytes=sum(map(len,old.values()))+sum(map(len,selected.values())),limits=dict(members=1500,uncompressedBytes=30*1024*1024),fullReplay='PASS_PREVIOUS_1432_AND_ALL_SELECTED_ORIGINAL_BYTES')
    facts=dict(status='PASS_FINITE_COMPLETED_TEXT_REPLAY_AND_SCAN_ONLY',compiledSource='ca45c461a2f5217ae5efb075f3868d6696786c44',modernRun=dict(id=41480553209,status='success',originalCommands=51),win7TargetRun=dict(id=41480562137,status='failure',originalCommands=53,failedPhase='clippy',failedExit=101),runtime=dict(OS='Windows11',firstCombined='FAIL_LIBRARY_DEFAULT60S_TIMEOUT_CLEANUP_PASS',secondLibrary='PASS_359_TESTS_69_97S_EXPLICIT120S_BOUND_CLEANUP_PASS',separateOtherSuites='installer1/windows347/application255; Windows4ignored',normalGUI='PASS_SELF_CHECK_SYSTEM_HIDDEN_HOST_AND_APPLICATION',foreground='UNTOUCHED'),formalMsi='NOT_RUN_FAILED_CI_NOT_ADMITTED',newSource='Five-file complete implementation/fix patch and SHA frozen; new official MSVC build required',previousArchiveSha256=BASE,selectionSha256=sha(selection),originals=rows,omitted='Full original official ZIPs/binaries and omitted Git-tree/domain/log files were fully verified before selection; this archive preserves only identities and explicit selected originals, not their complete omitted bytes',scanner=dict(sha256=SCANNER,findings=0,statistics=stats,additionalAllowances='NONE'),localCleanup='PENDING_FINITE_COMPLETED_CACHES_ONLY; persistent SSH/key and unfinished candidates retained')
    summary=json.loads((DEST/'summary.json').read_bytes());summary['formalMsvcAbi2Round']=facts;summary['archive']=archive
    readme=(DEST/'README.md').read_bytes()+('\n\n## Formal MSVC ABI2 / ca45 finite slice\n\nModern original CI passed; Win7-target original CI failed only strict Clippy. The failed result remains failed and cannot enter formal packaging. Current builder wiring and the equivalent boolean lint fix have local format/admission/Clippy checks; actual formal MSI execution remains NOT_RUN. Modern same-source normal GUI and four test PEs ran on Win11: the first combined library run hit the default60s harness budget and stays FAIL; isolated359 tests passed in69.97s under the explicit existing120s CLI bound, with hidden workbench and cleanup PASS. Other parent suites passed1/347/255 (4ignored); child process cases are not added again.\n\nThe existing1432 members are preserved byte-for-byte. The appended selection is finite original text with frozen-scanner0 findings and no new allowances. Full official ZIP/PE bytes, complete Git-tree/domain inventories and omitted logs are NOT stored here; their original identities and independent full-byte verification are recorded. New final code is identified by complete patch and SHA, separately from original ca45 compile/runtime evidence. Windows7/10 physical testing remains NOT_RUN at the user\'s request, not a release prerequisite. This is code-development evidence, not a published release.\n').encode()
    scan(encoded(summary),'generated-summary.json');scan(readme,'generated-readme.md')
    (stage/'summary.json').write_bytes(encoded(summary));(stage/'README.md').write_bytes(readme)
    (R/'archive-stage-verification.json').write_bytes(encoded(dict(status='PASS_EXTERNAL_THREE_FILE_STAGE_ONLY',archive=archive,scannerSha256=SCANNER,scanFindings=0,previousMembersExact=len(old),newMembersExact=len(selected))))
    print(json.dumps(dict(status='PASS_EXTERNAL_THREE_FILE_STAGE_ONLY',archive=archive,findings=0)))
if __name__=='__main__':main()
