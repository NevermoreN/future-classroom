from pathlib import Path,PurePosixPath
import argparse,hashlib,json,stat,sys,urllib.parse,urllib.request,zipfile

def main():
    p=argparse.ArgumentParser();p.add_argument('--role',choices=['modern','win7'],required=True)
    p.add_argument('--bytes',type=int,required=True);p.add_argument('--sha256',required=True)
    p.add_argument('--run-id',type=int,required=True);p.add_argument('--artifact-id',type=int,required=True)
    a=p.parse_args();root=Path(__file__).resolve().parent
    assert (root/'.owner').read_text()=='future-classroom-msvc-release-candidate/v1\n'
    url=sys.stdin.readline().strip();parsed=urllib.parse.urlparse(url)
    assert parsed.scheme=='https' and parsed.hostname.endswith('.oaiusercontent.com')
    path=root/(a.role+'-original.zip');assert not path.exists()
    assert 0<a.bytes<=256*1024*1024
    try:
        with urllib.request.urlopen(url,timeout=60) as response,path.open('xb') as out:
            total=0;digest=hashlib.sha256()
            while True:
                chunk=response.read(1024*1024)
                if not chunk:break
                total+=len(chunk);assert total<=a.bytes
                digest.update(chunk);out.write(chunk)
        assert total==a.bytes and digest.hexdigest()==a.sha256
    except Exception as error:
        print(json.dumps(dict(status='FAIL_RETAIN_PARTIAL_DOWNLOAD',errorType=type(error).__name__)),flush=True)
        return 1
    destination=root/(a.role+'-ci');assert not destination.exists();destination.mkdir()
    with zipfile.ZipFile(path) as z:
        members=z.infolist();assert len(members)<=1024
        assert sum(i.file_size for i in members)<=512*1024*1024
        seen=set();rows=[]
        for info in members:
            name=info.filename;relative=PurePosixPath(name)
            assert not relative.is_absolute() and '\\' not in name and ':' not in name
            assert all(part not in ('','.','..') for part in relative.parts)
            assert name.casefold() not in seen and not any(ord(c)<32 for c in name)
            seen.add(name.casefold());mode=info.external_attr>>16
            assert not stat.S_ISLNK(mode) and info.file_size<=64*1024*1024
            selected=destination.joinpath(*relative.parts)
            if info.is_dir():selected.mkdir(parents=True,exist_ok=True);continue
            data=z.read(info);assert len(data)==info.file_size
            selected.parent.mkdir(parents=True,exist_ok=True);selected.write_bytes(data)
            rows.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
        assert z.testzip() is None
    report=dict(status='PASS_FULL_OFFICIAL_ARTIFACT_BYTES_AND_MEMBER_CRC',role=a.role,runId=a.run_id,artifactId=a.artifact_id,zipBytes=total,zipSha256=digest.hexdigest(),fileCount=len(rows),uncompressedBytes=sum(r['bytes'] for r in rows),members=rows,Windows='NOT_RUN',downloadURL='NOT_STORED')
    (root/(a.role+'-download-report.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='members'}))
    return 0
if __name__=='__main__':raise SystemExit(main())
