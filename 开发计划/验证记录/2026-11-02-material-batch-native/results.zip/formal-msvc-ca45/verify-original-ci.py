from pathlib import Path
import argparse,hashlib,json,struct,subprocess

def sha(raw):return hashlib.sha256(raw).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--role',choices=['modern','win7'],required=True)
    p.add_argument('--expect-clippy-failure',action='store_true')
    a=p.parse_args();root=Path(__file__).resolve().parent;data=root/(a.role+'-ci');source=root/'source-git'
    expected='ca45c461a2f5217ae5efb075f3868d6696786c44'
    r=json.loads((data/'result.json').read_bytes())
    assert r['status']==('FAILED_OR_INCOMPLETE' if a.expect_clippy_failure else 'COMPILE_CHECKS_PASSED_RUNTIME_NOT_RUN')
    if a.expect_clippy_failure:
        assert a.role=='win7' and [(c['name'],c['exit_code']) for c in r['commands'] if c['passed'] is not True]==[('clippy',101)]
    assert r['source_sha']==r['dispatch_source_sha']==expected
    assert r['baseline']==('Modern' if a.role=='modern' else 'Win7')
    assert r['target']==('i686-pc-windows-msvc' if a.role=='modern' else 'i686-win7-windows-msvc')
    manifest=json.loads((data/'artifact-sha256.json').read_bytes())
    for row in manifest:
        raw=(data/row['path']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
    assert len(manifest)==len([f for f in data.rglob('*') if f.is_file()])-1
    commands=r['commands'];assert len({c['name'] for c in commands})==len(commands)
    for c in commands:
        assert type(c['exit_code']) is int
        if a.expect_clippy_failure and c['name']=='clippy':assert c['passed'] is False and c['exit_code']==101
        else:assert c['passed'] is True and c['exit_code']==0
        assert c['parent_exited'] is True and c['timed_out_or_pipe_stalled'] is False and c['log_truncated'] is False
        for stream in ('stdout','stderr'):
            raw=(data/c[stream]).read_bytes();assert sha(raw)==c[stream+'_sha256']
    for name,key in [('input-sha256','input_manifest_sha256'),('input-git-tree','git_tree_manifest_sha256'),('input-domains','input_domains_manifest_sha256')]:
        raw=(data/(name+'.json')).read_bytes()
        assert sha(raw)==r[key] and raw==(data/(name+'-after.json')).read_bytes()
    actual_tree=json.loads((data/'input-git-tree.json').read_bytes())
    assert actual_tree['source_sha']==expected
    assert actual_tree['root_tree_oid_sha1']==subprocess.check_output(['git','rev-parse',expected+'^{tree}'],cwd=source,text=True).strip()
    records=subprocess.check_output(['git','ls-tree','-rlz',expected],cwd=source).split(b'\0')
    expected_tree=[]
    for raw in records:
        if not raw:continue
        head,name=raw.split(b'\t',1);mode,kind,oid,size=head.split();name=name.decode()
        expected_tree.append(dict(path=name,mode=mode.decode(),type=kind.decode(),git_blob_oid_sha1=oid.decode(),git_blob_bytes=int(size),domain='historical_git_archive' if name.startswith('开发计划/验证记录/') else 'sha256_input'))
    assert actual_tree['files']==expected_tree
    raw=(data/'executables.json').read_bytes();assert sha(raw)==r['executables_manifest_sha256']
    ledger=json.loads(raw)
    for row in ledger:
        image=(data/row['relative_path']).read_bytes();assert len(image)==row['bytes'] and sha(image)==row['sha256']
        assert row['executed'] is False
    normal=[row for row in ledger if row['role'] in ('product','custom_action_library')]
    assert len(normal)==3 and {row['target'] for row in normal}=={'fc-bootstrap','fc-installer-lifecycle','fc_windows'}
    phases={'fc-bootstrap':'product-compile','fc-installer-lifecycle':'lifecycle-compile','fc_windows':'guard-library-compile'}
    metadata=json.loads((data/'logs/cargo-metadata.stdout.log').read_bytes());facts=[]
    for row in normal:
        assert row['cargo_profile_test'] is False
        package=next(x for x in metadata['packages'] if x['name']==row['package'])
        assert package['id'] in metadata['workspace_members'] and package['source'] is None
        phase=next(c for c in commands if c['name']==phases[row['target']])
        messages=[json.loads(line) for line in (data/phase['stdout']).read_bytes().splitlines() if line.startswith(b'{')]
        selected=[m for m in messages if m.get('reason')=='compiler-artifact' and m.get('target',{}).get('name')==row['target']]
        assert len(selected)==1;item=selected[0]
        assert item['profile']['test'] is False and item['package_id']==package['id'] and item['manifest_path']==package['manifest_path']
        assert item['target'] in package['targets']
        image=(data/row['relative_path']).read_bytes();pe=struct.unpack_from('<I',image,60)[0]
        assert image[:2]==b'MZ' and image[pe:pe+4]==b'PE\0\0'
        assert struct.unpack_from('<H',image,pe+4)[0]==0x14c
        assert struct.unpack_from('<H',image,pe+24)[0]==0x10b
        facts.append(dict(role=row['role'],target=row['target'],bytes=len(image),sha256=sha(image),cargoProfileTest=False,features=item['features'],cargoPackageId=item['package_id'],subsystem=struct.unpack_from('<H',image,pe+92)[0],subsystemVersion=struct.unpack_from('<HH',image,pe+72)))
    summary=dict(status='PASS_ORIGINAL_FAILED_CI_PROVENANCE_ONLY_FORMAL_ADMISSION_REJECTED' if a.expect_clippy_failure else 'PASS_ORIGINAL_SUCCESSFUL_CI_ALL_FILES_LOGS_GIT_TREE_AND_NORMAL_ARTIFACTS',originalCIStatus=r['status'],originalFailures=[dict(name=c['name'],exitCode=c['exit_code'])for c in commands if not c['passed']],role=a.role,source=expected,commands=len(commands),trackedTreeEntries=len(expected_tree),allArtifactFiles=len(manifest)+1,ordinarySourceRawBytes='Separately reproduced and checked by bind-ci-source.py',normalArtifacts=facts,Windows='NOT_RUN',resultSha256=sha((data/'result.json').read_bytes()))
    (root/(a.role+'-ci-verification.json')).write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary))
if __name__=='__main__':main()
