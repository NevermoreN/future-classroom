"""Pure producer contract regressions; synthetic metadata is never CI evidence."""
from pathlib import Path
import copy, hashlib, json, runpy, unittest, ast, subprocess, sys
R=Path(__file__).resolve().parent
F=runpy.run_path(str(R/'scripts/package-abi2-msvc-candidate.py'))
U=F['ABI2']; B=F['B']; TARGET=F['TARGET']

def result():
    r=dict(status='COMPILE_CHECKS_PASSED_RUNTIME_NOT_RUN',baseline='Win7',target=TARGET,
        toolchain='nightly-2026-10-29-x86_64-pc-windows-msvc',
        rustflags='-C target-feature=+crt-static -C link-arg=/SUBSYSTEM:CONSOLE,6.01',
        product_rustflags='-C target-feature=+crt-static -C link-arg=/SUBSYSTEM:WINDOWS,6.01',commands=[])
    for name, package, target in [('product-compile','fc-bootstrap','fc-bootstrap'),('lifecycle-compile','fc-bootstrap','fc-installer-lifecycle'),('guard-library-compile','fc-windows',None)]:
        args=['-Z','build-std','build' if target is None else 'rustc','-vv','--release','--locked','--target',TARGET,'-p',package]
        args+=['--lib']if target is None else['--bin',target]
        args+=['--message-format=json']
        r['commands'].append(dict(name=name,arguments=args,passed=True,exit_code=0,parent_exited=True,timed_out_or_pipe_stalled=False,log_truncated=False))
    return r

class FormalProducerContract(unittest.TestCase):
    def test_closed_normal_command_matrix(self):
        F['check_compile_result'](result())
        for index in range(3):
            for token in ('--tests','--features','--all-targets','--all-features','--no-default-features','--bin','test'):
                bad=result();bad['commands'][index]['arguments'].append(token)
                with self.subTest(phase=index,token=token),self.assertRaises(ValueError):F['check_compile_result'](bad)
    def test_each_original_phase_required_once(self):
        for index in range(3):
            bad=result();del bad['commands'][index]
            with self.assertRaises(ValueError):F['check_compile_result'](bad)
            bad=result();bad['commands'].append(copy.deepcopy(bad['commands'][index]))
            with self.assertRaises(ValueError):F['check_compile_result'](bad)
    def test_original_parent_success_and_log_completeness(self):
        for index in range(3):
            for key,value in [('exit_code',False),('exit_code',1),('parent_exited',False),('timed_out_or_pipe_stalled',True),('log_truncated',True),('passed',False)]:
                bad=result();bad['commands'][index][key]=value
                with self.subTest(phase=index,key=key),self.assertRaises(ValueError):F['check_compile_result'](bad)
    def test_other_target_toolchain_or_crt_scope_cannot_be_relabelled(self):
        for key,value in [('target','i686-pc-windows-gnu'),('target','i686-pc-windows-msvc'),('baseline','Modern'),('toolchain','stable'),('rustflags','-C target-feature=-crt-static'),('product_rustflags','-C target-feature=+crt-static'),('status','DEV_FROZEN_NORMAL_BUILD_ONLY')]:
            bad=result();bad[key]=value
            with self.subTest(key=key,value=value),self.assertRaises(ValueError):F['check_compile_result'](bad)
    def test_other_ci_command_failure_not_hidden_by_normal_phases(self):
        bad=result();bad['commands'].append(dict(name='clippy',passed=False))
        with self.assertRaises(ValueError):F['check_compile_result'](bad)
    def test_original_gnu_admission_and_sequence_functions_byte_equivalent_ast(self):
        a=ast.parse((R/'baseline/package-abi2-upgrade-dev.py').read_bytes());b=ast.parse((R/'scripts/package-abi2-upgrade-dev.py').read_bytes())
        for name in ('main','admit_normal_inputs','upgrade_source_binding','extent','upgrade_sequence','verify_upgrade_sequence','authoring','validate_contract'):
            left=next(x for x in a.body if isinstance(x,ast.FunctionDef)and x.name==name)
            right=next(x for x in b.body if isinstance(x,ast.FunctionDef)and x.name==name)
            self.assertEqual(ast.dump(left,include_attributes=False),ast.dump(right,include_attributes=False))
    def test_existing_formal_and_same_package_gnu_sources_unchanged(self):
        for name in ('package-msi-candidate.py','package-abi2-controlled-dev.py'):
            self.assertEqual((R/'baseline'/name).read_bytes(),(R/'scripts'/name).read_bytes())
    def test_upgrade_authoring_keeps_closed_v2_envelope_and_atomic_sequence(self):
        import xml.etree.ElementTree as ET
        xml=ET.fromstring(U['authoring']('0.2.0',sorted(B['LIFECYCLE_REQUIRED'])))
        product=xml.find('{'+B['WIX_NS']+'}Product')
        names={x.get('Id')for x in product.findall('{'+B['WIX_NS']+'}Binary')}
        self.assertEqual(names,set(U['BINARY_NAMES']))
        self.assertFalse(product.findall('{'+B['WIX_NS']+'}MsiEmbeddedChainer'))
        raw=('Action\tCondition\tSequence\r\ns72\tS255\tI2\r\nInstallExecuteSequence\tAction\r\nCostFinalize\t\t1000\r\nInstallValidate\t\t1400\r\nInstallInitialize\t\t1500\r\nRemoveExistingProducts\t\t6550\r\nInstallExecute\t\t6500\r\nInstallFinalize\t\t6600\r\n').encode()
        seq,old=U['upgrade_sequence'](raw)
        self.assertEqual(U['verify_upgrade_sequence'](seq)['RemoveExistingProducts'],1501)
        bad=seq.replace(b'RemoveExistingProducts\t\t1501',b'RemoveExistingProducts\t\t1401')
        with self.assertRaises(ValueError):U['verify_upgrade_sequence'](bad)
    def test_default_no_execute_never_creates_output(self):
        out=R/'must-not-exist'
        self.assertFalse(out.exists())
        completed=subprocess.run([sys.executable,str(R/'scripts/package-abi2-msvc-candidate.py'),'--output-dir',str(out)],capture_output=True,text=True,check=True)
        self.assertEqual(json.loads(completed.stdout)['status'],'NOT_RUN')
        self.assertFalse(out.exists())

if __name__=='__main__':unittest.main(verbosity=2)
