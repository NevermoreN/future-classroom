from pathlib import Path
import subprocess,json,os,time,hashlib
r=Path('/tmp/fc-batch-delete');env=os.environ.copy();env['CARGO_TARGET_DIR']=str(r/'gnu-target');env['CARGO_BUILD_JOBS']='4';rows=[];source=Path('crates/fc-bootstrap/src/application/material_batch_tests.rs');assert hashlib.sha256(source.read_bytes()).hexdigest()==json.loads((r/'native-assertion-fix.json').read_bytes())['afterSha256']
for n,c in [('native-second-clippy',['cargo','clippy','--workspace','--all-targets','--release','--locked','--target','i686-pc-windows-gnu','--','-D','warnings']),('native-second-build',['cargo','test','-p','fc-bootstrap','--bin','fc-bootstrap','--release','--locked','--target','i686-pc-windows-gnu','--no-run','--message-format=json'])]:
 t=time.monotonic()
 with (r/(n+'.stdout.log')).open('wb')as a,(r/(n+'.stderr.log')).open('wb')as b:p=subprocess.run(c,env=env,stdout=a,stderr=b)
 rows.append({'name':n,'command':c,'exit':p.returncode,'seconds':time.monotonic()-t});(r/'native-second-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(n,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
