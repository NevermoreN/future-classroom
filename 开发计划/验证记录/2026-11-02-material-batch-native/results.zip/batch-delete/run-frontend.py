from pathlib import Path
import subprocess,json,time
R=Path('/tmp/fc-batch-delete');out=[]
for name,cmd in [('ci',['npm','ci','--ignore-scripts']),('typecheck',['npm','run','typecheck']),('test',['npm','test']),('build',['npm','run','build'])]:
 t=time.monotonic()
 with (R/(name+'.stdout.log')).open('wb') as a,(R/(name+'.stderr.log')).open('wb') as b:p=subprocess.run(cmd,cwd=R/'web',stdout=a,stderr=b)
 out.append(dict(name=name,command=cmd,exit=p.returncode,seconds=time.monotonic()-t));(R/'frontend.json').write_text(json.dumps(out,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:break
raise SystemExit(out[-1]['exit'])
