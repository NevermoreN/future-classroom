#!/usr/bin/env python3
"""Finite browser QA coordinator; never a listener or browser-ownership proof.

The unchanged Edge Job owner proves physical browser/profile cleanup. Node owns
only its CDP context. Cookie/CSRF travel through private stdin, never argv,
environment, reports or raw CDP frames. Construction performs no I/O.
"""
import base64
from datetime import date
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import queue
import re
import selectors
import stat
import subprocess
import sys
import time
import uuid

sys.dont_write_bytecode = True
MAX_BYTES = 512 * 1024
MAX_INPUT = 64 * 1024
REPORT_KEYS = frozenset((
    "schemaVersion", "status", "marker", "scope", "assetManifestCanonicalSha256",
    "expectedCspSha256", "credentialScope", "browserPhysicalCleanup", "assets",
    "checks", "browserVersion", "generation", "origin", "maxMillis",
    "syntheticTextSha256", "elapsedMillis", "contextDisposed", "cdpDisconnected",
    "network", "wireResponses", "wireResponseCount", "observedRequestCount",
    "observedResponseCount", "cacheOnlyResponseCount", "apiResponses", "contentPosts",
    "sessionCsrfMatched", "writeOutcome", "contentRevision", "commandId", "commandTicket", "issuedCommand", "commandIssues",
    "pageErrorCount", "consoleErrorCount", "sourceSha256", "error", "apiOperations", "visualReads", "visualObservations", "contentKind", "reminderShortcutClicks", "reminderObservations",
))
RECORD_KEYS = frozenset((
    "method", "url", "status", "mime", "csp", "servedFromCache", "fromDiskCache",
    "fromServiceWorker", "fromPrefetchCache", "wireStatus", "finished", "bodyVerified", "failure",
))

FAILURE_KEYS = frozenset((
    "requestOrdinal", "kind", "path", "phase", "canceled", "errorText", "blockedReason",
    "failureMillis", "requestMillis", "responseMillis", "extraInfoMillis", "finishedMillis", "bodyVerifiedMillis",
    "responseReceived", "finished", "bodyVerified", "dataEvents", "dataBytes", "encodedBytes", "countsClamped",
))
FAILURE_PHASES = frozenset((
    "connect", "await-run", "inject-existing-approved-cookie", "navigate-native", "read-original-content",
    "visual-original", "enter-synthetic-text", "visual-refresh-with-draft", "save-once", "visual-after-save",
    "reload-and-read-durable-content", "visual-after-reload", "settle-observed-responses", "complete", "OTHER",
))
# Same finite names as Node; do not reflect an arbitrary ERR_<credential>.
NETWORK_ERRORS = frozenset((
    "net::ERR_FAILED", "net::ERR_ABORTED", "net::ERR_TIMED_OUT",
    "net::ERR_CONNECTION_CLOSED", "net::ERR_CONNECTION_RESET", "net::ERR_CONNECTION_REFUSED",
    "net::ERR_CONNECTION_ABORTED", "net::ERR_CONNECTION_FAILED", "net::ERR_EMPTY_RESPONSE",
    "net::ERR_CONTENT_LENGTH_MISMATCH", "net::ERR_INCOMPLETE_CHUNKED_ENCODING", "net::ERR_INVALID_CHUNKED_ENCODING",
    "net::ERR_NAME_NOT_RESOLVED", "net::ERR_ADDRESS_UNREACHABLE", "net::ERR_INTERNET_DISCONNECTED",
    "net::ERR_NETWORK_CHANGED", "net::ERR_SSL_PROTOCOL_ERROR", "net::ERR_SSL_VERSION_OR_CIPHER_MISMATCH",
    "net::ERR_CERT_AUTHORITY_INVALID", "net::ERR_CERT_COMMON_NAME_INVALID", "net::ERR_CERT_DATE_INVALID",
    "net::ERR_CERT_INVALID", "net::ERR_BLOCKED_BY_CLIENT", "net::ERR_BLOCKED_BY_RESPONSE",
    "net::ERR_HTTP2_PROTOCOL_ERROR", "net::ERR_QUIC_PROTOCOL_ERROR",
))
BLOCKED_REASONS = frozenset((
    "NONE", "OTHER", "other", "csp", "mixed-content", "origin", "inspector", "subresource-filter", "content-type",
    "coep-frame-resource-needs-coep-header", "coop-sandboxed-iframe-cannot-navigate-to-coop-page",
    "corp-not-same-origin", "corp-not-same-origin-after-defaulted-to-same-origin-by-coep", "corp-not-same-site",
))


def require(condition, code):
    if not condition:
        raise RuntimeError(code)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def command_identity(value):
    require(type(value) is dict and set(value) == {"commandId", "commandTicket"}, "NODE_COMMAND_PAIR_SHAPE")
    raw, ticket = value["commandId"], value["commandTicket"]
    require(type(raw) is str and re.fullmatch(r"[1-9][0-9]{0,19}", raw) is not None and int(raw) <= 2**64-1,
            "NODE_COMMAND_RAW_CANONICAL")
    match = re.fullmatch(r"c2:([0-9a-f]{32}):([1-9][0-9]{0,18})", ticket) if type(ticket) is str else None
    require(match is not None and match[1] != "0"*32 and int(match[2]) <= 2**63-1, "NODE_COMMAND_TICKET_CANONICAL")
    return {"commandId":raw,"commandTicket":ticket}


def failure(error, phase):
    # Exception messages can contain private stdin, a CDP capability or a remote
    # response body. Only static phase/type metadata belongs in the QA report.
    return {"phase": phase, "kind": type(error).__name__}


def validate_network_failures(value, run, manifest, content_kind):
    """Validate only finite diagnostic facts, never relax the PASS contract.

    Milliseconds describe local Node CDP event receipt relative to RUN receipt;
    null means unavailable/outside the 60s observation bound. Counters are
    capped with an explicit countsClamped flag. No socket/native clock claim.
    """
    records = value.get("network", [])
    require(isinstance(records, list) and len(records) <= 128, "NODE_FAILURE_NETWORK_BOUND")
    failures = []
    for index, record in enumerate(records):
        require(isinstance(record, dict), "NODE_FAILURE_RECORD_SHAPE")
        if "failure" not in record:
            continue
        require(set(record) <= RECORD_KEYS and value.get("status") == "FAIL"
                and isinstance(value.get("error"), dict) and value["error"].get("code") == "NETWORK_LOAD_FAILED",
                "NODE_FAILURE_OUTCOME")
        observation = record["failure"]
        require(isinstance(observation, dict) and set(observation) == FAILURE_KEYS, "NODE_FAILURE_SHAPE")
        path = observation["path"]
        require(isinstance(path, str) and len(path) <= 512 and record.get("url") == run["origin"] + path
                and record.get("method") in ("GET", "POST"), "NODE_FAILURE_PATH")
        prefix = "homework" if content_kind == "HOMEWORK" else "reminders"
        fixed_api = ("/fc/api/v1/status", "/fc/api/v1/session", f"/fc/api/v1/content/{prefix}/scopes/0")
        ids = r"[1-9][0-9]{0,19}/" * (3 if content_kind == "HOMEWORK" else 1)
        content = f"/fc/api/v1/content/{prefix}/" + ids + r"[0-9]{4}-[0-9]{2}-[0-9]{2}"
        assets = {"/fc/" + asset["path"] for asset in manifest["assets"]} | {"/fc/"}
        kind = ("command-issue" if path == "/fc/api/v1/commands" else
                "content" if re.fullmatch(content, path) else
                "visual" if content_kind == "HOMEWORK" and re.fullmatch(content + r"/visual", path) else
                "api" if path in fixed_api else "asset" if path in assets else None)
        require(kind is not None and observation["kind"] == kind
                and (record["method"] == "POST" if kind == "command-issue" else kind == "content" or record["method"] == "GET"), "NODE_FAILURE_UNEXPECTED_TARGET")
        require(type(observation["requestOrdinal"]) is int and observation["requestOrdinal"] == index + 1
                and isinstance(observation["phase"], str) and observation["phase"] in FAILURE_PHASES
                and type(observation["canceled"]) is bool
                and isinstance(observation["errorText"], str)
                and (observation["errorText"] == "OTHER" or observation["errorText"] in NETWORK_ERRORS)
                and isinstance(observation["blockedReason"], str) and observation["blockedReason"] in BLOCKED_REASONS,
                "NODE_FAILURE_CLASSIFICATION")
        for key in ("failureMillis", "requestMillis", "responseMillis", "extraInfoMillis", "finishedMillis", "bodyVerifiedMillis"):
            number = observation[key]
            require(number is None or type(number) is int and 0 <= number <= 60000, "NODE_FAILURE_TIME_BOUND")
            require(number is None or observation["failureMillis"] is None or number <= observation["failureMillis"],
                    "NODE_FAILURE_TIME_ORDER")
        for key in ("responseReceived", "finished", "bodyVerified", "countsClamped"):
            require(type(observation[key]) is bool, "NODE_FAILURE_FLAG")
        # This is a fault-instant snapshot: an already pending body-analysis
        # promise may complete during cleanup before summary. Facts may advance
        # false -> true afterwards, never erase something already observed.
        require(type(record.get("finished")) is bool and type(record.get("bodyVerified")) is bool
                and (not observation["finished"] or record["finished"])
                and (not observation["bodyVerified"] or record["bodyVerified"])
                and (not observation["responseReceived"] or record.get("status") is not None), "NODE_FAILURE_LIFECYCLE")
        for key, bound in (("dataEvents", 65536), ("dataBytes", 8 * 1024 * 1024), ("encodedBytes", 8 * 1024 * 1024)):
            require(type(observation[key]) is int and 0 <= observation[key] <= bound, "NODE_FAILURE_COUNTER")
        failures.append(dict(observation))
    require(len(failures) <= 1, "NODE_MULTIPLE_FIRST_FAILURES")
    # Summary's wire subset may repeat that same record, never add a hidden
    # second diagnostic or change its snapshot. It remains partial evidence.
    wires = value.get("wireResponses", [])
    require(isinstance(wires, list) and len(wires) <= 128, "NODE_FAILURE_WIRE_BOUND")
    for record in wires:
        if isinstance(record, dict) and "failure" in record:
            require(record in records, "NODE_FAILURE_WIRE_SUBSET")
    return failures


API_OPERATIONS = {"statusGets": 2, "sessionGets": 2, "scopeGets": 2,
                  "contentGets": 2, "contentPosts": 1, "commandIssues": 1, "visualGets": 4}
REMINDER_OPERATIONS = {**API_OPERATIONS, "visualGets": 0}
VISUAL_FIELDS = frozenset(("subjectRevision", "displayRevision", "rulesVersion", "effectiveRgb", "mode",
                          "homeworkFillPercent", "courseFillPercent", "homeworkComponentOpacityPercent",
                          "courseComponentOpacityPercent", "homeworkVisible", "courseVisible"))


def validate_visual_observations(value):
    observations = value.get("visualObservations")
    require(type(value.get("visualReads")) is int and value["visualReads"] == API_OPERATIONS["visualGets"]
            and isinstance(observations, list) and len(observations) == API_OPERATIONS["visualGets"], "NODE_VISUAL_COUNT")
    stages = ("initial", "draft-refresh", "after-save", "after-reload")
    def number(n):
        return type(n) in (int, float) and math.isfinite(n)
    for index, observed in enumerate(observations):
        require(isinstance(observed, dict) and set(observed) == {"stage", "readNumber", "responseBodySha256", "visual", "dom", "draftPreserved"}
                and observed["stage"] == stages[index] and type(observed["readNumber"]) is int
                and observed["readNumber"] == index + 1 and observed["draftPreserved"] is True
                and isinstance(observed["responseBodySha256"], str)
                and re.fullmatch(r"[0-9a-f]{64}", observed["responseBodySha256"]), "NODE_VISUAL_STAGE")
        visual, dom = observed["visual"], observed["dom"]
        require(isinstance(visual, dict) and set(visual) == VISUAL_FIELDS
                and all(isinstance(visual.get(k), str) and re.fullmatch(r"(?:0|[1-9][0-9]{0,19})", visual[k])
                        and int(visual[k]) <= (1 << 64) - 1 for k in ("subjectRevision", "displayRevision"))
                and visual["subjectRevision"] != "0" and type(visual["rulesVersion"]) is int and visual["rulesVersion"] == 1
                and isinstance(visual["effectiveRgb"], str) and re.fullmatch(r"#[0-9A-F]{6}", visual["effectiveRgb"])
                and visual["mode"] in ("FILLED", "OUTLINED")
                and all(type(visual[k]) is int and 0 <= visual[k] <= 100 for k in
                        ("homeworkFillPercent", "courseFillPercent", "homeworkComponentOpacityPercent", "courseComponentOpacityPercent"))
                and all(type(visual[k]) is bool for k in ("homeworkVisible", "courseVisible")), "NODE_VISUAL_VALUES")
        require(isinstance(dom, dict) and set(dom) == {"subjectRevision", "displayRevision", "rulesVersion", "homework", "course",
                    "refreshOpacity", "helpOpacity", "draftMatches", "bottomReminderAvailable"}
                and dom["subjectRevision"] == visual["subjectRevision"] and dom["displayRevision"] == visual["displayRevision"]
                and dom["rulesVersion"] == "1" and dom["draftMatches"] is True and dom["bottomReminderAvailable"] is True
                and all(number(dom[k]) and dom[k] == 1 for k in ("refreshOpacity", "helpOpacity")), "NODE_VISUAL_DOM")
        for kind in ("homework", "course"):
            pill = dom[kind]
            require(isinstance(pill, dict) and set(pill) == {"mode", "fillPercent", "effectiveRgb", "visible", "componentOpacity",
                    "pillOpacity", "effectiveOpacity", "backgroundColor", "borderWidth", "borderStyle", "textAlign", "textMatches", "textColorUnchanged"}
                    and pill["mode"] == visual["mode"] and pill["fillPercent"] == str(visual[kind + "FillPercent"])
                    and pill["effectiveRgb"] == visual["effectiveRgb"] and pill["visible"] == str(visual[kind + "Visible"]).lower()
                    and all(number(pill[k]) for k in ("componentOpacity", "pillOpacity", "effectiveOpacity", "borderWidth"))
                    and pill["componentOpacity"] == visual[kind + "ComponentOpacityPercent"] / 100
                    and abs(pill["effectiveOpacity"] - pill["componentOpacity"]) < 0.000001 and pill["pillOpacity"] == 1
                    and pill["textAlign"] == "center" and pill["textMatches"] is True and pill["textColorUnchanged"] is True,
                    "NODE_VISUAL_PILL")
            color = re.fullmatch(r"rgba?\(\s*(\d+(?:\.\d+)?),\s*(\d+(?:\.\d+)?),\s*(\d+(?:\.\d+)?)(?:,\s*(\d+(?:\.\d+)?))?\s*\)", str(pill["backgroundColor"]))
            require(color is not None, "NODE_VISUAL_COMPUTED_COLOR")
            rgba = [float(n) for n in color.groups()[:3]] + [float(color[4]) if color[4] is not None else 1.0]
            alpha = visual[kind + "FillPercent"] / 100 if visual["mode"] == "FILLED" else 0
            rgb = [int(visual["effectiveRgb"][i:i + 2], 16) for i in (1, 3, 5)]
            require(all(0 <= n <= 255 for n in rgba[:3]) and 0 <= rgba[3] <= 1
                    and abs(rgba[3] - alpha) < 0.000001 and (alpha == 0 or rgba[:3] == rgb)
                    and pill["borderWidth"] == (0 if visual["mode"] == "FILLED" else 1)
                    and pill["borderStyle"] == ("none" if visual["mode"] == "FILLED" else "solid"), "NODE_VISUAL_COMPUTED_STYLE")



def load_helpers():
    source = Path(__file__).resolve().with_name("windows-tls-probe.py")
    spec = importlib.util.spec_from_file_location("fc_native_browser_tls_helpers", source)
    require(spec is not None and spec.loader is not None, "TLS_HELPER_UNAVAILABLE")
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    return helper


def validate_reminder_observations(value, content_paths):
    observations = value.get("reminderObservations")
    require(isinstance(observations, list) and len(observations) == 3, "NODE_REMINDER_DOM_COUNT")
    fields = {"stage", "key", "revision", "titleMatches", "dateMatches", "expiryMatches",
              "draftMatches", "noVisualPreview", "bottomShortcutAvailable"}
    for index, observed in enumerate(observations):
        require(isinstance(observed, dict) and set(observed) == fields
                and observed["stage"] == ("initial", "after-save", "after-reload")[index]
                and observed["revision"] == ("0", "1", "1")[index]
                and all(observed[k] is True for k in fields - {"stage", "key", "revision"}),
                "NODE_REMINDER_DOM_FIELDS")
        key = observed["key"]
        require(isinstance(key, dict) and set(key) == {"kind", "classId", "date"}
                and key["kind"] == "REMINDER" and key["classId"] == "1"
                and isinstance(key["date"], str) and re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", key["date"]),
                "NODE_REMINDER_DOM_KEY")
        try:
            require(date.fromisoformat(key["date"]).isoformat() == key["date"], "NODE_REMINDER_DOM_DATE")
        except ValueError:
            raise RuntimeError("NODE_REMINDER_DOM_DATE") from None
        require(content_paths == {f'/fc/api/v1/content/reminders/1/{key["date"]}'}, "NODE_REMINDER_DOM_BINDING")


class BrowserObserver:
    def __init__(self, remote, local_root, report_path, marker, asset_manifest,
                 expected_csp, identity, ssh_target, content_kind="HOMEWORK"):
        require(content_kind in ("HOMEWORK", "REMINDER"), "BROWSER_CONTENT_KIND")
        self.content_kind = content_kind
        self.remote, self.local_root = remote, Path(local_root)
        self.report_path, self.marker = Path(report_path), marker
        self.manifest = json.loads(encoded(asset_manifest))
        self.expected_csp, self.identity, self.ssh_target = expected_csp, identity, ssh_target
        self.report = {"status": "NOT_RUN", "cleanup": "NOT_RUN", "marker": marker,
                       "credentialScope": "Cookie/CSRF private stdin only; no raw CDP frames",
                       "edgeSessionCapSeconds": 180, "ownerExitObservationSeconds": 215,
                       "errors": []}
        self.result = {}
        self.helper = self.owner = self.owner_logs = self.node = self.node_logs = None
        self.tunnel = self.control_file = self.control_hash = self.owner_marker = None
        self.edge_report = self.node_report = self.cdp_root = None
        self.prepared = self.started = self.closed = False
        self._secrets = []
        self._node_source_sha = None

    def _remaining(self, deadline):
        value = deadline - time.monotonic()
        require(value > 0, "BROWSER_DEADLINE")
        return value

    def _safe(self, raw):
        lowered = raw.lower()
        require(not any(secret.lower() in lowered for secret in self._secrets if secret),
                "PRIVATE_VALUE_IN_BROWSER_OUTPUT")

    def _file(self, path, limit=MAX_BYTES):
        require(stat.S_ISREG(path.lstat().st_mode), "REPORT_NOT_REGULAR")
        require(path.stat().st_size <= limit, "REPORT_BYTE_LIMIT")
        raw = path.read_bytes()
        require(len(raw) <= limit, "REPORT_BYTE_LIMIT")
        self._safe(raw)
        value = json.loads(raw)
        require(isinstance(value, dict), "REPORT_SHAPE")
        return value, {"path": str(path), "bytes": len(raw), "sha256": digest(raw)}

    def _line(self, process, logs, deadline):
        while True:
            remaining = self._remaining(deadline)
            require(not logs.overflow.is_set(), "BROWSER_OUTPUT_BOUND")
            try:
                return logs.lines.get(timeout=min(0.1, remaining))
            except queue.Empty:
                require(process.poll() is None or any(t.is_alive() for t in logs.threads),
                        "BROWSER_HELPER_EXITED_BEFORE_REPLY")

    def _send(self, message, deadline):
        data = encoded(message) + b"\n"
        require(len(data) <= MAX_INPUT and self.node.poll() is None, "NODE_INPUT_BOUND_OR_EXIT")
        # No writer thread and no unbounded buffered-pipe flush. A stalled Node
        # input consumes the same absolute prepare/run deadline.
        descriptor = self.node.stdin.fileno()
        os.set_blocking(descriptor, False)
        with selectors.DefaultSelector() as ready:
            ready.register(descriptor, selectors.EVENT_WRITE)
            offset = 0
            while offset < len(data):
                require(self.node.poll() is None, "NODE_EXITED_DURING_INPUT")
                require(ready.select(min(0.1, self._remaining(deadline))) or
                        time.monotonic() < deadline, "NODE_INPUT_DEADLINE")
                try:
                    offset += os.write(descriptor, data[offset:offset + 4096])
                except BlockingIOError:
                    pass

    def _read_control(self):
        if self.control_file is None or not self.control_file.exists():
            return False
        require(stat.S_ISREG(self.control_file.lstat().st_mode)
                and self.control_file.stat().st_mode & 0o077 == 0
                and self.control_file.stat().st_size <= 16 * 1024, "OWNER_CONTROL_NOT_PRIVATE")
        raw = self.control_file.read_bytes()
        require(len(raw) <= 16 * 1024, "OWNER_CONTROL_BOUND")
        state = json.loads(raw)
        require(state.get("schemaVersion") == 1 and state.get("sshTarget") == self.ssh_target
                and re.fullmatch(r"FutureClassroom-Test-Browser-[0-9a-f]{32}", state.get("marker", ""))
                and re.fullmatch(r"[0-9a-f]{64}", state.get("stopCapability", "")), "OWNER_CONTROL_IDENTITY")
        require(self.control_hash is None or self.control_hash == digest(raw), "OWNER_CONTROL_CHANGED")
        self.control_hash, self.owner_marker = digest(raw), state["marker"]
        # Retain only its hash; the stop capability remains in its mode-0600 file.
        return True

    def prepare(self, public_pem):
        require(not self.started and not self.closed, "OBSERVER_ALREADY_STARTED")
        self.started = True
        deadline = time.monotonic() + 60
        phase = "prepare-public-spki"
        try:
            require(re.fullmatch(r"FutureClassroom-Test-TLS-[0-9a-f]{32}", self.marker)
                    and self.remote.host == self.ssh_target, "BROWSER_COMPOSITION")
            pem = public_pem.encode("ascii") if isinstance(public_pem, str) else bytes(public_pem)
            require(len(pem) <= MAX_INPUT and pem.startswith(b"-----BEGIN CERTIFICATE-----"), "PUBLIC_PEM_BOUND")
            public = subprocess.run(["openssl", "x509", "-pubkey", "-noout"], input=pem,
                                    capture_output=True, timeout=min(5, self._remaining(deadline)))
            require(public.returncode == 0 and len(public.stdout) <= MAX_INPUT, "PUBLIC_KEY_EXTRACTION")
            der = subprocess.run(["openssl", "pkey", "-pubin", "-outform", "DER"], input=public.stdout,
                                 capture_output=True, timeout=min(5, self._remaining(deadline)))
            require(der.returncode == 0 and 0 < len(der.stdout) <= MAX_INPUT, "PUBLIC_SPKI_EXTRACTION")
            spki = base64.b64encode(hashlib.sha256(der.stdout).digest()).decode("ascii")
            self.helper = load_helpers()
            directory = Path(__file__).resolve().parent
            owner_source = directory / "windows-test-edge-owner.py"
            node_source = directory / "windows-native-browser-harness.mjs"
            self._node_source_sha = digest(node_source.read_bytes())
            self.report["sourceSha256"] = {
                "observer": digest(Path(__file__).read_bytes()), "edgeOwner": digest(owner_source.read_bytes()),
                "nodeHarness": self._node_source_sha, "tlsOwnershipHelpers": digest((directory / "windows-tls-probe.py").read_bytes()),
            }
            self.report["spkiSha256Base64"] = spki
            prefix = self.report_path.resolve()
            prefix.parent.mkdir(parents=True, exist_ok=True)
            self.edge_report = prefix.with_name(prefix.name + ".browser-edge-owner.json")
            self.node_report = prefix.with_name(prefix.name + ".browser-node.json")
            self.control_file = self.edge_report.with_name(self.edge_report.name + ".control.json")
            require(not any(p.exists() for p in (self.edge_report, self.node_report, self.control_file)),
                    "BROWSER_ARTIFACT_ALREADY_EXISTS")
            self.report["ownerReportPath"], self.report["nodeReportPath"] = str(self.edge_report), str(self.node_report)
            phase = "prepare-original-edge-owner"
            command = [sys.executable, "-B", str(owner_source), "run", "--spki", spki,
                       "--report", str(self.edge_report), "--ssh-target", self.ssh_target]
            if self.identity:
                command += ["--identity", str(self.identity)]
            self.owner = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            self.owner_logs = self.helper.Logs(self.owner)
            controlled = False
            while True:
                line = self._line(self.owner, self.owner_logs, deadline)
                if line.startswith("EDGE_CACHE_CONTROL "):
                    value = json.loads(line[len("EDGE_CACHE_CONTROL "):])
                    require(not controlled and Path(value["controlFile"]) == self.control_file
                            and self._read_control() and value.get("marker") == self.owner_marker,
                            "OWNER_CONTROL_PROTOCOL")
                    controlled = True
                elif line.startswith("EDGE_CACHE_READY "):
                    value = json.loads(line[len("EDGE_CACHE_READY "):])
                    require(controlled and value.get("marker") == self.owner_marker
                            and type(value.get("port")) is int and 1 <= value["port"] <= 65535
                            and re.fullmatch(r"/devtools/browser/[0-9a-fA-F-]{16,80}", value.get("webSocketPath", ""))
                            and value.get("boundLoopback") is True, "OWNER_READY_PROTOCOL")
                    break
            self.report["edgeReady"] = value
            phase = "prepare-independent-cdp-tunnel"
            self.cdp_root = self.local_root / ("browser-cdp-" + uuid.uuid4().hex[:12])
            self.cdp_root.mkdir(mode=0o700, parents=False, exist_ok=False)
            require(self._remaining(deadline) > 12, "CDP_PREPARE_BUDGET")
            self.tunnel = self.helper.Tunnel(self.remote, self.cdp_root)
            port = self.tunnel.open(value["port"])
            cdp_url = "ws://127.0.0.1:" + str(port) + value["webSocketPath"]
            self._secrets.append(cdp_url.encode())
            phase = "prepare-node-cdp-context"
            self.node = subprocess.Popen(["node", str(node_source), "--report", str(self.node_report)],
                                         stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            self.node_logs = self.helper.Logs(self.node)
            self._send({"type": "INIT", "cdpUrl": cdp_url, "expectedCsp": self.expected_csp,
                        "assetManifest": self.manifest, "marker": self.marker,
                        "contentKind": self.content_kind}, deadline)
            ready = json.loads(self._line(self.node, self.node_logs, deadline))
            require(set(ready) == {"type", "marker", "browserVersion", "scope"}
                    and ready.get("type") == "READY" and ready.get("marker") == self.marker,
                    "NODE_READY_PROTOCOL")
            self._safe(encoded(ready))
            self.report["nodeReady"] = ready
            self.prepared = True
            self.report["status"] = "PREPARED"
        except Exception as error:
            self.report["status"] = "FAIL"
            self.report["errors"].append(failure(error, phase))
            raise RuntimeError("NATIVE_BROWSER_PREPARE_FAILED") from None

    def _validate_result(self, value, message, run):
        validate_network_failures(value, run, self.manifest, self.content_kind)
        expected_operations = API_OPERATIONS if self.content_kind == "HOMEWORK" else REMINDER_OPERATIONS
        require(set(value) <= REPORT_KEYS and value.get("schemaVersion") == 1
                and value.get("status") == "PASS" and value.get("marker") == self.marker
                and value.get("generation") == run["generation"] and value.get("origin") == run["origin"]
                and value.get("maxMillis") == run["maxMillis"]
                and value.get("sourceSha256") == self._node_source_sha
                and value.get("assetManifestCanonicalSha256") == digest(encoded(self.manifest))
                and value.get("expectedCspSha256") == digest(self.expected_csp.encode())
                and value.get("contextDisposed") is True and value.get("cdpDisconnected") is True
                and value.get("sessionCsrfMatched") is True and value.get("writeOutcome") == "COMMITTED"
                and type(value.get("contentPosts")) is int and value["contentPosts"] == 1
                and value.get("contentKind") == self.content_kind,
                "NODE_REPORT_IDENTITY_OR_OUTCOME")
        pair = command_identity({k:value.get(k) for k in ("commandId","commandTicket")})
        require(command_identity(value.get("issuedCommand")) == pair
                and type(value.get("commandIssues")) is int and value["commandIssues"] == 1, "NODE_ISSUED_PAIR_MISMATCH")
        require(type(value.get("reminderShortcutClicks")) is int
                and value["reminderShortcutClicks"] == (2 if self.content_kind == "REMINDER" else 0),
                "NODE_REMINDER_SHORTCUT_COUNT")
        records = value.get("network")
        require(isinstance(records, list) and len(records) <= 128, "NODE_NETWORK_BOUND")
        assets = {asset["path"]: asset for asset in self.manifest["assets"]}
        prefix = "homework" if self.content_kind == "HOMEWORK" else "reminders"
        api = ("/fc/api/v1/status", "/fc/api/v1/session", f"/fc/api/v1/content/{prefix}/scopes/0")
        ids = r"[1-9][0-9]{0,19}/" * (3 if self.content_kind == "HOMEWORK" else 1)
        content = f"/fc/api/v1/content/{prefix}/" + ids + r"[0-9]{4}-[0-9]{2}-[0-9]{2}"
        for record in records:
            require(isinstance(record, dict) and set(record) <= RECORD_KEYS
                    and record.get("method") in ("GET", "POST") and isinstance(record.get("url"), str),
                    "NODE_NETWORK_SHAPE")
            path = record["url"].removeprefix(run["origin"])
            is_issue = path == "/fc/api/v1/commands" and record["method"] == "POST"
            is_content = re.fullmatch(content, path) is not None
            is_visual = self.content_kind == "HOMEWORK" and re.fullmatch(content + r"/visual", path) is not None
            require(record["url"] == run["origin"] + path
                    and (is_issue or is_content or record["method"] == "GET" and
                         (is_visual or path in api or path == "/fc/" or path.startswith("/fc/") and path[4:] in assets)),
                    "NODE_UNEXPECTED_TARGET")
            if "csp" in record:
                require(record["csp"] == self.expected_csp, "NODE_CSP_MISMATCH")
            statuses = (201,) if is_issue else (200,304,None)
            require(record.get("status") in statuses and record.get("wireStatus") in statuses,
                    "NODE_UNEXPECTED_HTTP_STATUS")
            require(record.get("finished") is True and record.get("bodyVerified") is True,
                    "NODE_INCOMPLETE_RESPONSE")
        wires = [record for record in records if record.get("wireStatus") == 304 or
                 record.get("wireStatus") is not None and not
                 (record.get("servedFromCache") or record.get("fromDiskCache") or
                  record.get("fromServiceWorker") or record.get("fromPrefetchCache"))]
        require(type(value.get("wireResponseCount")) is int and value["wireResponseCount"] == len(wires)
                and value.get("wireResponses") == wires and value.get("observedRequestCount") == len(records)
                and value["contentPosts"] == sum(record["method"] == "POST" and record["url"] != run["origin"]+"/fc/api/v1/commands" for record in records)
                and value.get("apiResponses") == sum(expected_operations.values()) and value.get("pageErrorCount") == 0
                and value.get("consoleErrorCount") == 0,
                "NODE_WIRE_LEDGER_MISMATCH")
        api_records = [record for record in records if "/api/v1/" in record["url"]]
        require(len(api_records) == sum(expected_operations.values()) and all(record.get("wireStatus") == (201 if record["url"] == run["origin"]+"/fc/api/v1/commands" else 200)
                and record.get("status") == record.get("wireStatus") and not any(record.get(key) for key in
                ("servedFromCache", "fromDiskCache", "fromServiceWorker", "fromPrefetchCache"))
                for record in api_records), "NODE_API_WIRE_IDENTITY")
        operations = dict.fromkeys(API_OPERATIONS, 0)
        content_paths, visual_paths = set(), set()
        for record in api_records:
            path = record["url"].removeprefix(run["origin"])
            if path == "/fc/api/v1/commands" and record["method"] == "POST": operations["commandIssues"] += 1
            elif path == api[0] and record["method"] == "GET": operations["statusGets"] += 1
            elif path == api[1] and record["method"] == "GET": operations["sessionGets"] += 1
            elif path == api[2] and record["method"] == "GET": operations["scopeGets"] += 1
            elif re.fullmatch(content, path):
                operations["contentPosts" if record["method"] == "POST" else "contentGets"] += 1
                content_paths.add(path)
            elif re.fullmatch(content + r"/visual", path) and record["method"] == "GET":
                operations["visualGets"] += 1
                visual_paths.add(path)
            else: raise RuntimeError("NODE_API_OPERATION_UNEXPECTED")
        reported_operations = value.get("apiOperations")
        require(isinstance(reported_operations, dict) and set(reported_operations) == set(API_OPERATIONS)
                and all(type(n) is int for n in reported_operations.values())
                and operations == expected_operations and reported_operations == operations
                and len(content_paths) == 1
                and visual_paths == ({next(iter(content_paths)) + "/visual"} if self.content_kind == "HOMEWORK" else set()),
                "NODE_EXACT_API_OPERATION_LEDGER")
        if self.content_kind == "HOMEWORK":
            validate_visual_observations(value)
            require(value.get("reminderObservations") == [], "NODE_HOMEWORK_NO_REMINDER_DOM")
        else:
            require(type(value.get("visualReads")) is int and value["visualReads"] == 0
                    and value.get("visualObservations") == [], "NODE_REMINDER_NO_VISUAL")
            validate_reminder_observations(value, content_paths)
        require(value.get("observedResponseCount") == sum(record.get("status") is not None for record in records)
                and value.get("cacheOnlyResponseCount") == sum(record not in wires and
                    bool(record.get("servedFromCache") or record.get("fromDiskCache")) for record in records),
                "NODE_CACHE_LEDGER_MISMATCH")
        for asset in value.get("assets", []):
            require(isinstance(asset, dict) and set(asset) == {"path", "bytes", "sha256", "verified"}
                    and asset.get("path") in assets and asset.get("verified") is True
                    and asset.get("bytes") == assets[asset["path"]]["sizeBytes"]
                    and asset.get("sha256") == assets[asset["path"]]["sha256"], "NODE_ASSET_IDENTITY")
        require(set(message) == {"type", "status", "marker", "wireResponseCount", "contentPosts", "contextDisposed", "report"}
                and message.get("type") == "RESULT" and message.get("status") == "PASS"
                and message.get("marker") == self.marker and message.get("report") == str(self.node_report)
                and message.get("wireResponseCount") == len(wires) and message.get("contentPosts") == 1
                and message.get("contextDisposed") is True, "NODE_RESULT_PROTOCOL")

    def _node_raw(self):
        drain_error = None
        try:
            self.node_logs.join()
        except Exception as error:
            drain_error = error
        raw = self.node_logs.report()
        private = False
        for item in raw.values():
            try:
                self._safe(base64.b64decode(item["base64"], validate=True))
            except Exception:
                # Keep non-reversible identity evidence of the failure, without
                # copying a leaked credential into the encompassing TLS report.
                item.pop("base64", None)
                item["privateOutputOmitted"] = True
                private = True
        self.report["nodeRaw"] = raw
        require(not private, "PRIVATE_VALUE_IN_BROWSER_OUTPUT")
        require(drain_error is None and all(item["captureScope"] == "COMPLETE" for item in raw.values()),
                "NODE_RAW_INCOMPLETE")

    def run(self, client):
        require(self.prepared and not self.closed and not self.result, "OBSERVER_RUN_STATE")
        phase = "run-private-input"
        try:
            maximum = min(12000, int((client.deadline - time.monotonic() - 5) * 1000))
            require(maximum > 0 and isinstance(client.cookie, str)
                    and re.fullmatch(r"__Host-FutureClassroom=[0-9a-fA-F]{64}", client.cookie)
                    and isinstance(client.csrf, str) and re.fullmatch(r"[0-9a-fA-F]{64}", client.csrf),
                    "BROWSER_RUN_AUTH_OR_BUDGET")
            self._secrets.extend((client.cookie.encode(), client.cookie.split("=", 1)[1].encode(), client.csrf.encode()))
            generation = client.ready.get("generation")
            require(type(generation) is int and 0 < generation <= 9007199254740991, "BROWSER_GENERATION")
            run = {"type": "RUN", "origin": client.ready["origin"], "cookie": client.cookie,
                   "expectedCsrf": client.csrf, "maxMillis": maximum, "marker": self.marker, "generation": generation}
            deadline = min(client.deadline - 2, time.monotonic() + maximum / 1000 + 3)
            self._send(run, deadline)
            self.node.stdin.close()
            phase = "run-node-result-and-actual-exit"
            line = self._line(self.node, self.node_logs, deadline)
            self._safe(line.encode())
            message = json.loads(line)
            self.node.wait(timeout=self._remaining(deadline))
            self.report["nodeActualExitCode"] = self.node.returncode
            self._node_raw()
            value, identity = self._file(self.node_report)
            self.report["nodeReport"] = identity
            diagnostics = validate_network_failures(value, run, self.manifest, self.content_kind)
            if diagnostics:
                require(value.get("marker") == self.marker and value.get("generation") == run["generation"]
                        and value.get("origin") == run["origin"] and value.get("maxMillis") == run["maxMillis"]
                        and value.get("sourceSha256") == self._node_source_sha and value.get("contentKind") == self.content_kind,
                        "NODE_FAILURE_REPORT_IDENTITY")
                self.report["networkFailureDiagnostics"] = diagnostics
            require(self.node.returncode == 0, "NODE_ACTUAL_EXIT_FAILED")
            stdout_lines = bytes(self.node_logs.stdout).decode("utf-8", "strict").splitlines()
            require(len(stdout_lines) == 2 and json.loads(stdout_lines[0]).get("type") == "READY"
                    and json.loads(stdout_lines[1]) == message, "NODE_STDOUT_SEQUENCE")
            self._validate_result(value, message, run)
            self.result = value
            self.report.update({"status": "PASS", "result": value, "wireResponseCount": value["wireResponseCount"]})
            return self.result
        except Exception as error:
            self.report["status"] = "FAIL"
            self.report["errors"].append(failure(error, phase))
            raise RuntimeError("NATIVE_BROWSER_RUN_FAILED") from None

    def close(self):
        if self.closed and self.report["cleanup"] == "PASS":
            return self.report
        # Failed cleanup is resumable only through these original Popen/owner
        # capabilities; never allocate a replacement browser or tunnel.
        self.closed = True
        errors = []

        def attempt(phase, action):
            try:
                action()
            except Exception as error:
                errors.append(failure(error, phase))

        def stop_node():
            if self.node is None:
                return
            if self.node.poll() is None:
                self.node.terminate()
                try:
                    self.node.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    self.node.kill()
                    self.node.wait(timeout=3)
            self.report["nodeActualExitCode"] = self.node.returncode

        if self.node is not None and self.node.stdin and not self.node.stdin.closed:
            attempt("close-original-node-stdin", self.node.stdin.close)
        attempt("close-original-node", stop_node)
        if self.node_logs:
            attempt("preserve-safe-node-output", self._node_raw)
        if self.tunnel:
            attempt("close-independent-cdp-tunnel", self.tunnel.close)
            attempt("preserve-cdp-tunnel-output", lambda: self.report.update({"cdpTunnelRaw": self.tunnel.logs.report()}))
        if self.cdp_root:
            attempt("remove-empty-cdp-control-directory", lambda: self.cdp_root.rmdir() if self.cdp_root.exists() else None)

        def request_owner_stop():
            if self.owner is None:
                return
            # If prepare failed before CONTROL was consumed, use only the same
            # deterministic fresh control path, never a PID/name fallback.
            if self.owner.poll() is None:
                require(self._read_control(), "OWNER_CONTROL_UNAVAILABLE")
                command = [sys.executable, "-B", str(Path(__file__).resolve().with_name("windows-test-edge-owner.py")),
                           "stop", "--state", str(self.control_file)]
                stopped = subprocess.run(command, capture_output=True, timeout=25)
                self._safe(stopped.stdout + stopped.stderr)
                self.report["ownerStopRequest"] = {"exitCode": stopped.returncode,
                    **{name: {"bytes": len(raw), "sha256": digest(raw), "base64": base64.b64encode(raw).decode()}
                       for name, raw in (("stdout", stopped.stdout), ("stderr", stopped.stderr))}}
                require(stopped.returncode == 0, "OWNER_STOP_REQUEST_FAILED")

        def observe_owner_exit():
            if self.owner is None:
                return
            # This is the ORIGINAL run Popen, not the stop request process.
            # On timeout retain the capability/profile; its original 180s cap
            # remains active. Never turn an unobserved exit into cleanup PASS.
            self.owner.wait(timeout=215)
            self.report["ownerActualExitCode"] = self.owner.returncode
            value, identity = self._file(self.edge_report, limit=16 * 1024 * 1024)
            self.report["ownerReport"] = identity
            outcome = value.get("nativeOutcome", {})
            require(self.owner.returncode == 0 and value.get("status") == "PASS"
                    and value.get("cleanup") == "PASS" and value.get("marker") == self.owner_marker
                    and value.get("rawPreservation", {}).get("status") == "PASS"
                    and outcome.get("actualJobProcessesZero") is True
                    and outcome.get("originalPrimaryExited") is True
                    and outcome.get("originalHandlesClosed") is True
                    and value.get("cleanupDetails", {}).get("rootAbsent") is True,
                    "OWNER_ACTUAL_PHYSICAL_CLEANUP_UNPROVEN")
            self.report["ownerPhysicalCleanup"] = "PASS"

        attempt("request-original-edge-owner-stop", request_owner_stop)
        attempt("observe-original-edge-owner-exit", observe_owner_exit)
        if self.owner_logs:
            attempt("drain-original-edge-owner-output", self.owner_logs.join)
            # Preserve the exact bounded stream even when EOF/overflow checking
            # failed; Logs.report labels any prefix instead of claiming full SHA.
            self.report["ownerSupervisorRaw"] = self.owner_logs.report()
        if not errors and self.control_file and self.control_file.exists():
            attempt("remove-private-owner-control-after-proof", lambda: (self._read_control(), self.control_file.unlink()))
        self.report["cleanup"] = "FAIL" if errors else "PASS"
        self.report["errors"].extend(errors)
        if errors:
            self.report["status"] = "FAIL"
            self.report["retainedControlFile"] = str(self.control_file) if self.control_file else None
            self.report["ownerProcessRetained"] = self.owner is not None and self.owner.poll() is None
            raise RuntimeError("NATIVE_BROWSER_CLEANUP_FAILED")
        self.report.pop("retainedControlFile", None)
        self.report["ownerProcessRetained"] = False
        return self.report
