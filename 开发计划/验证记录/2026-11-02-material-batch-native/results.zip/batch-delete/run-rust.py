from pathlib import Path
import os,subprocess,json,time,hashlib
R=Path('/tmp/fc-batch-delete');W=Path('/workspace/共享/Eliora/未来教室计划'); assert (R/'.owner').read_text()=='future-classroom-batch-delete/v1\n';mode=__import__('sys').argv[1];assert mode in ['host','gnu'];target=R/(mode+'-target');target.mkdir(exist_ok=True);(target/'.owner').write_text('future-classroom-batch-delete-'+mode+'/v1\n');env=os.environ.copy();env['CARGO_TARGET_DIR']=str(target);env['CARGO_BUILD_JOBS']='4';rows=[]
commands=([('host-clippy',['cargo','clippy','--workspace','--all-targets','--release','--locked','--','-D','warnings']),('host-test',['cargo','test','--workspace','--release','--locked','--','--test-threads=2'])] if mode=='host' else [('gnu-clippy',['cargo','clippy','--workspace','--all-targets','--release','--locked','--target','i686-pc-windows-gnu','--','-D','warnings']),('gnu-tests',['cargo','test','-p','fc-bootstrap','--lib','--bin','fc-bootstrap','--release','--locked','--target','i686-pc-windows-gnu','--no-run','--message-format=json']),('gnu-gui',['cargo','build','-p','fc-bootstrap','--release','--locked','--target','i686-pc-windows-gnu','--message-format=json'])])
for n,c in commands:
 t=time.monotonic()
 with (R/(n+'.stdout.log')).open('wb') as a,(R/(n+'.stderr.log')).open('wb') as b:
  p=subprocess.Popen(c,cwd=W,env=env,stdout=a,stderr=b);(R/(mode+'-active.json')).write_text(json.dumps({'pid':p.pid,'command':c})+'\n');ret=p.wait()
 rows.append({'name':n,'command':c,'exit':ret,'seconds':time.monotonic()-t});(R/(mode+'-results.json')).write_text(json.dumps(rows,indent=2)+'\n');print(n,ret,flush=True)
 if ret:break
(R/(mode+'-terminal.json')).write_text(json.dumps({'exit':rows[-1]['exit'],'rows':len(rows)})+'\n');raise SystemExit(rows[-1]['exit'])
