from pathlib import Path
import subprocess,json,urllib.request
r=Path('/tmp/fc-batch-delete');c=subprocess.run(['git','credential','fill'],input=b'protocol=https\nhost=github.com\n\n',stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True,timeout=20);fields=dict(x.split(b'=',1) for x in c.stdout.splitlines() if b'=' in x);token=fields[b'password'].decode();results=[]
for i in [41446931176,41446935738]:
 req=urllib.request.Request(f'https://api.github.com/repos/NevermoreN/future-classroom/actions/runs/{i}',headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','User-Agent':'future-classroom-compile-check'})
 with urllib.request.urlopen(req,timeout=30) as res:x=json.load(res)
 results.append({k:x[k] for k in ['id','head_sha','status','conclusion','html_url']})
(r/'previous-commit-ci.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results))
