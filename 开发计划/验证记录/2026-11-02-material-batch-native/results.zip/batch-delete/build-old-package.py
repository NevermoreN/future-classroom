from pathlib import Path
import subprocess,json,zipfile,hashlib
r=Path('/tmp/fc-batch-delete');rows=[]
for n,cmd in [('old-ci',['npm','ci','--ignore-scripts']),('old-build',['npm','run','build'])]:
 with (r/(n+'.stdout.log')).open('wb')as a,(r/(n+'.stderr.log')).open('wb')as b:p=subprocess.run(cmd,cwd=r/'old-package-source/web',stdout=a,stderr=b)
 rows.append({'name':n,'exit':p.returncode});(r/'old-package-results.json').write_text(json.dumps(rows)+'\n');print(n,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
for name,root in [('old-web-bundle',r/'old-package-source/web/dist'),('new-web-bundle',r/'web/dist')]:
 out=r/(name+'.zip')
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED)as z:
  for p in sorted(root.rglob('*')):
   if p.is_file():z.write(p,p.relative_to(root).as_posix())
 print(name,out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest(),flush=True)
