from pathlib import Path
import hashlib,subprocess,json,sys
r=Path('/tmp/fc-batch-delete');support=r/'browser-support';gui=r/'gnu-target/i686-pc-windows-gnu/release/fc-bootstrap.exe';stem=sys.argv[1];assert stem in ['second','third','fourth'];report=r/('browser-'+stem+'.json');assert not report.exists() and not report.with_name(report.name+'.pending.json').exists();assert hashlib.sha256(gui.read_bytes()).hexdigest()=='6059382155850a79d9bc8cd68537697abbd8b5fb928be9301d26fb96365fe043'
c=['python3',str(support/'windows-teacher-browser-probe.py'),'--execute','--ssh-target','future-classroom-win11','--identity','/config/.local/share/future-classroom-test-access/win11-192.168.10.212','--exe',str(gui),'--old-web-bundle',str(r/'old-web-bundle.zip'),'--new-web-bundle',str(r/'new-web-bundle.zip'),'--report',str(report)]
with (r/('browser-'+stem+'.stdout.log')).open('wb')as a,(r/('browser-'+stem+'.stderr.log')).open('wb')as b:p=subprocess.run(c,stdout=a,stderr=b)
(r/('browser-'+stem+'.controller.json')).write_text(json.dumps({'command':c,'exit':p.returncode})+'\n');print('Real teacher browser '+stem+' exit:',p.returncode,flush=True);raise SystemExit(p.returncode)
