use std::sync::atomic::{AtomicU64, Ordering};
fn main() {
 let value = AtomicU64::new(7);
 assert_eq!(value.try_update(Ordering::Relaxed, Ordering::Relaxed, |n| n.checked_add(1)), Ok(7));
 assert_eq!(value.load(Ordering::Relaxed), 8);
 let full = AtomicU64::new(u64::MAX);
 assert_eq!(full.try_update(Ordering::Relaxed, Ordering::Relaxed, |n| n.checked_add(1)), Err(u64::MAX));
 assert_eq!(full.load(Ordering::Relaxed), u64::MAX);
 println!("ATOMIC_TRY_UPDATE_RELAXED_CHECKED_ADD_AND_OVERFLOW_PASS");
}
