use std::sync::atomic::{AtomicU64, Ordering};
fn main() {
 let value = AtomicU64::new(7);
 assert_eq!(value.try_update(Ordering::Relaxed, Ordering::Relaxed, |n| n.checked_add(1)), Ok(7));
 assert_eq!(value.load(Ordering::Relaxed), 8);
}
