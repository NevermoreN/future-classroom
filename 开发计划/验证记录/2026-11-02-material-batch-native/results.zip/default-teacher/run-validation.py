from pathlib import Path
import subprocess,os,json,time,sys
r=Path('/tmp/fc-default-teacher');kind=sys.argv[1];assert kind in ['host','gnu']
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(r/(kind+'-target')),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_OPT_LEVEL='1',CARGO_PROFILE_TEST_OPT_LEVEL='1')
common=['cargo','clippy','--workspace','--all-targets','--locked']
if kind=='gnu':common+=['--target','i686-pc-windows-gnu']
commands=[(kind+'-clippy',common+['--','-D','warnings'])]
if kind=='host':commands.append(('host-tests',['cargo','test','--workspace','--locked','--','--test-threads=2']))
else:
 commands.append(('gnu-tests',['cargo','test','-p','fc-bootstrap','--lib','--bin','fc-bootstrap','--locked','--target','i686-pc-windows-gnu','--no-run','--message-format=json']))
 commands.append(('gnu-gui',['cargo','build','-p','fc-bootstrap','--locked','--target','i686-pc-windows-gnu','--message-format=json']))
rows=[]
for name,cmd in commands:
 start=time.monotonic()
 with (r/(name+'.stdout.log')).open('wb') as out,(r/(name+'.stderr.log')).open('wb') as err:
  p=subprocess.Popen(cmd,env=env,stdout=out,stderr=err);(r/(kind+'-active.json')).write_text(json.dumps(dict(pid=p.pid,command=cmd)))
  code=p.wait()
 rows.append(dict(name=name,command=cmd,exit=code,seconds=time.monotonic()-start));(r/(kind+'-results.json')).write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True)
 if code:break
(r/(kind+'-terminal.json')).write_text(json.dumps(dict(exit=code,rows=len(rows),profile='development opt-level=1, debug=0; not formal release qualification'))+'\n');sys.exit(code)
