from pathlib import Path
import ast,hashlib,json,zipfile,shutil,stat
R=Path('/tmp/fc-default-teacher');E=Path('开发计划/验证记录/2026-11-02-material-batch-native');Z=E/'results.zip';T=E/'.results.zip.default-teacher-staged'
assert (R/'.owner').read_text()=='future-classroom-default-teacher-candidate/v1\n' and not T.exists()
summary=json.loads((E/'summary.json').read_bytes());assert hashlib.sha256(Z.read_bytes()).hexdigest()==summary['archive']['sha256'] and summary['archive']['members']==930
for n in ['host-terminal.json','gnu-terminal.json','windows-controller.json']:assert json.loads((R/n).read_bytes())['exit']==0
w=json.loads((R/'windows.json').read_bytes());assert w['status']=='PASS' and w['cleanup']=='PASS'
h=json.loads((R/'host-qualification.json').read_bytes());q=json.loads((R/'windows-qualification.json').read_bytes());checks=json.loads((R/'final-checks.json').read_bytes())
for row in json.loads((R/'main-frozen.json').read_bytes())['files']:assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
next_root=Path('/tmp/fc-update-run-candidate');assert next_root.is_dir() and (next_root/'.owner').is_file()
key=Path('/config/.local/share/future-classroom-test-access/win11-192.168.10.212');kstat=key.stat();assert stat.S_IMODE(kstat.st_mode)==0o600
source=ast.parse(Path('/tmp/fc-round80-controlled-repair/root-scan-d13-credential-views-first.py').read_text());nodes=[]
for node in source.body:
 if isinstance(node,(ast.Import,ast.ImportFrom)) or isinstance(node,ast.FunctionDef) and node.name=='scan':nodes.append(node)
 elif isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in {'patterns','stats','hits'} for t in node.targets):nodes.append(node)
ns={};exec(compile(ast.Module(body=nodes,type_ignores=[]),'scanner','exec'),ns)
files=sorted(p for p in R.iterdir() if p.is_file() and (p.suffix in {'.json','.jsonl','.log','.py','.patch'} or p.name=='.owner')); originals=[]
with zipfile.ZipFile(Z) as old,zipfile.ZipFile(T,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as out:
 historical={i.filename:old.read(i) for i in old.infolist()};assert len(historical)==930
 for n,b in historical.items():out.writestr(n,b)
 for p in files:
  assert not p.is_symlink();b=p.read_bytes();b.decode('utf-8-sig');n='default-teacher/'+p.name;assert n not in historical
  out.writestr(n,b);originals.append(dict(member=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()));ns['stats']['members']+=1;ns['scan'](b,n)
assert not ns['hits'],[(x['path'],x['rule']) for x in ns['hits']]
with zipfile.ZipFile(T) as z:
 assert len(z.namelist())==len(set(z.namelist()))<=1500 and sum(i.file_size for i in z.infolist())<30*1024*1024
 for n,b in historical.items():assert z.read(n)==b
 for row in originals:assert hashlib.sha256(z.read(row['member'])).hexdigest()==row['sha256']
shutil.rmtree(R);assert not R.exists() and next_root.is_dir()
assert key.stat().st_ino==kstat.st_ino and stat.S_IMODE(key.stat().st_mode)==0o600
cleanup=dict(status='PASS',ownedRoot=str(R),ownedRootAbsent=True,buildTargetsAndPECopiesRemoved=True,windowsOriginalCleanup='PASS',sshdReadback='Running',persistentSSHAuthorizationPreserved=True,privateKeyAttributeOnlyCheck={'mode':'0600','sameInode':True,'contentsRead':False},unfinishedUpdateRunCandidatePreserved=str(next_root),allControllersObservedTerminal=True)
b=json.dumps(cleanup,indent=2).encode()+b'\n';n='default-teacher/cleanup-after-preservation.json'
with zipfile.ZipFile(T,'a',zipfile.ZIP_DEFLATED,compresslevel=9) as z:z.writestr(n,b)
originals.append(dict(member=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
with zipfile.ZipFile(T) as z:
 for n,b in historical.items():assert z.read(n)==b
 for row in originals:assert hashlib.sha256(z.read(row['member'])).hexdigest()==row['sha256']
 count=len(z.namelist());uncompressed=sum(i.file_size for i in z.infolist());assert count<=1500 and uncompressed<30*1024*1024
T.replace(Z)
summary['remaining'][0]='Complete business-data preservation across this project updates, enabled-Run upgrade retention, other account UNKNOWN paths and remaining D11 features'
summary['defaultTeacherQualification']=dict(status='PASS_FINITE_DEFAULT_TEACHER_NATIVE_MANAGEMENT',host=h,windows=q,checks=checks,profile='Development opt-level1/debug0; no claim of formal Release/MSVC qualification',source='default-teacher/main-frozen.json',limitations=['set/replace supported, no clear command in current domain','Other account UNKNOWN readback behavior not fixed by this change','Win7/Win10 actual OS and visible Seewo NOT_RUN','Complete software-update business data preservation NOT_RUN; external Run candidate not integrated/run'],wholeGoal='ACTIVE_INCOMPLETE')
summary['defaultTeacherOriginals']=originals;summary['defaultTeacherCredentialScan']=dict(status='PASS',hitCount=0,stats=ns['stats'],scope='All appended original text and recursive decoded views; prior 930 archive members preserved byte-for-byte');summary['defaultTeacherCleanup']=cleanup
summary['archive'].update(bytes=Z.stat().st_size,sha256=hashlib.sha256(Z.read_bytes()).hexdigest(),members=count,uncompressedBytes=uncompressed,fullReplay='PASS_ALL_930_HISTORICAL_AND_DEFAULT_TEACHER_ORIGINAL_MEMBERS')
(E/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
p=E/'README.md';s=p.read_text().replace('# P3-08 原生及教师网页批量资料导入／删除有限验证记录','# P3-08资料批次与P2-08默认老师有限验证记录').replace('批量删除本轮独占构建目录','批量删除当轮独占构建目录').replace('未完成的默认老师开发候选保留','当时未完成的默认老师开发候选保留')
s+='''\n默认老师设置另按独立冻结源码完成Host1076项、授权Win11库359项／原生249项及自检／隐藏宿主。新增6项用例实际覆盖原生选择确认、原回包丢失、后续更换老师、旧结果与当前设置分列、缺回执不写、CAS冲突和独立数据库重开。此轮使用开发opt-level1/debug0 profile；不冒充正式Release/MSVC或可见希沃验收。原候选、根整合补丁、真实控制器／日志与PE身份分别保存；最初本地目标名选择拒绝不属于Windows失败。保存重放与扫描后已清理默认老师独占候选／构建／PE目录，持续SSH授权保留，尚未验证的升级Run候选另行保留。\n\n旧资料迁移的验收范围已统一明确为本项目软件更新后的数据保留与按需转换；完整业务数据／启用Run在成功升级和失败回滚后的保留仍未完成。默认老师仅设置／替换，其他账号UNKNOWN路径及其余完整D11验收继续保留。\n''';p.write_text(s)
p=Path('开发计划/10-实施进度与验证记录.md');p.write_text(p.read_text()+f'\n默认老师本轮证据已追加至既有有限验证包，全部930件历史与新增{len(originals)}件原字节重放通过，新增文本递归凭据扫描0命中。保存后已清理 `/tmp/fc-default-teacher` 的完成候选、构建目标、测试PE及副本；Win11原清理报告PASS且sshd读回Running，持续SSH授权与仓库外0600私钥保留（仅属性检查）。尚未验证的 `/tmp/fc-update-run-candidate` 开发候选保留，不计作完成。\n')
print(json.dumps(dict(status='PASS',historical=930,added=len(originals),members=count,uncompressedBytes=uncompressed,zipBytes=Z.stat().st_size,cleanup='PASS',scanHits=0)))
