from pathlib import Path
import json,subprocess,time,sys
r=Path('/tmp/fc-default-teacher');cmd=['python3','scripts/windows-probe.py','--host','elior@192.168.10.212','--identity','/config/.local/share/future-classroom-test-access/win11-192.168.10.212','--exe',str(r/'gnu-target/i686-pc-windows-gnu/debug/fc-bootstrap.exe'),'--test-metadata',str(r/'gnu-tests.stdout.log'),'--test-timeout-seconds','180','--report',str(r/'windows.json')]
t=time.monotonic()
with (r/'windows.stdout.log').open('wb') as out,(r/'windows.stderr.log').open('wb') as err:
 code=subprocess.run(cmd,stdout=out,stderr=err).returncode
(r/'windows-controller.json').write_text(json.dumps(dict(command=cmd,exit=code,seconds=time.monotonic()-t),indent=2)+'\n');print(json.dumps(dict(exit=code,seconds=time.monotonic()-t)));sys.exit(code)
