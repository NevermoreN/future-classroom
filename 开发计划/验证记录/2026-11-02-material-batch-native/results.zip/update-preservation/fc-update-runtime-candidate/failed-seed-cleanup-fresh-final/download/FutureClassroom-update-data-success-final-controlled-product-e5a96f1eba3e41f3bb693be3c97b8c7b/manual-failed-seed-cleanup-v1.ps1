param([switch]$Execute,[string]$ScratchRoot,[string]$ExpectedBindingsSha256)
if(-not $Execute){@{status='PREPARED_NOT_RUN';Windows='NOT_CONTACTED';scope='MANUAL_FAILED_SEED_CLEANUP_ONLY'}|ConvertTo-Json -Compress;return}
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$OriginalStartQpc=[Diagnostics.Stopwatch]::GetTimestamp();$OriginalFrequency=[Diagnostics.Stopwatch]::Frequency
$script:result=[ordered]@{status='FAIL_MANUAL_CLEANUP_RETAIN_ORIGINALS';scope='FRESH_MANUAL_FAILED_SEED_EFFECTS_CLEANUP_ONLY_NOT_DATA_VALIDATION';budgetOrigin='NEW_MANUAL_CLEANUP_NOT_EXTENSION_OF_FAILED_600S_RUNTIME';wholeMilliseconds=600000;schoolDataPreservation='NOT_RUN_NOT_CLAIMED';seedPassClaim=$false;phases=@();updateDataStages=@();scratchCleanup='LEFT_TO_ROOT_FRESH_INVENTORY_DOWNLOAD_REPLAY_EXACT_DELETE';databaseOrDpapiContentsCaptured=$false;cleanup='NOT_RUN'}
$script:expectedRunBase64=$null;$script:ownerUnknown=$false;$script:instrumentUnknown=$false;$script:gateSnapshot=$null;$script:retireAttempted=$false;$script:allSetupBusinessSucceeded=$true;$script:installAttempted=$false;$script:formalAttempted=$false;$script:success=$false
$script:cachePaths=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
function Require([bool]$v,[string]$code){if(-not$v){throw $code}}
function Elapsed {Require ($OriginalFrequency-eq[Diagnostics.Stopwatch]::Frequency -and $OriginalStartQpc-gt0) 'ORIGINAL_MONOTONIC_CLOCK';$now=[Diagnostics.Stopwatch]::GetTimestamp();Require ($now-ge$OriginalStartQpc) 'CLOCK_NO_BACKWARD';return [long](($now-$OriginalStartQpc)*1000/$OriginalFrequency)}
function Remaining {return [Math]::Max(0,600000-(Elapsed))}
function Digest([string]$p){return (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function New-Json([string]$p,$v){$b=[Text.UTF8Encoding]::new($false).GetBytes(($v|ConvertTo-Json -Depth 24)+"`n");$f=[IO.File]::Open($p,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);try{$f.Write($b,0,$b.Length);$f.Flush()}finally{$f.Dispose()}}
function Clone($v){return (($v|ConvertTo-Json -Depth 24 -Compress)|ConvertFrom-Json)}
function Known-Path([string]$p){try{$a=[IO.File]::GetAttributes($p);return @{path=$p;status='KNOWN_PRESENT';directory=(($a-band16)-ne0);reparse=(($a-band1024)-ne0)}}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-is[IO.FileNotFoundException]-or$e-is[IO.DirectoryNotFoundException]){return @{path=$p;status='KNOWN_ABSENT'}};return @{path=$p;status='UNKNOWN';exception=$e.GetType().FullName}}}
function Coordination {$g=Known-Path $script:gateRoot;$p=Known-Path (Join-Path $script:gateRoot 'pending.v1');return @{root=$g;pending=$p;namespaceKnownAbsent=($g.status-ceq'KNOWN_ABSENT');pendingKnownAbsent=($p.status-ceq'KNOWN_ABSENT' -and ($g.status-ceq'KNOWN_ABSENT' -or ($g.status-ceq'KNOWN_PRESENT' -and $g.directory -and -not$g.reparse)))}}
function Measure-State([string]$label){return (Clone (Measure-FcProductState -Config $script:c -Expected $label -SourceRoot $ScratchRoot -ExpectedRunBase64 $script:expectedRunBase64))}
function Healthy($v){return ($v.status-ceq'PASS_READONLY_EXPECTED_PRESENT' -and $v.healthyPresent-eq$true -and $v.runExact-eq$true)}
function Absent($v){return ($v.status-ceq'PASS_READONLY_EXPECTED_ABSENT' -and $v.knownAbsent-eq$true -and $v.runAbsent-eq$true)}
function Own-Processes {
 $rows=@();$unknown=@();foreach($p in @(Get-CimInstance Win32_Process -Filter "Name='Setup.exe' OR Name='fc-bootstrap.exe'" -ErrorAction Stop)){
  if([string]::IsNullOrEmpty($p.ExecutablePath)){$unknown+=@{pid=$p.ProcessId;name=$p.Name;status='UNKNOWN_IMAGE_NO_COMMAND_READ'};continue}
  if($p.ExecutablePath-ieq(Join-Path $ScratchRoot 'u1\Setup.exe') -or $p.ExecutablePath-ieq(Join-Path $ScratchRoot 'u2\Setup.exe') -or $p.ExecutablePath-ieq(Join-Path $script:programRoot 'fc-bootstrap.exe')){$rows+=@{pid=$p.ProcessId;image=$p.ExecutablePath;created=[string]$p.CreationDate}}
 };return @{own=@($rows);unknownCandidates=@($unknown);count=$rows.Count;knownZero=($rows.Count-eq0 -and $unknown.Count-eq0);commandsRead=$false;mutations=$false}
}
function Cache-Fact([bool]$present){$v=[Fc80ProductState]::ObserveLocalPackage($script:c.productCode,$script:c.expectedUserSid);if($present){Require ($v.status-ceq'KNOWN_PRESENT_EXACT_API_LOCALPACKAGE_READONLY') 'REAL_LOCALPACKAGE_PRESENT';[void]$script:cachePaths.Add($v.path)}else{Require ($v.status-ceq'KNOWN_PRODUCT_ABSENT_NO_CACHE_PATH') 'REAL_LOCALPACKAGE_ABSENT'};$paths=@();foreach($p in $script:cachePaths){$paths+=,(Known-Path $p)};return @{actualApi=$v;paths=$paths;allObservedAbsent=($script:cachePaths.Count-gt0 -and @($paths|Where-Object{$_.status-cne'KNOWN_ABSENT'}).Count-eq0);mutations=$false}}
function Log-Facts([string]$dir){
 $facts=@();$others=@();$sourceRows=@();$dllRows=@();$derived=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase);$guardSeen=$false;$finalizeSeen=$false;$guardReturn1Count=0
 foreach($f in @(Get-ChildItem -LiteralPath $dir -File -Force)){
  Require (($f.Attributes-band1024)-eq0 -and $f.Length-le33554432) 'BOUNDED_LOG_NO_REPARSE'
  if($f.Name-cnotmatch'^MSI[A-Za-z0-9_-]*\.[Ll][Oo][Gg]$'){$others+=@{path=$f.FullName;bytes=$f.Length;sha256=(Digest $f.FullName);status='OWNED_TEMP_FILE_UNPARSED_NOT_DELETED'};continue}
  $text=[IO.File]::ReadAllText($f.FullName);$guardPattern='(?m)^Action ended[^\r\n]*: '+[regex]::Escape($script:c.guardAction)+'\. Return value 1\.';$guardReturn1Count+=[regex]::Matches($text,$guardPattern).Count;$guardSeen=$guardSeen-or($text-cmatch$guardPattern);$finalizeSeen=$finalizeSeen-or($text-cmatch'(?m)Action (?:start|ended)[^\r\n]*InstallFinalize')
  foreach($m in [regex]::Matches($text,'(?i)[A-Z]:\\Windows\\Installer\\(?:[0-9a-f]+\.msi|MSI[0-9a-f]+\.tmp|[0-9a-f_-]+\.dll)')){[void]$derived.Add($m.Value)}
  foreach($match in [regex]::Matches($text,'(?m)Original package ==> ([A-Za-z]:\\[^\r\n]+\.msi)\r?$')){$sourceRows+=@{log=$f.FullName;path=$match.Groups[1].Value;kind='ORIGINAL_PACKAGE_LINE'}}
  foreach($match in [regex]::Matches($text,'(?m)Invoking remote custom action\. DLL: ([A-Za-z]:\\[^\r\n,]+), Entrypoint: ([A-Za-z_][A-Za-z0-9_]*)')){$dllRows+=@{log=$f.FullName;path=$match.Groups[1].Value;entrypoint=$match.Groups[2].Value}}
  $facts+=@{path=$f.FullName;bytes=$f.Length;sha256=(Digest $f.FullName);guardActionNameObserved=($text-cmatch$guardPattern);sourceMsiLiteralObserved=$text.Contains($script:msiPath);beginReturn='NOT_ASSERTED_FROM_LOG_PROPERTY';apiReturns='NOT_SYNTHESIZED_FROM_TEXT'}
 }
 return @{guardReturn1Count=$guardReturn1Count;files=$facts;otherOwnedTempFiles=$others;originalSourcePaths=$sourceRows;type1DllPaths=$dllRows;logCount=$facts.Count;guardActionNameObserved=$guardSeen;installFinalizeObserved=$finalizeSeen;derivedExactInstallerPaths=@($derived);authority='REAL_MSI_LOG_FACTS_ONLY_NOT_NATIVE_BEGIN_RETURN_OR_TRANSACTION_AUTHORITY'}
}
function Phase([string]$name,[ValidateSet('install','repair','uninstall')][string]$verb,[int]$reserve){
 $start=Elapsed;$budget=[int][Math]::Min(150000,[Math]::Max(0,(Remaining)-$reserve));Require ($budget-gt0) 'ORIGINAL_WHOLE_RESERVE_NO_NEW_CLIENT';$deadline=$start+$budget
 $row=[ordered]@{name=$name;verb=$verb;startWholeMilliseconds=$start;deadlineWholeMilliseconds=$deadline;maximumMilliseconds=$budget;setupInternalSeconds=120;client=@{started=$false;actualExit=$false;exitCode=$null;pipesComplete=$false;timedOut=$false};guardianObservation='NOT_OBSERVED_NO_CREATION_INFERENCE';knownControlsReturned=$false;nativeBusinessSucceeded=$false}
 $script:result.phases+=,$row;$script:ownerUnknown=$true;$process=$null;$capture=$null;$observer=$null;$out=$null;$err=$null;$snapfile=$null;$ot=$null;$et=$null
 $logdir=Join-Path $ScratchRoot ($name+'-msi-logs');Require ((Known-Path $logdir).status-ceq'KNOWN_ABSENT') 'EXCLUSIVE_LOG_SUBDIRECTORY';[void][IO.Directory]::CreateDirectory($logdir)
 try{
  $observer=[Fc80SetupObserver]::new($script:setupPath,$script:c.setup.sha256,[int]$script:c.setup.bytes,$script:c.expectedUserSid,$budget);$capture=[Fc79Capture]::new()
  $snapfile=[IO.File]::Open((Join-Path $ScratchRoot ($name+'-originals.jsonl')),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
  $process=[Diagnostics.Process]::new();$process.StartInfo.FileName=$script:setupPath;$process.StartInfo.Arguments=$verb;$process.StartInfo.WorkingDirectory=$ScratchRoot;$process.StartInfo.UseShellExecute=$false;$process.StartInfo.CreateNoWindow=$true;$process.StartInfo.WindowStyle=[Diagnostics.ProcessWindowStyle]::Hidden;$process.StartInfo.RedirectStandardInput=$true;$process.StartInfo.RedirectStandardOutput=$true;$process.StartInfo.RedirectStandardError=$true;$process.StartInfo.EnvironmentVariables['TEMP']=$logdir;$process.StartInfo.EnvironmentVariables['TMP']=$logdir
  $out=[IO.File]::Open((Join-Path $ScratchRoot ($name+'-client.stdout.log')),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);$err=[IO.File]::Open((Join-Path $ScratchRoot ($name+'-client.stderr.log')),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
  Require ((Elapsed)-lt$deadline -and (Remaining)-gt$reserve) 'ORIGINAL_CLOCK_BEFORE_CREATEPROCESS';if($verb-ceq'install'){$script:installAttempted=$true}
  Require ($process.Start()) 'SETUP_CREATEPROCESS_FALSE';$row.client.started=$true;$process.StandardInput.Close();$created=$process.StartTime.ToUniversalTime().ToFileTimeUtc();$row.client['pid']=$process.Id;$row.client['creationFiletime']=$created
  $row['directOriginalAtStart']=Clone ($capture.HoldStartedClient($process.Handle,[uint32]$process.Id,$created,$script:setupPath,$script:c.setup.sha256,$script:c.expectedUserSid))
  $ot=$process.StandardOutput.BaseStream.CopyToAsync($out);$et=$process.StandardError.BaseStream.CopyToAsync($err);$last=''
  while((Elapsed)-lt$deadline -and (Remaining)-gt$reserve){
   $view=Clone ($observer.Snapshot());$encoded=$view|ConvertTo-Json -Depth 24 -Compress
   if($encoded-cne$last){$bytes=[Text.UTF8Encoding]::new($false).GetBytes($encoded+"`n");Require ($snapfile.Length+$bytes.Length-le16777216) 'OBSERVER_LOG_BOUND';$snapfile.Write($bytes,0,$bytes.Length);$snapfile.Flush();$last=$encoded}
   if($process.HasExited -and @($view.Processes|Where-Object{$_.ActualWait-ne0}).Count-eq0){break};Start-Sleep -Milliseconds 10
  }
  $row.client.actualExit=$process.HasExited;if($row.client.actualExit){$row.client.exitCode=$process.ExitCode}else{$row.client.timedOut=$true}
  $wait=[int][Math]::Max(0,[Math]::Min(2000,$deadline-(Elapsed)));$row.client.pipesComplete=[Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($ot,$et),$wait)
 }catch{$row['failureType']=$_.Exception.GetType().FullName;$row['failureCode']=$(if($_.Exception.Message-cmatch'^[A-Z0-9_]+$'){$_.Exception.Message}else{'NATIVE_OR_CLIENT_FAILURE_RETAIN'})}
 finally{
  if($observer){try{$closed=Clone ($observer.FinishAndClose());$row['observerFinal']=$closed;$seen=@($closed.Processes|Where-Object{$_.Role-ceq'owned-guardian'});$row.guardianObservation=$(if($seen.Count){'OBSERVED_ORIGINAL_G_OBJECTS'}else{'NOT_OBSERVED_NO_CREATION_INFERENCE'});$observedReturned=($closed.Closed -and @($closed.Errors).Count-eq0 -and @($closed.Processes|Where-Object{$_.IdentityStatus-cne'ORIGINAL_QUERY_SYNC_HANDLE_EXACT_IMAGE_BYTES_USER' -or $_.ActualWait-ne0 -or $null-eq$_.ActualExitCode -or $_.ExitStatus-cne'ACTUAL_ORIGINAL_GET_EXIT_CODE' -or $_.CloseStatus-cne'CHECKED_CLOSE_SUCCESS'}).Count-eq0);$row['capturedObjectsReturned']=$observedReturned;$row['capturedObjectsSucceeded']=($observedReturned -and @($closed.Processes|Where-Object{$_.ActualExitCode-ne0}).Count-eq0)}catch{$script:instrumentUnknown=$true;$row['observerFinish']='UNKNOWN_NO_RETRY'}}
  if($capture){try{$row['directOriginalFinal']=@((Clone ($capture.FinishAndClose())));$row['directNativeCloses']=Clone ($capture.NativeReturns());$row['directCloseUnknown']=$capture.NativeCloseUnknown}catch{$script:instrumentUnknown=$true;$row['directFinish']='UNKNOWN_NO_RETRY'}}
  if($process){try{if($row.client.started -and -not$process.HasExited){$row['retainedDirectClient']=@{pid=$process.Id;status='STILL_LIVE_NOT_KILLED'};$script:ownerUnknown=$true}else{$process.Dispose()}}catch{$script:instrumentUnknown=$true}}
  foreach($s in @($out,$err,$snapfile)){if($s){try{$s.Dispose()}catch{$script:instrumentUnknown=$true}}}
  $directGood=($row.Contains('directOriginalFinal') -and @($row.directOriginalFinal).Count-eq1 -and @($row.directOriginalFinal|Where-Object{$_.Status-cne'HELD_ORIGINAL_IDENTITY' -or $_.Wait-ne0 -or -not$_.ExitKnown -or -not$_.CloseAttempted -or -not$_.CheckedClose}).Count-eq0 -and -not$row.directCloseUnknown)
  $row.knownControlsReturned=($directGood -and $row.Contains('capturedObjectsReturned') -and $row.capturedObjectsReturned -and $row.client.actualExit -and $row.client.pipesComplete -and -not$row.client.timedOut -and -not$script:instrumentUnknown);$script:ownerUnknown=-not$row.knownControlsReturned;$row.nativeBusinessSucceeded=($row.knownControlsReturned -and $row.client.exitCode-eq0 -and @($row.directOriginalFinal|Where-Object{$_.ExitCode-ne0}).Count-eq0 -and $row.capturedObjectsSucceeded);$script:allSetupBusinessSucceeded=($script:allSetupBusinessSucceeded -and $row.nativeBusinessSucceeded)
  $row['endWholeMilliseconds']=Elapsed;try{$row['msiLogs']=Log-Facts $logdir}catch{$row['msiLogs']=@{logCount=0;guardActionNameObserved=$false;installFinalizeObserved=$false;derivedExactInstallerPaths=@();status='LOG_CAPTURE_UNKNOWN_OR_FAILED'};$row['logCaptureFailureType']=$_.Exception.GetType().FullName};New-Json (Join-Path $ScratchRoot ($name+'-phase.json')) $row
 }
 return $row
}
function Require-Phase($row){Require ($row.guardianObservation-ceq'OBSERVED_ORIGINAL_G_OBJECTS' -and @($row.observerFinal.Processes|Where-Object{$_.Role-ceq'owned-guardian'}).Count-eq1) 'EXACT_ONE_ORIGINAL_OWNED_GUARDIAN_REQUIRED';Require ($row.knownControlsReturned -and -not$script:ownerUnknown -and -not$script:instrumentUnknown) 'ORIGINAL_CLIENT_OR_CAPTURE_RETURN_UNKNOWN';Require $row.nativeBusinessSucceeded 'SETUP_OR_CAPTURE_KNOWN_NONZERO';Require ($row.msiLogs.logCount-gt0 -and $row.msiLogs.guardActionNameObserved -and $row.msiLogs.installFinalizeObserved) 'REAL_MSI_GUARD_AND_FINALIZE_LOGS_REQUIRED';$own=Own-Processes;$row['postPhaseProcesses']=$own;Require $own.knownZero 'OWNED_PROCESS_UNKNOWN_OR_LIVE'}
function Capture-Gate {try{$script:gateSnapshot=[FcR76GateRetirement]::Capture($script:c.expectedUserSid);$script:result['originalGateFacts']=@($script:gateSnapshot.Facts())}catch{$script:instrumentUnknown=$true;throw}}
function Retire-Gate {Require (-not$script:ownerUnknown -and -not$script:instrumentUnknown -and $script:gateSnapshot -and -not$script:retireAttempted -and (Remaining)-gt0) 'NO_ORIGINAL_GATE_RETIREMENT_AUTHORITY';Require ((Coordination).pendingKnownAbsent -and (Own-Processes).knownZero) 'GATE_RETIRE_ONLY_AFTER_RETURNED_ABSENT';$script:retireAttempted=$true;try{$script:result['gateRetirement']=[FcR76GateRetirement]::Retire($script:gateSnapshot)}catch{$script:instrumentUnknown=$true;throw};Require ((Coordination).namespaceKnownAbsent) 'ORIGINAL_GATE_NAMESPACE_STILL_PRESENT'}

try {
 Require ([Environment]::Is64BitProcess -and $PSVersionTable.PSVersion.Major-eq5 -and $PSVersionTable.PSVersion.Minor-eq1) 'FRESH_X64_PS51_CLEANUP_REQUIRED'
 Require ($ScratchRoot-ceq[IO.Path]::GetFullPath($ScratchRoot)) 'EXACT_EXISTING_SCRATCH_ROOT'
 Require ([IO.File]::ReadAllText((Join-Path $ScratchRoot '.owner'))-ceq"future-classroom-owned-update-data-success-final-controlled-product-runtime/v1`n") 'ORIGINAL_FAILED_RUNTIME_OWNER'
 $bindingPath=Join-Path $ScratchRoot 'manual-failed-seed-cleanup-bindings-v1.json';Require ((Digest $bindingPath)-ceq$ExpectedBindingsSha256) 'EXACT_CLEANUP_BINDINGS'
 $b=Get-Content -LiteralPath $bindingPath -Raw -Encoding UTF8|ConvertFrom-Json
 Require ($b.status-ceq'BOUND_MANUAL_FAILED_SEED_EFFECTS_CLEANUP_ONLY' -and $b.windowsRoot-ceq$ScratchRoot -and $b.nonce-cmatch'^[0-9a-f]{32}$' -and -not$b.originalOwners.ownerUnknown -and -not$b.originalOwners.instrumentUnknown -and $b.originalOwners.runtimeActualExit-eq1 -and $b.originalOwners.installKnownControlsReturned -and $b.originalOwners.installNativeBusinessSucceeded) 'ORIGINAL_FAILED_RUNTIME_ALL_OWNERS_RETURNED'
 Require ($b.originalSeedAttempt.stage-ceq'seed' -and $b.originalSeedAttempt.actualExit -and $b.originalSeedAttempt.exitCode-eq1 -and $b.originalSeedAttempt.checkedOriginalClose -and -not$b.originalSeedAttempt.seedPassClaim -and $b.originalSeedAttempt.rootWasAbsentBeforeAttempt) 'ORIGINAL_FAILED_SEED_NOT_SEED_PASS'
 $cp=Join-Path $ScratchRoot 'runtime-config.json';$ip=Join-Path $ScratchRoot 'runtime-inputs.json';$rp=Join-Path $ScratchRoot 'product-result.json'
 Require ((Digest $cp)-ceq$b.originalConfig.sha256 -and (Digest $ip)-ceq$b.originalInputs.sha256 -and (Digest $rp)-ceq$b.originalProductResult.sha256) 'ORIGINAL_CONFIG_INPUT_RESULT_BYTES'
 $script:c=Get-Content -LiteralPath $cp -Raw -Encoding UTF8|ConvertFrom-Json
 Require ($script:c.runtimeNonce-ceq$b.nonce -and $script:c.version-ceq'0.2.0' -and $script:c.productCode-ceq'{D420EDE5-0584-5FDC-8DE8-F25905018A0A}' -and $script:c.expectedUserSid-ceq$b.installedProduct.userSid) 'EXACT_ORIGINAL_U1_IDENTITY'
 $who=[Security.Principal.WindowsIdentity]::GetCurrent();try{Require ($who.User.Value-ceq$script:c.expectedUserSid) 'EXACT_AUTHORIZED_CURRENT_USER'}finally{$who.Dispose()}
 $manifest=Get-Content -LiteralPath $ip -Raw -Encoding UTF8|ConvertFrom-Json
 foreach($row in $manifest.files){Require ($row.path-cnotmatch'(^/|\\|:|(^|/)\.\.(/|$))') 'ORIGINAL_INPUT_SAFE_RELATIVE';$p=Join-Path $ScratchRoot $row.path;$f=Get-Item -LiteralPath $p -Force;Require (-not$f.PSIsContainer -and ($f.Attributes-band1024)-eq0 -and $f.Length-eq$row.bytes -and (Digest $p)-ceq$row.sha256) 'EXACT_ORIGINAL_UPLOADED_SOURCE_AND_PACKAGE_BYTES'}
 $local=[Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData);$script:programRoot=Join-Path $local 'Programs\FutureClassroom';$script:gateRoot=Join-Path $local ('FutureClassroom-Installer-'+$script:c.family);$script:setupPath=Join-Path $ScratchRoot 'u1\Setup.exe';$script:msiPath=Join-Path $ScratchRoot 'u1\FutureClassroom.msi'
 $exe=Join-Path $script:programRoot 'fc-bootstrap.exe';Require ((Digest $exe)-ceq$b.installedProduct.sha256 -and (Digest $script:setupPath)-ceq$script:c.setup.sha256 -and (Digest $script:msiPath)-ceq$script:c.msi.sha256) 'EXACT_INSTALLED_NORMAL_U1_AND_ORIGINAL_SETUP'
 . ([ScriptBlock]::Create([IO.File]::ReadAllText((Join-Path $ScratchRoot 'ProductState.ps1'),[Text.UTF8Encoding]::new($false))))
 . ([ScriptBlock]::Create([IO.File]::ReadAllText((Join-Path $ScratchRoot 'UpdateData.ps1'),[Text.UTF8Encoding]::new($false))))
 $temp=Join-Path $ScratchRoot 'manual-cleanup-instrument-temp-v1';Require ((Known-Path $temp).status-ceq'KNOWN_ABSENT') 'FRESH_CLEANUP_INSTRUMENT_TEMP';[void][IO.Directory]::CreateDirectory($temp);$env:TEMP=$temp;$env:TMP=$temp
 Add-Type -LiteralPath (Join-Path $ScratchRoot 'Capture.cs') -ErrorAction Stop;Add-Type -LiteralPath (Join-Path $ScratchRoot 'GateRetirement.cs') -ErrorAction Stop;Add-Type -LiteralPath (Join-Path $ScratchRoot 'ProcessObserver.cs') -ReferencedAssemblies @('System.dll','System.Core.dll','System.Management.dll') -ErrorAction Stop
 $before=Measure-State 'Present';$script:result['beforeCleanupProduct']=$before;Require (Healthy $before) 'KNOWN_FULL14_U1_AND_RUN_ABSENT_BEFORE_CLEANUP'
 Require ((Coordination).pendingKnownAbsent -and (Own-Processes).knownZero) 'CURRENT_ORIGINAL_HELPER_PRODUCT_PROCESS_ZERO_PENDING_ABSENT'
 $run=Clone ([Fc80ProductState]::ObserveRun($null));$script:result['beforeCleanupRun']=$run;Require ($run.absent -and $run.matchesExpected) 'INDEPENDENT_FIXED_RUN_ABSENT_AFTER_REAL_DISABLE'
 Require ($b.completedDisable.nonce-ceq$b.nonce -and $b.completedDisable.status-ceq'PASS_NORMAL_PRODUCT_OWNED_RUN_DISABLED_FOR_FAILED_SEED_CLEANUP' -and $b.completedDisable.actualExit -and $b.completedDisable.exit-eq0 -and -not$b.completedDisable.nativeCloseUnknown -and $b.completedDisable.runAbsent) 'BOUND_ACTUAL_NORMAL_PRODUCT_DISABLE_COMPLETED'
 $caps=@($b.completedDisable.originalFinal);Require ($caps.Count-eq1 -and $caps[0].Status-ceq'HELD_ORIGINAL_IDENTITY' -and $caps[0].Wait-eq0 -and $caps[0].ExitKnown -and $caps[0].ExitCode-eq0 -and $caps[0].CheckedClose -and $caps[0].CloseAttempted -and $caps[0].Sha256-ceq$b.installedProduct.sha256 -and $caps[0].Sid-ceq$script:c.expectedUserSid) 'ORIGINAL_DISABLE_PROCESS_ACTUAL_ZERO_AND_CHECKED_CLOSE'
 $script:dataRoot=Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::CommonApplicationData)) 'FutureClassroom';$script:dataNonce=$b.nonce;Assert-OwnedUpdateData
 $acl=[IO.Directory]::GetAccessControl($script:dataRoot);Require ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq$script:c.expectedUserSid) 'EXACT_SYNTHETIC_DATA_OWNER_PROTECTED_ACL'
 $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Require ($rules.Count-eq2 -and @($rules|Where-Object{$_.IdentityReference.Value-cnotin@($script:c.expectedUserSid,'S-1-5-18') -or $_.AccessControlType-ne'Allow' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count-eq0) 'EXACT_SYNTHETIC_OWNER_SYSTEM_ONLY_ACL'
 Require ((Known-Path (Join-Path $script:dataRoot 'update-data-probe.manifest')).status-ceq'KNOWN_ABSENT') 'ORIGINAL_FAILED_SEED_NO_PUBLISHED_MANIFEST'
 # Compatibility flags for the ORIGINAL owner-bound delete routine only.
 # They derive from original failed attempt + actual exact nonce/ACL + actual
 # completed normal disable. They never claim that seed or data validation passed.
 $script:dataSeeded=$true;$script:dataDisabled=$true;$script:result['ownedSyntheticCleanupAuthority']=@{source='ORIGINAL_FAILED_SEED_ATTEMPT_EXACT_NONCE_ACL_AND_COMPLETED_REAL_DISABLE';seedPassClaim=$false;nonce=$b.nonce}
 $cache=Cache-Fact $true;$script:result['originalCacheBeforeCleanup']=$cache
 foreach($name in @('path','bytes','sha256','volume','indexHigh','indexLow')){Require ([string]$cache.actualApi.$name-ceq[string]$b.originalCache.$name) 'ORIGINAL_EXACT_INSTALLED_CACHE_IDENTITY_AND_BYTES'}
 Capture-Gate;$currentFacts=@($script:gateSnapshot.Facts());Require ($currentFacts.Count-eq@($b.originalGateFacts).Count) 'ORIGINAL_GATE_FACT_COUNT';for($i=0;$i-lt$currentFacts.Count;$i++){Require ($currentFacts[$i]-ceq$b.originalGateFacts[$i]) 'SAME_ORIGINAL_GATE_DIRECTORY_FILE_ID_ACL'}
 $script:formalAttempted=$true;$uninstall=Phase 'manual-cleanup-formal-uninstall-u1' 'uninstall' 180000;Require-Phase $uninstall
 $absent=Measure-State 'Absent';$script:result['afterFormalUninstall']=$absent;Require ((Absent $absent) -and (Coordination).pendingKnownAbsent -and (Own-Processes).knownZero) 'ACTUAL_FORMAL_UNINSTALL_ALL14_MARKERS_PRODUCT_COMPONENTS_RUN_ABSENT'
 $script:result['cacheAfterFormalUninstall']=Cache-Fact $false;Require $script:result.cacheAfterFormalUninstall.allObservedAbsent 'ORIGINAL_EXACT_CACHE_PATH_ABSENT'
 Retire-Gate;Remove-OwnedUpdateData
 $final=Measure-State 'Absent';$coord=Coordination;$data=Known-Path $script:dataRoot;$own=Own-Processes;$run=Clone ([Fc80ProductState]::ObserveRun($null));$script:result['finalReadonly']=@{product=$final;coordination=$coord;data=$data;processes=$own;run=$run}
 Require ((Absent $final) -and $coord.namespaceKnownAbsent -and $coord.pendingKnownAbsent -and $data.status-ceq'KNOWN_ABSENT' -and $own.knownZero -and $run.absent -and (Remaining)-gt0) 'FINAL_PRODUCT_RUN_PROGRAMDATA_GATE_CACHE_ORIGINAL_OWNERS_ABSENT'
 $script:success=$true;$script:result.status='PASS_MANUAL_FAILED_SEED_EFFECTS_CLEANUP_SCRATCH_RETAINED_FOR_FRESH_REPLAY';$script:result.cleanup='PASS_FORMAL_UNINSTALL_ORIGINAL_CACHE_GATE_AND_NONCE_DATA_REMOVED'
}catch{$script:result['failureType']=$_.Exception.GetType().FullName;$script:result['failureCode']=$(if($_.Exception.Message-cmatch'^[A-Z0-9_]+$'){$_.Exception.Message}else{'MANUAL_CLEANUP_NATIVE_OR_CONFIG_FAILURE_RETAIN'});$script:result.cleanup='RETAIN_CURRENT_STATE_NO_BLIND_RECOVERY_OR_RETRY'}
finally{
 $script:result['elapsedFreshCleanupMilliseconds']=Elapsed;$script:result['freshCleanupBudgetExceeded']=((Elapsed)-ge600000);$script:result['ownerUnknown']=$script:ownerUnknown;$script:result['instrumentUnknown']=$script:instrumentUnknown;$script:result['formalUninstallAttempted']=$script:formalAttempted
 try{New-Json (Join-Path $ScratchRoot 'manual-failed-seed-cleanup-v1-result.json') $script:result}catch{$script:success=$false;$script:result['resultWriteFailed']=$true}
}
$script:result|ConvertTo-Json -Depth 24 -Compress
if(-not$script:success -or $script:result.freshCleanupBudgetExceeded){exit 1};exit 0
