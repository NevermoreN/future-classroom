"""Explicit manual cleanup of one bound failed seed. Default inert.
No data-preservation success is claimed; original failure and scratch stay intact.
"""
from pathlib import Path
import argparse,hashlib,json,runpy,subprocess,time,sys,shutil
R=Path(__file__).resolve().parent
P=R/'failed-seed-cleanup-preparation'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def need(v,m):
 if not v:raise ValueError(m)
def read(p):return json.loads(p.read_bytes())
def verify():
 b=read(P/'cleanup-bindings.json');need(b['status']=='BOUND_MANUAL_FAILED_SEED_EFFECTS_CLEANUP_ONLY','EXACT_MANUAL_CLEANUP_SCOPE')
 for key in ['originalFailureReport','sourceFreeze','originalConfig','originalInputs','originalProductResult','completedDisableReport']:
  row=b[key];p=Path(row['path']);need(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],'ORIGINAL_BOUND_FILE_'+key)
 j=read(Path(b['originalFailureReport']['path']));phase=j['phase'];need(j['downloadVerified'] is True and j['runtimeActualExit']==1 and phase['ownerUnknown'] is False and phase['instrumentUnknown'] is False and len(phase['phases'])==1 and phase['phases'][0]['name']=='install-u1' and phase['phases'][0]['nativeBusinessSucceeded'] is True,'ORIGINAL_INSTALL_AND_ALL_OWNERS_RETURNED')
 m=runpy.run_path(str(R/'success-final/run-controlled-product.py'));need(m['phase_returned'](phase['phases'][0]),'ORIGINAL_INSTALL_B_AND_G_ACTUAL_WAIT_EXIT_CLOSE')
 seed=phase['updateDataStages'];need(len(seed)==1 and seed[0]['stage']=='seed' and seed[0]['actualExit'] is True and seed[0]['exitCode']==1 and seed[0]['checkedOriginalClose'] is True and seed[0]['nativeCloseUnknown'] is False,'FAILED_SEED_ORIGINAL_RETURNED_NOT_PASSED')
 d=read(Path(b['completedDisableReport']['path']));caps=d['originalFinal'];caps=[caps] if isinstance(caps,dict) else caps;need(len(caps)==1,'ONE_ORIGINAL_DISABLE_PROCESS');c=caps[0]
 need(d['status']=='PASS_NORMAL_PRODUCT_OWNED_RUN_DISABLED_FOR_FAILED_SEED_CLEANUP' and d['nonce']==b['nonce'] and d['actualExit'] is True and d['exit']==0 and d['nativeCloseUnknown'] is False and d['runAbsent'] is True and c['Status']=='HELD_ORIGINAL_IDENTITY' and c['Wait']==0 and c['ExitKnown'] is True and c['ExitCode']==0 and c['CheckedClose'] is True and c['CloseAttempted'] is True and c['Sha256']==b['installedProduct']['sha256'] and c['Sid']==b['installedProduct']['userSid'] and c['Pid']==d['pid'] and c['Creation']==d['creation'],'ACTUAL_BOUND_NORMAL_PRODUCT_DISABLE_ZERO_WAIT_CLOSE_RUN_ABSENT')
 need(d['stdout'].strip()=='UPDATE_DATA_PROBE stage=disable result=PASS nonce='+b['nonce']+' sequence=0 manifest_sha256='+'0'*64,'ZERO_SHA_CLEANUP_ONLY_RECEIPT_NOT_DATA_PASS')
 for x in d['nativeReturns']:need(x['Attempted'] is True and x['Success'] is True and x['Unknown'] is False,'DISABLE_ALL_NATIVE_CLOSES_KNOWN')
 local=Path(b['originalDownloadedRoot']);files={};dirs=[]
 for p in local.rglob('*'):
  need(not p.is_symlink(),'ORIGINAL_DOWNLOAD_NO_LINK');name=p.relative_to(local).as_posix()
  if p.is_dir():dirs.append(name)
  else:files[name]=(p.stat().st_size,sha(p))
 need(files=={x['path']:(x['bytes'],x['sha256']) for x in b['originalInventory']['files']} and set(dirs)==set(b['originalInventory']['directories']),'ORIGINAL_DOWNLOADED_BYTE_REPLAY_BEFORE_CLEANUP')
 f=read(Path(b['sourceFreeze']['path']))
 for base,key in [(R/'success-final','files'),(R,'sharedFiles')]:
  for row in f[key]:p=base/row['path'];need(p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],'ORIGINAL_FROZEN_FUNCTION_SOURCE_UNCHANGED')
 return b,m

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');a=ap.parse_args()
 if not a.execute:print('{"status":"PREPARED_NOT_RUN","Windows":"NOT_CONTACTED","scope":"MANUAL_FAILED_SEED_CLEANUP_ONLY"}');return 0
 b,m=verify();d=R/'failed-seed-cleanup-result';need(not d.exists(),'NEW_ORIGINAL_CLEANUP_CONTROLLER_ONLY');d.mkdir();(d/'.owner').write_text('future-classroom-owned-manual-failed-seed-cleanup-result/v1\n');upload=d/'upload';upload.mkdir()
 shutil.copyfile(P/'cleanup-bindings.json',upload/'manual-failed-seed-cleanup-bindings-v1.json');shutil.copyfile(P/'Manual-FailedSeed-Cleanup.ps1',upload/'manual-failed-seed-cleanup-v1.ps1')
 c=dict(root=b['windowsRoot'],nonce=b['nonce'],sid=b['installedProduct']['userSid'],inventory=b['originalInventory'],bindingsSha=sha(upload/'manual-failed-seed-cleanup-bindings-v1.json'),scriptSha=sha(upload/'manual-failed-seed-cleanup-v1.ps1'))
 report=dict(status='FAIL_OR_UNKNOWN_MANUAL_CLEANUP_RETAIN_ORIGINALS',scope='FRESH_MANUAL_FAILED_SEED_EFFECTS_CLEANUP_ONLY_NOT_DATA_VALIDATION',budgetOrigin=b['budgetOrigin'],originalFailureReport=b['originalFailureReport'],completedDisableReport=b['completedDisableReport'],schoolDataPreservation='NOT_RUN_NOT_CLAIMED',databaseOrDpapiContentsCaptured=False,scratchCleanup='LEFT_TO_ROOT_FRESH_INVENTORY_DOWNLOAD_REPLAY_EXACT_DELETE',operations=[]);start=time.monotonic()
 def save():(d/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 def call(label,args,feed=None,timeout=30):
  row=dict(label=label,args=args,actualExit=None,parentReaped=False);report['operations'].append(row)
  if feed is not None:(d/(label+'.stdin.ps1')).write_bytes(feed)
  with (d/(label+'.stdout.log')).open('xb') as out,(d/(label+'.stderr.log')).open('xb') as err:
   p=subprocess.Popen(args,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=out,stderr=err);row['originalLocalPid']=p.pid;save()
   try:p.communicate(feed,timeout=timeout);row.update(actualExit=p.returncode,parentReaped=True)
   except subprocess.TimeoutExpired:row['remoteOwnership']='UNKNOWN_NO_RETRY_NO_WINDOWS_KILL';save();raise
  save();return row,(d/(label+'.stdout.log')).read_bytes()
 try:
  preflight=r'''CheckRoot $c.root;$now=Inventory $c.root;Need ($now.files.Count-eq$c.inventory.files.Count -and $now.directories.Count-eq$c.inventory.directories.Count) 'ORIGINAL_SCRATCH_MEMBERSHIP_BEFORE_ADDITIONS';foreach($f in $now.files){$old=@($c.inventory.files|Where-Object{$_.path-ceq$f.path});Need ($old.Count-eq1 -and $old[0].bytes-eq$f.bytes -and $old[0].sha256-ceq$f.sha256) 'ORIGINAL_SCRATCH_BYTES_BEFORE_ADDITIONS'};foreach($dir in $now.directories){Need ($dir-cin$c.inventory.directories) 'ORIGINAL_DIRECTORY_MEMBERSHIP'};@{status='PASS_ORIGINAL_SCRATCH_BYTES_BEFORE_MANUAL_CLEANUP_ADDITIONS';files=$now.files.Count}|ConvertTo-Json -Compress'''
  args,feed=m['remote'](preflight,c);row,out=call('01-original-scratch-preflight',args,feed,45);need(row['actualExit']==0,'ORIGINAL_SCRATCH_PREFLIGHT_ZERO');report['preflight']=json.loads(out.decode('utf-8-sig'))
  row,_=call('02-upload-manual-cleanup',['scp','-q','-o','BatchMode=yes',str(upload/'manual-failed-seed-cleanup-bindings-v1.json'),str(upload/'manual-failed-seed-cleanup-v1.ps1'),'future-classroom-win11:'+c['root'].replace('\\','/')+'/'],timeout=45);need(row['actualExit']==0,'MANUAL_CLEANUP_UPLOAD_ZERO')
  invoke=r'''CheckRoot $c.root;$runner=Join-Path $c.root 'manual-failed-seed-cleanup-v1.ps1';$binding=Join-Path $c.root 'manual-failed-seed-cleanup-bindings-v1.json';Need ((Fact $runner).sha256-ceq$c.scriptSha -and (Fact $binding).sha256-ceq$c.bindingsSha) 'EXACT_MANUAL_CLEANUP_BYTES';$text=[IO.File]::ReadAllText($runner,[Text.UTF8Encoding]::new($false));$tokens=$null;$errors=$null;$null=[Management.Automation.Language.Parser]::ParseInput($text,[ref]$tokens,[ref]$errors);Need ($errors.Count-eq0) 'MANUAL_CLEANUP_PS51_AST_REQUIRED';& ([ScriptBlock]::Create($text)) -Execute -ScratchRoot $c.root -ExpectedBindingsSha256 $c.bindingsSha;$code=Get-Variable -Name LASTEXITCODE -ErrorAction SilentlyContinue;Need ($null-ne$code) 'ORIGINAL_MANUAL_CLEANUP_RETURN_CODE';exit ([int]$code.Value)'''
  args,feed=m['remote'](invoke,c);row,out=call('03-fresh-manual-effects-cleanup',args,feed,640);report['runtimeActualExit']=row['actualExit'];result=json.loads(out.decode('utf-8-sig'));report['manualCleanup']=result
  need(row['actualExit']==0 and result['status']=='PASS_MANUAL_FAILED_SEED_EFFECTS_CLEANUP_SCRATCH_RETAINED_FOR_FRESH_REPLAY' and result['ownerUnknown'] is False and result['instrumentUnknown'] is False and result['freshCleanupBudgetExceeded'] is False and result['seedPassClaim'] is False and result['schoolDataPreservation']=='NOT_RUN_NOT_CLAIMED' and len(result['phases'])==1 and m['phase_returned'](result['phases'][0]),'ACTUAL_MANUAL_CLEANUP_AND_ORIGINAL_B_G_WAIT_EXIT_CLOSE')
  final=result['finalReadonly'];need(final['product']['knownAbsent'] is True and final['coordination']['namespaceKnownAbsent'] is True and final['coordination']['pendingKnownAbsent'] is True and final['data']['status']=='KNOWN_ABSENT' and final['run']['absent'] is True and final['processes']['knownZero'] is True and result['cacheAfterFormalUninstall']['allObservedAbsent'] is True,'MANUAL_CLEANUP_FINAL_INDEPENDENT_ABSENCE')
  report['status']='PASS_MANUAL_FAILED_SEED_EFFECTS_CLEANUP_SCRATCH_RETAINED_FOR_FRESH_REPLAY'
 except Exception as e:report['failureType']=type(e).__name__;report['failure']=str(e)
 finally:report['elapsedFreshControllerSeconds']=time.monotonic()-start;save()
 print(json.dumps(dict(status=report['status'],report=str(d/'report.json'),scratchCleanup=report['scratchCleanup'])));return 0 if report['status'].startswith('PASS_') else 1
if __name__=='__main__':raise SystemExit(main())
