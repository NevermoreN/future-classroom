from pathlib import Path
import json,runpy,subprocess,hashlib,sys
R=Path('/tmp/fc-update-runtime-candidate');j=json.loads((R/'success-result/report.json').read_bytes());p=j['phase'];assert j['downloadVerified'] and j['runtimeActualExit']==1 and p['phases']==[] and not p['ownerUnknown'] and not p['instrumentUnknown'] and not p['formalUninstallAttempted'] and p['before']['fixedPaths'][-1]['status']=='KNOWN_ABSENT'
m=runpy.run_path(str(R/'success/run-controlled-product.py'));plan=json.loads((R/'success-input/artifact-manifest.json').read_bytes());c=dict(root=j['windowsRoot'],nonce=j['nonce'],sid=plan['expectedUserSid'],plan=plan,inventory=j['inventory'])
pre=(R/'success/sources/ReadOnlyPreflightFunction.ps1').read_text()+"$v=Measure-FcBeforePreflight -Config $c.plan;Need ($v.status-ceq'PASS_BEFORE_KNOWN_ABSENCE_ONLY_NOT_EXECUTION_ADMISSION') 'UNCHANGED_ALL_REAL_PRODUCT_AND_DATA_ABSENT';$v|ConvertTo-Json -Depth 18 -Compress"
results=[]
for label,script in [('preflight',pre),('delete',m['DELETE'])]:
 args,feed=m['remote'](script,c);r=subprocess.run(args,input=feed,capture_output=True,timeout=45);(R/('first-success-cleanup-'+label+'.stdout.log')).write_bytes(r.stdout);(R/('first-success-cleanup-'+label+'.stderr.log')).write_bytes(r.stderr);assert r.returncode==0
 v=json.loads(r.stdout.decode('utf-8-sig'));results.append(dict(label=label,exit=r.returncode,parentReaped=True,result=v))
(R/'first-success-preinstall-cleanup.json').write_text(json.dumps(dict(status='PASS_EXACT_DOWNLOADED_PREINSTALL_FAILURE_SCRATCH_REMOVED',originalRuntimeUnchanged=True,noProductOrDataMutation=True,operations=results),indent=2)+'\n');print('PASS exact pre-install failure scratch cleanup; product and data unchanged')
