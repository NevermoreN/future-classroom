CURRENT SOURCE UPDATE DATA CANDIDATE — NO WINDOWS EVIDENCE
Owner: future-classroom-update-runtime-candidate/v1\n
No main tree writes, Git, compiler, installer or Windows calls were made.
All entrypoints are default inert. --execute requires real future pinned inputs.

READY ENTRYPOINTS (use --help for complete argument names):
1. package-current-u1.py: current complete frozen source + real normal Cargo3 +
   actual Web producer -> initial U1 0.2.0 normal ABI2 package.
   evidence.lifecycle_mode = ABI2_UPDATE_DATA_CURRENT_NORMAL_GNU_DEV.
   Existing DEV.admit still verifies actual Git base, before/after inventory,
   Cargo metadata, actual exit0/reaped compiler commands, actual artifacts,
   profile.test=false, default features. strip=symbols; removal scope removed.
2. bind-current-artifact.py --execute --u1-report <.../report.json>
   --u1-report-sha256 <actual SHA> --sid <actual authorized SID>
   --output-dir <this root>/u1-input
3. freeze-current.py --execute --branch u1-qualification
   u1-qualification/run-controlled-product.py --execute
   --artifact-manifest <this root>/u1-input/artifact-manifest.json
   --artifact-manifest-sha256 <actual SHA>
   --source-manifest <this root>/u1-input/source-manifest.json
   --source-manifest-sha256 <actual SHA>
   --preparation-freeze-sha256 <actual freeze SHA>
   --report <this root>/u1-result/report.json
   This is the full fresh install, real license damage, repair, uninstall chain.
   All original process/guardian/handle, source/cache and cleanup gates remain.
4. run-current-interop.py --execute --source-root <actual frozen U1 root>
   --msi <actual U1 MSI> --msi-sha256 <actual SHA>
   --output-dir <this root>/u1-interop
   Root executes actual finite Rust/Python source31 byte interoperability.
5. package-current-u2.py --execute <see --help>
   Supply actual complete U1 and U2 producer roots/evidence, original full U1
   chain, actual interop, actual Web producer and tools. Keeps U1's immutable
   normal helper+guard/carrier, independently admits actual changed U2 normal
   product. U2 compiler helper/guard outputs are not the packaged auxiliaries.
   Preserves reviewed four-Binary authoring/contract, exact streams/payloads,
   REP1501, actual compiler PackageCode and external32 seal.
6. bind-current-artifact.py --execute <same U1 args> --u2-report <actual report>
   --u2-report-sha256 <actual SHA> --output-dir <this root>/success-input
   freeze-current.py --execute --branch success
   success/run-controlled-product.py --execute <same manifest/hash/report args>
7. derive-current-type19.py --execute <see --help>: exact normal U2 source,
   two fixed extra table rows only, real 86-tool derivation. No fifth Binary or
   intermediate full14 hash witness is invented. Bind rollback input via step6
   plus --forced-derivation/--forced-derivation-sha256, freeze branch rollback,
   then rollback/run-controlled-product.py --execute <same manifest args>.

All reports/evidence/packages/logs must live under this owned candidate root;
normal source roots may be separate real frozen Git worktrees. Keep frozen U1
source unchanged while producing distinct U2 source. No hardcoded historical
6eb/595/18-overlay or old package/runtime SHA is accepted as current proof.

current-package-qualification.py is a concrete strict validator, not a stub.
It replays actual normal Cargo3 source qualification, pinned producer bytes,
original package tool logs, exact carrier binding, complete14 payloads and MSI
contract. Current publication requires original U1 three-phase runtime evidence,
actual source31 interoperability and current compiled native source/cache proof.
Missing future actual inputs reject before any Windows contact.

RUNTIME DATA AND RUN:
  Installed actual normal PE is held by original process handle for each stage:
    --update-data-probe-stage <ProgramData/FutureClassroom> <nonce> seed|verify|disable
  Real ProgramData root must be absent before any scratch root is created.
  Seed accepts only fresh protected owner/nonce synthetic data.
  Public receipt protocol:
    UPDATE_DATA_PROBE stage=<stage> result=PASS nonce=<nonce> sequence=<n> manifest_sha256=<SHA>
  Original immutable manifest sequence0 and every new verify sequence are copied
  to scratch. No DB, credential bytes or DPAPI files are captured.
  Run must be exact REG_SZ UTF16LE('"<installed exe>" --autostart\0'). Original
  enabled bytes are captured after seed and compared after upgrade/1603 rollback.
  Success: seed,verify,disable. Rollback: seed,verify,verify,disable.
  Normal application disables Run before uninstall. Original setup guardian,
  client, cache, Pending and gate retirement rules remain. Only after all return
  does finite exact-owner synthetic ProgramData cleanup occur. Unknown retained.

Root still runs PS51 AST/Add-Type checks, actual Cargo/Web producers and actual
Windows qualification/runtime. Local Python/default-inert checks prove none of
those execution outcomes. Preparation freezes include the shared qualifier and
producer dependency closure, in addition to each branch's exact sources.
