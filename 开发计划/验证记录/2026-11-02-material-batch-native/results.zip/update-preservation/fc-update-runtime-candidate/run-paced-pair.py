from pathlib import Path
import subprocess,json,time,sys
R=Path('/tmp/fc-update-runtime-candidate')
assert json.loads((R/'normal-build-u2-paced/terminal.json').read_bytes())==dict(exit=0,sourceUnchanged=True)
cleanup=json.loads((R/'failed-seed-manual-cleanup.json').read_bytes());assert cleanup['status']=='PASS_FAILED_SEED_FORMAL_CLEANUP_AND_FRESH_EXACT_SCRATCH_REMOVAL'
stages=['package-u2','bind-success','run-success','derive-rollback','bind-rollback','run-rollback'];results=[]
for stage in stages:
 cmd=['python3',str(R/'orchestrate-pair.py'),'--config',str(R/'pair-paced.json'),'--execute',stage];t=time.monotonic()
 with (R/('paced-run-'+stage+'.stdout.log')).open('xb') as out,(R/('paced-run-'+stage+'.stderr.log')).open('xb') as err:
  p=subprocess.Popen(cmd,stdout=out,stderr=err);(R/'paced-run.active.json').write_text(json.dumps(dict(pid=p.pid,stage=stage,command=cmd)));code=p.wait()
 row=dict(stage=stage,exit=code,originalParentReaped=True,seconds=time.monotonic()-t);results.append(row);(R/'paced-run.results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
 if code:sys.exit(code)
