from pathlib import Path
import json,runpy,subprocess,stat,hashlib
R=Path('/tmp/fc-update-runtime-candidate');m=runpy.run_path(str(R/'success-final/run-controlled-product.py'));plan=json.loads((R/'success-paced-input/artifact-manifest.json').read_bytes());c=dict(plan=plan)
script=(R/'success-final/sources/ReadOnlyPreflightFunction.ps1').read_text()+"$v=Measure-FcBeforePreflight -Config $c.plan;Need ($v.status-ceq'PASS_BEFORE_KNOWN_ABSENCE_ONLY_NOT_EXECUTION_ADMISSION') 'FINAL_PRODUCT_RUN_DATA_KNOWN_ABSENT';$s=Get-Service -Name sshd;Need ($s.Status-eq'Running') 'PERSISTENT_USER_AUTHORIZED_SSH_REMAINS_RUNNING';@{status='PASS_FINAL_READONLY_PRODUCT_RUN_DATA_ABSENCE_AND_PERSISTENT_SSH_RUNNING';preflight=$v;sshd=[string]$s.Status;serviceMutations=0;authorizationMutations=0}|ConvertTo-Json -Depth 18 -Compress"
a,f=m['remote'](script,c);p=subprocess.run(a,input=f,capture_output=True,timeout=30)
for name,b in [('stdin.ps1',f),('stdout.log',p.stdout),('stderr.log',p.stderr)]: (R/('final-readonly-check.'+name)).write_bytes(b)
assert p.returncode==0;j=json.loads(p.stdout.decode('utf-8-sig'));key=Path('/config/.local/share/future-classroom-test-access/win11-192.168.10.212');st=key.lstat();assert stat.S_ISREG(st.st_mode) and stat.S_IMODE(st.st_mode)==0o600
j.update(originalLocalExit=p.returncode,parentReaped=True,testPrivateKey=dict(path=str(key),regularFile=True,mode='0600',contentsRead=False,contentsHashed=False,removed=False));(R/'final-readonly-check.json').write_text(json.dumps(j,indent=2)+'\n');print(j['status'])
