from pathlib import Path
import subprocess,json,hashlib,runpy
R=Path('/tmp/fc-update-runtime-candidate');main=Path.cwd();M=runpy.run_path('scripts/package-controlled-dev.py')
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
for role in ['u1','u2']:
 dest=R/(role+'-text-source');resume=dest.exists();assert not resume or role=='u1' and M['source_inventory'](dest)==M['source_inventory'](R/'u1-final-source')
 if not resume:
  subprocess.run(['git','clone','--shared','--no-checkout',str(main),str(dest)],check=True)
  for args in [['sparse-checkout','init','--cone'],['sparse-checkout','set','crates','scripts','web','packaging','.cargo'],['checkout','main']]:subprocess.run(['git','-C',str(dest),*args],check=True)
 if role=='u2':patch=subprocess.check_output(['git','diff','--binary'])
 else:patch=(R/'u1-final-integrated.patch').read_bytes()
 if not resume:subprocess.run(['git','-C',str(dest),'apply','--binary','-'],input=patch,check=True)
 if role=='u1':
  base='crates/fc-bootstrap/src/application';p=dest/(base+'.rs');s=p.read_text()
  changes=[('    offscreen_probe: bool,\n','    offscreen_probe: bool,\n    probe_trace: bool,\n'),('        offscreen_probe: probe,\n','        offscreen_probe: probe,\n        probe_trace: true,\n')]
  for a,b in changes:assert s.count(a)==1;s=s.replace(a,b)
  for tail in ['\n            let kind = match &work {','\n                    eprintln!(\n                        \"PROBE_EVENT','\n                let kind = match &outcome {']:
   a='if self.offscreen_probe {'+tail;assert s.count(a)==1;s=s.replace(a,'if self.offscreen_probe && self.probe_trace {'+tail)
  src=(main/(base+'.rs')).read_text();start=src.index('    #[test]\n    fn update_data_subject_text_real_cas');end=src.index('    #[test]',start+8);test=src[start:end]
  assert s.count('mod tests {')==1;s=s.replace('mod tests {','mod tests {\n'+test,1);p.write_text(s)
  for f in ['backup_probe.rs','migration_probe_fixture.rs']:(dest/base/f).write_bytes((main/base/f).read_bytes())
  subprocess.run(['rustfmt','--config','skip_children=true',str(p)],check=True)
 inventory=M['source_inventory'](dest)
 if role=='u2':assert inventory==M['source_inventory'](main)
 diff=subprocess.check_output(['git','-C',str(dest),'diff','--binary']);(R/(role+'-text-integrated.patch')).write_bytes(diff)
 (R/(role+'-text-source-freeze.json')).write_text(json.dumps(dict(status='FROZEN_SUBJECT_TEXT_UPDATE_SOURCE',role=role,sourceRoot=str(dest),sourceHead=head,patchSha256=hashlib.sha256(diff).hexdigest(),inputCount=len(inventory),inputs=inventory),indent=2)+'\n')
 print(role,len(inventory))
for role in ['u1','u2']:
 s=(R/('build-normal-'+role+'-final.py')).read_text().replace('normal-build-'+role+'-final','normal-build-'+role+'-text').replace('normal-evidence-'+role+'-final','normal-evidence-'+role+'-text')
 p=R/('build-normal-'+role+'-text.py');assert not p.exists();p.write_text(s)
c=json.loads((R/'pair-final.json').read_text());c['pair']='text'
for role in ['u1','u2','success','rollback']:
 for key,value in list(c[role].items()):
  if key!='branch':c[role][key]=value.replace('-final','-text')
(R/'pair-text.json').write_text(json.dumps(c,indent=2)+'\n')
