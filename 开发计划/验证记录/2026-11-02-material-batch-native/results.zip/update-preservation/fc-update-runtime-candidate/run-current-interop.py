#!/usr/bin/env python3
"""Actual U1 SOURCE31 typed capture / Rust-Python byte interop. Not a cache API receipt."""
from pathlib import Path
import runpy,hashlib,json,subprocess,time,argparse
R=Path(__file__).resolve().parent

def fact(p):b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');ap.add_argument('--source-root',type=Path);ap.add_argument('--msi',type=Path);ap.add_argument('--msi-sha256');ap.add_argument('--output-dir',type=Path);a=ap.parse_args()
 if not a.execute:print('{"status":"PREPARED_NOT_RUN","Windows":"NOT_CONTACTED","compiler":"NOT_EXECUTED"}');return 0
 assert all([a.source_root,a.msi,a.msi_sha256,a.output_dir]);W=a.source_root.absolute();D=a.output_dir.absolute();assert D.parent==R and not D.exists();D.mkdir();(D/'.owner').write_text('future-classroom-current-u1-source31-interop/v1\n');pub=runpy.run_path(str(W/'scripts/installer-upgrade-publication.py'));source=a.msi.absolute();assert fact(source)['sha256']==a.msi_sha256;schema=pub['schema_from_rust']((W/'crates/fc-windows/src/installer_lifecycle/native/broker/maintenance/schema.rs').read_text());tables=pub['capture'](source,fact(source)['sha256'],schema);digest,facts,canonical=pub['signature'](tables);wire=pub['capture_wire'](tables)
 (D/'source-capture.bin').write_bytes(wire);(D/'python-canonical.bin').write_bytes(canonical);(D/'source-table-facts.json').write_text(json.dumps(dict(scope='ACTUAL_U1_SOURCE31_ONLY_NOT_CACHE',source=fact(source),logicalSHA256=digest,tables=facts),indent=2)+'\n')
 text=(R/'rust-interop.template.rs').read_text().replace('__CURRENT_SOURCE__',str(W));(D/'rust-interop.rs').write_text(text)
 sources=[Path(__file__).resolve(),D/'rust-interop.rs',W/'scripts/installer-upgrade-publication.py',W/'crates/fc-windows/src/installer_lifecycle/native/broker/maintenance/schema.rs',W/'crates/fc-windows/src/installer_lifecycle/native/broker/maintenance/logical.rs'];before=[fact(p)for p in sources];report=dict(status='FAIL_LOCAL_INTEROP',scope='U1_REAL_SOURCE31_NOT_NATIVE_CACHE_OR_UPGRADE_SUCCESS',source=fact(source),sourceBefore=before,commands=[],nativeCacheDigestSerialized=False,Windows='NOT_CONTACTED')
 for label,argv in [('compile',['rustc','--edition','2021','-D','warnings',str(D/'rust-interop.rs'),'-o',str(D/'rust-interop')]),('interop',[str(D/'rust-interop'),str(D/'source-capture.bin'),str(D/'rust-canonical.bin')])]:
  start=time.monotonic();p=subprocess.run(argv,capture_output=True,timeout=90);(D/(label+'.stdout.log')).write_bytes(p.stdout);(D/(label+'.stderr.log')).write_bytes(p.stderr);report['commands'].append(dict(label=label,argv=argv,actualExit=p.returncode,originalParentReaped=True,seconds=time.monotonic()-start,stdout=fact(D/(label+'.stdout.log')),stderr=fact(D/(label+'.stderr.log'))))
  if p.returncode:break
 else:
  assert (D/'rust-canonical.bin').read_bytes()==canonical;report.update(status='PASS_ACTUAL_U1_SOURCE31_RUST_PYTHON_CANONICAL_BYTES_EQUAL',canonicalBytes=len(canonical),logicalSHA256=digest,tableCount=len(tables),sourceTableFacts=fact(D/'source-table-facts.json'))
 report['sourceAfter']=[fact(p)for p in sources];report['sourceUnchanged']=before==report['sourceAfter'];report['binaryIdentitiesOnly']=[fact(p)for p in [D/'source-capture.bin',D/'python-canonical.bin',D/'rust-canonical.bin',D/'rust-interop']if p.exists()]
 if report['status'].startswith('PASS'):
  for leaf in ('source-capture.bin','python-canonical.bin','rust-canonical.bin','rust-interop'):(D/leaf).unlink()
  report['localTemporaryBinariesRemoved']=True
 (D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));return 0 if report['status'].startswith('PASS')else 1
if __name__=='__main__':raise SystemExit(main())
