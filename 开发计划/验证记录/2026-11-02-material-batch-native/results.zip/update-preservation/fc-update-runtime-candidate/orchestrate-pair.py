"""Default-inert current pair orchestration. Root supplies actual producer inputs.
One explicit stage at a time; originals are never overwritten or restarted.
"""
from pathlib import Path
import argparse,ast,hashlib,json,os,subprocess,sys,time
R=Path(__file__).resolve().parent
READONLY_RUN_PROBE="\n # Fixed project Run value: read-only calls only, never registry mutation.\n $nullRun=[Fc80ProductState]::ObserveRun($null);$emptyRun=[Fc80ProductState]::ObserveRun('')\n if($nullRun.Count-ne$emptyRun.Count){throw 'NULL_EMPTY_RUN_OBSERVATION_KEYS_DIFFER'}\n foreach($name in $nullRun.Keys){if(-not$emptyRun.ContainsKey($name) -or -not [Object]::Equals($nullRun[$name],$emptyRun[$name])){throw 'NULL_EMPTY_RUN_OBSERVATION_NOT_IDENTICAL'}}\n if($nullRun['absent']){if(-not$nullRun['matchesExpected']){throw 'ABSENT_VALUE_MUST_MATCH_NULL_EMPTY'}}else{if($nullRun['matchesExpected']){throw 'PRESENT_VALUE_CANNOT_MATCH_ABSENCE_EXPECTATION'}}\n $negative=@();foreach($case in @(@{label='INVALID_BASE64';value='%not-base64%';type='System.FormatException'},@{label='ONE_BYTE_VALID_BASE64';value='AA==';type='System.InvalidOperationException'},@{label='NONEMPTY_WHITESPACE';value=' ';type='System.InvalidOperationException'})){\n  $rejected=$false;$observed=$null\n  try{$ignored=[Fc80ProductState]::ObserveRun($case.value)}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};$observed=$e.GetType().FullName;if($observed-cne$case.type){throw 'NONEMPTY_EXPECTATION_WRONG_ERROR'};if($observed-ceq'System.InvalidOperationException' -and $e.Message-cne'BOUNDED_EXACT_REG_SZ_EXPECTATION'){throw 'NONEMPTY_EXPECTATION_NOT_BOUND_REJECTION'};$rejected=$true}\n  if(-not$rejected){throw 'MALFORMED_NONEMPTY_EXPECTATION_ACCEPTED'};$negative+=@{name=$case.label;rejected=$rejected;exceptionType=$observed}\n }\n $r['readonlyRunProbe']=@{status='PASS_LIVE_NULL_EMPTY_EQUIVALENCE_AND_NONEMPTY_REJECTIONS';nullEmptyEquivalent=$true;actualAbsent=[bool]$nullRun['absent'];absenceExpectationMatched=[bool]$nullRun['matchesExpected'];presentValueCannotMatchAbsenceExpectation=$true;negativeCases=$negative;registryWrites=0;actualRunContentsRetained=$false}\n"
STAGES=['plan','package-u1','bind-u1','sourcecheck-u1','run-u1','interop','package-u2','bind-success','sourcecheck-success','run-success','derive-rollback','bind-rollback','sourcecheck-rollback','run-rollback']
def need(value,message):
 if not value:raise ValueError(message)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_bytes())
def path(name):
 need(isinstance(name,str) and name and not name.startswith('/') and ':' not in name and chr(92) not in name and not any(ord(ch)<32 for ch in name) and all(x not in ['', '.', '..'] for x in name.split('/')),'CANONICAL_PAIR_RELATIVE_PATH');return R/name

def load(config_path):
 c=read(config_path);need(c['schema']==1 and c['root']==str(R) and c['pair'] and all(x.isalnum() or x in '-_' for x in c['pair']),'EXACT_CURRENT_PAIR_CONFIG')
 need((R/'.owner').read_text()=='future-classroom-update-runtime-candidate/v1\n','EXACT_CURRENT_OWNED_ROOT')
 for row in c['sharedPins']:
  p=path(row['path']);need(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],'ORIGINAL_SHARED_SOURCE_PIN_'+row['path'])
 for role in ['u1','u2','success','rollback']:
  for key,value in c[role].items():
   path(value)
   if key in ['branch','input','result','packageInput','packageOutput','interop','forcedPackage']:need('/' not in value,'DIRECT_OWNED_PAIR_DIRECTORY_'+key)
 return c

def environment(c):
 e=os.environ.copy()
 for name in ['LD_PRELOAD','LD_AUDIT','GIO_EXTRA_MODULES','GIO_MODULE_DIR']:e.pop(name,None)
 t=Path(c['toolsRoot']);child=read(t/'child-environment.json');need(set(child)=={'LD_LIBRARY_PATH','LC_ALL','GIO_USE_VFS','GSETTINGS_BACKEND'},'EXACT_CONTROLLED_TOOL_ENVIRONMENT');e.update(child);return e

def run(c,config_path,stage,cmd):
 label='pair-'+c['pair']+'-'+stage
 for ext in ['.active.json','.terminal.json','.stdout.log','.stderr.log']:need(not (R/(label+ext)).exists(),'NEW_ORIGINAL_STAGE_CONTROLLER_ONLY_'+label)
 start=time.monotonic()
 with (R/(label+'.stdout.log')).open('xb') as out,(R/(label+'.stderr.log')).open('xb') as err:
  p=subprocess.Popen(cmd,env=environment(c),stdout=out,stderr=err)
  (R/(label+'.active.json')).write_text(json.dumps(dict(pid=p.pid,command=cmd,pairConfig=str(config_path),pairConfigSha256=sha(config_path)))+'\n')
  code=p.wait()
 result=dict(exit=code,command=cmd,pairConfig=str(config_path),pairConfigSha256=sha(config_path),originalParentReaped=True,seconds=time.monotonic()-start)
 (R/(label+'.terminal.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);need(code==0,'ORIGINAL_PAIR_STAGE_NONZERO_'+stage)

def normal(c,role):
 v=c[role];terminal=read(path(v['terminal']));need(terminal.get('exit')==0 and terminal.get('sourceUnchanged') is True,'ACTUAL_PAIR_NORMAL_TERMINAL_ZERO_'+role)
 e=path(v['evidence']);j=read(e);need(j['status']=='DEV_FROZEN_NORMAL_BUILD_ONLY' and j['source_root']==str(path(v['source'])) and j['target']=='i686-pc-windows-gnu' and j['lifecycle_mode']=='ABI2_UPDATE_DATA_CURRENT_NORMAL_GNU_DEV','ACTUAL_PAIR_NORMAL_SOURCE_'+role)
 return e

def package(c,role):
 out=path(c[role]['packageOutput']);j=read(out/'report.json');expected='PASS_NORMAL_GNU_ABI2_UPGRADE_CAPABLE_DEV_STATIC_BUNDLE_NATIVE_NOT_RUN' if role=='u1' else 'PASS_NORMAL_GNU_ABI2_SUCCESSOR_MIXED_NORMAL_SOURCES_STATIC_BUNDLE_NATIVE_NOT_RUN'
 need(j['status']==expected and j['version']==('0.2.0' if role=='u1' else '0.3.0') and j['lifecycleMode']=='ABI2_UPDATE_DATA_CURRENT_NORMAL_GNU_DEV' and j['sourceRoot']==str(path(c['u1']['source'])),'ACTUAL_CURRENT_PAIR_STATIC_PACKAGE_'+role)
 need(j['upgradeSourceBinding']['sourceEvidence']['path']==str(path(c['u1']['evidence'])),'PAIR_PACKAGE_ACTUAL_U1_EVIDENCE')
 if role=='u2':need(j['productSourceRoot']==str(path(c['u2']['source'])) and j['productProvenance']['evidence']['path']==str(path(c['u2']['evidence'])),'PAIR_U2_ACTUAL_NEW_PRODUCT_DOMAIN')
 return out/'report.json'

def frozen(c,role):
 d=path(c[role]['branch']);revision=read(d/'revision.json');f=d/'freeze-first.json';need(sha(f)==revision['newFreeze']['sha256'],'EXACT_PAIR_BRANCH_FREEZE');j=read(f)
 for base,key in [(d,'files'),(R,'sharedFiles')]:
  for row in j[key]:
   p=base/row['path'];need(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],'EXACT_PAIR_FROZEN_SOURCE_'+row['path'])
 return d,f

def source_check(c,role):
 branch=c[role]['branch'];d,_=frozen(c,role);j=read(R/(branch+'-source-check.json'));need(j['status']=='PASS_PS51_AST_CSHARP_COMPILE_ONLY' and j['originalSSHExit']==0 and j['cleanup']==dict(exit=0,status='PASS_OWNED_ROOT_ABSENT'),'ACTUAL_PAIR_SOURCE_CHECK_PASS')
 need({p.name:sha(p) for p in (d/'sources').iterdir() if p.is_file()}=={x['name']:x['sha256'] for x in j['inputs']},'EXACT_PAIR_SOURCE_CHECK_BYTES')
 if role!='u1':
  probe=j['readonlyRunProbe'];need(probe['status']=='PASS_LIVE_NULL_EMPTY_EQUIVALENCE_AND_NONEMPTY_REJECTIONS' and probe['nullEmptyEquivalent'] is True and probe['registryWrites']==0 and len(probe['negativeCases'])==3 and all(x['rejected'] is True for x in probe['negativeCases']),'ACTUAL_PAIR_READONLY_RUN_SOURCE_PROBE')

def perform_source_check(c,role):
 # Load only original checker definitions; omit its old top-level parallel loop.
 branch=c[role]['branch'];frozen(c,role)
 for ext in ['.json','.stdout.log','.stderr.log']:need(not (R/(branch+'-source-check'+ext)).exists(),'NEW_SOURCE_CHECK_ONLY')
 original=R/'check-windows-sources.py';tree=ast.parse(original.read_bytes());body=[]
 for node in tree.body:
  if isinstance(node,(ast.Import,ast.ImportFrom,ast.Assign,ast.FunctionDef)):body.append(node)
  else:need(isinstance(node,(ast.With,ast.Expr,ast.Assert)),'KNOWN_ORIGINAL_SOURCE_CHECK_TOPLEVEL')
 if role!='u1':
  class AddReadonlyProbe(ast.NodeTransformer):
   count=0
   def visit_Constant(self,node):
    needle=" $r.status='PASS_PS51_AST_CSHARP_COMPILE_ONLY'"
    if isinstance(node.value,str) and needle in node.value:
     need(node.value.count(needle)==1,'ONE_ORIGINAL_SOURCE_STATUS');self.count+=1;return ast.copy_location(ast.Constant(node.value.replace(needle,READONLY_RUN_PROBE+needle,1)),node)
    return node
  add=AddReadonlyProbe();tree=add.visit(ast.Module(body=body,type_ignores=[]));need(add.count==1,'ONE_READONLY_PROBE_INJECTION');ast.fix_missing_locations(tree)
 else:tree=ast.Module(body=body,type_ignores=[])
 ns={'__file__':str(original),'__name__':'single_current_pair_source_checker'};exec(compile(tree,str(original),'exec'),ns);result=ns['one'](branch);source_check(c,role);print(json.dumps(result))

def base_package_args(c,role):
 v=c[role];ev=normal(c,'u1');web=path(c['web']['report']);t=Path(c['toolsRoot'])
 for key in ['packageInput','packageOutput']:need(not path(v[key]).exists(),'FRESH_CURRENT_PAIR_PACKAGE_'+key)
 return ['--source-root',str(path(c['u1']['source'])),'--evidence',str(ev),'--evidence-sha256',sha(ev),'--web-report',str(web),'--web-report-sha256',sha(web),'--web-dist',str(path(c['web']['dist'])),'--input-dir',str(path(v['packageInput'])),'--output-dir',str(path(v['packageOutput'])),'--wixl',str(t/'wrappers/wixl-second'),'--msibuild',str(t/'root/usr/bin/msibuild'),'--msibuild-sha256',sha(t/'root/usr/bin/msibuild'),'--msiinfo',str(t/'root/usr/bin/msiinfo'),'--msiextract',str(t/'root/usr/bin/msiextract'),'--objdump','/usr/bin/i686-w64-mingw32-objdump']

def main():
 p=argparse.ArgumentParser();p.add_argument('--config',type=Path,default=R/'pair-final.json');p.add_argument('--execute',action='store_true');p.add_argument('stage',choices=STAGES);a=p.parse_args()
 if not a.execute:
  print(json.dumps(dict(status='PREPARED_NOT_RUN',stage=a.stage,config=str(a.config),Windows='NOT_CONTACTED',Cargo='NOT_RUN',MSI='NOT_RUN')));return 0
 c=load(a.config);stage=a.stage
 if stage=='plan':print(json.dumps(dict(status='PAIR_CONFIGURATION_ONLY_NO_EXECUTION',config=c,stages=STAGES)));return 0
 if stage.startswith('sourcecheck-'):
  role=stage.split('-',1)[1];perform_source_check(c,role);return 0
 if stage=='package-u1':cmd=[sys.executable,str(R/'package-current-u1.py'),'--execute','--product-version','0.2.0']+base_package_args(c,'u1')
 elif stage=='package-u2':
  u1=package(c,'u1');runtime=path(c['u1']['result'])/'report.json';j=read(runtime);need(j['status']=='PASS_GNU_ABI2_SAME_PACKAGE_MAINTENANCE_WIN11_DEV_CONTROLLED_PRODUCT_CLOSURE_AND_EXACT_SCRATCH_CLEANUP' and j['runtimeActualExit']==0 and j['downloadVerified'] is True,'ACTUAL_NEW_PAIR_FULL_U1_CHAIN')
  af=j['artifactManifest'];need(af['path']==str(path(c['u1']['input'])/'artifact-manifest.json') and af['sha256']==sha(Path(af['path'])),'EXACT_NEW_PAIR_U1_RUNTIME_INPUT')
  interop=path(c['u1']['interop'])/'report.json';i=read(interop);need(i['status']=='PASS_ACTUAL_U1_SOURCE31_RUST_PYTHON_CANONICAL_BYTES_EQUAL' and i['source']['path']==str(path(c['u1']['packageOutput'])/'FutureClassroom.msi') and i['sourceUnchanged'] is True,'ACTUAL_NEW_PAIR_SOURCE31_INTEROP')
  ev=normal(c,'u2');cmd=[sys.executable,str(R/'package-current-u2.py'),'--execute']+base_package_args(c,'u2')+['--u2-source-root',str(path(c['u2']['source'])),'--u2-evidence',str(ev),'--u2-evidence-sha256',sha(ev),'--u1-package',str(u1),'--u1-package-sha',sha(u1),'--u1-runtime',str(runtime),'--u1-runtime-sha',sha(runtime),'--u1-interop',str(interop),'--u1-interop-sha',sha(interop)]
 elif stage.startswith('bind-'):
  role=stage.split('-',1)[1];u1=package(c,'u1');v=c[role];need(not path(v['input']).exists(),'FRESH_PAIR_RUNTIME_INPUT')
  cmd=[sys.executable,str(R/'bind-current-artifact.py'),'--execute','--u1-report',str(u1),'--u1-report-sha256',sha(u1),'--sid',c['expectedUserSid'],'--output-dir',str(path(v['input']))]
  if role!='u1':
   u2=package(c,'u2');cmd+=['--u2-report',str(u2),'--u2-report-sha256',sha(u2)]
   if role=='rollback':
    f=path(v['forcedPackage'])/'derivation-report.json';need(read(f)['canonicalReport']['path']==str(u2),'EXACT_PAIR_DERIVATION_CANONICAL_PACKAGE');cmd+=['--forced-derivation',str(f),'--forced-derivation-sha256',sha(f)]
 elif stage.startswith('run-'):
  role=stage.split('-',1)[1];d,f=frozen(c,role);source_check(c,role);v=c[role];inputs=path(v['input']);report=path(v['result'])/'report.json';need(not report.parent.exists(),'FRESH_ORIGINAL_PAIR_RUNTIME_REPORT')
  af=read(inputs/'artifact-manifest.json');need(af['packageReport']['path']==str(path(c['u1']['packageOutput'])/'report.json'),'EXACT_PAIR_RUNTIME_U1_PACKAGE')
  if role!='u1':need(af['successor']['packageReport']['path']==str(path(c['u2']['packageOutput'])/'report.json'),'EXACT_PAIR_RUNTIME_U2_PACKAGE')
  cmd=[sys.executable,str(d/'run-controlled-product.py'),'--execute','--artifact-manifest',str(inputs/'artifact-manifest.json'),'--artifact-manifest-sha256',sha(inputs/'artifact-manifest.json'),'--source-manifest',str(inputs/'source-manifest.json'),'--source-manifest-sha256',sha(inputs/'source-manifest.json'),'--preparation-freeze-sha256',sha(f),'--report',str(report)]
 elif stage=='interop':
  package(c,'u1');v=c['u1'];out=path(v['interop']);need(not out.exists(),'FRESH_PAIR_SOURCE31_INTEROP_OUTPUT');msi=path(v['packageOutput'])/'FutureClassroom.msi';cmd=[sys.executable,str(R/'run-current-interop.py'),'--execute','--source-root',str(path(v['source'])),'--msi',str(msi),'--msi-sha256',sha(msi),'--output-dir',str(out)]
 elif stage=='derive-rollback':
  u2=package(c,'u2');out=path(c['rollback']['forcedPackage']);need(not out.exists(),'FRESH_CURRENT_PAIR_TYPE19_OUTPUT');t=Path(c['toolsRoot']);cmd=[sys.executable,str(R/'derive-current-type19.py'),'--execute','--canonical-report',str(u2),'--canonical-report-sha256',sha(u2),'--source-root',str(path(c['u1']['source'])),'--tools-manifest',str(t/'tools.json'),'--tools-manifest-sha256',sha(t/'tools.json'),'--child-environment',str(t/'child-environment.json'),'--child-environment-sha256',sha(t/'child-environment.json'),'--output-dir',str(out)]
 else:raise ValueError('UNKNOWN_EXPLICIT_PAIR_STAGE')
 run(c,a.config,stage,cmd);return 0
if __name__=='__main__':raise SystemExit(main())
