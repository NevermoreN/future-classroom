from pathlib import Path
import subprocess,json,hashlib,runpy
R=Path('/tmp/fc-update-runtime-candidate');main=Path.cwd();M=runpy.run_path('scripts/package-controlled-dev.py');head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
for role in ['u1','u2']:
 dest=R/(role+'-tail-source');assert not dest.exists()
 subprocess.run(['git','clone','--shared','--no-checkout',str(main),str(dest)],check=True)
 for args in [['sparse-checkout','init','--cone'],['sparse-checkout','set','crates','scripts','web','packaging','.cargo'],['checkout','main']]:subprocess.run(['git','-C',str(dest),*args],check=True)
 patch=subprocess.check_output(['git','diff','--binary']) if role=='u2' else (R/'u1-text-integrated.patch').read_bytes()
 subprocess.run(['git','-C',str(dest),'apply','--binary','-'],input=patch,check=True)
 if role=='u1':subprocess.run(['git','-C',str(dest),'apply','-'],input=(R/'post-reconcile-run-tail.patch').read_bytes(),check=True)
 inv=M['source_inventory'](dest)
 if role=='u2':assert inv==M['source_inventory'](main)
 diff=subprocess.check_output(['git','-C',str(dest),'diff','--binary']);(R/(role+'-tail-integrated.patch')).write_bytes(diff)
 (R/(role+'-tail-source-freeze.json')).write_text(json.dumps(dict(status='FROZEN_FINAL_SUBJECT_TEXT_AND_TERMINAL_RUN_CHECK_SOURCE',role=role,sourceRoot=str(dest),sourceHead=head,patchSha256=hashlib.sha256(diff).hexdigest(),inputCount=len(inv),inputs=inv),indent=2)+'\n')
 s=(R/('build-normal-'+role+'-text.py')).read_text().replace('normal-build-'+role+'-text','normal-build-'+role+'-tail').replace('normal-evidence-'+role+'-text','normal-evidence-'+role+'-tail');(R/('build-normal-'+role+'-tail.py')).write_text(s)
 print(role,len(inv))
c=json.loads((R/'pair-text.json').read_text());c['pair']='tail'
for role in ['u1','u2','success','rollback']:
 for k,v in list(c[role].items()):
  if k!='branch':c[role][k]=v.replace('-text','-tail')
(R/'pair-tail.json').write_text(json.dumps(c,indent=2)+'\n')
