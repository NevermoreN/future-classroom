# Explicit synthetic update probe only; dot-source defines functions, no side effects.
function Initialize-UpdateData {
 $script:dataRoot=Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::CommonApplicationData)) 'FutureClassroom'
 Require ((Known-Path $script:dataRoot).status-ceq'KNOWN_ABSENT') 'PROGRAMDATA_PREEXISTING_OR_UNKNOWN_REFUSE'
 Require ($script:c.runtimeNonce-cmatch'^[0-9a-f]{32}$') 'EXACT_DATA_OWNER_NONCE'
 $script:dataNonce=$script:c.runtimeNonce;$script:dataSeeded=$false;$script:dataDisabled=$false;$script:dataSequence=-1;$script:result['updateDataStages']=@()
}
function Assert-OwnedUpdateData {
 $fact=Known-Path $script:dataRoot
 Require ($fact.status-ceq'KNOWN_PRESENT' -and $fact.directory -and -not$fact.reparse) 'SYNTHETIC_DATA_ROOT_EXACT_DIRECTORY'
 $p=Join-Path $script:dataRoot 'update-data-probe.owner';$f=Get-Item -LiteralPath $p -Force
 Require (-not$f.PSIsContainer -and ($f.Attributes-band1024)-eq0 -and $f.Length-eq32 -and [IO.File]::ReadAllText($p,[Text.UTF8Encoding]::new($false))-ceq$script:dataNonce) 'EXACT_SYNTHETIC_DATA_OWNER'
}
function Invoke-UpdateDataStage([ValidateSet('seed','verify','disable')][string]$stage) {
 Require (-not$script:ownerUnknown -and -not$script:instrumentUnknown -and (Remaining)-gt180000 -and (Own-Processes).knownZero) 'DATA_STAGE_ORIGINAL_RETURN_AND_CLEANUP_RESERVE'
 if($stage-ceq'seed'){Require (-not$script:dataSeeded -and (Known-Path $script:dataRoot).status-ceq'KNOWN_ABSENT') 'FRESH_DATA_ONLY'}else{Assert-OwnedUpdateData}
 $exe=Join-Path $script:programRoot 'fc-bootstrap.exe';$row=@($script:c.payloads|Where-Object{$_.path-ceq'fc-bootstrap.exe'});Require ($row.Count-eq1 -and (Digest $exe)-ceq$row[0].sha256) 'ACTUAL_INSTALLED_NORMAL_PRODUCT_HASH'
 Require ($script:dataRoot.IndexOf('"')-lt0 -and $script:dataRoot.IndexOf("`n")-lt0 -and $script:dataRoot.IndexOf("`r")-lt0) 'CLOSED_DATA_ARGUMENT_PATH'
 $ordinal=@($script:result.updateDataStages).Count;$r=[ordered]@{stage=$stage;ordinal=$ordinal;imageSha256=$row[0].sha256;nonce=$script:dataNonce;actualExit=$false;exitCode=$null;checkedOriginalClose=$false;data='SYNTHETIC_ONLY_NO_DATABASE_BYTES_CAPTURED'};$script:result.updateDataStages+=,$r
 $p=$null;$capture=$null;$out=$null;$err=$null;$ot=$null;$et=$null;$script:ownerUnknown=$true
 try {
  $capture=[Fc79Capture]::new();$p=[Diagnostics.Process]::new();$p.StartInfo.FileName=$exe;$p.StartInfo.Arguments='--update-data-probe-stage "'+$script:dataRoot+'" '+$script:dataNonce+' '+$stage;$p.StartInfo.WorkingDirectory=$script:programRoot;$p.StartInfo.UseShellExecute=$false;$p.StartInfo.CreateNoWindow=$true;$p.StartInfo.WindowStyle=[Diagnostics.ProcessWindowStyle]::Hidden;$p.StartInfo.RedirectStandardInput=$true;$p.StartInfo.RedirectStandardOutput=$true;$p.StartInfo.RedirectStandardError=$true
  $outPath=Join-Path $ScratchRoot ('data-'+$ordinal+'-'+$stage+'.stdout.log');$errPath=Join-Path $ScratchRoot ('data-'+$ordinal+'-'+$stage+'.stderr.log');$out=[IO.File]::Open($outPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);$err=[IO.File]::Open($errPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
  Require ($p.Start()) 'DATA_STAGE_CREATEPROCESS';$p.StandardInput.Close();$r['pid']=$p.Id;$r['creationFiletime']=$p.StartTime.ToUniversalTime().ToFileTimeUtc();$r['originalAtStart']=Clone ($capture.HoldStartedClient($p.Handle,[uint32]$p.Id,$r.creationFiletime,$exe,$row[0].sha256,$script:c.expectedUserSid));$ot=$p.StandardOutput.BaseStream.CopyToAsync($out);$et=$p.StandardError.BaseStream.CopyToAsync($err)
  $budget=[int][Math]::Min(45000,[Math]::Max(0,(Remaining)-180000));$r.actualExit=$p.WaitForExit($budget);if($r.actualExit){$r.exitCode=$p.ExitCode};$r['pipesComplete']=[Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($ot,$et),[int][Math]::Min(2000,[Math]::Max(0,(Remaining)-180000)))
 } finally {
  if($capture){try{$r['originalFinal']=@((Clone ($capture.FinishAndClose())));$r['nativeCloseUnknown']=$capture.NativeCloseUnknown;$r['nativeReturns']=Clone ($capture.NativeReturns());$r.checkedOriginalClose=(@($r.originalFinal).Count-eq1 -and @($r.originalFinal|Where-Object{$_.Status-cne'HELD_ORIGINAL_IDENTITY' -or $_.Wait-ne0 -or -not$_.ExitKnown -or -not$_.CloseAttempted -or -not$_.CheckedClose}).Count-eq0 -and -not$r.nativeCloseUnknown)}catch{$script:instrumentUnknown=$true}}
  foreach($f in @($out,$err)){if($f){$f.Dispose()}}
  if($p){if($r.actualExit){$p.Dispose()}else{$r['retainedLiveOriginal']=$true}}
  $script:ownerUnknown=-not($r.actualExit -and $r.checkedOriginalClose -and $r.Contains('pipesComplete') -and $r.pipesComplete -and -not$script:instrumentUnknown)
 }
 Require (-not$script:ownerUnknown -and $r.exitCode-eq0 -and @($r.originalFinal|Where-Object{$_.ExitCode-ne0}).Count-eq0) 'DATA_STAGE_ORIGINAL_ACTUAL_ZERO_AND_CLOSE'
 Require ((Get-Item -LiteralPath $outPath).Length-le4096 -and (Get-Item -LiteralPath $errPath).Length-eq0) 'DATA_STAGE_BOUNDED_PUBLIC_RECEIPT_ONLY'
 $line=[IO.File]::ReadAllText($outPath,[Text.UTF8Encoding]::new($false)).TrimEnd([char[]]@([char]13,[char]10));$pattern='\AUPDATE_DATA_PROBE stage='+$stage+' result=PASS nonce='+$script:dataNonce+' sequence=([0-9]|1[0-6]) manifest_sha256=([0-9a-f]{64})\z';$match=[regex]::Match($line,$pattern);Require $match.Success 'EXACT_NORMAL_PRODUCT_PUBLIC_RECEIPT'
 Assert-OwnedUpdateData;$sequence=[int]$match.Groups[1].Value;$expectedSequence=$(if($stage-ceq'seed'){0}elseif($stage-ceq'verify'){$script:dataSequence+1}else{$script:dataSequence});Require ($sequence-eq$expectedSequence) 'EXACT_NORMAL_MANIFEST_SEQUENCE';$leaf=$(if($sequence-eq0){'update-data-probe.manifest'}else{'update-data-probe.manifest.'+$sequence.ToString('D6')});$manifest=Join-Path $script:dataRoot $leaf;$f=Get-Item -LiteralPath $manifest -Force;Require (-not$f.PSIsContainer -and ($f.Attributes-band1024)-eq0 -and $f.Length-gt0 -and $f.Length-le65536 -and (Digest $manifest)-ceq$match.Groups[2].Value) 'ORIGINAL_NORMAL_PRODUCT_MANIFEST_HASH'
 $script:dataSequence=$sequence;$r['sequence']=$sequence;$r['manifestSha256']=$match.Groups[2].Value;$r['manifestBytes']=$f.Length;$r['currentProcesses']=Own-Processes;Require $r.currentProcesses.knownZero 'DATA_STAGE_OWN_PROCESS_ZERO'
 # The original public manifest is retained separately; credentials and DB are never copied.
 [IO.File]::Copy($manifest,(Join-Path $ScratchRoot ('data-'+$ordinal+'-'+$stage+'.manifest')),$false)
 if($stage-ceq'seed'){$script:dataSeeded=$true;$script:expectedRunBase64=[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes('"'+$exe+'" --autostart'+[char]0));$script:result['originalEnabledRun']=Clone ([Fc80ProductState]::ObserveRun($script:expectedRunBase64));Require $script:result.originalEnabledRun.matchesExpected 'SEED_EXACT_ENABLED_REG_SZ_UTF16'}
 elseif($stage-ceq'verify'){$actual=Clone ([Fc80ProductState]::ObserveRun($script:expectedRunBase64));$r['preservedRun']=$actual;Require ($actual.matchesExpected -and -not$actual.absent -and $actual.type-eq1 -and $actual.base64-ceq$script:result.originalEnabledRun.base64) 'UPGRADE_OR_ROLLBACK_ORIGINAL_RUN_BYTES_PRESERVED'}
 else{$script:expectedRunBase64=$null;$script:dataDisabled=$true;$r['disabledRun']=Clone ([Fc80ProductState]::ObserveRun($null));Require $r.disabledRun.absent 'NORMAL_PRODUCT_RUN_DISABLED'}
 $r['status']='PASS_ACTUAL_INSTALLED_NORMAL_PROCESS_AND_ORIGINAL_HANDLE'
}
function Remove-OwnedUpdateData {
 Require ($script:dataSeeded -and $script:dataDisabled -and -not$script:ownerUnknown -and -not$script:instrumentUnknown -and (Own-Processes).knownZero -and (Remaining)-gt0) 'SYNTHETIC_CLEANUP_AUTHORITY'
 Assert-OwnedUpdateData;$q=[Collections.Generic.Queue[string]]::new();$q.Enqueue($script:dataRoot);$files=@();$dirs=@();$total=0L
 while($q.Count){$dir=$q.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){$a=[IO.File]::GetAttributes($p);Require (($a-band1024)-eq0) 'SYNTHETIC_CLEANUP_NO_REPARSE';if(($a-band16)-ne0){$dirs+=$p;$q.Enqueue($p)}else{$f=Get-Item -LiteralPath $p -Force;$files+=$p;$total+=$f.Length};Require ($files.Count-le256 -and $dirs.Count-le64 -and $total-le33554432) 'SYNTHETIC_CLEANUP_FINITE'}}
 Assert-OwnedUpdateData;foreach($p in $files){if($p-cne(Join-Path $script:dataRoot 'update-data-probe.owner')){[IO.File]::Delete($p)}};foreach($p in @($dirs|Sort-Object Length -Descending)){[IO.Directory]::Delete($p,$false)};[IO.File]::Delete((Join-Path $script:dataRoot 'update-data-probe.owner'));[IO.Directory]::Delete($script:dataRoot,$false)
 Require ((Known-Path $script:dataRoot).status-ceq'KNOWN_ABSENT') 'SYNTHETIC_DATA_REMOVED';$script:result['syntheticDataCleanup']=@{status='PASS_EXACT_NONCE_OWNED_SYNTHETIC_DATA_ROOT_REMOVED';files=$files.Count;directories=$dirs.Count;databaseContentsCaptured=$false;knownAbsent=$true}
}
