from pathlib import Path
import json,runpy,hashlib
R=Path('/tmp/fc-update-runtime-candidate');rows=[]
for role,branch in [('success','success-final'),('rollback','rollback-final')]:
 p=R/(role+'-tail-result/report.json');j=json.loads(p.read_bytes());m=runpy.run_path(str(R/branch/'run-controlled-product.py'));v=j['phase'];plan=json.loads((R/(role+'-tail-input/artifact-manifest.json')).read_bytes());admitted=m['admission'](v,plan) if role=='rollback' else m['admission'](v)
 assert j['runtimeActualExit']==0 and j['downloadVerified'] and admitted and j['cleanup']['knownAbsent']
 row=dict(role=role,status=j['status'],reportSha256=hashlib.sha256(p.read_bytes()).hexdigest(),schoolDataPreservation=j['schoolDataPreservation'],enabledRunUpgrade=j['enabledRunUpgrade'],stages=[dict(stage=x['stage'],exit=x['exitCode'],sequence=x['sequence'],manifest=x['manifestSha256']) for x in v['updateDataStages']],phases=[dict(name=x['name'],exit=x['client']['exitCode'],knownControlsReturned=x['knownControlsReturned']) for x in v['phases']],syntheticDataCleanup=v['syntheticDataCleanup'],scratchRemoved=j['cleanup']['knownAbsent']);rows.append(row);print(json.dumps(row,ensure_ascii=False))
(R/'tail-pair-root-summary.json').write_text(json.dumps(dict(status='PASS_INDEPENDENT_ROOT_REPLAY_CURRENT_NORMAL_UPGRADE_AND_TYPE19_ROLLBACK',originalControllerExit=0,results=rows),ensure_ascii=False,indent=2)+'\n')
