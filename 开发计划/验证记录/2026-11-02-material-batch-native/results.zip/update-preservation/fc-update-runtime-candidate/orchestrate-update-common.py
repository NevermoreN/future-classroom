"""Root-only orchestration; preserves originals and never restarts a prior stage."""
from pathlib import Path
import hashlib,json,os,subprocess,time,sys
R=Path(__file__).resolve().parent
T=Path('/tmp/fc-round80-controlled-repair/inner-guard-probe-tools-first')
def need(v,m):
 if not v:raise ValueError(m)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def json_doc(p):return json.loads(Path(p).read_bytes())
def validate_fixed():
 need((R/'.owner').read_text()=='future-classroom-update-runtime-candidate/v1\n','EXACT_OWNED_CANDIDATE')
 for row in json_doc(R/'orchestration-input-pins.json')['files']:
  p=R/row['path'];need(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],'ORIGINAL_FIXED_INPUT_CHANGED_'+row['path'])
 need(json_doc(R/'normal-build-second/terminal.json')==dict(exit=0,sourceUnchanged=True),'ACTUAL_U1_NORMAL_TERMINAL_ZERO')
 r=json_doc(R/'u1-result/report.json');need(r['runtimeActualExit']==0 and r['downloadVerified'] is True and r['status']=='PASS_GNU_ABI2_SAME_PACKAGE_MAINTENANCE_WIN11_DEV_CONTROLLED_PRODUCT_CLOSURE_AND_EXACT_SCRATCH_CLEANUP','ORIGINAL_ACTUAL_U1_CHAIN_PASS')
 i=json_doc(R/'u1-interop/report.json');need(i['status']=='PASS_ACTUAL_U1_SOURCE31_RUST_PYTHON_CANONICAL_BYTES_EQUAL' and i['tableCount']==31 and i['sourceUnchanged'] is True,'ORIGINAL_ACTUAL_U1_SOURCE31_PASS')
def tools_environment():
 env=os.environ.copy()
 for key in ['LD_PRELOAD','LD_AUDIT','GIO_EXTRA_MODULES','GIO_MODULE_DIR']:env.pop(key,None)
 child=json_doc(T/'child-environment.json');need(set(child)=={'LD_LIBRARY_PATH','LC_ALL','GIO_USE_VFS','GSETTINGS_BACKEND'},'EXACT_FINITE_BUILDER_ENVIRONMENT');env.update(child);return env
def run(label,cmd,env=None):
 # Existing evidence is never overwritten or treated as authority to restart.
 for tail in ['stdout.log','stderr.log','active.json','terminal.json']:need(not (R/(label+'.'+tail)).exists(),'NEW_ORIGINAL_CONTROLLER_LABEL_REQUIRED')
 active=R/(label+'.active.json');terminal=R/(label+'.terminal.json');start=time.monotonic()
 with (R/(label+'.stdout.log')).open('xb') as out,(R/(label+'.stderr.log')).open('xb') as err:
  p=subprocess.Popen(cmd,env=env,stdout=out,stderr=err)
  active.write_text(json.dumps(dict(pid=p.pid,command=cmd,owner='root-original-orchestration-process'))+'\n')
  # The root observes this same original parent/tool handle until terminal.
  code=p.wait()
 result=dict(command=cmd,exit=code,originalParentReaped=True,seconds=time.monotonic()-start)
 terminal.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(stage=label,**result)),flush=True)
 need(code==0,'ACTUAL_CHILD_NONZERO_'+label);return result

def runtime_command(branch):
 d=R/(branch+'-input');freeze=R/branch/'freeze-first.json'
 need(d.is_dir() and freeze.is_file(),'ACTUAL_BOUND_INPUT_AND_FREEZE_REQUIRED')
 return [sys.executable,str(R/branch/'run-controlled-product.py'),'--execute','--artifact-manifest',str(d/'artifact-manifest.json'),'--artifact-manifest-sha256',sha(d/'artifact-manifest.json'),'--source-manifest',str(d/'source-manifest.json'),'--source-manifest-sha256',sha(d/'source-manifest.json'),'--preparation-freeze-sha256',sha(freeze),'--report',str(R/(branch+'-result')/'report.json')]
def bind_command(branch):
 c=json_doc(R/'u1-input/artifact-manifest.json')
 return [sys.executable,str(R/'bind-current-artifact.py'),'--execute','--u1-report',str(R/'u1-package/report.json'),'--u1-report-sha256',sha(R/'u1-package/report.json'),'--u2-report',str(R/'u2-package/report.json'),'--u2-report-sha256',sha(R/'u2-package/report.json'),'--sid',c['expectedUserSid'],'--output-dir',str(R/(branch+'-input'))]
def package_pass():
 need(json_doc(R/'package-u2.terminal.json')['exit']==0,'ORIGINAL_CURRENT_U2_PACKAGE_CONTROLLER_ZERO')
 j=json_doc(R/'u2-package/report.json');need(j['status']=='PASS_NORMAL_GNU_ABI2_SUCCESSOR_MIXED_NORMAL_SOURCES_STATIC_BUNDLE_NATIVE_NOT_RUN' and j['binaryReadback']=='ALL_FOUR_EXACT' and j['payloadReadback']=='ALL_FOURTEEN_EXACT','ACTUAL_CURRENT_NORMAL_U2_STATIC_PACKAGE')
def source_check(branch):
 j=json_doc(R/(branch+'-source-check.json'));need(j['status']=='PASS_PS51_AST_CSHARP_COMPILE_ONLY' and j['originalSSHExit']==0 and j['cleanup']['exit']==0,'ACTUAL_SOURCE_AST_AND_CSHARP_COMPILE_REQUIRED')
 actual={p.name:sha(p) for p in (R/branch/'sources').iterdir() if p.is_file()};expected={row['name']:row['sha256'] for row in j['inputs']};need(actual==expected,'SAME_ACTUAL_SOURCE_CHECKED_RUNTIME_FILES')
def previous_zero(label):need(json_doc(R/(label+'.terminal.json'))['exit']==0,'ORIGINAL_PREVIOUS_STAGE_ZERO_'+label)
def run_branch(branch,stage):
 validate_fixed();package_pass();source_check(branch)
 phases=['bind','freeze','run'] if branch=='success' else ['derive','bind','freeze','run']
 selected=phases if stage=='all' else [stage]
 for current in selected:
  if current=='derive':
   need(branch=='rollback' and not (R/'rollback-forced-package').exists(),'FRESH_FORCED_DERIVATION_OUTPUT')
   cmd=[sys.executable,str(R/'derive-current-type19.py'),'--execute','--canonical-report',str(R/'u2-package/report.json'),'--canonical-report-sha256',sha(R/'u2-package/report.json'),'--source-root',str(R/'u1-source'),'--tools-manifest',str(T/'tools.json'),'--tools-manifest-sha256',sha(T/'tools.json'),'--child-environment',str(T/'child-environment.json'),'--child-environment-sha256',sha(T/'child-environment.json'),'--output-dir',str(R/'rollback-forced-package')]
   run('rollback-derive',cmd,tools_environment())
  elif current=='bind':
   need(not (R/(branch+'-input')).exists(),'FRESH_RUNTIME_INPUT_BINDING_REQUIRED');cmd=bind_command(branch)
   if branch=='rollback':
    previous_zero('rollback-derive');f=R/'rollback-forced-package/derivation-report.json';need(json_doc(f)['status']=='PASS_DEV_ABI2_UPGRADE_TYPE19_POSTEXECUTE_FIXTURE_STATIC_ONLY','ACTUAL_COMPLETE_TYPE19_DERIVATION');cmd+=['--forced-derivation',str(f),'--forced-derivation-sha256',sha(f)]
   run(branch+'-bind',cmd,tools_environment())
  elif current=='freeze':
   previous_zero(branch+'-bind');need(not (R/branch/'freeze-first.json').exists(),'FRESH_PREPARATION_FREEZE_REQUIRED');run(branch+'-freeze',[sys.executable,str(R/'freeze-current.py'),'--execute','--branch',branch])
  elif current=='run':
   previous_zero(branch+'-bind');previous_zero(branch+'-freeze');need(not (R/(branch+'-result')).exists(),'FRESH_ORIGINAL_RUNTIME_REPORT_ROOT_REQUIRED');run(branch+'-runtime',runtime_command(branch),tools_environment())
