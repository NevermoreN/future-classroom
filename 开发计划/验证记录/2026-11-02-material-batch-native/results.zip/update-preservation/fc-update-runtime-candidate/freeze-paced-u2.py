from pathlib import Path
import subprocess,json,hashlib,runpy
R=Path('/tmp/fc-update-runtime-candidate');main=Path.cwd();M=runpy.run_path('scripts/package-controlled-dev.py');dest=R/'u2-paced-source';assert not dest.exists();subprocess.run(['git','clone','--shared','--no-checkout',str(main),str(dest)],check=True)
for args in [['sparse-checkout','init','--cone'],['sparse-checkout','set','crates','scripts','web','packaging','.cargo'],['checkout','main']]:subprocess.run(['git','-C',str(dest),*args],check=True)
patch=subprocess.check_output(['git','diff','--binary']);subprocess.run(['git','-C',str(dest),'apply','--binary','-'],input=patch,check=True);inv=M['source_inventory'](dest);assert inv==M['source_inventory'](main);(R/'u2-paced-integrated.patch').write_bytes(patch)
(R/'u2-paced-source-freeze.json').write_text(json.dumps(dict(status='FROZEN_FINAL_SOURCE_ISOLATED_NATIVE_PROBE_16MS_ONLY_PRODUCTION1000MS_AND_180S_UNCHANGED',sourceRoot=str(dest),sourceHead=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),patchSha256=hashlib.sha256(patch).hexdigest(),inputCount=len(inv),inputs=inv),indent=2)+'\n')
s=(R/'build-normal-u2-tail.py').read_text().replace('normal-build-u2-tail','normal-build-u2-paced').replace('normal-evidence-u2-tail','normal-evidence-u2-paced');(R/'build-normal-u2-paced.py').write_text(s)
c=json.loads((R/'pair-tail.json').read_text());c['pair']='paced'
for role in ['u2','success','rollback']:
 for key,v in list(c[role].items()):
  if key!='branch':c[role][key]=v.replace('-tail','-paced')
(R/'pair-paced.json').write_text(json.dumps(c,indent=2)+'\n');print('FROZEN_EXACT_PACED_U2',len(inv))
