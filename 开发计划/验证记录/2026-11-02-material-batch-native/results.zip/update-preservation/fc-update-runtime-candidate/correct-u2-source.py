from pathlib import Path
import json,hashlib,runpy,difflib
r=Path('/tmp/fc-update-runtime-candidate');w=Path('/workspace/共享/Eliora/未来教室计划');d=r/'u2-source'
assert w!=d and json.loads((r/'normal-build-u2-second/terminal.json').read_bytes())['exit']==101
m=runpy.run_path(str(w/'scripts/package-controlled-dev.py'));old=m['source_inventory'](d);assert old==json.loads((r/'normal-build-u2/inputs-before.json').read_bytes());new=m['source_inventory'](w)
oldmap={x['path']:x for x in old};newmap={x['path']:x for x in new};changed=[n for n in oldmap if oldmap[n]!=newmap[n]]
allowed=['crates/fc-bootstrap/src/application/'+n+'.rs' for n in ['settings_registry','subject_visual_probe','public_desktop_probe','teacher_browser_probe','ordinary_https_probe']];assert set(changed)==set(allowed),changed
patch=''.join(''.join(difflib.unified_diff((d/n).read_text().splitlines(keepends=True),(w/n).read_text().splitlines(keepends=True),fromfile='a/'+n,tofile='b/'+n)) for n in changed);(r/'u2-source-correction.patch').write_text(patch)
for n in changed:(d/n).write_bytes((w/n).read_bytes())
assert m['source_inventory'](d)==new
(r/'u2-source-freeze-second.json').write_text(json.dumps(dict(status='EXACT_CORRECTED_U2_SOURCE_AFTER_ORIGINAL_COMPILE_101_REAPED',sourceHead=json.loads((r/'u2-source-freeze.json').read_bytes())['sourceHead'],firstTerminal='normal-build-u2/terminal.json',secondTerminal='normal-build-u2-second/terminal.json',changedFiles=changed,patchSha256=hashlib.sha256(patch.encode()).hexdigest(),inputCount=len(new),inputs=new),indent=2)+'\n')
print(json.dumps(dict(corrected=len(changed),inputs=len(new))))
