from pathlib import Path
import json,runpy,subprocess,hashlib,time
R=Path('/tmp/fc-update-runtime-candidate');prior=json.loads((R/'failed-seed-cleanup-v2-result/report.json').read_bytes());assert prior['runtimeActualExit']==0 and prior['status'].startswith('PASS_');j=json.loads((R/'success-final-result/report.json').read_bytes());plan=json.loads((R/'success-final-input/artifact-manifest.json').read_bytes());m=runpy.run_path(str(R/'success-final/run-controlled-product.py'));c=dict(root=j['windowsRoot'],nonce=j['nonce'],sid=plan['expectedUserSid'],plan=plan);D=R/'failed-seed-cleanup-fresh-final';assert not D.exists();D.mkdir();rows=[]
def call(label,args,feed=None,timeout=45):
 t=time.monotonic();p=subprocess.run(args,input=feed,capture_output=True,timeout=timeout)
 for ext,raw in [('stdout.log',p.stdout),('stderr.log',p.stderr)]: (D/(label+'.'+ext)).write_bytes(raw)
 if feed is not None:(D/(label+'.stdin.ps1')).write_bytes(feed)
 rows.append(dict(label=label,exit=p.returncode,parentReaped=True,seconds=time.monotonic()-t));assert p.returncode==0;return p.stdout
args,feed=m['remote'](m['INVENTORY'],c);inv=json.loads(call('inventory',args,feed).decode('utf-8-sig'));m['validate_inventory'](inv);(D/'inventory.json').write_text(json.dumps(inv,indent=2)+'\n')
download=D/'download';download.mkdir();call('download',['scp','-q','-r','-o','BatchMode=yes','future-classroom-win11:'+c['root'].replace('\\','/'),str(download)],timeout=60);local=download/c['root'].replace('\\','/').rsplit('/',1)[-1];files={};dirs=[]
for p in local.rglob('*'):
 assert not p.is_symlink();name=p.relative_to(local).as_posix()
 if p.is_dir():dirs.append(name)
 else:files[name]=(p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
assert files=={x['path']:(x['bytes'],x['sha256']) for x in inv['files']} and set(dirs)==set(inv['directories'])
pre=(R/'success-final/sources/ReadOnlyPreflightFunction.ps1').read_text()+"$v=Measure-FcBeforePreflight -Config $c.plan;Need ($v.status-ceq'PASS_BEFORE_KNOWN_ABSENCE_ONLY_NOT_EXECUTION_ADMISSION') 'ALL_REAL_PRODUCT_RUN_AND_DATA_ABSENT_AFTER_FORMAL_CLEANUP';$v|ConvertTo-Json -Depth 18 -Compress"
args,feed=m['remote'](pre,c);absence=json.loads(call('preflight',args,feed).decode('utf-8-sig'));c['inventory']=inv;args,feed=m['remote'](m['DELETE'],c);deleted=json.loads(call('delete',args,feed).decode('utf-8-sig'));assert deleted['knownAbsent']
out=dict(status='PASS_FAILED_SEED_FORMAL_CLEANUP_AND_FRESH_EXACT_SCRATCH_REMOVAL',originalFailureUnchanged=True,schoolDataPreservation='NOT_RUN_NOT_CLAIMED',databaseOrDpapiBytesCaptured=False,manualCleanupReport=str(R/'failed-seed-cleanup-v2-result/report.json'),freshByteReplay=dict(files=len(files),directories=len(dirs)),productRunDataAbsent=absence,scratchDeletion=deleted,operations=rows);(R/'failed-seed-manual-cleanup.json').write_text(json.dumps(out,indent=2)+'\n');print(out['status'])
