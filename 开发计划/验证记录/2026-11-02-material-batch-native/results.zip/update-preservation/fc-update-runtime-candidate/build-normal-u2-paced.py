from pathlib import Path
import subprocess,os,json,time,runpy,shutil,sys,hashlib
R=Path('/tmp/fc-update-runtime-candidate');D=R/'normal-build-u2-paced';assert not D.exists();D.mkdir();(D/'.owner').write_text('future-classroom-current-normal-compile/v1\n');source=Path.cwd();M=runpy.run_path('scripts/package-controlled-dev.py')
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def inventory():return M['source_inventory'](source)
def fact(p):return dict(path=p.relative_to(R).as_posix(),**M['fact'](p))
env=os.environ.copy();removed=[k for k in list(env) if k.startswith('CARGO_PROFILE_RELEASE_') or k in ['FC_OWNED_REMOVAL_SCOPE_HEX','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']]
for k in removed:env.pop(k,None)
# Explicitly removed even when inherited environment never contained it.
if 'FC_OWNED_REMOVAL_SCOPE_HEX' not in removed:removed.append('FC_OWNED_REMOVAL_SCOPE_HEX')
env.update(CARGO_TARGET_DIR=str(R/'normal-target-u2'),CARGO_PROFILE_RELEASE_STRIP='symbols',CARGO_TARGET_I686_PC_WINDOWS_GNU_RUSTFLAGS='-C target-feature=+crt-static -C link-arg=-Wl,--major-subsystem-version,6,--minor-subsystem-version,1');assert 'FC_OWNED_REMOVAL_SCOPE_HEX' not in env
before=D/'inputs-before.json';save(before,inventory());head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
report=dict(status='RUNNING_NORMAL_ORIGINAL_CONTROLLER',target='i686-pc-windows-gnu',source_root=str(source),source_head=head,formal_ci=False,lifecycle_mode='ABI2_UPDATE_DATA_CURRENT_NORMAL_GNU_DEV',environment={'CARGO_TARGET_DIR':env['CARGO_TARGET_DIR'],'CARGO_PROFILE_RELEASE_STRIP':'symbols','CARGO_TARGET_I686_PC_WINDOWS_GNU_RUSTFLAGS':env['CARGO_TARGET_I686_PC_WINDOWS_GNU_RUSTFLAGS']},removed_environment_keys=removed,inputs_before=fact(before),commands=[])
def call(name,argv):
 out=D/(name+'.stdout.jsonl');err=D/(name+'.stderr.log');t=time.monotonic()
 with out.open('wb') as o,err.open('wb') as e:p=subprocess.Popen(argv,env=env,stdout=o,stderr=e);save(D/'active.json',dict(pid=p.pid,name=name,argv=argv));rc=p.wait()
 row=dict(name=name,argv=argv,actual_exit=rc,parent_reaped=True,timed_out=False,stdout=fact(out),stderr=fact(err),seconds=time.monotonic()-t);print(json.dumps({k:row[k] for k in ['name','actual_exit','seconds']}),flush=True)
 if rc:report['failure']=row;save(D/'report.json',report);save(D/'terminal.json',dict(exit=rc));sys.exit(rc)
 return row
meta=call('metadata',['cargo','metadata','--locked','--format-version','1','--no-deps']);report['metadata']=meta['stdout'];report['metadata_command']=meta
for name,pkg,selector in [('product-compile','fc-bootstrap',['--bin','fc-bootstrap']),('lifecycle-compile','fc-bootstrap',['--bin','fc-installer-lifecycle']),('guard-library-compile','fc-windows',['--lib'])]:
 argv=['cargo','build','-p',pkg,*selector,'--release','--locked','--target','i686-pc-windows-gnu','--message-format=json'];row=call(name,argv)
 target,leaf=M['ROLES'][name][1:];messages=[json.loads(s) for s in (R/row['stdout']['path']).read_text().splitlines() if s.startswith('{')];selected=[d for d in messages if d.get('reason')=='compiler-artifact' and d.get('target',{}).get('name')==target];assert len(selected)==1 and not selected[0]['profile']['test']
 d=selected[0];paths=[Path(x) for x in d['filenames'] if Path(x).name==leaf] if name=='guard-library-compile' else [Path(d['executable'])];assert len(paths)==1
 copy=D/leaf;shutil.copyfile(paths[0],copy);row['artifact']=fact(copy);row['selected_artifact_fresh']=d['fresh'];report['commands'].append(row);save(D/'report.json',report)
after=D/'inputs-after.json';save(after,inventory());assert before.read_bytes()==after.read_bytes();report['inputs_after']=fact(after);report['status']='DEV_FROZEN_NORMAL_BUILD_ONLY';save(R/'normal-evidence-u2-paced.json',report);save(D/'terminal.json',dict(exit=0,sourceUnchanged=True));print(json.dumps(dict(status=report['status'],normalArtifacts=3)))
