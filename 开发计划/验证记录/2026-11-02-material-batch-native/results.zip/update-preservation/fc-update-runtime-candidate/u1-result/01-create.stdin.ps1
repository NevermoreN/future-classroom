$c='{"nonce":"9ca1e8d2e5574bac9fdda84b0d84e53a","sid":"S-1-5-21-3896111207-1867804362-1971593122-1001","plan":{"status":"BOUND_GNU_ABI2_UPGRADE_U1_PRODUCT_INPUTS_NOT_RELEASE","sourceGit":"b39c0aab7625cf58edcf720396fdba7950400649","sourceRoot":"/tmp/fc-update-runtime-candidate/u1-source","target":"i686-pc-windows-gnu","family":"99378807-098D-5F04-8D4D-F181DFA218D5","productCode":"{D420EDE5-0584-5FDC-8DE8-F25905018A0A}","packageCode":"3CE52DDC-A35C-43F1-9DCE-229D727CA017","version":"0.2.0","expectedUserSid":"S-1-5-21-3896111207-1867804362-1971593122-1001","guardABI":2,"normalProfileTest":false,"formalCI":false,"lifecycleMode":"ABI2_UPDATE_DATA_CURRENT_NORMAL_GNU_DEV","sourceEvidenceSha256":"777e89db50fb2f2732751c29c131795bf6ad0c6b516914b1f73981c742dc4b59","guardAction":"FcControlledInnerGuard","payloads":[{"path":"LICENSE","size":1067,"sha256":"1fef5a26bc7b7bf66e38e83ac8d246a54e2e4e3d62fcfcb416d4db77603b2e40","component_guid":"BF8ECC92-DF5E-5031-AF8F-B122A05E64E6"},{"path":"MSI-CANDIDATE.txt","size":1784,"sha256":"5995cd920d173e401a7767f2a86974d28b65b0927e866882aa39a8227d9d7634","component_guid":"00CBA46A-3182-5F3E-A3C2-3B4D08BF8FCC"},{"path":"PROBE-README.txt","size":21767,"sha256":"7ebdcc9f18d6f0c1f9d2471f7b496f317e1ac5797264940b0f95be1945f64e09","component_guid":"1F2DCDC9-9F80-51BE-A10D-F294D45FDB05"},{"path":"THIRD-PARTY-NOTICES.txt","size":2401720,"sha256":"b611a4c99e2f65d2c5c2f1618f088dec978cab792cbdef2810937cc60d7ed6b0","component_guid":"44E7E505-D3CB-5DC8-9730-50964BA3CC8C"},{"path":"fc-bootstrap.exe","size":12651520,"sha256":"17ec1d732881b9e6e54364de0833906af688fe23e633f492e816fdfefe0cfb47","component_guid":"0CA01C62-B71F-5C57-905B-B6C979ACB487"},{"path":"manifest.json","size":34953,"sha256":"cdb1deb4abe9927d1501d2d36f4ba03d01b0eb3b741b2acd575f202decba09e5","component_guid":"8D7F75D1-8AD6-5097-AEE4-62389B788737"},{"path":"web/THIRD-PARTY-NOTICES.txt","size":25543,"sha256":"67cdd6d8f98149012bd01d11eeb5b1c2942298c26c043db461301a8b64b875e7","component_guid":"51201E26-0CF3-5876-A591-91F68B3A94DB"},{"path":"web/assets/favicon-CXuYoSfB.svg","size":282,"sha256":"46593a2ec46a77d65026d609dcd5630c447360522518d745458091a9df2f7f8a","component_guid":"D0B2E913-0457-5E64-A66B-EC1EE7DA7138"},{"path":"web/assets/index-DKzeA0_r.js","size":444691,"sha256":"0cee896613d87fb523c22aae77b23bc9cbfe19796fe1b9abbf6c67d9ab47ac49","component_guid":"0193B4F4-C1B0-5A42-BA90-D7B7178D365A"},{"path":"web/assets/index-DrrJeLm9.css","size":39554,"sha256":"fd6d963cdb889b3bffdebf631c310d869730a56474a389351fd7bdf49bdf385f","component_guid":"B9ADCF83-BCB1-5F42-97D8-967FF84A306F"},{"path":"web/assets/pcm-worklet-B7E4LRoP.js","size":1724,"sha256":"9934c276d98e30992dc8148ffc3a0dfdc178fed9aacbb8227255bede45c1fcfa","component_guid":"28DB1C02-71DB-5DAF-8D0C-9844E24D16DC"},{"path":"web/assets/wav-worker-LSywWbpJ.js","size":884,"sha256":"a0e364aa7c0d888d0f7118b86d873c95df95e461303546a8ad1d56d5038e1886","component_guid":"C0EC8190-410A-52A3-895E-AD6564B75C1E"},{"path":"web/fc-assets.json","size":1073,"sha256":"56dba719eb424d35850bfbcaf6cafa966909f59eaada98315f037fac669420af","component_guid":"0C6686BF-2327-51F5-89A6-4243C1FD11CF"},{"path":"web/index.html","size":1232,"sha256":"fe5d78798a26d7ff75781858e80a8ddf1af2c28f3d6a9c9ef610f90ea1aab3be","component_guid":"58B108D4-3264-56B1-9DE5-19636D8437E2"}],"msi":{"path":"/tmp/fc-update-runtime-candidate/u1-package/FutureClassroom.msi","bytes":11563008,"sha256":"3428393a2ec3673ed4aa3d03ea5bfb8a12691f85c741e51692cbeb0bb749535a"},"setup":{"path":"/tmp/fc-update-runtime-candidate/u1-package/Setup.exe","bytes":777348,"sha256":"fed9642934b33b55a936306a80efb820fc6355b552732193a1cdbfd9f4de15be"},"packageReport":{"path":"/tmp/fc-update-runtime-candidate/u1-package/report.json","bytes":77056,"sha256":"8079efce4fad1032e917a98f9e561d9569a1192404f5010aa7cee851ddcce0a3"},"packageBuilder":{"path":"/tmp/fc-update-runtime-candidate/package-current-u1.py","bytes":24153,"sha256":"c8b2de2b4701d2199f775675b37e435e55699920bb4916765af91833bd3b2457"},"registryMarkerKey":"Software\\FutureClassroom\\Installer\\Components","runKey":"Software\\Microsoft\\Windows\\CurrentVersion\\Run","runValue":"FutureClassroom","registryView":"Registry32","fixedDestinationKnownFolderSuffix":["Programs","FutureClassroom"],"sourceManifest":{"path":"/tmp/fc-update-runtime-candidate/u1-input/source-manifest.json","bytes":114232,"sha256":"9faf554136edf99ae0a24090ef49179966f6c285359aee9b5fa5ee49a073c249"}},"root":null}'|ConvertFrom-Json;
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Need([bool]$v,[string]$code){if(-not$v){throw $code}}
function Fact([string]$p){$f=Get-Item -LiteralPath $p -Force;Need (-not$f.PSIsContainer -and ($f.Attributes-band1024)-eq0) 'REGULAR_NO_REPARSE';return @{bytes=[long]$f.Length;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function RootPath {return Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) ('Temp\FutureClassroom-update-data-u1-qualification-controlled-product-'+$c.nonce)}
function CheckRoot([string]$root){Need ($root-ceq$c.root -and $root-ceq(RootPath)) 'EXACT_NONCE_ROOT';$a=[IO.File]::GetAttributes($root);Need (($a-band1024)-eq0 -and ($a-band16)-ne0) 'REGULAR_ROOT';Need ([IO.File]::ReadAllText((Join-Path $root '.owner'))-ceq"future-classroom-owned-update-data-u1-qualification-controlled-product-runtime/v1`n") 'OWNER';$acl=[IO.Directory]::GetAccessControl($root);Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq$c.sid) 'PROTECTED_ROOT_OWNER';$rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($rules.Count-eq2 -and @($rules|Where-Object{$_.IdentityReference.Value-cnotin@($c.sid,'S-1-5-18') -or $_.AccessControlType-ne'Allow' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count-eq0) 'ONLY_USER_SYSTEM_DACL'}
function Inventory([string]$root){CheckRoot $root;$files=@();$dirs=@();$q=[Collections.Generic.Queue[string]]::new();$q.Enqueue($root);while($q.Count){$dir=$q.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){$a=[IO.File]::GetAttributes($p);Need (($a-band1024)-eq0) 'NO_INVENTORY_REPARSE';$rel=$p.Substring($root.Length+1).Replace('\','/');if(($a-band16)-ne0){$dirs+=$rel;$q.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256}};Need ($files.Count-le256 -and $dirs.Count-le32) 'INVENTORY_BOUNDS'}};return @{files=$files;directories=$dirs}}
# TEST INSTRUMENT PREPARATION ONLY. Dot-source defines one function; no top-level side effects.
function Measure-FcBeforePreflight {
    param([Parameter(Mandatory=$true)]$Config)
    $c=$Config
    $ErrorActionPreference='Stop'
    if($c.status-cne'BOUND_GNU_ABI2_UPGRADE_U1_PRODUCT_INPUTS_NOT_RELEASE' -or $c.sourceGit-cnotmatch'^[0-9a-f]{40}$' -or $c.target-cne'i686-pc-windows-gnu' -or $c.guardABI-ne2 -or $c.normalProfileTest-ne$false -or $c.formalCI-ne$false -or $c.lifecycleMode-cne'ABI2_UPDATE_DATA_CURRENT_NORMAL_GNU_DEV' -or $c.sourceEvidenceSha256-cnotmatch'^[0-9a-f]{64}$' -or $c.family-cne'99378807-098D-5F04-8D4D-F181DFA218D5'){throw 'EXACT_BOUND_SOURCE_TARGET_FAMILY_REQUIRED'}
    if($c.productCode-cne'{D420EDE5-0584-5FDC-8DE8-F25905018A0A}' -or $c.version-cne'0.2.0'){throw 'EXACT_U1_PRODUCT_VERSION'}
    function PathFact($path) {
        try {
            $a=[IO.File]::GetAttributes($path)
            return @{path=$path;status='PRESENT_REFUSE';isDirectory=(($a-band[IO.FileAttributes]::Directory)-ne 0);isReparse=(($a-band[IO.FileAttributes]::ReparsePoint)-ne 0)}
        } catch {
            $e=$_.Exception;while($null-ne$e.InnerException){$e=$e.InnerException}
            if($e-is[IO.FileNotFoundException] -or $e-is[IO.DirectoryNotFoundException]){return @{path=$path;status='KNOWN_ABSENT'}}
            return @{path=$path;status='UNKNOWN_REFUSE';exceptionKind=$e.GetType().FullName;hresult=$e.HResult}
        }
    }
    function Registration {
        $i=$null;$products=$null;$related=$null
        try {
            $i=New-Object -ComObject WindowsInstaller.Installer
            $products=$i.GetType().InvokeMember('ProductsEx',[Reflection.BindingFlags]::GetProperty,$null,$i,@($c.productCode,'',7))
            $n=$products.GetType().InvokeMember('Count',[Reflection.BindingFlags]::GetProperty,$null,$products,@())
            $state=$i.GetType().InvokeMember('ProductState',[Reflection.BindingFlags]::GetProperty,$null,$i,@($c.productCode))
            $related=$i.GetType().InvokeMember('RelatedProducts',[Reflection.BindingFlags]::GetProperty,$null,$i,@('{'+$c.family+'}'))
            $rn=$related.GetType().InvokeMember('Count',[Reflection.BindingFlags]::GetProperty,$null,$related,@())
            if($n-isnot[Int32] -or $rn-isnot[Int32] -or $n-lt 0 -or $rn-lt 0){throw 'ACTUAL_COM_COUNT_TYPE_OR_RANGE'}
            return @{contexts=7;sidArgument='';otherUsers='NOT_QUERIED';product=$c.productCode;relatedFamily=$c.family;count=$n;state=$state;relatedCount=$rn;knownAbsent=($n-eq 0 -and $state-eq -1 -and $rn-eq 0)}
        } finally {
            foreach($o in @($related,$products,$i)){if($null-ne$o){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($o)}}
        }
    }
    $who=[Security.Principal.WindowsIdentity]::GetCurrent()
    try{$sid=$who.User.Value}finally{$who.Dispose()}
    if($sid-cne$c.expectedUserSid){throw 'EXACT_EXPECTED_CURRENT_USER_SID'}
    $local=[Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)
    if([string]::IsNullOrEmpty($local) -or -not [IO.Path]::IsPathRooted($local)){throw 'OS_KNOWN_FOLDER_UNAVAILABLE'}
    $target=Join-Path $local 'Programs\FutureClassroom'
    $gate=Join-Path $local ('FutureClassroom-Installer-'+$c.family)
    $programData=[Environment]::GetFolderPath([Environment+SpecialFolder]::CommonApplicationData);if([string]::IsNullOrEmpty($programData)){throw 'PROGRAMDATA_KNOWN_FOLDER_REQUIRED'};$paths=@((PathFact $target),(PathFact $gate),(PathFact (Join-Path $programData 'FutureClassroom')))
    # An existing gate, even an apparently empty/released one, is not adopted for a
    # fresh production experiment. Unknown is never converted to absence.
    $base=$null;$marker=$null;$run=$null
    try {
        $base=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry32)
        $marker=$base.OpenSubKey('Software\FutureClassroom\Installer\Components',$false)
        $markers=@{view='Registry32';key='Software\FutureClassroom\Installer\Components';knownAbsent=($null-eq$marker)}
        $run=$base.OpenSubKey('Software\Microsoft\Windows\CurrentVersion\Run',$false)
        $runAbsent=$true
        if($null-ne$run){$sentinel=[Object]::new();$value=$run.GetValue('FutureClassroom',$sentinel,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames);$runAbsent=[Object]::ReferenceEquals($sentinel,$value);$value=$null}
        # Only the fixed project value is queried; no other startup data is dumped.
        $runFact=@{view='Registry32';value='FutureClassroom';knownAbsent=$runAbsent;writePerformed=$false;contentsRetained=$false}
        $registration=Registration
    } finally {
        foreach($key in @($run,$marker,$base)){if($null-ne$key){$key.Dispose()}}
    }
    $pass=(@($paths|Where-Object{$_.status-cne'KNOWN_ABSENT'}).Count-eq 0 -and $markers.knownAbsent -and $runFact.knownAbsent -and $registration.knownAbsent)
    return @{status=$(if($pass){'PASS_BEFORE_KNOWN_ABSENCE_ONLY_NOT_EXECUTION_ADMISSION'}else{'REFUSE_PREEXISTING_OR_UNKNOWN_NO_MUTATION'});sourceGit=$c.sourceGit;target=$c.target;currentUserSid=$sid;localKnownFolder=$local;fixedPaths=$paths;componentMarkers=$markers;run=$runFact;registration=$registration;mutations=$false;normalRustHelper='NOT_EXECUTED';productMSI='NOT_EXECUTED';scope='Current authorized admin Win11 only; other users/cache/school data not queried; candidate helper independently rechecks under original native owner.'}
}
$start=[Diagnostics.Stopwatch]::GetTimestamp();$frequency=[Diagnostics.Stopwatch]::Frequency
Need ($PSVersionTable.PSVersion.Major-eq5 -and $PSVersionTable.PSVersion.Minor-eq1 -and [IntPtr]::Size-eq8) 'PS51_X64'
$who=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$who.User;Need ($sid.Value-ceq$c.sid) 'CURRENT_SID'}finally{$who.Dispose()}
$before=Measure-FcBeforePreflight -Config $c.plan;Need ($before.status-ceq'PASS_BEFORE_KNOWN_ABSENCE_ONLY_NOT_EXECUTION_ADMISSION') 'ALL_KNOWN_ABSENT_BEFORE_ROOT'
$root=RootPath;try{[void][IO.File]::GetAttributes($root);throw 'ROOT_ALREADY_PRESENT'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
$cursor=[IO.Path]::GetDirectoryName($root);while($cursor){$a=[IO.File]::GetAttributes($cursor);Need (($a-band1024)-eq0 -and ($a-band16)-ne0) 'ORIGINAL_NONREPARSE_ANCESTORS';$cursor=[IO.Path]::GetDirectoryName($cursor)}
[void][IO.Directory]::CreateDirectory($root);$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false);foreach($s in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($s,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))};[IO.Directory]::SetAccessControl($root,$acl);[IO.File]::WriteAllText((Join-Path $root '.owner'),"future-classroom-owned-update-data-u1-qualification-controlled-product-runtime/v1`n",[Text.UTF8Encoding]::new($false));$c.root=$root;CheckRoot $root
@{status='CREATED_ONLY_OWNED_GNU_ABI2_SAME_PACKAGE_MAINTENANCE_PRODUCT_RUNTIME_ROOT';root=$root;sid=$c.sid;nonce=$c.nonce;before=$before;originalStartQpc=$start;originalFrequency=$frequency}|ConvertTo-Json -Depth 18 -Compress
