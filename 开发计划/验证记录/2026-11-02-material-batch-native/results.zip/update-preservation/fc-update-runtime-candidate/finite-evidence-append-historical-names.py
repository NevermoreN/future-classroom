#!/usr/bin/env python3
"""Finite text-only append to the historical three-file evidence; default inert."""
import argparse, hashlib, io, json, os, re, stat, sys, zipfile
from pathlib import Path, PurePosixPath
sys.dont_write_bytecode = True
P = Path('/tmp/fc-update-evidence-candidate')
OLD = Path('/workspace/共享/Eliora/未来教室计划/开发计划/验证记录/2026-11-02-material-batch-native')
ROOTS = {n: Path('/tmp') / n for n in ('fc-update-run-candidate', 'fc-update-data-candidate', 'fc-update-runtime-candidate', 'fc-subject-disable-candidate', 'fc-subject-probes-candidate', 'fc-app-probe-candidate', 'fc-update-subject-text-fix')}
SCANNER_SHA = 'da2906c450ea8c2ac7d18e358507023f519dbcc6faf1a9ac1abb1ae16af8c30f'
OLD_ZIP_SHA = '5ac99a25f899a2b1b6d00da3d2d7ac4691e49cdb4ab8cf8595daccd6de05061e'
CAP_FILES, CAP_BYTES = 1500, 30 * 1024 * 1024
SUFFIXES = {'.json', '.jsonl', '.log', '.py', '.ps1', '.rs', '.cs', '.md', '.txt', '.patch', '.wxs', '.idt', '.stderr', '.stdout'}
DENY_PARTS = {'.git', 'target', 'deps', 'node_modules', 'node', 'dist', '__pycache__', 'upload', 'extracted', 'payload', 'Binary', 'lifecycle', 'baseline', 'source', 'u1-source', 'web-source', 'u1-input-stage'}
DENY_WORDS = ('private-key', 'private_key', 'id_ed25519', 'id_rsa', 'dpapi', '.sqlite', '.db', '.pfx', '.p12', '.pem', '.key', 'scope.hex', 'scope.bin')
STATS = ('textViews', 'utf16Views', 'cp936Views', 'clixmlDecodedViews', 'decodedBase64Views', 'jsonContainers', 'decodedJsonStringViews')
def need(v, code):
    if not v: raise AssertionError(code)
def sha(b): return hashlib.sha256(b).hexdigest()
def encoded(v): return (json.dumps(v, ensure_ascii=False, indent=2) + '\n').encode()
def canonical(name):
    p = PurePosixPath(name)
    need(not p.is_absolute() and name == p.as_posix() and name and '..' not in p.parts and '\\' not in name, 'CANONICAL_MEMBER')
    need(all(ord(c) >= 32 for c in name), 'PATH_CONTROLS')
    return p

def original(row):
    root = ROOTS[row['root']]
    rel = canonical(row['path'])
    if row['root'] == 'fc-update-subject-text-fix':
        need(str(rel) in {'HANDOFF.txt', 'update-subject-text-and-quiet-trace.patch', 'baseline-sha256.json', 'candidate-sha256.json'}, 'EXACT_SUBJECT_TEXT_FOUR_FILE_SCOPE')
    if row['root'] == 'fc-app-probe-candidate':
        need(str(rel) in {'HANDOFF.txt', 'application-probe-explicit-read.patch', 'baseline-sha256.json', 'candidate-sha256.json'}, 'EXACT_APP_PROBE_FOUR_FILE_SCOPE')
    need(not any(v in DENY_PARTS or 'target' in v.lower() for v in rel.parts), 'FORBIDDEN_SUBTREE')
    need(not any(v in str(rel).lower() for v in DENY_WORDS), 'FORBIDDEN_SENSITIVE_PATH')
    public_manifest = (row['root'] == 'fc-update-runtime-candidate' and len(rel.parts) == 4 and rel.parts[0] in {'success-paced-result', 'rollback-paced-result'} and rel.parts[1] == 'download' and rel.name in {'data-0-seed.manifest', 'data-1-verify.manifest', 'data-2-disable.manifest'})
    need((Path(str(rel)).suffix.lower() in SUFFIXES or public_manifest) and not rel.name.startswith('binary-'), 'EXPLICIT_TEXT_EXTENSION_ONLY')
    p = root.joinpath(*rel.parts)
    for parent in (p, *p.parents):
        if parent == root or parent.is_relative_to(root): need(not parent.is_symlink(), 'NO_LINK_SOURCE')
    st = p.stat(); need(stat.S_ISREG(st.st_mode) and st.st_size <= 8 * 1024 * 1024, 'BOUNDED_REGULAR_TEXT')
    b = p.read_bytes()
    need(len(b) == row['bytes'] and sha(b) == row['sha256'], 'EXACT_FROZEN_SELECTION_BYTES')
    if public_manifest:
        need(len(b) <= 8192 and b.startswith(b'FC_UPDATE_DATA_V1\n') and b.decode('ascii').encode('ascii') == b, 'EXACT_PUBLIC_UPDATE_HASH_MANIFEST_TEXT')
    need(not b.startswith((b'MZ', b'PK\x03\x04', b'\xd0\xcf\x11\xe0', b'\x7fELF', b'SQLite format 3\0')), 'BINARY_CONTENT_REJECTED')
    member = 'update-preservation/' + row['root'] + '/' + rel.as_posix()
    need(row['member'] == member, 'EXACT_ORIGINAL_MEMBER_MAPPING')
    return b

def reviewed_derived_views(data, label, row):
    need(label is not None and label == row['label'], 'EXACT_REVIEWED_DERIVED_LABEL')
    need(len(data) == row['bytes'] and sha(data) == row['sha256'], 'EXACT_REVIEWED_DERIVED_BYTES')
    kind = row['textForm']
    if kind == 'EXACT_OWNED_RUN_REG_SZ_UTF16LE_SINGLE_TERMINAL_NUL':
        need(len(data) == 170 and sha(data) == '82e6b2c5867b7773158c2f79172e2bda3d5abfc6ea0ca3c2808d08f87079268d', 'FIXED_OBSERVED_RUN_BYTES')
        text = data.decode('utf-16-le')
        need(text.encode('utf-16-le') == data and len(data) // 2 <= 260, 'REG_SZ_EXACT_UTF16LE_ROUNDTRIP_BOUND')
        need(text.endswith(chr(0)) and text.count(chr(0)) == 1, 'ONLY_SINGLE_TERMINAL_REG_SZ_NUL')
        need(text == '"C:\\Users\\Elior\\AppData\\Local\\Programs\\FutureClassroom\\fc-bootstrap.exe" --autostart\x00', 'EXACT_FIXED_INSTALLED_BOOTSTRAP_COMMAND')
        control, encoding = chr(0), 'utf16-reviewed-owned-run-reg-sz'
    elif kind == 'EXACT_MSI_OLE_SUMMARY_INFORMATION_ARGV':
        need(len(data) == 19 and sha(data) == 'a2a4382df0ecfdc0fa1ddcd28a00693fe310ea8de404e46d8800ad956c37decc', 'FIXED_OBSERVED_OLE_ARGV_BYTES')
        text = data.decode('utf-8')
        need(text.encode() == data and text == chr(5) + 'SummaryInformation', 'EXACT_FIXED_PUBLIC_OLE_SUMMARY_STREAM_LITERAL')
        control, encoding = chr(5), 'utf8-reviewed-msi-ole-summary-argv'
    else:
        raise AssertionError('UNKNOWN_REVIEWED_DERIVED_FORM')
    need(not any(ord(c) < 32 and c not in (chr(13), chr(10), chr(9), control) for c in text), 'NO_OTHER_DERIVED_CONTROLS')
    return [(encoding, text), (encoding + '-visible-boundary', text.replace(control, '[U+%04X]' % ord(control))), (encoding + '-control-concatenated', text.replace(control, ''))]

def backend(forms, derived_forms=()):
    b = (P / 'scanner-frozen.py').read_bytes(); need(sha(b) == SCANNER_SHA, 'FROZEN_SCANNER')
    ns = {'__name__': 'finite_update_scanner'}; exec(compile(b, '<frozen-scanner>', 'exec'), ns)
    ns['TEXT_FORMS'] = {v['path']: v for v in forms}; ns['TEXT_DERIVED_VIEWS'] = {}
    need(len(ns['TEXT_FORMS']) == len(forms), 'UNIQUE_EXACT_TEXT_FORMS')
    derived = {row['label']: row for row in derived_forms}
    need(len(derived) == len(derived_forms) and all(label is not None for label in derived), 'UNIQUE_FINITE_DERIVED_LABELS')
    original_views = ns['text_views']
    def exact_views(data, label=None):
        row = derived.get(label)
        return original_views(data, label) if row is None else reviewed_derived_views(data, label, row)
    ns['text_views'] = exact_views
    return ns

def scan(ns, data, member, stats):
    findings = []
    ns['credential_scan'](data, 'source:' + member, stats, findings)
    if member.endswith('.jsonl'):
        for i, line in enumerate(data.splitlines()):
            if not line.strip(): continue
            need(i < 250000, 'JSONL_COUNT_BOUND'); json.loads(line)
            ns['credential_scan'](line, 'source:' + member + '::jsonl/' + str(i + 1), stats, findings)
    # Never print matching payload, token or secret values.
    need(not findings, 'CREDENTIAL_MATCH_STOP_PATH_KIND_ONLY:' + json.dumps(findings))

def execute(args):
    selection_raw = Path(args.selection).read_bytes(); selection = json.loads(selection_raw)
    approval_raw = Path(args.root_acceptance).read_bytes()
    need(sha(approval_raw) == args.root_acceptance_sha256, 'PINNED_ROOT_FINAL_ACCEPTANCE')
    approval = json.loads(approval_raw)
    need(approval['status'] == 'PASS_FINAL_ROOT_UPDATE_EVIDENCE_ACCEPTANCE', 'WAIT_ROOT_FINAL_UPDATE_ACCEPTANCE')
    need(approval['selectionSha256'] == sha(selection_raw), 'ROOT_ACCEPTS_EXACT_SELECTION')
    need(approval['controllersTerminal'] is True and approval['upgradeAndRollbackTerminal'] is True, 'WAIT_U2_UPGRADE_ROLLBACK_TERMINAL')
    rows = selection['originals']; references = selection.get('alreadyArchivedReferences', [])
    all_rows = rows + references
    need(len(all_rows) <= CAP_FILES and len(all_rows) == len({r['member'] for r in all_rows}), 'UNIQUE_FINITE_ADDITIONS_AND_REFERENCES')
    need(all(isinstance(r['bytes'], int) and 0 <= r['bytes'] <= 8 * 1024 * 1024 for r in all_rows) and sum(r['bytes'] for r in all_rows) <= CAP_BYTES, 'BOUNDED_SELECTED_SIZES')
    need(966 + len(rows) <= CAP_FILES and 14030219 + sum(r['bytes'] for r in rows) <= CAP_BYTES, 'PRECHARGE_1500_MEMBERS_30MIB_BEFORE_READING')
    old_raw = (OLD / 'results.zip').read_bytes(); need(sha(old_raw) == OLD_ZIP_SHA, 'EXACT_HISTORICAL_ZIP')
    old_summary_raw = (OLD / 'summary.json').read_bytes(); old_readme = (OLD / 'README.md').read_bytes()
    need(sha(old_summary_raw) == selection['historical']['summarySha256'] and sha(old_readme) == selection['historical']['readmeSha256'], 'HISTORICAL_THREE_FILE_BINDING')
    old_summary = json.loads(old_summary_raw)
    payload = {}; ns = backend(selection.get('textForms', []), selection.get('reviewedDerivedViews', [])); stats = dict.fromkeys(STATS, 0)
    for row in rows:
        b = original(row); scan(ns, b, row['member'], stats); payload[row['member']] = b
    reference_bytes = {}
    for row in references:
        b = original(row); scan(ns, b, row['member'], stats); reference_bytes[row['member']] = b
    with zipfile.ZipFile(io.BytesIO(old_raw)) as z:
        infos = z.infolist(); need(len(infos) == 966 and sum(i.file_size for i in infos) == 14030219, 'HISTORICAL_966_BOUNDARY')
        old_members = {}
        for i in infos:
            # Preserve three pinned old Windows download names literally; no extraction.
            historical_literal_names = {'teacher-web/browser/runtime-fifth.json.browser-edge-owner-FutureClassroom-Test-Browser-6e6f194d79e940f3a87e10f0f6fa8f7d-raw/downloads\\ef9190bf-05d2-4af1-91c6-fe9afa95f95d': (45, 'e2c1d62a10119d6340c861a2fdb0b8e3e2bd72556155149c88a33e0ec168f5b9'), 'teacher-web/browser/runtime-fourth.json.browser-edge-owner-FutureClassroom-Test-Browser-a4a74ebb90fd4bbaab4d3a7fdb24d3c0-raw/downloads\\b7aa702a-9ef2-4f99-bf06-2ee8f6e79f54': (45, 'e2c1d62a10119d6340c861a2fdb0b8e3e2bd72556155149c88a33e0ec168f5b9'), 'teacher-web/browser/runtime-third.json.browser-edge-owner-FutureClassroom-Test-Browser-4b9af8d274484ed98b394175c1dc2931-raw/downloads\\45c9c9bb-c026-469d-ab1a-da8eab76c364': (45, 'e2c1d62a10119d6340c861a2fdb0b8e3e2bd72556155149c88a33e0ec168f5b9')}
            if i.filename in historical_literal_names:
                need((i.file_size, sha(z.read(i))) == historical_literal_names[i.filename], 'EXACT_THREE_HISTORICAL_LITERAL_WINDOWS_NAMES')
            else:
                canonical(i.filename)
            need(not i.is_dir() and i.filename not in old_members and not stat.S_ISLNK(i.external_attr >> 16), 'HISTORICAL_REGULAR_UNIQUE')
            need(i.filename not in payload, 'NO_OVERWRITE_HISTORICAL_MEMBER')
            old_members[i.filename] = z.read(i)
    for row in references:
        if 'historicalMember' in row:
            need(row['historicalMember'] in old_members and old_members[row['historicalMember']] == reference_bytes[row['member']], 'ALREADY_ARCHIVED_REFERENCE_COMPLETE_BYTE_EQUAL')
        else:
            need(row['selectedMember'] in payload and payload[row['selectedMember']] == reference_bytes[row['member']], 'SELECTED_REFERENCE_COMPLETE_BYTE_EQUAL_NO_SECOND_MEMBER')
    need(len(old_members) + len(payload) <= CAP_FILES and sum(map(len, old_members.values())) + sum(map(len, payload.values())) <= CAP_BYTES, '1500_MEMBERS_30MIB_UNCOMPRESSED_CAP')
    out = Path(args.output).absolute(); need(out.parent == P and not out.exists(), 'NEW_EXTERNAL_STAGING_ONLY')
    need(not out.is_symlink(), 'NO_OUTPUT_LINK'); out.mkdir()
    try:
        zip_path = out / 'results.zip'
        with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
            for i in infos: z.writestr(i, old_members[i.filename])
            for member, b in sorted(payload.items()): z.writestr(member, b)
        with zipfile.ZipFile(zip_path) as z:
            need(len(z.infolist()) == len(old_members) + len(payload), 'FULL_REPLAY_EXACT_COUNT')
            need(set(z.namelist()) == set(old_members) | set(payload), 'FULL_REPLAY_EXACT_MEMBER_DOMAIN')
            for member, b in old_members.items(): need(z.read(member) == b, 'HISTORICAL_MEMBER_FULL_BYTE_REPLAY')
            for member, b in payload.items():
                replay = z.read(member); need(replay == b, 'NEW_MEMBER_FULL_BYTE_REPLAY'); scan(ns, replay, member, stats)
        summary = dict(old_summary)
        summary['updatePreservation'] = {'status': 'PASS_FINITE_APPEND_FULL_BYTE_REPLAY_AND_CREDENTIAL_SCAN', 'rootFinalAcceptance': {'bytes': len(approval_raw), 'sha256': sha(approval_raw), 'facts': approval['qualification']}, 'selectionSha256': sha(selection_raw), 'historicalZip': {'members': 966, 'bytes': len(old_raw), 'sha256': OLD_ZIP_SHA}, 'originals': rows, 'alreadyArchivedReferences': references, 'scanner': {'sha256': SCANNER_SHA, 'source': 'R79 exact archived scanner; identical to historical native scanner', 'statistics': stats, 'findings': 0, 'textForms': selection.get('textForms', []), 'reviewedDerivedViews': selection.get('reviewedDerivedViews', []), 'appendWrapperSha256': sha(Path(__file__).read_bytes())}, 'scope': 'Finite update/Run/data-preservation and subject-flow evidence; actual report statuses preserved, not complete product/platform delivery.'}
        raw_zip = zip_path.read_bytes()
        summary['archive'] = {'file': 'results.zip', 'bytes': len(raw_zip), 'sha256': sha(raw_zip), 'members': len(old_members) + len(payload), 'uncompressedBytes': sum(map(len, old_members.values())) + sum(map(len, payload.values())), 'limits': {'members': CAP_FILES, 'uncompressedBytes': CAP_BYTES}, 'fullReplay': 'PASS_ALL_966_HISTORICAL_AND_EXPLICIT_NEW_ORIGINAL_BYTES'}
        raw_summary = encoded(summary); readme = old_readme + ('\n\n' + approval['readmeAppend'].strip() + '\n').encode()
        scan(ns, raw_summary, 'generated-summary.json', stats); scan(ns, readme, 'generated-README.md', stats)
        (out / 'summary.json').write_bytes(raw_summary); (out / 'README.md').write_bytes(readme)
        need({p.name for p in out.iterdir()} == {'results.zip', 'README.md', 'summary.json'}, 'EXACT_THREE_OUTPUTS')
        print(json.dumps({'status': summary['updatePreservation']['status'], 'externalOutput': str(out), 'archive': summary['archive'], 'repositoryWritten': False, 'sourceDeletion': False}))
    except BaseException:
        # Preserve any partial external files for exact review; never touch originals.
        raise

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--execute', action='store_true'); p.add_argument('--selection'); p.add_argument('--root-acceptance'); p.add_argument('--root-acceptance-sha256'); p.add_argument('--output')
    a = p.parse_args()
    if not a.execute:
        print(json.dumps({'status': 'WAIT_ROOT_FINAL_U2_UPGRADE_ROLLBACK_ACCEPTANCE', 'archiveExecuted': False, 'repositoryWritten': False, 'payloadScan': 'NOT_RUN'})); return
    need(all((a.selection, a.root_acceptance, a.root_acceptance_sha256, a.output)), 'ALL_EXPLICIT_FINAL_ARGUMENTS_REQUIRED')
    execute(a)
if __name__ == '__main__': main()
