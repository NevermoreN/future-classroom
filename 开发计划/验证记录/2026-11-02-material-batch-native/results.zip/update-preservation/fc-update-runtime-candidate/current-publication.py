"""Current actual U1 chain + source31 interop gate. No installation authority."""
from pathlib import Path
import hashlib,json,runpy
R=Path(__file__).resolve().parent
Q=runpy.run_path(str(R/'current-package-qualification.py'))
need=Q['need'];fact=Q['fact'];document=Q['document'];bound=Q['bound']
def prepare_record(package_report,package_sha,runtime_report,runtime_sha,interop):
 package=Path(package_report);runtime=Path(runtime_report)
 u1=document(dict(path=str(package),bytes=package.stat().st_size,sha256=package_sha));r=document(dict(path=str(runtime),bytes=runtime.stat().st_size,sha256=runtime_sha))
 af=r['artifactManifest'];manifest=document(af)
 need(manifest['packageReport']==fact(package),'U1_RUNTIME_EXACT_CURRENT_STATIC_PACKAGE')
 verified=Q['verify_one'](manifest);normal=verified['normal'];w=Path(u1['sourceRoot'])
 need(u1['version']=='0.2.0' and u1['productCode']==Q['U1'] and manifest['sourceGit']==normal['baseGit'],'CURRENT_ACTUAL_U1_IDENTITY')
 need(r['status']=='PASS_GNU_ABI2_SAME_PACKAGE_MAINTENANCE_WIN11_DEV_CONTROLLED_PRODUCT_CLOSURE_AND_EXACT_SCRATCH_CLEANUP' and r['downloadVerified'] is True and type(r['runtimeActualExit']) is int and r['runtimeActualExit']==0 and r['originalWholeBudgetExceeded'] is False,'CURRENT_ACTUAL_U1_COMPLETE_CHAIN')
 phase=r['phase'];g=runpy.run_path(str(R/'u1-qualification'/'run-controlled-product.py'))
 need(g['admission'](phase) and phase['allSetupBusinessSucceeded'] is True,'ALL_ORIGINAL_U1_CLIENT_GUARDIAN_AND_CLEANUP')
 need([p['verb'] for p in phase['phases']]==['install','repair','uninstall'],'COMPLETE_ORIGINAL_U1_THREE_PHASE_CHAIN')
 for p in phase['phases']:
  facts=p['observerFinal']['Processes'];need(len(facts)==2 and sorted(f['Role'] for f in facts)==sorted(['owned-guardian','setup-'+p['verb']]),'EXACT_U1_ORIGINAL_B_AND_G')
  need(all(f['Sha256']==manifest['setup']['sha256'] and f['Sid']==manifest['expectedUserSid'] for f in facts),'EXACT_CURRENT_U1_PROCESS_IDENTITY')
 for k in ['initial','uninstalled','finallyProduct']:need(phase[k]['knownAbsent'] is True and phase[k]['runAbsent'] is True,'U1_ORIGINAL_ABSENT_BOUNDARY')
 for k in ['installed','repaired']:need(phase[k]['healthyPresent'] is True and phase[k]['runAbsent'] is True,'CURRENT_U1_FULL14_SOURCE_REPAIR')
 need(phase['licenseDamage']['status']=='DELETED_ONLY_EXACT_NEW_INSTALL_LICENSE_BY_ORIGINAL_HANDLE' and phase['licenseDamage']['checkedClose'] is True and phase['damaged']['healthyPresent'] is False,'REAL_U1_LICENSE_DAMAGE_AND_REPAIR')
 pub=runpy.run_path(str(w/'scripts/installer-upgrade-publication.py'));codec=runpy.run_path(str(w/'scripts/installer-carrier-format.py'));schema=pub['schema_from_rust']((w/'crates/fc-windows/src/installer_lifecycle/native/broker/maintenance/schema.rs').read_text())
 msi=bound(manifest['msi']);tables=pub['capture'](msi,manifest['msi']['sha256'],schema);streams=dict(next(rows for name,cols,rows in tables if name=='Binary'))
 need(set(streams)=={'FcControlledGuardDll','FcGuardClientTemplate','FcPayloadManifest'},'ACTUAL_U1_ONLY_THREE_BINARY')
 envelope=streams['FcPayloadManifest'];old=codec['parse_payload_manifest'](envelope)
 need(old['product']==Q['U1'] and old['version']=='0.2.0' and old['package']==u1['packageCode'],'CURRENT_U1_ACTUAL_ENVELOPE')
 evidence=normal['upgradeSourceBinding']['sourceEvidence'];meta=dict(target=2,source_commit=normal['baseGit'],source_manifest_sha=normal['sourceInventory'],producer_sha=evidence['sha256'],source_msi_sha=manifest['msi']['sha256'],template_sha=hashlib.sha256(streams['FcGuardClientTemplate']).hexdigest(),guard_sha=hashlib.sha256(streams['FcControlledGuardDll']).hexdigest(),logical_sha=pub['signature'](tables)[0],template_bytes=len(streams['FcGuardClientTemplate']))
 i=document(interop)
 need(i['status']=='PASS_ACTUAL_U1_SOURCE31_RUST_PYTHON_CANONICAL_BYTES_EQUAL' and i['source']==fact(msi) and i['sourceUnchanged'] is True and i['sourceBefore']==i['sourceAfter'] and i['logicalSHA256']==meta['logical_sha'] and i['tableCount']==31,'ACTUAL_CURRENT_U1_RUST_PYTHON_SOURCE31_INTEROP')
 for f in i['sourceBefore']:
  p=Path(f['path']);need(p.is_file() and not p.is_symlink() and p.stat().st_size==f['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256'],'ACTUAL_CURRENT_INTEROP_SOURCE_BYTES')
 need(len(i['commands'])==2 and [op['label'] for op in i['commands']]==['compile','interop'],'ORIGINAL_INTEROP_TWO_COMMANDS')
 for op in i['commands']:
  need(type(op['actualExit']) is int and op['actualExit']==0 and op['originalParentReaped'] is True,'ACTUAL_ORIGINAL_INTEROP_ZERO')
  for k in ['stdout','stderr']:bound(op[k])
 proof=[]
 inventory=json.loads((Path(evidence['path']).parent/json.loads(Path(evidence['path']).read_bytes())['inputs_before']['path']).read_bytes())
 for leaf in ['crates/fc-windows/src/installer_lifecycle/native/broker/maintenance.rs','crates/fc-windows/src/installer_lifecycle/native/broker/controlled_owner.rs']:
  p=w/leaf;raw=p.read_bytes();row=next(x for x in inventory if x['path']==leaf);need(len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],'CURRENT_COMPILED_NATIVE_SOURCE_CACHE_PROOF');proof.append(dict(path=str(p),bytes=len(raw),sha256=row['sha256']))
 blob=pub['encode_format'](meta,envelope,codec['parse_payload_manifest'])
 return blob,dict(status='BOUND_DEV_PREDECESSOR_FROM_ACTUAL_COMPLETE_CURRENT_U1_CHAIN_NOT_FORMAL_CI',u1Package=fact(package),u1Runtime=fact(runtime),sourceCanonicalInterop=interop,meta=meta,cacheCompatibilityEvidence=dict(method='PRODUCTION_SUCCESS_BRANCH_INFERENCE',nativeCacheDigestSerialized=False,sourceCanonicalInterop=interop,frozenProductionProofSources=proof,directCacheDigestReceipt='NOT_SERIALIZED',actualNativeRepairReturned0=True,sourceDigestOrigin='LIBMSI_READONLY_FIXED31_U1_SOURCE_ONLY',sourceEqualsCacheBasis='Current frozen native maintenance same_source compares source_logical/cache_logical before VerifiedSameSourceMaintenance; actual Repair and Uninstall each returned0',upgradeRechecks='Actual native captures and compares old cache31 on every Upgrade'),record=dict(bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest()),cacheVsSource='Whole cache SHA NOT equated to source',BeginEndTelemetry='No numeric API return synthesized from logs or exits')
