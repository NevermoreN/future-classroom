def upgrade_source_binding(source_root: Path, evidence: Path, data: dict) -> dict:
    """Current source build evidence, never the historical 6eb overlay mode."""
    mode='ABI2_UPDATE_DATA_CURRENT_NORMAL_GNU_DEV'
    NEED(data.get('lifecycle_mode')==mode, 'Explicit current source development mode')
    for leaf in ('package-controlled-dev.py','package-msi-candidate.py','package-probe.py','audit-pe.py','installer-carrier-format.py'):
        NEED((source_root/'scripts'/leaf).read_bytes()==(HERE/leaf).read_bytes(), 'Actual imported script closure equals frozen source: '+leaf)
    before=DEV['bound'](evidence.parent,data['inputs_before']).read_bytes()
    after=DEV['bound'](evidence.parent,data['inputs_after']).read_bytes()
    NEED(before==after and B['json_document'](before)==DEV['source_inventory'](source_root), 'Actual complete unchanged current source inventory')
    NEED(data['environment']['CARGO_PROFILE_RELEASE_STRIP']=='symbols' and 'FC_OWNED_REMOVAL_SCOPE_HEX' in data['removed_environment_keys'], 'Normal strip and removed removal-scope override')
    return {'lifecycleMode':mode,'sourceRoot':str(source_root),'baseGit':data['source_head'],'sourceInventorySha256':B['digest'](before),'sourceCount':len(B['json_document'](before)),'oldOverlayEvidenceReused':False,'sourceEvidence':{'path':str(evidence),'bytes':evidence.stat().st_size,'sha256':B['file_digest'](evidence)}}
