from pathlib import Path
p=Path('/tmp/fc-update-data-candidate/source/crates/fc-bootstrap/src/application/migration_probe_fixture.rs');s=p.read_text()
s=s.replace('fn seed_material(app: &App, paths: &DataPaths, target: bool) -> Check<MaterialRecord> {','''fn seed_material(app: &App, paths: &DataPaths, target: bool) -> Check<MaterialRecord> {
    seed_material_using(app, paths, target, None)
}
fn seed_material_using(app: &App, paths: &DataPaths, target: bool, update_nonce: Option<&str>) -> Check<MaterialRecord> {''',1)
s=s.replace('''                SelectedFile::isolated_probe(paths.root(), filename),
                "isolated TXT selection",''','''                match update_nonce {
                    Some(nonce) => SelectedFile::update_probe(paths.root(), nonce, filename),
                    None => SelectedFile::isolated_probe(paths.root(), filename),
                },
                "owned synthetic TXT selection",''',1)
start=s.index('fn publish(\n');end=s.index('\nfn publish_image(',start);part=s[start:end]
newpart=part.replace('fn publish(\n','fn publish_with_receipt(\n',1).replace(') -> Check<()> {',') -> Check<IssuedCommand> {',1)
old='''    require(
        outcome.is_some_and(|outcome| outcome.status == ProfileContentStatus::Committed),
        "original content command committed",
    )
}'''
new='''    require(
        outcome.is_some_and(|outcome| outcome.status == ProfileContentStatus::Committed),
        "original content command committed",
    )?;
    Ok(issued)
}'''
assert old in newpart;newpart=newpart.replace(old,new,1)
wrapper='''fn publish(app: &App, paths: &DataPaths, slot: ContentSlotKey, intent_label: u64,
    input: LocalContentInput, kind: ContentPayloadKind) -> Check<()> {
    publish_with_receipt(app, paths, slot, intent_label, input, kind).map(|_| ())
}
'''
s=s[:start]+wrapper+newpart+s[end:]
start=s.index('fn publish_image(\n');end=s.index('\npub(super) fn seed_source',start);part=s[start:end]
newpart=part.replace('fn publish_image(\n','fn publish_image_using(\n',1).replace('''    red: u8,
) -> Check<()> {''','''    red: u8,
    update_nonce: Option<&str>,
) -> Check<IssuedCommand> {''',1).replace('''    publish(
''','''    publish_with_receipt(
''',1).replace('''            SelectedFile::isolated_probe(paths.root(), &name),
            "isolated PNG selection",''','''            match update_nonce {
                Some(nonce) => SelectedFile::update_probe(paths.root(), nonce, &name),
                None => SelectedFile::isolated_probe(paths.root(), &name),
            },
            "owned synthetic PNG selection",''',1)
wrapper='''fn publish_image(app: &App, paths: &DataPaths, slot: ContentSlotKey, command: u64, red: u8) -> Check<()> {
    publish_image_using(app, paths, slot, command, red, None).map(|_| ())
}
'''
s=s[:start]+wrapper+newpart+s[end:]
p.write_text(s)
