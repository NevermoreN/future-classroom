from pathlib import Path
r=Path('/tmp/fc-update-data-candidate/source')
p=r/'crates/fc-windows/src/system/paths.rs';s=p.read_text(); anchor='    /// Explicit deployment operation. Creates only this project\'s directories with\n'
add='''    /// Hidden update verification owns a fresh synthetic production deployment.
    /// Never adopt an existing root, even if its ACL would otherwise be valid.
    pub fn prepare_fresh_for_current_user(&self) -> Result<DeploymentDirectory> {
        if self.root != Self::program_data()?.root {
            return Err(Error::from_hresult(E_ACCESSDENIED));
        }
        check_local_ancestors(&self.root)?;
        let user_sid = current_user_sid()?;
        let expected = Descriptor::for_user(&user_sid)?;
        let attributes = SECURITY_ATTRIBUTES {
            nLength: std::mem::size_of::<SECURITY_ATTRIBUTES>() as u32,
            lpSecurityDescriptor: expected.0 .0,
            bInheritHandle: false.into(),
        };
        // SAFETY: the OS creates this exact fixed root with its protected DACL.
        // AlreadyExists is deliberately propagated, never accepted as ownership.
        unsafe { CreateDirectoryW(&HSTRING::from(self.root.as_os_str()), Some(&attributes))?; }
        let _root = crate::materials::files::PinnedDirectory::open(&self.root)?;
        verify_acl(&self.root, &expected)?;
        for child in CHILDREN {
            ensure_directory(&self.root.join(child), &expected)?;
        }
        let deployment = DeploymentDirectory {
            root: self.root.clone(), user_sid, _thread: PhantomData,
        };
        deployment.read_back()?;
        Ok(deployment)
    }
    /// Fixed actual installed GUI destination, discovered without environment
    /// variable input. This is path discovery, not an installation permission.
    pub fn installed_bootstrap_for_current_user() -> Result<PathBuf> {
        use windows::Win32::UI::Shell::{SHGetKnownFolderPath, FOLDERID_LocalAppData, KF_FLAG_DEFAULT};
        crate::com_task::with_task_memory(|memory| unsafe {
            let raw = SHGetKnownFolderPath(&FOLDERID_LocalAppData, KF_FLAG_DEFAULT, None)?;
            let value = raw.to_string();
            memory.free(raw.0.cast());
            let local = PathBuf::from(value?);
            let path = local.join("Programs").join("FutureClassroom").join("fc-bootstrap.exe");
            check_local_ancestors(&path)?;
            Ok(path)
        })
    }
'''
assert anchor in s;s=s.replace(anchor,add+anchor,1);p.write_text(s)
p=r/'crates/fc-windows/src/materials/chooser.rs';s=p.read_text();anchor='    /// Hidden diagnostics use only synthetic files under a protected isolated\n'
add='''    /// Update diagnostics may select only this fixture's fixed synthetic source
    /// names in the exact nonce-owned, protected default deployment. This does
    /// not relax the isolated picker or accept an arbitrary external path.
    pub fn update_probe(root: &Path, nonce: &str, name: &str) -> Result<Self> {
        use std::io::Read;
        let paths = crate::system::DataPaths::program_data()?;
        if root != paths.root()
            || nonce.len() != 32
            || !nonce.bytes().all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
            || !matches!(name, "migration-source.txt" | "update-second.txt"
                | "migration-source-601.png" | "migration-source-602.png")
        { return Err(Error::from_hresult(E_ACCESSDENIED)); }
        paths.verify_root_for_current_user()?;
        let _root = super::files::PinnedDirectory::open(root)?;
        paths.verify_root_for_current_user()?;
        let mut owner = LockedFile::open(&root.join("update-data-probe.owner"), 32)?;
        if owner.len()? != 32 { return Err(Error::from_hresult(E_ACCESSDENIED)); }
        let mut bytes = [0u8; 32];
        owner.file_mut().read_exact(&mut bytes)?;
        if bytes != nonce.as_bytes() { return Err(Error::from_hresult(E_ACCESSDENIED)); }
        Ok(Self { path: root.join("quarantine").join(name) })
    }
'''
assert anchor in s;s=s.replace(anchor,add+anchor,1);p.write_text(s)
p=r/'crates/fc-bootstrap/src/application.rs';s=p.read_text();anchor='mod http_business_probe;';add='''pub fn update_data_probe_stage(root: &Path, nonce: &str, stage: &str) -> std::result::Result<(), String> {
    crate::installation_startup::run(|| backup_probe::update_data_stage(root, nonce, stage))
}
''';assert anchor in s;s=s.replace(anchor,add+anchor,1);p.write_text(s)
p=r/'crates/fc-bootstrap/src/main.rs';s=p.read_text();anchor='    match args.as_slice() {\n';add='''        [flag, root, nonce, stage] if flag == "--update-data-probe-stage" => {
            #[cfg(windows)] { application::update_data_probe_stage(std::path::Path::new(root), nonce, stage) }
            #[cfg(not(windows))] {
                let _ = (root, nonce, stage);
                Err("update data native probe requires Windows".into())
            }
        }
''';assert anchor in s;s=s.replace(anchor,anchor+add,1);p.write_text(s)
