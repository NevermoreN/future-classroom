from pathlib import Path
import subprocess,os,json,time,sys,hashlib
r=Path('/tmp/fc-update-run-candidate');kind=sys.argv[1];env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(r/(kind+'-target')),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_OPT_LEVEL='1',CARGO_PROFILE_TEST_OPT_LEVEL='1');target=['--target','i686-pc-windows-gnu'] if kind=='gnu' else []
commands=[(kind+'-clippy',['cargo','clippy','-p','fc-windows','--all-targets','--locked',*target,'--','-D','warnings']),(kind+'-tests',['cargo','test','-p','fc-windows','--lib','--locked',*target,*(['--no-run','--message-format=json'] if target else ['--','--test-threads=2'])])]
rows=[]
for n,cmd in commands:
 t=time.monotonic()
 with (r/(n+'.stdout.log')).open('wb') as out,(r/(n+'.stderr.log')).open('wb') as err:p=subprocess.Popen(cmd,env=env,stdout=out,stderr=err);(r/(kind+'-active.json')).write_text(json.dumps(dict(pid=p.pid,command=cmd)));code=p.wait()
 row=dict(name=n,command=cmd,exit=code,seconds=time.monotonic()-t);rows.append(row);(r/(kind+'-results.json')).write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if code:break
(r/(kind+'-terminal.json')).write_text(json.dumps(dict(exit=code,profile='development opt1/debug0'))+'\n');sys.exit(code)
