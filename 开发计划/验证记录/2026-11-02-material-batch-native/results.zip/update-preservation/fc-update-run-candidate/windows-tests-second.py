from pathlib import Path
import runpy,json,hashlib,subprocess,uuid,time,sys
R=Path('/tmp/fc-update-run-candidate');H=runpy.run_path('scripts/windows-probe.py');P=H['ps_literal'];remote=H['Remote']('elior@192.168.10.212',Path('/config/.local/share/future-classroom-test-access/win11-192.168.10.212'))
assert json.loads((R/'gnu-tests-second.terminal.json').read_bytes())['exit']==0
for row in json.loads((R/'second-inputs.json').read_bytes()):assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
rows=[json.loads(line) for line in (R/'gnu-tests-second.stdout.log').read_text().splitlines()]
selected=[d for d in rows if d.get('reason')=='compiler-artifact' and d.get('profile',{}).get('test') and d.get('executable')];assert len(selected)==1 and not selected[0]['fresh'];exe=Path(selected[0]['executable']);sha=hashlib.sha256(exe.read_bytes()).hexdigest();nonce=uuid.uuid4().hex;leaf='FutureClassroom-Test-UpdateRun-'+nonce
report=dict(status='FAIL_NOT_COMPLETE',nonce=nonce,binarySha256=sha,fresh=False,profile=selected[0]['profile'],cleanup='NOT_RUN',scope='Only supplied fc-windows x86 development tests in owned noninteractive temp; no foreground changes');directory=None;start=time.monotonic();code=1
try:
 directory=remote.powershell('$r=Join-Path $env:TEMP '+P(leaf)+';New-Item -ItemType Directory -Path $r -ErrorAction Stop|Out-Null;[IO.File]::WriteAllText((Join-Path $r ".owner"),'+P(nonce)+');$r');report['remoteRoot']=directory
 remote.upload(exe,directory);root=P(directory);name=P(exe.name)
 actual=remote.powershell('(Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path '+root+' '+name+')).Hash.ToLowerInvariant()');assert actual==sha
 report['platform']=json.loads(remote.powershell('$s=Get-CimInstance Win32_OperatingSystem;@{caption=$s.Caption;build=$s.BuildNumber;architecture=$s.OSArchitecture}|ConvertTo-Json -Compress'))
 script='$r='+root+';$env:TEMP=Join-Path $r "temp";New-Item -ItemType Directory -Path $env:TEMP|Out-Null;$env:TMP=$env:TEMP;$ErrorActionPreference="Continue";$o=@(& (Join-Path $r '+name+') --test-threads=2 --nocapture 2>&1|ForEach-Object{"$_"});$c=$LASTEXITCODE;$ErrorActionPreference="Stop";@{exitCode=$c;output=$o}|ConvertTo-Json -Depth 6 -Compress'
 report['tests']=json.loads(remote.powershell(script,timeout=240));assert report['tests']['exitCode']==0;report['status']='PASS';code=0
except Exception as error:
 report['errorType']=type(error).__name__
finally:
 if directory:
  root=P(directory)
  try:
   script='$r='+root+';if(!(Test-Path -LiteralPath $r)){throw "owned root missing"};if([IO.File]::ReadAllText((Join-Path $r ".owner"))-cne '+P(nonce)+'){throw "owner mismatch"};$prefix=$r+"\\";foreach($p in @(Get-CimInstance Win32_Process|Where-Object{$_.ExecutablePath -and $_.ExecutablePath.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)})){Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop};Remove-Item -LiteralPath $r -Force -Recurse -ErrorAction Stop;if(Test-Path -LiteralPath $r){throw "owned root retained"};@{status="PASS";rootAbsent=$true}|ConvertTo-Json -Compress'
   report['cleanup']=json.loads(remote.powershell(script,timeout=45))
  except Exception as error:report['cleanup']=dict(status='FAIL_RETAIN_OWNER',errorType=type(error).__name__);code=1
 report['seconds']=time.monotonic()-start;(R/'windows-tests-second.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status=report['status'],cleanup=report['cleanup'],seconds=report['seconds'])));sys.exit(code)
