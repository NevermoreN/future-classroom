from pathlib import Path
import subprocess,os,json,time,sys,hashlib
R=Path('/tmp/fc-update-run-candidate');env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(R/'gnu-target'),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_OPT_LEVEL='1',CARGO_PROFILE_TEST_OPT_LEVEL='1');cmd=['cargo','test','-p','fc-windows','--lib','--locked','--target','i686-pc-windows-gnu','--no-run','--message-format=json'];t=time.monotonic()
files=[p for p in subprocess.check_output(['git','diff','--name-only','-z']).decode().split('\0') if p];assert len(files)==9
(R/'second-inputs.json').write_text(json.dumps([dict(path=p,sha256=hashlib.sha256(Path(p).read_bytes()).hexdigest()) for p in files],indent=2)+'\n')
with (R/'gnu-tests-second.stdout.log').open('wb') as out,(R/'gnu-tests-second.stderr.log').open('wb') as err:p=subprocess.Popen(cmd,env=env,stdout=out,stderr=err);(R/'gnu-tests-second.active.json').write_text(json.dumps(dict(pid=p.pid,command=cmd)));code=p.wait()
row=dict(command=cmd,exit=code,seconds=time.monotonic()-t);(R/'gnu-tests-second.terminal.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row));sys.exit(code)
