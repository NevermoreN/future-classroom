from pathlib import Path
p=Path('/tmp/fc-subject-disable-candidate/source/crates/fc-bootstrap/src/application.rs');s=p.read_text()
s=s.replace('''    AccountsLoaded(IdentityState),''','''    AccountsLoaded(IdentityState),
    SubjectsLoaded { facts: settings_registry::SubjectFacts, history: Option<Box<NativeHistory>>, saved: bool },''',1)
s=s.replace('''enum NativeIntent {
''','''enum NativeIntent {
    Subject { expected: Revision, command: IdentityCommand },
''',1)
s=s.replace('''enum NativeResolution {
''','''enum NativeResolution {
    SubjectRejected(IdentityError),
    Subject(Option<(Revision, fc_domain::identity::SchoolSubject)>),
''',1)
anchor='''        match (&self.resolution, self.command.intent()) {
''';add='''            (NativeResolution::SubjectRejected(IdentityError::RevisionConflict | IdentityError::InvalidScope | IdentityError::Capacity | IdentityError::InvalidText | IdentityError::DuplicateName | IdentityError::DuplicateId | IdentityError::NotFound | IdentityError::VersionOverflow), Some(NativeIntent::Subject { .. })) => true,
            (NativeResolution::SubjectRejected(_), _) => false,
            (NativeResolution::Subject(saved), Some(NativeIntent::Subject { expected, command: IdentityCommand::PutSubject { id, name, enabled, color, expected_revision } })) => saved.as_ref().is_none_or(|(revision, subject)| {
                expected.next().ok() == Some(*revision) && subject.id == *id && subject.name == *name
                    && subject.enabled == *enabled && subject.color == *color
                    && expected_revision.unwrap_or_default().next().ok() == Some(subject.revision)
            }),
            (NativeResolution::Subject(_), _) => false,
            (NativeResolution::Expired, Some(NativeIntent::Subject { .. })) => true,
            (_, Some(NativeIntent::Subject { .. })) => false,
''';assert anchor in s;s=s.replace(anchor,anchor+add,1)
anchor='''    fn default_teacher_rejection(
''';add='''    fn subject(command: NativeCommand, issued: fc_ports::command_window::IssuedCommand,
        result: fc_bootstrap::backend::Result<Option<(Revision, fc_domain::identity::SchoolSubject)>>) -> Result<Self> {
        let resolution = match result {
            Ok(value) => NativeResolution::Subject(value),
            Err(error) if error.command_window_error() == Some(fc_ports::command_window::CommandWindowError::Expired) => NativeResolution::Expired,
            Err(error) => return Err(error.into()),
        };
        let history = Self { command, issued, resolution };
        if !history.valid_result() { return Err(Failure::Stopped); }
        Ok(history)
    }
    fn subject_rejected(command: NativeCommand, issued: fc_ports::command_window::IssuedCommand, error: IdentityError) -> Result<Self> {
        let history = Self { command, issued, resolution: NativeResolution::SubjectRejected(error) };
        if !history.valid_result() { return Err(Failure::Stopped); }
        Ok(history)
    }
''';assert anchor in s;s=s.replace(anchor,add+anchor,1)
s=s.replace('''                | NativeResolution::DefaultTeacher(None)
''','''                | NativeResolution::DefaultTeacher(None)
                | NativeResolution::Subject(None)
''',1)
s=s.replace('''        match &self.resolution {
''','''        match &self.resolution {
            NativeResolution::SubjectRejected(IdentityError::InvalidScope) => "本次保存已被拒绝，未修改科目。请先调整课表中的相关课程和保留双表引用，再重新读取核对。",
            NativeResolution::SubjectRejected(_) => "本次科目保存已被明确拒绝，未修改设置。草稿保留，请重新读取后核对。",
            NativeResolution::Subject(None) => "尚未查到原科目保存结果，请重新读取核对；不会重复保存。当前目录另行显示。",
            NativeResolution::Subject(Some(_)) => "已查到原科目保存结果；当前目录另行显示，不会再次保存。",
''',1)
s=s.replace('''            Self::DefaultTeacherLoaded { history, .. } => Some(history),''','''            Self::DefaultTeacherLoaded { history, .. } => Some(history),
            Self::SubjectsLoaded { history, .. } => history.as_deref(),''',1)
s=s.replace('''    Accounts(SessionLease),''','''    Accounts(SessionLease),
    Subjects(SessionLease),''',1)
s=s.replace('''            | (Self::Accounts(_), Outcome::AccountsLoaded(_))''','''            | (Self::Accounts(_), Outcome::AccountsLoaded(_))
            | (Self::Subjects(_), Outcome::SubjectsLoaded { .. })''',1)
s=s.replace('''    LoadAccounts(Arc<Mutex<Backend>>, SessionLease),''','''    LoadAccounts(Arc<Mutex<Backend>>, SessionLease),
    LoadSubjects(Arc<Mutex<Backend>>, SessionLease),
    SaveSubject(Arc<Mutex<Backend>>, SessionLease, Revision, IdentityCommand),''',1)
s=s.replace('''            | Self::LoadAccounts(_, _)''','''            | Self::LoadAccounts(_, _)
            | Self::LoadSubjects(_, _)''',1)
anchor='''            Self::SaveAccount(_, _, operation) => {
''';add='''            Self::SaveSubject(_, _, _, command) => match command {
                IdentityCommand::PutSubject { name, .. } => name.capacity().checked_add(4096),
                _ => None,
            },
''';assert anchor in s;s=s.replace(anchor,add+anchor,1)
s=s.replace('''            Self::SaveAccount(..)
''','''            Self::SaveAccount(..)
            | Self::SaveSubject(..)
''',1)
anchor='''        match self {
            Self::Tracked(work, _) => work.native_intent(),
''';add='''            Self::SaveSubject(_, _, expected, command) => Some(NativeIntent::Subject { expected: *expected, command: command.clone() }),
''';assert anchor in s;s=s.replace(anchor,anchor+add,1)
s=s.replace('''            Self::SaveAccount(_, lease, _) => NativeTarget::Accounts(*lease),''','''            Self::SaveAccount(_, lease, _) => NativeTarget::Accounts(*lease),
            Self::SaveSubject(_, lease, ..) => NativeTarget::Subjects(*lease),''',1)
s=s.replace('''            (Self::LoadAccounts(_, lease), NativeTarget::Accounts(original))''','''            (Self::LoadAccounts(_, lease), NativeTarget::Accounts(original))
            | (Self::LoadSubjects(_, lease), NativeTarget::Subjects(original))''',1)
anchor='''            Self::SaveAccount(backend, lease, operation) => {
''';add='''            Self::LoadSubjects(backend, lease) => {
                let mut backend = backend.lock().map_err(|_| Failure::Stopped)?;
                let history = if let Some(NativeIntent::Subject { expected, command: intent }) = command.intent() {
                    let issued = command.original()?;
                    let result = command.query(&mut backend, context, |b| Ok(b.subject_outcome(lease, *expected, intent.clone())?));
                    Some(Box::new(match result {
                        Ok(value) => NativeHistory::subject(command.clone(), issued, Ok(value))?,
                        Err(Failure::Backend(error)) => NativeHistory::subject(command.clone(), issued, Err(error))?,
                        Err(error) => return Err(error),
                    }))
                } else { None };
                let facts = settings_registry::load_subjects(&backend, lease, context)?;
                Ok(Outcome::SubjectsLoaded { facts, history, saved: false })
            }
            Self::SaveSubject(backend, lease, expected, intent) => {
                let mut backend = backend.lock().map_err(|_| Failure::Stopped)?;
                command.run(&mut backend, fc_ports::command_window::CommandFamily::Identity, Some(lease), SessionPurpose::Manage, context, |b| {
                    let (history, saved) = match b.identity_at(lease, expected, intent.clone()) {
                        Ok(state) => {
                            let IdentityCommand::PutSubject { id, .. } = &intent else { return Err(Failure::Stopped); };
                            let subject = state.subjects.iter().find(|s| s.id == *id).ok_or(Failure::Stopped)?.clone();
                            (NativeHistory::subject(command.clone(), command.original()?, Ok(Some((state.revision, subject))))?, true)
                        }
                        Err(BackendError::Identity(fc_ports::IdentityRepositoryError::Domain(error @ (IdentityError::RevisionConflict | IdentityError::InvalidScope | IdentityError::Capacity | IdentityError::InvalidText | IdentityError::DuplicateName | IdentityError::DuplicateId | IdentityError::NotFound | IdentityError::VersionOverflow)))) => {
                            (NativeHistory::subject_rejected(command.clone(), command.original()?, error)?, false)
                        }
                        Err(error) => return Err(error.into()),
                    };
                    Ok(Outcome::SubjectsLoaded { facts: settings_registry::load_subjects(b, lease, context)?, history: Some(Box::new(history)), saved })
                })
            }
''';assert anchor in s;s=s.replace(anchor,add+anchor,1)
s=s.replace('''    accounts: Option<accounts_editor::Editor>,''','''    accounts: Option<accounts_editor::Editor>,
    subject_editor: Option<settings_registry::SubjectEditor>,''',1)
s=s.replace('''        accounts: None,''','''        accounts: None,
        subject_editor: None,''',1)
anchor='''        let command = match &work {
''';add='''            Work::LoadSubjects(..) if readback && self.native_unknown && self.native_command.as_ref().is_some_and(|original| matches!(original.intent(), Some(NativeIntent::Subject { .. }))) => {
                self.native_command.as_ref().ok_or("原科目保存记录不可用。")?.clone()
            }
''';assert anchor in s;s=s.replace(anchor,anchor+add,1)
s=s.replace('''                    TO_RECOVERY | TO_SCHOOL | TO_SUBJECTS | TO_HOMEWORK | TO_PASSWORD''','''                    TO_SUBJECTS => self.open_subjects()?,
                    TO_RECOVERY | TO_SCHOOL | TO_HOMEWORK | TO_PASSWORD''',1)
s=s.replace('''                            TO_SUBJECTS => Screen::Subjects,
''','',1)
s=s.replace('''                Ok(Outcome::AccountsLoaded(state)) => {''','''                Ok(Outcome::SubjectsLoaded { facts, history, saved }) => self.subjects_loaded(facts, history, saved)?,
                Ok(Outcome::AccountsLoaded(state)) => {''',1)
anchor='''            || self
                .profiles
                .as_ref()
                .is_some_and(|e| e.owner() == owner && e.has_unsaved_changes())''';add='''            || self.subject_editor.as_ref().is_some_and(|e| e.has_unsaved_changes())
''';assert anchor in s;s=s.replace(anchor,add+anchor,1)
s=s.replace('''                ) | NativeResolution::DefaultTeacher(Some(_))''','''                ) | NativeResolution::DefaultTeacher(Some(_)) | NativeResolution::Subject(Some(_))''',1)
# Old main diagnostic creates its subject through the actual new UI; no legacy
# SAVE bypass remains in production routing.
anchor='''    const INITIAL: &str = "Probe-admin-password-2026";''';add='''    if *stage == 6 {
        if app.screen == Screen::Home { *stage += 1; return Ok(()); }
        let view = app.view();
        let action = if app.state.subjects.iter().any(|s| s.name == "数学") && view.actions.iter().any(|a| a.id == settings_registry::SUBJECT_NEW) { BACK }
            else if view.actions.iter().any(|a| a.id == settings_registry::SUBJECT_NEW) { settings_registry::SUBJECT_NEW }
            else if view.actions.iter().any(|a| a.id == settings_registry::SUBJECT_REVIEW) { settings_registry::SUBJECT_REVIEW }
            else { settings_registry::SUBJECT_CONFIRM };
        let mut form = FormData::new();
        for field in view.fields.into_iter().filter(|f| f.kind != FieldKind::ReadOnly) {
            let value = if field.id == SUBJECT { "数学".into() } else if field.id == COLOR { "70A5D8".into() } else { field.value };
            form.insert(field.id, value).map_err(|_| "科目原生诊断表单无效")?;
        }
        app.window.probe_submit(action, form).map_err(|_| "科目原生诊断操作未接纳")?;
        return Ok(());
    }
''';assert anchor in s;s=s.replace(anchor,add+anchor,1)
p.write_text(s)
p=Path('/tmp/fc-subject-disable-candidate/source/crates/fc-bootstrap/src/application/settings_registry.rs');s=p.read_text().replace(', ..View::default()','');s=s.replace('''                if old.is_some_and(|s| s.enabled != draft.enabled) {''','''                if !draft.enabled && courses > 0 {
                    view.description.push_str("\\n课表仍有引用时保存会被拒绝，请先调整课表和保留双表；不会自动删除或替换课程。");
                }
                if old.is_some_and(|s| s.enabled != draft.enabled) {''',1);p.write_text(s)
