from pathlib import Path
import os,subprocess,json,time,sys,hashlib
R=Path('/tmp/fc-subject-disable-candidate');env=os.environ.copy();env.update(CARGO_TARGET_DIR='/tmp/fc-update-run-candidate/gnu-target',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_OPT_LEVEL='1',CARGO_PROFILE_TEST_OPT_LEVEL='1')
files=[p for p in subprocess.check_output(['git','diff','--name-only','-z']).decode().split('\0') if p];assert len(files)==16
(R/'root-inputs.json').write_text(json.dumps([dict(path=p,sha256=hashlib.sha256(Path(p).read_bytes()).hexdigest()) for p in files],indent=2)+'\n')
cmd=['cargo','test','-p','fc-bootstrap','--bins','--lib','--locked','--target','i686-pc-windows-gnu','--no-run','--message-format=json'];t=time.monotonic()
with (R/'native-compile.stdout.jsonl').open('xb') as out,(R/'native-compile.stderr.log').open('xb') as err:
 p=subprocess.Popen(cmd,env=env,stdout=out,stderr=err);(R/'native-compile.active.json').write_text(json.dumps(dict(pid=p.pid,command=cmd)));code=p.wait()
row=dict(command=cmd,exit=code,parentReaped=True,seconds=time.monotonic()-t);(R/'native-compile.terminal.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row));sys.exit(code)
