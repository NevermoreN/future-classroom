    #[test]
    fn subjects_native_self_teaching_revocation_confirms_commit_without_new_lease_or_current_read() {
        let _serial = SERIAL.lock().unwrap();
        let (scratch, mut app) = ready_management();
        let paths = DataPaths::isolated_test(scratch.0.clone()).unwrap();
        migration_probe_fixture::seed_source(&mut app, &paths).unwrap();
        let backend = app.backend.as_ref().unwrap().clone();
        const INITIAL: &str = "Synthetic self subject administrator 2026!";
        const CHANGED: &str = "Synthetic self subject changed 2026!";
        {
            let mut b = backend.lock().unwrap(); let lease = app.lease.unwrap();
            let issued = b.issue_native_command(fc_ports::command_window::CommandFamily::Identity,Some(lease),SessionPurpose::Manage).unwrap();
            drop(b.begin_command_scope(issued).unwrap().create_account(lease, NewAccount {
                id: PrincipalId::new(3).unwrap(), login_name: "subject-self-admin".into(), display_name: "合成任教主管理员".into(), role: Role::GlobalAdmin,
                scopes: vec![AssignmentScope { class_id: ClassId::new(1).unwrap(), subject_id: SubjectId::new(1).unwrap() }] }, Password::new(INITIAL.into()).unwrap()).unwrap());
        }
        subject_test_ui(&mut app, LOCK, &[]);
        subject_test_ui(&mut app, LOG_IN, &[(LOGIN,"subject-self-admin"),(PASSWORD,INITIAL)]);
        assert!(app.screen == Screen::Password);
        subject_test_ui(&mut app, SAVE, &[(PASSWORD,INITIAL),(NEW_PASSWORD,CHANGED),(CONFIRM,CHANGED)]);
        subject_test_ui(&mut app, LOG_IN, &[(LOGIN,"subject-self-admin"),(PASSWORD,CHANGED)]);
        let old_lease = app.lease.unwrap(); assert_eq!(old_lease.principal_id().get(),3);
        app.open_subjects().unwrap(); wait_for(&mut app, |a| a.pending.is_none());
        subject_test_edit(&mut app,"0");
        app.window.probe_submit(settings_registry::SUBJECT_CONFIRM,FormData::new()).unwrap();
        for event in app.window.take_events().unwrap() { app.event(event).unwrap(); }
        assert!(app.pending.as_ref().unwrap().self_revokes, "normal GUI heartbeat must consume its original completion");
        wait_for(&mut app, |a| a.pending.is_none());
        assert!(app.screen == Screen::Login && app.lease.is_none());
        assert!(!app.native_unknown && app.status.contains("已保存"));
        assert!(app.control.as_ref().unwrap().is_local_locked());
        let original = app.native_command.as_ref().unwrap().clone();
        let pair = original.snapshot().unwrap();
        let NativeIntent::Subject { expected, command } = original.intent().unwrap().clone() else { panic!("subject original intent"); };
        {
            let mut b = backend.lock().unwrap(); let current = b.state().unwrap();
            assert!(!current.subjects[0].enabled);
            assert!(b.check_session(old_lease,SessionPurpose::Manage).is_err());
            let mut original_scope = b.begin_command_scope(pair).unwrap();
            assert!(original_scope.subject_outcome(old_lease,expected,command).is_err(), "a saved receipt is never authority for the retired caller");
        }
        app.open_subjects().unwrap();
        assert!(app.lease.is_none() && app.screen == Screen::Login, "original result display cannot mint or renew a management lease");
        drain(app); drop(backend); drop(scratch);
    }
