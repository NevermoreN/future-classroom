from pathlib import Path
import subprocess,json,hashlib,time,sys
R=Path('/tmp/fc-subject-disable-candidate');U=Path('/tmp/fc-update-runtime-candidate')
assert json.loads((U/'integrated-clippy-paced.terminal.json').read_bytes())['exit']==0
assert json.loads((U/'normal-build-u2-paced/terminal.json').read_bytes())['exit']==0
for row in json.loads((U/'u2-paced-source-freeze.json').read_bytes())['inputs']:assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
exe=U/'normal-build-u2-paced/fc-bootstrap.exe';base=['python3','scripts/windows-probe.py','--host','elior@192.168.10.212','--identity','/config/.local/share/future-classroom-test-access/win11-192.168.10.212','--exe',str(exe),'--native-seconds','1']
commands=[('paced-native-workflows',base+['--application','--system-host','--report',str(R/'paced-native-workflows-win11.json')]),('paced-public-desktop',base+['--public-desktop','--report',str(R/'paced-public-desktop-win11.json')]),('paced-subject-visuals',base+['--subject-visuals','--report',str(R/'paced-subject-visuals-win11.json')])];results=[]
for label,cmd in commands:
 t=time.monotonic()
 with (R/(label+'.stdout.log')).open('xb') as out,(R/(label+'.stderr.log')).open('xb') as err:
  p=subprocess.Popen(cmd,stdout=out,stderr=err);(R/'windows-paced-active.json').write_text(json.dumps(dict(pid=p.pid,command=cmd)));code=p.wait()
 row=dict(label=label,command=cmd,exit=code,parentReaped=True,seconds=time.monotonic()-t);results.append(row);(R/'windows-paced-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
 if code:sys.exit(code)
