    fn subject_test_identity(app: &App, command: IdentityCommand) -> IdentityState {
        let mut backend = app.backend.as_ref().unwrap().lock().unwrap();
        let lease = app.lease.unwrap(); let expected = backend.state().unwrap().revision;
        let issued = backend.issue_native_command(fc_ports::command_window::CommandFamily::Identity, Some(lease), SessionPurpose::Manage).unwrap();
        let result = backend.begin_command_scope(issued).unwrap().identity_at(lease, expected, command).unwrap(); result
    }
    fn subject_test_ui(app: &mut App, action: ActionId, values: &[(FieldId,&str)]) {
        voice_management_probe::submit(app, action, values, Instant::now() + Duration::from_secs(60)).unwrap();
    }
    fn subject_test_edit(app: &mut App, enabled: &str) {
        subject_test_ui(app, settings_registry::SUBJECT_EDIT, &[(settings_registry::SUBJECT_SELECT,"1")]);
        subject_test_ui(app, settings_registry::SUBJECT_REVIEW, &[(settings_registry::SUBJECT_ENABLED,enabled)]);
    }
    #[test]
    fn subjects_native_disable_receipt_after_lost_reply_rename_without_enabling_and_reenable_keep_originals() {
        use fc_domain::{materials::*, profile::SubjectProfileKey, profile_content::*, layout::{LayoutScope, NodeKind, WidgetKind}};
        use fc_ports::MaterialListRequest;
        let _serial = SERIAL.lock().unwrap();
        let (scratch, mut app) = ready_management();
        let paths = DataPaths::isolated_test(scratch.0.clone()).unwrap();
        migration_probe_fixture::seed_source(&mut app, &paths).unwrap();
        let backend = app.backend.as_ref().unwrap().clone(); let lease = app.lease.unwrap();
        let scope = MaterialScope { teacher_id: PrincipalId::new(2).unwrap(), subject_id: SubjectId::new(1).unwrap() };
        let profile_key = SubjectProfileKey { class_id: ClassId::new(1).unwrap(), subject_id: scope.subject_id, teacher_id: scope.teacher_id };
        let (before, page, profile, images) = {
            let b = backend.lock().unwrap();
            let profile = b.read_subject_profile(lease, profile_key).unwrap().unwrap();
            let slot = ContentSlotKey { scope: LayoutScope::Subject(profile_key), node_id: profile.tree.nodes.iter().find(|n| n.kind == NodeKind::Widget(WidgetKind::SubjectImage)).unwrap().id };
            (b.state().unwrap(), b.materials(lease, MaterialListRequest { scope, cursor: None }).unwrap(), profile, b.read_profile_content(lease, slot).unwrap())
        };
        let original_path = paths.root().join("teachers/2/subjects/1/500/501.txt");
        let original_bytes = fs::read(&original_path).unwrap();
        app.open_subjects().unwrap(); wait_for(&mut app, |a| a.pending.is_none());
        subject_test_edit(&mut app,"0");
        assert!(app.view().description.contains("默认老师1项"));
        subject_test_ui(&mut app, settings_registry::SUBJECT_CANCEL, &[]);
        assert_eq!(backend.lock().unwrap().state().unwrap(), before, "review/cancel never writes");
        subject_test_edit(&mut app,"0");
        app.window.probe_submit(settings_registry::SUBJECT_CONFIRM, FormData::new()).unwrap();
        for event in app.window.take_events().unwrap() { app.event(event).unwrap(); }
        lose_worker_reply(&mut app);
        let original = app.native_command.as_ref().unwrap().clone(); let pair = original.snapshot().unwrap();
        let NativeIntent::Subject { expected, command: original_intent } = original.intent().unwrap().clone() else { panic!("subject original intent"); };
        let disabled = backend.lock().unwrap().state().unwrap();
        assert!(!disabled.subjects[0].enabled); assert!(disabled.default_teachers.is_empty());
        assert_eq!(disabled.assignments, before.assignments); assert_eq!(fs::read(&original_path).unwrap(), original_bytes);
        // A later real publication deliberately differs from the original result.
        let saved = &disabled.subjects[0];
        subject_test_identity(&app, IdentityCommand::PutSubject { id: saved.id, name: "后续停用名称".into(), enabled: false, color: saved.color, expected_revision: Some(saved.revision) });
        let later = backend.lock().unwrap().state().unwrap();
        subject_test_ui(&mut app, settings_registry::SUBJECT_RELOAD, &[]);
        assert!(!app.native_unknown); assert_eq!(app.native_command.as_ref(), Some(&original));
        assert_eq!(app.state.as_ref(), &later, "historical identity cannot replace current authority");
        assert!(app.status.contains("源合成科目一") && app.status.contains("停用"));
        assert_eq!(backend.lock().unwrap().state().unwrap(), later, "original receipt query never replays identity");
        {
            let mut b = backend.lock().unwrap(); let mut original_scope = b.begin_command_scope(pair).unwrap();
            let result = original_scope.subject_outcome(lease, expected, original_intent.clone()).unwrap().unwrap();
            assert_eq!(result.1, disabled.subjects[0]);
            assert!(original_scope.subject_outcome(lease, expected.next().unwrap(), original_intent.clone()).is_err());
            let mut tampered = original_intent.clone(); if let IdentityCommand::PutSubject { enabled, .. } = &mut tampered { *enabled = true; }
            assert!(original_scope.subject_outcome(lease, expected, tampered).is_err(), "original C2 binds complete intent");
        }
        subject_test_ui(&mut app, settings_registry::SUBJECT_EDIT, &[(settings_registry::SUBJECT_SELECT,"1")]);
        subject_test_ui(&mut app, settings_registry::SUBJECT_REVIEW, &[(SUBJECT,"界面改名仍停用")]);
        subject_test_ui(&mut app, settings_registry::SUBJECT_CONFIRM, &[]);
        assert!(!backend.lock().unwrap().state().unwrap().subjects[0].enabled, "renaming cannot silently enable");
        subject_test_edit(&mut app,"1");
        subject_test_ui(&mut app, settings_registry::SUBJECT_CONFIRM, &[]);
        let b = backend.lock().unwrap(); let enabled = b.state().unwrap();
        assert!(enabled.subjects[0].enabled); assert_eq!(enabled.subjects[0].id, before.subjects[0].id);
        assert_eq!(enabled.subjects[0].color, before.subjects[0].color); assert_eq!(enabled.assignments, before.assignments);
        assert!(enabled.default_teachers.is_empty(), "re-enable cannot silently choose a default teacher");
        assert!(enabled.account(scope.teacher_id).unwrap().principal.auth_epoch > before.account(scope.teacher_id).unwrap().principal.auth_epoch);
        assert_eq!(b.materials(lease, MaterialListRequest { scope, cursor: None }).unwrap(), page);
        assert_eq!(b.read_subject_profile(lease, profile_key).unwrap().unwrap(), profile);
        assert_eq!(b.read_profile_content(lease, images.slot).unwrap(), images, "both real image versions survive");
        assert_eq!(fs::read(&original_path).unwrap(), original_bytes);
        drop(b); drain(app); drop(backend); drop(scratch);
    }
    #[test]
    fn subjects_native_stale_identity_and_retained_only_timetable_reference_are_definite_rejections() {
        use fc_domain::{schedule::*, schedule_document::SemesterPlan, time::*};
        let _serial = SERIAL.lock().unwrap();
        let (scratch, mut app) = ready_management();
        let paths = DataPaths::isolated_test(scratch.0.clone()).unwrap();
        migration_probe_fixture::seed_source(&mut app, &paths).unwrap();
        let backend = app.backend.as_ref().unwrap().clone(); let lease = app.lease.unwrap();
        app.open_subjects().unwrap(); wait_for(&mut app, |a| a.pending.is_none());
        subject_test_edit(&mut app,"0");
        subject_test_identity(&app, IdentityCommand::RenameSchool { name: "并发合成学校".into() });
        let concurrent = backend.lock().unwrap().state().unwrap();
        subject_test_ui(&mut app, settings_registry::SUBJECT_CONFIRM, &[]);
        assert_eq!(backend.lock().unwrap().state().unwrap(), concurrent);
        assert!(!app.native_unknown && app.status.contains("拒绝")); assert!(app.has_unsaved_changes());
        subject_test_ui(&mut app, settings_registry::SUBJECT_RELOAD, &[]);
        // Only the retained Even table references this subject. The surviving
        // Single table has no cells; counting only current rows would miss it.
        {
            let year = app.clock.try_now().unwrap().date.year();
            let anchor = (25..=31).filter_map(|day| LocalDate::new(year-1,12,day).ok()).find(|d| d.weekday()==Weekday::Monday).unwrap();
            let row = |id, cell: bool| TimetableRow { id: RowId::new(id).unwrap(), logical_key: LogicalRowKey::new(100).unwrap(),
                group: DayGroup::Morning, kind: RowKind::Course,
                range: MinuteRange::new(Minute::new(480).unwrap(),Minute::new(525).unwrap()).unwrap(), enabled_days: [true;7],
                courses: std::array::from_fn(|day| (cell && day==0).then_some(CourseCell { subject_id: SubjectId::new(1).unwrap(), teacher: TeacherBinding::Default })) };
            let plan = SemesterPlan::new(Semester { id: SemesterId::new(100).unwrap(), class_id: ClassId::new(1).unwrap(), revision: Revision::default(), enabled: false,
                start: LocalDate::new(year,1,1).unwrap(), end: LocalDate::new(year,12,31).unwrap(), first_week_monday: anchor,
                tables: vec![WeekTable { id: TableId::new(101).unwrap(), role: TableRole::Odd, rows: vec![row(102,false)] }, WeekTable { id: TableId::new(103).unwrap(), role: TableRole::Even, rows: vec![row(104,true)] }] }, "保留双表引用合成课表".into()).disable_dual(TableId::new(101).unwrap()).unwrap();
            let mut b = backend.lock().unwrap(); let mut document = b.read_schedule(lease).unwrap(); document.semesters = vec![plan]; document.update_id_high_water();
            let issued = b.issue_native_command(fc_ports::command_window::CommandFamily::Schedule,Some(lease),SessionPurpose::Manage).unwrap();
            b.begin_command_scope(issued).unwrap().save_schedule(lease,document.revision,document).unwrap();
        }
        subject_test_ui(&mut app, settings_registry::SUBJECT_RELOAD, &[]);
        subject_test_edit(&mut app,"0");
        assert!(app.view().description.contains("课表1格（含保留双表）"));
        assert!(app.view().description.contains("保存会被拒绝"));
        let before = backend.lock().unwrap().state().unwrap();
        subject_test_ui(&mut app, settings_registry::SUBJECT_CONFIRM, &[]);
        assert_eq!(backend.lock().unwrap().state().unwrap(),before);
        assert!(!app.native_unknown && app.status.contains("保留双表"));
        assert!(app.has_unsaved_changes());
        // Lock discards the confirmation, preserving only non-secret draft.
        subject_test_ui(&mut app, settings_registry::SUBJECT_REVIEW, &[]);
        app.event(Event::Submit(LOCK,FormData::new())).unwrap();
        assert!(app.screen == Screen::Login && app.lease.is_none());
        assert_eq!(backend.lock().unwrap().state().unwrap(),before);
        drain(app); drop(backend); drop(scratch);
    }
