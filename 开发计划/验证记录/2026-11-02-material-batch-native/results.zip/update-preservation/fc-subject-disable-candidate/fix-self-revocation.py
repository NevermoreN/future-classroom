from pathlib import Path
p=Path('/tmp/fc-subject-disable-candidate/source/crates/fc-bootstrap/src/application.rs');s=p.read_text();anchor='''    SubjectsLoaded {
        facts: settings_registry::SubjectFacts,
        history: Option<Box<NativeHistory>>,
        saved: bool,
    },''';add='''
    SubjectSelfRevoked { state: IdentityState, history: Box<NativeHistory> },''';assert anchor in s;s=s.replace(anchor,anchor+add,1)
s=s.replace('''            Self::SubjectsLoaded { history, .. } => history.as_deref(),''','''            Self::SubjectsLoaded { history, .. } => history.as_deref(),
            Self::SubjectSelfRevoked { history, .. } => Some(history),''',1)
anchor='''                    |b| {
                        let (history, saved) = match b.identity_at(lease, expected, intent.clone())''';add='''                    |b| {
                        let original_epoch = b.state()?.account(lease.principal_id())
                            .map_err(|_| Failure::Stopped)?.principal.auth_epoch;
                        let (history, saved) = match b.identity_at(lease, expected, intent.clone())''';assert anchor in s;s=s.replace(anchor,add,1)
old='''                                (
                                    NativeHistory::subject(
                                        command.clone(),
                                        command.original()?,
                                        Ok(Some((state.revision, subject))),
                                    )?,
                                    true,
                                )''';new='''                                let history = NativeHistory::subject(command.clone(), command.original()?,
                                    Ok(Some((state.revision, subject))))?;
                                if state.account(lease.principal_id()).map_err(|_| Failure::Stopped)?.principal.auth_epoch != original_epoch {
                                    // The committed operation revoked this caller's own teaching
                                    // session. Report only this original result; do not perform a
                                    // management read with the retired lease or issue a new one.
                                    return Ok(Outcome::SubjectSelfRevoked { state, history: Box::new(history) });
                                }
                                (history, true)''';assert old in s;s=s.replace(old,new,1)
anchor='''        let self_revokes = matches!(&work,Work::Request(r) if r.action==EXIT||r.action==SAVE&&matches!(r.screen,Screen::Password|Screen::Rotate))
            || matches!(&work, Work::SaveAccount(_, lease, operation) if matches!(operation.as_ref(), accounts_editor::Command::Update { command: IdentityCommand::UpdateAccount { id, .. }, .. } if *id == lease.principal_id()));''';new='''        let self_revokes = matches!(&work,Work::Request(r) if r.action==EXIT||r.action==SAVE&&matches!(r.screen,Screen::Password|Screen::Rotate))
            || matches!(&work, Work::SaveAccount(_, lease, operation) if matches!(operation.as_ref(), accounts_editor::Command::Update { command: IdentityCommand::UpdateAccount { id, .. }, .. } if *id == lease.principal_id()))
            || matches!(&work, Work::SaveSubject(_, lease, _, IdentityCommand::PutSubject { id, enabled, .. })
                if self.state.subjects.iter().any(|s| s.id == *id && s.enabled != *enabled)
                    && self.state.assignments.iter().any(|a| a.teacher_id == lease.principal_id() && a.subject_id == *id && a.enabled));''';assert anchor in s;s=s.replace(anchor,new,1)
anchor='''                Ok(Outcome::SubjectsLoaded {
                    facts,
                    history,
                    saved,
                }) => self.subjects_loaded(facts, history, saved)?,''';new='''                Ok(Outcome::SubjectSelfRevoked { state, .. }) => {
                    self.state = Arc::new(state);
                    self.subject_editor = None;
                    self.lock();
                    self.status = "科目修改已保存。你也任教该科目，原会话已失效；请重新登录。".into();
                }
'''+anchor;assert anchor in s;s=s.replace(anchor,new,1)
p.write_text(s)
