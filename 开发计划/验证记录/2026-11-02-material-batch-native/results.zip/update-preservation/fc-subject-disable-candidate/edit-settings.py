from pathlib import Path
p=Path('/tmp/fc-subject-disable-candidate/source/crates/fc-bootstrap/src/application/settings_registry.rs');s=p.read_text();s=s.replace('''            render: page_subjects,
            submit: None,
            early_submit: false,
            input: no_input,
            grid: no_grid,
            suspend: no_suspend,''','''            render: page_subjects,
            submit: Some(App::subjects_event),
            early_submit: false,
            input: no_input,
            grid: no_grid,
            suspend: suspend_subjects,''',1)
a=s.index('fn page_subjects(');b=s.index('\nfn page_accounts(',a);s=s[:a]+'''fn page_subjects(app: &App, status: &str) -> View {
    if let Some(view) = public_view(app, status) { return view; }
    if let Some(editor) = &app.subject_editor {
        let mut view = editor.view(&app.state, status);
        view.busy = app.pending.is_some() || app.stopping;
        return view;
    }
    let mut view = frame(app, status);
    view.title = "学校基础科目".into();
    view.description = "正在读取科目状态与引用，请稍候。".into();
    view.actions = vec![action(LOCK, "锁定")];
    view
}
'''+s[b:]
s=s.replace('''    Registration {
        key: (Screen::Subjects, SAVE),
        implementation: request_subjects_save,
    },
''','',1)
a=s.index('fn request_subjects_save(');b=s.index('\nfn request_homework_load(',a);s=s[:a]+s[b:]
anchor='fn suspend_accounts(app: &mut App) {';add='''fn suspend_subjects(app: &mut App) {
    if app.screen == Screen::Subjects {
        if let (Some(editor), Ok(data)) = (&mut app.subject_editor, app.window.draft_nonsecret()) {
            editor.suspend(&data);
        }
    }
}
''';assert anchor in s;s=s.replace(anchor,add+anchor,1);p.write_text(s)
