from pathlib import Path
import os,subprocess,json,time,sys
R=Path('/tmp/fc-subject-disable-candidate');env=os.environ.copy();env.update(CARGO_TARGET_DIR='/tmp/fc-update-run-candidate/host-target',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_OPT_LEVEL='1',CARGO_PROFILE_TEST_OPT_LEVEL='1')
commands=[('clippy',['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings']),('tests',['cargo','test','--workspace','--locked','--','--test-threads=2'])];results=[]
for label,cmd in commands:
 t=time.monotonic()
 with (R/('host-'+label+'.stdout.log')).open('xb') as out,(R/('host-'+label+'.stderr.log')).open('xb') as err:
  p=subprocess.Popen(cmd,env=env,stdout=out,stderr=err);(R/'host-active.json').write_text(json.dumps(dict(pid=p.pid,command=cmd)));code=p.wait()
 row=dict(command=cmd,exit=code,parentReaped=True,seconds=time.monotonic()-t);results.append(row);(R/'host-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
 if code:sys.exit(code)
