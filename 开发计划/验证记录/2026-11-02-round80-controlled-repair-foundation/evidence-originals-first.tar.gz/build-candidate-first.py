from pathlib import Path
import os,json,hashlib,subprocess,time,signal
R=Path('/tmp/fc-round80-controlled-repair');W=R/'checkout-52d6392-first';D=R/'native-build-first';assert not D.exists();assert (R/'.owner').read_bytes()==b'future-classroom-owned-r80-controlled-repair/v1\n';report=json.loads((R/'implementation-first/implementation-first.json').read_text());paths=['crates/fc-windows/src/installer_lifecycle.rs','crates/fc-windows/src/installer_lifecycle/native.rs','crates/fc-windows/src/installer_lifecycle/tests.rs','crates/fc-windows/src/installer_lifecycle/controlled.rs']
def facts():return [{'path':n,'bytes':len((W/n).read_bytes()),'sha256':hashlib.sha256((W/n).read_bytes()).hexdigest()} for n in paths]
before=facts();head=subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD']).decode().strip();assert head=='52d6392552679e7cedb564cd52db08e6e2ebc04b';D.mkdir();argv=['cargo','test','--release','--offline','--locked','-p','fc-windows','--all-targets','--target','i686-pc-windows-gnu','--target-dir',str(R/'target-first'),'--no-run','--message-format=json-render-diagnostics'];env=os.environ.copy();env['CARGO_BUILD_JOBS']='2';began=time.monotonic();p=subprocess.Popen(argv,cwd=W,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);expired=False
try:out,err=p.communicate(timeout=900)
except subprocess.TimeoutExpired:
 expired=True;os.killpg(p.pid,signal.SIGTERM)
 try:out,err=p.communicate(timeout=10)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);out,err=p.communicate()
(D/'cargo.stdout.jsonl').write_bytes(out);(D/'cargo.stderr.log').write_bytes(err);after=facts();rows=[]
for line in out.splitlines():
 try:j=json.loads(line)
 except (ValueError,UnicodeDecodeError):continue
 if j.get('reason')=='compiler-artifact' and j.get('executable'):
  f=Path(j['executable']);b=f.read_bytes();rows.append({'path':str(f),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'test':j['profile']['test'],'target':j['target']})
status='PASS_BUILD_ONLY_TARGET_RUNTIME_NOT_RUN' if p.returncode==0 and not expired and before==after else 'FAIL';r={'status':status,'actualExit':p.returncode,'originalParentReaped':p.poll() is not None,'budgetSeconds':900,'budgetExceeded':expired,'seconds':time.monotonic()-began,'argv':argv,'sourceBase':head,'sourcesBefore':before,'sourcesAfter':after,'sourceUnchanged':before==after,'outputs':rows,'stdout':{'bytes':len(out),'sha256':hashlib.sha256(out).hexdigest()},'stderr':{'bytes':len(err),'sha256':hashlib.sha256(err).hexdigest()},'runtime':'NOT_RUN','productionAdmission':False};(D/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':status,'actualExit':p.returncode,'seconds':r['seconds'],'reportSha256':hashlib.sha256((D/'report.json').read_bytes()).hexdigest(),'outputs':len(rows),'sourceUnchanged':before==after}));raise SystemExit(0 if status.startswith('PASS') else 1)
