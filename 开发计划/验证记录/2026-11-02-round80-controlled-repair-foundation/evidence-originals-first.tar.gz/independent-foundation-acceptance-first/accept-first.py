#!/usr/bin/env python3
"""Finite immutable foundation acceptance; no W source reads, Cargo or Windows."""
from pathlib import Path
import hashlib,json,re,subprocess
R=Path('/tmp/fc-round80-controlled-repair');A=R/'independent-foundation-acceptance-first';P=R/'foundation-archive-preparation-first';G=Path('/workspace/共享/Eliora/未来教室计划')
COMMIT='3e790e555a61a843e801000b371773a134df5c03';BASE='52d6392552679e7cedb564cd52db08e6e2ebc04b'
inputs={};checks=[]
def need(x,label):
 if not x:raise AssertionError(label)
def read(rel):
 p=R/rel;need(p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(R),'EXACT_OWNED_REGULAR');b=p.read_bytes();need(len(b)<=16*1024*1024,'FINITE_FILE');inputs[rel]={'path':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};return b
def j(rel):return json.loads(read(rel))
def eqfact(rel,row):
 b=read(rel);need(len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],'RAW_IDENTITY_'+rel)
def git(*args):return subprocess.check_output(['git','-C',str(G),*args],timeout=20)
def passed(label,**data):checks.append({'check':label,'status':'PASS',**data})
i=j('implementation-first/implementation-first.json');need(hashlib.sha256(read('implementation-first/implementation-first.json')).hexdigest()=='d05a5ebb5e175e47ee3e22826eb15b91cca6ca7abb3ae04cd48e238e41be9d16','FIXED_IMPLEMENTATION');sources=i['sources']
need(git('rev-parse',COMMIT+'^').decode().strip()==BASE,'FIXED_PARENT')
changed=git('diff-tree','--no-commit-id','--name-only','-r',COMMIT).decode().splitlines();need(set(changed)=={x['path'] for x in sources},'FOUR_FIXED_COMMIT_PATHS')
for s in sources:
 b=read('implementation-first/source/'+s['path']);need(len(b)==s['bytes'] and hashlib.sha256(b).hexdigest()==s['sha256'],'SOURCE_COPY');need(git('show',COMMIT+':'+s['path'])==b,'FIXED_GIT_BLOB_EQUALS_COPY')
eqfact('implementation-first/candidate-first.patch',i['patch']);c=j('foundation-source-commit-first.json');need(c['commit']==COMMIT and c['parent']==BASE and c['validatedSourceHashes']=={s['path']:s['sha256'] for s in sources},'COMMIT_RECEIPT');passed('four_fixed_commit_blobs_equal_source_copies_and_implementation',commit=COMMIT,parent=BASE,changedPaths=changed)
review=j('independent-source-review-first/review-first.json');need(review['blockingFindings']==[] and review['sources']==sources,'FIXED_SOURCE_REVIEW');rf=j('independent-source-review-first/freeze-first.json')
for f in rf['files']:eqfact('independent-source-review-first/'+f['path'],f)
passed('independent_private_foundation_review_bound',checks=len(review['checks']))
for d,status in [('native-build-first','PASS_BUILD_ONLY_TARGET_RUNTIME_NOT_RUN'),('strict-clippy-first','PASS_STRICT_CLIPPY_ONLY_TARGET_RUNTIME_NOT_RUN')]:
 q=j(d+'/report.json');need(q['status']==status and q['actualExit']==0 and q['originalParentReaped'] is True and q['budgetExceeded'] is False and q['sourceUnchanged'] is True and q['sourcesBefore']==q['sourcesAfter']==sources,'ACTUAL_BUILD_SOURCE_BOUND')
 eqfact(d+'/cargo.stdout.jsonl',q['stdout']);eqfact(d+'/cargo.stderr.log',q['stderr']);need('--release' in q['argv'] and 'i686-pc-windows-gnu' in q['argv'],'TARGET')
 if 'clippy' in d:need(q['argv'][-3:]==['--','-D','warnings'],'STRICT_WARNINGS')
 passed(d+'_actual_original_exit_and_raw_logs',actualExit=0,seconds=q['seconds'],scope=status)
build=j('native-build-first/report.json');need(len(build['outputs'])==1,'ONE_TEST_EXE');exe=build['outputs'][0]
r=j('native-runtime-first/report.json');need(r['status']=='PASS_CONTROLLED_REPAIR_FOUNDATION_NATIVE_TESTS_WIN11_ONLY' and r['candidateSourcesUnchanged'] is True and r['compiledExeUnchanged'] is True and r['sourceInputs']==sources,'RUNTIME_SOURCE_BINDING')
eqfact('native-build-first/report.json',r['producer']);need(r['nativeInput']['bytes']==exe['bytes'] and r['nativeInput']['sha256']==exe['sha256'],'BUILD_OUTPUT_BINDING');eqfact('native-reference-first/Capture.cs',r['capture'])
for op in r['operations']:
 need(op['actualReturnCode']==0 and op['originalLocalReaped'] is True and op['remoteOriginalReturnUnknown'] is False and op['budgetExceeded'] is False,'ORIGINAL_TRANSPORT_RETURN')
 for key in ['stdout','stderr']:
  rel=str(Path(op[key]['path']).relative_to(R));eqfact(rel,op[key])
root=j('root-native-runtime-operation-first.json');need(root['actualExit']==0 and root['originalLocalParentReaped'] is True and root['stderr']=='','ROOT_WRAPPER');ss=json.loads(root['stdout']);need(ss['sha256']==inputs['native-runtime-first/report.json']['sha256'],'ROOT_REPORT_SHA');need(root['sourceSha256']==hashlib.sha256(read('native-runtime-preparation-second/run-native.py')).hexdigest(),'ROOT_CONTROLLER_IDENTITY')
download=R/'native-runtime-first/download';roots=list(download.iterdir());need(len(roots)==1 and roots[0].is_dir() and not roots[0].is_symlink(),'ONE_DOWNLOAD_ROOT');localfiles={p.relative_to(roots[0]).as_posix() for p in roots[0].rglob('*') if p.is_file()};need(localfiles=={f['path'] for f in r['inventory']['files']},'COMPLETE_DOWNLOAD_SET')
for f in r['inventory']['files']:eqfact(str((roots[0]/f['path']).relative_to(R)),f)
v=j(str((roots[0]/'native-result.json').relative_to(R)));need(v==r['native']==j('native-runtime-first/run.stdout.log'),'ORIGINAL_NATIVE_REPLAY_IDENTICAL')
need(v['originalWholeSeconds']==600 and v['originalParentReturned'] is True and v['controlledNativeReturns']=='CFG_TEST_SYNTHETIC_BEGIN_END_OBSERVATIONS_ONLY' and v['productionMsiAdapter']=='NOT_EXERCISED','PRECISE_NATIVE_SCOPE')
need(len(v['originalObjects'])==2 and [x['name'] for x in v['cases']]==['controlled','lifecycle'],'TWO_ORIGINAL_PARENTS')
qualified=[]
for case,count in zip(v['cases'],[6,52]):
 cap=case['original'];need(cap in v['originalObjects'] and type(cap['Wait']) is int and cap['Wait']==0 and type(cap['ExitCode']) is int and cap['ExitCode']==case['exitCode']==0 and cap['ExitKnown'] is True and cap['CheckedClose'] is True and cap['Status']=='HELD_ORIGINAL_IDENTITY' and cap['Kind']=='process' and cap['Creation']>0 and cap['Pid']==case['pid'] and cap['Sha256']==exe['sha256'] and cap['Image']==r['windowsRoot']+'\\candidate-tests.exe' and cap['Sid']=='S-1-5-21-3896111207-1867804362-1971593122-1001','ACTUAL_ORIGINAL_PARENT_CAP')
 text=case['stdout'];need(case['stderr']=='' and case['actualExit'] is True,'NO_NATIVE_STDERR');summaries=re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text,re.M);need(summaries and tuple(map(int,summaries[-1][:4]))==(count,0,0,0),'FINAL_PARENT_SUMMARY_NOT_FIRST_NESTED')
 running=re.findall(r'^running (\d+) tests?$',text,re.M);need(int(running[0])==count,'OUTER_RUNNING_COUNT');need(case['endedWholeMilliseconds']<=case['originalDeadlineWholeMilliseconds'] and case['endedWholeMilliseconds']<600000,'ORIGINAL_CASE_DEADLINE')
 names=re.findall(r'^test (installer_lifecycle::tests::controlled_[A-Za-z0-9_]+) \.\.\. ok$',text,re.M);need(len(names)==6 and len(set(names))==6,'SIX_EXPECTED_TEST_LINES');qualified.append({'name':case['name'],'outerPassed':count,'failed':0,'ignored':0,'summaryCount':len(summaries),'nestedSummaries':len(summaries)-1,'originalPid':cap['Pid'],'originalExit':0,'checkedClose':True})
need(r['cleanup']=='PASS_EXACT_DOWNLOADED_OWNED_SCRATCH_ONLY' and r['delete']['knownAbsent'] is True and r['ownedProcessReadback']['count']==0,'ACTUAL_CLEANUP');passed('native_complete_download_original_parent_summary_and_cleanup',cases=qualified,downloadFiles=len(localfiles),countRule='52 includes6, do not sum',scope='Win11 gate regression and synthetic Begin/End observations; NOT actual production API adapter')
# Exact source preparation, unchanged PS chunks, known qualification/parse failure and original corrections.
for d,f in [('native-runtime-preparation-first','freeze-first.json'),('native-runtime-preparation-second','freeze-second.json')]:
 fr=j(d+'/'+f)
 for row in fr['files']:eqfact(d+'/'+row['path'],row)
for n in ['create.ps1','run.ps1','delete.ps1','boot.ps1']:need(read('native-runtime-preparation-first/'+n)==read('native-runtime-preparation-second/'+n),'UNCHANGED_PS_CHUNK')
parse=j('root-native-ps-parse-second.json');need(parse['actualExit']==0 and parse['parentReaped'] is True and parse['native']['mutations']=='NONE' and all(x['errors']==[] for x in parse['native']['rows']),'ACTUAL_PS_AST')
eqfact('root-native-ps-parse-second.stdout.log',{'bytes':parse['stdoutBytes'],'sha256':parse['stdoutSha256']});eqfact('root-native-ps-parse-second.stderr.log',{'bytes':parse['stderrBytes'],'sha256':parse['stderrSha256']})
failed=j('root-native-ps-parse-first-local-failure.json');need(failed['status']=='FAIL_LOCAL_CONSOLE_DECODE_NOT_A_WINDOWS_TEST' and failed['nativeExitCode']=='NOT_RECORDED','FIRST_UNKNOWN_PRESERVED')
hist=j('native-history-replay-first/report.json');need(hist['historicalExpected']==46 and hist['r80Actual52']=='NOT_CLAIMED_BY_REPLAY','HISTORICAL_SCOPE');eqfact('native-reference-first/r79-native-release-second-original-report.json',hist['historicalReport']);j('root-native-history-replay-first.json');passed('preparations_and_actual_ps_ast_and_historical46_replay_scopes_preserved')
for name in ['provenance-first.json','provenance-helper-second.json','provenance-audit-third.json','provenance-native-output-fourth.json']:
 q=j('native-reference-first/'+name)
 for row in q.get('files',[q]):
  dest=row.get('copiedName')
  if dest:eqfact('native-reference-first/'+dest,row)
for row in j('evidence-reference/reference-manifest.json'):eqfact('evidence-reference/'+row['copy'],row)
passed('copied_r79_references_bound_without_accessing_deleted_r79_root')
a=j('windows-readonly-final-first.json');need(inputs['windows-readonly-final-first.json']['sha256']=='a378b2be172aec6a0ed811ef17e71113bb8de07f1c30ee5918c6f9faf10346ca' and a['status']=='PASS' and a['scratchDirectories']==a['ownedProcesses']==a['ownedTasks']==[] and a['sshd']=='Running' and a['publicAuthorizationUnchanged'] is True and a['projectRunUnchanged'] is True and a['persistentKeyMode']=='0o600','FINAL_READONLY_AUDIT');ap=j('audit-preparation-first.json');need(hashlib.sha256(read('audit-windows-r80-first.py')).hexdigest()==ap['sha256'],'AUDIT_FIXED_SCRIPT');passed('final_readonly_win11_audit',scope='zero owned scratch/process/task, auth/Run unchanged, sshd running, key metadata only')
result={'schemaVersion':1,'status':'PASS_R80_FINITE_PRIVATE_FOUNDATION_COMMIT_BUILD_CLIPPY_WIN11_ACCEPTANCE','sourceCommit':COMMIT,'sourceBase':BASE,'inputs':list(inputs.values()),'checks':checks,'qualifiedScopes':{'controlled':6,'lifecycle':52,'scopeOverlap':'52 includes6; do not sum','Windows11':'ACTUAL_PASS','Windows7':'NOT_RUN','Windows10':'NOT_RUN','productionMsiAdapter':'NOT_EXERCISED','nativeBeginEndObservations':'CFG_TEST_SYNTHETIC'},'preservedFailures':['first parser rejected nested harness history until qualification corrected; both preparation sources and replay retained','first local console UTF8 decode failure lost its raw streams/native exit; UNKNOWN preserved, not upgraded by second AST PASS','audit reference owner marker backslash-n corrected to actual LF before actual execution; original copied reference and correction receipt preserved'],'productionAdmission':False,'fullGoalComplete':False,'sourceTreeRead':'NO_WORKTREE_SOURCE_READS; fixed Git objects and implementation source copies only','reviewerActions':{'Windows':False,'Cargo':False,'compile':False,'commit':False,'mainWrite':False,'archive':False,'delete':False,'keyRead':False},'errata':'An empty temporary file was briefly created at R root then immediately moved into this owned acceptance directory as .owner; no source, build, runtime or key payload was changed.'}
(A/'acceptance-first.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':result['status'],'checks':len(checks),'inputs':len(inputs),'sha256':hashlib.sha256((A/'acceptance-first.json').read_bytes()).hexdigest()}))
