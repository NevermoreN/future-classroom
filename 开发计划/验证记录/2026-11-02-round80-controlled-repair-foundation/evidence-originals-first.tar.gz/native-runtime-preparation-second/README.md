# R80 finite native regression preparation

Default `python3 -B run-native.py` is inert. Only root may explicitly execute:

```
python3 -B /tmp/fc-round80-controlled-repair/native-runtime-preparation-first/run-native.py --execute
```

The single fresh result directory is `/tmp/fc-round80-controlled-repair/native-runtime-first`.
An existing result directory is refused. This controller performs no Cargo build,
source edits, Git mutation or deployment. It uses the authorized SSH alias and
does not read the external SSH private key or touch the retained authorization.

Admission pins the original GNU release producer report, actual Cargo artifact
row/output bytes, HEAD52d6392 and the four original source facts before/after.
It also requires exactly the four expected worktree changes, original Capture.cs
and copied transport-helper hashes. The helper is loaded only for its immutable
COMMON, download verifier and exact DELETE definitions; its old main is never
called and no R79 path is opened.

The first hidden test process runs `installer_lifecycle::tests::controlled_`
with its original 150-second budget and must pass exactly six named tests. The
second runs `installer_lifecycle::` with its original 300-second budget and must
pass all 52 source-derived named tests. The latter includes the six controlled
tests and 11 effects tests; these counts must not be added together. All native
Begin/End observations in the new gate tests are explicitly cfg(test) synthetic
observations. The OS gate, original child/process return and fault-retention
paths are actual native regression coverage, not a production MSI API adapter.

Each original launched test-parent handle is duplicated, creation/image/hash/SID
checked, physically waited and exit-code checked from the same retained object,
then checked closed. Redirected pipes must return before the original per-case
deadline. The whole Windows phase remains 600 seconds and root transport 900
seconds; all waits consume those original budgets. There is no Windows process
kill, Type1 callback capture or budget renewal. A local transport timeout kills
only the local ssh/scp child and retains the unknown Windows state.

On full native PASS, the controller requires zero owned-image processes, captures
the complete bounded remote file/directory inventory, downloads all originals,
checks every path/byte/SHA and verifies downloaded native-result JSON equals the
original phase JSON. It then rechecks exactly that inventory and deletes only
the fresh marker-owned scratch. Any unknown or failure retains originals for
root's separate finite capture/cleanup; it never treats missing data as success.

PS AST chunks are literal COMMON+CREATE, COMMON+RUN and COMMON+DELETE plus the
transport BOOT expression. Root must parse these on the authorized Windows
PowerShell 5.1 before execution. Python qualification recognizes nested harness running/summary scopes: only original
parent depth-one starts are counted once for all required names, nested child
names and summaries remain diagnostic, and the final summary must be the original
parent exact 6/52 success. Any FAILED scope or incomplete parent is rejected.

Local preparation checks prove syntax of Python,
input/source identities, source test counts and default nonexecution only.
