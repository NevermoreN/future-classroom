"""Pure stdout qualification samples only. No Windows, Cargo or fixture process."""
from pathlib import Path
import json
import runpy

HERE=Path(__file__).resolve().parent
qualify=runpy.run_path(str(HERE/'run-native.py'),run_name='local_qualification_only')['qualify_harness']
plan=json.loads((HERE.parent/'native-runtime-preparation-first/execution-plan-first.json').read_text())
def summary(n,state='ok',failed=0):
    return f'test result: {state}. {n} passed; {failed} failed; 0 ignored; 0 measured; 233 filtered out; finished in 0.01s\n'
def fixture(names,nested=False):
    text=f'running {len(names)} tests\n'
    for i,name in enumerate(names):
        text+=f'test installer_lifecycle::tests::{name} ... '
        if nested and i<3:
            # This same basename also runs once in the original parent scope.
            text+='\nrunning 1 test\ntest installer_lifecycle::native::broker::tests::pipe_process_fixture_child ... ok\n\n'+summary(1)+'\nok\n'
        else:text+='ok\n'
    return text+'\n'+summary(len(names))
controlled=plan['controlledTestNames'];all_names=plan['lifecycleTestNames']
assert len(controlled)==6 and len(all_names)==52 and 'pipe_process_fixture_child' in all_names
out=[]
for label,text,names in [('six-flat',fixture(controlled),controlled),('full-flat',fixture(all_names),all_names),('full-nested-three-duplicate-child-names',fixture(all_names,True),all_names)]:
    r=qualify(text,names,len(names));assert r['outerTotals']['passed']==len(names);out.append({'case':label,'status':'PASS_EXPECTED_ACCEPT','facts':r})
full=fixture(all_names,True)
rejects={
 'missing-parent-final-summary':full.rsplit('test result:',1)[0],
 'wrong-final-parent-scope':full.rsplit('test result:',1)[0]+summary(1),
 'parent-real-failure':full.rsplit('test result:',1)[0]+summary(51,'FAILED',1),
 'nested-real-failure':full.replace(summary(1),summary(0,'FAILED',1),1),
 'duplicate-outer-start':full.replace('\n'+summary(52),'\ntest installer_lifecycle::tests::'+all_names[0]+' ... ok\n'+summary(52)),
 'missing-outer-start':full.replace('test installer_lifecycle::tests::'+all_names[-1]+' ... ok\n','',1),
 'wrong-initial-running':full.replace('running 52 tests','running 1 test',1),
}
for label,text in rejects.items():
    try:qualify(text,all_names,52)
    except AssertionError:out.append({'case':label,'status':'PASS_EXPECTED_REJECT'})
    else:raise AssertionError('incorrectly accepted '+label)
print(json.dumps({'status':'PASS_PURE_STDOUT_QUALIFICATION_SAMPLES_ONLY','windows':'NOT_RUN','cargo':'NOT_RUN','cases':out},indent=2))
