from pathlib import Path
import hashlib,json,base64,subprocess,time,runpy
R=Path('/tmp/fc-round80-controlled-repair');P=R/'password-cng-interop-preparation-first';O=R/'password-cng-interop-runtime-5a3702d9164859cd1efe6df65bd4b49e';f=O/'report.json'
assert hashlib.sha256(f.read_bytes()).hexdigest()=='470ea37eb4ef3eef767f6456718fbabe2001c6bde082f7dc3c4427983f836163'
r=json.loads(f.read_bytes());n=r['native'];assert r['completeDownloadVerified'] is True and n['originalParentReturned']is True and n['actualExit']==1 and n['status']=='FAIL_RETAIN';assert len(n['originalObjects'])==1
for x in n['originalObjects']:assert x['Wait']==0 and x['ExitKnown']is True and x['CheckedClose']is True and x['ExitCode']==1
m=runpy.run_path(str(P/'run-native.py'));m['verify_download'](O/'download'/r['windowsRoot'].replace('\\','/').split('/')[-1],r['inventory'])
c=dict(nonce=r['nonce'],root=r['windowsRoot'],sid=m['SID'],inventory=r['inventory'])
script="$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+(P/'Common.ps1').read_text()+(P/'Delete.ps1').read_text()
(R/'root-password-cng-first-failure-cleanup.stdin.ps1').write_text(script)
argv=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','future-classroom-win11','powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(m['BOOT'].encode('utf-16-le')).decode()]
t=time.monotonic();p=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);so,se=p.communicate(script.encode(),timeout=60)
(R/'root-password-cng-first-failure-cleanup.stdout.log').write_bytes(so);(R/'root-password-cng-first-failure-cleanup.stderr.log').write_bytes(se);result=json.loads(so);assert p.returncode==0 and result['knownAbsent']is True
out=dict(status='PASS_KNOWN_RETURNED_FAILED_PROBE_EXACT_SCRATCH_CLEANUP',originalFailureSha256=hashlib.sha256(f.read_bytes()).hexdigest(),failurePreserved=True,downloadReplayed=True,originalCases=0,cng='NOT_CALLED_PS5_ULONG_TYPE_NAME_REJECTED_BEFORE_CALL',originalActualExit=1,actualExit=p.returncode,originalLocalReaped=p.poll()is not None,seconds=time.monotonic()-t,result=result)
(R/'root-password-cng-first-failure-cleanup.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
