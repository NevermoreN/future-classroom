$c='{"nonce":"182309509a8e143e3875f8023edf1049","sid":"S-1-5-21-3896111207-1867804362-1971593122-1001","root":"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r80-password-cng-182309509a8e143e3875f8023edf1049","inputs":[{"name":"Capture.cs","bytes":6527,"sha256":"e687c76e4b45c478ec1daaa62565e4ac293b1e76424727653c9d33fe47e2886a"},{"name":"CngProbe.cs","bytes":1847,"sha256":"9089fc35358f6ffa2008fa5d861139a94a40ad6638d43feb0ae8314aa3f8d407"},{"name":"Probe.ps1","bytes":2017,"sha256":"a4de6b79905d7c13e92c662b0fa74d07d9bde05dcf249b5a3061bf05ff3e20a1"},{"name":"expected.json","bytes":1901,"sha256":"6ce4a7e264b9b92b77a301c873b284d668dfd3da6d4fd2cf9f036c331a80d2b0"},{"name":"fixtures.json","bytes":2372,"sha256":"36c603da5c699a67e5211499edfafc1ae2af8c69fd591469d8895af440b50a0c"}]}'|ConvertFrom-Json;$ErrorActionPreference='Stop';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function RootPath {return Join-Path ([IO.Path]::GetFullPath($env:TEMP)) ('FutureClassroom-r80-password-cng-'+$c.nonce)}
function Fact($p){$a=[IO.File]::GetAttributes($p);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0 -or ($a-band[IO.FileAttributes]::Directory)-ne0){throw 'REGULAR_NO_REPARSE'};return @{bytes=[long]([IO.FileInfo]::new($p).Length);sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function CheckRoot($root){if($root-cne$c.root -or [IO.Path]::GetFileName($root)-cne('FutureClassroom-r80-password-cng-'+$c.nonce)){throw 'EXACT_ROOT'};$a=[IO.File]::GetAttributes($root);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0){throw 'ROOT_REPARSE'};if([IO.File]::ReadAllText((Join-Path $root '.owner'))-cne"future-classroom-owned-r80-password-cng-runtime/v1`n"){throw 'OWNER_MARKER'};$acl=[IO.Directory]::GetAccessControl($root);if(-not$acl.AreAccessRulesProtected -or $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-cne$c.sid){throw 'EXACT_PROTECTED_OWNER'};$rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));if($rules.Count-ne2 -or @($rules|Where-Object{$_.IdentityReference.Value-notin@($c.sid,'S-1-5-18') -or $_.AccessControlType-ne'Allow' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count){throw 'ONLY_USER_SYSTEM_DACL'}}
function Inventory($root){CheckRoot $root;$files=@();$dirs=@();$q=[Collections.Generic.Queue[string]]::new();$q.Enqueue($root);while($q.Count){$dir=$q.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){$a=[IO.File]::GetAttributes($p);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0){throw 'INVENTORY_REPARSE'};$rel=$p.Substring($root.Length+1).Replace('\','/');if(($a-band[IO.FileAttributes]::Directory)-ne0){$dirs+=$rel;$q.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256}};if($files.Count-gt128 -or $dirs.Count-gt16){throw 'INVENTORY_BOUND'}}};return @{files=$files;directories=$dirs}}
CheckRoot $c.root;$root=$c.root
foreach($x in $c.inputs){$f=Fact (Join-Path $root $x.name);if($f.bytes-ne$x.bytes-or$f.sha256-cne$x.sha256){throw 'INPUT_BYTES'}}
$oldTemp=$env:TEMP;$oldTmp=$env:TMP;$capture=$null;$p=$null;$started=$false;$returned=$true;$clock=[Diagnostics.Stopwatch]::StartNew()
$r=@{status='FAIL_RETAIN';scope='INDEPENDENT_WIN11_CNG_PBKDF2_FOUR_PUBLIC_SYNTHETIC_VECTORS';installer='NOT_EXERCISED';userData='NOT_TOUCHED';nativeBudgetMilliseconds=180000}
try{
 $env:TEMP=Join-Path $root 'compiler-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP);Add-Type -Path (Join-Path $root 'Capture.cs') -ErrorAction Stop
 $capture=[Fc79Capture]::new();$r.foregroundBefore=[FcR06Foreground]::Get()
 $exe=Join-Path $PSHOME 'powershell.exe';$exeFact=Fact $exe;$r.systemPowerShell=@{path=$exe;bytes=$exeFact.bytes;sha256=$exeFact.sha256}
 $child='$ErrorActionPreference=''Stop'';& ([ScriptBlock]::Create([IO.File]::ReadAllText('+"'"+(Join-Path $root 'Probe.ps1')+"'"+'))) -Root '+"'"+$root+"'"
 $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$exe;$info.Arguments='-NoProfile -NonInteractive -EncodedCommand '+[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($child));$info.WorkingDirectory=$root;$info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
 $p=[Diagnostics.Process]::new();$p.StartInfo=$info
 if(-not$p.Start()){throw 'START'};$started=$true;$returned=$false;$r.pid=$p.Id;$r.creation=$p.StartTime.ToUniversalTime().ToFileTimeUtc()
 $stdout=$p.StandardOutput.ReadToEndAsync();$stderr=$p.StandardError.ReadToEndAsync()
 $r.original=$capture.HoldStartedClient($p.Handle,[uint32]$p.Id,[long]$r.creation,$exe,$exeFact.sha256,$c.sid)
 $left=[int](180000-$clock.ElapsedMilliseconds);if($left-le0-or-not$p.WaitForExit($left)){throw 'ORIGINAL_PARENT_UNKNOWN_RETAIN_NO_KILL'}
 $returned=$true;$p.Refresh();$r.actualExit=$p.ExitCode
 if(-not[Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($stdout,$stderr),[int][Math]::Max(0,180000-$clock.ElapsedMilliseconds))){throw 'ORIGINAL_PIPES_UNKNOWN'}
 $r.stdout=$stdout.Result;$r.stderr=$stderr.Result;[IO.File]::WriteAllText((Join-Path $root 'cng.stdout.log'),$r.stdout,[Text.UTF8Encoding]::new($false));[IO.File]::WriteAllText((Join-Path $root 'cng.stderr.log'),$r.stderr,[Text.UTF8Encoding]::new($false))
 [void]$capture.Snapshot();if($r.original.Wait-ne0-or-not$r.original.ExitKnown-or$r.original.ExitCode-ne$r.actualExit){throw 'ORIGINAL_RETURN_MISMATCH'}
 $p.Dispose();$p=$null
 if($r.actualExit-ne0){throw 'CNG_ACTUAL_NONZERO'}
 $r.cng=$r.stdout|ConvertFrom-Json;if($r.cng.status-cne'PASS_CNG_FOUR_SYNTHETIC_PRODUCTION_600000'){throw 'EXACT_CHILD_STATUS'}
 $r.foregroundAfter=[FcR06Foreground]::Get();$r.status='PASS_WIN11_CNG_INTEROP_FOUR'
}catch{$r.error=$_.Exception.Message}finally{
 $env:TEMP=$oldTemp;$env:TMP=$oldTmp
 if($null-ne$p-and(-not$started-or$returned)){$p.Dispose()}
 if($null-ne$capture){try{if($returned){$r.originalObjects=@($capture.FinishAndClose())}else{$r.originalObjects=@($capture.Snapshot())}}catch{$r.status='FAIL_RETAIN';$r.closeError=$_.Exception.Message}}
 $r.originalParentReturned=$returned;$r.elapsedMilliseconds=$clock.ElapsedMilliseconds
 if($clock.ElapsedMilliseconds-ge180000){$r.status='FAIL_RETAIN';$r.budgetExceeded=$true}
 [IO.File]::WriteAllText((Join-Path $root 'native-result.json'),($r|ConvertTo-Json -Depth 30),[Text.UTF8Encoding]::new($false))
}
$r|ConvertTo-Json -Depth 30 -Compress
if($r.status-cne'PASS_WIN11_CNG_INTEROP_FOUR'){$global:LASTEXITCODE=1}
