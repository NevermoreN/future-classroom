from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent;O=P.parent/'r06-native-preparation-first'
for n in ('Common.ps1','Create.ps1','Delete.ps1'):
 text=(O/n).read_text().replace('FutureClassroom-r80-r06-native-','FutureClassroom-r80-password-cng-').replace('future-classroom-owned-r80-r06-native-runtime/v1','future-classroom-owned-r80-password-cng-runtime/v1').replace('REMOVED_EXACT_R06_NATIVE_RUNTIME_ROOT','REMOVED_EXACT_PASSWORD_CNG_RUNTIME_ROOT');(P/n).write_text(text)
(P/'Capture.cs').write_bytes((O/'Capture.cs').read_bytes())
(P/'CngProbe.cs').write_text(r'''// Independent acceptance probe only. All inputs are public synthetic vectors.
using System;
using System.Runtime.InteropServices;
public static class FcPasswordCngProbe {
 [DllImport("bcrypt.dll",ExactSpelling=true,CharSet=CharSet.Unicode)]
 static extern int BCryptOpenAlgorithmProvider(out IntPtr algorithm,string id,string provider,uint flags);
 [DllImport("bcrypt.dll",ExactSpelling=true)]
 static extern int BCryptDeriveKeyPBKDF2(IntPtr algorithm,[In] byte[] password,uint passwordBytes,[In] byte[] salt,uint saltBytes,ulong iterations,[Out] byte[] output,uint outputBytes,uint flags);
 [DllImport("bcrypt.dll",ExactSpelling=true)] static extern int BCryptCloseAlgorithmProvider(IntPtr algorithm,uint flags);
 public sealed class Result { public int OpenStatus,DeriveStatus,CloseStatus;public bool Opened,Derived,CloseAttempted,CheckedClose;public string VerifierHex; }
 public static Result Derive(byte[] password,byte[] salt,ulong iterations) {
  Result r=new Result();r.OpenStatus=r.DeriveStatus=r.CloseStatus=unchecked((int)0xc0000001);IntPtr algorithm=IntPtr.Zero;byte[] output=new byte[32];
  try {
   r.OpenStatus=BCryptOpenAlgorithmProvider(out algorithm,"SHA256","Microsoft Primitive Provider",8);
   r.Opened=r.OpenStatus==0 && algorithm!=IntPtr.Zero;if(!r.Opened)return r;
   r.DeriveStatus=BCryptDeriveKeyPBKDF2(algorithm,password,checked((uint)password.Length),salt,checked((uint)salt.Length),iterations,output,32,0);
   r.Derived=r.DeriveStatus==0;if(r.Derived)r.VerifierHex=BitConverter.ToString(output).Replace("-","").ToLowerInvariant();return r;
  } finally {
   if(algorithm!=IntPtr.Zero){r.CloseAttempted=true;r.CloseStatus=BCryptCloseAlgorithmProvider(algorithm,0);r.CheckedClose=r.CloseStatus==0;}
   Array.Clear(output,0,output.Length);Array.Clear(password,0,password.Length);Array.Clear(salt,0,salt.Length);
  }
 }
}
''')
(P/'Probe.ps1').write_text(r'''param([Parameter(Mandatory=$true)][string]$Root)
$ErrorActionPreference='Stop';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$r=@{status='FAIL_CNG_INTEROP';cases=@();algorithm='SHA256-HMAC';provider='Microsoft Primitive Provider';iterations=600000;derivedBytes=32;testOnly='PUBLIC_SYNTHETIC_FIXTURES';os=[Environment]::OSVersion.VersionString;processBits=[IntPtr]::Size*8}
try{
 Add-Type -Path (Join-Path $Root 'CngProbe.cs') -ErrorAction Stop
 $fixtures=[IO.File]::ReadAllText((Join-Path $Root 'fixtures.json'))|ConvertFrom-Json
 $expected=[IO.File]::ReadAllText((Join-Path $Root 'expected.json'))|ConvertFrom-Json
 if($fixtures.cases.Count-ne4 -or $expected.cases.Count-ne4){throw 'EXACT_FOUR'}
 foreach($case in $fixtures.cases){
  $want=@($expected.cases|Where-Object{$_.id-ceq$case.id});if($want.Count-ne1){throw 'EXACT_CASE'}
  $bytes=[Text.UTF8Encoding]::new($false,$true).GetBytes([string]$case.password)
  $salt=[byte[]]::new(32);for($i=0;$i-lt32;$i++){$salt[$i]=[Convert]::ToByte($case.saltHex.Substring($i*2,2),16)}
  $utf8Bytes=$bytes.Length;$native=[FcPasswordCngProbe]::Derive($bytes,$salt,[ulong]600000)
  $row=@{id=$case.id;utf8Bytes=$utf8Bytes;openStatus=$native.OpenStatus;deriveStatus=$native.DeriveStatus;closeStatus=$native.CloseStatus;opened=$native.Opened;derived=$native.Derived;closeAttempted=$native.CloseAttempted;checkedClose=$native.CheckedClose;verifierHex=$native.VerifierHex;rustMatch=($native.VerifierHex-ceq$want[0].verifierHex)};$r.cases+=,$row
  if(-not$row.opened-or-not$row.derived-or-not$row.closeAttempted-or-not$row.checkedClose-or-not$row.rustMatch-or$utf8Bytes-ne$want[0].utf8Bytes){throw 'CNG_RESULT_OR_ORIGINAL_CLOSE'}
 }
 $r.status='PASS_CNG_FOUR_SYNTHETIC_PRODUCTION_600000'
}catch{$r.error=$_.Exception.Message}
[IO.File]::WriteAllText((Join-Path $Root 'cng-result.json'),($r|ConvertTo-Json -Depth 16),[Text.UTF8Encoding]::new($false));$r|ConvertTo-Json -Depth 16 -Compress
if($r.status-ceq'PASS_CNG_FOUR_SYNTHETIC_PRODUCTION_600000'){exit 0}else{exit 1}
''')
(P/'Run.ps1').write_text(r'''CheckRoot $c.root;$root=$c.root
foreach($x in $c.inputs){$f=Fact (Join-Path $root $x.name);if($f.bytes-ne$x.bytes-or$f.sha256-cne$x.sha256){throw 'INPUT_BYTES'}}
$oldTemp=$env:TEMP;$oldTmp=$env:TMP;$capture=$null;$p=$null;$started=$false;$returned=$true;$clock=[Diagnostics.Stopwatch]::StartNew()
$r=@{status='FAIL_RETAIN';scope='INDEPENDENT_WIN11_CNG_PBKDF2_FOUR_PUBLIC_SYNTHETIC_VECTORS';installer='NOT_EXERCISED';userData='NOT_TOUCHED';nativeBudgetMilliseconds=180000}
try{
 $env:TEMP=Join-Path $root 'compiler-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP);Add-Type -Path (Join-Path $root 'Capture.cs') -ErrorAction Stop
 $capture=[Fc79Capture]::new();$r.foregroundBefore=[FcR06Foreground]::Get()
 $exe=Join-Path $PSHOME 'powershell.exe';$exeFact=Fact $exe;$r.systemPowerShell=@{path=$exe;bytes=$exeFact.bytes;sha256=$exeFact.sha256}
 $child='$ErrorActionPreference=''Stop'';& ([ScriptBlock]::Create([IO.File]::ReadAllText('+"'"+(Join-Path $root 'Probe.ps1')+"'"+'))) -Root '+"'"+$root+"'"
 $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$exe;$info.Arguments='-NoProfile -NonInteractive -EncodedCommand '+[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($child));$info.WorkingDirectory=$root;$info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
 $p=[Diagnostics.Process]::new();$p.StartInfo=$info
 if(-not$p.Start()){throw 'START'};$started=$true;$returned=$false;$r.pid=$p.Id;$r.creation=$p.StartTime.ToUniversalTime().ToFileTimeUtc()
 $stdout=$p.StandardOutput.ReadToEndAsync();$stderr=$p.StandardError.ReadToEndAsync()
 $r.original=$capture.HoldStartedClient($p.Handle,[uint32]$p.Id,[long]$r.creation,$exe,$exeFact.sha256,$c.sid)
 $left=[int](180000-$clock.ElapsedMilliseconds);if($left-le0-or-not$p.WaitForExit($left)){throw 'ORIGINAL_PARENT_UNKNOWN_RETAIN_NO_KILL'}
 $returned=$true;$p.Refresh();$r.actualExit=$p.ExitCode
 if(-not[Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($stdout,$stderr),[int][Math]::Max(0,180000-$clock.ElapsedMilliseconds))){throw 'ORIGINAL_PIPES_UNKNOWN'}
 $r.stdout=$stdout.Result;$r.stderr=$stderr.Result;[IO.File]::WriteAllText((Join-Path $root 'cng.stdout.log'),$r.stdout,[Text.UTF8Encoding]::new($false));[IO.File]::WriteAllText((Join-Path $root 'cng.stderr.log'),$r.stderr,[Text.UTF8Encoding]::new($false))
 [void]$capture.Snapshot();if($r.original.Wait-ne0-or-not$r.original.ExitKnown-or$r.original.ExitCode-ne$r.actualExit){throw 'ORIGINAL_RETURN_MISMATCH'}
 $p.Dispose();$p=$null
 if($r.actualExit-ne0){throw 'CNG_ACTUAL_NONZERO'}
 $r.cng=$r.stdout|ConvertFrom-Json;if($r.cng.status-cne'PASS_CNG_FOUR_SYNTHETIC_PRODUCTION_600000'){throw 'EXACT_CHILD_STATUS'}
 $r.foregroundAfter=[FcR06Foreground]::Get();$r.status='PASS_WIN11_CNG_INTEROP_FOUR'
}catch{$r.error=$_.Exception.Message}finally{
 $env:TEMP=$oldTemp;$env:TMP=$oldTmp
 if($null-ne$p-and(-not$started-or$returned)){$p.Dispose()}
 if($null-ne$capture){try{if($returned){$r.originalObjects=@($capture.FinishAndClose())}else{$r.originalObjects=@($capture.Snapshot())}}catch{$r.status='FAIL_RETAIN';$r.closeError=$_.Exception.Message}}
 $r.originalParentReturned=$returned;$r.elapsedMilliseconds=$clock.ElapsedMilliseconds
 if($clock.ElapsedMilliseconds-ge180000){$r.status='FAIL_RETAIN';$r.budgetExceeded=$true}
 [IO.File]::WriteAllText((Join-Path $root 'native-result.json'),($r|ConvertTo-Json -Depth 30),[Text.UTF8Encoding]::new($false))
}
$r|ConvertTo-Json -Depth 30 -Compress
if($r.status-cne'PASS_WIN11_CNG_INTEROP_FOUR'){$global:LASTEXITCODE=1}
''')
(P/'official-api-references.json').write_text(json.dumps({'sources':[{'url':'https://learn.microsoft.com/en-us/windows/win32/api/bcrypt/nf-bcrypt-bcryptderivekeypbkdf2','facts':['Password and salt lengths are bytes','ULONGLONG iteration count','dwFlags zero','Minimum supported client Windows 7; documentation only, not actual Win7 runtime']},{'url':'https://learn.microsoft.com/en-us/windows/win32/api/bcrypt/nf-bcrypt-bcryptopenalgorithmprovider','facts':['SHA256 HMAC algorithm handle','Explicit Microsoft Primitive Provider','Open handle must be closed']},{'url':'https://learn.microsoft.com/en-us/windows/win32/api/bcrypt/nf-bcrypt-bcryptclosealgorithmprovider','facts':['Close actual original provider once; success status zero']},{'url':'https://source.dot.net/System.Security.Cryptography/src/runtime/src/libraries/Common/src/Interop/Windows/BCrypt/Cng.cs.html','facts':['BCRYPT_ALG_HANDLE_HMAC_FLAG numeric value 0x00000008']}],'implementation':'Test-only P/Invoke probe, no change to production cryptography or production unsafe-code rule'},indent=2)+'\n')
print('PREPARED_SYNTHETIC_CNG_PROBE_NO_WINDOWS')
