from pathlib import Path
import hashlib,json,os,subprocess,time
P=Path(__file__).resolve().parent
W=P.parent/'checkout-abi2-upgrade-final-first'
D=P/'host-first';D.mkdir();Q=D/'probe';(Q/'src').mkdir(parents=True)
def fact(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=True,indent=2)+'\n')
fixtures=[dict(id='chinese-existing',password='中文口令至少十二个汉字用以测试',saltHex='01'*32),dict(id='ascii-sequence',password='Synthetic-Test-2026',saltHex=bytes(range(32)).hex()),dict(id='unicode-max-512',password='\U0001f642'*128,saltHex='ff'*32),dict(id='combining-and-nul',password='Cafe\u0301\0Test12345',saltHex='800001ff'*8)]
write(P/'fixtures.json',{'classification':'PUBLIC_SYNTHETIC_TEST_FIXTURES_NO_REAL_ACCOUNT_OR_SECRET','cases':fixtures})
manifest='[package]\nname="fc-password-cng-interop-probe"\nversion="0.0.0"\nedition="2021"\npublish=false\n[workspace]\n[dependencies]\nfc-security={path='+json.dumps(str(W/'crates/fc-security'))+'}\nfc-ports={path='+json.dumps(str(W/'crates/fc-ports'))+'}\nserde_json="=1.0.145"\n'
(Q/'Cargo.toml').write_text(manifest)
rust='''use fc_ports::RandomPort;
use fc_security::{Password,create_password_record,verify_password,PBKDF2_ITERATIONS};
struct FixtureRandom { salt:[u8;32], calls:usize }
impl RandomPort for FixtureRandom { type Error=(); fn fill(&mut self,out:&mut[u8])->Result<(),()> { assert_eq!(out.len(),32); assert_eq!(self.calls,0); self.calls+=1;out.copy_from_slice(&self.salt);Ok(()) } }
fn hex(x:&[u8])->String{x.iter().map(|b|format!("{b:02x}")).collect()}
fn main(){let value:serde_json::Value=serde_json::from_str(include_str!("../../fixtures-copy.json")).unwrap();
 for case in value["cases"].as_array().unwrap(){
 let id=case["id"].as_str().unwrap();let text=case["password"].as_str().unwrap();let raw=case["saltHex"].as_str().unwrap();
 let mut salt=[0u8;32];for(i,v)in salt.iter_mut().enumerate(){*v=u8::from_str_radix(&raw[2*i..2*i+2],16).unwrap();}
 let mut rng=FixtureRandom{salt,calls:0};let password=Password::new(text.to_owned()).unwrap();let record=create_password_record(&password,&mut rng).unwrap();
 assert_eq!(record.iterations(),600_000);assert_eq!(PBKDF2_ITERATIONS,600_000);assert_eq!(record.format(),1);assert_eq!(rng.calls,1);assert_eq!(record.salt(),&salt);
 let correct=verify_password(&password,&record).unwrap();let wrong=verify_password(&Password::new("Wrong-Synthetic-2026".into()).unwrap(),&record).unwrap();assert!(correct&&!wrong);
 println!("{}",serde_json::json!({"id":id,"utf8Bytes":text.len(),"unicodeScalars":text.chars().count(),"format":record.format(),"iterations":record.iterations(),"saltHex":hex(record.salt()),"verifierHex":hex(record.verifier()),"correctVerified":correct,"wrongVerified":wrong,"randomFillCalls":rng.calls}));
 }}
'''
(Q/'src/main.rs').write_text(rust)
(D/'fixtures-copy.json').write_bytes((P/'fixtures.json').read_bytes())
# Exactly the production crates reachable through the two path dependencies.
def inventory():
 files=[W/'Cargo.toml',W/'Cargo.lock',W/'rust-toolchain.toml']
 for name in ('fc-domain','fc-ports','fc-security'):
  files += [x for x in (W/'crates'/name).rglob('*') if x.is_file() and (x.suffix=='.rs' or x.name=='Cargo.toml')]
 return [fact(x) for x in sorted(files)]
r=dict(status='RUNNING',sourceCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),sourceBefore=inventory(),scope='Actual production fc-security create_password_record/verify_password with fixed synthetic RandomPort; no production changes; host is not Windows runtime',commands=[])
write(D/'report.json',r)
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(D/'target'),CARGO_BUILD_JOBS='2',CARGO_TERM_COLOR='never')
commands=[('lock',['cargo','generate-lockfile','--offline']),('metadata',['cargo','metadata','--offline','--locked','--format-version','1']),('build',['cargo','build','--release','--offline','--locked','--message-format=json']),('run',[str(D/'target/release/fc-password-cng-interop-probe')])]
for label,argv in commands:
 t=time.monotonic()
 with (D/(label+'.stdout.log')).open('xb')as so,(D/(label+'.stderr.log')).open('xb')as se:
  proc=subprocess.Popen(argv,cwd=Q,env=env,stdout=so,stderr=se);code=proc.wait(timeout=600)
 r['commands'].append(dict(label=label,argv=argv,actualExit=code,originalReaped=proc.poll() is not None,seconds=time.monotonic()-t,stdout=fact(D/(label+'.stdout.log')),stderr=fact(D/(label+'.stderr.log'))));write(D/'report.json',r);print(label,code,flush=True)
 if code:raise SystemExit(code)
metadata=json.loads((D/'metadata.stdout.log').read_bytes());locals=[x for x in metadata['packages']if x['source']is None];assert {x['name']for x in locals}=={'fc-password-cng-interop-probe','fc-security','fc-ports','fc-domain'}
rows=[json.loads(x)for x in(D/'run.stdout.log').read_text().splitlines()];assert len(rows)==len(fixtures)==4
for a,b in zip(fixtures,rows):
 assert a['id']==b['id'] and a['saltHex']==b['saltHex'] and b['iterations']==600000 and b['format']==1 and b['correctVerified'] is True and b['wrongVerified'] is False and b['randomFillCalls']==1
 expected=hashlib.pbkdf2_hmac('sha256',a['password'].encode('utf-8'),bytes.fromhex(a['saltHex']),600000,32).hex();assert expected==b['verifierHex'];b['pythonOpenSslMatches']=True
assert rows[0]['verifierHex']=='44cca2634e314a690a713b4aa3229b1bacb74941e6e44c548672e7b199e604e4'
assert rows[2]['utf8Bytes']==512 and rows[2]['unicodeScalars']==128
r.update(sourceAfter=inventory(),cases=rows,pythonOpenSsl='4 actual independent pbkdf2_hmac calls at 600000 rounds',probeBinary=fact(D/'target/release/fc-password-cng-interop-probe'),probeSources=[fact(Q/'Cargo.toml'),fact(Q/'Cargo.lock'),fact(Q/'src/main.rs'),fact(D/'fixtures-copy.json')])
assert r['sourceBefore']==r['sourceAfter'];r['sourceUnchanged']=True;r['status']='PASS_HOST_PRODUCTION_RUST_AND_PYTHON4_WINDOWS_NOT_RUN';write(D/'report.json',r);write(P/'expected.json',{'scope':'Actual production Rust at 600000 rounds and Python OpenSSL cross-check; public synthetic fixtures only','cases':rows});print(r['status'],flush=True)
