CheckRoot $c.root;$root=$c.root
foreach($x in $c.inputs){$f=Fact (Join-Path $root $x.name);if($f.bytes-ne$x.bytes-or$f.sha256-cne$x.sha256){throw 'INPUT_BYTES'}}
$oldTemp=$env:TEMP;$oldTmp=$env:TMP;$capture=$null;$p=$null;$started=$false;$returned=$true;$clock=[Diagnostics.Stopwatch]::StartNew()
$r=@{status='FAIL_RETAIN';scope='INDEPENDENT_WIN11_CNG_PBKDF2_FOUR_PUBLIC_SYNTHETIC_VECTORS';installer='NOT_EXERCISED';userData='NOT_TOUCHED';nativeBudgetMilliseconds=180000}
try{
 $env:TEMP=Join-Path $root 'compiler-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP);Add-Type -Path (Join-Path $root 'Capture.cs') -ErrorAction Stop
 $capture=[Fc79Capture]::new();$r.foregroundBefore=[FcR06Foreground]::Get()
 $exe=Join-Path $PSHOME 'powershell.exe';$exeFact=Fact $exe;$r.systemPowerShell=@{path=$exe;bytes=$exeFact.bytes;sha256=$exeFact.sha256}
 $child='$ErrorActionPreference=''Stop'';& ([ScriptBlock]::Create([IO.File]::ReadAllText('+"'"+(Join-Path $root 'Probe.ps1')+"'"+'))) -Root '+"'"+$root+"'"
 $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$exe;$info.Arguments='-NoProfile -NonInteractive -EncodedCommand '+[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($child));$info.WorkingDirectory=$root;$info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
 $p=[Diagnostics.Process]::new();$p.StartInfo=$info
 if(-not$p.Start()){throw 'START'};$started=$true;$returned=$false;$r.pid=$p.Id;$r.creation=$p.StartTime.ToUniversalTime().ToFileTimeUtc()
 $stdout=$p.StandardOutput.ReadToEndAsync();$stderr=$p.StandardError.ReadToEndAsync()
 $r.original=$capture.HoldStartedClient($p.Handle,[uint32]$p.Id,[long]$r.creation,$exe,$exeFact.sha256,$c.sid)
 $left=[int](180000-$clock.ElapsedMilliseconds);if($left-le0-or-not$p.WaitForExit($left)){throw 'ORIGINAL_PARENT_UNKNOWN_RETAIN_NO_KILL'}
 $returned=$true;$p.Refresh();$r.actualExit=$p.ExitCode
 if(-not[Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($stdout,$stderr),[int][Math]::Max(0,180000-$clock.ElapsedMilliseconds))){throw 'ORIGINAL_PIPES_UNKNOWN'}
 $r.stdout=$stdout.Result;$r.stderr=$stderr.Result;[IO.File]::WriteAllText((Join-Path $root 'cng.stdout.log'),$r.stdout,[Text.UTF8Encoding]::new($false));[IO.File]::WriteAllText((Join-Path $root 'cng.stderr.log'),$r.stderr,[Text.UTF8Encoding]::new($false))
 [void]$capture.Snapshot();if($r.original.Wait-ne0-or-not$r.original.ExitKnown-or$r.original.ExitCode-ne$r.actualExit){throw 'ORIGINAL_RETURN_MISMATCH'}
 $p.Dispose();$p=$null
 if($r.actualExit-ne0){throw 'CNG_ACTUAL_NONZERO'}
 $r.cng=$r.stdout|ConvertFrom-Json;if($r.cng.status-cne'PASS_CNG_FOUR_SYNTHETIC_PRODUCTION_600000'){throw 'EXACT_CHILD_STATUS'}
 $r.foregroundAfter=[FcR06Foreground]::Get();$r.status='PASS_WIN11_CNG_INTEROP_FOUR'
}catch{$r.error=$_.Exception.Message}finally{
 $env:TEMP=$oldTemp;$env:TMP=$oldTmp
 if($null-ne$p-and(-not$started-or$returned)){$p.Dispose()}
 if($null-ne$capture){try{if($returned){$r.originalObjects=@($capture.FinishAndClose())}else{$r.originalObjects=@($capture.Snapshot())}}catch{$r.status='FAIL_RETAIN';$r.closeError=$_.Exception.Message}}
 $r.originalParentReturned=$returned;$r.elapsedMilliseconds=$clock.ElapsedMilliseconds
 if($clock.ElapsedMilliseconds-ge180000){$r.status='FAIL_RETAIN';$r.budgetExceeded=$true}
 [IO.File]::WriteAllText((Join-Path $root 'native-result.json'),($r|ConvertTo-Json -Depth 30),[Text.UTF8Encoding]::new($false))
}
$r|ConvertTo-Json -Depth 30 -Compress
if($r.status-cne'PASS_WIN11_CNG_INTEROP_FOUR'){$global:LASTEXITCODE=1}
