use fc_ports::RandomPort;
use fc_security::{Password,create_password_record,verify_password,PBKDF2_ITERATIONS};
struct FixtureRandom { salt:[u8;32], calls:usize }
impl RandomPort for FixtureRandom { type Error=(); fn fill(&mut self,out:&mut[u8])->Result<(),()> { assert_eq!(out.len(),32); assert_eq!(self.calls,0); self.calls+=1;out.copy_from_slice(&self.salt);Ok(()) } }
fn hex(x:&[u8])->String{x.iter().map(|b|format!("{b:02x}")).collect()}
fn main(){let value:serde_json::Value=serde_json::from_str(include_str!("../../fixtures-copy.json")).unwrap();
 for case in value["cases"].as_array().unwrap(){
 let id=case["id"].as_str().unwrap();let text=case["password"].as_str().unwrap();let raw=case["saltHex"].as_str().unwrap();
 let mut salt=[0u8;32];for(i,v)in salt.iter_mut().enumerate(){*v=u8::from_str_radix(&raw[2*i..2*i+2],16).unwrap();}
 let mut rng=FixtureRandom{salt,calls:0};let password=Password::new(text.to_owned()).unwrap();let record=create_password_record(&password,&mut rng).unwrap();
 assert_eq!(record.iterations(),600_000);assert_eq!(PBKDF2_ITERATIONS,600_000);assert_eq!(record.format(),1);assert_eq!(rng.calls,1);assert_eq!(record.salt(),&salt);
 let correct=verify_password(&password,&record).unwrap();let wrong=verify_password(&Password::new("Wrong-Synthetic-2026".into()).unwrap(),&record).unwrap();assert!(correct&&!wrong);
 println!("{}",serde_json::json!({"id":id,"utf8Bytes":text.len(),"unicodeScalars":text.chars().count(),"format":record.format(),"iterations":record.iterations(),"saltHex":hex(record.salt()),"verifierHex":hex(record.verifier()),"correctVerified":correct,"wrongVerified":wrong,"randomFillCalls":rng.calls}));
 }}
