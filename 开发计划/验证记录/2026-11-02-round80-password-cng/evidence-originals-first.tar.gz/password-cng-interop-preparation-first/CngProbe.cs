// Independent acceptance probe only. All inputs are public synthetic vectors.
using System;
using System.Runtime.InteropServices;
public static class FcPasswordCngProbe {
 [DllImport("bcrypt.dll",ExactSpelling=true,CharSet=CharSet.Unicode)]
 static extern int BCryptOpenAlgorithmProvider(out IntPtr algorithm,string id,string provider,uint flags);
 [DllImport("bcrypt.dll",ExactSpelling=true)]
 static extern int BCryptDeriveKeyPBKDF2(IntPtr algorithm,[In] byte[] password,uint passwordBytes,[In] byte[] salt,uint saltBytes,ulong iterations,[Out] byte[] output,uint outputBytes,uint flags);
 [DllImport("bcrypt.dll",ExactSpelling=true)] static extern int BCryptCloseAlgorithmProvider(IntPtr algorithm,uint flags);
 public sealed class Result { public int OpenStatus,DeriveStatus,CloseStatus;public bool Opened,Derived,CloseAttempted,CheckedClose;public string VerifierHex; }
 public static Result Derive(byte[] password,byte[] salt,ulong iterations) {
  Result r=new Result();r.OpenStatus=r.DeriveStatus=r.CloseStatus=unchecked((int)0xc0000001);IntPtr algorithm=IntPtr.Zero;byte[] output=new byte[32];
  try {
   r.OpenStatus=BCryptOpenAlgorithmProvider(out algorithm,"SHA256","Microsoft Primitive Provider",8);
   r.Opened=r.OpenStatus==0 && algorithm!=IntPtr.Zero;if(!r.Opened)return r;
   r.DeriveStatus=BCryptDeriveKeyPBKDF2(algorithm,password,checked((uint)password.Length),salt,checked((uint)salt.Length),iterations,output,32,0);
   r.Derived=r.DeriveStatus==0;if(r.Derived)r.VerifierHex=BitConverter.ToString(output).Replace("-","").ToLowerInvariant();return r;
  } finally {
   if(algorithm!=IntPtr.Zero){r.CloseAttempted=true;r.CloseStatus=BCryptCloseAlgorithmProvider(algorithm,0);r.CheckedClose=r.CloseStatus==0;}
   Array.Clear(output,0,output.Length);Array.Clear(password,0,password.Length);Array.Clear(salt,0,salt.Length);
  }
 }
}
