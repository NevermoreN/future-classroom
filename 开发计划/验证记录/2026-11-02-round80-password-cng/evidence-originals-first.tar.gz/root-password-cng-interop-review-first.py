from pathlib import Path
import hashlib,json,shutil
R=Path('/tmp/fc-round80-controlled-repair');A=R/'password-cng-interop-preparation-first';B=R/'password-cng-interop-preparation-second';O=R/'password-cng-interop-runtime-182309509a8e143e3875f8023edf1049'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fact(p):p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
assert sha(O/'report.json')=='bd5b66be7849c0bb276d811571e9214a265cb75a4c3cee52735ecaa69807a774'
assert sha(A/'freeze-first.json')=='d12ec268766a9eb1eac18f3009b83f64c6b63656c53113003bbe840a3487f1d8'
assert sha(B/'freeze-first.json')=='59e63881897e2f054f18afb2fe0810ac660dedb37057b51a6a9bd2caae488074'
freezes=[]
for p in (A,B):
 fr=json.loads((p/'freeze-first.json').read_bytes())
 for x in fr['files']:
  f=p/x['path'];assert f.resolve().is_relative_to(p)and not f.is_symlink()and f.is_file()and f.stat().st_size==x['bytes']and sha(f)==x['sha256']
 freezes.append(dict(path=str(p/'freeze-first.json'),sha256=sha(p/'freeze-first.json'),files=len(fr['files'])))
h=json.loads((A/'host-first/report.json').read_bytes());assert h['sourceCommit']=='b6b18631379e61b1971c20b361296db8671eb885'and h['sourceBefore']==h['sourceAfter']
for x in h['sourceBefore']:assert fact(x['path'])==x
metadata=json.loads((A/'host-first/metadata.stdout.log').read_bytes());local={x['name']:x for x in metadata['packages']if x['source']is None};assert set(local)=={'fc-domain','fc-ports','fc-security','fc-password-cng-interop-probe'}
assert local['fc-security']['manifest_path']==str(R/'checkout-abi2-upgrade-final-first/crates/fc-security/Cargo.toml')
build=[json.loads(x)for x in(A/'host-first/build.stdout.log').read_bytes().splitlines()if x.strip()];exe=[x for x in build if x.get('reason')=='compiler-artifact'and x.get('executable')==h['probeBinary']['path']];assert len(exe)==1 and exe[0]['profile']['test']is False and exe[0]['target']['src_path']==str(A/'host-first/probe/src/main.rs')
for x in h['commands']:assert x['actualExit']==0 and x['originalReaped']is True and fact(x['stdout']['path'])==x['stdout']and fact(x['stderr']['path'])==x['stderr']
r=json.loads((O/'report.json').read_bytes());assert r['status']=='PASS_PRODUCTION_RUST_PYTHON_AND_WIN11_CNG_FOUR_SYNTHETIC_600000'and r['completeDownloadVerified']is True and r['delete']['knownAbsent']is True
localroot=O/'download'/r['windowsRoot'].replace('\\','/').split('/')[-1];inv=r['inventory'];have={}
for f in localroot.rglob('*'):
 assert not f.is_symlink()
 if f.is_file():have[f.relative_to(localroot).as_posix()]=dict(path=f.relative_to(localroot).as_posix(),bytes=f.stat().st_size,sha256=sha(f))
assert have=={x['path']:x for x in inv['files']}
n=json.loads((localroot/'native-result.json').read_bytes());assert n==r['native']and n['originalParentReturned']is True and n['actualExit']==0 and len(n['originalObjects'])==1
cap=n['originalObjects'][0];assert cap['Pid']==n['pid']and cap['Creation']==n['creation']and cap['Wait']==0 and cap['ExitKnown']is True and cap['ExitCode']==0 and cap['CheckedClose']is True and cap['Sha256']==n['systemPowerShell']['sha256']and cap['Sid']=='S-1-5-21-3896111207-1867804362-1971593122-1001'
cng=json.loads((localroot/'cng-result.json').read_bytes());assert cng==n['cng']and cng['iterations']==600000 and cng['derivedBytes']==32 and cng['processBits']==64
fixtures=json.loads((A/'fixtures.json').read_bytes())['cases'];expected=json.loads((A/'expected.json').read_bytes())['cases'];assert len(fixtures)==len(expected)==len(cng['cases'])==4
qualified=[]
for f,x,y in zip(fixtures,expected,cng['cases']):
 actual=hashlib.pbkdf2_hmac('sha256',f['password'].encode(),bytes.fromhex(f['saltHex']),600000,32).hex();assert actual==x['verifierHex']==y['verifierHex']and f['id']==x['id']==y['id']
 assert x['correctVerified']is True and x['wrongVerified']is False and y['rustMatch']is True
 assert all(y[k]==0 for k in('openStatus','deriveStatus','closeStatus'))and all(y[k]is True for k in('opened','derived','closeAttempted','checkedClose'))
 qualified.append(dict(id=f['id'],utf8Bytes=x['utf8Bytes'],unicodeScalars=x['unicodeScalars'],rustProductionAndPythonAndCngMatch=True,originalCngProviderClosed=True))
assert expected[0]['verifierHex']=='44cca2634e314a690a713b4aa3229b1bacb74941e6e44c548672e7b199e604e4'
assert qualified[2]['utf8Bytes']==512 and qualified[2]['unicodeScalars']==128
old=R/'password-cng-interop-runtime-5a3702d9164859cd1efe6df65bd4b49e/report.json';assert sha(old)=='470ea37eb4ef3eef767f6456718fbabe2001c6bde082f7dc3c4427983f836163';cleanup=json.loads((R/'root-password-cng-first-failure-cleanup.json').read_bytes());assert cleanup['failurePreserved']is True and cleanup['result']['knownAbsent']is True
# Original Rust subprocesses are known terminal. Delete only this probe's private Cargo target.
target=A/'host-first/target';assert target.resolve()==target and target.is_dir()and not target.is_symlink();assert fact(h['probeBinary']['path'])==h['probeBinary']
files=[];dirs=0;size=0
for f in target.rglob('*'):
 assert not f.is_symlink()
 if f.is_dir():dirs+=1
 else:files.append(f.relative_to(target).as_posix());size+=f.stat().st_size
removed=dict(path=str(target),files=len(files),directories=dirs,logicalBytes=size,originalProcesses='All four exact original host subprocesses exited0 and reaped',originalBinaryIdentity=h['probeBinary'])
shutil.rmtree(target);assert not target.exists();removed['knownAbsent']=True
out=dict(status='PASS_ROOT_INDEPENDENT_FOUR_SYNTHETIC_PRODUCTION_600000_CNG_REPLAY_AND_CLEANUP',runtimeReport=fact(O/'report.json'),preparationFreezes=freezes,completeDownloadedFiles=len(have),completeDownloadedDirectories=len(inv['directories']),cases=qualified,nativeMilliseconds=n['elapsedMilliseconds'],outerSeconds=r['seconds'],originalProcessCheckedClose=True,providerOpenDeriveClose='Four independent original CNG handles; all actual statuses 0',existingChineseVerifier='Exact production known vector matched Rust/Python/CNG',firstFailure='Retained PS5 ulong name failure before any CNG call, scratch cleaned after complete download',hostBuildTargetCleanup=removed,windowsNonceCleanup=r['delete'],productionCodeChanged=False,scopeLimits=['Win11 x64 independent CNG API runtime only; host production Rust compiled from exact candidate dependencies','No claim about production CSPRNG quality from deterministic fixture','No old unprovided code/database migration format proof','Win7/Win10 actual NOT_RUN','No P0 device performance, whole Q25 matrix, or real account credential use'])
(R/'root-password-cng-interop-review-first.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k]for k in('status','completeDownloadedFiles','completeDownloadedDirectories','cases','nativeMilliseconds','outerSeconds','productionCodeChanged')}))
