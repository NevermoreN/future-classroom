param([Parameter(Mandatory=$true)][string]$Root)
$ErrorActionPreference='Stop';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$r=@{status='FAIL_CNG_INTEROP';cases=@();algorithm='SHA256-HMAC';provider='Microsoft Primitive Provider';iterations=600000;derivedBytes=32;testOnly='PUBLIC_SYNTHETIC_FIXTURES';os=[Environment]::OSVersion.VersionString;processBits=[IntPtr]::Size*8}
try{
 Add-Type -Path (Join-Path $Root 'CngProbe.cs') -ErrorAction Stop
 $fixtures=[IO.File]::ReadAllText((Join-Path $Root 'fixtures.json'))|ConvertFrom-Json
 $expected=[IO.File]::ReadAllText((Join-Path $Root 'expected.json'))|ConvertFrom-Json
 if($fixtures.cases.Count-ne4 -or $expected.cases.Count-ne4){throw 'EXACT_FOUR'}
 foreach($case in $fixtures.cases){
  $want=@($expected.cases|Where-Object{$_.id-ceq$case.id});if($want.Count-ne1){throw 'EXACT_CASE'}
  $bytes=[Text.UTF8Encoding]::new($false,$true).GetBytes([string]$case.password)
  $salt=[byte[]]::new(32);for($i=0;$i-lt32;$i++){$salt[$i]=[Convert]::ToByte($case.saltHex.Substring($i*2,2),16)}
  $utf8Bytes=$bytes.Length;$native=[FcPasswordCngProbe]::Derive($bytes,$salt,[UInt64]600000)
  $row=@{id=$case.id;utf8Bytes=$utf8Bytes;openStatus=$native.OpenStatus;deriveStatus=$native.DeriveStatus;closeStatus=$native.CloseStatus;opened=$native.Opened;derived=$native.Derived;closeAttempted=$native.CloseAttempted;checkedClose=$native.CheckedClose;verifierHex=$native.VerifierHex;rustMatch=($native.VerifierHex-ceq$want[0].verifierHex)};$r.cases+=,$row
  if(-not$row.opened-or-not$row.derived-or-not$row.closeAttempted-or-not$row.checkedClose-or-not$row.rustMatch-or$utf8Bytes-ne$want[0].utf8Bytes){throw 'CNG_RESULT_OR_ORIGINAL_CLOSE'}
 }
 $r.status='PASS_CNG_FOUR_SYNTHETIC_PRODUCTION_600000'
}catch{$r.error=$_.Exception.Message}
[IO.File]::WriteAllText((Join-Path $Root 'cng-result.json'),($r|ConvertTo-Json -Depth 16),[Text.UTF8Encoding]::new($false));$r|ConvertTo-Json -Depth 16 -Compress
if($r.status-ceq'PASS_CNG_FOUR_SYNTHETIC_PRODUCTION_600000'){exit 0}else{exit 1}
