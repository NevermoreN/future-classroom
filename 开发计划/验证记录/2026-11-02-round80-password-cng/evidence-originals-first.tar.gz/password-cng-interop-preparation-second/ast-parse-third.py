from pathlib import Path
import base64,json,subprocess,time,hashlib
P=Path(__file__).resolve().parent
chunks={n:(P/n).read_text()for n in('Common.ps1','Create.ps1','Delete.ps1','Run.ps1','Probe.ps1')}
payload=base64.b64encode(json.dumps(chunks).encode()).decode()
script="$ErrorActionPreference='Stop';$c=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('"+payload+"'))|ConvertFrom-Json;$r=@();foreach($x in $c.PSObject.Properties){$tok=$null;$err=$null;[void][Management.Automation.Language.Parser]::ParseInput([string]$x.Value,[ref]$tok,[ref]$err);$r+=@{name=$x.Name;errors=@($err|ForEach-Object{$_.Message})};if($err.Count){throw 'AST_ERROR'}};$r|ConvertTo-Json -Depth 8 -Compress"
boot="$ErrorActionPreference='Stop';[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);try{& ([ScriptBlock]::Create([Console]::In.ReadToEnd()))}catch{[Console]::Error.WriteLine($_.Exception.ToString());exit 1}"
argv=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','future-classroom-win11','powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(boot.encode('utf-16-le')).decode()]
t=time.monotonic();p=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);so,se=p.communicate(script.encode(),timeout=60)
(P/'ast-third.stdout.log').write_bytes(so);(P/'ast-third.stderr.log').write_bytes(se)
r=dict(status='PASS_AST_ONLY_NO_WINDOWS_FILES_OR_CNG_RUN'if p.returncode==0 else'FAIL_AST',actualExit=p.returncode,originalReaped=p.poll()is not None,seconds=time.monotonic()-t,chunks=[dict(name=n,bytes=len(x.encode()),sha256=hashlib.sha256(x.encode()).hexdigest())for n,x in chunks.items()]);(P/'ast-third.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(p.returncode)
