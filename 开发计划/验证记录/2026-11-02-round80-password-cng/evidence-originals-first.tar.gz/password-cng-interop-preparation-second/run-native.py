"""Finite independent synthetic PBKDF2 acceptance. Root-only Windows execution; default inert."""
from pathlib import Path
import argparse,base64,hashlib,json,os,re,secrets,shutil,subprocess,time
P=Path(__file__).resolve().parent;R=P.parent;W=R/'checkout-abi2-upgrade-final-first'
BOOT="$ErrorActionPreference='Stop';[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);$global:LASTEXITCODE=0;try{& ([ScriptBlock]::Create([Console]::In.ReadToEnd()))}catch{[Console]::Error.WriteLine($_.Exception.ToString());$global:LASTEXITCODE=1};exit ([int]$global:LASTEXITCODE)"
COMMON=(P/'Common.ps1').read_text();SID='S-1-5-21-3896111207-1867804362-1971593122-1001'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fact(p):p=Path(p);assert p.is_file()and not p.is_symlink();return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def write(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=True,indent=2)+'\n')
def inventory_valid(v):
 assert set(v)=={'files','directories'} and len(v['files'])<=128 and len(v['directories'])<=16
 seen=set()
 for x in v['files']:
  s=x['path'];assert s and '\\'not in s and ':'not in s and not s.startswith('/') and all(a not in('','.','..')for a in s.split('/'))and s not in seen;seen.add(s)
  assert type(x['bytes'])is int and 0<=x['bytes']<=4*1024*1024 and re.fullmatch('[0-9a-f]{64}',x['sha256'])
 assert len(set(v['directories']))==len(v['directories'])
 for s in v['directories']:assert s and s not in seen and '\\'not in s and ':'not in s and not s.startswith('/')and all(a not in('','.','..')for a in s.split('/'))
def verify_download(root,v):
 inventory_valid(v);files={};dirs=[]
 for p in root.rglob('*'):
  assert not p.is_symlink();rel=p.relative_to(root).as_posix()
  if p.is_dir():dirs.append(rel)
  else:files[rel]=dict(path=rel,bytes=p.stat().st_size,sha256=sha(p))
 assert files=={x['path']:x for x in v['files']}and set(dirs)==set(v['directories'])
def validate(freeze_sha):
 f=P/'freeze-first.json';assert sha(f)==freeze_sha;fr=json.loads(f.read_bytes())
 for row in fr['files']:
  p=P/row['path'];assert p.resolve().is_relative_to(P)and fact(p)==dict(path=str(p),bytes=row['bytes'],sha256=row['sha256'])
 h=json.loads((P/'host-first/report.json').read_bytes());assert h['status']=='PASS_HOST_PRODUCTION_RUST_AND_PYTHON4_WINDOWS_NOT_RUN'and h['sourceCommit']=='b6b18631379e61b1971c20b361296db8671eb885'and h['sourceBefore']==h['sourceAfter']
 assert len(h['commands'])==4 and all(x['actualExit']==0 and x['originalReaped']is True for x in h['commands'])
 for row in h['sourceBefore']:assert fact(row['path'])==row
 expected=json.loads((P/'expected.json').read_bytes())['cases'];assert expected==h['cases']and len(expected)==4
 return fr,h,expected

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');ap.add_argument('--preparation-freeze-sha256');ap.add_argument('--validate-inputs-only',action='store_true');args=ap.parse_args()
 if not(args.execute or args.validate_inputs_only):print('{"status":"NOT_RUN_DEFAULT_INERT"}');return 0
 assert not(args.execute and args.validate_inputs_only);fr,h,expected=validate(args.preparation_freeze_sha256)
 if args.validate_inputs_only:print('{"status":"PASS_LOCAL_CLOSED_SYNTHETIC_INPUTS_NO_WINDOWS","cases":4}');return 0
 nonce=secrets.token_hex(16);out=R/('password-cng-interop-runtime-'+nonce);out.mkdir();r=dict(status='STARTED',nonce=nonce,hostReport=fact(P/'host-first/report.json'),preparationFreeze=fact(P/'freeze-first.json'),operations=[],cleanup='NOT_RUN',windows='Windows 11 only',oldWindows='Win7/Win10 actual NOT_RUN',scope='Independent CNG comparison of production Rust PBKDF2 SHA256 600000 rounds; all data public synthetic; no account, key, registry, listener, installer or service mutation');start=time.monotonic();c=dict(nonce=nonce,sid=SID,root=None)
 def save():write(out/'report.json',r)
 def call(label,argv,feed=None,limit=60,allowed=(0,)):
  begin=time.monotonic();assert begin-start<600
  p=subprocess.Popen(argv,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  # On observation timeout do not kill/restart: leave exact local handle facts and retain remote scratch.
  try:so,se=p.communicate(feed,timeout=limit)
  except subprocess.TimeoutExpired:
   r.update(status='UNKNOWN_RETAIN_NO_KILL',liveLocalPid=p.pid,observationLabel=label);save();raise
  (out/(label+'.stdout.log')).write_bytes(so);(out/(label+'.stderr.log')).write_bytes(se)
  r['operations'].append(dict(label=label,argv=argv,actualExit=p.returncode,originalLocalReaped=p.poll()is not None,seconds=time.monotonic()-begin,stdout=fact(out/(label+'.stdout.log')),stderr=fact(out/(label+'.stderr.log'))));save();assert p.returncode in allowed,(label,p.returncode);return so,p.returncode
 def remote(label,body,limit=60,allowed=(0,)):
  text="$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+COMMON+body
  (out/(label+'.stdin.ps1')).write_text(text)
  return call(label,['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','future-classroom-win11','powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(BOOT.encode('utf-16-le')).decode()],text.encode(),limit,allowed)
 try:
  c['root']=json.loads(remote('create',(P/'Create.ps1').read_text())[0])['root'];r['windowsRoot']=c['root'];save()
  names=['Capture.cs','CngProbe.cs','Probe.ps1','fixtures.json','expected.json'];upload=out/'upload';upload.mkdir()
  for name in names:shutil.copyfile(P/name,upload/name)
  c['inputs']=[dict(name=p.name,bytes=p.stat().st_size,sha256=sha(p))for p in sorted(upload.iterdir())]
  for p in sorted(upload.iterdir()):call('upload-'+p.name,['scp','-q','-o','BatchMode=yes',str(p),'future-classroom-win11:'+c['root'].replace('\\','/')+'/'])
  raw,code=remote('run',(P/'Run.ps1').read_text(),limit=210,allowed=(0,1));native=json.loads(raw);r.update(native=native,runtimeActualExit=code);save()
  assert native.get('originalParentReturned') is True and all(x['Wait']==0 and x['ExitKnown']is True and x['CheckedClose']is True for x in native.get('originalObjects',[])),'UNKNOWN_OWNERS_RETAIN'
  v=json.loads(remote('inventory','Inventory $c.root|ConvertTo-Json -Depth 12 -Compress')[0]);inventory_valid(v);r['inventory']=v;save()
  download=out/'download';download.mkdir();call('download',['scp','-q','-r','-o','BatchMode=yes','future-classroom-win11:'+c['root'].replace('\\','/'),str(download)])
  local=download/c['root'].replace('\\','/').split('/')[-1];verify_download(local,v);assert json.loads((local/'native-result.json').read_bytes())==native
  for row in c['inputs']:assert (local/row['name']).read_bytes()==(upload/row['name']).read_bytes()
  r['completeDownloadVerified']=True;save()
  assert code==0 and native['status']=='PASS_WIN11_CNG_INTEROP_FOUR'and native['actualExit']==0 and native['elapsedMilliseconds']<180000, 'ACTUAL_CNG_NATIVE_NONZERO_OR_NOT_PASS'
  assert len(native['originalObjects'])==1
  original=native['originalObjects'][0];assert original['Pid']==native['pid']and original['Creation']==native['creation']and original['Sid']==SID and original['Sha256']==native['systemPowerShell']['sha256']and original['Image'].lower()==native['systemPowerShell']['path'].lower()and original['ExitCode']==0
  actual=json.loads((local/'cng-result.json').read_bytes());assert actual==native['cng']and actual['status']=='PASS_CNG_FOUR_SYNTHETIC_PRODUCTION_600000'and len(actual['cases'])==4
  for want,row in zip(expected,actual['cases']):
   assert row['id']==want['id']and row['utf8Bytes']==want['utf8Bytes']and row['verifierHex']==want['verifierHex']and row['rustMatch']is True
   assert all(row[k]==0 for k in('openStatus','deriveStatus','closeStatus'))and all(row[k]is True for k in('opened','derived','closeAttempted','checkedClose'))
  validate(args.preparation_freeze_sha256);r['sourceAndPreparationUnchanged']=True;c['inventory']=v;r['delete']=json.loads(remote('delete',(P/'Delete.ps1').read_text())[0]);assert r['delete']['knownAbsent']is True
  r.update(status='PASS_PRODUCTION_RUST_PYTHON_AND_WIN11_CNG_FOUR_SYNTHETIC_600000',cleanup='PASS_EXACT_COMPLETE_DOWNLOADED_NONCE_KNOWN_ABSENT')
 except Exception as error:r.update(status='FAIL_RETAIN_ORIGINALS',errorType=type(error).__name__,error=str(error))
 r['seconds']=time.monotonic()-start;save();print(json.dumps(dict(status=r['status'],report=str(out/'report.json'),sha256=sha(out/'report.json'),error=r.get('error'))));return 0 if r['status'].startswith('PASS_')else 1
if __name__=='__main__':raise SystemExit(main())
