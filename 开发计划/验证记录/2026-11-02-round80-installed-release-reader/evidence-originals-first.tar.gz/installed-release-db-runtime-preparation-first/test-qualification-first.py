from pathlib import Path
import copy,json,runpy
P=Path(__file__).resolve().parent
q=runpy.run_path(str(P/'run-controlled-product.py'))['probe_passed']
base={'started':True,'knownControlsReturned':True,'nativeProbePassed':True,'actualExit':True,'exitCode':0,'pipesComplete':True,'rustSuccessLineObserved':True,'strictSingleTestPass':True,'pid':42,'creationFiletime':123,'originalFinal':[{'Status':'HELD_ORIGINAL_IDENTITY','Pid':42,'Creation':123,'Wait':0,'ExitKnown':True,'ExitCode':0,'CloseAttempted':True,'CheckedClose':True}]}
assert q(base)
mutations=[('noProbePass',lambda x:x.update(nativeProbePassed=False)),('knownBusinessNonzero',lambda x:x.update(exitCode=101)),('pipeUnknown',lambda x:x.update(pipesComplete=False)),('absentSourceLine',lambda x:x.update(rustSuccessLineObserved=False)),('zeroTestsOrIgnored',lambda x:x.update(strictSingleTestPass=False)),('unknownClose',lambda x:x['originalFinal'][0].update(CheckedClose=False)),('otherProcessInstance',lambda x:x['originalFinal'][0].update(Creation=124)),('boolWaitNotNativeNumber',lambda x:x['originalFinal'][0].update(Wait=False)),('boolExitNotNativeNumber',lambda x:x.update(exitCode=False)),('extraOriginalObject',lambda x:x['originalFinal'].append(copy.deepcopy(x['originalFinal'][0])))]
for name,mutate in mutations:
 x=copy.deepcopy(base);mutate(x);assert not q(x),name
assert not q({});assert not q(None)
print(json.dumps(dict(status='PASS_PURE_PROBE_QUALIFICATION_REJECTIONS_ONLY_NOT_NATIVE',positiveSyntheticSample=1,rejectedMutations=len(mutations)+2)))
