from pathlib import Path
import subprocess,json,time
R=Path('/tmp/fc-round80-controlled-repair');W=R/'checkout-installed-release-db-first';O=R/'installed-release-db-implementation-first';P=W/'crates/fc-windows/src/installer_lifecycle/native/broker/installed_release'
wrapper=O/'pure-tests-first.rs';exe=O/'pure-tests-first'
wrapper.write_text('#[path = '+json.dumps(str(P/'format.rs'))+']\nmod format;\n#[path = '+json.dumps(str(P/'database_rules.rs'))+']\nmod database_rules;\n')
r=[]
try:
 for name,cmd in [('pure-compile-first',['rustc','--edition=2021','--test',str(wrapper),'-o',str(exe)]),('pure-tests-first',[str(exe)])]:
  start=time.monotonic();p=subprocess.run(cmd,cwd=W,capture_output=True,timeout=60);(O/(name+'.stdout.log')).write_bytes(p.stdout);(O/(name+'.stderr.log')).write_bytes(p.stderr);r.append(dict(name=name,argv=cmd,actualExit=p.returncode,parentReaped=True,seconds=time.monotonic()-start));assert p.returncode==0
finally:
 (O/'pure-checks-first.json').write_text(json.dumps(r,indent=2)+'\n');wrapper.unlink(missing_ok=True);exe.unlink(missing_ok=True)
print(json.dumps(r))
