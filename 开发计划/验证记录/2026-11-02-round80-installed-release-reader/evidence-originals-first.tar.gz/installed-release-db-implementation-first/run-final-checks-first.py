from pathlib import Path
import json,hashlib,subprocess,time,os
R=Path('/tmp/fc-round80-controlled-repair');W=R/'checkout-installed-release-db-first';O=R/'installed-release-db-implementation-first'
files=['crates/fc-windows/src/installer_lifecycle/native/broker.rs','crates/fc-windows/src/installer_lifecycle/native/broker/installed_release.rs','crates/fc-windows/src/installer_lifecycle/native/broker/installed_release/format.rs','crates/fc-windows/src/installer_lifecycle/native/broker/installed_release/database_rules.rs','crates/fc-windows/src/installer_lifecycle/native/broker/installed_release/cached_database.rs']
def inventory():return [dict(path=p,bytes=len((b:=(W/p).read_bytes())),sha256=hashlib.sha256(b).hexdigest()) for p in files]
env=os.environ.copy();env['CARGO_TARGET_DIR']=str(R/'installed-release-db-target-first');env['CARGO_BUILD_JOBS']='2';env.pop('FC_OWNED_REMOVAL_SCOPE_HEX',None)
r=dict(sourceBefore=inventory(),checks=[])
commands=[('cargo-check-second',['cargo','check','--locked','--offline','--target','i686-pc-windows-gnu','-p','fc-windows','--tests']),('clippy-first',['cargo','clippy','--locked','--offline','--target','i686-pc-windows-gnu','-p','fc-windows','--tests','--','-D','warnings']),('fmt-final',['rustfmt','--edition','2021','--check','--config','skip_children=true']+files),('architecture-final',['python3','scripts/check-architecture.py']),('diff-final',['git','diff','--check'])]
for name,cmd in commands:
 start=time.monotonic()
 with (O/(name+'.stdout.log')).open('xb') as so,(O/(name+'.stderr.log')).open('xb')as se:
  p=subprocess.Popen(cmd,cwd=W,env=env,stdout=so,stderr=se);exit=p.wait(timeout=900)
 r['checks'].append(dict(name=name,argv=cmd,actualExit=exit,parentReaped=True,seconds=time.monotonic()-start,targetDir=env['CARGO_TARGET_DIR']))
 if exit:break
r['sourceAfter']=inventory();r['unchanged']=r['sourceBefore']==r['sourceAfter'];(O/'final-checks-first.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
