"""Root-owned finite candidate native tests. Default inert; retain any unknown."""
import argparse, base64, hashlib, json, os, re, runpy, secrets, shutil, struct, subprocess, time
from pathlib import Path
E=Path('/tmp/fc-round80-controlled-repair')
BASE=E/'native-reference-first/run-negative-msi-r79-third.py'
assert hashlib.sha256(BASE.read_bytes()).hexdigest()=='da74f0058deac86507b712075904556780be6b262b18acb82415da6725c6e202'
COMMON=runpy.run_path(str(BASE))['COMMON'].replace('r79-production-msi-','r80-installed-release-db-native-').replace('r79-production-msi-runtime/v1','r80-installed-release-db-native-runtime/v1')
CAP=E/'native-reference-first/Capture.cs'
SID='S-1-5-21-3896111207-1867804362-1971593122-1001'
BOOT="[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()))"
CREATE=r'''
$w=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$w.User;if($sid.Value-cne$c.sid){throw 'SID'}}finally{$w.Dispose()}
$root=RootPath;try{[void][IO.File]::GetAttributes($root);throw 'ROOT_EXISTS'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
$cursor=[IO.Path]::GetDirectoryName($root);while($cursor){if(([IO.File]::GetAttributes($cursor)-band[IO.FileAttributes]::ReparsePoint)-ne0){throw 'ANCESTOR_REPARSE'};$cursor=[IO.Path]::GetDirectoryName($cursor)}
[void][IO.Directory]::CreateDirectory($root);$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false);foreach($s in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($s,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))};[IO.Directory]::SetAccessControl($root,$acl)
[IO.File]::WriteAllText((Join-Path $root '.owner'),"future-classroom-owned-r80-installed-release-db-native-runtime/v1`n",[Text.UTF8Encoding]::new($false));$c.root=$root;CheckRoot $root;@{root=$root;status='CREATED'}|ConvertTo-Json -Compress
'''
RUN=r'''
CheckRoot $c.root;$root=$c.root
foreach($x in $c.inputs){$f=Fact (Join-Path $root $x.name);if($f.bytes-ne$x.bytes-or$f.sha256-cne$x.sha256){throw 'INPUT_BYTES'}}
$oldTemp=$env:TEMP;$oldTmp=$env:TMP;$clock=[Diagnostics.Stopwatch]::StartNew();$capture=$null;$p=$null;$returned=$true
$r=@{status='FAIL_RETAIN';cases=@();originalWholeSeconds=600;captureSourceOnlyProcessMethods=$true;controlledNativeReturns='CFG_TEST_SYNTHETIC_BEGIN_END_OBSERVATIONS_ONLY';productionMsiAdapter='NOT_EXERCISED';ownedRemovalAuthority='COMPILED_SCOPE_ABSENT_NO_PRODUCT_RECOVERY_PERMITTED';newGuardTests='PURE_CONTRACT_BRIDGE_PRESENT_INTENT_AND_TYPED_SCRIPT_REPLAY_ONLY';newSetupTests='PURE_INTENT_AND_UNSEALED_CURRENT_IMAGE_REJECTION_ONLY';readerRegressionScope='FOUNDATION4_AND_DATABASE_RULES4_NO_REAL_DB_READ_IN_THIS_BATCH';explicitInstalledProbe='EXACT_FULL_NAME_SKIPPED_ALREADY_REAL_SEPARATE_PASS';cleanup='ROOT_DOWNLOAD_THEN_EXACT_DELETE_REQUIRED'}
try{
 $env:TEMP=Join-Path $root 'compiler-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP)
 try{Add-Type -Path (Join-Path $root 'Capture.cs') -ErrorAction Stop}finally{$env:TEMP=$oldTemp;$env:TMP=$oldTmp}
 $capture=[Fc79Capture]::new();$exe=Join-Path $root 'candidate-tests.exe'
 $env:TEMP=Join-Path $root 'test-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP)
 foreach($s in @(@{name='controlled';filter='installer_lifecycle::tests::controlled_';seconds=150},@{name='lifecycle';filter='installer_lifecycle::';seconds=300})){
  if($clock.ElapsedMilliseconds-ge600000){throw 'WHOLE_BUDGET'}
  $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$exe;$info.Arguments=$s.filter+' --test-threads=1 --nocapture';if($s.name-ceq'lifecycle'){$info.Arguments+=' --skip installer_lifecycle::native::broker::installed_release::cached_database::native_probe::captures_real_installed_a470_cache_and_returns_every_owned_handle'};$info.WorkingDirectory=$root;$info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
  $p=[Diagnostics.Process]::new();$p.StartInfo=$info;$case=@{name=$s.name;argv=$info.Arguments;originalSeconds=$s.seconds;actualExit=$false;exitCode=$null};$r.cases+=,$case
  $case.startedWholeMilliseconds=$clock.ElapsedMilliseconds;$case.originalDeadlineWholeMilliseconds=[Math]::Min(600000,$case.startedWholeMilliseconds+$s.seconds*1000)
  if(-not$p.Start()){throw 'START'};$returned=$false;$case.pid=$p.Id;$case.creation=$p.StartTime.ToUniversalTime().ToFileTimeUtc()
  $stdout=$p.StandardOutput.ReadToEndAsync();$stderr=$p.StandardError.ReadToEndAsync()
  $case.original=$capture.HoldStartedClient($p.Handle,[uint32]$p.Id,[long]$case.creation,$exe,$c.exeSha,$c.sid)
  $left=[int]($case.originalDeadlineWholeMilliseconds-$clock.ElapsedMilliseconds)
  if($left-le0-or-not$p.WaitForExit($left)){throw 'ORIGINAL_TEST_PARENT_UNKNOWN_RETAIN_NO_KILL'}
  $returned=$true;$p.Refresh();$case.actualExit=$true;$case.exitCode=$p.ExitCode
  if(-not[Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($stdout,$stderr),[int][Math]::Max(0,$case.originalDeadlineWholeMilliseconds-$clock.ElapsedMilliseconds))){throw 'ORIGINAL_PIPES_UNKNOWN'}
  $case.stdout=$stdout.Result;$case.stderr=$stderr.Result;[void]$capture.Snapshot()
  if($case.original.Wait-ne0-or-not$case.original.ExitKnown-or$case.original.ExitCode-ne$case.exitCode){throw 'ORIGINAL_TEST_RETURN_MISMATCH'}
  $case.endedWholeMilliseconds=$clock.ElapsedMilliseconds
  $p.Dispose();$p=$null;if($case.exitCode-ne0){throw 'NATIVE_TEST_FAILURE'}
  if($case.endedWholeMilliseconds-gt$case.originalDeadlineWholeMilliseconds){throw 'ORIGINAL_TEST_DEADLINE_EXCEEDED'}
 }
 $r.status='PASS_SETUP_COMPONENTS_AND_FULL_LIFECYCLE_NATIVE_TESTS_WIN11_ONLY'
}catch{$r.error=$_.Exception.Message}finally{
 $env:TEMP=$oldTemp;$env:TMP=$oldTmp
 if($null-ne$p-and$returned){$p.Dispose()}
 if($null-ne$capture){try{$r.originalObjects=@($capture.FinishAndClose())}catch{$r.status='FAIL_RETAIN';$r.closeError=$_.Exception.Message}}
 $r.originalParentReturned=$returned;$r.elapsedMilliseconds=$clock.ElapsedMilliseconds
 if($clock.ElapsedMilliseconds-ge600000){$r.status='FAIL_RETAIN';$r.budgetExceeded=$true}
 [IO.File]::WriteAllText((Join-Path $root 'native-result.json'),($r|ConvertTo-Json -Depth 30),[Text.UTF8Encoding]::new($false))
}
$r|ConvertTo-Json -Depth 30 -Compress
if($r.status-cne'PASS_SETUP_COMPONENTS_AND_FULL_LIFECYCLE_NATIVE_TESTS_WIN11_ONLY'){exit 1}
'''
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fact(p):p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def qualify_harness(stdout,required,expected):
 # --test-threads=1 is fixed by RUN. Nested fixture subprocesses inherit stdout
 # and may run a name that is also in the parent's 74-test scope. Count starts
 # only in the original harness scope; never promote a child's summary.
 assert len(required)==expected and len(set(required))==expected
 scopes=[];outer_names=[];summaries=[];outer_final=None;running=[]
 for line in stdout.splitlines():
  m=re.fullmatch(r'running (\d+) tests?',line)
  if m:
   n=int(m[1]);running.append(n)
   if not scopes:
    assert not summaries and n==expected,'ORIGINAL_PARENT_RUNNING_SCOPE'
   scopes.append(n)
   continue
  m=re.match(r'^test (installer_lifecycle::[^\s]+) \.\.\.',line)
  if m and len(scopes)==1:
   outer_names.append(m[1].rsplit('::',1)[-1])
  m=re.match(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',line)
  if m:
   assert scopes,'SUMMARY_WITHOUT_ORIGINAL_HARNESS_SCOPE'
   final=m.groups();summaries.append(final)
   assert final[0]=='ok' and all(int(n)==0 for n in final[2:5]),'REAL_TEST_FAILURE_OR_IGNORED_PRESENT'
   scope_count=scopes.pop()
   assert int(final[1])==scope_count,'HARNESS_SCOPE_SUMMARY_COUNT_MISMATCH'
   if not scopes:
    assert outer_final is None and int(final[1])==expected,'ORIGINAL_PARENT_FINAL_SCOPE'
    outer_final=final
 assert running and running[0]==expected and not scopes,'ORIGINAL_PARENT_HARNESS_NOT_COMPLETE'
 assert len(outer_names)==expected and set(outer_names)==set(required) and all(outer_names.count(name)==1 for name in required),'EXPECTED_OUTER_TEST_STARTS_EXACTLY_ONCE'
 assert outer_final is not None and summaries[-1]==outer_final,'FINAL_SUMMARY_MUST_BE_ORIGINAL_PARENT'
 assert not re.search(r'^test [^\r\n]*\.\.\. FAILED\r?$',stdout,re.M),'REAL_TEST_FAILURE_PRESENT'
 return dict(outerTotals={k:int(n) for k,n in zip(('passed','failed','ignored','measured','filteredOut'),outer_final[1:])},outerRunningCount=running[0],expectedOuterStarts=len(outer_names),summaryCount=len(summaries),nestedSummaryCount=len(summaries)-1,summaryAuthority='FINAL_ORIGINAL_PARENT_SUMMARY_WITH_ORIGINAL_PARENT_EXIT0_AND_CHECKED_CLOSE')

def main():
 a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');a.add_argument('--validate-inputs-only',action='store_true');a.add_argument('--preparation-freeze-sha256');a.add_argument('--producer',type=Path);a.add_argument('--producer-sha256');a.add_argument('--inventory',type=Path);a.add_argument('--inventory-sha256');v=a.parse_args()
 if not v.execute and not v.validate_inputs_only:print('{"status":"NOT_RUN"}');return
 assert not(v.execute and v.validate_inputs_only)
 assert v.producer and v.inventory and re.fullmatch(r'[0-9a-f]{64}',v.producer_sha256 or '') and re.fullmatch(r'[0-9a-f]{64}',v.inventory_sha256 or ''),'EXACT_ROOT_PRODUCER_AND_INVENTORY_REQUIRED'
 assert (E/'.owner').read_bytes()==b'future-classroom-owned-r80-controlled-repair/v1\n'
 producer=v.producer.resolve();inventory=v.inventory.resolve()
 assert producer==E/'installed-release-db-implementation-second/build-report-second.json' and v.producer_sha256=='9ec7ae275f74f7f44414ee70445db98970459f83c05e1869f208801f2f8ea10b' and sha(producer)==v.producer_sha256
 assert inventory==E/'installed-release-db-implementation-second/compiler-inputs-after-second.json' and v.inventory_sha256=='3f7112dfe5d77a8cd3be0b3610ba75d8bce2e1c3fca559b8f61e92c8585ecdb9' and sha(inventory)==v.inventory_sha256
 pr=json.loads(producer.read_bytes());source_rows=json.loads(inventory.read_bytes());assert pr['status']=='PASS_FROZEN_GNU_RELEASE_PROBE_COMPILER_ARTIFACT_ONLY_NATIVE_NOT_RUN' and pr['target']=='i686-pc-windows-gnu' and pr['sourceBase']=='a4702b56bff66da5f5cbe74551d8751eb33fa520'
 assert pr['sourceUnchanged'] is True and pr['sourceBefore']==pr['sourceAfter']==source_rows and len(source_rows)==467
 assert len(pr['operations'])==2 and all(p['actualExit']==0 and p['parentReaped'] is True for p in pr['operations'])
 assert pr['operations'][1]['argv']==['cargo','test','--locked','--offline','--release','--target','i686-pc-windows-gnu','-p','fc-windows','--no-run','--message-format=json']
 wt=E/'checkout-installed-release-db-probe-first';assert pr['worktree']==str(wt)
 controller_input=fact(Path(__file__).resolve());fixture_inputs=[fact(BASE),fact(CAP)]
 freeze=Path(__file__).parent/'freeze-first.json';assert re.fullmatch('[0-9a-f]{64}',v.preparation_freeze_sha256 or '') and sha(freeze)==v.preparation_freeze_sha256;frozen_preparation=json.loads(freeze.read_bytes())
 for row in frozen_preparation['files']:
  p=Path(__file__).parent/row['path'];assert p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
 preparation_input=fact(freeze)
 def verify_controller_fixture():
  assert fact(Path(__file__).resolve())==controller_input and fact(freeze)==preparation_input
  assert [fact(BASE),fact(CAP)]==fixture_inputs
 def verify_sources():
  head=subprocess.run(['git','rev-parse','HEAD'],cwd=wt,capture_output=True,check=True).stdout.decode().strip();assert head==pr['sourceBase']
  paths=sorted(set([p for p in(wt/'crates').rglob('*')if p.is_file()and(p.suffix=='.rs'or p.name=='Cargo.toml')]+[wt/p for p in('Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml')if(wt/p).is_file()]))
  assert [dict(path=str(p.relative_to(wt)),bytes=p.stat().st_size,sha256=sha(p))for p in paths]==source_rows
 verify_sources();verify_controller_fixture();assert sha(CAP)=='e74300d27694e46fde2e8113cfeee47ffd3f11f9172f01c5621fa2ba5fdcab5a'
 metadata=Path(pr['metadata']['path']);assert fact(metadata)==pr['metadata'];meta=json.loads(metadata.read_bytes());pkg=next(p for p in meta['packages']if p['name']=='fc-windows');assert pkg['manifest_path']==str(wt/'crates/fc-windows/Cargo.toml')
 stdout=Path(pr['operations'][1]['stdout']['path']);assert fact(stdout)==pr['operations'][1]['stdout'];compiler_stdout=fact(stdout)
 events=[json.loads(line)for line in stdout.read_bytes().splitlines()if line.strip()];artifacts=[x for x in events if x.get('reason')=='compiler-artifact'and x.get('profile',{}).get('test') is True and x.get('executable')and x['target']['name']=='fc_windows'];assert len(artifacts)==1
 artifact=artifacts[0];assert artifact==pr['compilerArtifact'] and artifact['package_id']==pkg['id'] and artifact['features']==['default'] and artifact['profile']['test'] is True and artifact['profile']['opt_level']=='3' and artifact['target']['src_path']==str(wt/'crates/fc-windows/src/lib.rs')
 exe=Path(pr['executable']['path']);assert exe==E/'installed-release-db-implementation-second/probe-artifact-second/db-reader-tests.exe' and fact(exe)==pr['executable'] and exe.stat().st_size==4371728 and sha(exe)=='5af49451fe8a716993f558c5f374095337bfdd6e27a7bed5db8a5594807edc45'
 original=Path(pr['originalExecutable']['path']);assert original==Path(artifact['executable']) and original.parent==E/'installed-release-db-probe-target-first/i686-pc-windows-gnu/release/deps' and fact(original)==pr['originalExecutable'] and original.read_bytes()==exe.read_bytes()
 build_script=E/'installed-release-db-implementation-second/build-probe-third.py';assert sha(build_script)==json.loads((Path(__file__).parent/'qualification-pins.json').read_bytes())['buildController']['sha256']
 script=build_script.read_text();assert "if key.startswith('FC_OWNED_REMOVAL'):del env[key]" in script and "'--features'" not in script
 prior=E/'installed-release-db-runtime-first/report.json';assert sha(prior)=='c477f6777ba72ac9d100370602fadc09e770b167e206818b0d539485ee25ce95'
 raw=exe.read_bytes();off=struct.unpack_from('<I',raw,60)[0];assert raw[off:off+4]==b'PE\0\0'and struct.unpack_from('<H',raw,off+4)[0]==0x14c and struct.unpack_from('<H',raw,off+92)[0]==3
 test_source=(wt/'crates/fc-windows/src/installer_lifecycle/tests.rs').read_text();controlled=tuple(re.findall(r'^fn (controlled_\w+)\(',test_source,re.M));assert len(controlled)==6
 declarations=[]
 for source in sorted((wt/'crates/fc-windows/src/installer_lifecycle').rglob('*.rs')):
  for m in re.finditer(r'#\[test\]\s*((?:#\[[^\n]+\]\s*)*)fn (\w+)\(',source.read_text()):declarations.append(dict(name=m[2],attributes=m[1].strip(),path=str(source.relative_to(wt))))
 assert len(declarations)==78 and len({x['name']for x in declarations})==78
 scope='crates/fc-windows/src/installer_lifecycle/native/broker/controlled_owner/recovery/scope.rs'
 excluded_scope={'owned_removal_scope_never_accepts_unbound_or_runtime_authority_text','owned_removal_pending_requires_exact_original_schema_sid_and_tag5','owned_removal_scope_closes_full_manifest_receipts_and_object_identity'}
 assert {x['name']for x in declarations if x['path']==scope}==excluded_scope
 assert '#[cfg(feature = "owned-test-removal")]\nmod recovery;' in(wt/'crates/fc-windows/src/installer_lifecycle/native/broker/controlled_owner.rs').read_text()
 skipped='captures_real_installed_a470_cache_and_returns_every_owned_handle'
 ignored=[x for x in declarations if x['attributes']];assert len(ignored)==1 and ignored[0]['name']==skipped and ignored[0]['path'].endswith('/cached_database/native_probe.rs') and ignored[0]['attributes'].startswith('#[ignore = ')
 all_names=[x['name']for x in declarations if x['name']not in excluded_scope|{skipped}];assert len(all_names)==74 and set(controlled)<=set(all_names)
 if v.validate_inputs_only:
  print(json.dumps(dict(status='PASS_FROZEN_GNU_DEFAULT_NATIVE_COMPONENT_INPUT_QUALIFICATION_ONLY',sourceInputs=len(source_rows),allSourceDeclarations=78,expectedScopes={'controlled':6,'lifecycle':74},excludedFeatureTests=sorted(excluded_scope),skipExactFullName='installer_lifecycle::native::broker::installed_release::cached_database::native_probe::'+skipped,artifact=fact(exe),nativeExecution='NOT_RUN')));return
 out=E/'installed-release-db-native-runtime-first';out.mkdir();(out/'.owner').write_text('future-classroom-owned-r80-installed-release-db-native-local/v1\n')
 r=dict(status='STARTED',authority='GNU_DEFAULT_LIFECYCLE74_SCOPE_ENV_UNSET_NO_RECOVERY_OR_UPGRADE_AUTHORIZATION',sourceQualificationScope='FROZEN_WORKSPACE_RUST_CARGO_ONLY',pythonCiAndMsiPackaging='NOT_VERIFIED',controllerInput=controller_input,fixtureInputs=fixture_inputs,preparationFreeze=preparation_input,skipExactFullName='installer_lifecycle::native::broker::installed_release::cached_database::native_probe::captures_real_installed_a470_cache_and_returns_every_owned_handle',featureScope='THREE_TESTS_NOT_COMPILED_DEFAULT_ONLY',compiledScopeEnvironment='UNSET_BY_FROZEN_BUILD_CONTROLLER_AND_MODULE_NOT_COMPILED',priorActualInstalledProbe=fact(prior),compileInventory=fact(inventory),sourceBase=pr['sourceBase'],sourceInputs=source_rows,expectedScopes={'controlled':6,'lifecycle':74},scopeOverlap='74 includes controlled6; nested child summaries are not added to parent totals',producer=fact(producer),producerCompilerStdout=compiler_stdout,nativeInput=fact(exe),capture=fact(CAP),operations=[],cleanup='NOT_RUN',outerSeconds=900);c=dict(nonce=secrets.token_hex(16),sid=SID,root=None,exeSha=sha(exe));start=time.monotonic()
 def save():(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
 def call(label,cmd,feed=None,limit=30):
  begin=time.monotonic();left=900-(begin-start);assert left>0
  child=subprocess.Popen(cmd,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  timed=False
  try:stdout,stderr=child.communicate(feed,timeout=min(left,limit))
  except subprocess.TimeoutExpired:
   timed=True;child.kill();stdout,stderr=child.communicate()
  so=out/(label+'.stdout.log');se=out/(label+'.stderr.log');so.write_bytes(stdout);se.write_bytes(stderr)
  r['operations'].append(dict(name=label,argv=cmd,actualReturnCode=child.returncode,originalLocalReaped=True,remoteOriginalReturnUnknown=timed,budgetExceeded=timed,elapsedSeconds=time.monotonic()-begin,stdout=fact(so),stderr=fact(se)));save()
  assert not timed and child.returncode==0,(label,child.returncode,'REMOTE_UNKNOWN_RETAIN' if timed else 'ACTUAL_NONZERO')
  return stdout
 def remote(label,script,limit=30):
  feed=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+COMMON+script).encode()
  return call(label,['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','future-classroom-win11','powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(BOOT.encode('utf-16-le')).decode()],feed,limit)
 try:
  c['root']=json.loads(remote('create',CREATE))['root'];r['windowsRoot']=c['root'];save()
  upload=out/'upload';upload.mkdir();shutil.copyfile(exe,upload/'candidate-tests.exe');shutil.copyfile(CAP,upload/'Capture.cs')
  c['inputs']=[dict(name=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(upload.iterdir())]
  for p in sorted(upload.iterdir()):call('upload-'+p.name,['scp','-q','-o','BatchMode=yes',str(p),'future-classroom-win11:'+c['root'].replace('\\','/')+'/'],limit=60)
  native=json.loads(remote('run',RUN,600));r['native']=native
  assert native['originalParentReturned'] is True
  assert native['status']=='PASS_SETUP_COMPONENTS_AND_FULL_LIFECYCLE_NATIVE_TESTS_WIN11_ONLY'
  assert len(native['cases'])==2 and [x['name'] for x in native['cases']]==['controlled','lifecycle']
  r['qualifiedCases']=[]
  for case in native['cases']:
   required=controlled if case['name']=='controlled' else all_names
   expected_argv=('installer_lifecycle::tests::controlled_ --test-threads=1 --nocapture' if case['name']=='controlled' else 'installer_lifecycle:: --test-threads=1 --nocapture --skip installer_lifecycle::native::broker::installed_release::cached_database::native_probe::captures_real_installed_a470_cache_and_returns_every_owned_handle');assert case['argv']==expected_argv
   assert case['actualExit'] and case['exitCode']==0
   expected=6 if case['name']=='controlled' else 74
   qualified=qualify_harness(case['stdout'],required,expected)
   r['qualifiedCases'].append(dict(name=case['name'],**qualified))
  assert len(native['originalObjects'])==2 and all(x['CheckedClose'] and x['Wait']==0 and x['ExitKnown'] and x['ExitCode']==0 for x in native['originalObjects'])
  ownedProcesses=json.loads(remote('owned-processes',"$a=@(Get-CimInstance Win32_Process -ErrorAction Stop|Where-Object {$_.ExecutablePath -and $_.ExecutablePath.StartsWith($c.root+'\\',[StringComparison]::OrdinalIgnoreCase)});@{count=$a.Count}|ConvertTo-Json -Compress"));r['ownedProcessReadback']=ownedProcesses;assert ownedProcesses['count']==0
  inv=json.loads(remote('inventory','Inventory $c.root|ConvertTo-Json -Depth 12 -Compress'));r['inventory']=inv
  for item in c['inputs']:
   actual=[x for x in inv['files'] if x['path']==item['name']];assert len(actual)==1 and actual[0]['bytes']==item['bytes'] and actual[0]['sha256']==item['sha256']
  save()
  download=out/'download';download.mkdir();call('download',['scp','-q','-r','-o','BatchMode=yes','future-classroom-win11:'+c['root'].replace('\\','/'),str(download)],limit=60)
  local=download/Path(c['root'].replace('\\','/')).name
  assert sha(BASE)=='da74f0058deac86507b712075904556780be6b262b18acb82415da6725c6e202'
  verify_controller_fixture();helper=runpy.run_path(str(BASE));helper['verify_download'](local,inv)
  assert json.loads((local/'native-result.json').read_text())==native
  c['inventory']=inv
  cleanup=helper['DELETE'].replace('PRODUCT_RUNTIME_ROOT','REPAIR_NATIVE_RUNTIME_ROOT')
  verify_controller_fixture();r['delete']=json.loads(remote('delete',cleanup));r['cleanup']='PASS_EXACT_DOWNLOADED_OWNED_SCRATCH_ONLY';r['status']='PASS_GNU_DEFAULT_CONTROLLED6_LIFECYCLE74_NATIVE_REGRESSION_WIN11_ONLY'
 except Exception as error:r.update(status='FAIL_RETAIN_ORIGINALS',errorType=type(error).__name__,error=str(error))
 r['elapsedSeconds']=time.monotonic()-start
 if r['elapsedSeconds']>=900:r['status']='FAIL_OUTER_ORIGINAL_BUDGET_EXCEEDED';r['outerBudgetExceeded']=True
 try:verify_sources();verify_controller_fixture();r['candidateSourcesUnchanged']=True;r['controllerAndFixturesUnchanged']=True
 except Exception:r['candidateSourcesUnchanged']=False;r['status']='FAIL_CANDIDATE_SOURCE_CHANGED'
 r['producerCompilerStdoutUnchanged']=fact(stdout)==compiler_stdout
 if not r['producerCompilerStdoutUnchanged']:r['status']='FAIL_PRODUCER_COMPILER_STDOUT_CHANGED'
 r['compiledExeUnchanged']=fact(exe)==r['nativeInput']
 if not r['compiledExeUnchanged']:r['status']='FAIL_COMPILED_EXE_CHANGED'
 save();print(json.dumps({'status':r['status'],'report':str(out/'report.json'),'sha256':sha(out/'report.json'),'error':r.get('error')}));raise SystemExit(0 if r['status'].startswith('PASS_') else 1)
if __name__=='__main__':main()
