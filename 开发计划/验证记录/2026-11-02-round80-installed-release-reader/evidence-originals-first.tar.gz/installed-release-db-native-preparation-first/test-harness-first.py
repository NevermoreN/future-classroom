from pathlib import Path
import runpy,copy,json
P=Path(__file__).resolve().parent;q=runpy.run_path(str(P/'run-native.py'))['qualify_harness']
names=['fixture_'+str(i)for i in range(74)]
lines=['running 74 tests']
for i,name in enumerate(names):
 if i==3:lines+=['test installer_lifecycle::tests::'+name+' ... ','running 1 test','test installer_lifecycle::tests::child_fixture ... ok','test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s','ok']
 else:lines.append('test installer_lifecycle::tests::'+name+' ... ok')
lines+=['test result: ok. 74 passed; 0 failed; 0 ignored; 0 measured; 1 filtered out; finished in 0.01s']
raw='\n'.join(lines)+'\n';v=q(raw,names,74);assert v['outerTotals']['passed']==74 and v['nestedSummaryCount']==1
bad=[raw.replace('74 passed; 0 failed; 0 ignored','74 passed; 0 failed; 1 ignored'),raw.replace('74 passed; 0 failed; 0 ignored','73 passed; 1 failed; 0 ignored'),raw.replace('running 74 tests','running 75 tests'),raw.replace('test installer_lifecycle::tests::fixture_2 ... ok\n',''),raw.replace('test installer_lifecycle::tests::fixture_2 ... ok','test installer_lifecycle::tests::fixture_1 ... ok'),raw+'test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out; finished in 0.00s\n']
for text in bad:
 try:q(text,names,74)
 except AssertionError:pass
 else:raise AssertionError('MALFORMED_PARENT_SCOPE_ACCEPTED')
print(json.dumps(dict(status='PASS_PURE_NESTED_74_SCOPE_QUALIFICATION_ONLY_NOT_NATIVE',positiveSamples=1,negativeSamples=len(bad),controlledSubsetNotAdded=True)))
