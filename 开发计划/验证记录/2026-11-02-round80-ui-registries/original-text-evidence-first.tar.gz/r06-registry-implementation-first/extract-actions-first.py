from pathlib import Path
import re
w=Path('/tmp/fc-round80-controlled-repair/checkout-r06-registry-first')
p=w/'crates/fc-bootstrap/src/application.rs'
s=p.read_text()
a=s.index('fn execute(mut r: Request) -> Result<Outcome> {')
b=s.index('\n}',a)+2
old=s[a:b]
match=old[old.index('    match (r.screen, r.action) {')+len('    match (r.screen, r.action) {'):old.index('    Ok(Outcome::Updated')]
# Match only top-level arm headers (eight spaces); bodies contain no same-indent closing braces.
pat=re.compile(r'        \((Screen::\w+|_), (\w+)\) => \{\n(.*?)\n        \}',re.S)
rows=[]; funcs=[]
for screen,action,body in pat.findall(match):
 name='request_'+(screen.removeprefix('Screen::').lower() if screen!='_' else 'any')+'_'+action.lower()
 body=body.replace('require_lease()', 'require_lease(r)').replace('next_lease', 'transition.lease')
 body=re.sub(r'\bnext\b','transition.next',body)
 body=re.sub(r'\bcode\b','transition.code',body)
 body=body.replace('return Ok(Outcome::Loaded { key, record });','return Ok(Some(Outcome::Loaded { key, record }));').replace('return Ok(Outcome::ExitAuthorized);','return Ok(Some(Outcome::ExitAuthorized));')
 # These return paths already complete this callback.
 terminal=action in ('LOAD','EXIT')
 trans='transition' if 'transition.' in body else '_transition'
 funcs.append(f'fn {name}(backend: &mut Backend, r: &mut Request, {trans}: &mut Transition) -> Result<Option<Outcome>> {{\n'+body+('' if terminal else '\n    Ok(None)')+'\n}\n')
 if screen=='_':
  screens=re.findall(r'Self::(\w+)',s[s.index('impl Screen {'):s.index('\n#[derive(Debug)]')])
  rows.extend((f'Screen::{x}',action,name) for x in screens)
 else:rows.append((screen,action,name))
assert len(funcs)==12,(len(funcs),[x[:50] for x in funcs])
# Private registry shares the existing management worker and backend; no new authority.
module='''\nstruct Transition { next: Screen, lease: Option<SessionLease>, code: Option<RecoveryCode> }\ntype RequestHandler = fn(&mut Backend, &mut Request, &mut Transition) -> Result<Option<Outcome>>;\nstatic REQUESTS: &[Registration<(Screen, ActionId), RequestHandler>] = &[\n'''
module+=''.join(f'    Registration {{ key: ({screen}, {action}), implementation: {name} }},\n' for screen,action,name in rows)
module+=''' ];
fn require_lease(r: &Request) -> Result<SessionLease> { r.lease.ok_or_else(|| invalid("请先登录。")) }
pub(super) fn execute(mut r: Request) -> Result<Outcome> {
    let handler = Registry::new(REQUESTS).and_then(|registry| registry.get((r.screen, r.action))).map_err(|_| invalid("此操作在当前页面不可用。"))?;
    let owner = Arc::clone(&r.backend);
    let mut backend = owner.lock().map_err(|_| Failure::Stopped)?;
    let mut transition = Transition { next: Screen::Home, lease: r.lease, code: None };
    if let Some(outcome) = handler(&mut backend, &mut r, &mut transition)? { return Ok(outcome); }
    Ok(Outcome::Updated { state: backend.state()?, lease: transition.lease, code: transition.code, next: transition.next })
}
'''+''.join(funcs)
q=w/'crates/fc-bootstrap/src/application/settings_registry.rs'
q.write_text(q.read_text()+module)
p.write_text(s[:a]+'fn execute(r: Request) -> Result<Outcome> { settings_registry::execute(r) }'+s[b:])
