from pathlib import Path
w=Path('/tmp/fc-round80-controlled-repair/checkout-r06-registry-first')
p=w/'crates/fc-windows/src/workbench.rs';s=p.read_text();s=s.replace('    pub fn set_layout_preview(&self, image: Option<LayoutPreview>) -> Result<()> {','''    pub fn set_layout_preview(&self, image: Option<LayoutPreview>) -> Result<()> {
        (registry::hooks(WindowRole::Preview)?.preview)(self, image)
    }
    fn bind_preview_native(&self, image: Option<LayoutPreview>) -> Result<()> {''');s=s.replace('    pub fn clear_layout_preview(&self) {\n        self.state.clear_layout_preview();','''    pub fn clear_layout_preview(&self) {
        match registry::hooks(WindowRole::Preview) {
            Ok(hooks) => (hooks.clear_preview)(self),
            Err(_) => self.clear_preview_native(),
        }
    }
    fn clear_preview_native(&self) {
        self.state.clear_layout_preview();''')
s=s.replace('        (hooks.bind)(self, view)?;\n        self.role.set(role);\n        (hooks.measure)(self)','''        (hooks.bind)(view)?;
        let changed = (hooks.render)(self, view)?;
        self.role.set(role);
        if changed { (hooks.measure)(self)?; }
        Ok(())''')
s=s.replace('    fn bind_native(&self, view: &View) -> Result<()> {\n        view.validate()\n            .map_err(|_| Error::from_hresult(E_INVALIDARG))?;', '    fn render_native(&self, view: &View) -> Result<bool> {')
# Only the equal-view fast path and final success in this function change type.
a=s.index('    fn render_native(');b=s.index('    fn measure_native(',a);part=s[a:b].replace('return Ok(());','return Ok(false);').replace('        Ok(())\n    }','        Ok(true)\n    }');s=s[:a]+part+s[b:];p.write_text(s)
p=w/'crates/fc-windows/src/workbench/registry.rs';s=p.read_text().replace('pub bind: fn(&Window, &View) -> Result<()>,','pub bind: fn(&View) -> Result<()>,\n    pub render: fn(&Window, &View) -> Result<bool>,\n    pub preview: fn(&Window, Option<LayoutPreview>) -> Result<()>,\n    pub clear_preview: fn(&Window),').replace('bind: Window::bind_native,','bind: bind_view,\n        render: Window::render_native,\n        preview: Window::bind_preview_native,\n        clear_preview: Window::clear_preview_native,');s+='''
fn bind_view(view: &View) -> Result<()> {
    view.validate().map_err(|_| Error::from_hresult(E_INVALIDARG))
}
''';p.write_text(s)
p=w/'crates/fc-bootstrap/src/application/window_registry.rs';s=p.read_text().replace('key: Screen::Code,\n        implementation: WindowRole::Preview','key: Screen::Code,\n        implementation: WindowRole::Workbench');p.write_text(s)
p=w/'crates/fc-presentation/src/card_body.rs';s=p.read_text();s+='''
#[cfg(test)]
mod registration_tests {
    use super::*;
    #[test]
    fn neutral_placeholders_bind_without_borrowing_another_components_builder() {
        let content = CardContent::Text("等待当前课程数据".into());
        for kind in ComponentKind::ALL.into_iter().chain([ComponentKind::SubjectText, ComponentKind::SubjectImage]) {
            let body = card_body_spec(kind, &content, false, None).unwrap();
            assert_eq!(body.blocks.len(), 1);
            assert_eq!(body.blocks[0].text, "等待当前课程数据");
            assert_eq!(body.dynamic, CardBodyDynamic::Static);
        }
        let clock = CardContent::Clock(ClockContent { mode: ClockMode::Analog, show_seconds: false });
        assert!(matches!(card_body_spec(ComponentKind::Clock, &clock, false, None).unwrap().dynamic, CardBodyDynamic::AnalogClock));
        assert_eq!(card_body_spec(ComponentKind::Date, &clock, false, None), Err(CardBodyError::InvalidContent));
    }
    #[test]
    fn public_lesson_control_keeps_its_own_binding_without_changing_schedule_content() {
        let content = CardContent::LessonControl { caption: "仅本节".into(), can_change: true };
        let control = card_body_spec(ComponentKind::Schedule, &content, true, None).unwrap();
        assert!(control.blocks.is_empty());
        assert_eq!(control.dynamic, CardBodyDynamic::LessonControl { caption: "仅本节".into(), can_change: true });
        assert_eq!(card_body_spec(ComponentKind::Date, &content, false, None), Err(CardBodyError::InvalidContent));
        let schedule = card_body_spec(ComponentKind::Schedule, &CardContent::Courses(vec![]), true, None).unwrap();
        assert_eq!(schedule.dynamic, CardBodyDynamic::Static);
        assert_eq!(schedule.top_inset, control.top_inset);
    }
}
''';p.write_text(s)
p=w/'crates/fc-bootstrap/src/application/settings_registry.rs';s=p.read_text();s+='''
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn incomplete_page_routes_and_cross_page_business_actions_fail_closed() {
        validate().unwrap();
        let requests = Registry::new(REQUESTS).unwrap();
        assert!(requests.get((Screen::Login, SAVE)).is_err());
        assert!(requests.get((Screen::Setup, LOG_IN)).is_err());
        assert!(requests.get((Screen::Home, ADD_CLASS)).is_err());
        assert!(requests.get((Screen::School, ADD_CLASS)).is_ok());
        for screen in Screen::ALL { assert!(requests.get((*screen, EXIT)).is_ok()); }
        // Backup and HTTPS keep the original pre-pending dispatch so their own
        // cancellation/suspension handlers remain reachable during work.
        assert!(submit_handler(Screen::Backup, true).unwrap().is_some());
        assert!(submit_handler(Screen::Backup, false).unwrap().is_none());
        assert!(submit_handler(Screen::Profiles, true).unwrap().is_none());
        assert!(submit_handler(Screen::Profiles, false).unwrap().is_some());
    }
}
''';p.write_text(s)
