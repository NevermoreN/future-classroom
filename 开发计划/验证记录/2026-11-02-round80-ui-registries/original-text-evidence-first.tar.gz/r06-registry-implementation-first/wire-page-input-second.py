from pathlib import Path
import re
w=Path('/tmp/fc-round80-controlled-repair/checkout-r06-registry-first');p=w/'crates/fc-bootstrap/src/application.rs';s=Path('/tmp/fc-round80-controlled-repair/r06-registry-implementation-first/source-before/crates/fc-bootstrap/src/application.rs').read_text();q=w/'crates/fc-bootstrap/src/application/settings_registry.rs';t=q.read_text()
# Extract original per-page capture/selection/suspension bodies without changing
# their pending/stopping/owner checks or the shared authentication boundaries.
def capture(region,indent):
 heads=list(re.finditer(r'^'+(' '*indent)+r'if self.screen == Screen::(\w+)',region,re.M));out={}
 for i,h in enumerate(heads):
  block=region[h.start():heads[i+1].start() if i+1<len(heads) else len(region)].rstrip()
  out[h.group(1)]=block
 return out
input_a=s.index('                if self.screen == Screen::Schedule',s.index('    fn event('));input_b=s.index('\n            }\n            Event::LayoutSelect',input_a)
grid_a=s.index('                if self.screen == Screen::Accounts',input_b);grid_b=s.index('\n            }\n            Event::Close',grid_a)
suspend_a=s.index('        if self.screen == Screen::Accounts',s.index('    fn lock('));suspend_b=s.index('        // A locked review',suspend_a)
inputs=capture(s[input_a:input_b],16);grids=capture(s[grid_a:grid_b],16);suspends=capture(s[suspend_a:suspend_b],8)
assert (len(inputs),len(grids),len(suspends))==(6,5,5)
# Later-to-earlier substitutions retain recorded offsets.
s=s[:grid_a]+'                settings_registry::grid(self, row, column)?;'+s[grid_b:]
s=s[:input_a]+'                settings_registry::input(self)?;'+s[input_b:]
s=s[:suspend_a]+'        settings_registry::suspend(self);\n'+s[suspend_b:]
start=s.index('                if self.screen == Screen::Profiles {',s.index('    fn event('));end=s.index('                if action == EXIT',start)
old=s[start:end];pairs=re.findall(r'if self.screen == Screen::(\w+) \{\s+return self\.(\w+)\(action, data\);\s+}',old);assert len(pairs)==11
s=s[:start]+'''                if let Some(handler) = settings_registry::submit_handler(self.screen, false)? {
                    return handler(self, action, data);
                }
'''+s[end:]
start=s.index('                if self.screen == Screen::Backup && !self.stopping {',s.index('    fn event('));end=s.index('                if self.pending.is_some()',start)
s=s[:start]+'''                if !self.stopping {
                    if let Some(handler) = settings_registry::submit_handler(self.screen, true)? {
                        return handler(self, action, data);
                    }
                }
'''+s[end:]
assert True # application changes were already written by first attempt
handlers=dict(pairs);handlers.update(Backup='backup_event',HttpsSettings='https_event')
old='''struct Page {
    render: fn(&App, &str) -> View,
}'''
new='''type SubmitHandler = fn(&mut App, ActionId, FormData) -> std::result::Result<(), String>;
struct Page {
    render: fn(&App, &str) -> View,
    submit: Option<SubmitHandler>,
    early_submit: bool,
    input: fn(&mut App) -> std::result::Result<(), String>,
    grid: fn(&mut App, usize, usize) -> std::result::Result<(), String>,
    suspend: fn(&mut App),
}'''
assert old in t;t=t.replace(old,new)
pat=re.compile(r'(key: Screen::(\w+),\s+implementation: Page \{\s+render: (\w+),?)')
def fields(m):
 name=m[2];return m[1].rstrip(',')+','+f'\n            submit: '+('Some(App::'+handlers[name]+')' if name in handlers else 'None')+f',\n            early_submit: {str(name in ("Backup","HttpsSettings")).lower()},\n            input: '+('input_'+name.lower() if name in inputs else 'no_input')+',\n            grid: '+('grid_'+name.lower() if name in grids else 'no_grid')+',\n            suspend: '+('suspend_'+name.lower() if name in suspends else 'no_suspend')+','
t,n=pat.subn(fields,t);assert n==28,n
t+='''
fn page(screen: Screen) -> std::result::Result<&'static Page, String> {
    Registry::new(PAGES).and_then(|registry| registry.get(screen)).map_err(|_| "页面注册不可用".to_owned())
}
pub(super) fn submit_handler(screen: Screen, early: bool) -> std::result::Result<Option<SubmitHandler>, String> {
    let page = page(screen)?;
    Ok(if page.early_submit == early { page.submit } else { None })
}
pub(super) fn input(app: &mut App) -> std::result::Result<(), String> { (page(app.screen)?.input)(app) }
pub(super) fn grid(app: &mut App, row: usize, column: usize) -> std::result::Result<(), String> { (page(app.screen)?.grid)(app, row, column) }
pub(super) fn suspend(app: &mut App) {
    // A broken static page cannot stop the caller's management lock and secret
    // cleanup. This hook only retains the original nonsecret editing draft.
    if let Ok(page) = page(app.screen) { (page.suspend)(app); }
}
fn no_input(_: &mut App) -> std::result::Result<(), String> { Ok(()) }
fn no_grid(_: &mut App, _: usize, _: usize) -> std::result::Result<(), String> { Ok(()) }
fn no_suspend(_: &mut App) {}
'''
for category,blocks in [('input',inputs),('grid',grids),('suspend',suspends)]:
 for name,block in blocks.items():
  params='app: &mut App'+(', row: usize, column: usize' if category=='grid' else '')
  result='' if category=='suspend' else ' -> std::result::Result<(), String>'
  t+=f'fn {category}_{name.lower()}({params}){result} {{\n'+re.sub(r'\bself\b','app',block)+('' if category=='suspend' else '\n    Ok(())')+'\n}\n'
q.write_text(t)
