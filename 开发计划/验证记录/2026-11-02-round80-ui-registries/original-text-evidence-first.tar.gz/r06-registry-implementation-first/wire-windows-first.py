from pathlib import Path
w=Path('/tmp/fc-round80-controlled-repair/checkout-r06-registry-first')
p=w/'crates/fc-presentation/src/lib.rs'; s=p.read_text().replace('\npub mod registry;','');s=s.replace('pub mod layout;','pub mod layout;\npub mod registry;');p.write_text(s)
p=w/'crates/fc-presentation/src/registry.rs';s=p.read_text();a=s.index('/// A fixed lifecycle,');b=s.index('#[cfg(test)]',a);p.write_text(s[:a]+s[b:])
p=w/'crates/fc-presentation/src/workbench.rs';s=p.read_text();s+='''
/// Logical compositions share the same UI-thread native owner and form adapter.
/// These are compile-time roles, never persisted IDs or management capabilities.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum WindowRole { Workbench, LayoutEditor, Preview, Status }
impl WindowRole { pub const ALL: [Self; 4] = [Self::Workbench, Self::LayoutEditor, Self::Preview, Self::Status]; }
''';p.write_text(s)
p=w/'crates/fc-windows/src/workbench.rs';s=p.read_text();s=s.replace('use fc_presentation::workbench::{','use fc_presentation::workbench::{WindowRole, ');s=s.replace('mod widgets;','mod widgets;\n#[path = "workbench/registry.rs"]\nmod registry;');s=s.replace('    hwnd: HWND,\n    state: Box<State>,','    hwnd: HWND,\n    role: Cell<WindowRole>,\n    state: Box<State>,')
s=s.replace('    pub fn new() -> Result<Self> {\n        let class', '''    pub fn new() -> Result<Self> {
        (registry::hooks(WindowRole::Workbench)?.create)()
    }
    fn create_native() -> Result<Self> {
        let class''')
s=s.replace('            hwnd: HWND::default(),\n            state:', '            hwnd: HWND::default(),\n            role: Cell::new(WindowRole::Workbench),\n            state:')
s=s.replace('    pub fn render(&self, view: &View) -> Result<()> {\n        view.validate()', '''    pub fn render(&self, view: &View) -> Result<()> {
        self.render_for(WindowRole::Workbench, view)
    }
    pub fn render_for(&self, role: WindowRole, view: &View) -> Result<()> {
        let hooks = registry::hooks(role)?;
        (hooks.bind)(self, view)?;
        self.role.set(role);
        (hooks.measure)(self)
    }
    fn bind_native(&self, view: &View) -> Result<()> {
        view.validate()''')
s=s.replace('        layout(self.hwnd, &self.state)?;\n        Ok(())\n    }\n    fn build_controls', '        Ok(())\n    }\n    fn measure_native(&self) -> Result<()> { layout(self.hwnd, &self.state) }\n    fn build_controls')
s=s.replace('    pub fn take_events(&self) -> Result<Vec<Event>> {\n        let error', '''    pub fn take_events(&self) -> Result<Vec<Event>> {
        (registry::hooks(self.role.get())?.input)(self)
    }
    fn input_native(&self) -> Result<Vec<Event>> {
        let error''')
s=s.replace('impl Drop for Window {\n    fn drop(&mut self) {', '''impl Drop for Window {
    fn drop(&mut self) {
        // Static validation happens before creation. Even a broken descriptor
        // must never strand an owned HWND during unwinding.
        match registry::hooks(self.role.get()) {
            Ok(hooks) => (hooks.dispose)(self),
            Err(_) => self.dispose_native(),
        }
    }
}
impl Window {
    fn dispose_native(&mut self) {''')
p.write_text(s)
q=w/'crates/fc-windows/src/workbench/registry.rs';q.write_text('''//! Explicit native window lifecycle implementations; all remain on their
//! original UI thread. Roles reuse one adapter, not additional hidden windows.
use super::*;
use fc_presentation::registry::{Registration, Registry};
pub(super) struct Hooks {
    pub create: fn() -> Result<Window>,
    pub bind: fn(&Window, &View) -> Result<()>,
    pub measure: fn(&Window) -> Result<()>,
    pub input: fn(&Window) -> Result<Vec<Event>>,
    pub dispose: fn(&mut Window),
}
const fn form() -> Hooks { Hooks { create: Window::create_native, bind: Window::bind_native, measure: Window::measure_native, input: Window::input_native, dispose: Window::dispose_native } }
static WINDOWS: &[Registration<WindowRole, Hooks>] = &[
    Registration { key: WindowRole::Workbench, implementation: form() },
    Registration { key: WindowRole::LayoutEditor, implementation: form() },
    Registration { key: WindowRole::Preview, implementation: form() },
    Registration { key: WindowRole::Status, implementation: form() },
];
pub(super) fn hooks(role: WindowRole) -> Result<&'static Hooks> {
    let registry = Registry::new(WINDOWS).map_err(|_| Error::from_hresult(E_UNEXPECTED))?;
    registry.require(&WindowRole::ALL).map_err(|_| Error::from_hresult(E_UNEXPECTED))?;
    registry.get(role).map_err(|_| Error::from_hresult(E_UNEXPECTED))
}
''')
q=w/'crates/fc-bootstrap/src/application/window_registry.rs';q.write_text('''//! Production window composition. Native registrations own creation, binding,
//! measurement, captured input and disposal; this layer selects only the role.
use super::*;
use fc_presentation::{registry::{Registration, Registry}, workbench::WindowRole};
static WINDOWS: &[Registration<Screen, WindowRole>] = &[
'''+''.join(f'    Registration {{ key: Screen::{x}, implementation: WindowRole::{("LayoutEditor" if x in ("Display","Profiles","ProfileContent") else "Status" if x in ("Starting","Restoring","Repair") else "Preview" if x=="Code" else "Workbench")} }},\n' for x in ['Starting','Setup','Login','Recovery','Code','Home','School','Subjects','Accounts','Password','Rotate','Homework','HomeworkEdit','Schedule','Calendar','Autostart','Backup','Restoring','Display','Profiles','ProfileContent','Materials','Lesson','Voice','Web','HttpsSettings','ExitDraft','Repair'])+'''];
pub(super) fn create_workbench() -> windows::core::Result<Window> {
    let registry = Registry::new(WINDOWS).map_err(|_| windows::core::Error::from_hresult(windows::Win32::Foundation::E_UNEXPECTED))?;
    registry.require(Screen::ALL).map_err(|_| windows::core::Error::from_hresult(windows::Win32::Foundation::E_UNEXPECTED))?;
    Window::new()
}
pub(super) fn render(window: &Window, screen: Screen, view: &View) -> windows::core::Result<()> {
    let role = Registry::new(WINDOWS).and_then(|registry| registry.get(screen)).map_err(|_| windows::core::Error::from_hresult(windows::Win32::Foundation::E_UNEXPECTED))?;
    window.render_for(*role, view)
}
''')
p=w/'crates/fc-bootstrap/src/application.rs';s=p.read_text();s=s.replace('        self.window\n            .render(&self.view())','        window_registry::render(&self.window, self.screen, &self.view())');p.write_text(s)
