from pathlib import Path
w=Path('/tmp/fc-round80-controlled-repair/checkout-r06-registry-first')
p=w/'crates/fc-windows/src/desktop.rs';s=p.read_text();s=s.replace('mod tree;','mod tree;\n#[path = "desktop/registry.rs"]\nmod registry;');s=s.replace('                validate_card(card)?;\n                let body = prepare_content(&self.graphics, card, scene.public_calendar_unverified)?;', '''                let hooks = registry::hooks(card.kind)?;
                (hooks.bind)(card)?;
                let body = (hooks.measure)(&self.graphics, card, scene.public_calendar_unverified)?;''');s=s.replace('                let surface = self.surface(static_rect)?;', '                let surface = (hooks.create)(self, static_rect)?;')
a=s.index('fn title(kind: ComponentKind)');b=s.index('fn render_card(',a);s=s[:a]+s[b:]
a=s.index('fn render_card(');b=s.index('    // SAFETY below:',a)
s=s[:a]+'''fn render_card(g: &Graphics, c: &mut Card) -> Result<()> {
    (registry::hooks(c.source.kind)?.render)(g, c)
}
fn render_frame(g: &Graphics, c: &mut Card) -> Result<()> {
'''+s[b:]
s=s.replace('title(c.source.kind),','registry::hooks(c.source.kind)?.title,')
a=s.index('            if let CardContent::Clock(clock) = c.source.content {',s.index('fn render_frame'));b=s.index('\n        }\n        target.EndDraw',a)
s=s[:a]+'            (registry::hooks(c.source.kind)?.decorate)(&target, c)?;'+s[b:]
s=s.replace('fn render_dynamic(g: &Graphics, c: &mut Card, now: LocalDateTime) -> Result<()> {','''fn render_dynamic(g: &Graphics, c: &mut Card, now: LocalDateTime) -> Result<()> {
    (registry::hooks(c.source.kind)?.dynamic)(g, c, now)
}
fn render_dynamic_frame(g: &Graphics, c: &mut Card, now: LocalDateTime) -> Result<()> {''')
s=s.replace('fn render_inputs(g: &Graphics, c: &mut Card) -> Result<()> {','''fn render_inputs(g: &Graphics, c: &mut Card) -> Result<()> {
    (registry::hooks(c.source.kind)?.input)(g, c)
}
fn render_input_strip(g: &Graphics, c: &mut Card) -> Result<()> {''')
s=s.replace('impl Card {\n    fn hide', '''impl Drop for Card {
    fn drop(&mut self) {
        // Fields retain native ownership and are dropped after the registered
        // lifecycle hides every surface, including partially prepared cards.
        match registry::hooks(self.source.kind) {
            Ok(hooks) => (hooks.dispose)(self),
            Err(_) => self.hide(),
        }
    }
}
impl Card {
    fn hide''')
p.write_text(s)
q=w/'crates/fc-windows/src/desktop/registry.rs';q.write_text('''//! Built-in desktop implementations. Shared frame drawing and native ownership
//! remain here; each registration supplies its actual lifecycle and decoration.
use super::*;
use fc_presentation::registry::{Registration, Registry};
pub(super) struct Hooks {
    pub title: &'static str,
    pub bind: fn(&SceneCard) -> Result<()>,
    pub create: fn(&DesktopRenderer, Rect) -> Result<Surface>,
    pub measure: fn(&Graphics, &SceneCard, bool) -> Result<ContentLayout>,
    pub render: fn(&Graphics, &mut Card) -> Result<()>,
    pub decorate: fn(&ID2D1DCRenderTarget, &Card) -> Result<()>,
    pub dynamic: fn(&Graphics, &mut Card, LocalDateTime) -> Result<()>,
    pub input: fn(&Graphics, &mut Card) -> Result<()>,
    pub dispose: fn(&Card),
}
const fn frame(title: &'static str) -> Hooks {
    Hooks { title, bind: validate_card, create: DesktopRenderer::surface,
        measure: prepare_content, render: render_frame, decorate: no_decoration,
        dynamic: no_dynamic, input: render_input_strip, dispose: Card::hide }
}
const fn clock() -> Hooks { let mut hooks = frame("时钟"); hooks.decorate = clock_dial; hooks.dynamic = render_dynamic_frame; hooks }
const fn recess() -> Hooks { let mut hooks = frame("课间倒计时"); hooks.dynamic = render_dynamic_frame; hooks }
const fn schedule() -> Hooks { let mut hooks = frame("今日课表"); hooks.render = schedule_frame; hooks }
static COMPONENTS: &[Registration<ComponentKind, Hooks>] = &[
    Registration { key: ComponentKind::Clock, implementation: clock() },
    Registration { key: ComponentKind::Date, implementation: frame("日期") },
    Registration { key: ComponentKind::Schedule, implementation: schedule() },
    Registration { key: ComponentKind::Homework, implementation: frame("今日作业") },
    Registration { key: ComponentKind::Materials, implementation: frame("课堂资料") },
    Registration { key: ComponentKind::Reminder, implementation: frame("今日提醒") },
    Registration { key: ComponentKind::DateCountdown, implementation: frame("日期倒计时") },
    Registration { key: ComponentKind::Recess, implementation: recess() },
    Registration { key: ComponentKind::SubjectText, implementation: frame("独立文字") },
    Registration { key: ComponentKind::SubjectImage, implementation: frame("独立图片") },
];
const KINDS: [ComponentKind; 10] = [ComponentKind::Clock, ComponentKind::Date, ComponentKind::Schedule, ComponentKind::Homework, ComponentKind::Materials, ComponentKind::Reminder, ComponentKind::DateCountdown, ComponentKind::Recess, ComponentKind::SubjectText, ComponentKind::SubjectImage];
pub(super) fn hooks(kind: ComponentKind) -> Result<&'static Hooks> {
    let registry = Registry::new(COMPONENTS).map_err(|_| Error::from_hresult(E_UNEXPECTED))?;
    registry.require(&KINDS).map_err(|_| Error::from_hresult(E_UNEXPECTED))?;
    registry.get(kind).map_err(|_| Error::from_hresult(E_UNEXPECTED))
}
fn no_decoration(_: &ID2D1DCRenderTarget, _: &Card) -> Result<()> { Ok(()) }
fn no_dynamic(_: &Graphics, _: &mut Card, _: LocalDateTime) -> Result<()> { Ok(()) }
fn clock_dial(target: &ID2D1DCRenderTarget, card: &Card) -> Result<()> {
    if matches!(card.source.content, CardContent::Clock(clock) if clock.mode == ClockMode::Analog) { draw_dial(target, card)?; }
    Ok(())
}
fn schedule_frame(graphics: &Graphics, card: &mut Card) -> Result<()> {
    if let CardContent::LessonControl { caption, can_change } = &card.source.content {
        render_lesson_control(graphics, card, caption.clone(), *can_change)
    } else { render_frame(graphics, card) }
}
''')
