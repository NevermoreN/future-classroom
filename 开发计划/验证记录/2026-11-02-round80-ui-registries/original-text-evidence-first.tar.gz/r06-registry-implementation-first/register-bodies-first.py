from pathlib import Path
import re
w=Path('/tmp/fc-round80-controlled-repair/checkout-r06-registry-first')
p=w/'crates/fc-presentation/src/card_body.rs';s=p.read_text();a=s.index('    let mut push = |text: String,',s.index('pub fn card_body_spec'));m=s.index('    match content {',a);e=s.index('    spec.validate()?;',m)
match=s[m:e]
# Extract composition arms by balancing braces, including the single expression arm.
rows=[];pos=len('    match content {\n')
while pos<len(match):
 while pos<len(match) and match[pos].isspace():pos+=1
 if pos>=len(match) or match[pos]=='}':break
 arrow=match.index('=>',pos);pattern=match[pos:arrow].strip();start=arrow+2
 while match[start].isspace():start+=1
 if match[start]=='{':
  depth=1;j=start+1;instr=False;escape=False
  while depth:
   c=match[j]
   if instr:
    if escape:escape=False
    elif c=='\\':escape=True
    elif c=='"':instr=False
   elif c=='"':instr=True
   elif c=='{':depth+=1
   elif c=='}':depth-=1
   j+=1
  body=match[start+1:j-1];pos=j
 else:
  j=match.index('\n',start);body=match[start:j].rstrip(',');pos=j
 if pattern=='_':break
 rows.append((pattern,body))
assert len(rows)==10,len(rows)
names=['clock','recess','lesson','text','standalone','image','courses','homework','materials','unavailable']
# actual arms include clock,recess,lesson,text,standalone,image,courses,homework,materials,unavailable =10

variants=['Clock','Recess','LessonControl','Text','StandaloneText','Image','Courses','Homework','Materials','MaterialsUnavailable']
kinds=['Clock','Recess','Schedule',None,'SubjectText','SubjectImage','Schedule','Homework','Materials','Materials']
allkinds=['Clock','Date','Schedule','Homework','Materials','Reminder','DateCountdown','Recess','SubjectText','SubjectImage']
extra="""
#[derive(Clone, Copy, PartialEq, Eq)]
enum BodyKind { Clock, Recess, LessonControl, Text, StandaloneText, Image, Courses, Homework, Materials, MaterialsUnavailable }
impl BodyKind {
    fn of(content: &CardContent) -> Self { match content {
        CardContent::Clock(_) => Self::Clock,
        CardContent::Recess { .. } => Self::Recess,
        CardContent::LessonControl { .. } => Self::LessonControl,
        CardContent::Text(_) => Self::Text,
        CardContent::StandaloneText(_) => Self::StandaloneText,
        CardContent::Image(_) => Self::Image,
        CardContent::Courses(_) => Self::Courses,
        CardContent::Homework(_) => Self::Homework,
        CardContent::Materials(_) => Self::Materials,
        CardContent::MaterialsUnavailable => Self::MaterialsUnavailable,
    } }
}
type BodyBuilder = fn(&mut CardBodySpec, &CardContent, Option<&str>) -> Result<(), CardBodyError>;
static BODIES: &[crate::registry::Registration<(ComponentKind, BodyKind), BodyBuilder>] = &[
"""
for name,variant,kind in zip(names,variants,kinds):
 for k in ([kind] if kind else allkinds):
  extra+=f'    crate::registry::Registration {{ key: (ComponentKind::{k}, BodyKind::{variant}), implementation: bind_{name} }},\n'
extra+='];\n'
for (pattern,body),name in zip(rows,names):
 pattern=pattern.split(' if kind ==')[0]
 body=body.replace('push(', 'push(spec, ')
 note='note' if name in ['materials','unavailable'] else '_note'
 extra+=f'fn bind_{name}(spec: &mut CardBodySpec, content: &CardContent, {note}: Option<&str>) -> Result<(), CardBodyError> {{\n    let {pattern} = content else {{ return Err(CardBodyError::InvalidContent); }};\n'+body.rstrip().rstrip(',')+';\n    Ok(())\n}\n'
extra+="""
fn push(spec: &mut CardBodySpec, text: String, center: bool, fill: Option<(Rgb, f32, f32)>, leaf: Option<usize>, role: CardBodyRole) {
    spec.blocks.push(CardBodyBlock { text, center, fill, leaf, role, min_height: if fill.is_some() || role != CardBodyRole::Plain { 44. } else { 24. } });
}
"""
s=s[:a]+"""    let registry = crate::registry::Registry::new(BODIES).map_err(|_| CardBodyError::InvalidContent)?;
    let builder = registry.get((kind, BodyKind::of(content))).map_err(|_| CardBodyError::InvalidContent)?;
    builder(&mut spec, content, note)?;
"""+s[e:]+extra
p.write_text(s)
