from pathlib import Path
import re
W=Path('/tmp/fc-round80-controlled-repair/checkout-r06-registry-first');p=W/'crates/fc-bootstrap/src/application.rs';s=p.read_text();start=s.index('    fn view(&self) -> View {');end=s.index('    fn render(&self)',start);v=s[start:end];mstart=v.index('        match self.screen {');mend=v.rindex('\n        }\n        view');arms=v[mstart+len('        match self.screen {'):mend];heads=list(re.finditer(r'^            Screen::',arms,re.M));parsed=[]
for i,h in enumerate(heads):
 part=arms[h.start():heads[i+1].start() if i+1<len(heads) else len(arms)].strip();header,body=part.split('=>',1);body=body.strip();assert body.startswith('{') and body.endswith('}');parsed.append((re.findall(r'Screen::(\w+)',header),body[1:-1].strip()))
variants=re.findall(r'^    (\w+),$',s[s.index('enum Screen {'):s.index('\n}',s.index('enum Screen {'))],re.M);assert sorted(n for ns,_ in parsed for n in ns)==sorted(variants)
early=v[v.index('        if matches!(self.screen, Screen::Backup'):v.index('        let mut view = View {')];patterns=list(re.finditer(r'^        if (?:self\.screen == Screen::\w+|matches!\(self\.screen, Screen::Backup \| Screen::Restoring\)|self\.public_lesson_flow\.is_some\(\)) \{',early,re.M));special={};public=''
for i,m in enumerate(patterns):
 block=early[m.start():patterns[i+1].start() if i+1<len(patterns) else len(early)].rstrip()
 if 'self.public_lesson_flow.is_some()' in block.split('\n')[0]:public=block;continue
 for n in re.findall(r'Screen::(\w+)',block.split('\n')[0]):special[n]=block
assert public and len(special)==14
base='''//! Static settings-page implementations. Business authorization remains in the
//! original usecases; registration does not create a management capability.
use super::*;
use fc_presentation::registry::{Registration, Registry, RegistrationError};
struct Page { render: fn(&App, &str) -> View }
'''
base+='static PAGES: &[Registration<Screen, Page>] = &[\n'
for ns,_ in parsed:
 for n in ns:base+=f'    Registration {{ key: Screen::{n}, implementation: Page {{ render: page_{ns[0].lower()} }} }},\n'
base+='];\npub(super) fn validate() -> std::result::Result<(), RegistrationError> { Registry::new(PAGES)?.require(Screen::ALL) }\n'
base+='''pub(super) fn view(app: &App, status: &str) -> View {
    match Registry::new(PAGES).and_then(|registry| registry.get(app.screen)) {
        Ok(page) => (page.render)(app, status),
        Err(_) => View { title: "页面注册不可用".into(), description: "已停止页面输入，请正常关闭后核对程序。".into(), status: String::new(), fields: vec![], actions: vec![], busy: true, grid: None },
    }
}
fn field(id: FieldId, label: &str, kind: FieldKind, value: String, max_utf16: usize) -> Field { Field { id, label: label.into(), kind, value, max_utf16 } }
fn action(id: ActionId, label: &str) -> Action { Action { id, label: label.into(), enabled: true } }
fn plain(id: FieldId, label: &str, value: String) -> Field { field(id, label, FieldKind::Text, value, 128) }
fn secret(id: FieldId, label: &str) -> Field { field(id, label, FieldKind::Password, String::new(), 256) }
fn frame(app: &App, status: &str) -> View { View { title: "未来教室".into(), description: String::new(), status: status.into(), fields: vec![], actions: vec![], busy: app.pending.is_some() || app.stopping, grid: None } }
fn public_view(app: &App, status: &str) -> Option<View> {
    if app.public_lesson_flow.is_none() { return None; }
    if let Some(editor) = &app.public_lesson_editor {
        return Some(editor.view(status, app.pending.is_some() || app.stopping || app.public_lesson_flow.as_ref().is_some_and(|flow| flow.guard().is_waiting_for_authority())));
    }
    Some(View { title: "正在读取本节课程".into(), description: "本节临时换课仅影响当前这一节。".into(), status: status.into(), fields: vec![], actions: vec![Action { id: public_lesson_editor::CLOSE, label: "关闭".into(), enabled: true }], busy: app.pending.is_some() || app.stopping, grid: None })
}
'''
for names,body in parsed:
 name=names[0];specialblock=re.sub(r'\bself\b','app',special.get(name,''));base+=f'\nfn page_{name.lower()}(app: &App, status: &str) -> View {{\n    let status = status.to_owned();\n';before=name in ['Backup','Restoring','Profiles','ProfileContent','Accounts']
 if specialblock and before:base+=specialblock+'\n'
 base+='    if let Some(view) = public_view(app, &status) { return view; }\n'
 if specialblock and not before:base+=specialblock+'\n'
 base+='    let mut view = frame(app, &status);\n'
 if re.search(r'\bschool\b',body):base+='    let school = app.state.installation.as_ref().map(|i| i.school_name.as_str()).unwrap_or("未配置学校");\n'
 base+=re.sub(r'\bself\b','app',body)+'\n    view\n}\n'
(W/'crates/fc-bootstrap/src/application/settings_registry.rs').write_text(base);prefix=v[:v.index('        if matches!')];s=s[:start]+prefix+'        settings_registry::view(self, &status)\n    }\n'+s[end:];insert=s.index('\n#[derive(Clone, Copy, PartialEq, Eq)]\nenum Screen');s=s[:insert]+'\nmod settings_registry;\nmod window_registry;\n'+s[insert:];end_enum=s.index('\n}',s.index('enum Screen {'))+2;s=s[:end_enum]+'\nimpl Screen {\n    const ALL: &\'static [Self] = &['+', '.join('Self::'+n for n in variants)+'];\n}\n'+s[end_enum:];s=s.replace('    let window = Window::new().map_err(|_| "无法创建工作台".to_owned())?;','    settings_registry::validate().map_err(|_| "设置页注册不完整或重复".to_owned())?;\n    let window = window_registry::create_workbench().map_err(|_| "无法创建工作台".to_owned())?;',1);p.write_text(s);print('registeredPages',len(variants),'specializedPages',len(special),'fallbackHandlers',len(parsed))
