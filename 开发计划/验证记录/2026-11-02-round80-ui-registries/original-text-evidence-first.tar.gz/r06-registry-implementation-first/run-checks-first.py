import os,json,time,subprocess,hashlib,signal
from pathlib import Path
R=Path('/tmp/fc-round80-controlled-repair');W=R/'checkout-r06-registry-first';P=R/'r06-registry-implementation-first';T=R/'r06-registry-target-first';D=P/'checks-first';D.mkdir(exist_ok=False);tmp=D/'tmp';tmp.mkdir();env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(T),TMPDIR=str(tmp),TEMP=str(tmp),TMP=str(tmp));rows=[]
def snapshot():
 return [{'path':p.relative_to(W).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for root in ['crates','scripts'] for p in sorted((W/root).rglob('*')) if p.is_file() and not p.is_symlink() and p.suffix in ['.rs','.toml','.py','.sh']]
before=snapshot();(D/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
commands=[('architecture',['python3','scripts/check-architecture.py'],60),('presentation-tests',['cargo','test','-p','fc-presentation','--release','--locked','--offline','--','--test-threads=1'],600),('windows-check',['cargo','check','-p','fc-bootstrap','-p','fc-windows','--all-targets','--target','x86_64-pc-windows-gnu','--locked','--offline'],600),('windows-clippy',['cargo','clippy','-p','fc-bootstrap','-p','fc-windows','--all-targets','--target','x86_64-pc-windows-gnu','--locked','--offline','--','-D','warnings'],600)]
for name,argv,budget in commands:
 start=time.monotonic();out=D/(name+'.stdout.log');err=D/(name+'.stderr.log')
 with out.open('wb') as o,err.open('wb') as e:
  p=subprocess.Popen(argv,cwd=W,env=env,stdout=o,stderr=e,start_new_session=True)
  (D/'active.json').write_text(json.dumps({'name':name,'pid':p.pid,'argv':argv,'budgetSeconds':budget})+'\n')
  timeout=False
  try:code=p.wait(timeout=budget)
  except subprocess.TimeoutExpired:
   timeout=True;os.killpg(p.pid,signal.SIGKILL);code=p.wait()
 row={'name':name,'argv':argv,'exit':code,'timeout':timeout,'elapsedSeconds':time.monotonic()-start};rows.append(row);(D/'report.json').write_text(json.dumps({'checks':rows,'complete':False},indent=2)+'\n')
 if code:break
after=snapshot();(D/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');remaining=[x.name for x in tmp.iterdir()];tmp.rmdir() if not remaining else None
(D/'report.json').write_text(json.dumps({'checks':rows,'complete':len(rows)==len(commands),'sourceUnchanged':before==after,'temporaryResiduals':remaining,'scope':'Host pure presentation tests; GNU Windows static checking. No Windows execution.'},indent=2)+'\n')
(D/'active.json').unlink();print(json.dumps(rows))
