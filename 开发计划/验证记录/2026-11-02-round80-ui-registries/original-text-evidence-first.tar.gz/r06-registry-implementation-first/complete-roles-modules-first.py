from pathlib import Path
w=Path('/tmp/fc-round80-controlled-repair/checkout-r06-registry-first')
p=w/'crates/fc-presentation/src/workbench.rs';s=p.read_text().replace('pub enum WindowRole {\n    Workbench,','pub enum WindowRole {\n    Display,\n    Workbench,').replace('pub const ALL: [Self; 4] = [','pub const FORMS: [Self; 4] = [');p.write_text(s)
p=w/'crates/fc-windows/src/workbench/registry.rs';s=p.read_text().replace('require(&WindowRole::ALL)','require(&WindowRole::FORMS)');p.write_text(s)
p=w/'crates/fc-windows/src/workbench.rs';s=p.read_text().replace('for role in WindowRole::ALL {','for role in WindowRole::FORMS {');s=s.replace('            assert_eq!(WORKBENCHES.with(|windows| windows.borrow().len()), count + 1);','''            let last_role = window.role.get();
            assert!(window.render_for(WindowRole::Display, &model).is_err());
            assert_eq!(window.role.get(), last_role);
            assert_eq!(read_edit(field(&window, 2)).unwrap(), "synthetic-role-draft");
            assert_eq!(WORKBENCHES.with(|windows| windows.borrow().len()), count + 1);''');p.write_text(s)
p=w/'crates/fc-windows/src/desktop/registry.rs';s=p.read_text().replace('create: DesktopRenderer::surface,','create: display_surface,');s+='''
// Display surfaces have a different native owner/class and may never be
// substituted by the management form constructor, even though both use roles.
static WINDOWS: &[Registration<fc_presentation::workbench::WindowRole, fn(&DesktopRenderer, Rect) -> Result<Surface>>] = &[
    Registration { key: fc_presentation::workbench::WindowRole::Display, implementation: DesktopRenderer::surface },
];
fn display_surface(owner: &DesktopRenderer, rect: Rect) -> Result<Surface> {
    let create = Registry::new(WINDOWS).and_then(|registry| registry.get(fc_presentation::workbench::WindowRole::Display)).map_err(|_| Error::from_hresult(E_UNEXPECTED))?;
    create(owner, rect)
}
''';p.write_text(s)
p=w/'crates/fc-bootstrap/src/application.rs';s=p.read_text().replace('self.pool.request_stop();','module_registry::stop(module_registry::Kind::SharedWorkers, self);');s=s.replace('''        app.pool
            .join()
            .map_err(|_| "后台执行池关闭失败".to_owned())?;''','''        module_registry::join_workers(app.pool)?;''');p.write_text(s)
p=w/'crates/fc-bootstrap/src/application/module_registry.rs';s=p.read_text().replace('    Workers(fn() -> std::io::Result<shared_pool::SharedPool<Work>>),','    Workers(WorkerFactory),');idx=s.index('struct Module {');s=s[:idx]+'''struct WorkerFactory {
    create: fn() -> std::io::Result<shared_pool::SharedPool<Work>>,
    dispose: fn(shared_pool::SharedPool<Work>) -> std::result::Result<(), fc_runtime::worker::JoinError>,
}
'''+s[idx:];s=s.replace('Factory::Workers(shared_pool::SharedPool::start)','Factory::Workers(WorkerFactory { create: shared_pool::SharedPool::start, dispose: shared_pool::SharedPool::join })');s=s.replace('''    let Factory::Workers(create) = module(Kind::SharedWorkers)?.create else''','''    let Factory::Workers(factory) = &module(Kind::SharedWorkers)?.create else''').replace('    create().map_err(|_| "无法启动后台执行池".to_owned())','    (factory.create)().map_err(|_| "无法启动后台执行池".to_owned())');s+='''
pub(super) fn join_workers(pool: shared_pool::SharedPool<Work>) -> std::result::Result<(), String> {
    let Factory::Workers(factory) = &module(Kind::SharedWorkers)?.create else { return Err(wrong_factory()); };
    (factory.dispose)(pool).map_err(|_| "后台执行池关闭失败".to_owned())
}
''';p.write_text(s)
