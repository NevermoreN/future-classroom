// Test-only instrumentation. These process/thread objects never authorize a
// production session or settlement. A live shared MSI host is a recorded fact.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;

public sealed class Fc79Capture
{
    [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint access,bool inherit,uint pid);
    [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenThread(uint access,bool inherit,uint tid);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetProcessTimes(IntPtr p,out long creation,out long exit,out long kernel,out long user);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetThreadTimes(IntPtr p,out long creation,out long exit,out long kernel,out long user);
    [DllImport("kernel32.dll",SetLastError=true)] static extern uint GetProcessIdOfThread(IntPtr p);
    [DllImport("kernel32.dll",SetLastError=true,CharSet=CharSet.Unicode,ExactSpelling=true)] static extern bool QueryFullProcessImageNameW(IntPtr p,uint flags,StringBuilder text,ref uint length);
    [DllImport("advapi32.dll",SetLastError=true)] static extern bool OpenProcessToken(IntPtr p,uint access,out IntPtr token);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetExitCodeProcess(IntPtr p,out uint code);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetExitCodeThread(IntPtr p,out uint code);
    [DllImport("kernel32.dll",SetLastError=true)] static extern uint WaitForSingleObject(IntPtr p,uint ms);
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool CloseHandle(IntPtr p);
    [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool DuplicateHandle(IntPtr sourceProcess,IntPtr source,IntPtr targetProcess,out IntPtr target,uint access,bool inherit,uint options);
    public sealed class Fact
    {
        public uint Pid,Tid,Wait,ExitCode; public long Creation;
        public string Image,Sha256,Sid,Kind,Status,Error;
        public bool ExitKnown,CheckedClose; internal IntPtr Handle;
    }
    readonly List<Fact> facts=new List<Fact>();
    static void Win(bool v,string s) { if(!v)throw new Win32Exception(Marshal.GetLastWin32Error(),s); }
    public static string Hash(string path) {
        using(FileStream f=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete))
        using(SHA256 h=SHA256.Create()) { return BitConverter.ToString(h.ComputeHash(f)).Replace("-","").ToLowerInvariant(); }
    }
    static void Close(IntPtr p) { Win(CloseHandle(p),"CloseHandle"); }
    public Fact Hold(uint pid,long creation,string expectedImage,string expectedSha,string expectedSid)
    {
        foreach(Fact old in facts) if(old.Kind=="process" && old.Pid==pid && old.Creation==creation)return old;
        Fact x=new Fact();x.Pid=pid;x.Creation=creation;x.Kind="process";x.Status="UNKNOWN";
        x.Handle=OpenProcess(0x101000,false,pid); Win(x.Handle!=IntPtr.Zero,"OpenProcess");
        facts.Add(x);
        return Inspect(x,creation,expectedImage,expectedSha,expectedSid);
    }
    public Fact HoldStartedClient(IntPtr original,uint pid,long creation,string image,string imageSha,string sid)
    {
        Fact x=new Fact();x.Pid=pid;x.Creation=creation;x.Kind="process";x.Status="UNKNOWN";
        Win(DuplicateHandle(GetCurrentProcess(),original,GetCurrentProcess(),out x.Handle,0x101000,false,0),"DuplicateHandle(original client)");
        facts.Add(x);return Inspect(x,creation,image,imageSha,sid);
    }
    Fact Inspect(Fact x,long creation,string expectedImage,string expectedSha,string expectedSid)
    {
        try {
            long c,e,k,u;Win(GetProcessTimes(x.Handle,out c,out e,out k,out u),"GetProcessTimes");if(c!=creation)throw new InvalidOperationException("CREATION_CHANGED");
            StringBuilder image=new StringBuilder(32768);uint n=(uint)image.Capacity;Win(QueryFullProcessImageNameW(x.Handle,0,image,ref n),"QueryFullProcessImageNameW");x.Image=image.ToString();x.Sha256=Hash(x.Image);
            IntPtr token;Win(OpenProcessToken(x.Handle,8,out token),"OpenProcessToken");
            try { using(WindowsIdentity who=new WindowsIdentity(token))x.Sid=who.User.Value; }finally{Close(token);}
            if(!String.Equals(x.Image,expectedImage,StringComparison.OrdinalIgnoreCase) || x.Sha256!=expectedSha || x.Sid!=expectedSid)throw new InvalidOperationException("ORIGINAL_IDENTITY_MISMATCH");
            x.Status="HELD_ORIGINAL_IDENTITY";return x;
        }catch(Exception error){x.Error=error.Message;throw;}
    }
    public Fact HoldThread(uint pid,uint tid,long creation)
    {
        foreach(Fact old in facts)if(old.Kind=="thread" && old.Tid==tid && old.Creation==creation)return old;
        Fact x=new Fact();x.Pid=pid;x.Tid=tid;x.Creation=creation;x.Kind="thread";x.Status="UNKNOWN";
        x.Handle=OpenThread(0x100800,false,tid);Win(x.Handle!=IntPtr.Zero,"OpenThread");facts.Add(x);
        try {long c,e,k,u;Win(GetThreadTimes(x.Handle,out c,out e,out k,out u),"GetThreadTimes");if(c!=creation || GetProcessIdOfThread(x.Handle)!=pid)throw new InvalidOperationException("ORIGINAL_THREAD_MISMATCH");x.Status="HELD_ORIGINAL_IDENTITY";return x;}
        catch(Exception error){x.Error=error.Message;throw;}
    }
    public Fact[] Snapshot() {
        foreach(Fact x in facts)if(x.Handle!=IntPtr.Zero){x.Wait=WaitForSingleObject(x.Handle,0);if(x.Wait==0){uint code;Win(x.Kind=="thread"?GetExitCodeThread(x.Handle,out code):GetExitCodeProcess(x.Handle,out code),"GetExitCode");x.ExitCode=code;x.ExitKnown=true;}else if(x.Wait!=258)throw new Win32Exception(Marshal.GetLastWin32Error(),"WaitForSingleObject");}
        return facts.ToArray();
    }
    public Fact[] FinishAndClose() {
        Exception failure=null;
        try{Snapshot();}catch(Exception e){failure=e;}
        foreach(Fact x in facts)if(x.Handle!=IntPtr.Zero){try{Close(x.Handle);x.CheckedClose=true;x.Handle=IntPtr.Zero;}catch(Exception e){x.Error=e.Message;failure=e;}}
        if(failure!=null)throw failure;return facts.ToArray();
    }
}

public static class FcR06Foreground {
    [DllImport("user32.dll", ExactSpelling=true)] static extern IntPtr GetForegroundWindow();
    public static long Get() { return GetForegroundWindow().ToInt64(); }
}
