"""Root-only finite hidden R06 native test transport. Default is inert."""
import argparse,base64,hashlib,json,os,re,secrets,shutil,signal,struct,subprocess,time
from pathlib import Path
R=Path('/tmp/fc-round80-controlled-repair');P=Path(__file__).resolve().parent
SID='S-1-5-21-3896111207-1867804362-1971593122-1001'
PRODUCER=R/'r06-integrated-native-producer-closure-first/report.json'
PRODUCER_SHA='83639102af31606321bab9e81ea442ef9a5f26b031d8ed05a065e72c6a9596c5'
OLD=R/'r06-integrated-native-producer-first/report.json'
OLD_SHA='869daaa537560cdcddb4b59babbe79598ce692885fae36365d3a882a973c5a71'
W=R/'checkout-r06-integrated-first'
SOURCE=R/'r06-registry-implementation-first/source-identities-final.json'
SOURCE_SHA='74284e5dacdc583d92bdcbb498a8a6ce32c0bc5f436aea3faa3b7156c4ec180f'
COMMON=(P/'Common.ps1').read_text();CREATE=(P/'Create.ps1').read_text();RUN=(P/'Run.ps1').read_text();DELETE=(P/'Delete.ps1').read_text()
BOOT="""$ErrorActionPreference='Stop';[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);$global:LASTEXITCODE=0;try{& ([ScriptBlock]::Create([Console]::In.ReadToEnd()))}catch{[Console]::Error.WriteLine($_.Exception.ToString());$global:LASTEXITCODE=1};exit ([int]$global:LASTEXITCODE)"""
OWNED=r"$a=@(Get-CimInstance Win32_Process -ErrorAction Stop|Where-Object {$_.ExecutablePath -and $_.ExecutablePath.StartsWith($c.root+'\',[StringComparison]::OrdinalIgnoreCase)});@{count=$a.Count}|ConvertTo-Json -Compress"
CHUNKS={'create':COMMON+CREATE,'run':COMMON+RUN,'owned-processes':COMMON+OWNED,'inventory':COMMON+'Inventory $c.root|ConvertTo-Json -Depth 12 -Compress','delete':COMMON+DELETE}
TESTS=[
('roles','windows-tests.exe','workbench::tests::registered_roles_keep_identical_view_drafts_and_dispose_the_original_window'),
('page-routes','bootstrap-tests.exe','application::settings_registry::tests::incomplete_page_routes_and_cross_page_business_actions_fail_closed'),
('shutdown-open','bootstrap-tests.exe','application::tests::shutdown_during_open_hands_backend_to_shutdown_worker_before_pool_stops'),
('shutdown-audio','bootstrap-tests.exe','application::tests::shutdown_keeps_writer_alive_until_audio_acknowledges_native_release'),
('shutdown-full-queue','bootstrap-tests.exe','application::backup_shutdown_tests::full_shared_queue_delays_shutdown_until_the_writer_can_really_close')]
PUBLIC_STEPS=('setup-administrator-fixture','create-bound-class-and-subjects','seed-current-lesson','management-lock-removes-session','hidden-desktop-rendered','native-public-button-without-session','public-catalog-only','cancel-without-change','new-native-public-entry','unassigned-review-without-write','local-account-lock-keeps-public-flow','explicit-public-change-closes','changed-desktop-rendered','old-scene-entry-rejected','new-native-restore-entry','explicit-public-restore-closes','restored-desktop-rendered','public-close-hides-chooser','physical-shared-workers-shutdown','isolated-deployment-cleanup')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fact(p):
 p=Path(p);assert p.is_file() and not p.is_symlink();return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def exact_fact(f):
 p=Path(f['path']);assert p.is_absolute() and p.resolve().is_relative_to(R) and fact(p)=={k:f[k] for k in ('path','bytes','sha256')};return p
def qualify_exact(text,name):
 runs=re.findall(r'^running (\d+) tests?\r?$',text,re.M)
 assert runs==['1'],'EXACT_ONE_ORIGINAL_TEST_SCOPE'
 starts=re.findall(r'^test ([\w:]+) \.\.\.',text,re.M);assert starts==[name],'EXACT_TEST_NAME'
 summaries=re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text,re.M)
 assert len(summaries)==1 and summaries[0][:5]==('ok','1','0','0','0'),'EXACT_ONE_PASS_ZERO_FAILED_ZERO_IGNORED'
 return {'test':name,'passed':1,'failed':0,'ignored':0,'filtered':int(summaries[0][5])}
def qualify_public(text):
 rows=re.findall(r'^PUBLIC_DESKTOP_NATIVE_STEP index=(\d+) name=([\w-]+)\r?$',text,re.M)
 assert rows==[(str(i),n) for i,n in enumerate(PUBLIC_STEPS)],'EXACT_PUBLIC20_ORDER'
 done=re.findall(r'^PUBLIC_DESKTOP_NATIVE_PASS steps=20 shared_workers=2 public_session=NONE database_reopen=NOT_EXERCISED change_restore=PASS old_scene=REJECTED foreground=UNTOUCHED isolated_cleanup=PASS elapsed_ms=\d+\r?$',text,re.M)
 assert len(done)==1;return {'steps':20,'order':list(PUBLIC_STEPS),'physicalAudio':'NOT_EXERCISED','schoolData':'ISOLATED_SYNTHETIC_ONLY'}
def pe_i386(p):
 b=Path(p).read_bytes();assert b[:2]==b'MZ' and len(b)>=64;offset=struct.unpack_from('<I',b,60)[0];assert offset+26<=len(b) and b[offset:offset+4]==b'PE\0\0' and struct.unpack_from('<H',b,offset+4)[0]==0x14c and struct.unpack_from('<H',b,offset+24)[0]==0x10b

def admission():
 assert sha(PRODUCER)==PRODUCER_SHA and sha(OLD)==OLD_SHA and sha(SOURCE)==SOURCE_SHA
 pr=json.loads(PRODUCER.read_bytes());old=json.loads(OLD.read_bytes())
 assert pr['status']=='PASS_ORIGINAL_COMPILE_AND_EXACT_LOCAL_TEMP_CLEANUP_NATIVE_NOT_RUN_ORIGINAL_WRAPPER_FAIL_RETAINED'
 assert pr['originalWrapperStatus']==old['status']=='FAIL_RETAIN_ORIGINALS' and pr['runtime']=='NOT_RUN' and pr['compilerTempKnownAbsent'] is True
 assert exact_fact(pr['originalCompileReport'])==OLD and pr['originalCommands']==old['commands']
 commands=pr['originalCommands'];assert len(commands)==2 and all(x['actualExit']==0 and x['originalReaped'] is True and x['timeout'] is False for x in commands)
 assert commands[1]['argv']==['cargo','test','--no-run','--release','--target','i686-pc-windows-gnu','-p','fc-windows','-p','fc-bootstrap','--locked','--offline','--message-format=json']
 assert pr['sourceRoot']==str(W) and pr['sourceUnchanged'] is True and old['sourceUnchanged'] is True and pr['sourceBefore']==pr['sourceAfter']==old['sourceBefore']==old['sourceAfter']
 source=pr['sourceBefore'];assert len(source)==583 and len({x['path'] for x in source})==len(source)
 def verify_sources():
  for row in source:
   rel=Path(row['path']);assert not rel.is_absolute() and '..' not in rel.parts
   p=W/rel;f=fact(p);assert f['bytes']==row['bytes'] and f['sha256']==row['sha256']
 verify_sources()
 own=json.loads(SOURCE.read_bytes())['sources'];assert len(own)==12
 by_path={x['path']:x for x in source};assert all(by_path[x['path']]==x for x in own)
 stdout=OLD.parent/'test-compile.stdout.log';assert sha(stdout)==commands[1]['stdoutSha256']
 events=[json.loads(line) for line in stdout.read_bytes().splitlines() if line.strip()]
 artifacts=pr['artifacts'];assert len(artifacts)==3
 for item in artifacts:
  p=exact_fact({k:item[k] for k in ('path','bytes','sha256')});assert p.parent==PRODUCER.parent/'artifacts';pe_i386(p)
  original=exact_fact(item['originalArtifact']);assert original.read_bytes()==p.read_bytes()
  assert item['features']==['default'] and item['profile']['opt_level']=='3'
  matches=[e for e in events if e.get('reason')=='compiler-artifact' and e.get('executable')==str(original)]
  assert len(matches)==1 and all(matches[0][k]==item[k] for k in ('target','profile','features'))
 expected={'bootstrap-tests.exe':('fc-bootstrap',True,'crates/fc-bootstrap/src/main.rs'),'windows-tests.exe':('fc_windows',True,'crates/fc-windows/src/lib.rs'),'fc-bootstrap.exe':('fc-bootstrap',False,'crates/fc-bootstrap/src/main.rs')}
 selected={Path(x['path']).name:x for x in artifacts};assert set(selected)==set(expected)
 for name,(target,test,path) in expected.items():
  x=selected[name];assert x['target']['name']==target and x['profile']['test'] is test and x['target']['src_path']==str(W/path)
 # Actual test declarations/public ORDER are checked on the already frozen input,
 # not guessed from model names. They still require actual native 1/0/0 later.
 for _,exe,name in TESTS:
  leaf=name.rsplit('::',1)[1]
  file=('crates/fc-windows/src/workbench.rs' if exe=='windows-tests.exe' else 'crates/fc-bootstrap/src/application/settings_registry.rs' if 'settings_registry' in name else 'crates/fc-bootstrap/src/application/backup_shutdown_tests.rs' if 'backup_shutdown_tests' in name else 'crates/fc-bootstrap/src/application.rs')
  assert re.search(r'#\[test\]\s*fn '+leaf+r'\(', (W/file).read_text())
 public=(W/'crates/fc-bootstrap/src/application/public_desktop_probe.rs').read_text();order=public.split('pub(super) const ORDER: [&str; 20] = [',1)[1].split('];',1)[0];assert tuple(re.findall(r'"([\w-]+)"',order))==PUBLIC_STEPS
 assert 'let deadline = started + Duration::from_secs(120);' in public and 'DataPaths::isolated_test' in public and 'stop_owned_app(app, deadline)?;' in public
 return pr,selected,source,verify_sources

def inventory_valid(v):
 assert set(v)=={'files','directories'} and isinstance(v['files'],list) and isinstance(v['directories'],list)
 assert len(v['files'])<=128 and len(v['directories'])<=16
 seen=set()
 for row in v['files']:
  p=row['path'];assert isinstance(p,str) and p and '\\' not in p and ':' not in p and not p.startswith('/') and all(x not in ('','.','..') for x in p.split('/')) and p not in seen;seen.add(p)
  assert type(row['bytes']) is int and row['bytes']>=0 and re.fullmatch('[0-9a-f]{64}',row['sha256'])
 assert len(set(v['directories']))==len(v['directories'])
 for p in v['directories']:assert p and p not in seen and '\\' not in p and ':' not in p and not p.startswith('/') and all(x not in ('','.','..') for x in p.split('/'))
def verify_download(root,inv):
 inventory_valid(inv);have={};dirs=[]
 for p in root.rglob('*'):
  assert not p.is_symlink();rel=p.relative_to(root).as_posix()
  if p.is_dir():dirs.append(rel)
  else:have[rel]={'path':rel,'bytes':p.stat().st_size,'sha256':sha(p)}
 assert have=={x['path']:x for x in inv['files']} and set(dirs)==set(inv['directories'])

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');ap.add_argument('--validate-inputs-only',action='store_true');ap.add_argument('--preparation-freeze-sha256');args=ap.parse_args()
 if not args.execute and not args.validate_inputs_only:print('{"status":"NOT_RUN_DEFAULT_INERT"}');return 0
 assert not(args.execute and args.validate_inputs_only)
 pr,artifacts,sources,verify_sources=admission()
 if args.validate_inputs_only:print(json.dumps({'status':'PASS_LOCAL_CLOSED_INPUTS_NO_WINDOWS','artifacts':len(artifacts),'sources':len(sources),'exactTests':len(TESTS),'publicSteps':len(PUBLIC_STEPS)}));return 0
 freeze=P/'freeze-first.json';assert re.fullmatch('[0-9a-f]{64}',args.preparation_freeze_sha256 or '') and sha(freeze)==args.preparation_freeze_sha256
 fr=json.loads(freeze.read_bytes())
 for row in fr['files']:
  p=P/row['path'];assert not p.is_symlink() and p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
 frozen=[fact(P/x['path']) for x in fr['files']];controller=fact(Path(__file__).resolve());pf=fact(PRODUCER);of=fact(OLD)
 def unchanged():
  verify_sources();assert fact(PRODUCER)==pf and fact(OLD)==of and fact(Path(__file__).resolve())==controller and [fact(P/x['path']) for x in fr['files']]==frozen
 nonce=secrets.token_hex(16);out=R/('r06-native-runtime-'+nonce);out.mkdir();(out/'.owner').write_text('future-classroom-owned-r06-native-runtime-result/v1\n')
 r={'status':'STARTED','producerClosure':pf,'originalWrapper':of,'originalWrapperStill':'FAIL_RETAIN_ORIGINALS','sourceInputs':sources,'preparationFreeze':fact(freeze),'operations':[],'originalOuterSeconds':900,'nativeWholeSeconds':600,'cleanup':'NOT_RUN','runtimeScope':'5 exact hidden tests plus normal-main synthetic public20; no installer/Pending/network/physical audio'};start=time.monotonic();c={'nonce':nonce,'sid':SID,'root':None}
 def save():(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
 def call(label,argv,feed=None,limit=30,allowed=(0,)):
  left=900-(time.monotonic()-start);assert left>0;begin=time.monotonic();p=subprocess.Popen(argv,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);timeout=False
  try:so,se=p.communicate(feed,timeout=min(left,limit))
  except subprocess.TimeoutExpired:
   timeout=True
   try:os.killpg(p.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   so,se=p.communicate()
  sofile=out/(label+'.stdout.log');sefile=out/(label+'.stderr.log');sofile.write_bytes(so);sefile.write_bytes(se)
  operation={'label':label,'argv':argv,'actualExit':p.returncode,'originalLocalReaped':True,'remoteOriginalReturnUnknown':timeout,'elapsedSeconds':time.monotonic()-begin,'stdout':fact(sofile),'stderr':fact(sefile)};r['operations'].append(operation);save();assert not timeout and p.returncode in allowed,(label,p.returncode,'REMOTE_UNKNOWN' if timeout else 'KNOWN_NONZERO');return so,p.returncode
 def remote(label,body,limit=30,allowed=(0,)):
  feed=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+COMMON+body).encode();(out/(label+'.stdin.ps1')).write_bytes(feed)
  return call(label,['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','future-classroom-win11','powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(BOOT.encode('utf-16-le')).decode()],feed,limit,allowed)
 try:
  c['root']=json.loads(remote('create',CREATE)[0])['root'];r['windowsRoot']=c['root'];save()
  upload=out/'upload';upload.mkdir()
  for name,item in artifacts.items():shutil.copyfile(item['path'],upload/name)
  shutil.copyfile(P/'Capture.cs',upload/'Capture.cs');c['inputs']=[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(upload.iterdir())]
  for p in sorted(upload.iterdir()):call('upload-'+p.name,['scp','-q','-o','BatchMode=yes',str(p),'future-classroom-win11:'+c['root'].replace('\\','/')+'/'],limit=60)
  c['cases']=[{'name':name,'executable':exe,'argv':'--exact '+test+' --test-threads=1 --nocapture','sha256':artifacts[exe]['sha256'],'seconds':150} for name,exe,test in TESTS]
  c['cases'].append({'name':'public-desktop','executable':'fc-bootstrap.exe','argv':'--public-desktop-probe','sha256':artifacts['fc-bootstrap.exe']['sha256'],'seconds':150})
  raw,code=remote('run',RUN,600,(0,1));native=json.loads(raw);r['native']=native;r['runtimeActualExit']=code;save()
  # Even a known native FAIL may be downloaded. Unknown owners prevent deletion;
  # a known nonzero exit is not relabelled as physical return unknown.
  owned=json.loads(remote('owned-processes',OWNED)[0]);r['ownedProcesses']=owned
  inv=json.loads(remote('inventory','Inventory $c.root|ConvertTo-Json -Depth 12 -Compress')[0]);inventory_valid(inv);r['inventory']=inv;save()
  download=out/'download';download.mkdir();call('download',['scp','-q','-r','-o','BatchMode=yes','future-classroom-win11:'+c['root'].replace('\\','/'),str(download)],limit=90)
  local=download/Path(c['root'].replace('\\','/')).name;verify_download(local,inv)
  remote_inputs={x['path']:x for x in inv['files']}
  for item in c['inputs']:assert remote_inputs[item['name']]=={'path':item['name'],'bytes':item['bytes'],'sha256':item['sha256']}
  assert json.loads((local/'native-result.json').read_bytes())==native;r['completeDownloadVerified']=True;save()
  assert code==0 and native['status']=='PASS_R06_FIVE_EXACT_AND_PUBLIC20_NATIVE_WIN11_ONLY' and native['originalParentReturned'] is True and native['elapsedMilliseconds']<600000
  assert len(native['cases'])==6 and len(native['originalObjects'])==6 and owned['count']==0
  assert native['foregroundBefore']==native['foregroundAfter']
  qualified=[]
  for case,scope in zip(native['cases'],c['cases']):
   assert case['name']==scope['name'] and case['argv']==scope['argv'] and case['executable']==scope['executable'] and case['started'] is True and case['actualExit'] is True and case['exitCode']==0
   assert case['foregroundBefore']==case['foregroundAfter'] and case['endedWholeMilliseconds']<=case['originalDeadlineWholeMilliseconds']
   cap=case['original'];assert cap['Pid']==case['pid'] and cap['Creation']==case['creation'] and cap['Sid']==SID and cap['Sha256']==scope['sha256'] and cap['Kind']=='process'
   assert cap['Image'].lower()==(c['root']+'\\'+scope['executable']).lower()
   assert sum(x['Pid']==cap['Pid'] and x['Creation']==cap['Creation'] and x['Kind']=='process' for x in native['originalObjects'])==1
   qualified.append({'name':case['name'],**(qualify_public(case['stdout']) if case['name']=='public-desktop' else qualify_exact(case['stdout'],TESTS[len(qualified)][2]))})
  assert all(x['CheckedClose'] is True and x['Wait']==0 and x['ExitKnown'] is True and x['ExitCode']==0 for x in native['originalObjects'])
  r['qualifiedCases']=qualified;unchanged();c['inventory']=inv
  r['delete']=json.loads(remote('delete',DELETE)[0]);assert r['delete']['knownAbsent'] is True
  r['cleanup']='PASS_EXACT_DOWNLOADED_NONCE_KNOWN_ABSENT';r['status']='PASS_R06_EXACT5_PUBLIC20_NATIVE_WIN11_ONLY'
 except Exception as error:r.update(status='FAIL_RETAIN_ORIGINALS',errorType=type(error).__name__,error=str(error))
 try:unchanged();r['sourceAndControllerUnchanged']=True
 except Exception:r['sourceAndControllerUnchanged']=False;r['status']='FAIL_SOURCE_OR_CONTROLLER_CHANGED_RETAIN'
 r['elapsedSeconds']=time.monotonic()-start
 if r['elapsedSeconds']>=900:r['status']='FAIL_ORIGINAL_OUTER_BUDGET_EXCEEDED_RETAIN'
 save();print(json.dumps({'status':r['status'],'report':str(out/'report.json'),'sha256':sha(out/'report.json'),'error':r.get('error')}));return 0 if r['status']=='PASS_R06_EXACT5_PUBLIC20_NATIVE_WIN11_ONLY' else 1
if __name__=='__main__':raise SystemExit(main())
