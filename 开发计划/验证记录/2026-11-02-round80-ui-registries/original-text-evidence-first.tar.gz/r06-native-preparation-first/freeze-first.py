from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent
rows=[]
for p in sorted(P.rglob('*')):
 assert not p.is_symlink()
 if p.is_file() and p!=P/'freeze-first.json':
  b=p.read_bytes();rows.append({'path':p.relative_to(P).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
f=P/'freeze-first.json';f.write_text(json.dumps({'schema':'future-classroom-r06-native-preparation/v1','status':'FROZEN_STOPPED_WRITING_WINDOWS_NOT_RUN','files':rows,'fileCountIncludingFreeze':len(rows)+1},indent=2)+'\n');print(json.dumps({'fileCount':len(rows)+1,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'runnerSha256':hashlib.sha256((P/'run-native.py').read_bytes()).hexdigest()}))
