CheckRoot $c.root;$root=$c.root
foreach($x in $c.inputs){$f=Fact (Join-Path $root $x.name);if($f.bytes-ne$x.bytes-or$f.sha256-cne$x.sha256){throw 'INPUT_BYTES'}}
$oldTemp=$env:TEMP;$oldTmp=$env:TMP;$clock=[Diagnostics.Stopwatch]::StartNew();$capture=$null;$p=$null;$returned=$true;$started=$false
$r=@{status='FAIL_RETAIN';cases=@();originalWholeSeconds=600;sourceScope='R06_REGISTERED_UI_AND_ORIGINAL_PHYSICAL_SHUTDOWN';installer='NOT_EXERCISED';pending='NOT_TOUCHED';network='APPLICATION_LISTENER_NOT_STARTED_SSH_TRANSPORT_SEPARATE';physicalAudio='NO_PLAYBACK_JOB_SUBMITTED_HELD_FACTORY_SYNTHETIC';cleanup='ROOT_DOWNLOAD_THEN_EXACT_DELETE_REQUIRED'}
try{
 $env:TEMP=Join-Path $root 'compiler-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP)
 try{Add-Type -Path (Join-Path $root 'Capture.cs') -ErrorAction Stop}finally{$env:TEMP=$oldTemp;$env:TMP=$oldTmp}
 $capture=[Fc79Capture]::new();$r.foregroundBefore=[FcR06Foreground]::Get()
 foreach($s in $c.cases){
  if($clock.ElapsedMilliseconds-ge600000){throw 'WHOLE_BUDGET'}
  $env:TEMP=Join-Path $root ('test-temp-'+$s.name);$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP)
  $exe=Join-Path $root $s.executable
  $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$exe;$info.Arguments=$s.argv;$info.WorkingDirectory=$root;$info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
  $p=[Diagnostics.Process]::new();$p.StartInfo=$info;$started=$false;$returned=$true
  $case=@{name=$s.name;argv=$s.argv;executable=$s.executable;started=$false;actualExit=$false;exitCode=$null;foregroundBefore=[FcR06Foreground]::Get();originalSeconds=$s.seconds};$r.cases+=,$case
  $case.startedWholeMilliseconds=$clock.ElapsedMilliseconds;$case.originalDeadlineWholeMilliseconds=[Math]::Min(600000,$case.startedWholeMilliseconds+$s.seconds*1000)
  if(-not$p.Start()){throw 'START'};$started=$true;$case.started=$true;$returned=$false
  $case.pid=$p.Id;$case.creation=$p.StartTime.ToUniversalTime().ToFileTimeUtc()
  $stdout=$p.StandardOutput.ReadToEndAsync();$stderr=$p.StandardError.ReadToEndAsync()
  $case.original=$capture.HoldStartedClient($p.Handle,[uint32]$p.Id,[long]$case.creation,$exe,$s.sha256,$c.sid)
  $left=[int]($case.originalDeadlineWholeMilliseconds-$clock.ElapsedMilliseconds)
  if($left-le0-or-not$p.WaitForExit($left)){throw 'ORIGINAL_PARENT_UNKNOWN_RETAIN_NO_KILL'}
  $returned=$true;$p.Refresh();$case.actualExit=$true;$case.exitCode=$p.ExitCode
  if(-not[Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($stdout,$stderr),[int][Math]::Max(0,$case.originalDeadlineWholeMilliseconds-$clock.ElapsedMilliseconds))){throw 'ORIGINAL_PIPES_UNKNOWN'}
  $case.stdout=$stdout.Result;$case.stderr=$stderr.Result
  [IO.File]::WriteAllText((Join-Path $root ($s.name+'.stdout.log')),$case.stdout,[Text.UTF8Encoding]::new($false));[IO.File]::WriteAllText((Join-Path $root ($s.name+'.stderr.log')),$case.stderr,[Text.UTF8Encoding]::new($false))
  [void]$capture.Snapshot();$case.foregroundAfter=[FcR06Foreground]::Get();$case.endedWholeMilliseconds=$clock.ElapsedMilliseconds
  if($case.original.Wait-ne0-or-not$case.original.ExitKnown-or$case.original.ExitCode-ne$case.exitCode){throw 'ORIGINAL_RETURN_MISMATCH'}
  $p.Dispose();$p=$null
  if($case.foregroundAfter-ne$case.foregroundBefore){throw 'FOREGROUND_CHANGED_NO_RESTORE'}
  if($case.exitCode-ne0){throw 'NATIVE_ACTUAL_NONZERO'}
  if($case.endedWholeMilliseconds-gt$case.originalDeadlineWholeMilliseconds){throw 'ORIGINAL_CASE_DEADLINE'}
 }
 $r.foregroundAfter=[FcR06Foreground]::Get();if($r.foregroundAfter-ne$r.foregroundBefore){throw 'WHOLE_FOREGROUND_CHANGED_NO_RESTORE'}
 $r.status='PASS_R06_FIVE_EXACT_AND_PUBLIC20_NATIVE_WIN11_ONLY'
}catch{$r.error=$_.Exception.Message}finally{
 $env:TEMP=$oldTemp;$env:TMP=$oldTmp
 if($null-ne$p-and(-not$started-or$returned)){$p.Dispose()}
 if($null-ne$capture){try{$r.originalObjects=@($capture.FinishAndClose())}catch{$r.status='FAIL_RETAIN';$r.closeError=$_.Exception.Message}}
 $r.originalParentReturned=$returned;$r.elapsedMilliseconds=$clock.ElapsedMilliseconds
 if($clock.ElapsedMilliseconds-ge600000){$r.status='FAIL_RETAIN';$r.budgetExceeded=$true}
 [IO.File]::WriteAllText((Join-Path $root 'native-result.json'),($r|ConvertTo-Json -Depth 30),[Text.UTF8Encoding]::new($false))
}
$r|ConvertTo-Json -Depth 30 -Compress
if($r.status-cne'PASS_R06_FIVE_EXACT_AND_PUBLIC20_NATIVE_WIN11_ONLY'){$global:LASTEXITCODE=1}
