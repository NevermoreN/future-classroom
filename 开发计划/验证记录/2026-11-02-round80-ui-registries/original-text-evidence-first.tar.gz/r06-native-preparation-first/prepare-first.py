from pathlib import Path
import runpy,hashlib,json
P=Path('/tmp/fc-round80-controlled-repair/r06-native-preparation-first');R=P.parent
(P/'.owner').write_text('future-classroom-owned-r06-native-preparation/v1\n')
ref=R/'native-reference-first/run-negative-msi-r79-third.py';assert hashlib.sha256(ref.read_bytes()).hexdigest()=='da74f0058deac86507b712075904556780be6b262b18acb82415da6725c6e202';old=runpy.run_path(str(ref))
common=old['COMMON'].replace('r79-production-msi-','r80-r06-native-').replace('r79-production-msi-runtime/v1','r80-r06-native-runtime/v1')
(P/'Common.ps1').write_text(common)
(P/'Delete.ps1').write_text(old['DELETE'].replace('PRODUCT_RUNTIME_ROOT','R06_NATIVE_RUNTIME_ROOT'))
cap=R/'native-reference-first/Capture.cs';raw=cap.read_text();new=raw[:raw.index('    public static object Product(')]+'}\n';new='\n'.join(line for line in new.splitlines() if '[DllImport("msi.dll"' not in line and 'static extern uint GetFileAttributesW' not in line)+'\n';new+='''
public static class FcR06Foreground {
    [DllImport("user32.dll", ExactSpelling=true)] static extern IntPtr GetForegroundWindow();
    public static long Get() { return GetForegroundWindow().ToInt64(); }
}
''';(P/'Capture.cs').write_text(new)
(P/'reference-first.json').write_text(json.dumps({'commonAndDelete':{'path':str(ref),'sha256':hashlib.sha256(ref.read_bytes()).hexdigest()},'processCapture':{'path':str(cap),'sha256':hashlib.sha256(cap.read_bytes()).hexdigest()},'scope':'Process cap methods retained; unused MSI APIs and product helpers removed; read-only foreground sampler added. No Windows invocation.'},indent=2)+'\n')
