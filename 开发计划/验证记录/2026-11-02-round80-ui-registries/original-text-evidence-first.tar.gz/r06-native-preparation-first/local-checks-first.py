import ast,json,runpy,subprocess,sys,hashlib
from pathlib import Path
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent;script=P/'run-native.py';ast.parse(script.read_text());m=runpy.run_path(str(script));name=m['TESTS'][0][2];q=m['qualify_exact'];public=m['qualify_public'];checks=[]
valid='running 1 test\ntest '+name+' ... ok\ntest result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 84 filtered out; finished in 0.01s\n'
assert q(valid,name)['passed']==1
for label,bad in [('zero',valid.replace('running 1 test','running 0 tests').replace('1 passed','0 passed')),('wrong',valid.replace(name,'other::test')),('ignored',valid.replace('1 passed; 0 failed; 0 ignored','0 passed; 0 failed; 1 ignored')),('nested',valid+valid),('failed',valid.replace('ok. 1 passed; 0 failed','FAILED. 0 passed; 1 failed'))]:
 try:q(bad,name)
 except AssertionError:checks.append({'negative':label,'rejected':True})
 else:raise AssertionError(label)
pub=''.join(f'PUBLIC_DESKTOP_NATIVE_STEP index={i} name={s}\n' for i,s in enumerate(m['PUBLIC_STEPS']))+'PUBLIC_DESKTOP_NATIVE_PASS steps=20 shared_workers=2 public_session=NONE database_reopen=NOT_EXERCISED change_restore=PASS old_scene=REJECTED foreground=UNTOUCHED isolated_cleanup=PASS elapsed_ms=31\n'
assert public(pub)['steps']==20
try:public(pub.replace('index=19','index=18'))
except AssertionError:checks.append({'negative':'wrong-public-step','rejected':True})
else:raise AssertionError('public')
for label,args in [('default',[]),('input-admission',['--validate-inputs-only'])]:
 c=subprocess.run([sys.executable,'-B',str(script),*args],capture_output=True,timeout=30);(P/(label+'.stdout.log')).write_bytes(c.stdout);(P/(label+'.stderr.log')).write_bytes(c.stderr);assert c.returncode==0;checks.append({'name':label,'actualExit':c.returncode,'stdoutSha256':hashlib.sha256(c.stdout).hexdigest(),'stderrSha256':hashlib.sha256(c.stderr).hexdigest()})
chunks=P/'ps-ast-chunks';chunks.mkdir();rows=[]
for name,text in m['CHUNKS'].items():
 b=text.encode();p=chunks/(name+'.ps1');p.write_bytes(b);rows.append({'path':p.relative_to(P).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
# BOOT is independently included: it explicitly propagates the body's global
# native exit and catch failures, rather than trusting ScriptBlock exit behavior.
b=m['BOOT'].encode();(chunks/'bootstrap.ps1').write_bytes(b);rows.append({'path':'ps-ast-chunks/bootstrap.ps1','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
assert '$case.started=$true' in m['RUN'] and '$global:LASTEXITCODE=1' in m['RUN'] and 'exit ([int]$global:LASTEXITCODE)' in m['BOOT']
assert not any(x in (P/'Capture.cs').read_text() for x in ['msi.dll','MsiInstall','MsiBegin','MsiEnd','SetForegroundWindow'])
(P/'local-checks-first.json').write_text(json.dumps({'status':'PASS_LOCAL_PARSE_QUALIFIERS_AND_EXACT_INPUTS_WINDOWS_NOT_RUN','checks':checks,'chunks':rows,'powershellAST':'ROOT_EXECUTION_REQUIRED_NOT_RUN_HERE','CSharpCompilation':'ROOT_EXECUTION_REQUIRED_NOT_RUN_HERE','Windows':'NOT_RUN','noCargoGitSourceEdit':True},indent=2)+'\n');print(json.dumps({'checks':len(checks),'chunks':len(rows),'Windows':'NOT_RUN'}))
