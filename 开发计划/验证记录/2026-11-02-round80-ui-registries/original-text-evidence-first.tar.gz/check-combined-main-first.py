"""Check the actual merged main source; no native evidence borrowed wholesale."""
from pathlib import Path
import os,json,hashlib,subprocess,time,runpy
R=Path('/tmp/fc-round80-controlled-repair');W=Path('/workspace/共享/Eliora/未来教室计划');D=R/'combined-main-checks-first';assert not D.exists();D.mkdir();(D/'.owner').write_text('future-classroom-owned-combined-main-checks/v1\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inv():return runpy.run_path(str(W/'scripts/package-controlled-dev.py'))['source_inventory'](W)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=W);head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip();rows=[]
for p,key in [(R/'abi2-summary-output-integrated-checks-first/source-identities-first.json','files'),(R/'r06-registry-implementation-first/source-identities-final.json','sources')]:
 for x in json.loads(p.read_bytes())[key]:assert (W/x['path']).stat().st_size==x['bytes']and sha(W/x['path'])==x['sha256'];rows.append(x)
assert len(rows)==28 and len({x['path']for x in rows})==28
r=dict(status='RUNNING',commit=head,sourceBefore=inv(),exact28OwnedSources=rows,operations=[],nativeScopes='Separate same-source installer16 and UI12 native receipts; no combined-main native claim');env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(R/'carrier-abi2-target-first'),PYTHONDONTWRITEBYTECODE='1')
def save():(D/'report.json').write_text(json.dumps(r,indent=2)+'\n')
cmds=[('architecture',['python3','scripts/check-architecture.py']),('format',['cargo','fmt','--all','--','--check']),('gnu-check',['cargo','check','--locked','--offline','--target','i686-pc-windows-gnu','-p','fc-windows','-p','fc-bootstrap','--all-targets']),('gnu-clippy',['cargo','clippy','--locked','--offline','--target','i686-pc-windows-gnu','-p','fc-windows','-p','fc-bootstrap','--all-targets','--','-D','warnings']),('diff',['git','diff','--check'])]
for name,argv in cmds:
 t=time.monotonic()
 with(D/(name+'.stdout.log')).open('xb')as so,(D/(name+'.stderr.log')).open('xb')as se:
  p=subprocess.Popen(argv,cwd=W,env=env,stdout=so,stderr=se);(D/'active.json').write_text(json.dumps(dict(pid=p.pid,name=name,argv=argv))+'\n');code=p.wait(timeout=900)
 r['operations'].append(dict(name=name,argv=argv,actualExit=code,originalReaped=p.poll()is not None,seconds=time.monotonic()-t,stdoutSha256=sha(D/(name+'.stdout.log')),stderrSha256=sha(D/(name+'.stderr.log'))));save();print(name,code,flush=True)
 if code:break
r['sourceAfter']=inv();r['sourceUnchanged']=r['sourceBefore']==r['sourceAfter'];r['status']='PASS_COMBINED_MAIN_STATIC_CHECKS_ONLY'if len(r['operations'])==len(cmds)and all(x['actualExit']==0 for x in r['operations'])and r['sourceUnchanged']else'FAIL_RETAIN_ORIGINALS';save();(D/'active.json').unlink();print(json.dumps(dict(status=r['status'],commit=head,reportSha256=sha(D/'report.json'))));raise SystemExit(0 if r['status'].startswith('PASS')else 1)
