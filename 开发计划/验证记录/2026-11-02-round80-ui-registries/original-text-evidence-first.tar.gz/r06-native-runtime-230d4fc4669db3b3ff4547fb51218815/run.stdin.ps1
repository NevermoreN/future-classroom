$c='{"nonce":"230d4fc4669db3b3ff4547fb51218815","sid":"S-1-5-21-3896111207-1867804362-1971593122-1001","root":"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r80-r06-native-230d4fc4669db3b3ff4547fb51218815","inputs":[{"name":"Capture.cs","bytes":6527,"sha256":"e687c76e4b45c478ec1daaa62565e4ac293b1e76424727653c9d33fe47e2886a"},{"name":"bootstrap-tests.exe","bytes":12966052,"sha256":"4d979a929a32ff215664b68873bba4083e5548120efac5ae28413025b45a39b4"},{"name":"fc-bootstrap.exe","bytes":13455250,"sha256":"2e01971680cc99a82ec03ca70344a0b3ad967a527a8930f8f7253e6ff026047c"},{"name":"windows-tests.exe","bytes":4566745,"sha256":"42279d4991ff39e904c2524e6eae20ae7307edb43fff7b2b564484bb5fa25a0c"}],"cases":[{"name":"roles","executable":"windows-tests.exe","argv":"--exact workbench::tests::registered_roles_keep_identical_view_drafts_and_dispose_the_original_window --test-threads=1 --nocapture","sha256":"42279d4991ff39e904c2524e6eae20ae7307edb43fff7b2b564484bb5fa25a0c","seconds":150},{"name":"page-routes","executable":"bootstrap-tests.exe","argv":"--exact application::settings_registry::tests::incomplete_page_routes_and_cross_page_business_actions_fail_closed --test-threads=1 --nocapture","sha256":"4d979a929a32ff215664b68873bba4083e5548120efac5ae28413025b45a39b4","seconds":150},{"name":"shutdown-open","executable":"bootstrap-tests.exe","argv":"--exact application::tests::shutdown_during_open_hands_backend_to_shutdown_worker_before_pool_stops --test-threads=1 --nocapture","sha256":"4d979a929a32ff215664b68873bba4083e5548120efac5ae28413025b45a39b4","seconds":150},{"name":"shutdown-audio","executable":"bootstrap-tests.exe","argv":"--exact application::tests::shutdown_keeps_writer_alive_until_audio_acknowledges_native_release --test-threads=1 --nocapture","sha256":"4d979a929a32ff215664b68873bba4083e5548120efac5ae28413025b45a39b4","seconds":150},{"name":"shutdown-full-queue","executable":"bootstrap-tests.exe","argv":"--exact application::backup_shutdown_tests::full_shared_queue_delays_shutdown_until_the_writer_can_really_close --test-threads=1 --nocapture","sha256":"4d979a929a32ff215664b68873bba4083e5548120efac5ae28413025b45a39b4","seconds":150},{"name":"public-desktop","executable":"fc-bootstrap.exe","argv":"--public-desktop-probe","sha256":"2e01971680cc99a82ec03ca70344a0b3ad967a527a8930f8f7253e6ff026047c","seconds":150}]}'|ConvertFrom-Json;$ErrorActionPreference='Stop';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function RootPath {return Join-Path ([IO.Path]::GetFullPath($env:TEMP)) ('FutureClassroom-r80-r06-native-'+$c.nonce)}
function Fact($p){$a=[IO.File]::GetAttributes($p);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0 -or ($a-band[IO.FileAttributes]::Directory)-ne0){throw 'REGULAR_NO_REPARSE'};return @{bytes=[long]([IO.FileInfo]::new($p).Length);sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function CheckRoot($root){if($root-cne$c.root -or [IO.Path]::GetFileName($root)-cne('FutureClassroom-r80-r06-native-'+$c.nonce)){throw 'EXACT_ROOT'};$a=[IO.File]::GetAttributes($root);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0){throw 'ROOT_REPARSE'};if([IO.File]::ReadAllText((Join-Path $root '.owner'))-cne"future-classroom-owned-r80-r06-native-runtime/v1`n"){throw 'OWNER_MARKER'};$acl=[IO.Directory]::GetAccessControl($root);if(-not$acl.AreAccessRulesProtected -or $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-cne$c.sid){throw 'EXACT_PROTECTED_OWNER'};$rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));if($rules.Count-ne2 -or @($rules|Where-Object{$_.IdentityReference.Value-notin@($c.sid,'S-1-5-18') -or $_.AccessControlType-ne'Allow' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count){throw 'ONLY_USER_SYSTEM_DACL'}}
function Inventory($root){CheckRoot $root;$files=@();$dirs=@();$q=[Collections.Generic.Queue[string]]::new();$q.Enqueue($root);while($q.Count){$dir=$q.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){$a=[IO.File]::GetAttributes($p);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0){throw 'INVENTORY_REPARSE'};$rel=$p.Substring($root.Length+1).Replace('\','/');if(($a-band[IO.FileAttributes]::Directory)-ne0){$dirs+=$rel;$q.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256}};if($files.Count-gt128 -or $dirs.Count-gt16){throw 'INVENTORY_BOUND'}}};return @{files=$files;directories=$dirs}}
CheckRoot $c.root;$root=$c.root
foreach($x in $c.inputs){$f=Fact (Join-Path $root $x.name);if($f.bytes-ne$x.bytes-or$f.sha256-cne$x.sha256){throw 'INPUT_BYTES'}}
$oldTemp=$env:TEMP;$oldTmp=$env:TMP;$clock=[Diagnostics.Stopwatch]::StartNew();$capture=$null;$p=$null;$returned=$true;$started=$false
$r=@{status='FAIL_RETAIN';cases=@();originalWholeSeconds=600;sourceScope='R06_REGISTERED_UI_AND_ORIGINAL_PHYSICAL_SHUTDOWN';installer='NOT_EXERCISED';pending='NOT_TOUCHED';network='APPLICATION_LISTENER_NOT_STARTED_SSH_TRANSPORT_SEPARATE';physicalAudio='NO_PLAYBACK_JOB_SUBMITTED_HELD_FACTORY_SYNTHETIC';cleanup='ROOT_DOWNLOAD_THEN_EXACT_DELETE_REQUIRED'}
try{
 $env:TEMP=Join-Path $root 'compiler-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP)
 try{Add-Type -Path (Join-Path $root 'Capture.cs') -ErrorAction Stop}finally{$env:TEMP=$oldTemp;$env:TMP=$oldTmp}
 $capture=[Fc79Capture]::new();$r.foregroundBefore=[FcR06Foreground]::Get()
 foreach($s in $c.cases){
  if($clock.ElapsedMilliseconds-ge600000){throw 'WHOLE_BUDGET'}
  $env:TEMP=Join-Path $root ('test-temp-'+$s.name);$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP)
  $exe=Join-Path $root $s.executable
  $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$exe;$info.Arguments=$s.argv;$info.WorkingDirectory=$root;$info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
  $p=[Diagnostics.Process]::new();$p.StartInfo=$info;$started=$false;$returned=$true
  $case=@{name=$s.name;argv=$s.argv;executable=$s.executable;started=$false;actualExit=$false;exitCode=$null;foregroundBefore=[FcR06Foreground]::Get();originalSeconds=$s.seconds};$r.cases+=,$case
  $case.startedWholeMilliseconds=$clock.ElapsedMilliseconds;$case.originalDeadlineWholeMilliseconds=[Math]::Min(600000,$case.startedWholeMilliseconds+$s.seconds*1000)
  if(-not$p.Start()){throw 'START'};$started=$true;$case.started=$true;$returned=$false
  $case.pid=$p.Id;$case.creation=$p.StartTime.ToUniversalTime().ToFileTimeUtc()
  $stdout=$p.StandardOutput.ReadToEndAsync();$stderr=$p.StandardError.ReadToEndAsync()
  $case.original=$capture.HoldStartedClient($p.Handle,[uint32]$p.Id,[long]$case.creation,$exe,$s.sha256,$c.sid)
  $left=[int]($case.originalDeadlineWholeMilliseconds-$clock.ElapsedMilliseconds)
  if($left-le0-or-not$p.WaitForExit($left)){throw 'ORIGINAL_PARENT_UNKNOWN_RETAIN_NO_KILL'}
  $returned=$true;$p.Refresh();$case.actualExit=$true;$case.exitCode=$p.ExitCode
  if(-not[Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($stdout,$stderr),[int][Math]::Max(0,$case.originalDeadlineWholeMilliseconds-$clock.ElapsedMilliseconds))){throw 'ORIGINAL_PIPES_UNKNOWN'}
  $case.stdout=$stdout.Result;$case.stderr=$stderr.Result
  [IO.File]::WriteAllText((Join-Path $root ($s.name+'.stdout.log')),$case.stdout,[Text.UTF8Encoding]::new($false));[IO.File]::WriteAllText((Join-Path $root ($s.name+'.stderr.log')),$case.stderr,[Text.UTF8Encoding]::new($false))
  [void]$capture.Snapshot();$case.foregroundAfter=[FcR06Foreground]::Get();$case.endedWholeMilliseconds=$clock.ElapsedMilliseconds
  if($case.original.Wait-ne0-or-not$case.original.ExitKnown-or$case.original.ExitCode-ne$case.exitCode){throw 'ORIGINAL_RETURN_MISMATCH'}
  $p.Dispose();$p=$null
  if($case.foregroundAfter-ne$case.foregroundBefore){throw 'FOREGROUND_CHANGED_NO_RESTORE'}
  if($case.exitCode-ne0){throw 'NATIVE_ACTUAL_NONZERO'}
  if($case.endedWholeMilliseconds-gt$case.originalDeadlineWholeMilliseconds){throw 'ORIGINAL_CASE_DEADLINE'}
 }
 $r.foregroundAfter=[FcR06Foreground]::Get();if($r.foregroundAfter-ne$r.foregroundBefore){throw 'WHOLE_FOREGROUND_CHANGED_NO_RESTORE'}
 $r.status='PASS_R06_FIVE_EXACT_AND_PUBLIC20_NATIVE_WIN11_ONLY'
}catch{$r.error=$_.Exception.Message}finally{
 $env:TEMP=$oldTemp;$env:TMP=$oldTmp
 if($null-ne$p-and(-not$started-or$returned)){$p.Dispose()}
 if($null-ne$capture){try{$r.originalObjects=@($capture.FinishAndClose())}catch{$r.status='FAIL_RETAIN';$r.closeError=$_.Exception.Message}}
 $r.originalParentReturned=$returned;$r.elapsedMilliseconds=$clock.ElapsedMilliseconds
 if($clock.ElapsedMilliseconds-ge600000){$r.status='FAIL_RETAIN';$r.budgetExceeded=$true}
 [IO.File]::WriteAllText((Join-Path $root 'native-result.json'),($r|ConvertTo-Json -Depth 30),[Text.UTF8Encoding]::new($false))
}
$r|ConvertTo-Json -Depth 30 -Compress
if($r.status-cne'PASS_R06_FIVE_EXACT_AND_PUBLIC20_NATIVE_WIN11_ONLY'){$global:LASTEXITCODE=1}
