"""Finite D13 text evidence archive, immutable originals, no main/Git/Windows actions."""
from pathlib import Path
import argparse,gzip,hashlib,io,json,os,re,shutil,stat,tarfile,time,urllib.parse
R=Path('/tmp/fc-round80-controlled-repair');P=Path(__file__).resolve().parent
PRUNE={'.git','sourcecopy.git','target','node_modules','__pycache__','.ssh','credentials','secrets'}
BIN={'.exe','.dll','.msi','.cab','.zip','.gz','.tar','.a','.lib','.rlib','.rmeta','.pdb','.obj','.o','.so','.bin','.ico','.png','.jpg','.woff','.woff2'}
BIDI={chr(x)for x in list(range(0x202a,0x202f))+list(range(0x2066,0x206a))}
MAGIC=(b'MZ',b'MSCF',b'PK\x03\x04',b'\x7fELF',b'\xd0\xcf\x11\xe0')
def sha(data):return hashlib.sha256(data).hexdigest()
def file_sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def sensitive(p):
 name=p.name.lower();return name in {'scope.bin','scope.hex','scope.json','scope-binding.json','.env'}or name.endswith('.env')or ('scope'in name and p.suffix.lower()in {'.hex','.bin','.env'})or any(x.lower()in{'.ssh','credentials','secrets'}for x in p.parts)
def walk(root):
 assert root.is_dir()and not root.is_symlink()
 for current,dirs,files in os.walk(root,followlinks=False):
  base=Path(current)
  kept=[]
  for d in sorted(dirs):
   q=base/d;assert not q.is_symlink(),'SOURCE_SYMLINK_DIRECTORY'
   if d in PRUNE or d.startswith(('checkout-','target-'))or d.endswith('target-first'):continue
   assert q.stat().st_dev==root.stat().st_dev,'MOUNT_REJECTED';kept.append(d)
  dirs[:]=kept
  for name in sorted(files):
   q=base/name;s=q.lstat();assert stat.S_ISREG(s.st_mode)and not q.is_symlink(),'SPECIAL_OR_SYMLINK_FILE';yield q

def scan(text,path,raw_sha):
 hits=[]
 rules=[('PRIVATE_KEY',r'-----BEGIN (?:RSA |OPENSSH |EC |DSA )?PRIVATE KEY-----'),('GITHUB_TOKEN',r'\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})\b'),('SCOPE_ENV_VALUE',r'FC_OWNED_REMOVAL_SCOPE_HEX[\x22\x27]?\s*[:=]\s*[\x22\x27]?[0-9a-fA-F]{512,}'),('AUTH_BEARER',r'(?i)authorization[\x22\x27]?\s*[:=]\s*[\x22\x27]?bearer\s+[A-Za-z0-9_.-]{20,}')]
 for name,rule in rules:
  if re.search(rule,text):hits.append(name)
 for url in re.findall(r'https?://[^\s\x22\x27<>]+',text):
  try:keys={x.lower()for x in urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)}
  except ValueError:continue
  if keys&{'sig','signature','token','access_token','x-amz-signature','x-amz-credential'}:hits.append('SIGNED_OR_TOKEN_URL')
 stripped=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',text)if path.lower().endswith(('.log','.jsonl'))else text
 exceptions=json.loads((P/'control-exceptions-second.json').read_bytes())['files'];matched=[x for x in exceptions if x['path']==path and x['sha256']==raw_sha]
 if matched:
  assert len(matched)==1;expected=matched[0];observed=[dict(offset=i,code=ord(c))for i,c in enumerate(text)if ord(c)<32 and c not in '\r\n\t'];assert observed==expected['controls'];allowed={x['offset']for x in observed};stripped=''.join(c for i,c in enumerate(text)if i not in allowed)
 if any(ord(c)<32 and c not in '\r\n\t'for c in stripped):hits.append('NON_TEXT_CONTROL')
 if any(c in BIDI for c in text):hits.append('BIDI_CONTROL')
 return sorted(set(hits))
def classify(p):
 s=p.stat();assert s.st_size<=128*1024*1024,'SOURCE_FILE_BOUND';row=dict(path=p.relative_to(R).as_posix(),originalPath=str(p),bytes=s.st_size)
 if sensitive(p):return dict(**row,kind='SENSITIVE_METADATA_ONLY_NOT_READ',sha256=None,contentRead=False),None
 with p.open('rb')as f:prefix=f.read(512)
 if p.suffix.lower()in BIN or prefix.startswith(MAGIC):return dict(**row,kind='BINARY_IDENTITY_ONLY',sha256=file_sha(p),contentRead='HASH_ONLY_NOT_ARCHIVED'),None
 raw=p.read_bytes()
 try:
  if raw.startswith((b'\xff\xfe',b'\xfe\xff')):text=raw.decode('utf-16');encoding='UTF16_ORIGINAL_BOM'
  else:text=raw.decode('utf-8-sig');encoding='UTF8_ORIGINAL'
 except UnicodeError:return dict(**row,kind='BINARY_IDENTITY_ONLY',sha256=sha(raw),contentRead='IDENTITY_ONLY_NOT_ARCHIVED'),None
 if '\0'in text:return dict(**row,kind='BINARY_IDENTITY_ONLY',sha256=sha(raw),contentRead='RAW_STREAM_NOT_ARCHIVED'),None
 return dict(**row,kind='ORIGINAL_TEXT',sha256=sha(raw),encoding=encoding,scanHits=scan(text,row['path'],sha(raw))),raw

def exact_freeze(pin):
 f=P/'freeze-first.json';assert file_sha(f)==pin
 data=json.loads(f.read_bytes());actual={p.relative_to(P).as_posix()for p in walk(P)};assert actual=={x['path']for x in data['files']}|{'freeze-first.json'}
 for x in data['files']:q=P/x['path'];assert q.stat().st_size==x['bytes']and file_sha(q)==x['sha256']
def main():
 a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');a.add_argument('--preparation-freeze-sha256');a.add_argument('--output-dir',type=Path);v=a.parse_args()
 if not v.execute:print('{"status":"NOT_RUN"}');return
 exact_freeze(v.preparation_freeze_sha256);scope=json.loads((P/'scope-first.json').read_bytes());assert not scope['waitingNotRead'];assert v.output_dir==R/'r06-ui-registries-archive-staged-first'and not v.output_dir.exists();O=v.output_dir;O.mkdir();(O/'.owner').write_text('future-classroom-owned-d13-ui-registries-archive/v1\n');started=time.monotonic()
 allfiles=[]
 for name in scope['terminalDirectoryWhitelist']:
  assert '/'not in name and not name.startswith(('checkout','target'))and all(x not in name.lower()for x in ['upgrade','r06','g02']);allfiles.extend(walk(R/name))
 allfiles.extend(R/name for name in scope['terminalFileWhitelist']);allfiles.extend(walk(P));allfiles=sorted(set(allfiles));assert len(allfiles)<10000
 rows=[];contents={};hits=[]
 for p in allfiles:
  row,raw=classify(p);rows.append(row)
  if raw is not None:contents[row['path']]=raw;hits.extend(dict(path=row['path'],rule=x)for x in row['scanHits'])
 (O/'source-index-first.json').write_text(json.dumps(dict(status='EXACT_FINITE_ORIGINAL_IDENTITIES',scope=scope,files=rows),indent=2)+'\n')
 if hits:
  (O/'scanner-first.json').write_text(json.dumps(dict(status='FAIL_RETAIN_ORIGINALS_NO_ARCHIVE_WRITTEN',hits=hits,contentOrURLDisclosed=False),indent=2)+'\n');print(json.dumps(dict(status='FAIL_STRICT_SCAN',hits=hits)));raise SystemExit(1)
 archive=O/'original-text-evidence-first.tar.gz';members=[]
 with archive.open('xb')as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0)as g:
   with tarfile.open(fileobj=g,mode='w',format=tarfile.PAX_FORMAT)as t:
    for name,raw in sorted(contents.items()):
     info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(raw));members.append(dict(path=name,bytes=len(raw),sha256=sha(raw)))
 binary=[x for x in rows if x['kind']=='BINARY_IDENTITY_ONLY'];private=[x for x in rows if x['kind']=='SENSITIVE_METADATA_ONLY_NOT_READ']
 (O/'archive-index-first.json').write_text(json.dumps(dict(archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=file_sha(archive)),members=members,binaryIdentities=binary,sensitiveMetadataOnly=private,originalSourceIndexSha256=file_sha(O/'source-index-first.json')),indent=2)+'\n')
 # Readable exact copies of key original reports, plus nested freeze to guard the
 # previous basename-exclusion mistake. Tar remains the full admitted text set.
 promote=['r06-registry-implementation-first/freeze-final.json', 'r06-integrated-native-producer-first/report.json', 'r06-integrated-native-producer-closure-first/report.json', 'r06-native-preparation-first/freeze-first.json', 'r06-native-final-local-first/report.json', 'r06-native-runtime-230d4fc4669db3b3ff4547fb51218815/report.json', 'combined-main-checks-first/report.json', 'combined-main-checks-first/freeze-first.json', 'r06-source-commit-first.json', 'r06-archive-preparation-first/independent-review-first.json']
 for name in promote:assert name in contents;q=O/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(contents[name])
 shutil.copyfile(P/'replay.py',O/'replay.py');shutil.copyfile(P/'scope-first.json',O/'scope-first.json')
 (O/'scanner-first.json').write_text(json.dumps(dict(status='PASS_STRICT_CREDENTIAL_AND_CONTROL_SCAN',hits=[],hitCount=0,scannedOriginalTextFiles=len(contents),signedURLsPrinted=False,sensitiveOriginalFilesNotRead=len(private),binaryFilesNotArchived=len(binary),boundedControlExceptions=dict(files=0,rule='NONE_NO_R06_CONTROL_EXCEPTION')),indent=2)+'\n')
 (O/'scope.md').write_text('本档仅保存 R06 两套注册表/页面生命周期重构的冻结源和验证证据。原 no-run wrapper 保持FAIL，原cargo实际返回0；后续closure记录260个0字节GCC临时文件条目已清理，没有据此改写首失败。3个实际产物中两个为Rust test-profile PE，一个为正常profile.test=false的fc-bootstrap。Win11实际运行5个固定exact测试，各1通过/0失败/0忽略，以及正常main的20步隔离合成公开桌面流程。六个原进程wait0/exit0并checked-close，观测测试会话foreground=0→0；18文件7目录完整下载核对后nonce精确删除。物理音频、真实学校数据、网络、MSI/Pending和Win7/Win10实机不在此次运行范围。\n\n组合主分支本地f4023a7e4950de359e7a89de25a1adfdc8cafb36的594输入前后相同，架构12crate/33edge、fmt、GNU两crate all-targets检查、strictClippy、diff五命令通过。28个owned源分别绑定installer16与R06-12各自实际native来源；这不构成组合源码全量native通过。R06本地候选3ae1b3de4dee9ba7f190861220f467bcf7258f39的保存收据保留当时not-yet-remote状态，不回写历史。D12、G02和Upgrade不混入此档，PE仅身份，不执行。\n',encoding='utf-8')
 receipt=dict(status='PASS_LOCAL_FINITE_D13_TEXT_ARCHIVE_ORIGINALS_UNCHANGED',archiveSha256=file_sha(archive),memberCount=len(members),memberBytes=sum(x['bytes']for x in members),binaryIdentityCount=len(binary),sensitiveMetadataCount=len(private),promoted=promote,sourceFiles=len(rows),elapsedSeconds=time.monotonic()-started,Windows='NO_ACTIONS',Git='NO_ACTIONS',main='NOT_MODIFIED',destinationSuggested=scope['destination']);(O/'archive-operation-first.json').write_text(json.dumps(receipt,indent=2)+'\n')
 exact_freeze(v.preparation_freeze_sha256)
 # Exactly one excluded path: this OUTPUT root's new freeze file itself.
 files=[dict(path=p.relative_to(O).as_posix(),bytes=p.stat().st_size,sha256=file_sha(p))for p in walk(O)];f=O/'freeze-first.json';assert not f.exists();f.write_text(json.dumps(dict(files=files),indent=2)+'\n');print(json.dumps(dict(status=receipt['status'],output=str(O),freezeSha256=file_sha(f),archiveSha256=file_sha(archive),members=len(members),binaryIdentities=len(binary),sensitiveMetadata=len(private))))
if __name__=='__main__':main()
