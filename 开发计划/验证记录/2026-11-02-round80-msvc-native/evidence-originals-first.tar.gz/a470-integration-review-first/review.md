本轮有限只读审阅未发现阻止候选 a4702b56bff66da5f5cbe74551d8751eb33fa520 合入开发 main 的具体源码问题。合入由 root 决定；该结论不等于发布准入。

审阅实际路径为 `/tmp/fc-round80-controlled-repair/checkout-msvc-clippy-fix-first`。相对 main 当前文件系统代码差异恰27件；main07ef084身份来自 root 指令，未运行 Git。候选当前466项 Rust/Cargo/工具链输入与已冻结编译库存逐字节匹配；本轮仅静态解析 Cargo TOML 得12 crate/33条允许的一方依赖，未运行 Cargo 或重复测试矩阵。

普通 Pending 拒绝仍在 `crates/fc-windows/src/installer_lifecycle/native.rs:338` 与 `:460`，普通启动、legacy维护及 `controlled.rs:18` 的 Draft 均经此入口；正常 Setup `native/broker/controlled_owner.rs:573` 先 seal 检查再获取该 Draft。仅显式私有恢复在原负向记录持柄情况下调用 existing-only gate 路径。

默认关闭边界在 `crates/fc-windows/Cargo.toml:12`、`crates/fc-bootstrap/Cargo.toml:11`、`installer_lifecycle/broker.rs:51`、`native/broker/controlled_owner.rs:9`。恢复只有编译 feature 下的固定词，scope 在 `recovery/scope.rs:114` 用 option_env 固定，`recovery.rs:449` 在 Session/gate 前拒绝缺失/不合法范围；没有 runtime env、路径、SHA、PID、nonce或结果的权限入口。

Token 修正在 `recovery.rs:205`：仅定位本次成功 watch 新增的 Role::Token 并 checked-close，失败保原 owner/gate/负向记录且不进入 READY/G2；`native.rs:730` 只在实际关闭成功后移除账本项。G1 process/thread 在 `recovery.rs:253` 归还后才能推进下一阶段，原 self-token 不被错误当作 G1 token 关闭。

重复通知修正在 `guard_context.rs:339` 与 `:565`：未 grant 仍拒绝；第一次 typed InstallInitialize 必须先关闭真实 CA pipe/controls，再发 Returned 并置位。仅 granted/returned 后的脚本重播通知幂等忽略，不二次 close、grant 或发回执。对应初次实际卸载失败、修复后真实联合回滚与卸载证据已在此前有限步骤保留；本轮不重复扩大历史语义审阅。

a470 的三个 as_chunks 修正仍保留32字节 nonce、scope 偶数边界和 dialog DWORD补齐，未放宽 lint 或字段语法。普通 Join 与真实 Begin 的 TransactionOrigin 匹配仍在 `installer_lifecycle.rs:259/:285`；正常 Install/Repair 严格 Present、Uninstall 严格 Absent，原 End非0保留claim、效果及源控制归还后才同 owner 结算的路径未改变。

验证边界已按 root 新回执更新：modern MSVC 原生6/66运行实际0，首次 wrapper `NameError(re)` 原FAIL保留，后续独立补取已精确清理原nonce；Win7-target官方PE在 Win11 的6/66亦实际0并精确清理。66包含6，不相加。真正 Win7/Win10 OS仍NOT_RUN，组件原生测试不冒充官方MSVC完整MSI联合运行，GNU此前实际联合证据和Begin/End未直接序列化的范围仍分开。root补充的13 seal负例/5静态合同/格式/架构actual0按其指令注明，本轮未重跑；尚运行中的host workspace未提前记PASS。

完整定位、证据 bytes/SHA、27件对照身份和限制见 review-first.json/source-identities-first.json。仅写本R目录；未接触Windows/SSH、未构建、未改W/W2/main/归档、未执行Git。
