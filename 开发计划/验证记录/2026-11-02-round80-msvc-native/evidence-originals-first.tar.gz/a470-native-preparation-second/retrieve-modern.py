"""Retrieve existing native result and clean exactly its nonce; never rerun PE."""
import argparse,base64,hashlib,json,runpy,subprocess,time
from pathlib import Path
R=Path('/tmp/fc-round80-controlled-repair');P=R/'a470-native-preparation-second'
FIRST=R/'a470-modern-native-runtime-first/report.json'
FIRST_SHA='2f0fb8df3e7ece2cb7ba63cac142766b356676ad035f37c4dc883ef5612ce8fc'
NONCE='120c495e90a98bbcb628e9f6c31df2bb'
READ=r'''
CheckRoot $c.root
$f=Fact (Join-Path $c.root 'native-result.json');if($f.bytes-le0-or$f.bytes-gt262144){throw 'BOUNDED_NATIVE_JSON'}
$b=[IO.File]::ReadAllBytes((Join-Path $c.root 'native-result.json'));$again=Fact (Join-Path $c.root 'native-result.json');if($f.bytes-ne$again.bytes-or$f.sha256-cne$again.sha256-or$b.Length-ne$f.bytes){throw 'NATIVE_RESULT_CHANGED'}
@{nativeRawBase64=[Convert]::ToBase64String($b);nativeFile=$f;status='READ_EXISTING_NATIVE_ONLY_NO_CREATE_NO_EXECUTION'}|ConvertTo-Json -Depth 12 -Compress
'''
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fact(p):
 p=Path(p);assert p.is_file() and not p.is_symlink();return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf-8')
def original():
 assert sha(FIRST)==FIRST_SHA;x=json.loads(FIRST.read_text())
 assert x['status']=='FAIL_RETAIN_ORIGINALS' and x['errorType']=='NameError' and x['error']=="name 're' is not defined"
 assert x['sourceSha']=='a4702b56bff66da5f5cbe74551d8751eb33fa520' and x['target']=='i686-pc-windows-msvc'
 assert x['windowsRoot']=='C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r80-a470-msvc-native-'+NONCE
 assert x['officialZipSourcesAndNativeUnchanged'] and x['cleanup']=='NOT_RUN'
 rows=[r for r in x['operations'] if r['name']=='run'];assert len(rows)==1 and rows[0]['actualReturnCode']==0 and not rows[0]['remoteOriginalReturnUnknown']
 assert fact(Path(rows[0]['stdout']['path']))==rows[0]['stdout']
 assert canonical(json.loads(Path(rows[0]['stdout']['path']).read_bytes()))==canonical(x['native'])
 return x

def main():
 a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');a.add_argument('--preparation-freeze-sha256');a.add_argument('--output-dir',type=Path);v=a.parse_args()
 if not v.execute:print('{"status":"NOT_RUN","nativeRerun":false}');return 0
 m=runpy.run_path(str(P/'run-native.py'));m['freeze_check'](v.preparation_freeze_sha256)
 first=original();q,exe=m['qualification']('modern');native=first['native']
 assert native['status']=='PASS_SETUP_COMPONENTS_AND_FULL_LIFECYCLE_NATIVE_TESTS_WIN11_ONLY' and native['originalParentReturned'] and native['originalWholeSeconds']==600
 assert [c['name'] for c in native['cases']]==['controlled','lifecycle']
 cases=[]
 for case in native['cases']:
  expected=6 if case['name']=='controlled' else 66;names=q['controlledNames'] if expected==6 else q['lifecycleNames']
  assert case['actualExit'] and case['exitCode']==0
  cases.append(dict(name=case['name'],**m['qualify_harness'](case['stdout'],names,expected)))
 caps=native['originalObjects'];assert len(caps)==2
 for cap,case in zip(caps,native['cases']):
  assert cap['Pid']==case['pid'] and cap['Creation']==case['creation'] and cap['Wait']==0 and cap['ExitKnown'] and cap['ExitCode']==0 and cap['CheckedClose'] and cap['Kind']=='process' and cap['Sid']==m['SID'] and cap['Sha256']==first['nativeInput']['sha256']==q['executable']['sha256']
  assert cap['Image']==first['windowsRoot']+'\\candidate-tests.exe'
 c=dict(nonce=NONCE,sid=m['SID'],root=first['windowsRoot']);out=v.output_dir
 assert out and out.is_absolute() and out.parent==R and out.name=='a470-modern-native-retrieval-first' and not out.exists()
 out.mkdir();(out/'.owner').write_text('future-classroom-owned-a470-modern-native-retrieval/v1\n')
 r=dict(status='STARTED_EXISTING_NATIVE_RETRIEVAL_ONLY',firstReport=fact(FIRST),firstOverallStatusPreserved=first['status'],firstNativeCanonicalSha256=hashlib.sha256(canonical(native)).hexdigest(),comparisonScope='ENTIRE_NATIVE_JSON_VALUE_CANONICAL_UTF8_BYTES_EQUAL_FIRST_REPORT; FIRST_REPORT_HAS_NO_ORIGINAL_RAW_FILE_HASH; READBACK_RAW_BYTES_SHA_MUST_EQUAL_COMPLETE_DOWNLOAD',qualifiedCases=cases,originalObjects=caps,nativeRerun=False,noCreateOrAddType=True,wholeSeconds=180,budgetScope='SEPARATE_EXISTING_RESULT_READBACK_DOWNLOAD_AND_EXACT_SCRATCH_CLEANUP; DOES_NOT_RENEW_OR_RERUN_ORIGINAL_600_SECOND_NATIVE',operations=[],cleanup='NOT_RUN',originalRoot=c['root'])
 start=time.monotonic()
 def save():(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
 def call(label,cmd,feed=None,limit=30):
  begin=time.monotonic();left=180-(begin-start);assert left>0
  child=subprocess.Popen(cmd,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE);timed=False
  try:stdout,stderr=child.communicate(feed,timeout=min(limit,left))
  except subprocess.TimeoutExpired:timed=True;child.kill();stdout,stderr=child.communicate()
  so=out/(label+'.stdout.log');se=out/(label+'.stderr.log');so.write_bytes(stdout);se.write_bytes(stderr)
  row=dict(name=label,argv=cmd,actualExit=child.returncode,originalLocalReaped=True,remoteReturnUnknown=timed,timedOut=timed,seconds=time.monotonic()-begin,stdout=fact(so),stderr=fact(se))
  if feed is not None:row['stdin']=dict(bytes=len(feed),sha256=hashlib.sha256(feed).hexdigest())
  r['operations'].append(row);save();assert child.returncode==0 and not timed,(label,'UNKNOWN_RETAIN' if timed else 'ACTUAL_NONZERO')
  return stdout
 def remote(label,script,limit=30):
  feed=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+m['COMMON']+script).encode()
  return call(label,['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','future-classroom-win11','powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(m['BOOT'].encode('utf-16-le')).decode()],feed,limit)
 save()
 try:
  read=json.loads(remote('read-existing-native',READ));assert read['status']=='READ_EXISTING_NATIVE_ONLY_NO_CREATE_NO_EXECUTION'
  b=base64.b64decode(read['nativeRawBase64'],validate=True);nf=read['nativeFile'];assert len(b)==nf['bytes'] and hashlib.sha256(b).hexdigest()==nf['sha256']
  assert canonical(json.loads(b))==canonical(native),'CANONICAL_JSON_VALUE_BYTES_MUST_EQUAL_ORIGINAL_REPORT_NATIVE'
  r['nativeFileReadback']=nf;r['nativeCanonicalBytesEqualFirstReport']=True
  proc=json.loads(remote('owned-processes',m['PROCESSES']));assert proc['count']==0;r['ownedProcessReadback']=proc
  inv=json.loads(remote('inventory',m['INVENTORY']));m['helper']['validate_inventory'](inv);r['inventory']=inv
  expected={'candidate-tests.exe':(q['executable']['bytes'],q['executable']['sha256']),'Capture.cs':(m['CAP'].stat().st_size,sha(m['CAP'])),'native-result.json':(len(b),hashlib.sha256(b).hexdigest())}
  for name,(size,digest) in expected.items():
   rows=[f for f in inv['files'] if f['path']==name];assert len(rows)==1 and rows[0]['bytes']==size and rows[0]['sha256']==digest
  download=out/'download';download.mkdir();call('download',['scp','-q','-r','-o','BatchMode=yes','future-classroom-win11:'+c['root'].replace('\\','/'),str(download)],limit=60)
  local=download/Path(c['root'].replace('\\','/')).name;m['helper']['verify_download'](local,inv)
  assert (local/'native-result.json').read_bytes()==b and canonical(json.loads((local/'native-result.json').read_bytes()))==canonical(native)
  r['allOriginalNonceFilesDownloadedExact']=True;original();m['freeze_check'](v.preparation_freeze_sha256)
  c['inventory']=inv;r['delete']=json.loads(remote('delete',m['DELETE']));assert r['delete']['knownAbsent'] and r['delete']['nonce']==NONCE
  r['cleanup']='PASS_EXACT_ORIGINAL_DOWNLOADED_NATIVE_NONCE_REMOVED';r['status']='PASS_EXISTING_MODERN_NATIVE_QUALIFICATION_AND_SCRATCH_CLEANUP_ONLY'
 except Exception as error:r.update(status='FAIL_RETAIN_EXISTING_NONCE',errorType=type(error).__name__,error=str(error))
 try:original();m['freeze_check'](v.preparation_freeze_sha256);r['originalFailureAndPreparationUnchanged']=True
 except Exception as error:r.update(status='FAIL_INPUT_CHANGED',inputError=str(error))
 r['elapsedSeconds']=time.monotonic()-start
 if r['elapsedSeconds']>=180:r['status']='FAIL_READBACK_CLEANUP_ORIGINAL_BUDGET_EXCEEDED'
 save();print(json.dumps(dict(status=r['status'],report=str(out/'report.json'),sha256=sha(out/'report.json'),error=r.get('error'))));return 0 if r['status'].startswith('PASS_') else 1
if __name__=='__main__':raise SystemExit(main())
