"""Fixed official a470 MSVC test artifacts. Root executes; default is inert."""
import argparse,base64,hashlib,json,re,runpy,secrets,shutil,subprocess,time
from pathlib import Path
E=Path('/tmp/fc-round80-controlled-repair')
P=E/'a470-native-preparation-first'
OLD=E/'owned-removal-native-preparation-first/run-native.py'
BASE=E/'native-reference-first/run-negative-msi-r79-third.py'
CAP=E/'native-reference-first/Capture.cs'
SOURCE='a4702b56bff66da5f5cbe74551d8751eb33fa520'
SID='S-1-5-21-3896111207-1867804362-1971593122-1001'
PINS={OLD:'aba4e0e69328b67f0eb88b775b2390645961b33c2d46cfb4ea3a319bba402169',BASE:'da74f0058deac86507b712075904556780be6b262b18acb82415da6725c6e202',CAP:'e74300d27694e46fde2e8113cfeee47ffd3f11f9172f01c5621fa2ba5fdcab5a'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fact(p):
 p=Path(p);assert p.is_file() and not p.is_symlink();return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def references():
 for p,s in PINS.items():assert fact(p)['sha256']==s
references()
old=runpy.run_path(str(OLD));helper=runpy.run_path(str(BASE))
COMMON=old['COMMON'].replace('r80-owned-removal-native','r80-a470-msvc-native')
CREATE=old['CREATE'].replace('r80-owned-removal-native','r80-a470-msvc-native')
CREATE="if($PSVersionTable.PSVersion.Major-ne5-or[IntPtr]::Size-ne8){throw 'PS51_X64_REQUIRED'};if([Environment]::OSVersion.Version.Build-lt22000){throw 'WIN11_REQUIRED'};"+CREATE
RUN=old['RUN'].replace('69-test','66-test').replace('COMPILED_SCOPE_ABSENT_NO_PRODUCT_RECOVERY_PERMITTED','DEFAULT_FEATURE_SCOPE_MODULE_NOT_COMPILED_NO_RECOVERY_AUTHORITY')
DELETE=helper['DELETE']
PROCESSES="$a=@(Get-CimInstance Win32_Process -ErrorAction Stop|Where-Object {$_.ExecutablePath -and $_.ExecutablePath.StartsWith($c.root+'\\',[StringComparison]::OrdinalIgnoreCase)});@{count=$a.Count}|ConvertTo-Json -Compress"
INVENTORY='Inventory $c.root|ConvertTo-Json -Depth 12 -Compress'
BOOT=old['BOOT']
PS_CHUNKS=dict(create=COMMON+CREATE,run=COMMON+RUN,processes=COMMON+PROCESSES,inventory=COMMON+INVENTORY,delete=COMMON+DELETE)
qualify_harness=runpy.run_path(str(P/'harness.py'))['qualify_harness']
def freeze_check(expected):
 f=P/'freeze-first.json';assert re.fullmatch(r'[0-9a-f]{64}',expected or '') and sha(f)==expected
 x=json.loads(f.read_text());assert x['ownedRoot']==str(P)
 for item in x['files']:
  q=Path(item['path']);assert q.is_relative_to(P) and fact(q)==item
 references()
def qualification(label):
 x=runpy.run_path(str(P/'admission.py'))['qualify'](label);raw=x.pop('nativeBytes')
 frozen=json.loads((P/'inputs'/label/'qualification.json').read_text());assert x==frozen
 exe=P/'inputs'/label/'candidate-tests.exe';assert exe.read_bytes()==raw
 return x,exe

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');ap.add_argument('--validate-inputs-only',action='store_true');ap.add_argument('--target',choices=['modern','win7']);ap.add_argument('--preparation-freeze-sha256');ap.add_argument('--output-dir',type=Path);a=ap.parse_args()
 if not a.execute and not a.validate_inputs_only:print('{"status":"NOT_RUN","windows":"NOT_RUN"}');return 0
 assert not(a.execute and a.validate_inputs_only)
 freeze_check(a.preparation_freeze_sha256)
 labels=[a.target] if a.target else ['modern','win7'];qualified={label:qualification(label) for label in labels}
 if a.validate_inputs_only:
  print(json.dumps(dict(status='PASS_STATIC_OFFICIAL_A470_INPUTS_ONLY',source=SOURCE,targets=labels,windows='NOT_RUN',expectedParentScopes={'controlled':6,'lifecycle':66},lifecycleIncludesControlled=True)));return 0
 assert a.target and a.output_dir
 q,exe=qualified[a.target]
 out=a.output_dir;assert out.is_absolute() and out.parent==E and out.name=='a470-'+a.target+'-native-runtime-first' and not out.exists()
 assert (E/'.owner').read_bytes()==b'future-classroom-owned-r80-controlled-repair/v1\n'
 out.mkdir();(out/'.owner').write_text('future-classroom-owned-a470-msvc-native-result/v1\n')
 r=dict(status='STARTED',sourceSha=SOURCE,target=q['target'],toolchain=q['toolchain'],runtimeOS='WINDOWS11_ONLY',officialCiQualification=fact(P/'inputs'/a.target/'qualification.json'),nativeInput=fact(exe),preparationFreeze=fact(P/'freeze-first.json'),fixtureInputs=[fact(x) for x in PINS],expectedScopes={'controlled':6,'lifecycle':66},scopeOverlap='66 includes controlled6; child summaries not added to parent totals',excludedScopeNames=q['excludedOnlyFeatureGatedScopeTests'],feature='DEFAULT_SCOPE_MODULE_NOT_COMPILED',productionMsi='NOT_EXERCISED',windows7='NOT_RUN',windows10='NOT_RUN',operations=[],cleanup='NOT_RUN',nativeWholeSeconds=600,outerSeconds=900)
 c=dict(nonce=secrets.token_hex(16),sid=SID,root=None,exeSha=sha(exe));start=time.monotonic()
 def save():(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
 def call(label,cmd,feed=None,limit=30):
  begin=time.monotonic();left=900-(begin-start);assert left>0
  child=subprocess.Popen(cmd,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  timed=False
  try:stdout,stderr=child.communicate(feed,timeout=min(left,limit))
  except subprocess.TimeoutExpired:
   timed=True;child.kill();stdout,stderr=child.communicate()
  so=out/(label+'.stdout.log');se=out/(label+'.stderr.log');so.write_bytes(stdout);se.write_bytes(stderr)
  row=dict(name=label,argv=cmd,actualReturnCode=child.returncode,originalLocalReaped=True,remoteOriginalReturnUnknown=timed,budgetExceeded=timed,elapsedSeconds=time.monotonic()-begin,stdout=fact(so),stderr=fact(se))
  if feed is not None:row['stdin']=dict(bytes=len(feed),sha256=hashlib.sha256(feed).hexdigest())
  r['operations'].append(row);save()
  assert not timed and child.returncode==0,(label,child.returncode,'REMOTE_UNKNOWN_RETAIN_NO_WINDOWS_KILL' if timed else 'ACTUAL_NONZERO')
  return stdout
 def remote(label,script,limit=30):
  feed=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+COMMON+script).encode()
  return call(label,['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','future-classroom-win11','powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(BOOT.encode('utf-16-le')).decode()],feed,limit)
 save()
 try:
  c['root']=json.loads(remote('create',CREATE))['root'];r['windowsRoot']=c['root'];save()
  upload=out/'upload';upload.mkdir();shutil.copyfile(exe,upload/'candidate-tests.exe');shutil.copyfile(CAP,upload/'Capture.cs')
  c['inputs']=[dict(name=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(upload.iterdir())]
  for p in sorted(upload.iterdir()):call('upload-'+p.name,['scp','-q','-o','BatchMode=yes',str(p),'future-classroom-win11:'+c['root'].replace('\\','/')+'/'],limit=60)
  native=json.loads(remote('run',RUN,600));r['native']=native
  assert native['status']=='PASS_SETUP_COMPONENTS_AND_FULL_LIFECYCLE_NATIVE_TESTS_WIN11_ONLY'
  assert native['originalParentReturned'] and len(native['cases'])==2 and [x['name'] for x in native['cases']]==['controlled','lifecycle']
  r['qualifiedCases']=[]
  for case in native['cases']:
   required=q['controlledNames'] if case['name']=='controlled' else q['lifecycleNames'];expected=6 if case['name']=='controlled' else 66
   assert case['actualExit'] and case['exitCode']==0
   r['qualifiedCases'].append(dict(name=case['name'],**qualify_harness(case['stdout'],required,expected)))
  assert len(native['originalObjects'])==2 and all(x['CheckedClose'] and x['Wait']==0 and x['ExitKnown'] and x['ExitCode']==0 for x in native['originalObjects'])
  r['ownedProcessReadback']=json.loads(remote('owned-processes',PROCESSES));assert r['ownedProcessReadback']['count']==0
  inv=json.loads(remote('inventory',INVENTORY));helper['validate_inventory'](inv);r['inventory']=inv
  for item in c['inputs']:
   rows=[x for x in inv['files'] if x['path']==item['name']];assert len(rows)==1 and rows[0]['bytes']==item['bytes'] and rows[0]['sha256']==item['sha256']
  save();download=out/'download';download.mkdir();call('download',['scp','-q','-r','-o','BatchMode=yes','future-classroom-win11:'+c['root'].replace('\\','/'),str(download)],limit=60)
  local=download/Path(c['root'].replace('\\','/')).name;helper['verify_download'](local,inv)
  assert json.loads((local/'native-result.json').read_text())==native
  freeze_check(a.preparation_freeze_sha256);c['inventory']=inv
  r['delete']=json.loads(remote('delete',DELETE));r['cleanup']='PASS_FULL_DOWNLOAD_VERIFIED_EXACT_OWNED_NONCE_REMOVED';r['status']='PASS_OFFICIAL_A470_MSVC_LIFECYCLE_NATIVE_REGRESSION_WIN11_ONLY'
 except Exception as error:r.update(status='FAIL_RETAIN_ORIGINALS',errorType=type(error).__name__,error=str(error))
 r['elapsedSeconds']=time.monotonic()-start
 if r['elapsedSeconds']>=900:r['status']='FAIL_OUTER_ORIGINAL_BUDGET_EXCEEDED';r['outerBudgetExceeded']=True
 try:
  freeze_check(a.preparation_freeze_sha256);now,nowexe=qualification(a.target);assert now==q and fact(nowexe)==r['nativeInput'];r['officialZipSourcesAndNativeUnchanged']=True
 except Exception as error:r.update(status='FAIL_INPUTS_CHANGED',inputError=str(error),officialZipSourcesAndNativeUnchanged=False)
 r['elapsedSeconds']=time.monotonic()-start
 if r['elapsedSeconds']>=900:r['status']='FAIL_OUTER_ORIGINAL_BUDGET_EXCEEDED';r['outerBudgetExceeded']=True
 save();print(json.dumps(dict(status=r['status'],report=str(out/'report.json'),sha256=sha(out/'report.json'),error=r.get('error'))));return 0 if r['status'].startswith('PASS_') else 1
if __name__=='__main__':raise SystemExit(main())
