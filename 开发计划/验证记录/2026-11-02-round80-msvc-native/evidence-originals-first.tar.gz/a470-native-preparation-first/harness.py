def qualify_harness(stdout,required,expected):
 # --test-threads=1 is fixed by RUN. Nested fixture subprocesses inherit stdout
 # and may run a name that is also in the parent's 69-test scope. Count starts
 # only in the original harness scope; never promote a child's summary.
 assert len(required)==expected and len(set(required))==expected
 scopes=[];outer_names=[];summaries=[];outer_final=None;running=[]
 for line in stdout.splitlines():
  m=re.fullmatch(r'running (\d+) tests?',line)
  if m:
   n=int(m[1]);running.append(n)
   if not scopes:
    assert not summaries and n==expected,'ORIGINAL_PARENT_RUNNING_SCOPE'
   scopes.append(n)
   continue
  m=re.match(r'^test (installer_lifecycle::[^\s]+) \.\.\.',line)
  if m and len(scopes)==1:
   outer_names.append(m[1].rsplit('::',1)[-1])
  m=re.match(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',line)
  if m:
   assert scopes,'SUMMARY_WITHOUT_ORIGINAL_HARNESS_SCOPE'
   final=m.groups();summaries.append(final)
   assert final[0]=='ok' and all(int(n)==0 for n in final[2:5]),'REAL_TEST_FAILURE_OR_IGNORED_PRESENT'
   scope_count=scopes.pop()
   assert int(final[1])==scope_count,'HARNESS_SCOPE_SUMMARY_COUNT_MISMATCH'
   if not scopes:
    assert outer_final is None and int(final[1])==expected,'ORIGINAL_PARENT_FINAL_SCOPE'
    outer_final=final
 assert running and running[0]==expected and not scopes,'ORIGINAL_PARENT_HARNESS_NOT_COMPLETE'
 assert len(outer_names)==expected and set(outer_names)==set(required) and all(outer_names.count(name)==1 for name in required),'EXPECTED_OUTER_TEST_STARTS_EXACTLY_ONCE'
 assert outer_final is not None and summaries[-1]==outer_final,'FINAL_SUMMARY_MUST_BE_ORIGINAL_PARENT'
 assert not re.search(r'^test [^\r\n]*\.\.\. FAILED\r?$',stdout,re.M),'REAL_TEST_FAILURE_PRESENT'
 return dict(outerTotals={k:int(n) for k,n in zip(('passed','failed','ignored','measured','filteredOut'),outer_final[1:])},outerRunningCount=running[0],expectedOuterStarts=len(outer_names),summaryCount=len(summaries),nestedSummaryCount=len(summaries)-1,summaryAuthority='FINAL_ORIGINAL_PARENT_SUMMARY_WITH_ORIGINAL_PARENT_EXIT0_AND_CHECKED_CLOSE')
