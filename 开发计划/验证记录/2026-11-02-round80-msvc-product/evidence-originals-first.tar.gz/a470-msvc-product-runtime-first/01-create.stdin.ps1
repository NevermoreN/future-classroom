$c='{"nonce":"0a3c0a1912ae4049bee91d02b9a14f28","sid":"S-1-5-21-3896111207-1867804362-1971593122-1001","plan":{"status":"BOUND_MSVC_WIN7_TARGET_CONTROLLED_PRODUCT_INPUTS_NOT_RELEASE","sourceGit":"a4702b56bff66da5f5cbe74551d8751eb33fa520","target":"i686-win7-windows-msvc","family":"99378807-098D-5F04-8D4D-F181DFA218D5","productCode":"{9E50831D-7811-5039-8BC3-4934647448D8}","version":"0.1.0","expectedUserSid":"S-1-5-21-3896111207-1867804362-1971593122-1001","payloads":[{"path":"LICENSE","size":1088,"sha256":"32b48e0a752c101a54d4ea1affc589dd99d8b553c72bedba17c6e2e30d319b30","component_guid":"BF8ECC92-DF5E-5031-AF8F-B122A05E64E6"},{"path":"MSI-CANDIDATE.txt","size":1813,"sha256":"057bb922663a6fcfee4affe324c97354c9866a0874b3cc90a02dbcf4ccb6ce1c","component_guid":"00CBA46A-3182-5F3E-A3C2-3B4D08BF8FCC"},{"path":"PROBE-README.txt","size":21941,"sha256":"e5ee6a5c2843c98d66e496cd59797ba1fd759a5df5aec35f77c104e200e880f9","component_guid":"1F2DCDC9-9F80-51BE-A10D-F294D45FDB05"},{"path":"THIRD-PARTY-NOTICES.txt","size":2448718,"sha256":"0bf19c345f74c394a7ba30f0059db8bd1943d30d564165eefe3eb3205c2c72c9","component_guid":"44E7E505-D3CB-5DC8-9730-50964BA3CC8C"},{"path":"fc-bootstrap.exe","size":10873856,"sha256":"6a8e0c40d1c83158ca01d1bc01c573613ed0e6a980ddf7c345c0f9e94929483f","component_guid":"0CA01C62-B71F-5C57-905B-B6C979ACB487"},{"path":"manifest.json","size":32262,"sha256":"a079b46fffbe438d268832f6eae099580d24e3de31d33670c3efdb187dfff02a","component_guid":"8D7F75D1-8AD6-5097-AEE4-62389B788737"},{"path":"web/THIRD-PARTY-NOTICES.txt","size":26033,"sha256":"7e717fcd0c465c72e70e46d223b3a819b4b03a12c13877c896e194626815f33b","component_guid":"51201E26-0CF3-5876-A591-91F68B3A94DB"},{"path":"web/assets/favicon-CXuYoSfB.svg","size":282,"sha256":"46593a2ec46a77d65026d609dcd5630c447360522518d745458091a9df2f7f8a","component_guid":"D0B2E913-0457-5E64-A66B-EC1EE7DA7138"},{"path":"web/assets/index-BkiZ2CBl.js","size":415401,"sha256":"cdf0d8f9c8cfa259031cb22e10aacb1ffea7b1f7affb3a4235478069b2138bf3","component_guid":"18B1A37C-EE86-5233-ACC2-773B48D189BB"},{"path":"web/assets/index-DrrJeLm9.css","size":39554,"sha256":"fd6d963cdb889b3bffdebf631c310d869730a56474a389351fd7bdf49bdf385f","component_guid":"B9ADCF83-BCB1-5F42-97D8-967FF84A306F"},{"path":"web/assets/pcm-worklet-B7E4LRoP.js","size":1724,"sha256":"9934c276d98e30992dc8148ffc3a0dfdc178fed9aacbb8227255bede45c1fcfa","component_guid":"28DB1C02-71DB-5DAF-8D0C-9844E24D16DC"},{"path":"web/assets/wav-worker-LSywWbpJ.js","size":884,"sha256":"a0e364aa7c0d888d0f7118b86d873c95df95e461303546a8ad1d56d5038e1886","component_guid":"C0EC8190-410A-52A3-895E-AD6564B75C1E"},{"path":"web/fc-assets.json","size":1073,"sha256":"2b4034c8a0f0bfa73812a7f2853ba83b766772ff55096fc1e33c9f2ddb9e4593","component_guid":"0C6686BF-2327-51F5-89A6-4243C1FD11CF"},{"path":"web/index.html","size":1232,"sha256":"8761e3d65d2bee4fb860e14b315eec9e634a019b1633aea627c335397f8299f2","component_guid":"58B108D4-3264-56B1-9DE5-19636D8437E2"}],"setup":{"path":"/tmp/fc-round80-controlled-repair/a470-msvc-product-package-first/Setup.exe","bytes":483768,"sha256":"35b2f66be2aa0276d6954e41634acc30987a84cb72806bc6808262633ee8136c"},"msi":{"path":"/tmp/fc-round80-controlled-repair/a470-msvc-product-package-first/FutureClassroom.msi","bytes":6787072,"sha256":"bfa908c58450016ad219e372a0c47dd13d9d71a68270e9cdbf2b9c6fc3b52fdc"},"sourceManifest":{"bytes":111081,"sha256":"837191c4c731aadc96f185dc1a4a34957d5d7d6499b52d580549b0394695f3a1"},"guardAction":"FcControlledInnerGuard","packageReport":{"path":"/tmp/fc-round80-controlled-repair/a470-msvc-product-package-first/report.json","bytes":93983,"sha256":"f6b5265bf94dd0b88cd493a6a731a82cfe297cd991e7505d5ca5b811099eb6e5"},"officialNormalInputs":{"path":"/tmp/fc-round80-controlled-repair/a470-msvc-product-input-first/manifest.json","bytes":721344,"sha256":"60821498b9899c15efc9197835d6cd690de532ef93808df0c015355960f657eb"},"officialCiResult":{"path":"/tmp/fc-round80-controlled-repair/a470-msvc-product-input-first/ci-evidence/result.json","bytes":50566,"sha256":"f3d1d8bf04f914e56fdbc724b1cc6bd26e69d0f194f2178239bcf8148b565d45"},"runtimeOS":"WINDOWS11_ONLY","registryMarkerKey":"Software\\FutureClassroom\\Installer\\Components","runKey":"Software\\Microsoft\\Windows\\CurrentVersion\\Run","runValue":"FutureClassroom","registryView":"Registry32","fixedDestinationKnownFolderSuffix":["Programs","FutureClassroom"]},"root":null}'|ConvertFrom-Json;
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Need([bool]$v,[string]$code){if(-not$v){throw $code}}
function Fact([string]$p){$f=Get-Item -LiteralPath $p -Force;Need (-not$f.PSIsContainer -and ($f.Attributes-band1024)-eq0) 'REGULAR_NO_REPARSE';return @{bytes=[long]$f.Length;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function RootPath {return Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) ('Temp\FutureClassroom-r80-a470-msvc-controlled-product-'+$c.nonce)}
function CheckRoot([string]$root){Need ($root-ceq$c.root -and $root-ceq(RootPath)) 'EXACT_NONCE_ROOT';$a=[IO.File]::GetAttributes($root);Need (($a-band1024)-eq0 -and ($a-band16)-ne0) 'REGULAR_ROOT';Need ([IO.File]::ReadAllText((Join-Path $root '.owner'))-ceq"future-classroom-owned-r80-a470-msvc-controlled-product-runtime/v1`n") 'OWNER';$acl=[IO.Directory]::GetAccessControl($root);Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq$c.sid) 'PROTECTED_ROOT_OWNER';$rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($rules.Count-eq2 -and @($rules|Where-Object{$_.IdentityReference.Value-cnotin@($c.sid,'S-1-5-18') -or $_.AccessControlType-ne'Allow' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count-eq0) 'ONLY_USER_SYSTEM_DACL'}
function Inventory([string]$root){CheckRoot $root;$files=@();$dirs=@();$q=[Collections.Generic.Queue[string]]::new();$q.Enqueue($root);while($q.Count){$dir=$q.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){$a=[IO.File]::GetAttributes($p);Need (($a-band1024)-eq0) 'NO_INVENTORY_REPARSE';$rel=$p.Substring($root.Length+1).Replace('\','/');if(($a-band16)-ne0){$dirs+=$rel;$q.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256}};Need ($files.Count-le256 -and $dirs.Count-le32) 'INVENTORY_BOUNDS'}};return @{files=$files;directories=$dirs}}
# TEST INSTRUMENT PREPARATION ONLY. Dot-source defines one function; no top-level side effects.
function Measure-FcBeforePreflight {
    param([Parameter(Mandatory=$true)]$Config)
    $c=$Config
    $ErrorActionPreference='Stop'
    if($c.status-cne'BOUND_GNU_DEV_CONTROLLED_PRODUCT_INPUTS_NOT_RELEASE' -or $c.sourceGit-cnotmatch'^[0-9a-f]{40}$' -or $c.target-cne'i686-pc-windows-gnu' -or $c.family-cne'99378807-098D-5F04-8D4D-F181DFA218D5'){throw 'EXACT_BOUND_SOURCE_TARGET_FAMILY_REQUIRED'}
    function PathFact($path) {
        try {
            $a=[IO.File]::GetAttributes($path)
            return @{path=$path;status='PRESENT_REFUSE';isDirectory=(($a-band[IO.FileAttributes]::Directory)-ne 0);isReparse=(($a-band[IO.FileAttributes]::ReparsePoint)-ne 0)}
        } catch {
            $e=$_.Exception;while($null-ne$e.InnerException){$e=$e.InnerException}
            if($e-is[IO.FileNotFoundException] -or $e-is[IO.DirectoryNotFoundException]){return @{path=$path;status='KNOWN_ABSENT'}}
            return @{path=$path;status='UNKNOWN_REFUSE';exceptionKind=$e.GetType().FullName;hresult=$e.HResult}
        }
    }
    function Registration {
        $i=$null;$products=$null;$related=$null
        try {
            $i=New-Object -ComObject WindowsInstaller.Installer
            $products=$i.GetType().InvokeMember('ProductsEx',[Reflection.BindingFlags]::GetProperty,$null,$i,@($c.productCode,'',7))
            $n=$products.GetType().InvokeMember('Count',[Reflection.BindingFlags]::GetProperty,$null,$products,@())
            $state=$i.GetType().InvokeMember('ProductState',[Reflection.BindingFlags]::GetProperty,$null,$i,@($c.productCode))
            $related=$i.GetType().InvokeMember('RelatedProducts',[Reflection.BindingFlags]::GetProperty,$null,$i,@('{'+$c.family+'}'))
            $rn=$related.GetType().InvokeMember('Count',[Reflection.BindingFlags]::GetProperty,$null,$related,@())
            if($n-isnot[Int32] -or $rn-isnot[Int32] -or $n-lt 0 -or $rn-lt 0){throw 'ACTUAL_COM_COUNT_TYPE_OR_RANGE'}
            return @{contexts=7;sidArgument='';otherUsers='NOT_QUERIED';product=$c.productCode;relatedFamily=$c.family;count=$n;state=$state;relatedCount=$rn;knownAbsent=($n-eq 0 -and $state-eq -1 -and $rn-eq 0)}
        } finally {
            foreach($o in @($related,$products,$i)){if($null-ne$o){[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($o)}}
        }
    }
    $who=[Security.Principal.WindowsIdentity]::GetCurrent()
    try{$sid=$who.User.Value}finally{$who.Dispose()}
    if($sid-cne$c.expectedUserSid){throw 'EXACT_EXPECTED_CURRENT_USER_SID'}
    $local=[Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)
    if([string]::IsNullOrEmpty($local) -or -not [IO.Path]::IsPathRooted($local)){throw 'OS_KNOWN_FOLDER_UNAVAILABLE'}
    $target=Join-Path $local 'Programs\FutureClassroom'
    $gate=Join-Path $local ('FutureClassroom-Installer-'+$c.family)
    $paths=@((PathFact $target),(PathFact $gate))
    # An existing gate, even an apparently empty/released one, is not adopted for a
    # fresh production experiment. Unknown is never converted to absence.
    $base=$null;$marker=$null;$run=$null
    try {
        $base=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry32)
        $marker=$base.OpenSubKey('Software\FutureClassroom\Installer\Components',$false)
        $markers=@{view='Registry32';key='Software\FutureClassroom\Installer\Components';knownAbsent=($null-eq$marker)}
        $run=$base.OpenSubKey('Software\Microsoft\Windows\CurrentVersion\Run',$false)
        $runAbsent=$true
        if($null-ne$run){$sentinel=[Object]::new();$value=$run.GetValue('FutureClassroom',$sentinel,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames);$runAbsent=[Object]::ReferenceEquals($sentinel,$value);$value=$null}
        # Only the fixed project value is queried; no other startup data is dumped.
        $runFact=@{view='Registry32';value='FutureClassroom';knownAbsent=$runAbsent;writePerformed=$false;contentsRetained=$false}
        $registration=Registration
    } finally {
        foreach($key in @($run,$marker,$base)){if($null-ne$key){$key.Dispose()}}
    }
    $pass=(@($paths|Where-Object{$_.status-cne'KNOWN_ABSENT'}).Count-eq 0 -and $markers.knownAbsent -and $runFact.knownAbsent -and $registration.knownAbsent)
    return @{status=$(if($pass){'PASS_BEFORE_KNOWN_ABSENCE_ONLY_NOT_EXECUTION_ADMISSION'}else{'REFUSE_PREEXISTING_OR_UNKNOWN_NO_MUTATION'});sourceGit=$c.sourceGit;target=$c.target;currentUserSid=$sid;localKnownFolder=$local;fixedPaths=$paths;componentMarkers=$markers;run=$runFact;registration=$registration;mutations=$false;normalRustHelper='NOT_EXECUTED';productMSI='NOT_EXECUTED';scope='Current authorized admin Win11 only; other users/cache/school data not queried; candidate helper independently rechecks under original native owner.'}
}
$start=[Diagnostics.Stopwatch]::GetTimestamp();$frequency=[Diagnostics.Stopwatch]::Frequency
Need ($PSVersionTable.PSVersion.Major-eq5 -and $PSVersionTable.PSVersion.Minor-eq1 -and [IntPtr]::Size-eq8) 'PS51_X64'
$who=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$who.User;Need ($sid.Value-ceq$c.sid) 'CURRENT_SID'}finally{$who.Dispose()}
$before=Measure-FcBeforePreflight -Config $c.plan;Need ($before.status-ceq'PASS_BEFORE_KNOWN_ABSENCE_ONLY_NOT_EXECUTION_ADMISSION') 'ALL_KNOWN_ABSENT_BEFORE_ROOT'
$root=RootPath;try{[void][IO.File]::GetAttributes($root);throw 'ROOT_ALREADY_PRESENT'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
$cursor=[IO.Path]::GetDirectoryName($root);while($cursor){$a=[IO.File]::GetAttributes($cursor);Need (($a-band1024)-eq0 -and ($a-band16)-ne0) 'ORIGINAL_NONREPARSE_ANCESTORS';$cursor=[IO.Path]::GetDirectoryName($cursor)}
[void][IO.Directory]::CreateDirectory($root);$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false);foreach($s in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($s,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))};[IO.Directory]::SetAccessControl($root,$acl);[IO.File]::WriteAllText((Join-Path $root '.owner'),"future-classroom-owned-r80-a470-msvc-controlled-product-runtime/v1`n",[Text.UTF8Encoding]::new($false));$c.root=$root;CheckRoot $root
@{status='CREATED_ONLY_OWNED_MSVC_WIN7_TARGET_PRODUCT_RUNTIME_ROOT';root=$root;sid=$c.sid;nonce=$c.nonce;before=$before;originalStartQpc=$start;originalFrequency=$frequency}|ConvertTo-Json -Depth 18 -Compress
