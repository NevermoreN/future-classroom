$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$w=[Security.Principal.WindowsIdentity]::GetCurrent();try{if($w.User.Value-cne'S-1-5-21-3896111207-1867804362-1971593122-1001'){throw 'EXACT_CURRENT_SID'}}finally{$w.Dispose()}
$root=Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) 'Temp\FutureClassroom-r80-a470-msvc-controlled-product-0a3c0a1912ae4049bee91d02b9a14f28'
try{$a=[IO.File]::GetAttributes($root);@{status='PRESENT_REFUSE_NO_MUTATION';path=$root;reparse=(($a-band1024)-ne0);directory=(($a-band16)-ne0);mutations=$false}|ConvertTo-Json -Compress;exit 1}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-is[IO.FileNotFoundException]-or$e-is[IO.DirectoryNotFoundException]){@{status='KNOWN_ABSENT_READONLY_FIRST_FAILED_NONCE';path=$root;mutations=$false;productQueryOrMSI=$false}|ConvertTo-Json -Compress;exit 0};throw}
