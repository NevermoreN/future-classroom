"""Fixed a470 official Win7 normal artifacts; local static packaging only."""
from pathlib import Path,PureWindowsPath
import argparse,hashlib,json,os,re,runpy,shutil,struct,subprocess,time,zipfile
R=Path('/tmp/fc-round80-controlled-repair');P=R/'a470-msvc-product-preparation-first';I=R/'a470-msvc-product-input-first';A=R/'a470-msvc-product-assembly-first';O=R/'a470-msvc-product-package-first'
S='a4702b56bff66da5f5cbe74551d8751eb33fa520';W=R/'checkout-msvc-clippy-fix-first';Z=R/'a470-win7-download-first/artifact.zip';WEB=R/'controlled-web-first'
ADMISSION=R/'a470-native-preparation-first/admission.py';TOOLS=R/'inner-guard-probe-tools-first/tools.json';ENV=TOOLS.with_name('child-environment.json')
PINS={ADMISSION:'cdd08f3ae911917abbbe24b9f599e14680b95bc4a69eda78833e419d33a97bc6',TOOLS:'d82866321cc565890c38b494f7dd2ae6afa2fed8d4ae55270d7c4e931562099d',ENV:'d0b2d946aba5c21d94713c6e17cfa90a5c85c74dfa00d2336d4cbf88f05b37a0',WEB/'report.json':'706673da7a6ee05299b04f76b0cfe14329d5842417740bd2be0c4430ae0da41c'}
def digest(b):return hashlib.sha256(b).hexdigest()
def fact(p):
 p=Path(p);assert p.is_file() and not p.is_symlink();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=digest(b))
def fixed():
 for p,sha in PINS.items():assert fact(p)['sha256']==sha,(str(p),'FIXED_INPUT')
 tools=json.loads(TOOLS.read_text());env=json.loads(ENV.read_text())
 assert set(env)=={'LD_LIBRARY_PATH','LC_ALL','GIO_USE_VFS','GSETTINGS_BACKEND'}
 for name in ['wixl','msibuild','msiinfo','msiextract','objdump']:assert fact(Path(tools[name]['path']))['sha256']==tools[name]['sha256']
 return tools,env
def freeze_check(sha):
 assert re.fullmatch('[0-9a-f]{64}',sha or '') and fact(P/'freeze-first.json')['sha256']==sha
 x=json.loads((P/'freeze-first.json').read_text());assert x['ownedRoot']==str(P)
 for row in x['files']:assert fact(Path(row['path']))==row
 fixed()
def source_blobs(rows):
 raw=subprocess.check_output(['git','cat-file','--batch'],cwd=W,input=''.join(S+':'+r['path']+'\n' for r in rows).encode());cursor=0;out={}
 for row in rows:
  end=raw.index(b'\n',cursor);h=raw[cursor:end].split();assert h[1]==b'blob';size=int(h[2]);start=end+1;b=raw[start:start+size];assert raw[start+size:start+size+1]==b'\n';cursor=start+size+1;out[row['path']]=b
 assert cursor==len(raw);return out

def prepare():
 assert not I.exists();I.mkdir();(I/'.owner').write_text('future-classroom-owned-a470-msvc-product-input-first/v1\n');operations=[];started=time.monotonic()
 def command(label,argv,cwd=I):
  begin=time.monotonic();p=subprocess.run(argv,cwd=cwd,capture_output=True,timeout=60);so=I/(label+'.stdout.log');se=I/(label+'.stderr.log');so.write_bytes(p.stdout);se.write_bytes(p.stderr)
  operations.append(dict(name=label,argv=argv,actualExit=p.returncode,parentReaped=True,seconds=time.monotonic()-begin,stdout=fact(so),stderr=fact(se)));(I/'operations.json').write_text(json.dumps(operations,indent=2)+'\n');assert p.returncode==0;return p.stdout
 q=runpy.run_path(str(ADMISSION))['qualify']('win7');q.pop('nativeBytes');normal=[]
 with zipfile.ZipFile(Z) as z:
  result=json.loads(z.read('result.json'));ledger=json.loads(z.read('executables.json'));metadata=json.loads(z.read('logs/cargo-metadata.stdout.log'));sources=json.loads(z.read('input-sha256.json'))
  records=[r for r in ledger if r['role'] in ['product','custom_action_library']];assert len(records)==3
  expected={'fc-bootstrap':('fc-bootstrap','product','product-compile'),'fc-installer-lifecycle':('fc-bootstrap','product','lifecycle-compile'),'fc_windows':('fc-windows','custom_action_library','guard-library-compile')}
  assert {r['target'] for r in records}==set(expected)
  for row in records:
   pkg,role,phase=expected[row['target']];assert row['package']==pkg and row['role']==role and row['cargo_profile_test'] is False and row['executed'] is False
   package=[p for p in metadata['packages'] if p['name']==pkg];assert len(package)==1;package=package[0]
   targets=[t for t in package['targets'] if t['name']==row['target']];assert len(targets)==1;target=targets[0]
   steps=[r for r in result['commands'] if r['name']==phase];assert len(steps)==1;step=steps[0]
   assert step['passed'] and step['exit_code']==0 and step['parent_exited'] and not step['timed_out_or_pipe_stalled'] and not step['log_truncated']
   assert step==json.loads(z.read('logs/'+phase+'.result.json'))
   for stream in ['stdout','stderr']:assert digest(z.read(step[stream]))==step[stream+'_sha256']
   args=step['arguments'];assert args[:3]==['-Z','build-std','build' if row['target']=='fc_windows' else 'rustc'] and args[args.index('--target')+1]=='i686-win7-windows-msvc' and args[args.index('-p')+1]==pkg and '--release' in args and '--locked' in args and '--message-format=json' in args
   assert not any(a in args for a in ['--features','--all-features','--no-default-features','--tests','--all-targets'])
   if row['target']=='fc_windows':assert '--lib' in args and '--bin' not in args
   else:assert args[args.index('--bin')+1]==row['target']
   msgs=[json.loads(line) for line in z.read(step['stdout']).decode().splitlines() if line.startswith('{')]
   msgs=[m for m in msgs if m.get('reason')=='compiler-artifact' and m.get('package_id')==package['id'] and m.get('target')==target and m.get('manifest_path')==package['manifest_path']];assert len(msgs)==1;msg=msgs[0]
   assert msg['profile']['test'] is False and msg['profile']['opt_level']=='3' and not msg['profile']['debug_assertions']
   assert msg['features']==['default']
   filename='fc_windows.dll' if row['target']=='fc_windows' else row['target']+'.exe'
   outputs=[v for v in msg['filenames'] if PureWindowsPath(v).name==filename];assert len(outputs)==1
   assert PureWindowsPath(outputs[0]).is_relative_to(PureWindowsPath(metadata['target_directory'])/'i686-win7-windows-msvc'/'release')
   data=z.read(row['relative_path']);assert len(data)==row['bytes'] and digest(data)==row['sha256']
   off=struct.unpack_from('<I',data,60)[0];assert data[:2]==b'MZ' and data[off:off+4]==b'PE\0\0' and struct.unpack_from('<H',data,off+4)[0]==0x14c and struct.unpack_from('<H',data,off+24)[0]==0x10b and struct.unpack_from('<HH',data,off+72)==(6,1)
   assert bool(struct.unpack_from('<H',data,off+22)[0]&0x2000)==(row['target']=='fc_windows')
   normal.append(dict(executable=row,compilerArtifact=msg,compilerCommand=step))
  evidence=I/'ci-evidence';evidence.mkdir()
  for name in z.namelist():
   if name.startswith('logs/') or ('/' not in name and name.endswith('.json')) or name in [r['relative_path'] for r in records]:
    dest=evidence/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(name))
  blobs=source_blobs(sources)
 source=I/'source';source.mkdir();command('source-init',['git','init','--quiet',str(source)])
 gitcommon=subprocess.check_output(['git','rev-parse','--path-format=absolute','--git-common-dir'],cwd=W).decode().strip();alternate=Path(gitcommon)/'objects';assert alternate.is_dir()
 (source/'.git/objects/info/alternates').write_text(str(alternate)+'\n')
 command('source-detached-head',['git','update-ref','--no-deref','HEAD',S],source);command('source-index',['git','read-tree',S],source)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source).decode().strip()==S
 proof=q['committedInputMaterializationProof'];assert len(proof)==len(sources)==618
 pm={r['path']:r for r in proof}
 for row in sources:
  name=row['path'];b=blobs[name];p=pm[name];assert digest(b)==p['gitBlobSha256']
  if p['materialization']=='EXACT_UTF8_LF_TO_CRLF_CHECKOUT_BYTES':b=b.replace(b'\n',b'\r\n')
  else:assert p['materialization']=='EXACT_GIT_BLOB'
  assert len(b)==row['bytes'] and digest(b)==row['sha256'];dest=source/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 web=json.loads((WEB/'report.json').read_text());assert web['status']=='PASS_OWNED_WEB_BUILD_ONLY_NOT_PRODUCT_MSI_RUNTIME' and web['originalWorktreeInputsUnchanged']
 assert len(web['operations'])==2 and all(r['actualExit']==0 and r['originalParentReaped'] for r in web['operations'])
 webrows=web['originalInputs'];assert len(webrows)==len({r['path'] for r in webrows})==65
 tracked=subprocess.check_output(['git','ls-tree','-r','--name-only',S,'--','web'],cwd=W).decode().splitlines();assert set(tracked)=={r['path'] for r in webrows}
 for row in webrows:assert row['path'] in blobs and len(blobs[row['path']])==row['bytes'] and digest(blobs[row['path']])==row['sha256']
 dist=I/'web-dist';dist.mkdir()
 for row in web['outputs']:
  origin=WEB/'web/dist'/row['path'];b=origin.read_bytes();assert len(b)==row['bytes'] and digest(b)==row['sha256'];dest=dist/row['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 assert len(web['outputs'])==7
 notice=web['generatedLicense'];noticeBytes=(WEB/'web'/notice['path']).read_bytes();assert len(noticeBytes)==notice['bytes'] and digest(noticeBytes)==notice['sha256'] and noticeBytes==blobs['web/THIRD-PARTY-NOTICES.txt']
 tools,childenv=fixed()
 report=dict(status='PASS_OFFICIAL_WIN7_NORMAL_INPUTS_AND_EXACT_CI_MATERIALIZATION_ONLY',sourceSha=S,zip=fact(Z),officialCiQualification=q,normalArtifacts=normal,evidenceRoot=str(evidence),sourceRoot=str(source),sourceRawInventory=sources,materializationProof=proof,gitIdentity=dict(head=S,index='FULL_COMMITTED_TREE',worktree='PARTIAL_COPY_ONLY_618_CI_INPUTS_MATERIALIZED; HISTORICAL_ARCHIVE_PATHS_NOT_MATERIALIZED; NOT_CLAIMED_FULL_CLEAN_WORKTREE',objectAlternates=str(alternate),mainRepositoryGitWrites=False),web=dict(report=fact(WEB/'report.json'),sourceClosureRows=webrows,sourceClosureEqualsA470Git=True,dist=web['outputs'],generatedNotice=notice,packagedNotice='Exact admitted CI checkout raw bytes from source/web/THIRD-PARTY-NOTICES.txt; may be CRLF, distinct from verified original LF build notice.'),toolInputs=[fact(TOOLS),fact(ENV)]+[fact(Path(tools[n]['path'])) for n in ['wixl','msibuild','msiinfo','msiextract','objdump']],operations=operations,elapsedSeconds=time.monotonic()-started,windows='NOT_RUN',nativeExecution=False,systemInstallation=False,cargoInvocation=False)
 (I/'manifest.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],manifest=fact(I/'manifest.json'))))

def verify_inputs(expected):
 assert fact(I/'manifest.json')['sha256']==expected;x=json.loads((I/'manifest.json').read_text());assert x['status']=='PASS_OFFICIAL_WIN7_NORMAL_INPUTS_AND_EXACT_CI_MATERIALIZATION_ONLY' and x['sourceSha']==S
 source=Path(x['sourceRoot']);assert source==I/'source' and subprocess.check_output(['git','rev-parse','HEAD'],cwd=source).decode().strip()==S
 for row in x['sourceRawInventory']:
  f=fact(source/row['path']);assert f['bytes']==row['bytes'] and f['sha256']==row['sha256']
 for row in x['normalArtifacts']:
  a=row['executable'];f=fact(I/'ci-evidence'/a['relative_path']);assert f['bytes']==a['bytes'] and f['sha256']==a['sha256']
 for row in x['web']['dist']:
  f=fact(I/'web-dist'/row['path']);assert f['bytes']==row['bytes'] and f['sha256']==row['sha256']
 assert fact(Z)==x['zip'];fixed();return x

def assemble(expected):
 x=verify_inputs(expected);assert not A.exists() and not O.exists();A.mkdir();(A/'.owner').write_text('future-classroom-owned-a470-msvc-product-assembly-first/v1\n')
 tools,childenv=fixed();env=os.environ.copy();env.update(childenv);source=I/'source';evidence=I/'ci-evidence';steps=[];start=time.monotonic()
 def command(label,argv,seconds):
  begin=time.monotonic();p=subprocess.Popen(argv,cwd=source,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);timed=False
  try:out,err=p.communicate(timeout=seconds)
  except subprocess.TimeoutExpired:
   timed=True;import signal;os.killpg(p.pid,signal.SIGTERM)
   try:out,err=p.communicate(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);out,err=p.communicate()
  so=A/(label+'.stdout.log');se=A/(label+'.stderr.log');so.write_bytes(out);se.write_bytes(err)
  steps.append(dict(name=label,argv=argv,actualExit=p.returncode,parentReaped=True,timedOut=timed,seconds=time.monotonic()-begin,originalBudgetSeconds=seconds,stdout=fact(so),stderr=fact(se)))
  (A/'operations.json').write_text(json.dumps(steps,indent=2)+'\n');assert p.returncode==0 and not timed
 normal={r['executable']['target']:r['executable'] for r in x['normalArtifacts']};probe=A/'normal-product.zip'
 command('package-probe',['python3',str(source/'scripts/package-probe.py'),'--exe',str(evidence/normal['fc-bootstrap']['relative_path']),'--output',str(probe),'--target','i686-win7-windows-msvc','--toolchain','nightly-2026-10-29-x86_64-pc-windows-msvc','--objdump',tools['objdump']['path'],'--web-dist',str(I/'web-dist')],120)
 argv=['python3',str(source/'scripts/package-msi-candidate.py'),'--source-root',str(source),'--controlled','--guard-library',str(evidence/normal['fc_windows']['relative_path']),'--guard-library-sha256',normal['fc_windows']['sha256'],'--input-zip',str(probe),'--input-sha256',fact(probe)['sha256'],'--lifecycle-helper',str(evidence/normal['fc-installer-lifecycle']['relative_path']),'--lifecycle-helper-sha256',normal['fc-installer-lifecycle']['sha256'],'--build-evidence',str(evidence),'--build-result-sha256',fact(evidence/'result.json')['sha256'],'--output-dir',str(O)]
 for n in ['wixl','msibuild','msiinfo','msiextract','objdump']:argv+=['--'+n,tools[n]['path']]
 argv+=['--msibuild-sha256',tools['msibuild']['sha256']];command('controlled-msi',argv,600)
 verify_inputs(expected);report=json.loads((O/'report.json').read_text());assert report['status']=='PASS' and report['controlled_inner'] and not report['development_fixture_only'] and report['source_checkout']['head']==S and report['installation']=='NOT_RUN'
 result=dict(status='PASS_FORMAL_TARGET_SOURCE_CONTROLLED_CANDIDATE_STATIC_ONLY',inputManifest=fact(I/'manifest.json'),sourceSha=S,target='i686-win7-windows-msvc',commands=steps,normalProbe=fact(probe),buildReport=fact(O/'report.json'),seconds=time.monotonic()-start,windows='NOT_RUN',cargoInvocation=False,nativeExecution=False,systemInstallation=False,readiness='NOT_GRANTED',limitations=['Official MSVC normal same-source provenance, not released or Win7/Win10 runtime acceptance.','Controlled joint MSI and damaged repair for this exact package remain NOT_EXERCISED.'])
 (A/'report.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

def main():
 a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');a.add_argument('--prepare-inputs',action='store_true');a.add_argument('--assemble',action='store_true');a.add_argument('--preparation-freeze-sha256');a.add_argument('--input-manifest-sha256');v=a.parse_args()
 if not v.execute:print('{"status":"NOT_RUN","windows":"NOT_RUN"}');return
 assert v.prepare_inputs!=v.assemble;freeze_check(v.preparation_freeze_sha256)
 if v.prepare_inputs:prepare()
 else:assert re.fullmatch('[0-9a-f]{64}',v.input_manifest_sha256 or '');assemble(v.input_manifest_sha256)
 freeze_check(v.preparation_freeze_sha256)
if __name__=='__main__':main()
