"""Retire downloaded ended nonce scratch only; original MSI coverage FAIL stays."""
from pathlib import Path
import argparse,base64,datetime,hashlib,json,runpy,subprocess,time
E=Path('/tmp/fc-round78-ci-evidence');M=E/'msi-preparation-review-first'
REVIEW='df2cf2e28a3e12a0e00c550ab5e5638aa207f067096a7dfa5fc8ba28d1e9a89f'
REPORT='5126fb9b3c20f861ce7b3cf1f5ba7024508dfb17d827430e5da3cc33afd9545e'
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');a=p.parse_args()
 if not a.execute:print(json.dumps({'status':'NOT_RUN_PREPARATION_ONLY'}));return 0
 assert (E/'.owner').read_bytes()==b'future-classroom-owned-r78-ci-evidence/v1\n'
 review=E/'independent-preparation-review-first/review-third.json';assert sha(review.read_bytes())==REVIEW
 original=E/'product-msi-runtime-first/report.json';b=original.read_bytes();assert sha(b)==REPORT;r=json.loads(b);phase=r['phaseResult']
 assert r['phaseParentExit']==0 and r['downloadVerified']=='EXACT_EACH_REMOTE_FILE_SIZE_SHA_AND_MEMBERSHIP' and r['sourceUnchanged'] is True
 operation=[x for x in r['operations'] if x['name']=='03-original-phase-parent'];assert len(operation)==1 and operation[0]['actualExit'] is True and operation[0]['exitCode']==0 and operation[0]['timedOut'] is False and operation[0]['reaped'] is True
 assert len(phase['phases'])==2 and phase['status']=='FAIL_NOT_COMPLETE' and phase['failureCode']=='PHASE_INDEPENDENT_ROLE_COVERAGE_UNKNOWN' and phase['ownerUnknown'] is False and phase['instrumentUnknown'] is False and phase['retainedDirectClients']==0
 for p in phase['phases']:
  assert p['client']['actualExit'] is True and p['client']['exitCode']==0 and p['client']['pipesComplete'] is True and p['ownerProof']['knownControlsReturned'] is True
  o=p['observerFinal'];assert o['Closed'] is True and not o['Errors'] and len(o['Processes'])==4
  assert all(f['ActualWait']==0 and f['ActualExitCode']==0 and f['CloseStatus']=='CHECKED_CLOSE_SUCCESS' for f in o['Processes'])
  assert p['helperImageCleanup']['status']=='PASS_PRECISE_HELPER_IMAGE_AUTOMATIC_ABSENCE' and p['helperImageCleanup']['brokerImageKnownAbsent'] is True and p['helperImageCleanup']['allCapturedImagesKnownAbsent'] is True
 assert phase['failureCleanupAbsent']['knownAbsent'] is True and phase['gateRetirementExternalReadback']['namespaceKnownAbsent'] is True and phase['gateRetirementExternalReadback']['pendingKnownAbsent'] is True
 t=runpy.run_path(str(M/'adapted-second/run-production-msi-r78-second.py'));config=Path(r['config']['path']);cb=config.read_bytes();assert len(cb)==r['config']['bytes'] and sha(cb)==r['config']['sha256'];plan=json.loads(cb)
 local=E/'product-msi-runtime-first/download'/plan['runtimeRootName'];t['verify_download'](local,r['remoteInventory'])
 paths=sorted({x['path'] for p in phase['phases'] for x in p['helperImageCleanup']['images']}|{r'C:\Windows\Installer\3491279d.msi',r'C:\Windows\Installer\349127a1.msi',r'C:\Windows\Installer\MSI28C8.tmp',r'C:\Windows\Installer\MSI2CE2.tmp'})
 c=dict(nonce=plan['runtimeNonce'],sid=plan['expectedUserSid'],root=r['beforeCreate']['root'],plan=plan,inventory=r['remoteInventory'],precisePaths=paths)
 preflight=(M/'adapted-second/ReadOnlyPreflightFunction.ps1').read_text()
 script=preflight+r'''
$before=Measure-FcBeforePreflight -Config $c.plan;if($before.status-cne'PASS_BEFORE_KNOWN_ABSENCE_ONLY_NOT_EXECUTION_ADMISSION'){throw 'CURRENT_PRODUCT_REGISTRATION_RUN_GATE_OR_PENDING_NOT_ABSENT'}
CheckRoot $c.root
$processes=@(Get-CimInstance Win32_Process|Where-Object{$_.ExecutablePath -and $_.ExecutablePath.StartsWith(($c.root+'\'),[StringComparison]::OrdinalIgnoreCase)})
if($processes.Count-ne0){throw 'OWNED_ROOT_HAS_LIVE_EXECUTABLE'}
$observed=@();foreach($p in $c.precisePaths){try{[void][IO.File]::GetAttributes($p);throw 'PRECISE_SYSTEM_TEST_PATH_STILL_PRESENT'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}};$observed+=@{path=$p;status='KNOWN_ABSENT';mutations=$false}}
''' + t['DELETE'] + r'''
@{status='PASS_DOWNLOADED_ENDED_NONCE_SCRATCH_ONLY_ORIGINAL_MSI_FAIL_RETAINED';before=$before;preciseSystemPathObservations=$observed;ownedProcesses=$processes.Count;originalCoverageFailure='PHASE_INDEPENDENT_ROLE_COVERAGE_UNKNOWN_UNCHANGED';systemCacheOrRegistryMutation=$false;knownRootAbsent=$true}|ConvertTo-Json -Depth 10 -Compress
'''
 cmd,feed=t['remote'](script,c);out=E/'root-first-product-scratch-cleanup-first.json';assert not out.exists();value={'status':'RUNNING','originalReportSha256':REPORT,'independentReviewSha256':REVIEW,'command':cmd,'stdin':{'bytes':len(feed),'sha256':sha(feed),'base64':base64.b64encode(feed).decode()},'scope':'Current readonly product/gate/Run/cache/image absence, unchanged downloaded inventory, then delete only this owned nonce scratch. No cache/service/registry deletion, no MSI execution, no original FAIL rewrite.','startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'originalBudgetSeconds':45};out.write_text(json.dumps(value,indent=2)+'\n');start=time.monotonic()
 try:
  completed=subprocess.run(cmd,input=feed,capture_output=True,timeout=45);value.update(actualExit=True,exitCode=completed.returncode,elapsedSeconds=time.monotonic()-start)
  for k,data in [('stdout',completed.stdout),('stderr',completed.stderr)]:value[k]={'bytes':len(data),'sha256':sha(data),'base64':base64.b64encode(data).decode()}
  lines=completed.stdout.decode('utf-8-sig').splitlines();assert completed.returncode==0 and len(lines)==2
  deleted=json.loads(lines[0]);native=json.loads(lines[1]);assert deleted['status']=='REMOVED_EXACT_PRODUCT_RUNTIME_ROOT' and deleted['nonce']==plan['runtimeNonce'] and deleted['knownAbsent'] is True and native['knownRootAbsent'] is True
  assert native['status']=='PASS_DOWNLOADED_ENDED_NONCE_SCRATCH_ONLY_ORIGINAL_MSI_FAIL_RETAINED' and {x['path'] for x in native['preciseSystemPathObservations']}==set(paths) and all(x['status']=='KNOWN_ABSENT' for x in native['preciseSystemPathObservations'])
  value.update(status='PASS',actual= native,deleteReceipt=deleted,originalReportStillExact=sha(original.read_bytes())==REPORT);assert value['originalReportStillExact'] is True
 except Exception as error:value.update(status='FAIL_RETAIN_REMAINING_ORIGINALS',errorType=type(error).__name__,error=str(error))
 out.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps({k:value.get(k) for k in ('status','exitCode','errorType','error')}));return 0 if value['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
