"""Finite exact-path readonly follow-up; default does not contact Windows."""
from pathlib import Path, PureWindowsPath
import argparse, base64, hashlib, json, re, runpy, subprocess, sys
sys.dont_write_bytecode = True
E = Path('/tmp/fc-round78-ci-evidence')
ROOT = Path('/workspace/共享/Eliora/未来教室计划')
def sha(b): return hashlib.sha256(b).hexdigest()
def raw(b): return dict(bytes=len(b), sha256=sha(b), base64=base64.b64encode(b).decode(), captureScope='COMPLETE')
def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('--execute',action='store_true'); a=ap.parse_args()
    if not a.execute:
        print(json.dumps(dict(status='PREPARED_NOT_RUN',mutations='NONE')));return
    assert (E/'.owner').read_bytes()==b'future-classroom-owned-r78-ci-evidence/v1\n'
    result=E/'root-second-msi-system-paths-first.json'
    assert not result.exists()
    rb=(E/'product-msi-runtime-second/report.json').read_bytes()
    assert sha(rb)=='a636d1cc6a3f3f91a8c21d0aaf0dac43cbe93e856e9a66e5926af1ee3437d1f7'
    r=json.loads(rb); assert r['status']=='PASS_PRODUCT_MSI_RUNTIME_CAPTURE_AND_EXACT_SCRATCH_CLEANUP_WIN11_ONLY'
    checked=E/'independent-finite-acceptance-first/checked-originals.json'; cb=checked.read_bytes()
    assert sha(cb)=='c504a319c12a13b9b369364ab7500d3930a2c29eed706d6876fea88907d30d0a'
    c=json.loads(cb)['msi']; assert len(c['sixImages'])==6
    sources={}; logs=[]
    pattern=re.compile(r'C:\\Windows\\Installer\\(?:[0-9a-f]{1,16}\.msi|MSI[0-9a-f]{1,8}\.tmp)(?![\w.\\])',re.I)
    def add(p, origin):
        assert pattern.fullmatch(p),p
        key=p.lower(); sources.setdefault(key,dict(path=p,origins=[]))['origins'].append(origin)
    for p in c['sixImages']: add(p,dict(kind='CAPTURED_EXECUTABLE_IMAGE_ORIGINAL_HANDLE'))
    for p in c['cache']['previouslyObservedExactPaths']:
        add(p['path'],dict(kind='ACTUAL_LOCALPACKAGE_API_PATH'))
    download=E/'product-msi-runtime-second/download'; dirs=list(download.iterdir()); assert len(dirs)==1
    inventory={x.get('relativePath',x.get('path','')):x for x in r['remoteInventory']['files']}
    for phase in r['phaseResult']['phases']:
        name=PureWindowsPath(phase['rawMsiLog']).name; path=dirs[0]/name; data=path.read_bytes()
        entries=[x for x in r['remoteInventory']['files'] if str(x.get('relativePath',x.get('path',''))).replace('\\','/').split('/')[-1]==name]
        assert len(entries)==1, (name, r['remoteInventory']['files'][0])
        entry=entries[0]; assert sha(data)==entry['sha256'] and len(data)==entry.get('bytes',entry.get('length'))
        assert data.startswith(b'\xff\xfe'), 'original MSI log UTF16 LE BOM expected'
        text=data.decode('utf-16'); logs.append(dict(path=str(path),bytes=len(data),sha256=sha(data),encoding='UTF-16-LE-BOM'))
        for n,line in enumerate(text.splitlines(),1):
            for m in pattern.finditer(line):
                add(m.group(),dict(kind='RUNNING_SCRIPT_LOG_PATH' if 'Running Script:' in line else 'EXACT_INSTALLER_PATH_IN_ORIGINAL_LOG',phase=phase['name'],log=name,lineNumber=n,line=line))
    paths=sorted(sources.values(),key=lambda x:x['path'].lower()); assert len(paths)==11,len(paths)
    ps=r'''$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);
Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class ExactReadonlyAttributes{[DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)]public static extern uint GetFileAttributesW(string name);}'
$paths=__PATHS__; $facts=@(foreach($p in $paths){$a=[ExactReadonlyAttributes]::GetFileAttributesW($p);$e=[Runtime.InteropServices.Marshal]::GetLastWin32Error();$s=if($a -ne [uint32]::MaxValue){'PRESENT'}elseif($e -eq 2 -or $e -eq 3){'KNOWN_ABSENT'}else{'UNKNOWN'};@{path=$p;attributes=[uint64]$a;win32Error=$e;status=$s}});
@{facts=$facts;mutations='NONE';scope='Exact original twelve-role trial system paths only; no enumeration, deletion, remote scratch access, or process interaction'}|ConvertTo-Json -Depth 8 -Compress
'''.replace('__PATHS__','@('+','.join("'"+x['path']+"'" for x in paths)+')')
    remote=runpy.run_path(str(ROOT/'scripts/windows-probe.py'))['Remote']('elior@192.168.10.212',Path('/config/.local/share/future-classroom-test-access/win11-192.168.10.212'))
    wrapper="[Console]::InputEncoding=[System.Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()));"
    cmd=['ssh',*remote.options,remote.host,'powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(wrapper.encode('utf-16-le')).decode()]
    report=dict(status='FAIL',mutations='NONE',runtimeReportSha256=sha(rb),independentCheckedOriginalsSha256=sha(cb),sourceSha256=sha(Path(__file__).read_bytes()),paths=paths,originalLogs=logs,powershellSource=ps,command=cmd,stdin=raw(ps.encode()),timeoutSeconds=45)
    with result.open('x') as f:
        try:
            p=subprocess.run(cmd,input=ps.encode(),capture_output=True,timeout=45)
            report['ssh']=dict(actualExit=True,exitCode=p.returncode,stdout=raw(p.stdout),stderr=raw(p.stderr))
            assert p.returncode==0
            facts=json.loads(p.stdout.decode('utf-8-sig')); report['observed']=facts
            assert {x['path'].lower() for x in facts['facts']}==set(sources)
            assert len(facts['facts'])==11 and all(x['status']=='KNOWN_ABSENT' for x in facts['facts'])
            report['status']='PASS'
        except subprocess.TimeoutExpired as e:
            report['ssh']=dict(actualExit=False,stdout=raw(e.stdout or b''),stderr=raw(e.stderr or b''));report['error']='TIMEOUT'
        except Exception as e: report['error']=str(e)
        f.write(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(status=report['status'],report=str(result),sha256=sha(result.read_bytes()),exactPaths=len(paths),mutations='NONE')))
    if report['status']!='PASS': raise SystemExit(1)
if __name__=='__main__': main()
