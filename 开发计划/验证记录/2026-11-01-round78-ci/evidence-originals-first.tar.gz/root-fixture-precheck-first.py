"""Compile test instruments and parse PS only; never invoke their entrypoints/MSI."""
from pathlib import Path
import argparse,base64,datetime,hashlib,json,secrets,subprocess,time
E=Path('/tmp/fc-round78-ci-evidence')
D=E/'msi-preparation-review-first'
FREEZE_SHA='ef2f5218c18c4be2ed58ab715736ce597afa9ba8e3f2e10b8728e0885e1bf1af'
KEY='/config/.local/share/future-classroom-test-access/win11-192.168.10.212'
SCRIPT=r'''
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Sha([byte[]]$b){$h=[Security.Cryptography.SHA256]::Create();try{return ([BitConverter]::ToString($h.ComputeHash($b))).Replace('-','').ToLowerInvariant()}finally{$h.Dispose()}}
function KnownAbsent($p){try{[void][IO.File]::GetAttributes($p);return $false}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-is[IO.FileNotFoundException]-or$e-is[IO.DirectoryNotFoundException]){return $true};throw}}
$r=@{status='FAIL';scope='PS parse and C# library compile only; no instrument entrypoint, product, MSI, registry or service action';powershellParse=@();compiler=$null;cleanup='NOT_RUN'}
$root=Join-Path ([IO.Path]::GetFullPath($env:TEMP)) ('FutureClassroom-r78-fixture-parse-'+$c.nonce)
$created=$false;$compilerReturned=$true;$p=$null
try{
 if($PSVersionTable.PSVersion.Major-ne5 -or [IntPtr]::Size-ne8){throw 'DESKTOP_PS51_X64'}
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$identity.User;if($sid.Value-cne$c.sid){throw 'EXACT_USER'}}finally{$identity.Dispose()}
 if(-not(KnownAbsent $root)){throw 'NEW_NONCE_ROOT_REQUIRED'}
 $parent=[IO.Path]::GetDirectoryName($root);while($parent){if(([IO.File]::GetAttributes($parent)-band[IO.FileAttributes]::ReparsePoint)-ne0){throw 'PARENT_REPARSE'};$parent=[IO.Path]::GetDirectoryName($parent)}
 [void][IO.Directory]::CreateDirectory($root);$created=$true
 $acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false)
 foreach($s in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($s,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))}
 [IO.Directory]::SetAccessControl($root,$acl)
 [IO.File]::WriteAllText((Join-Path $root '.owner'),"future-classroom-owned-r78-fixture-parse/v1`n",[Text.UTF8Encoding]::new($false))
 $r.root=$root;$r.nonce=$c.nonce;$r.sources=@()
 foreach($f in $c.files){
  if($f.name-cnotin@('ProcessObserver.cs','ProductState.cs','GateRetirement.cs','ReadOnlyPreflightFunction.ps1','ProductState.ps1','Invoke-ProductionMsiPhases.ps1')){throw 'CLOSED_SIX_SOURCE_NAMES'}
  $b=[Convert]::FromBase64String($f.base64);if($b.Length-ne$f.bytes -or (Sha $b)-cne$f.sha256){throw 'SOURCE_BYTES'}
  [IO.File]::WriteAllBytes((Join-Path $root $f.name),$b);$r.sources+=@{name=$f.name;bytes=$b.Length;sha256=(Sha $b)}
  if($f.name.EndsWith('.ps1')){$tokens=$null;$errors=$null;[void][Management.Automation.Language.Parser]::ParseInput([Text.Encoding]::UTF8.GetString($b),[ref]$tokens,[ref]$errors);$r.powershellParse+=@{name=$f.name;errors=@($errors|ForEach-Object{@{message=$_.Message;errorId=$_.ErrorId;line=$_.Extent.StartLineNumber}})};if($errors.Count-ne0){throw 'POWERSHELL_PARSE_ERRORS'}}
 }
 $compiler=Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe';$output=Join-Path $root 'fixture.dll'
 $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$compiler;$info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
 $args=@('/nologo','/target:library','/platform:x86','/r:System.Management.dll','/r:System.Core.dll',('/out:"'+$output+'"'))
 foreach($n in @('ProcessObserver.cs','ProductState.cs','GateRetirement.cs')){$args+=('"'+(Join-Path $root $n)+'"')};$info.Arguments=$args-join' '
 $p=[Diagnostics.Process]::new();$p.StartInfo=$info;if(-not$p.Start()){throw 'COMPILER_START'};$compilerReturned=$false
 $stdout=$p.StandardOutput.ReadToEndAsync();$stderr=$p.StandardError.ReadToEndAsync();if(-not$p.WaitForExit(45000)){throw 'ORIGINAL_COMPILER_45S_UNKNOWN_RETAIN'};$compilerReturned=$true
 $r.compiler=@{path=$compiler;pid=$p.Id;actualExit=$true;exitCode=$p.ExitCode;stdout=$stdout.Result;stderr=$stderr.Result;originalBudgetSeconds=45;target='x86 library; never loaded or invoked'}
 $p.Dispose();$p=$null;if($r.compiler.exitCode-ne0){throw 'CSHARP_COMPILE_FAILED'}
 $b=[IO.File]::ReadAllBytes($output);$r.compiledLibrary=@{name='fixture.dll';bytes=$b.Length;sha256=(Sha $b);executed=$false}
 $r.status='PASS_PARSE_AND_COMPILE_ONLY_PRODUCT_MSI_NOT_RUN'
}catch{$r.error=@{type=$_.Exception.GetType().FullName;message=$_.Exception.Message}}
finally{
 if($created -and $compilerReturned){try{
  if([IO.File]::ReadAllText((Join-Path $root '.owner'))-cne"future-classroom-owned-r78-fixture-parse/v1`n"){throw 'EXACT_OWNER'}
  if(([IO.File]::GetAttributes($root)-band[IO.FileAttributes]::ReparsePoint)-ne0){throw 'ROOT_REPARSE'}
  $all=@([IO.Directory]::GetFileSystemEntries($root));$r.deletedFiles=@()
  foreach($f in $all){$a=[IO.File]::GetAttributes($f);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0 -or ($a-band[IO.FileAttributes]::Directory)-ne0 -or [IO.Path]::GetFileName($f)-cnotin@('.owner','ProcessObserver.cs','ProductState.cs','GateRetirement.cs','ReadOnlyPreflightFunction.ps1','ProductState.ps1','Invoke-ProductionMsiPhases.ps1','fixture.dll')){throw 'EXACT_OWNED_FLAT_MEMBERSHIP'};$b=[IO.File]::ReadAllBytes($f);$r.deletedFiles+=@{name=[IO.Path]::GetFileName($f);bytes=$b.Length;sha256=(Sha $b)}}
  foreach($f in $all){if([IO.Path]::GetFileName($f)-cne'.owner'){[IO.File]::Delete($f)}};[IO.File]::Delete((Join-Path $root '.owner'));[IO.Directory]::Delete($root,$false)
  if(-not(KnownAbsent $root)){throw 'ROOT_NOT_ABSENT'};$r.cleanup='PASS_EXACT_NONCE_ROOT_KNOWN_ABSENT'
 }catch{$r.cleanup='FAIL_RETAIN_REMAINING';$r.cleanupError=$_.Exception.Message}}
 elseif($created){$r.cleanup='RETAIN_ORIGINAL_COMPILER_RETURN_UNKNOWN'}
}
$r|ConvertTo-Json -Depth 14 -Compress
if($r.status-cne'PASS_PARSE_AND_COMPILE_ONLY_PRODUCT_MSI_NOT_RUN' -or $r.cleanup-cne'PASS_EXACT_NONCE_ROOT_KNOWN_ABSENT'){exit 1}
'''
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');a=p.parse_args()
 if not a.execute:print(json.dumps({'status':'NOT_RUN_PREPARATION_ONLY','windows':'NOT_CONTACTED'}));return 0
 assert (E/'.owner').read_bytes()==b'future-classroom-owned-r78-ci-evidence/v1\n'
 f=D/'final-preparation-freeze-first.json';b=f.read_bytes();assert sha(b)==FREEZE_SHA
 freeze=json.loads(b)
 for row in freeze['files']:
  raw=Path(row['path']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
 rows=[r for r in freeze['files'] if Path(r['path']).suffix in ('.cs','.ps1')];assert len(rows)==6
 c={'nonce':secrets.token_hex(16),'sid':'S-1-5-21-3896111207-1867804362-1971593122-1001','files':[{'name':Path(r['path']).name,'bytes':r['bytes'],'sha256':r['sha256'],'base64':base64.b64encode(Path(r['path']).read_bytes()).decode()} for r in rows]}
 source=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+SCRIPT).encode()
 wrapper="[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()))"
 cmd=['ssh','-i',KEY,'-o','BatchMode=yes','-o','ConnectTimeout=8','elior@192.168.10.212','powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(wrapper.encode('utf-16-le')).decode()]
 out=E/'root-fixture-precheck-first.json';assert not out.exists()
 r={'status':'RUNNING','scope':'Test instrument PS parsing and x86 library compilation; no entrypoints or MSI executed','sourceFreezeSha256':FREEZE_SHA,'sourceFiles':rows,'nonce':c['nonce'],'command':cmd,'remoteSource':source.decode(),'originalOuterBudgetSeconds':60,'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 out.write_text(json.dumps(r,indent=2)+'\n');start=time.monotonic()
 try:
  v=subprocess.run(cmd,input=source,capture_output=True,timeout=60);r.update(actualExit=True,exitCode=v.returncode,elapsedSeconds=time.monotonic()-start)
  for label,data in [('stdout',v.stdout),('stderr',v.stderr)]:r[label]={'bytes':len(data),'sha256':sha(data),'base64':base64.b64encode(data).decode()}
  native=json.loads(v.stdout.decode('utf-8-sig'));r['native']=native
  assert v.returncode==0 and native['status']=='PASS_PARSE_AND_COMPILE_ONLY_PRODUCT_MSI_NOT_RUN' and native['cleanup']=='PASS_EXACT_NONCE_ROOT_KNOWN_ABSENT'
  assert {x['name']:(x['bytes'],x['sha256']) for x in native['sources']}=={x['name']:(x['bytes'],x['sha256']) for x in c['files']}
  r['status']='PASS_INSTRUMENT_PARSE_COMPILE_AND_CLEANUP_ONLY'
 except Exception as error:r.update(status='FAIL_RETAIN_ORIGINALS',errorType=type(error).__name__,error=str(error))
 out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k) for k in ('status','exitCode','errorType','error')}) );return 0 if r['status'].startswith('PASS_') else 1
if __name__=='__main__':raise SystemExit(main())
