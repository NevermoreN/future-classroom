"""Root's serial second archive invocation; creates receipt outside E on success."""
from pathlib import Path
import base64, datetime, hashlib, json, subprocess, sys, time
E=Path('/tmp/fc-round78-ci-evidence')
DEST=Path('/workspace/共享/Eliora/未来教室计划/开发计划/验证记录/2026-11-01-round78-ci')
def sha(b):return hashlib.sha256(b).hexdigest()
def raw(b):return dict(bytes=len(b),sha256=sha(b),base64=base64.b64encode(b).decode(),captureScope='COMPLETE')
def main():
    controller=E/'archive-preparation-second/archive-second.py'
    assert sha(controller.read_bytes())=='ea621b1a5402e5800c4bb0675365cc53a017bbe9dadfbc82430070e864207b01'
    assert sha((E/'independent-archive-review-first/review-second.json').read_bytes())=='8562fcbadc05a1caedad9c936eef989d0cfd6ad1759270ca3314434f087dcd9e'
    assert not DEST.exists()
    args=['python3','-B',str(controller),'--execute','--root-controllers-terminal','--source-base-git','261c58aca8b0f63ff2cfb4dbd5e85c0d17770005']
    bindings={
      'acceptance-report':str(E/'independent-finite-acceptance-first/acceptance-first.json'),
      'expected-acceptance-sha256':'51c5daa45e07ca0781174e973757e55c17a9d25d4308ae3a62c512e6a5d04735',
      'expected-acceptance-status':'PASS_R78_FINITE_DUAL_MSVC_WIN11_AND_PRODUCT_MSI_AUTOMATIC_IMAGE_CLEANUP',
      'readonly-audit':str(E/'windows-readonly-final-first.json'),
      'expected-readonly-sha256':'c62f735c28fd60ab5aaea6053453ce41a32ba6545f6245bcb14ef840a1a7a23d',
      'modern-static-audit':str(E/'ci-admission-preparation-first/modern-static-audit-first.json'),
      'expected-modern-static-sha256':'af22170491244c24b93a8718f1bbe29c4060d995ebc51bd5b48ff10fb2ec5bb7',
      'modern-run-id':'41332456981',
      'win7-static-audit':str(E/'ci-admission-preparation-first/win7-static-audit-first.json'),
      'expected-win7-static-sha256':'c7c1874cc341ad5e0b0ab030a64a7e488669e8cf0abb0029abbdd791d7a7ba77',
      'win7-run-id':'41332469102',
      'tools-report':str(E/'msi-tools-preparation-first/msi-tools-preparation-first.json'),
      'expected-tools-sha256':'f76db8b7e920215c82949012369477d1cdb7e4d9c7977801c29f5afa170b9a8c'}
    for k,v in bindings.items():args.extend(['--'+k,v])
    promoted=['independent-finite-acceptance-first/acceptance-first.json','windows-readonly-final-first.json','root-second-msi-system-paths-first.json','ci-admission-preparation-first/modern-static-audit-first.json','ci-admission-preparation-first/win7-static-audit-first.json','modern-msvc-runtime-operation-first.json','win7-msvc-runtime-operation-first.json','modern-msvc-runtime-first.json','win7-msvc-runtime-first.json','product-msi-runtime-first/report.json','product-msi-runtime-second/report.json','root-first-product-scratch-cleanup-first.json','independent-preparation-review-first/review-third.json','msi-preparation-review-first/final-preparation-freeze-third.json','root-fixture-precheck-first.json','root-fixture-precheck-third.json','root-package-pipeline-first.json','root-main-checks-first.json','local-cleanup-preparation-first/preparation-validation-first.json','package-source-preparation-first/candidate-output-first/report.json','root-archive-operation-first.json','independent-archive-review-first/review-second.json']
    for p in promoted:args.extend(['--promote',p])
    started=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.monotonic()
    p=subprocess.run(args,capture_output=True)
    report=dict(status='PASS' if p.returncode==0 else 'FAIL_ORIGINAL_SECOND_ARCHIVE_EXIT',actualExit=True,exitCode=p.returncode,command=args,startedUtc=started,completedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-t,stdout=raw(p.stdout),stderr=raw(p.stderr),controllerSha256=sha(controller.read_bytes()),invocationControllerSha256=sha(Path(__file__).read_bytes()),sourceDeletion=False,windowsContacted=False)
    # On PASS, E's exact frozen membership may never be changed again.
    destination=DEST/'root-archive-operation-second.json' if p.returncode==0 else E/'root-archive-operation-second.json'
    with destination.open('x') as f:f.write(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(status=report['status'],exitCode=p.returncode,receipt=str(destination),elapsedSeconds=report['elapsedSeconds'],stdout=p.stdout.decode(),stderr=p.stderr.decode())))
    return p.returncode
if __name__=='__main__':sys.exit(main())
