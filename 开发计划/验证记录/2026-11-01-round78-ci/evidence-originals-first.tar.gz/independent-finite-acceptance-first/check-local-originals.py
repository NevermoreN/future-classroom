"""Independent local replay only; never calls Windows, Cargo, network or PE.
Writes only this directory's checked-originals.json, not final acceptance.
"""
import sys
sys.dont_write_bytecode = True
import argparse, datetime, hashlib, json, pathlib, runpy, subprocess, zipfile

E = pathlib.Path('/tmp/fc-round78-ci-evidence')
D = pathlib.Path(__file__).resolve().parent
MAIN = pathlib.Path('/workspace/共享/Eliora/未来教室计划')
SOURCE = '261c58aca8b0f63ff2cfb4dbd5e85c0d17770005'
CI = E/'ci-admission-preparation-first'

def sha(b): return hashlib.sha256(b).hexdigest()
def fact(p):
    p=pathlib.Path(p); b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=sha(b))
def read(p): return json.loads(pathlib.Path(p).read_text())
def exact(row):
    actual=fact(row['path'])
    assert actual['sha256']==row['sha256'] and ('bytes' not in row or actual['bytes']==row['bytes']),row['path']
    return actual

old=runpy.run_path(str(MAIN/'开发计划/验证记录/2026-11-01-round67-ci/independent-runtime-first.py'))
children=runpy.run_path(str(CI/'parse-native-children-first.py'))
gate=runpy.run_path(str(CI/'runtime-inputs-first.py'))
result=dict(status='PASS_LOCAL_ORIGINALS_REPLAY_FINAL_AUDITS_NOT_YET_BOUND',sourceSha=SOURCE,
            startedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),ci=[],msi={})
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=MAIN).decode().strip()==SOURCE
for row in read(CI/'prepared-implementation-first.json')['implementations']: exact(row)

for tag in ('modern','win7'):
    ap=CI/(tag+'-static-audit-first.json'); audit=read(ap)
    sp=CI/(tag+'-static-operation-first.json'); sop=read(sp)
    rp=E/(tag+'-msvc-runtime-first.json'); runtime=read(rp)
    rop=E/(tag+'-msvc-runtime-operation-first.json'); operation=read(rop)
    for op in (sop,operation): assert op['actualExit'] is True and op['exitCode']==0
    assert operation['inputsUnchanged'] and operation['cleanup']=='PASS'
    assert audit['status']=='PASS_STATIC_ONLY_RUNTIME_NOT_RUN' and audit['sourceSha']==SOURCE
    assert all(p['status']=='PASS' for p in audit['phases'])
    for row in operation['inputIdentities'].values(): exact(row)
    for row in operation['pinnedSourceIdentities'].values(): exact(row)
    a=argparse.Namespace(source_sha=SOURCE,baseline=tag,run_id=audit['runId'],job_id=audit['jobId'],
        artifact_id=audit['artifactId'],zip_bytes=audit['zip']['bytes'],zip_sha256=audit['zip']['sha256'],
        zip=pathlib.Path(audit['zip']['path']),run_metadata=E/(tag+'-run-final-first.json'),
        job_metadata=E/(tag+'-jobs-final-first.json'),artifact_metadata=E/(tag+'-artifacts-final-first.json'),
        download_receipt=E/(tag+'-download-original-official-first.json'),
        download_operation=E/(tag+'-download-operation-official-first.json'),
        static_audit=ap,static_audit_sha256=fact(ap)['sha256'],static_operation=sp,
        static_operation_sha256=fact(sp)['sha256'],
        output_dir=pathlib.Path(sop['command'][sop['command'].index('--output-dir')+1]))
    a.download_receipt_sha256=fact(a.download_receipt)['sha256']
    a.download_operation_sha256=fact(a.download_operation)['sha256']
    bound=gate['runtime_inputs'](a)
    zfact=exact(audit['zip'])
    with zipfile.ZipFile(a.zip) as z:
        assert z.testzip() is None
        info=[i for i in z.infolist() if not i.is_dir()]
        assert len(info)==len(audit['members'])
        members={r['path']:r for r in audit['members']}
        # Original archives may use Windows separators; normalize only member names.
        assert len({i.filename.replace('\\','/') for i in info})==len(info)
        for i in info:
            name=i.filename.replace('\\','/'); row=members[name]; data=z.read(i)
            assert len(data)==row['bytes'] and sha(data)==row['sha256']
    raw=a.output_dir/'raw'
    for row in audit['members']:
        p=raw/row['path']
        if p.is_file():
            actual=fact(p); assert (actual['bytes'],actual['sha256'])==(row['bytes'],row['sha256'])
    matches=audit['sourceMatches']
    batch=subprocess.run(['git','cat-file','--batch'],cwd=MAIN,input=('\n'.join(r['gitBlobOidSha1'] for r in matches)+'\n').encode(),capture_output=True,check=True).stdout
    pos=0
    for row in matches:
        end=batch.index(b'\n',pos); hdr=batch[pos:end].split(); n=int(hdr[2]); blob=batch[end+1:end+1+n]; pos=end+1+n+1
        assert hdr[1]==b'blob'
        ci_bytes=blob if row['checkoutMatch']=='EXACT_GIT_BLOB' else blob.replace(b'\n',b'\r\n') if row['checkoutMatch']=='EXACT_FULL_LF_TO_CRLF' else None
        assert ci_bytes is not None and len(ci_bytes)==row['bytes'] and sha(ci_bytes)==row['sha256']
        assert (MAIN/row['path']).read_bytes()==blob
    old['check_platform'](runtime)
    cases=[]
    for item in runtime['tests']:
        if item['name']==pathlib.Path(bound['native']['localPath']).name:
            cases.append(children['native_harness'](item,bound['native'],bound['childSource']))
        else: cases.append(old['harness'](item))
    assert cases==operation['harnesses']
    totals={k:sum(c[k] for c in cases) for k in ('passed','failed','ignored','measured','filteredOut')}
    assert totals==operation['totals']==dict(passed=1567,failed=0,ignored=0,measured=0,filteredOut=0)
    probe=runpy.run_path(str(MAIN/'scripts/windows-probe.py'))
    flow=old['flow'](runtime,'public',probe['PUBLIC_DESKTOP_STEPS'])
    assert flow==operation['publicDesktop'] and flow['steps']==20
    result['ci'].append(dict(baseline=tag,audit=fact(ap),staticParent=fact(sp),wholeZip=zfact,
        wholeZipCrcAndEveryMemberRehashed=True,zipMembers=len(info),actualSourceMatchesRecomputed=len(matches),
        mainGitLfMatches=True,exactFullCrlfSeparation=True,peCount=len(bound['artifacts']),
        peFiles=[fact(r['localPath']) for r in bound['artifacts']],runtime=fact(rp),runtimeParent=fact(rop),
        harnesses=cases,totals=totals,publicDesktop=flow,cleanup='PASS',normalHelper='PIN_ONLY_NOT_FULLRUN_EXECUTED'))

checkout=read(E/'package-source-preparation-first/actual-checkout-first.json')
assert checkout['selectedCount']==len(checkout['selectedInputs'])==544
for row in checkout['selectedInputs']: exact(row)
result['checkout']=dict(original=fact(E/'package-source-preparation-first/actual-checkout-first.json'),
    selectedActualCiFilesRehashed=544,scriptActualCheckout=checkout['scriptCheckout'],
    scriptGitLfBlobSha256=checkout['scriptGitBlobContentSha256'])

mp=E/'product-msi-runtime-second/report.json'; m=read(mp)
assert fact(mp)['sha256']=='a636d1cc6a3f3f91a8c21d0aaf0dac43cbe93e856e9a66e5926af1ee3437d1f7'
assert m['status']=='PASS_PRODUCT_MSI_RUNTIME_CAPTURE_AND_EXACT_SCRATCH_CLEANUP_WIN11_ONLY'
assert m['phaseParentExit']==0 and m['sourceUnchanged'] and m['cleanupActual']['knownAbsent']
for op in m['operations']:
    assert op['actualExit'] and op['exitCode']==0 and op['reaped'] and not op['timedOut']
    exact(op['stdout']);exact(op['stderr'])
plan=read(m['config']['path']);exact(m['config']);exact(m['msi'])
binder=pathlib.Path(plan['planBinder']['path']);exact(plan['planBinder'])
runpy.run_path(str(binder))['validate_bound_plan'](plan)
phase=m['phaseResult']; assert phase['elapsedWholeMilliseconds']==3409
assert [x['name'] for x in phase['phases']]==['fresh','reapply','uninstall']
processes=[];images=set()
for p in phase['phases']:
    assert p['client']['actualExit'] and p['client']['exitCode']==0 and p['client']['pipesComplete'] and not p['client']['timedOut']
    assert p['ownerProof']['complete'] and p['ownerProof']['knownControlsReturned']
    assert p['ownerProof']['brokerEverObservedWait258']
    fs=p['observerFinal']['Processes'];assert len(fs)==4 and {x['Role'] for x in fs}=={'begin','broker','supervisor','guardian'}
    by={x['Role']:x for x in fs}
    assert by['broker']['ParentPid']==by['begin']['Pid'] and by['broker']['ParentCreationFiletime']==by['begin']['CreationFiletime']
    assert by['guardian']['ParentPid']==by['supervisor']['Pid'] and by['guardian']['ParentCreationFiletime']==by['supervisor']['CreationFiletime']
    assert by['guardian']['Transaction']==by['supervisor']['Transaction']!=0
    for f in fs:
        assert f['ActualWait']==f['ActualExitCode']==f['NativeCommandNtStatus']==f['NativeBasicNtStatus']==0
        assert f['CloseStatus']=='CHECKED_CLOSE_SUCCESS' and f['CommandStatus']=='EXACT_ORIGINAL_HANDLE_NT_CLASS60_FACT_ONLY'
        assert f['NativeCommandBufferFreeStatus']==f['NativeBasicBufferFreeStatus']=='CHECKED_LOCALFREE_SUCCESS'
        assert f['NativeCommandStatus']=='SUCCESS_VALIDATED_UTF16' and f['NativeBasicStatus']=='EXACT_ORIGINAL_HANDLE_BASIC_INFORMATION'
        processes.append(f)
    assert p['helperImageCleanup']['brokerImageKnownAbsent'] and p['helperImageCleanup']['allCapturedImagesKnownAbsent']
    for f in p['helperImageCleanup']['images']:assert f['status']=='KNOWN_ABSENT';images.add(f['path'])
for k in ('freshPresent','reapplyPresent'):
    assert phase[k]['healthyPresent'] and len(phase[k]['observations']['files']['files'])==14
assert phase['uninstallAbsent']['knownAbsent'] and phase['finallyProductState']['knownAbsent']
assert phase['uninstallCache']['allPreviouslyObservedPathsKnownAbsent']
assert phase['gateRetirementExternalReadback']['namespaceKnownAbsent'] and phase['finallyCoordination']['pendingKnownAbsent']
assert not phase['ownerUnknown'] and not phase['instrumentUnknown'] and not phase['originalBudgetExceeded']
assert phase['retainedDirectClients']==0 and len(images)==6
download=next((E/'product-msi-runtime-second/download').iterdir());inv=m['remoteInventory']
have={};dirs=[]
for q in download.rglob('*'):
    assert not q.is_symlink();rel=q.relative_to(download).as_posix()
    if q.is_dir():dirs.append(rel)
    else: x=fact(q);have[rel]=dict(path=rel,bytes=x['bytes'],sha256=x['sha256'])
assert have=={x['path']:x for x in inv['files']} and set(dirs)==set(inv['directories'])
assert len(have)==26 and read(download/'phase-runner-result.json')==phase
result['msi']=dict(original=fact(mp),parent=fact(E/'root-product-msi-operation-second.json'),
    fullLocalBinderReplayed=True,config=m['config'],msi=m['msi'],phases=phase['phases'],
    healthyFresh=phase['freshPresent'],healthyReapply=phase['reapplyPresent'],uninstalled=phase['uninstallAbsent'],
    cache=phase['uninstallCache'],gate=phase['gateRetirementExternalReadback'],
    twelveOriginalObjects=processes,sixImages=sorted(images),downloadFilesRehashed=26,
    cleanup=m['cleanupActual'],wholeMilliseconds=3409)
result['finishedUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
dest=D/'checked-originals.json';assert not dest.exists();dest.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(dict(status=result['status'],report=fact(dest))))
