"""Invoke only frozen R78 prepared static/runtime command with actual metadata."""
from pathlib import Path
import argparse,datetime,hashlib,json,subprocess,time
E=Path('/tmp/fc-round78-ci-evidence');D=E/'ci-admission-preparation-first'
def fact(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def main():
 p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');p.add_argument('--baseline',choices=['modern','win7'],required=True);p.add_argument('--stage',choices=['static','runtime'],required=True);a=p.parse_args()
 if not a.execute:print(json.dumps({'status':'NOT_RUN_PREPARATION_ONLY'}));return 0
 assert (E/'.owner').read_bytes()==b'future-classroom-owned-r78-ci-evidence/v1\n'
 name=a.baseline;kind=a.stage
 art=json.loads((E/(name+'-artifacts-final-first.json')).read_bytes())['artifacts'];assert len(art)==1;art=art[0]
 jobs=json.loads((E/(name+'-jobs-final-first.json')).read_bytes())['jobs'];assert len(jobs)==1;job=jobs[0]
 args=json.loads((D/('commands-first.json' if kind=='static' else 'runtime-commands-first.json')).read_bytes())[name]
 values={'<ACTUAL_JOB_ID>':str(job['id']),'<ACTUAL_ARTIFACT_ID>':str(art['id']),'<ACTUAL_ZIP_BYTES>':str(art['size_in_bytes']),'<ACTUAL_ZIP_SHA256>':art['digest'].removeprefix('sha256:'),'<E/actual-run-metadata.json>':str(E/(name+'-run-final-first.json')),'<E/actual-job-metadata.json>':str(E/(name+'-jobs-final-first.json')),'<E/actual-artifact-metadata.json>':str(E/(name+'-artifacts-final-first.json')),'<ACTUAL_RECEIPT_SHA256>':fact(E/(name+'-download-original-official-first.json'))['sha256'],'<ACTUAL_OPERATION_SHA256>':fact(E/(name+'-download-operation-official-first.json'))['sha256']}
 if kind=='runtime':values.update({'<ACTUAL_STATIC_AUDIT_SHA256>':fact(D/(name+'-static-audit-first.json'))['sha256'],'<ACTUAL_STATIC_OPERATION_SHA256>':fact(D/(name+'-static-operation-first.json'))['sha256']})
 cmd=[values.get(x,x) for x in args];assert not any('<' in x or '>' in x for x in cmd)
 output=E/('root-'+name+'-'+kind+'-invocation-first.json');out=output.with_suffix('.stdout.log');err=output.with_suffix('.stderr.log');assert not any(x.exists() for x in (output,out,err))
 r={'status':'RUNNING','command':cmd,'scope':'Original prepared command with actual official metadata and exact completed download/static report hashes; no extra timeout or revised producer budget','startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()};output.write_text(json.dumps(r,indent=2)+'\n');begin=time.monotonic()
 with out.open('xb') as stdout,err.open('xb') as stderr:
  child=subprocess.Popen(cmd,stdout=stdout,stderr=stderr);r['pid']=child.pid;output.write_text(json.dumps(r,indent=2)+'\n');code=child.wait()
 r.update(status='PASS_COMMAND' if code==0 else 'FAIL_COMMAND',actualExit=True,exitCode=code,elapsedSeconds=time.monotonic()-begin,stdout=fact(out),stderr=fact(err));output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ('status','exitCode','elapsedSeconds','stdout','stderr')}));print(out.read_text()[-1600:]);print(err.read_text()[-1600:]);return code
if __name__=='__main__':raise SystemExit(main())
