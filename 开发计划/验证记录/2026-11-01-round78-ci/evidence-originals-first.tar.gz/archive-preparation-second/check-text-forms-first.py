"""Finite listed 15 immutable originals only; no E inventory or archive."""
from pathlib import Path
import ast,hashlib,importlib.util,json,subprocess,sys,time
sys.dont_write_bytecode=True
E=Path('/tmp/fc-round78-ci-evidence');D=E/'archive-preparation-second';p=D/'archive-second.py'
spec=importlib.util.spec_from_file_location('r78_archive_second',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
c=json.loads((D/'text-forms-first.json').read_bytes());m.TEXT_FORMS={r['path']:r for r in c['files']};m.TEXT_DERIVED_VIEWS={r['viewPath']:r for r in c['derivedJsonViews']};rows=[];start=time.monotonic()
for row in c['files']:
 b=(E/row['path']).read_bytes();views=m.text_views(b,'source:'+row['path']);assert len(views)==3
 stats={k:0 for k in ('textViews','utf16Views','cp936Views','clixmlDecodedViews','decodedBase64Views','jsonContainers','decodedJsonStringViews')};findings=[];m.credential_scan(b,'source:'+row['path'],stats,findings);assert not findings
 rejected=0
 for label,data in [('source:unlisted-different-original.log',b),('source:'+row['path'],b+b'X')]:
  try:m.text_views(data,label)
  except AssertionError:rejected+=1
  else:raise AssertionError('ALTERED_OR_UNLISTED_FORM_NOT_REJECTED')
 rows.append(dict(path=row['path'],bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),status='PASS_THREE_COMPLETE_VIEWS_AND_CREDENTIAL_SCAN',views=[v[0] for v in views],statistics=stats,negativeWrongPathOrBytesRejected=rejected))
derived_rows=[]
for row in c['derivedJsonViews']:
 parent=json.loads((E/row['containerPath']).read_bytes());text=parent
 for key in row['jsonTrail']:text=text[key]
 raw=text.encode();views=m.text_views(raw,'source:'+row['viewPath']);assert len(views)==3
 stats={k:0 for k in ('textViews','utf16Views','cp936Views','clixmlDecodedViews','decodedBase64Views','jsonContainers','decodedJsonStringViews')};findings=[];m.credential_scan(raw,'source:'+row['viewPath'],stats,findings);assert not findings
 derived_rows.append(dict(viewPath=row['viewPath'],bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),status='PASS_EXACT_JSON_VIEW_FULL_SCAN'))
# The config itself contains only literal backslash control representations.
for q in (D/'text-forms-first.json',E/'independent-archive-review-first/review-first.json'):
 stats={k:0 for k in ('textViews','utf16Views','cp936Views','clixmlDecodedViews','decodedBase64Views','jsonContainers','decodedJsonStringViews')};findings=[];m.credential_scan(q.read_bytes(),'source:'+q.relative_to(E).as_posix(),stats,findings);assert not findings
r=subprocess.run(['python3','-B',str(p)],capture_output=True,timeout=10);assert r.returncode==0 and json.loads(r.stdout)['status']=='PREPARED_ARCHIVE_ONLY_NOT_EXECUTED' and not r.stderr
out=dict(status='PASS_AST_DEFAULT_NOT_RUN_15_RAW_AND_THREE_EXACT_JSON_NOTE_VIEWS',controller=dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()),configSha256=hashlib.sha256((D/'text-forms-first.json').read_bytes()).hexdigest(),defaultExitCode=r.returncode,defaultStdout=r.stdout.decode(),scope='Finite decoder preparation verification only; source membership/inventory, final archive gate, tar writing, cleanup, Windows and network NOT_RUN.',files=rows,derivedJsonViews=derived_rows,fullRawBytesAltered=False,currentSourceInventory='NOT_RUN',archive='NOT_RUN',elapsedSeconds=time.monotonic()-start)
(D/'preparation-validation-first.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status=out['status'],files=len(rows),negativeRejections=sum(r['negativeWrongPathOrBytesRejected'] for r in rows),controllerSha256=out['controller']['sha256'],validationSha256=hashlib.sha256((D/'preparation-validation-first.json').read_bytes()).hexdigest(),elapsedSeconds=out['elapsedSeconds'])))
