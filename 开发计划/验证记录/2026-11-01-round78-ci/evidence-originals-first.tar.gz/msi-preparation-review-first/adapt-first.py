from pathlib import Path
import hashlib,json,re
D=Path(__file__).resolve().parent
O=D/'adapted';O.mkdir(exist_ok=False)
SOURCE='261c58aca8b0f63ff2cfb4dbd5e85c0d17770005'
def read(n):return (D/n).read_text()
def put(n,s):(O/n).write_text(s)
s=read('ProcessObserver.cs').replace('FcR76ProcessObserver','FcR78ProcessObserver')
s=s.replace('public string[] Errors; public Fact[] Processes;','public string[] Errors,MetadataWarnings,CaptureWarnings; public Fact[] Processes;')
s=s.replace('public uint Pid,ParentPid;','public uint Pid,ParentPid; public uint? Transaction;')
s=s.replace('readonly string expectedHash,user,fixedFile,installer;', 'readonly List<string> metadataWarnings=new List<string>(),captureWarnings=new List<string>();\n    readonly string expectedHash,user,fixedFile,installer;')
s=s.replace('void RecordError(string s) { if(errors.Count<64) errors.Add(s); }','void RecordError(string s) { if(errors.Count<64) errors.Add(s); }\n    void MetadataWarning(string s) { if(metadataWarnings.Count<64)metadataWarnings.Add(s); }\n    void CaptureWarning(string s) { if(captureWarnings.Count<64)captureWarnings.Add(s); }')
s=s.replace('n>=1&&n<=4','n>=1&&n<=6')
s=s.replace('else if(a.Length==2&&(a[1]=="broker"||a[1]=="commit"||a[1]=="rollback"))role=a[1];','else if(a.Length==2&&a[1]=="broker")role="broker";')
s=s.replace('else if(a.Length==3&&a[2]=="guardian"&&UInt32.TryParse(a[1],NumberStyles.None,CultureInfo.InvariantCulture,out txn)&&txn!=0)role="guardian";','else if(a.Length==3&&(a[2]=="guardian"||a[2]=="supervisor")&&UInt32.TryParse(a[1],NumberStyles.None,CultureInfo.InvariantCulture,out txn)&&txn!=0){role=a[2];f.Transaction=txn;}')
s=s.replace('old.Role=="begin"&&f.Role=="broker"','((old.Role=="begin"&&f.Role=="broker")||(old.Role=="supervisor"&&f.Role=="guardian"))')
s=s.replace('f.ParentLink="HELD_ORIGINAL_BEGIN_INSTANCE";return;', 'f.ParentLink=f.Role=="broker"?"HELD_ORIGINAL_BEGIN_INSTANCE":"HELD_ORIGINAL_SUPERVISOR_INSTANCE";return;')
s=s.replace('(f.Role=="begin"||f.Role=="guardian"||f.Role=="commit"||f.Role=="rollback")','(f.Role=="begin"||f.Role=="supervisor")')
s=s.replace('RecordError("candidate_metadata:"+pid+":"+e.GetType().Name+":"+e.Message);','MetadataWarning("candidate_metadata:"+pid+":"+e.GetType().Name+":"+e.Message);')
s=s.replace('lock(sync)RecordError("capture:"+pid+":"+e.GetType().Name+":"+e.Message);','lock(sync){if(closeFault)RecordError("capture_close_fault:"+pid+":"+e.GetType().Name+":"+e.Message);else CaptureWarning("capture_not_authenticated:"+pid+":"+e.GetType().Name+":"+e.Message);}')
s=s.replace('lock(sync)RecordError("poll_candidate:"+e.GetType().Name);','lock(sync)CaptureWarning("poll_candidate_not_authenticated:"+e.GetType().Name);')
s=s.replace('r.Errors=errors.ToArray();r.Processes=facts.ToArray();','r.Errors=errors.ToArray();r.MetadataWarnings=metadataWarnings.ToArray();r.CaptureWarnings=captureWarnings.ToArray();r.Processes=facts.ToArray();')
s=s.replace('if(!closed)foreach(Fact f in facts) { Refresh(f);', '''// Relink only already captured original facts before closing any handle.
            // No late PID disappearance, WMI command guess, or replacement handle
            // can turn a missing role into known original coverage.
            if(!closed)foreach(Fact f in facts) if(f.ParentLink=="UNKNOWN") {
                try { Parent(f); }catch(Exception e){MetadataWarning("final_parent:"+f.Pid+":"+e.GetType().Name+":"+e.Message);}
            }
            if(!closed)foreach(Fact f in facts) { Refresh(f);''')
put('ProcessObserver.cs',s)
# The state observer remains independently read-only. Only source pin and one
# explicit exact-product LocalPackage query are new; no cache enumeration.
s=read('ProductState.cs').replace('FcR76ProductState','FcR78ProductState').replace('3bad94949012e840cd1dda6a73a0ea1ddb067697',SOURCE)
pos=s.index('    static Dictionary<string,object> Registration(')
s=s[:pos]+'''    public static Dictionary<string,object> ObserveLocalPackage(string product,string sid) {
        Require(GuidText(product,true),"EXACT_PRODUCT_FOR_CACHE_QUERY");
        using(var own=WindowsIdentity.GetCurrent())Require(own.User.Value==sid,"EXACT_CACHE_QUERY_USER");
        var buffer=new StringBuilder(32768);uint n=32768;
        uint code=MsiGetProductInfoExW(product,sid,2,"LocalPackage",buffer,ref n);
        string path=buffer.ToString();
        var result=D("productCode",product,"userSid",sid,"context",2,"property","LocalPackage","apiCode",code,"returnedChars",n,"path",path,"mutations",false,"scope","Exact product API query only; no Windows Installer directory enumeration");
        if(code==1605){Require(path.Length==0,"UNKNOWN_PRODUCT_NO_CACHE_PATH");result["status"]="KNOWN_PRODUCT_ABSENT_NO_CACHE_PATH";return result;}
        Require(code==0&&n<32768&&path.Length>0,"EXACT_LOCALPACKAGE_API_RESULT");
        string parent=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),"Installer");
        Require(String.Equals(Path.GetFullPath(path),path,StringComparison.OrdinalIgnoreCase)&&String.Equals(Path.GetDirectoryName(path),parent,StringComparison.OrdinalIgnoreCase)&&System.Text.RegularExpressions.Regex.IsMatch(Path.GetFileName(path),@"\\A[0-9a-f]{1,16}\\.msi\\z",System.Text.RegularExpressions.RegexOptions.IgnoreCase|System.Text.RegularExpressions.RegexOptions.CultureInvariant),"CLOSED_API_CACHE_PATH");
        using(var file=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete)) {
            Info before=FileInfo(file.SafeFileHandle);Require((before.Attributes&(Reparse|DirectoryAttribute))==0&&Length(before)>0&&Length(before)<=64*1024*1024,"BOUNDED_REGULAR_CACHE_FILE");
            using(var digest=SHA256.Create())result["sha256"]=Hex(digest.ComputeHash(file));
            Info after=FileInfo(file.SafeFileHandle);Require(before.Volume==after.Volume&&before.IndexHigh==after.IndexHigh&&before.IndexLow==after.IndexLow&&Length(before)==Length(after)&&before.Write.High==after.Write.High&&before.Write.Low==after.Write.Low,"STABLE_CACHE_READ_FACT");
            result["bytes"]=Length(before);result["volume"]=before.Volume;result["indexHigh"]=before.IndexHigh;result["indexLow"]=before.IndexLow;
        }
        result["status"]="KNOWN_PRESENT_EXACT_API_LOCALPACKAGE_READONLY";return result;
    }
''' +s[pos:]
put('ProductState.cs',s)
put('ProductState.ps1',read('ProductState.ps1').replace('FcR76ProductState','FcR78ProductState').replace('3bad94949012e840cd1dda6a73a0ea1ddb067697',SOURCE))
for n in ['GateRetirement.cs','ReadOnlyPreflightFunction.ps1']:put(n,read(n).replace('3bad94949012e840cd1dda6a73a0ea1ddb067697',SOURCE))
s=read('Invoke-ProductionMsiPhases.ps1').replace('FcR76ProcessObserver','FcR78ProcessObserver').replace('3bad94949012e840cd1dda6a73a0ea1ddb067697',SOURCE).replace('r76-production-msi','r78-production-msi')
s=s.replace('$script:retainedClients=', '$script:cachePaths=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)\n$script:retainedClients=')
s=s.replace('engineLogSupplement=\'NOT_IMPLEMENTED_BY_THIS_PREPARATION_UNKNOWN_IS_NOT_EXIT0\'',"engineLogSupplement='NOT_IMPLEMENTED_BY_THIS_PREPARATION_UNKNOWN_IS_NOT_EXIT0';helperImageCleanup='PRODUCT_AUTOMATIC_ONLY_NO_MANUAL_MSI_IMAGE_OR_CACHE_DELETION'")
start=s.index('function Owner-Proof(');end=s.index('function Invoke-Phase(',start)
s=s[:start]+'''function Owner-Proof($closed,$live){
 $returnProblems=[Collections.Generic.List[string]]::new();$coverageProblems=[Collections.Generic.List[string]]::new()
 if(-not $closed.WmiStarted -or -not $closed.Closed -or @($closed.Errors).Count-ne0){$returnProblems.Add('OBSERVER_ERROR_OR_NOT_RETURNED')}
 $facts=@($closed.Processes)
 foreach($f in $facts){
  # Metadata UNKNOWN never changes a successfully observed original object's
  # actual Wait/GetExit/Close. Full role coverage remains independently required.
  if($f.IdentityStatus-cne'ORIGINAL_QUERY_SYNC_HANDLE_EXACT_IMAGE_BYTES_USER' -or $f.Sha256-cne$script:c.embeddedHelper.sha256 -or $f.Sid-cne$script:c.expectedUserSid -or $f.ActualWait-ne0 -or $f.ActualExitCode-ne0 -or $f.ExitStatus-cne'ACTUAL_ORIGINAL_GET_EXIT_CODE' -or $f.CloseStatus-cne'CHECKED_CLOSE_SUCCESS'){$returnProblems.Add('CAPTURED_ORIGINAL_UNKNOWN_OR_NONZERO')}
  if($f.CommandStatus-cne'EXACT_CREATION_MATCHED_WMI_FACT_ONLY' -or $f.Role-ceq'UNKNOWN'){$coverageProblems.Add('CAPTURED_ORIGINAL_ROLE_METADATA_UNKNOWN')}
 }
 $byRole=@{}
 foreach($role in @('begin','broker','supervisor','guardian')){
  $same=@($facts|Where-Object{$_.Role-ceq$role})
  if($same.Count-ne1){$coverageProblems.Add('ROLE_'+$role+'_UNKNOWN_OR_NONUNIQUE')}else{$byRole[$role]=$same[0]}
 }
 if(-not$byRole.ContainsKey('broker')){$returnProblems.Add('ORIGINAL_BROKER_UNKNOWN_OR_NONUNIQUE')}
 if($byRole.ContainsKey('begin') -and $byRole.ContainsKey('broker')){
  $b=$byRole.broker;$a=$byRole.begin
  if($b.ParentLink-cne'HELD_ORIGINAL_BEGIN_INSTANCE' -or $b.ParentPid-ne$a.Pid -or $b.ParentCreationFiletime-ne$a.CreationFiletime -or $b.Image-cine$a.Image){$coverageProblems.Add('BROKER_ORIGINAL_BEGIN_LINK_OR_IMAGE_UNKNOWN')}
 }
 foreach($role in @('begin','supervisor')){if($byRole.ContainsKey($role) -and $byRole[$role].ParentLink-cne'ORIGINAL_ENGINE_INSTANCE_FACT_NOT_SESSION_ID'){$coverageProblems.Add('ROLE_'+$role+'_ENGINE_INSTANCE_UNKNOWN')}}
 if($byRole.ContainsKey('begin') -and $byRole.ContainsKey('supervisor')){
  $a=$byRole.begin;$p=$byRole.supervisor
  if($a.ParentPid-ne$p.ParentPid -or $a.ParentCreationFiletime-ne$p.ParentCreationFiletime -or $a.ParentImage-cine$p.ParentImage -or $a.ParentSid-cne$p.ParentSid){$coverageProblems.Add('ORIGINAL_ENGINE_INSTANCE_NOT_SAME')}
 }
 if($byRole.ContainsKey('supervisor') -and $byRole.ContainsKey('guardian')){
  $p=$byRole.supervisor;$g=$byRole.guardian
  if($g.ParentLink-cne'HELD_ORIGINAL_SUPERVISOR_INSTANCE' -or $g.ParentPid-ne$p.Pid -or $g.ParentCreationFiletime-ne$p.CreationFiletime -or $g.Image-cine$p.Image -or $null-eq$g.Transaction -or $g.Transaction-eq0 -or $g.Transaction-ne$p.Transaction){$coverageProblems.Add('GUARDIAN_ORIGINAL_SUPERVISOR_TRANSACTION_OR_IMAGE_UNKNOWN')}
 }
 return @{knownControlsReturned=($returnProblems.Count-eq0);complete=($returnProblems.Count-eq0 -and $coverageProblems.Count-eq0);returnProblems=@($returnProblems.ToArray());coverageProblems=@($coverageProblems.ToArray());brokerEverObservedWait258=($live.Count-gt0);metadataWarnings=@($closed.MetadataWarnings);captureWarnings=@($closed.CaptureWarnings);channel='Original held object actual return is separate from mandatory external four-role/engine/parent/transaction coverage';engineSupplement='UNKNOWN_NOT_IMPLEMENTED';productNativeAuthentication='Product-internal proof is not substituted for external observer coverage'}
}
function Observe-PhaseImages($row){
 $facts=@($row.observerFinal.Processes);$images=@($facts|Select-Object -ExpandProperty Image -Unique);$paths=@()
 foreach($image in $images){$v=Known-Path $image;$paths+=,$v}
 $broker=@($facts|Where-Object{$_.Role-ceq'broker'})
 $v=@{status='UNKNOWN';scope='Precise paths of authenticated actual helpers only; no enumeration/deletion of MSI cache or shared processes';images=$paths;brokerImage=$(if($broker.Count-eq1){$broker[0].Image}else{$null});brokerImageKnownAbsent=$false;allCapturedImagesKnownAbsent=$false;mutations=$false}
 if($broker.Count-eq1){$m=@($paths|Where-Object{$_.path-cieq$broker[0].Image});$v.brokerImageKnownAbsent=($m.Count-eq1 -and $m[0].status-ceq'KNOWN_ABSENT')}
 $v.allCapturedImagesKnownAbsent=($paths.Count-gt0 -and @($paths|Where-Object{$_.status-cne'KNOWN_ABSENT'}).Count-eq0)
 if($v.brokerImageKnownAbsent -and $v.allCapturedImagesKnownAbsent){$v.status='PASS_PRECISE_HELPER_IMAGE_AUTOMATIC_ABSENCE'}
 return $v
}
function Observe-Cache([bool]$present){
 $v=[FcR78ProductState]::ObserveLocalPackage($script:productArgument,$script:c.expectedUserSid)
 if($present){Require ($v.status-ceq'KNOWN_PRESENT_EXACT_API_LOCALPACKAGE_READONLY') 'ACTUAL_EXACT_API_CACHE_PRESENT';[void]$script:cachePaths.Add($v.path)}else{Require ($v.status-ceq'KNOWN_PRODUCT_ABSENT_NO_CACHE_PATH') 'ACTUAL_CACHE_QUERY_PRODUCT_ABSENT'}
 $old=@();foreach($p in $script:cachePaths){$old+=,(Known-Path $p)}
 return @{actualProductQuery=$v;previouslyObservedExactPaths=$old;allPreviouslyObservedPathsKnownAbsent=($script:cachePaths.Count-gt0 -and @($old|Where-Object{$_.status-cne'KNOWN_ABSENT'}).Count-eq0);mutations=$false;scope='No cache directory enumeration; no cache deletion; cache SHA is observed, not falsely equated to input MSI bytes'}
}
''' +s[end:]
s=s.replace("$row['endWholeMilliseconds']=$whole.ElapsedMilliseconds;", "$row['helperImageCleanup']=Observe-PhaseImages $row\n  $row['endWholeMilliseconds']=$whole.ElapsedMilliseconds;")
s=s.replace("function Require-Phase($row){Require-ReturnedControls $row;Require $row.ownerProof.complete 'PHASE_INDEPENDENT_ROLE_COVERAGE_UNKNOWN'}", "function Require-Phase($row){Require-ReturnedControls $row;Require $row.ownerProof.complete 'PHASE_INDEPENDENT_ROLE_COVERAGE_UNKNOWN';Require ($row.helperImageCleanup.status-ceq'PASS_PRECISE_HELPER_IMAGE_AUTOMATIC_ABSENCE') 'PRODUCT_HELPER_IMAGE_AUTOMATIC_RETIREMENT_NOT_PROVEN'}")
s=s.replace("$fresh=Invoke-Phase 'fresh' 'Fresh' 180000;Require-Phase $fresh", "$fresh=Invoke-Phase 'fresh' 'Fresh' 180000;Require-Phase $fresh\n $script:result['freshCache']=Observe-Cache $true")
s=s.replace("$reapply=Invoke-Phase 'reapply' 'Reapply' 180000;Require-Phase $reapply", "$reapply=Invoke-Phase 'reapply' 'Reapply' 180000;Require-Phase $reapply\n $script:result['reapplyCache']=Observe-Cache $true")
s=s.replace("$absent=Measure-State 'Absent';$script:result['uninstallAbsent']=$absent;Assert-State $absent 'Absent';Retire-Gate", "$absent=Measure-State 'Absent';$script:result['uninstallAbsent']=$absent;Assert-State $absent 'Absent'\n $script:result['uninstallCache']=Observe-Cache $false;Require $script:result.uninstallCache.allPreviouslyObservedPathsKnownAbsent 'EXACT_OBSERVED_CACHE_PATHS_NOT_ABSENT';Retire-Gate")
s=s.replace("PASS_THREE_PHASE_HELD_OWNERS_STATE_AND_ORIGINAL_GATE_WIN11_ONLY", "PASS_THREE_PHASE_FOUR_ROLE_AUTOMATIC_IMAGE_CLEANUP_AND_ORIGINAL_GATE_WIN11_ONLY")
# Finally original cleanup may remove the product through one real /x only when
# original captured return is known; coverage failure remains original failure.
# Cache cleanup failure is evidence, never permission to hand-delete a cache.
s=s.replace("$script:result['failureCleanupAbsent']=$after;Assert-State $after 'Absent'", "$script:result['failureCleanupAbsent']=$after;Assert-State $after 'Absent'\n    $script:result['failureCleanupCache']=Observe-Cache $false")
# No observerFinal exists if observer setup failed; record typed UNKNOWN rather
# than throw from finally and lose the native original failure receipt.
s=s.replace("$facts=@($row.observerFinal.Processes);$images=", "if(-not$row.Contains('observerFinal')){return @{status='UNKNOWN_NO_OBSERVER_FINAL';brokerImageKnownAbsent=$false;allCapturedImagesKnownAbsent=$false;images=@();mutations=$false}}\n $facts=@($row.observerFinal.Processes);$images=")
put('Invoke-ProductionMsiPhases.ps1',s)
rows=[]
for p in sorted(O.iterdir()):
 b=p.read_bytes();rows.append(dict(path=p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
(D/'adapted-sources-first.json').write_text(json.dumps(dict(status='PREPARED_FINITE_ADAPTATION_ONLY_NOT_COMPILED_OR_WINDOWS_RUN',sourceGit=SOURCE,files=rows,budgets=dict(nativeBrokerSeconds=120,phaseSeconds=150,wholeSeconds=600,outerSeconds=900),windows='NOT_RUN'),indent=2)+'\n')
print(json.dumps(rows))
