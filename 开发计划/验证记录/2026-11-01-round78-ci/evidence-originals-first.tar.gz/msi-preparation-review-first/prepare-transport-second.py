from pathlib import Path
import hashlib,json,ast
D=Path(__file__).resolve().parent;O=D/'adapted'
rows=[]
for p in sorted(O.iterdir()):
 b=p.read_bytes();rows.append(dict(path=p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
(D/'adapted-sources-second.json').write_text(json.dumps(dict(status='PREPARED_FINITE_ADAPTATION_ONLY_NOT_COMPILED_OR_WINDOWS_RUN',sourceGit='261c58aca8b0f63ff2cfb4dbd5e85c0d17770005',files=rows,budgets=dict(nativeBrokerSeconds=120,phaseSeconds=150,wholeSeconds=600,outerSeconds=900),windows='NOT_RUN'),indent=2)+'\n')
s=(D/'run-production-msi-first.py').read_text().replace('fc-round76-ci-evidence','fc-round78-ci-evidence').replace('3bad94949012e840cd1dda6a73a0ea1ddb067697','261c58aca8b0f63ff2cfb4dbd5e85c0d17770005').replace('r76-production-msi','r78-production-msi').replace('r76-ci-evidence','r78-ci-evidence').replace('R76','R78').replace('source3bad','source261c58')
a=s.index('FILES=');b=s.index('BOOT=',a)
names=['ProcessObserver.cs','GateRetirement.cs','ReadOnlyPreflightFunction.ps1','ProductState.cs','ProductState.ps1','Invoke-ProductionMsiPhases.ps1']
s=s[:a]+'FILES=[R/\'msi-preparation-review-first\'/\'adapted\'/n for n in '+repr(tuple(names))+']\nPINS='+repr([hashlib.sha256((O/n).read_bytes()).hexdigest() for n in names])+'\n'+s[b:]
s=s.replace('PASS_THREE_PHASE_HELD_OWNERS_STATE_AND_ORIGINAL_GATE_WIN11_ONLY','PASS_THREE_PHASE_FOUR_ROLE_AUTOMATIC_IMAGE_CLEANUP_AND_ORIGINAL_GATE_WIN11_ONLY')
s=s.replace("and len(phases)==3 and all(","and r.get('uninstallCache',{}).get('allPreviouslyObservedPathsKnownAbsent') is True and len(phases)==3 and all(")
s=s.replace("and x.get('ownerProof',{}).get('complete') is True for x in phases)","and x.get('ownerProof',{}).get('complete') is True and x.get('helperImageCleanup',{}).get('status')=='PASS_PRECISE_HELPER_IMAGE_AUTOMATIC_ABSENCE' and x.get('helperImageCleanup',{}).get('brokerImageKnownAbsent') is True and x.get('helperImageCleanup',{}).get('allCapturedImagesKnownAbsent') is True for x in phases)")
p=O/'run-production-msi-r78-first.py';ast.parse(s);p.write_text(s)
print(json.dumps(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),ast='PASS',windows='NOT_RUN')))
