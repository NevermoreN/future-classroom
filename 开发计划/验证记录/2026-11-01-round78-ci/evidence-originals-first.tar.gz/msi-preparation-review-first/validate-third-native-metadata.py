from pathlib import Path
import ast,hashlib,json,ctypes,runpy,subprocess,copy
D=Path(__file__).resolve().parent;B=D/'adapted-third'
def need(v,s):
 if not v:raise AssertionError(s)
def fact(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
class U(ctypes.Structure):_fields_=[('Length',ctypes.c_uint16),('MaximumLength',ctypes.c_uint16),('Buffer',ctypes.c_void_p)]
class P(ctypes.Structure):_fields_=[('ExitStatus',ctypes.c_int32),('PebBaseAddress',ctypes.c_void_p),('AffinityMask',ctypes.c_uint64),('BasePriority',ctypes.c_int32),('UniqueProcessId',ctypes.c_uint64),('InheritedFromUniqueProcessId',ctypes.c_uint64)]
layout=dict(localHostPointerBytes=ctypes.sizeof(ctypes.c_void_p),unicodeBytes=ctypes.sizeof(U),unicodeBufferOffset=U.Buffer.offset,basicBytes=ctypes.sizeof(P),basicPidOffset=P.UniqueProcessId.offset,basicParentOffset=P.InheritedFromUniqueProcessId.offset,scope='Independent local ctypes x64 layout arithmetic only, not Windows C# Marshal/runtime proof')
need([layout[k] for k in ('localHostPointerBytes','unicodeBytes','unicodeBufferOffset','basicBytes','basicPidOffset','basicParentOffset')]==[8,16,8,48,32,40],'expected native x64 ABI arithmetic')
# Independent boundary specification for the native copied-buffer decoder.
# These synthetic values never call NtQueryInformationProcess and cannot prove
# which status/buffer layout the actual Windows kernel will return.
def decode(status,returned,offset,length,maximum,raw):
 need(status==0 and 16<=returned<=65552,'status/returned')
 need(length>0 and length%2==0 and maximum%2==0 and length<=maximum and length<=65532,'unicode lengths')
 need(16<=offset<=returned and maximum<=returned-offset,'pointer/max extent')
 text=raw[:length].decode('utf-16-le','strict');need(1<=len(text)<=32766 and all(x not in text for x in ('\0','\r','\n')),'closed utf16');return text
raw='"C:\\Windows\\Installer\\MSI123.tmp" broker'.encode('utf-16-le');positive=dict(status=0,returned=16+len(raw)+2,offset=16,length=len(raw),maximum=len(raw)+2,raw=raw+b'\0\0');need(decode(**positive).endswith(' broker'),'positive local native buffer')
cases=[dict(name='exact native copy synthetic buffer',actual='ACCEPTED')]
for name,changes in [('nonzero status',dict(status=-1073741820)),('zero return',dict(returned=0)),('return exceeds allocation',dict(returned=65553)),('odd length',dict(length=len(raw)-1)),('maximum below length',dict(maximum=len(raw)-2)),('pointer into header',dict(offset=8)),('pointer beyond returned',dict(offset=100000)),('maximum outside returned',dict(returned=16+len(raw)-2)),('unpaired surrogate',dict(raw=b'\x00\xd8'+raw[2:])),('embedded null',dict(raw=b'\0\0'+raw[2:])),('embedded line break',dict(raw=b'\n\0'+raw[2:]))]:
 v=dict(positive);v.update(changes)
 try:decode(**v)
 except (AssertionError,UnicodeDecodeError):cases.append(dict(name=name,actual='REJECTED'))
 else:raise AssertionError(name)
observer=(B/'ProcessObserver.cs').read_text();phase=(B/'Invoke-ProductionMsiPhases.ps1').read_text();checks={
 'same_held_query_only':'NtQueryInformationProcess(f.Held,60' in observer and 'NtQueryInformationProcess(f.Held,0' in observer,
 'fixed_class60_single_allocation':'const int NativeCommandCapacity=65552' in observer and observer.count('NtQueryInformationProcess(f.Held,60')==1,
 'exact_status_and_retlen': 'Need(status==0,"CLASS60_NONZERO_STATUS_UNKNOWN_NO_RETRY")' in observer and 'Need(status==0&&returned==48' in observer,
 'entire_unicode_max_extent':'value.MaximumLength<=returned-offset' in observer and 'offset>=16' in observer,
 'strict_utf16': 'new UnicodeEncoding(false,false,true)' in observer,
 'checked_native_free_no_retry':'UNKNOWN_LOCALFREE_NEVER_RETRY' in observer and 'CHECKED_LOCALFREE_SUCCESS' in observer,
 'no_remote_peb_reads': 'ReadProcessMemory' not in observer and 'NtReadVirtualMemory' not in observer,
 'no_permission_increase':'const uint Access=0x101000' in observer,
 'native_caller_layout_checked':'Marshal.SizeOf(typeof(NativeUnicodeString))==16' in observer and 'Marshal.SizeOf(typeof(NativeBasicInformation))==48' in observer,
 'foreign_cli_not_requested':'if(needCommand||needParent)try{WmiFallback(f,needCommand,needParent);}' in observer,
 'real_parent_native_and_wmi_conflicts_unknown':'UNKNOWN_NATIVE_WMI_CONFLICT' in observer,
 'native_status_admission_only':'EXACT_ORIGINAL_HANDLE_NT_CLASS60_FACT_ONLY' in phase,
 'four_role_and_relationships_preserved': all(x in phase for x in ["@('begin','broker','supervisor','guardian')",'HELD_ORIGINAL_BEGIN_INSTANCE','HELD_ORIGINAL_SUPERVISOR_INSTANCE','$g.Transaction-ne$p.Transaction','$a.ParentCreationFiletime-ne$p.ParentCreationFiletime']),
 'unknown_native_stays_fallback_or_unknown':'bool needCommand=f.NativeCommandStatus!="SUCCESS_VALIDATED_UTF16"' in observer,
 'no_suspend_or_kill': all(x not in observer for x in ['SuspendThread(', 'NtSuspendProcess(', 'TerminateProcess(','.Kill(']),
 'native_instrument_scope_explicit':'WIN11_NATIVE_X64_TEST_ONLY_CLASS60_AND_PBI_NOT_PRODUCT_OR_WIN7_REQUIREMENT' in observer,
}
need(all(checks.values()),'finite source checks')
mod=runpy.run_path(str(B/'run-production-msi-r78-third.py'),run_name='third_pure_transport');need(mod['PINS']==[fact(p)['sha256'] for p in mod['FILES']],'all third sources pinned')
second=runpy.run_path(str(D/'adapted-second/run-production-msi-r78-second.py'),run_name='second_pure_transport');need(ast.dump(ast.parse(__import__('inspect').getsource(mod['phase_cleanup_admission'])))==ast.dump(ast.parse(__import__('inspect').getsource(second['phase_cleanup_admission']))),'transport cleanup admission exact AST unchanged')
commands=[]
for p in (D/'bind-production-msi-r78-third.py',B/'run-production-msi-r78-third.py'):
 ast.parse(p.read_text());r=subprocess.run(['python3',str(p)],capture_output=True,timeout=10);need(r.returncode==0 and not r.stderr,'default inert actual0');commands.append(dict(command=['python3',str(p)],actualExitCode=r.returncode,stdout=r.stdout.decode(),windows='NOT_RUN'))
previous=[]
for f in (D/'final-preparation-freeze-first.json',D/'final-preparation-freeze-second.json'):
 j=json.loads(f.read_text());need(all(fact(Path(r['path']))==r for r in j['files']),'first second all original source identities unchanged');previous.append(dict(freeze=fact(f),allOriginalsUnchanged=True))
original=D.parent/'product-msi-runtime-first/report.json';v=json.loads(original.read_text());need(v['status']=='FAIL_PRODUCT_PHASE_OR_COVERAGE_RETAINED' and v['phaseResult']['failureCode']=='PHASE_INDEPENDENT_ROLE_COVERAGE_UNKNOWN','first actual MSI finite failure preserved')
primary=[dict(url='https://learn.microsoft.com/en-us/windows/win32/api/winternl/nf-winternl-ntqueryinformationprocess',supports='Native query takes an original process handle, supplies returned byte count, and documents class0/PBI native pointer-sized layout. Microsoft marks native interfaces as internal and changeable; class60 has no Microsoft stable contract.'),dict(url='https://learn.microsoft.com/en-us/windows/win32/api/ntdef/ns-ntdef-_unicode_string',supports='Unicode descriptor has byte-count Length/MaximumLength and a PWSTR; Length excludes a terminator when one exists.'),dict(url='https://raw.githubusercontent.com/winsiderss/phnt/master/ntpsapi.h',supports='System Informer own primary header enumerates ProcessCommandLineInformation as class60 returning UNICODE_STRING; this is implementation knowledge, not formal Microsoft compatibility.'),dict(url='https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-localalloc',supports='Fixed zeroed local allocation returns a local pointer.'),dict(url='https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-localfree',supports='LocalFree reports success with a null return; failure is preserved and never retried.'),dict(url='https://learn.microsoft.com/en-us/windows/win32/api/wow64apiset/nf-wow64apiset-iswow64process2',supports='Current process architecture is checked native AMD64 before using x64 layouts; this test-only API is not introduced into product binaries.')]
(D/'primary-native-metadata-third.json').write_text(json.dumps(dict(status='PRIMARY_SOURCES_REVIEWED_NOT_RUNTIME_PROOF',sources=primary,implementationPolicy='Bounded fixed native buffers, exact same original held process identity, strict local span checks and checked frees are additional instrument policy; no source guarantees that querying a terminated process succeeds.'),indent=2)+'\n')
receipt=dict(status='PREPARED_THIRD_NATIVE_ORIGINAL_HANDLE_METADATA_ONLY_NOT_WINDOWS_VALIDATED',sourceGit='261c58aca8b0f63ff2cfb4dbd5e85c0d17770005',previous=previous,firstActualProductMsi=dict(report=fact(original),status=v['status'],failureCode=v['phaseResult']['failureCode'],reapply='NOT_REACHED',scope='Original fresh succeeds and cleanup /x succeeds; overall original finite role-coverage FAIL is preserved, not upgraded by this later instrument preparation.'),files=[fact(D/'bind-production-msi-r78-third.py'),*[fact(p) for p in sorted(B.iterdir())]],staticChecks=checks,independentSyntheticNativeBufferCases=cases,independentLocalLayoutArithmetic=layout,defaultInertCommands=commands,primarySources=fact(D/'primary-native-metadata-third.json'),powershellParse='NOT_RUN_THIRD',csharpCompile='NOT_RUN_THIRD',nativeClass60='NOT_RUN_THIRD',windows='NOT_RUN_THIRD',productFourSources='UNCHANGED',budgets=dict(brokerSeconds=120,phaseSeconds=150,wholeSeconds=600,outerSeconds=900),remaining='Root must parse/compile then perform a new original three-phase test; class60 may fail on already-exited candidates or be unsupported, which remains metadata UNKNOWN/factual WMI fallback. No synchronous OS hard-realtime claim.',entrypoints=dict(binder=str(D/'bind-production-msi-r78-third.py'),transport=str(B/'run-production-msi-r78-third.py')),finalFilesFrozen=True)
p=D/'final-preparation-freeze-third.json';need(not p.exists(),'new third freeze');p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(fact(p)))
