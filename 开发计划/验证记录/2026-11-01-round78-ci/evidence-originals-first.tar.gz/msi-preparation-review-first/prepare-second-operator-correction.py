from pathlib import Path
import hashlib,json,ast,subprocess,difflib,runpy,copy
D=Path(__file__).resolve().parent;A=D/'adapted';B=D/'adapted-second'
def need(v,s):
 if not v:raise AssertionError(s)
def fact(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
freeze=D/'final-preparation-freeze-first.json';need(fact(freeze)['sha256']=='ef2f5218c18c4be2ed58ab715736ce597afa9ba8e3f2e10b8728e0885e1bf1af','original first freeze exact')
first=json.loads(freeze.read_text());before={r['path']:fact(Path(r['path'])) for r in first['files']};need(all(before[r['path']]==r for r in first['files']),'all first originals unchanged')
need(not B.exists(),'new second destination only');B.mkdir()
names=['ProcessObserver.cs','GateRetirement.cs','ReadOnlyPreflightFunction.ps1','ProductState.cs','ProductState.ps1','Invoke-ProductionMsiPhases.ps1'];changes=[]
for n in names:
 raw=(A/n).read_bytes();fixed=raw
 if n=='Invoke-ProductionMsiPhases.ps1':
  need(raw.count(b'-cine')==3 and raw.count(b'-cieq')==1,'exact four invalid operators only')
  fixed=raw.replace(b'-cine',b'-ine').replace(b'-cieq',b'-ieq')
  need(b'-cine' not in fixed and b'-cieq' not in fixed,'no invalid compare operators')
 (B/n).write_bytes(fixed);changes.append(dict(name=n,changed=fixed!=raw,original=fact(A/n),second=fact(B/n)))
# Rebind only derived fixture namespace/entrypoints and byte pins. No change to
# role, process, parent, image, cache, timeout, or cleanup admission semantics.
binder_first=D/'bind-production-msi-r78-first.py';binder_second=D/'bind-production-msi-r78-second.py'
need(not binder_second.exists(),'new binder only')
s=binder_first.read_text();need(s.count("D/'adapted'/n")==1 and s.count("D/'adapted/run-production-msi-r78-first.py'")==1,'exact binder namespace replacements')
s=s.replace("D/'adapted'/n","D/'adapted-second'/n").replace("D/'adapted/run-production-msi-r78-first.py'","D/'adapted-second/run-production-msi-r78-second.py'")
ast.parse(s);binder_second.write_text(s)
transport_first=A/'run-production-msi-r78-first.py';transport_second=B/'run-production-msi-r78-second.py';s=transport_first.read_text()
need(s.count("/'adapted'/n")==1 and s.count('msi-preparation-review-first/bind-production-msi-r78-first.py')==1,'exact transport namespace replacements')
s=s.replace("/'adapted'/n","/'adapted-second'/n").replace('msi-preparation-review-first/bind-production-msi-r78-first.py','msi-preparation-review-first/bind-production-msi-r78-second.py')
old=hashlib.sha256(binder_first.read_bytes()).hexdigest();new=hashlib.sha256(binder_second.read_bytes()).hexdigest();need(s.count(old)==1,'one exact old binder pin');s=s.replace(old,new)
p0=s.index('PINS=');p1=s.index('\nBOOT=',p0);s=s[:p0]+'PINS='+repr([hashlib.sha256((B/n).read_bytes()).hexdigest() for n in names])+s[p1:]
ast.parse(s);transport_second.write_text(s)
for p,q,label in [(A/'Invoke-ProductionMsiPhases.ps1',B/'Invoke-ProductionMsiPhases.ps1','powershell-four-operator-only-second.diff'),(binder_first,binder_second,'binder-namespace-only-second.diff'),(transport_first,transport_second,'transport-namespace-and-pins-only-second.diff')]:
 (D/label).write_text(''.join(difflib.unified_diff(p.read_text().splitlines(True),q.read_text().splitlines(True),fromfile=str(p),tofile=str(q))))
mod=runpy.run_path(str(transport_second),run_name='r78_second_pure_validation');need(mod['PINS']==[fact(p)['sha256'] for p in mod['FILES']],'exact second fixture pins')
admit=mod['phase_cleanup_admission'];phase=dict(client=dict(started=True,actualExit=True,pipesComplete=True,exitCode=0),ownerProof=dict(complete=True),helperImageCleanup=dict(status='PASS_PRECISE_HELPER_IMAGE_AUTOMATIC_ABSENCE',brokerImageKnownAbsent=True,allCapturedImagesKnownAbsent=True))
r=dict(status='PASS_THREE_PHASE_FOUR_ROLE_AUTOMATIC_IMAGE_CLEANUP_AND_ORIGINAL_GATE_WIN11_ONLY',cleanup='PASS_FORMAL_UNINSTALL_AND_ORIGINAL_GATE_RETIRED',ownerUnknown=False,instrumentUnknown=False,retainedDirectClients=0,formalUninstallAttempted=True,originalBudgetExceeded=False,finallyProductState=dict(knownAbsent=True),finallyCoordination=dict(namespaceKnownAbsent=True,pendingKnownAbsent=True),uninstallCache=dict(allPreviouslyObservedPathsKnownAbsent=True),phases=[copy.deepcopy(phase) for _ in range(3)])
need(admit(r)=='COMPLETE_PHASE_PASS_ONLY','positive admission unchanged');cases=[dict(name='closed positive',actual=admit(r))]
for name,mut in [('broker image present',lambda x:x['phases'][0]['helperImageCleanup'].update(brokerImageKnownAbsent=False)),('another helper present',lambda x:x['phases'][1]['helperImageCleanup'].update(allCapturedImagesKnownAbsent=False)),('four-role coverage unknown',lambda x:x['phases'][0]['ownerProof'].update(complete=False)),('cache path present',lambda x:x['uninstallCache'].update(allPreviouslyObservedPathsKnownAbsent=False)),('client nonzero',lambda x:x['phases'][2]['client'].update(exitCode=1603)),('return unknown',lambda x:x.update(ownerUnknown=True)),('old R76 status',lambda x:x.update(status='PASS_THREE_PHASE_HELD_OWNERS_STATE_AND_ORIGINAL_GATE_WIN11_ONLY'))]:
 v=copy.deepcopy(r);mut(v);actual=admit(v);need(actual=='RETAIN_UNKNOWN',name);cases.append(dict(name=name,actual=actual))
commands=[]
for p in (binder_second,transport_second):
 child=subprocess.run(['python3',str(p)],capture_output=True,timeout=10);need(child.returncode==0 and not child.stderr,'inert default return');commands.append(dict(command=['python3',str(p)],actualExitCode=child.returncode,stdout=child.stdout.decode(),windows='NOT_RUN'))
need(all(fact(Path(k))==v for k,v in before.items()) and fact(freeze)['sha256']=='ef2f5218c18c4be2ed58ab715736ce597afa9ba8e3f2e10b8728e0885e1bf1af','all first sources/freeze preserved after second')
error_path=D.parent/'root-fixture-precheck-first.json';original_error=json.loads(error_path.read_text());need(original_error['status']=='FAIL_RETAIN_ORIGINALS' and original_error['native']['error']['message']=='POWERSHELL_PARSE_ERRORS','actual original parse failure retained')
report=dict(status='PREPARED_SECOND_FOUR_POWERSHELL_OPERATOR_CORRECTIONS_ONLY_NOT_WINDOWS_VALIDATED',sourceGit=first['sourceGit'],firstFreeze=fact(freeze),firstOriginalsUnchanged=True,firstActualPrecheck=dict(original=fact(error_path),status='FAIL_RETAIN_ORIGINALS',powershellParse='FAIL',csharpCompile='NOT_REACHED',msi='NOT_RUN',cleanup='ROOT_REPORTED_EXACT_OWNED_PRECHECK_ROOT_CLEANED_NOT_REQUERIED',invalidOperators=dict(cine=3,cieq=1),correctedOperators=dict(ine=3,ieq=1)),sourceChanges=changes,files=[fact(binder_second),*[fact(p) for p in sorted(B.iterdir())]],defaultInertCommands=commands,pureTransportAdmissionCases=cases,pythonAst='PASS',powershellParse='NOT_RUN_SECOND',csharpCompile='NOT_RUN_SECOND',windows='NOT_RUN_SECOND',budgets=first['budgets'],reviewScope='Only four invalid case-insensitive PowerShell compare operators changed; other five fixture files byte identical. Binder/transport namespace and hashes derived for second sources; four-role/parent/image/identity/cache/cleanup gates and budgets unchanged.',entrypoints=dict(binder=str(binder_second),transport=str(transport_second)),finalFilesFrozen=True)
output=D/'final-preparation-freeze-second.json';need(not output.exists(),'second freeze create-new');output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(fact(output)))
