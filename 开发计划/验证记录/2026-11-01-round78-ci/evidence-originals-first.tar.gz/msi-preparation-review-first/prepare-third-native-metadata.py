from pathlib import Path
import hashlib,json,ast,difflib,subprocess,runpy,copy
D=Path(__file__).resolve().parent;A=D/'adapted-second';B=D/'adapted-third'
def need(v,s):
 if not v:raise AssertionError(s)
def fact(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
F=[D/'final-preparation-freeze-first.json',D/'final-preparation-freeze-second.json'];pre=[]
for f in F:
 j=json.loads(f.read_text());need(all(fact(Path(r['path']))==r for r in j['files']),'previous frozen sources exact');pre.append(dict(freeze=fact(f),files=j['files']))
need(not B.exists(),'third create-new');B.mkdir()
for n in ('ProcessObserver.cs','GateRetirement.cs','ReadOnlyPreflightFunction.ps1','ProductState.cs','ProductState.ps1','Invoke-ProductionMsiPhases.ps1'):(B/n).write_bytes((A/n).read_bytes())
p=B/'ProcessObserver.cs';s=p.read_text()
s=s.replace('    const uint Access=0x101000;', '''    // TEST-ONLY native metadata for the authorized native x64 Windows 11
    // observer. No new API enters either normal product or Win7 target code.
    [DllImport("ntdll.dll",ExactSpelling=true)] static extern int NtQueryInformationProcess(IntPtr process,int informationClass,IntPtr data,uint bytes,out uint returnedBytes);
    [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr LocalAlloc(uint flags,UIntPtr bytes);
    [DllImport("kernel32.dll",SetLastError=true)] static extern uint GetProcessId(IntPtr process);
    [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
    [DllImport("kernel32.dll",SetLastError=true)] static extern bool IsWow64Process2(IntPtr process,out ushort processMachine,out ushort nativeMachine);
    [StructLayout(LayoutKind.Sequential)] struct NativeUnicodeString { public ushort Length,MaximumLength; public IntPtr Buffer; }
    [StructLayout(LayoutKind.Sequential)] struct NativeBasicInformation {
        public int ExitStatus;public IntPtr PebBaseAddress;public UIntPtr AffinityMask;public int BasePriority;
        public UIntPtr UniqueProcessId,InheritedFromUniqueProcessId;
    }
    const int NativeCommandCapacity=65552; // one fixed allocation: 16-byte US + bounded UTF16, no resizing/retry
    const uint Access=0x101000;''')
s=s.replace('        internal IntPtr Held;', '''        public string NativeCommandStatus,NativeCommandBufferFreeStatus,NativeBasicStatus,NativeBasicBufferFreeStatus,ParentPidSource,WmiSupplementStatus;
        public int? NativeCommandNtStatus,NativeBasicNtStatus;
        public uint? NativeCommandReturnLength,NativeBasicReturnLength,NativeBasicPid,NativeBasicParentPid;
        public ushort? NativeCommandLength,NativeCommandMaximumLength;
        public ulong? NativeCommandBufferOffset;
        public uint? AtOriginalOpenWait,AtAuthenticatedCaptureWait;
        public long ArrivalElapsedTicks,OriginalOpenElapsedTicks,AuthenticatedElapsedTicks,MetadataCompleteElapsedTicks;
        internal IntPtr Held;''')
s=s.replace('        public string Scope="ORIGINAL_HELD_PROCESS_FACTS_NOT_PRODUCT_SETTLEMENT";', '''        public string Scope="ORIGINAL_HELD_PROCESS_FACTS_NOT_PRODUCT_SETTLEMENT";
        public string NativeMetadataScope="WIN11_NATIVE_X64_TEST_ONLY_CLASS60_AND_PBI_NOT_PRODUCT_OR_WIN7_REQUIREMENT";
        public long StopwatchFrequency=Stopwatch.Frequency;public int ObserverPointerBytes=IntPtr.Size;''')
a=s.index('    // WMI CommandLine is read only AFTER');b=s.index('    void Parent(Fact f) {',a)
s=s[:a]+'''    void FreeNative(ref IntPtr allocation,string stage) {
        if(allocation==IntPtr.Zero)return;IntPtr original=allocation;allocation=IntPtr.Zero;
        if(LocalFree(original)!=IntPtr.Zero){closeFault=true;throw Error(stage+":UNKNOWN_LOCALFREE_NEVER_RETRY");}
    }
    void MetadataDeadline() { Need(clock.ElapsedMilliseconds<=limitMs,"ORIGINAL_METADATA_DEADLINE_EXPIRED"); }
    string NativeCommand(Fact f) {
        IntPtr buffer=IntPtr.Zero;f.NativeCommandStatus="UNKNOWN_NOT_COMPLETED";f.NativeCommandBufferFreeStatus="NOT_ALLOCATED";
        try {
            MetadataDeadline();Need(Creation(f.Held)==f.CreationFiletime&&GetProcessId(f.Held)==f.Pid,"SAME_ORIGINAL_COMMAND_OBJECT");
            buffer=LocalAlloc(0x40,new UIntPtr((uint)NativeCommandCapacity));if(buffer==IntPtr.Zero)throw Error("native_command_LocalAlloc");
            f.NativeCommandBufferFreeStatus="OWNED_NOT_YET_RETURNED";
            uint returned;int status=NtQueryInformationProcess(f.Held,60,buffer,NativeCommandCapacity,out returned);
            f.NativeCommandNtStatus=status;f.NativeCommandReturnLength=returned;
            Need(status==0,"CLASS60_NONZERO_STATUS_UNKNOWN_NO_RETRY");
            Need(returned>=16&&returned<=NativeCommandCapacity,"CLASS60_RETURN_LENGTH_BOUNDED");
            NativeUnicodeString value=(NativeUnicodeString)Marshal.PtrToStructure(buffer,typeof(NativeUnicodeString));
            f.NativeCommandLength=value.Length;f.NativeCommandMaximumLength=value.MaximumLength;
            Need(value.Length>0&&(value.Length&1)==0&&(value.MaximumLength&1)==0&&value.Length<=value.MaximumLength&&value.Length<=65532,"CLASS60_UNICODE_LENGTH_BOUNDED_EVEN");
            long signedBase=buffer.ToInt64(),signedPointer=value.Buffer.ToInt64();
            Need(signedBase>0&&signedPointer>=signedBase,"CLASS60_LOCAL_BUFFER_POINTER_NOT_REMOTE");
            ulong offset=(ulong)(signedPointer-signedBase);f.NativeCommandBufferOffset=offset;
            Need(offset>=16&&offset<=returned&&value.MaximumLength<=returned-offset,"CLASS60_ENTIRE_MAXIMUM_WITHIN_RETURNED_LOCAL_BUFFER");
            byte[] bytes=new byte[value.Length];Marshal.Copy(value.Buffer,bytes,0,bytes.Length);
            string command=new UnicodeEncoding(false,false,true).GetString(bytes);
            Need(command.Length>=1&&command.Length<=32766&&command.IndexOf('\\0')<0&&command.IndexOf('\\r')<0&&command.IndexOf('\\n')<0,"CLASS60_STRICT_UTF16_CLOSED_COMMAND");
            Need(Creation(f.Held)==f.CreationFiletime&&GetProcessId(f.Held)==f.Pid,"SAME_ORIGINAL_COMMAND_OBJECT_AFTER_COPY");
            MetadataDeadline();f.NativeCommandStatus="SUCCESS_VALIDATED_UTF16";return command;
        } finally {
            if(buffer!=IntPtr.Zero)try{FreeNative(ref buffer,"native_command");f.NativeCommandBufferFreeStatus="CHECKED_LOCALFREE_SUCCESS";}
            catch{f.NativeCommandBufferFreeStatus="UNKNOWN_LOCALFREE_NOT_RETRIED";throw;}
        }
    }
    void NativeParentPid(Fact f) {
        IntPtr buffer=IntPtr.Zero;f.NativeBasicStatus="UNKNOWN_NOT_COMPLETED";f.NativeBasicBufferFreeStatus="NOT_ALLOCATED";
        try {
            MetadataDeadline();Need(Creation(f.Held)==f.CreationFiletime&&GetProcessId(f.Held)==f.Pid,"SAME_ORIGINAL_BASIC_OBJECT");
            buffer=LocalAlloc(0x40,new UIntPtr(48));if(buffer==IntPtr.Zero)throw Error("native_basic_LocalAlloc");
            f.NativeBasicBufferFreeStatus="OWNED_NOT_YET_RETURNED";
            uint returned;int status=NtQueryInformationProcess(f.Held,0,buffer,48,out returned);
            f.NativeBasicNtStatus=status;f.NativeBasicReturnLength=returned;
            Need(status==0&&returned==48,"BASIC_EXACT_STATUS_AND_RETURN_LENGTH");
            NativeBasicInformation value=(NativeBasicInformation)Marshal.PtrToStructure(buffer,typeof(NativeBasicInformation));
            ulong actual=value.UniqueProcessId.ToUInt64(),parent=value.InheritedFromUniqueProcessId.ToUInt64();
            Need(actual==f.Pid&&parent>0&&parent<=UInt32.MaxValue&&parent!=actual,"BASIC_ORIGINAL_PID_AND_BOUNDED_PARENT");
            Need(Creation(f.Held)==f.CreationFiletime&&GetProcessId(f.Held)==f.Pid,"SAME_ORIGINAL_BASIC_OBJECT_AFTER_COPY");
            MetadataDeadline();f.NativeBasicPid=(uint)actual;f.NativeBasicParentPid=(uint)parent;f.ParentPid=(uint)parent;
            f.NativeBasicStatus="EXACT_ORIGINAL_HANDLE_BASIC_INFORMATION";f.ParentPidSource="ORIGINAL_HANDLE_PBI_CLASS0";
        } finally {
            if(buffer!=IntPtr.Zero)try{FreeNative(ref buffer,"native_basic");f.NativeBasicBufferFreeStatus="CHECKED_LOCALFREE_SUCCESS";}
            catch{f.NativeBasicBufferFreeStatus="UNKNOWN_LOCALFREE_NOT_RETRIED";throw;}
        }
    }
    void ApplyCommand(Fact f,string command,string source) {
        Need(command.Length<=32768,"bounded_original_command");string[] a=Argv(command);
        Need(String.Equals(a[0],f.Image,StringComparison.OrdinalIgnoreCase),"original_argv0_image");
        string role="UNKNOWN";uint txn;
        if(a.Length==3&&a[1]=="begin"&&String.Equals(a[2],fixedFile,StringComparison.OrdinalIgnoreCase))role="begin";
        else if(a.Length==2&&a[1]=="broker")role="broker";
        else if(a.Length==3&&(a[2]=="guardian"||a[2]=="supervisor")&&UInt32.TryParse(a[1],NumberStyles.None,CultureInfo.InvariantCulture,out txn)&&txn!=0){role=a[2];f.Transaction=txn;}
        f.Role=role;f.ExactCandidateArgv=a;f.CommandStatus=source;
    }
    // WMI is a real creation-matched fallback only after authentication and a
    // bounded original-handle native attempt. Never read an engine's CLI.
    static ManagementObjectCollection GetRows(ManagementObjectSearcher q) { q.Options.Timeout=TimeSpan.FromSeconds(2);return q.Get(); }
    void WmiFallback(Fact f,bool needCommand,bool needParent) {
        f.WmiSupplementStatus="UNKNOWN_NO_CREATION_MATCHED_WMI_INSTANCE";
        string columns=needCommand?"ProcessId,ParentProcessId,CreationDate,CommandLine":"ProcessId,ParentProcessId,CreationDate";
        MetadataDeadline();
        using(ManagementObjectSearcher q=new ManagementObjectSearcher("SELECT "+columns+" FROM Win32_Process WHERE ProcessId="+f.Pid.ToString(CultureInfo.InvariantCulture)))
        using(ManagementObjectCollection rows=GetRows(q)) {
            foreach(ManagementObject m in rows) using(m) {
                string d=m["CreationDate"] as string;if(d==null)continue;
                long c=ManagementDateTimeConverter.ToDateTime(d).ToUniversalTime().ToFileTimeUtc();if(Math.Abs(c-f.CreationFiletime)>9)continue;
                MetadataDeadline();uint parent=Convert.ToUInt32(m["ParentProcessId"],CultureInfo.InvariantCulture);
                Need(Creation(f.Held)==f.CreationFiletime&&GetProcessId(f.Held)==f.Pid,"SAME_ORIGINAL_WMI_FALLBACK_OBJECT");
                if(f.ParentPid!=0&&f.ParentPid!=parent){f.ParentPid=0;f.ParentPidSource="UNKNOWN_NATIVE_WMI_CONFLICT";f.Role="UNKNOWN";f.CommandStatus="UNKNOWN_METADATA_CONFLICT";throw new InvalidOperationException("NATIVE_WMI_PARENT_CONFLICT");}
                if(needParent){Need(parent>0&&parent!=f.Pid,"WMI_BOUNDED_PARENT");f.ParentPid=parent;f.ParentPidSource="CREATION_MATCHED_WMI_PARENT_FACT_ONLY";}
                if(needCommand){string cmd=m["CommandLine"] as string;if(cmd==null)continue;ApplyCommand(f,cmd,"EXACT_CREATION_MATCHED_WMI_FACT_ONLY");}
                f.WmiSupplementStatus="ACTUAL_CREATION_MATCHED_WMI_FALLBACK_FACT_ONLY";break;
            }
        }
    }
    void Command(Fact f) {
        f.CommandStatus="UNKNOWN_NO_ORIGINAL_COMMAND";f.Role="UNKNOWN";f.ParentPidSource="UNKNOWN";
        f.WmiSupplementStatus="NOT_REQUESTED_NATIVE_COMMAND_AND_PARENT_COMPLETE";
        try {string command=NativeCommand(f);ApplyCommand(f,command,"EXACT_ORIGINAL_HANDLE_NT_CLASS60_FACT_ONLY");}
        catch(Exception e){MetadataWarning("native_command:"+f.Pid+":"+e.GetType().Name+":"+e.Message);}
        if(closeFault)return;
        try {NativeParentPid(f);}catch(Exception e){MetadataWarning("native_basic:"+f.Pid+":"+e.GetType().Name+":"+e.Message);}
        if(closeFault)return;
        // Valid native bytes with an invalid/unknown argv never grant authority
        // for a different WMI argv. That candidate's role remains UNKNOWN.
        bool needCommand=f.NativeCommandStatus!="SUCCESS_VALIDATED_UTF16";
        bool needParent=f.ParentPid==0;
        if(needCommand||needParent)try{WmiFallback(f,needCommand,needParent);}
        catch(Exception e){MetadataWarning("wmi_fallback:"+f.Pid+":"+e.GetType().Name+":"+e.Message);}
        f.MetadataCompleteElapsedTicks=clock.ElapsedTicks;
    }
''' +s[b:]
s=s.replace('lock(lifetime) { if(stopping||closed)return;activeCaptures++; }','long arrivalTicks=clock.ElapsedTicks;\n        lock(lifetime) { if(stopping||closed)return;activeCaptures++; }')
s=s.replace('h=OpenProcess(Access,false,pid);if(h==IntPtr.Zero)return;\n            lock(sync)', 'h=OpenProcess(Access,false,pid);if(h==IntPtr.Zero)return;\n            long openTicks=clock.ElapsedTicks;uint initialWait=WaitForSingleObject(h,0);\n            lock(sync)')
s=s.replace('f.Held=h;h=IntPtr.Zero;facts.Add(f);','f.ArrivalElapsedTicks=arrivalTicks;f.OriginalOpenElapsedTicks=openTicks;f.AtOriginalOpenWait=initialWait;f.AtAuthenticatedCaptureWait=WaitForSingleObject(h,0);f.AuthenticatedElapsedTicks=clock.ElapsedTicks;\n                f.Held=h;h=IntPtr.Zero;facts.Add(f);')
needle='        Need(Regex.IsMatch(embeddedImageSha256??"",@"\\A[0-9a-f]{64}\\z")'
need(s.count(needle)==1,'constructor needle')
s=s.replace(needle,'''        ushort ownMachine,nativeMachine;
        Need(IntPtr.Size==8&&Environment.Is64BitProcess&&IsWow64Process2(GetCurrentProcess(),out ownMachine,out nativeMachine)&&ownMachine==0&&nativeMachine==0x8664,"WIN11_TEST_OBSERVER_NATIVE_AMD64_CALLER_ONLY");
        Need(Marshal.SizeOf(typeof(NativeUnicodeString))==16&&Marshal.OffsetOf(typeof(NativeUnicodeString),"Buffer").ToInt32()==8&&Marshal.SizeOf(typeof(NativeBasicInformation))==48&&Marshal.OffsetOf(typeof(NativeBasicInformation),"UniqueProcessId").ToInt32()==32&&Marshal.OffsetOf(typeof(NativeBasicInformation),"InheritedFromUniqueProcessId").ToInt32()==40,"CHECKED_NATIVE_X64_QUERY_LAYOUTS");
''' +needle)
p.write_text(s)
p=B/'Invoke-ProductionMsiPhases.ps1';s=p.read_text();needle="$f.CommandStatus-cne'EXACT_CREATION_MATCHED_WMI_FACT_ONLY' -or $f.Role-ceq'UNKNOWN'";need(s.count(needle)==1,'single command status admission')
s=s.replace(needle,"$f.CommandStatus-cnotin@('EXACT_CREATION_MATCHED_WMI_FACT_ONLY','EXACT_ORIGINAL_HANDLE_NT_CLASS60_FACT_ONLY') -or $f.Role-ceq'UNKNOWN'")
p.write_text(s)
# Namespace and actual-byte pin derivatives; all admission semantics unchanged.
bf=D/'bind-production-msi-r78-second.py';bn=D/'bind-production-msi-r78-third.py';need(not bn.exists(),'new third binder')
s=bf.read_text().replace("D/'adapted-second'/n","D/'adapted-third'/n").replace("D/'adapted-second/run-production-msi-r78-second.py'","D/'adapted-third/run-production-msi-r78-third.py'");ast.parse(s);bn.write_text(s)
tf=A/'run-production-msi-r78-second.py';tn=B/'run-production-msi-r78-third.py';s=tf.read_text().replace("/'adapted-second'/n","/'adapted-third'/n").replace('msi-preparation-review-first/bind-production-msi-r78-second.py','msi-preparation-review-first/bind-production-msi-r78-third.py')
old=fact(bf)['sha256'];need(s.count(old)==1,'one second binder pin');s=s.replace(old,fact(bn)['sha256'])
names=['ProcessObserver.cs','GateRetirement.cs','ReadOnlyPreflightFunction.ps1','ProductState.cs','ProductState.ps1','Invoke-ProductionMsiPhases.ps1'];p0=s.index('PINS=');p1=s.index('\nBOOT=',p0);s=s[:p0]+'PINS='+repr([fact(B/n)['sha256'] for n in names])+s[p1:];ast.parse(s);tn.write_text(s)
for name in names:
 (D/('third-'+name+'.diff')).write_text(''.join(difflib.unified_diff((A/name).read_text().splitlines(True),(B/name).read_text().splitlines(True),fromfile='second/'+name,tofile='third/'+name)))
for item in pre:need(fact(Path(item['freeze']['path']))==item['freeze'] and all(fact(Path(r['path']))==r for r in item['files']),'all previous originals retained')
print(json.dumps(dict(status='THIRD_PREPARED_NOT_COMPILED_OR_EXECUTED',files=[fact(bn),*[fact(p) for p in sorted(B.iterdir())]])))
