from pathlib import Path
import ast,hashlib,json,copy,runpy,subprocess,difflib,tarfile
D=Path(__file__).resolve().parent;A=D/'adapted';R=Path('/workspace/共享/Eliora/未来教室计划')
def need(v,s):
 if not v:raise AssertionError(s)
def fact(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
source=subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip();need(source=='261c58aca8b0f63ff2cfb4dbd5e85c0d17770005','source frozen')
names=['ProcessObserver.cs','GateRetirement.cs','ReadOnlyPreflightFunction.ps1','ProductState.cs','ProductState.ps1','Invoke-ProductionMsiPhases.ps1']
for n in names:
 old=(D/n).read_text().splitlines(True);new=(A/n).read_text().splitlines(True)
 (D/(n+'.diff')).write_text(''.join(difflib.unified_diff(old,new,fromfile='R76-original/'+n,tofile='R78-adapted/'+n)))
observer=(A/'ProcessObserver.cs').read_text();phase=(A/'Invoke-ProductionMsiPhases.ps1').read_text();state=(A/'ProductState.cs').read_text()
checks={
 'all_four_unique_roles':"@('begin','broker','supervisor','guardian')" in phase,
 'original_supervisor_parent': 'HELD_ORIGINAL_SUPERVISOR_INSTANCE' in observer and 'HELD_ORIGINAL_SUPERVISOR_INSTANCE' in phase,
 'transaction_binding': '$g.Transaction-ne$p.Transaction' in phase,
 'same_original_engine': '$a.ParentCreationFiletime-ne$p.ParentCreationFiletime' in phase,
 'argv_bounded_six_closed_roles': 'n>=1&&n<=6' in observer and 'a.Length==3&&(a[2]=="guardian"||a[2]=="supervisor")' in observer,
 'sampling_warnings_not_return_errors': 'capture_not_authenticated:' in observer and 'MetadataWarning("candidate_metadata:' in observer,
 'hard_close_fault_still_error': 'if(closeFault)RecordError("CHECKED_NATIVE_CLOSE_OR_FREE_FAILED")' in observer,
 'broker_precise_absence_required': "Require ($row.helperImageCleanup.status-ceq'PASS_PRECISE_HELPER_IMAGE_AUTOMATIC_ABSENCE')" in phase,
 'cache_exact_api_only': '"LocalPackage"' in state and 'MsiGetProductInfoExW(product,sid,2' in state,
 'cache_no_reparse_open': 'using(var handle=Open(path,false)) using(var file=new FileStream(handle,FileAccess.Read))' in state,
 'no_explicit_cache_delete_in_state_or_observer': all(x not in observer+state for x in ['File.Delete(','Directory.Delete(','TerminateProcess(','Kill(']),
 'native_budget_120_preserved': 'nativeBrokerOriginalSeconds=120' in phase and 'productionBrokerOriginalSeconds-eq120' in phase,
 'finite_phase_150_whole_600_preserved': '600000' in phase and '150000' in phase,
 'post_settlement_cleanup_qualified': 'does not infer retained Pending or rollback' in phase,
}
need(all(checks.values()),'finite static checks')
mod=runpy.run_path(str(A/'run-production-msi-r78-first.py'),run_name='finite_pure_validation');admit=mod['phase_cleanup_admission'];need([mod['fact'](p)['sha256'] for p in mod['FILES']]==mod['PINS'],'actual six frozen source pins')
phase_ok=dict(client=dict(started=True,actualExit=True,pipesComplete=True,exitCode=0),ownerProof=dict(complete=True),helperImageCleanup=dict(status='PASS_PRECISE_HELPER_IMAGE_AUTOMATIC_ABSENCE',brokerImageKnownAbsent=True,allCapturedImagesKnownAbsent=True))
positive=dict(status='PASS_THREE_PHASE_FOUR_ROLE_AUTOMATIC_IMAGE_CLEANUP_AND_ORIGINAL_GATE_WIN11_ONLY',cleanup='PASS_FORMAL_UNINSTALL_AND_ORIGINAL_GATE_RETIRED',ownerUnknown=False,instrumentUnknown=False,retainedDirectClients=0,formalUninstallAttempted=True,originalBudgetExceeded=False,finallyProductState=dict(knownAbsent=True),finallyCoordination=dict(namespaceKnownAbsent=True,pendingKnownAbsent=True),uninstallCache=dict(allPreviouslyObservedPathsKnownAbsent=True),phases=[copy.deepcopy(phase_ok) for _ in range(3)])
need(admit(positive)=='COMPLETE_PHASE_PASS_ONLY','positive frozen transport admission')
tests=[dict(name='all four-role original returns and automatic exact image/cache absence',actual=admit(positive))]
for name,mut in [
 ('broker image still present',lambda x:x['phases'][0]['helperImageCleanup'].update(brokerImageKnownAbsent=False)),
 ('captured helper remains',lambda x:x['phases'][1]['helperImageCleanup'].update(allCapturedImagesKnownAbsent=False)),
 ('four-role coverage UNKNOWN',lambda x:x['phases'][0]['ownerProof'].update(complete=False)),
 ('cache exact path remains',lambda x:x['uninstallCache'].update(allPreviouslyObservedPathsKnownAbsent=False)),
 ('original client nonzero',lambda x:x['phases'][2]['client'].update(exitCode=1603)),
 ('native return unknown',lambda x:x.update(ownerUnknown=True)),
 ('old R76 status',lambda x:x.update(status='PASS_THREE_PHASE_HELD_OWNERS_STATE_AND_ORIGINAL_GATE_WIN11_ONLY')),
]:
 case=copy.deepcopy(positive);mut(case);value=admit(case);need(value=='RETAIN_UNKNOWN',name);tests.append(dict(name=name,actual=value))
ast.parse((A/'run-production-msi-r78-first.py').read_text());ast.parse(Path(__file__).read_text())
original_names=['b5-plan-binding-first/prepare-production-msi-b5-first.py','msi-runtime-orchestrator-preparation-first/Invoke-ProductionMsiPhases.ps1','production-msi-preparation-first/ProcessObserver.cs','production-msi-transport-preparation-first/run-production-msi-first.py','production-msi-preparation-first/GateRetirement.cs','production-msi-preparation-first/ReadOnlyPreflightFunction.ps1','msi-state-preparation-third/ProductState.cs','msi-state-preparation-third/ProductState.ps1']
originals=[]
with tarfile.open(R/'开发计划/验证记录/2026-11-01-round76-ci/evidence-originals-first.tar.gz','r:gz') as t:
 for name in original_names:
  b=t.extractfile(name).read();need(b==(D/Path(name).name).read_bytes(),'exact extracted original');originals.append(dict(member=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
report=dict(status='PASS_FINITE_STATIC_AND_PURE_PREPARATION_NOT_CSHARP_PS_COMPILE_OR_MSI_RUNTIME',sourceGit=source,originals=originals,adapted=[fact(p) for p in sorted(A.iterdir())],staticChecks=checks,pureTransportAdmissionCases=tests,budget=dict(nativeBrokerSeconds=120,phaseSeconds=150,wholeSeconds=600,outerSeconds=900),windows='NOT_RUN',csharpCompile='NOT_RUN',powershellParse='NOT_RUN',rootMustReviewBeforeExecution=['Parse PS5.1 and compile C# in owned instrument temp before any MSI; no main source changes in this preparation','Bind new accepted R78 MSVC CI helper/package overlay SHA/manifest and new nonce via independent exact current-source config binder','Original R76 B5 binder remains original only; do not execute its old source-3bad/old-root closure','A missing four-role external proof remains UNKNOWN; no command-line guessing/late PID disappearance/native self-authentication substitution','A post-broker-exit supervisor failure is cleanup failure; do not claim original Pending retained or product rolled back'])
(D/'validation-first.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],cases=len(tests),files=len(report['adapted']),report=fact(D/'validation-first.json'))))
