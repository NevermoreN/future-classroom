from pathlib import Path
import ast
D=Path('/tmp/fc-round78-ci-evidence/archive-preparation-first')
s=(D/'original-r76-archive-evidence-packed-second.py').read_text();tree=ast.parse(s)
# Reuse reviewed R76 byte/PE/magic/secret patterns and strict text decoder as the
# derivation baseline, not its R75/B5 runtime gates or its fixed old run hashes.
keep={'need','sha','write_new','as_json','valid_pe','binary_magic'}
parts=[]
for node in tree.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PATTERNS' for t in node.targets):parts.append(ast.get_source_segment(s,node))
 if isinstance(node,ast.FunctionDef) and node.name in keep:parts.append(ast.get_source_segment(s,node))
(D/'r76_reused_helpers.inc').write_text('\n\n'.join(parts)+'\n')
