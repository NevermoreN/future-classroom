"""Finite in-memory decoder tests only; never inventory the owned source."""
from pathlib import Path
import base64,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True
D=Path('/tmp/fc-round78-ci-evidence/archive-preparation-first')
spec=importlib.util.spec_from_file_location('r78_archive_prepared',D/'archive-first.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
secret='gh'+'p_'+'A'*32
rows=[]
def scan_case(name,data,want_finding=False,want_error=False):
 stats={k:0 for k in ('textViews','utf16Views','cp936Views','clixmlDecodedViews','decodedBase64Views','jsonContainers','decodedJsonStringViews')};findings=[];error=False
 try:m.credential_scan(data,'synthetic-'+name,stats,findings)
 except AssertionError:error=True
 assert error==want_error and (bool(findings)==want_finding if not error else True),name
 rows.append(dict(name=name,status='PASS',expectedRejected=want_error,expectedCredentialFound=want_finding,actualRejected=error,actualFindingCount=len(findings),statistics=stats))
scan_case('ordinary-clean-utf8','纯文本'.encode())
scan_case('utf16-detected',secret.encode('utf-16'),True)
scan_case('cp936-detected',('中文'+secret).encode('cp936'),True)
escaped='_x0067_'+'_x0068_'+'p_'+'A'*32
xml='#< CLIXML\r\n<Objs xmlns="http://schemas.microsoft.com/powershell/2004/04"><S>'+escaped+'</S></Objs>'
scan_case('parsed-clixml-escaped-detected',xml.encode(),True)
inner=json.dumps({'stdoutBase64':base64.b64encode(secret.encode('utf-16')).decode()}).encode();outer=json.dumps({'base64':base64.b64encode(inner).decode()}).encode()
scan_case('nested-json-base64-utf16-detected',outer,True)
scan_case('declared-binary-rejected',json.dumps({'base64':base64.b64encode(b'PK\x03\x04').decode()}).encode(),want_error=True)
scan_case('unknown-control-binary-rejected',b'\x01\x02',want_error=True)
report=dict(status='PASS_SEVEN_PURE_IN_MEMORY_DECODER_CASES_ONLY',controllerSha256=hashlib.sha256((D/'archive-first.py').read_bytes()).hexdigest(),sourceInventory='NOT_RUN',archive='NOT_RUN',cases=rows)
(D/'pure-decoder-checks-first.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],cases=len(rows))))
