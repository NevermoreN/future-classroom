"""R78 runtime-input bridge; reuses frozen static gate, never executes Windows."""
from pathlib import Path
import hashlib,json,runpy,subprocess,sys
sys.dont_write_bytecode=True
E=Path(__file__).resolve().parent.parent
STATIC_GATE=Path(__file__).resolve().parent/'ci-inputs-first.py'
assert hashlib.sha256(STATIC_GATE.read_bytes()).hexdigest()=='7e4cf2ca04d1f47ed94bf153437297d6aa6eaa4354fc5c157f493f0482db1112'
g=runpy.run_path(str(STATIC_GATE))
for name in ('need','fact','exact','read','scoped','add_inputs','terminal_download','audit_command','Waiting','Invalid','AUDITOR','AUDITOR_SHA','CONFIG','REPO'):
 globals()[name]=g[name]
BROKER='crates/fc-windows/src/installer_lifecycle/native/broker.rs'
BROKER_SHA='c0ab9c5cfe7be2c433dce7ae2fca0471883a9fd58c925db4417d888cdba1b5cb'
def sha(data):return hashlib.sha256(data).hexdigest()
def runtime_inputs(a):
    bound=terminal_download(a);audit=read(a.static_audit);op=read(a.static_operation)
    need(fact(a.static_audit)['sha256']==a.static_audit_sha256 and fact(a.static_operation)['sha256']==a.static_operation_sha256,'EXPLICIT_STATIC_ORIGINAL_IDENTITIES')
    need(audit.get('schema')=='future-classroom.ci-independent-artifact/v2' and audit.get('runtime')=='NOT_RUN' and audit.get('status')=='PASS_STATIC_ONLY_RUNTIME_NOT_RUN' and audit.get('sourceSha')==a.source_sha and audit.get('baseline')==CONFIG[a.baseline]['baseline'] and (audit.get('runId'),audit.get('jobId'),audit.get('artifactId'))==(a.run_id,a.job_id,a.artifact_id) and audit.get('helper',{}).get('sha256')==AUDITOR_SHA,'ACTUAL_SECOND_AUDITOR_EXACT_PASS')
    need(len(audit.get('phases',[]))==6 and all(v.get('status')=='PASS' for v in audit['phases']) and audit['zip']==bound['zip'],'ALL_STATIC_PHASES_WHOLE_ZIP_IDENTITY')
    need(op.get('status')=='PASS_STATIC_AUDITOR_ACTUAL_EXIT0' and op.get('exitCode')==0 and op.get('actualExit') is True and op.get('command')==audit_command(a) and op.get('actualReport')==fact(a.static_audit),'STATIC_PARENT_ACTUAL_RETURNED')
    exact(op['stdout']);exact(op['stderr'])
    rows=audit['executables'];tests=[r for r in rows if r['producer']['role']=='tests'];normals={r['producer']['target']:r for r in rows if r['producer']['role']=='product'}
    expected_targets=audit['testTargetInventory'];expected_count=len(expected_targets)
    need(expected_count==22 and len(rows)==expected_count+2 and len(tests)==expected_count and len(normals)==2 and set(normals)=={'fc-bootstrap','fc-installer-lifecycle'} and audit['counts']['executables']==len(rows) and audit['counts']['tests']==expected_count and audit['counts']['product']==2 and audit['counts']['metadataExpectedTests']==expected_count,'COMPLETE_SOURCE_DERIVED_TARGET_LEDGER_22TESTS_TWO_GUI')
    need(len({Path(r['localPath']).name for r in rows})==24 and len({r['localPath'] for r in rows})==24,'UNIQUE24_PE_NAMES_AND_PATHS')
    for row in rows:
        producer=row['producer'];f=fact(row['localPath']);need(f['bytes']==producer['bytes'] and f['sha256']==producer['sha256'],'EVERY_ACTUAL24_PE_REOPENED')
        need(row['peHeader']['subsystem']==(3 if producer['role']=='tests' else 2) and producer['cargo_profile_test'] is (producer['role']=='tests'),'ROLE_BOUND_ACTUAL_GUI_CUI_PROFILE')
        exact(row['rawInspection'])
    need(audit['normalExecutables']==normals and audit['normalExecutable']==normals['fc-bootstrap'] and audit['lifecycleExecutable']==normals['fc-installer-lifecycle'],'CLOSED_GUI_NORMAL_ALIASES')
    metadata=exact(audit['testMetadata']);cargo=[]
    for line in Path(metadata['path']).read_bytes().splitlines():
        v=json.loads(line)
        if v.get('reason')=='compiler-artifact' and v.get('profile',{}).get('test') is True and v.get('executable'):cargo.append(Path(v['executable']).resolve())
    need(len(cargo)==len(set(cargo))==expected_count and set(cargo)=={Path(r['localPath']).resolve() for r in tests},'EXACT_SOURCE_DERIVED_CARGO_JSON_TEST_METADATA')
    parsed=[json.loads(line) for line in Path(metadata['path']).read_bytes().splitlines()]
    target_keys={(r['packageId'],r['target'],tuple(r['kinds'])) for r in expected_targets}
    actual_keys={(r['package_id'],r['target']['name'],tuple(r['target']['kind'])) for r in parsed}
    need(len(target_keys)==len(actual_keys)==expected_count and target_keys==actual_keys,'EACH_SOURCE_BOUND_CARGO_TARGET_IDENTITY_EXACT')
    native=[r for r in tests if r['producer']['package']=='fc-windows' and r['producer']['target']=='fc_windows' and r['producer']['kinds']==['lib']];need(len(native)==1,'EXACT_SOURCE_BOUND_MSVC_NATIVE_TEST_TARGET')
    blob=subprocess.check_output(['git','show',a.source_sha+':'+BROKER],cwd=REPO);need(sha(blob)==BROKER_SHA and (REPO/BROKER).read_bytes()==blob,'SAME_PINNED_CHILD_FIXTURE_SOURCE_AT_ACTUAL_CI_SOURCE')
    sources=[r for r in audit['sourceMatches'] if r['path']==BROKER];need(len(sources)==1,'STATIC_SOURCE_MATCH_FOR_CHILD_FIXTURE');s=sources[0]
    checkout=blob if s['checkoutMatch']=='EXACT_GIT_BLOB' else blob.replace(b'\n',b'\r\n') if s['checkoutMatch']=='EXACT_FULL_LF_TO_CRLF' else None
    need(checkout is not None and sha(checkout)==s['sha256'] and len(checkout)==s['bytes'],'EXACT_CI_CHILD_SOURCE_CHECKOUT_BYTES')
    return dict(bound=bound,audit=audit,artifacts=rows,tests=tests,app=normals['fc-bootstrap'],helper=normals['fc-installer-lifecycle'],metadata=metadata,native=native[0],childSource=dict(path=BROKER,gitSourceSha256=sha(blob),ciCheckout=s))
