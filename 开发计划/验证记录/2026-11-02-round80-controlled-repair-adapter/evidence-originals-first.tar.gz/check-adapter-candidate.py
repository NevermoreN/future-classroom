"""Root-run local compiler check; source inventory must already be frozen."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import signal
import subprocess
import time

R = Path('/tmp/fc-round80-controlled-repair')
W = R / 'checkout-52d6392-first'


def facts():
    paths = sorted({*W.glob('crates/**/*.rs'), *W.glob('crates/**/Cargo.toml'),
                    W / 'Cargo.toml', W / 'Cargo.lock',
                    *W.glob('.cargo/*'), *W.glob('rust-toolchain*')})
    return [{'path': str(p.relative_to(W)), 'bytes': p.stat().st_size,
             'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
            for p in paths if p.is_file() and not p.is_symlink()]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=['build', 'clippy'], required=True)
    parser.add_argument('--inventory', type=Path, required=True)
    parser.add_argument('--inventory-sha256', required=True)
    parser.add_argument('--output-name', required=True)
    args = parser.parse_args()
    assert (R / '.owner').read_bytes() == b'future-classroom-owned-r80-controlled-repair/v1\n'
    assert args.output_name.startswith('adapter-') and '/' not in args.output_name
    output = R / args.output_name
    assert not output.exists()
    raw = args.inventory.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == args.inventory_sha256
    frozen = json.loads(raw)
    before = facts()
    assert before == frozen['sources']
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
    assert head == frozen['sourceBase']
    command = ['cargo', 'test' if args.mode == 'build' else 'clippy',
               '--release', '--offline', '--locked', '-p', 'fc-windows', '--all-targets',
               '--target', 'i686-pc-windows-gnu', '--target-dir', str(R / 'target-first')]
    if args.mode == 'build':
        command += ['--no-run']
    command += ['--message-format=json-render-diagnostics']
    if args.mode == 'clippy':
        command += ['--', '-D', 'warnings']
    output.mkdir()
    env = os.environ.copy()
    env['CARGO_BUILD_JOBS'] = '2'
    start = time.monotonic()
    process = subprocess.Popen(command, cwd=W, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, start_new_session=True)
    expired = False
    try:
        stdout, stderr = process.communicate(timeout=900)
    except subprocess.TimeoutExpired:
        expired = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            stdout, stderr = process.communicate(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            stdout, stderr = process.communicate()
    (output / 'cargo.stdout.jsonl').write_bytes(stdout)
    (output / 'cargo.stderr.log').write_bytes(stderr)
    after = facts()
    outputs = []
    for line in stdout.splitlines():
        try:
            item = json.loads(line)
        except (ValueError, UnicodeDecodeError):
            continue
        if item.get('reason') == 'compiler-artifact' and item.get('executable'):
            path = Path(item['executable'])
            data = path.read_bytes()
            outputs.append({'path': str(path), 'bytes': len(data),
                            'sha256': hashlib.sha256(data).hexdigest(),
                            'test': item['profile']['test'], 'target': item['target']})
    passed = process.returncode == 0 and not expired and before == after
    report = {'status': 'PASS_LOCAL_COMPILER_CHECK_ONLY' if passed else 'FAIL',
              'mode': args.mode, 'actualExit': process.returncode,
              'originalParentReaped': process.poll() is not None,
              'seconds': time.monotonic() - start, 'budgetSeconds': 900,
              'budgetExceeded': expired, 'argv': command,
              'sourceBase': head, 'frozenInventorySha256': args.inventory_sha256,
              'sourcesBefore': before, 'sourcesAfter': after,
              'sourceUnchanged': before == after, 'outputs': outputs,
              'runtime': 'NOT_RUN', 'productionAdmission': False}
    (output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ['status', 'mode', 'actualExit', 'seconds',
                                           'sourceUnchanged']}))
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
