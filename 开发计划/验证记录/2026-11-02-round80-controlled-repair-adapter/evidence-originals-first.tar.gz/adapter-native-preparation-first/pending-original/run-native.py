"""Root-owned finite candidate native tests. Default inert; retain any unknown."""
import argparse, base64, hashlib, json, os, re, runpy, secrets, shutil, struct, subprocess, time
from pathlib import Path
E=Path('/tmp/fc-round80-controlled-repair')
FINAL_PRODUCER_READY=False  # Root is correcting source; no stale build may execute.
BASE=E/'native-reference-first/run-negative-msi-r79-third.py'
assert hashlib.sha256(BASE.read_bytes()).hexdigest()=='da74f0058deac86507b712075904556780be6b262b18acb82415da6725c6e202'
COMMON=runpy.run_path(str(BASE))['COMMON'].replace('r79-production-msi-','r80-adapter-native-').replace('r79-production-msi-runtime/v1','r80-adapter-native-runtime/v1')
CAP=E/'native-reference-first/Capture.cs'
SID='S-1-5-21-3896111207-1867804362-1971593122-1001'
BOOT="[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()))"
CREATE=r'''
$w=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$w.User;if($sid.Value-cne$c.sid){throw 'SID'}}finally{$w.Dispose()}
$root=RootPath;try{[void][IO.File]::GetAttributes($root);throw 'ROOT_EXISTS'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
$cursor=[IO.Path]::GetDirectoryName($root);while($cursor){if(([IO.File]::GetAttributes($cursor)-band[IO.FileAttributes]::ReparsePoint)-ne0){throw 'ANCESTOR_REPARSE'};$cursor=[IO.Path]::GetDirectoryName($cursor)}
[void][IO.Directory]::CreateDirectory($root);$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false);foreach($s in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($s,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))};[IO.Directory]::SetAccessControl($root,$acl)
[IO.File]::WriteAllText((Join-Path $root '.owner'),"future-classroom-owned-r80-adapter-native-runtime/v1`n",[Text.UTF8Encoding]::new($false));$c.root=$root;CheckRoot $root;@{root=$root;status='CREATED'}|ConvertTo-Json -Compress
'''
RUN=r'''
CheckRoot $c.root;$root=$c.root
foreach($x in $c.inputs){$f=Fact (Join-Path $root $x.name);if($f.bytes-ne$x.bytes-or$f.sha256-cne$x.sha256){throw 'INPUT_BYTES'}}
$oldTemp=$env:TEMP;$oldTmp=$env:TMP;$clock=[Diagnostics.Stopwatch]::StartNew();$capture=$null;$p=$null;$returned=$true
$r=@{status='FAIL_RETAIN';cases=@();originalWholeSeconds=600;captureSourceOnlyProcessMethods=$true;controlledNativeReturns='CFG_TEST_SYNTHETIC_BEGIN_END_OBSERVATIONS_ONLY';productionMsiAdapter='NOT_EXERCISED',newAdapterTests='PURE_SEAL_AND_MESSAGE_PARSERS_ONLY';cleanup='ROOT_DOWNLOAD_THEN_EXACT_DELETE_REQUIRED'}
try{
 $env:TEMP=Join-Path $root 'compiler-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP)
 try{Add-Type -Path (Join-Path $root 'Capture.cs') -ErrorAction Stop}finally{$env:TEMP=$oldTemp;$env:TMP=$oldTmp}
 $capture=[Fc79Capture]::new();$exe=Join-Path $root 'candidate-tests.exe'
 $env:TEMP=Join-Path $root 'test-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP)
 foreach($s in @(@{name='controlled';filter='installer_lifecycle::tests::controlled_';seconds=150},@{name='lifecycle';filter='installer_lifecycle::';seconds=300})){
  if($clock.ElapsedMilliseconds-ge600000){throw 'WHOLE_BUDGET'}
  $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$exe;$info.Arguments=$s.filter+' --test-threads=1 --nocapture';$info.WorkingDirectory=$root;$info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
  $p=[Diagnostics.Process]::new();$p.StartInfo=$info;$case=@{name=$s.name;argv=$info.Arguments;originalSeconds=$s.seconds;actualExit=$false;exitCode=$null};$r.cases+=,$case
  $case.startedWholeMilliseconds=$clock.ElapsedMilliseconds;$case.originalDeadlineWholeMilliseconds=[Math]::Min(600000,$case.startedWholeMilliseconds+$s.seconds*1000)
  if(-not$p.Start()){throw 'START'};$returned=$false;$case.pid=$p.Id;$case.creation=$p.StartTime.ToUniversalTime().ToFileTimeUtc()
  $stdout=$p.StandardOutput.ReadToEndAsync();$stderr=$p.StandardError.ReadToEndAsync()
  $case.original=$capture.HoldStartedClient($p.Handle,[uint32]$p.Id,[long]$case.creation,$exe,$c.exeSha,$c.sid)
  $left=[int]($case.originalDeadlineWholeMilliseconds-$clock.ElapsedMilliseconds)
  if($left-le0-or-not$p.WaitForExit($left)){throw 'ORIGINAL_TEST_PARENT_UNKNOWN_RETAIN_NO_KILL'}
  $returned=$true;$p.Refresh();$case.actualExit=$true;$case.exitCode=$p.ExitCode
  if(-not[Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($stdout,$stderr),[int][Math]::Max(0,$case.originalDeadlineWholeMilliseconds-$clock.ElapsedMilliseconds))){throw 'ORIGINAL_PIPES_UNKNOWN'}
  $case.stdout=$stdout.Result;$case.stderr=$stderr.Result;[void]$capture.Snapshot()
  if($case.original.Wait-ne0-or-not$case.original.ExitKnown-or$case.original.ExitCode-ne$case.exitCode){throw 'ORIGINAL_TEST_RETURN_MISMATCH'}
  $case.endedWholeMilliseconds=$clock.ElapsedMilliseconds
  $p.Dispose();$p=$null;if($case.exitCode-ne0){throw 'NATIVE_TEST_FAILURE'}
  if($case.endedWholeMilliseconds-gt$case.originalDeadlineWholeMilliseconds){throw 'ORIGINAL_TEST_DEADLINE_EXCEEDED'}
 }
 $r.status='PASS_ADAPTER_COMPONENTS_AND_FULL_LIFECYCLE_NATIVE_TESTS_WIN11_ONLY'
}catch{$r.error=$_.Exception.Message}finally{
 $env:TEMP=$oldTemp;$env:TMP=$oldTmp
 if($null-ne$p-and$returned){$p.Dispose()}
 if($null-ne$capture){try{$r.originalObjects=@($capture.FinishAndClose())}catch{$r.status='FAIL_RETAIN';$r.closeError=$_.Exception.Message}}
 $r.originalParentReturned=$returned;$r.elapsedMilliseconds=$clock.ElapsedMilliseconds
 if($clock.ElapsedMilliseconds-ge600000){$r.status='FAIL_RETAIN';$r.budgetExceeded=$true}
 [IO.File]::WriteAllText((Join-Path $root 'native-result.json'),($r|ConvertTo-Json -Depth 30),[Text.UTF8Encoding]::new($false))
}
$r|ConvertTo-Json -Depth 30 -Compress
if($r.status-cne'PASS_ADAPTER_COMPONENTS_AND_FULL_LIFECYCLE_NATIVE_TESTS_WIN11_ONLY'){exit 1}
'''
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fact(p):p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def qualify_harness(stdout,required,expected):
 # --test-threads=1 is fixed by RUN. Nested fixture subprocesses inherit stdout
 # and may run a name that is also in the parent's 52-test scope. Count starts
 # only in the original harness scope; never promote a child's summary.
 assert len(required)==expected and len(set(required))==expected
 scopes=[];outer_names=[];summaries=[];outer_final=None;running=[]
 for line in stdout.splitlines():
  m=re.fullmatch(r'running (\d+) tests?',line)
  if m:
   n=int(m[1]);running.append(n)
   if not scopes:
    assert not summaries and n==expected,'ORIGINAL_PARENT_RUNNING_SCOPE'
   scopes.append(n)
   continue
  m=re.match(r'^test (installer_lifecycle::[^\s]+) \.\.\.',line)
  if m and len(scopes)==1:
   outer_names.append(m[1].rsplit('::',1)[-1])
  m=re.match(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',line)
  if m:
   assert scopes,'SUMMARY_WITHOUT_ORIGINAL_HARNESS_SCOPE'
   final=m.groups();summaries.append(final)
   assert final[0]=='ok' and all(int(n)==0 for n in final[2:5]),'REAL_TEST_FAILURE_OR_IGNORED_PRESENT'
   scope_count=scopes.pop()
   assert int(final[1])==scope_count,'HARNESS_SCOPE_SUMMARY_COUNT_MISMATCH'
   if not scopes:
    assert outer_final is None and int(final[1])==expected,'ORIGINAL_PARENT_FINAL_SCOPE'
    outer_final=final
 assert running and running[0]==expected and not scopes,'ORIGINAL_PARENT_HARNESS_NOT_COMPLETE'
 assert len(outer_names)==expected and set(outer_names)==set(required) and all(outer_names.count(name)==1 for name in required),'EXPECTED_OUTER_TEST_STARTS_EXACTLY_ONCE'
 assert outer_final is not None and summaries[-1]==outer_final,'FINAL_SUMMARY_MUST_BE_ORIGINAL_PARENT'
 assert not re.search(r'^test [^\r\n]*\.\.\. FAILED\r?$',stdout,re.M),'REAL_TEST_FAILURE_PRESENT'
 return dict(outerTotals={k:int(n) for k,n in zip(('passed','failed','ignored','measured','filteredOut'),outer_final[1:])},outerRunningCount=running[0],expectedOuterStarts=len(outer_names),summaryCount=len(summaries),nestedSummaryCount=len(summaries)-1,summaryAuthority='FINAL_ORIGINAL_PARENT_SUMMARY_WITH_ORIGINAL_PARENT_EXIT0_AND_CHECKED_CLOSE')

def main():
 a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');v=a.parse_args()
 if not v.execute:print('{"status":"NOT_RUN"}');return
 assert FINAL_PRODUCER_READY,'FINAL_ROOT_PRODUCER_NOT_BOUND'
 assert (E/'.owner').read_bytes()==b'future-classroom-owned-r80-controlled-repair/v1\n'
 producer=E/'adapter-build-second/report.json';assert sha(producer)=='c2b04b243f63807c642ed5f3de04efba405e71026b5133e9f3e46a16745a97f6'
 pr=json.loads(producer.read_text());assert pr['status']=='PASS_LOCAL_COMPILER_CHECK_ONLY' and pr['mode']=='build' and pr['actualExit']==0 and pr['originalParentReaped'] and pr['sourceUnchanged'] and pr['sourceBase']=='3e790e555a61a843e801000b371773a134df5c03'
 inventory=E/'adapter-inputs-second.json';assert sha(inventory)=='d6e5e2f25d34d372a31a26659894c2b8be2f6916c38f7f641bf670d76cc534e0'
 frozen=json.loads(inventory.read_text());assert pr['frozenInventorySha256']==sha(inventory) and pr['sourcesBefore']==pr['sourcesAfter']==frozen['sources'] and len(pr['sourcesBefore'])==456
 wt=E/'checkout-52d6392-first'
 source_rows=pr['sourcesBefore']
 python_inputs=[{'path': 'scripts/controlled-setup-seal.py', 'bytes': 3793, 'sha256': '1beac71c68ac4f0f6a4f5d73e247e33102fa43703c26ecaf6d9bdc2799100598'}, {'path': 'scripts/test-controlled-setup-seal.py', 'bytes': 6866, 'sha256': 'e40a6b0dc4cc49b75f420cc9bd053df902b57254d846a426fd7ef59ff243de0c'}]
 expected_dirty=['crates/fc-windows/src/installer_lifecycle/broker.rs', 'crates/fc-windows/src/installer_lifecycle/controlled.rs', 'crates/fc-windows/src/installer_lifecycle/native.rs', 'crates/fc-windows/src/installer_lifecycle/native/broker.rs', 'crates/fc-windows/src/installer_lifecycle/native/broker/controlled_owner.rs', 'crates/fc-windows/src/installer_lifecycle/native/broker/effects.rs', 'crates/fc-windows/src/installer_lifecycle/native/broker/retirement.rs', 'scripts/controlled-setup-seal.py', 'scripts/test-controlled-setup-seal.py']
 def verify_sources():
  head=subprocess.run(['git','rev-parse','HEAD'],cwd=wt,capture_output=True,check=True).stdout.decode().strip();assert head==pr['sourceBase']
  changed=subprocess.run(['git','diff','--name-only','HEAD'],cwd=wt,capture_output=True,check=True).stdout.decode().splitlines()
  untracked=subprocess.run(['git','ls-files','--others','--exclude-standard'],cwd=wt,capture_output=True,check=True).stdout.decode().splitlines()
  assert sorted(changed+untracked)==expected_dirty
  paths=sorted({*wt.glob('crates/**/*.rs'),*wt.glob('crates/**/Cargo.toml'),wt/'Cargo.toml',wt/'Cargo.lock',*wt.glob('.cargo/*'),*wt.glob('rust-toolchain*')})
  actual=[dict(path=str(p.relative_to(wt)),bytes=p.stat().st_size,sha256=sha(p)) for p in paths if p.is_file() and not p.is_symlink()]
  assert actual==source_rows
  for row in python_inputs:
   f=fact(wt/row['path']);assert f['bytes']==row['bytes'] and f['sha256']==row['sha256']
 verify_sources()
 assert sha(CAP)=='e74300d27694e46fde2e8113cfeee47ffd3f11f9172f01c5621fa2ba5fdcab5a'
 stdout=producer.parent/'cargo.stdout.jsonl';assert fact(stdout)['sha256']=='55f2fc9b847d56708df8087f7d3a865fea960b69971d398c067e71338bbeb72d' and fact(stdout)['bytes']==40116
 rows=[json.loads(x) for x in stdout.read_text().splitlines()]
 rows=[x for x in rows if x.get('reason')=='compiler-artifact' and x.get('profile',{}).get('test') and x.get('executable') and x['target']['name']=='fc_windows'];assert len(rows)==1
 exe=Path(rows[0]['executable']);assert len(pr['outputs'])==1 and pr['outputs'][0]['path']==str(exe) and pr['outputs'][0]['test'] is True
 assert fact(exe)['bytes']==pr['outputs'][0]['bytes'] and fact(exe)['sha256']==pr['outputs'][0]['sha256']
 raw=exe.read_bytes();off=struct.unpack_from('<I',raw,60)[0];assert raw[off:off+4]==b'PE\0\0' and struct.unpack_from('<H',raw,off+4)[0]==0x14c and struct.unpack_from('<H',raw,off+92)[0]==3
 test_source=(wt/'crates/fc-windows/src/installer_lifecycle/tests.rs').read_text()
 controlled=tuple(re.findall(r'^fn (controlled_\w+)\(',test_source,re.M));assert len(controlled)==6
 all_names=[]
 for source in sorted((wt/'crates/fc-windows/src/installer_lifecycle').rglob('*.rs')):
  all_names.extend(re.findall(r'#\[test\]\s*fn (\w+)\(',source.read_text()))
 assert len(all_names)==len(set(all_names))==54
 out=E/'adapter-native-runtime-first';out.mkdir();(out/'.owner').write_text('future-classroom-owned-r80-adapter-native-local/v1\n')
 r=dict(status='STARTED',authority='LEGACY_AND_ADAPTER_COMPONENT_REGRESSION_NOT_ACTUAL_BEGIN_OWNER_FLOW',sealedPythonInputs=python_inputs,compileInventory=fact(inventory),sourceBase=pr['sourceBase'],sourceInputs=source_rows,expectedScopes={'controlled':6,'lifecycle':54},scopeOverlap='54 includes 6 controlled, 11 effects and 2 pure adapter parser tests; do not sum',producer=fact(producer),nativeInput=fact(exe),capture=fact(CAP),operations=[],cleanup='NOT_RUN',outerSeconds=900);c=dict(nonce=secrets.token_hex(16),sid=SID,root=None,exeSha=sha(exe));start=time.monotonic()
 def save():(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
 def call(label,cmd,feed=None,limit=30):
  begin=time.monotonic();left=900-(begin-start);assert left>0
  child=subprocess.Popen(cmd,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  timed=False
  try:stdout,stderr=child.communicate(feed,timeout=min(left,limit))
  except subprocess.TimeoutExpired:
   timed=True;child.kill();stdout,stderr=child.communicate()
  so=out/(label+'.stdout.log');se=out/(label+'.stderr.log');so.write_bytes(stdout);se.write_bytes(stderr)
  r['operations'].append(dict(name=label,argv=cmd,actualReturnCode=child.returncode,originalLocalReaped=True,remoteOriginalReturnUnknown=timed,budgetExceeded=timed,elapsedSeconds=time.monotonic()-begin,stdout=fact(so),stderr=fact(se)));save()
  assert not timed and child.returncode==0,(label,child.returncode,'REMOTE_UNKNOWN_RETAIN' if timed else 'ACTUAL_NONZERO')
  return stdout
 def remote(label,script,limit=30):
  feed=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+COMMON+script).encode()
  return call(label,['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','future-classroom-win11','powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(BOOT.encode('utf-16-le')).decode()],feed,limit)
 try:
  c['root']=json.loads(remote('create',CREATE))['root'];r['windowsRoot']=c['root'];save()
  upload=out/'upload';upload.mkdir();shutil.copyfile(exe,upload/'candidate-tests.exe');shutil.copyfile(CAP,upload/'Capture.cs')
  c['inputs']=[dict(name=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(upload.iterdir())]
  for p in sorted(upload.iterdir()):call('upload-'+p.name,['scp','-q','-o','BatchMode=yes',str(p),'future-classroom-win11:'+c['root'].replace('\\','/')+'/'],limit=60)
  native=json.loads(remote('run',RUN,600));r['native']=native
  assert native['status']=='PASS_ADAPTER_COMPONENTS_AND_FULL_LIFECYCLE_NATIVE_TESTS_WIN11_ONLY'
  assert len(native['cases'])==2 and [x['name'] for x in native['cases']]==['controlled','lifecycle']
  r['qualifiedCases']=[]
  for case in native['cases']:
   required=controlled if case['name']=='controlled' else all_names
   assert case['actualExit'] and case['exitCode']==0
   expected=6 if case['name']=='controlled' else 54
   qualified=qualify_harness(case['stdout'],required,expected)
   r['qualifiedCases'].append(dict(name=case['name'],**qualified))
  assert len(native['originalObjects'])==2 and all(x['CheckedClose'] and x['Wait']==0 and x['ExitKnown'] and x['ExitCode']==0 for x in native['originalObjects'])
  ownedProcesses=json.loads(remote('owned-processes',"$a=@(Get-CimInstance Win32_Process -ErrorAction Stop|Where-Object {$_.ExecutablePath -and $_.ExecutablePath.StartsWith($c.root+'\\',[StringComparison]::OrdinalIgnoreCase)});@{count=$a.Count}|ConvertTo-Json -Compress"));r['ownedProcessReadback']=ownedProcesses;assert ownedProcesses['count']==0
  inv=json.loads(remote('inventory','Inventory $c.root|ConvertTo-Json -Depth 12 -Compress'));r['inventory']=inv
  for item in c['inputs']:
   actual=[x for x in inv['files'] if x['path']==item['name']];assert len(actual)==1 and actual[0]['bytes']==item['bytes'] and actual[0]['sha256']==item['sha256']
  save()
  download=out/'download';download.mkdir();call('download',['scp','-q','-r','-o','BatchMode=yes','future-classroom-win11:'+c['root'].replace('\\','/'),str(download)],limit=60)
  local=download/Path(c['root'].replace('\\','/')).name
  assert sha(BASE)=='da74f0058deac86507b712075904556780be6b262b18acb82415da6725c6e202'
  helper=runpy.run_path(str(BASE));helper['verify_download'](local,inv)
  assert json.loads((local/'native-result.json').read_text())==native
  c['inventory']=inv
  cleanup=helper['DELETE'].replace('PRODUCT_RUNTIME_ROOT','REPAIR_NATIVE_RUNTIME_ROOT')
  r['delete']=json.loads(remote('delete',cleanup));r['cleanup']='PASS_EXACT_DOWNLOADED_OWNED_SCRATCH_ONLY';r['status']='PASS_ADAPTER_COMPONENT_REGRESSION_NATIVE_TESTS_WIN11_ONLY'
 except Exception as error:r.update(status='FAIL_RETAIN_ORIGINALS',errorType=type(error).__name__,error=str(error))
 r['elapsedSeconds']=time.monotonic()-start
 if r['elapsedSeconds']>=900:r['status']='FAIL_OUTER_ORIGINAL_BUDGET_EXCEEDED';r['outerBudgetExceeded']=True
 try:verify_sources();r['candidateSourcesUnchanged']=True
 except Exception:r['candidateSourcesUnchanged']=False;r['status']='FAIL_CANDIDATE_SOURCE_CHANGED'
 r['compiledExeUnchanged']=fact(exe)==r['nativeInput']
 if not r['compiledExeUnchanged']:r['status']='FAIL_COMPILED_EXE_CHANGED'
 save();print(json.dumps({'status':r['status'],'report':str(out/'report.json'),'sha256':sha(out/'report.json'),'error':r.get('error')}));raise SystemExit(0 if r['status'].startswith('PASS_') else 1)
if __name__=='__main__':main()
