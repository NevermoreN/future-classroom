# Adapter component regression, final third producer

Default execution prints NOT_RUN. Root alone may explicitly run:

```
python3 -B /tmp/fc-round80-controlled-repair/adapter-native-preparation-first/run-native.py --execute
```

The result directory must be fresh: R80/adapter-native-runtime-first. Windows
uses a new cryptographic nonce under FutureClassroom-r80-adapter-native-, with
its exact marker and protected current-user/SYSTEM owner. Closed earlier
Windows roots are neither reopened nor adopted.

Admission binds final third GNU producer actual0, its original Cargo artifact,
the complete 456 Rust/Cargo/toolchain inventory at HEAD3e790e5, exact compiled
EXE bytes, Capture/helper references and separate frozen SHA facts for the two
Python setup-seal tools. Python tools are outside the Rust compilation domain.

The focused process must pass exactly six controlled tests in 150 seconds; the
second must pass all 54 lifecycle tests in 300 seconds. The latter includes the
six controlled, 11 effects and two pure adapter-parser tests. Counts are not
additive. Parent harness starts, nested child scopes and final parent summary
use the previously verified unchanged qualifier, with original native parent
exit0 and checked close still required.

These are legacy and adapter **component** regressions. The controlled test
Begin/End observations are cfg(test) synthetic credentials; the two new tests
exercise seal/message parsers. The actual production Begin-owner flow, sealed
Setup entry and new inner guard remain NOT_EXERCISED by this runner.

The original 600-second whole phase and 900-second transport budgets, physical
original process capability checks, complete raw download/inventory proof and
exact marker-owned cleanup are preserved. Unknown Windows controls are never
killed. Each PS AST chunk is unchanged from the pending preparation; only final
Python producer admission/readiness changed. Root performs any PS AST parsing
and actual Windows execution.

All pending preparation originals were copied byte-for-byte to pending-original
before the final producer was bound. They remain explicitly nonexecutable.
