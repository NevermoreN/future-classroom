"""Pure harness stdout samples; neither Windows nor Cargo runs here."""
from pathlib import Path
import json
import re
import runpy

HERE=Path(__file__).resolve().parent
R=HERE.parent
q=runpy.run_path(str(HERE/'run-native.py'),run_name='pure_samples_not_main')['qualify_harness']
W=R/'checkout-52d6392-first'
controlled=re.findall(r'^fn (controlled_\w+)\(', (W/'crates/fc-windows/src/installer_lifecycle/tests.rs').read_text(), re.M)
names=[]
for p in sorted((W/'crates/fc-windows/src/installer_lifecycle').rglob('*.rs')):
    names.extend(re.findall(r'#\[test\]\s*fn (\w+)\(',p.read_text()))
assert len(controlled)==6 and len(names)==len(set(names))==54
def summary(n,state='ok',failed=0):
    return f'test result: {state}. {n} passed; {failed} failed; 0 ignored; 0 measured; 233 filtered out; finished in 0.01s\n'
def sample(items,nested=False):
    s=f'running {len(items)} tests\n'
    for i,n in enumerate(items):
        s+=f'test installer_lifecycle::tests::{n} ... '
        if nested and i<3:s+='\nrunning 1 test\ntest installer_lifecycle::native::broker::tests::pipe_process_fixture_child ... ok\n'+summary(1)+'\nok\n'
        else:s+='ok\n'
    return s+summary(len(items))
results=[]
for label,text,required in [('focus6',sample(controlled),controlled),('full54',sample(names),names),('full54-three-inherited-child-scopes',sample(names,True),names)]:
    facts=q(text,required,len(required));results.append({'label':label,'status':'PASS_EXPECTED_ACCEPT','facts':facts})
full=sample(names,True)
for label,text in {
    'missing-parent-final':full.rsplit('test result:',1)[0],
    'child-summary-cannot-substitute-parent54':full.rsplit('test result:',1)[0]+summary(1),
    'parent-failure':full.rsplit('test result:',1)[0]+summary(53,'FAILED',1),
    'nested-failure':full.replace(summary(1),summary(0,'FAILED',1),1),
    'missing-outer-start':full.replace(f'test installer_lifecycle::tests::{names[-1]} ... ok\n','',1),
    'wrong-parent-initial-scope':full.replace('running 54 tests','running 1 test',1),
}.items():
    try:q(text,names,54)
    except AssertionError:results.append({'label':label,'status':'PASS_EXPECTED_REJECT'})
    else:raise AssertionError('incorrect acceptance '+label)
print(json.dumps({'status':'PASS_PURE_SAMPLES_ONLY_NOT_NATIVE_RUNTIME','controlledCount':6,'lifecycleCount':54,'actualBeginAdapter':'NOT_EXERCISED','windows':'NOT_RUN','cargo':'NOT_RUN','results':results},indent=2))
