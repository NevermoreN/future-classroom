Private actual Begin-owner adapter source, not a released installer.
Six Rust files only; independent Python setup-seal agent files are excluded from this patch.
Original CreateProcess process/thread capabilities are duplicated directly; no TID-based OpenThread recapture.
G cannot Begin before verified original parent READY; B creates Pending5 only after actual Begin0 and returned preimage pins, then authorizes Run.
G executes synchronous fixed hash-bound source MSI, native End and checked event return; B waits original G+thread exit0, checks effects and clears only original Pending/gate.
Post-arm errors retain original owner; pre-arm known abort requires actual empty End0/controls/G return.
Typed business result distinguishes rollback success from installation success.
Current inner FcBeginGate is not bypassed; public Setup entry and a verified new inner guard are not activated.
New uninstall is rejected until independent cache/source maintenance identity is proven; legacy route remains.
No Windows, Cargo, source commit, push, main or historical archive changes were executed.
