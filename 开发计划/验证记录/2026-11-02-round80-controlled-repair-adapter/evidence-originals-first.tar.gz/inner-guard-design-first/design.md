# Inner guard: one Type1 entry plus the original G callback and pipe

建议做一个可验证的 Type1 guard 原型。维持十二 crate：在现 `fc-windows` 增加 `cdylib` 输出和 `extern "system"` 导出 `FcControlledInnerGuard(hInstall)`；独立 controlled-inner MSI 的 `FcBeginGate` 仍为无条件、同步、检查返回值的动作，位置1499。把其实现从旧 Type2 `begin` 换成此 guard，不把条件改0、不接受 `HOST=1`。这是新的 controlled-inner 包格式；旧 standalone 包保留原规则。

x86导出名必须用明确export/DEF并对MSI Target逐字检查，不能假定stdcall装饰名恰好匹配。cdylib是ABI实现选择，不表示现有Rust编译链已经通过Win7/Win10 DLL运行。

这是可实现设计，**尚未实现或运行，不授予生产结算权威**。

## 为什么不选 INSTALL_IN_PROGRESS 时间窗

[官方 `_MSIExecute` 文档](https://learn.microsoft.com/en-us/windows/win32/msi/-msiexecute-mutex)只把互斥范围描述为执行三个 execute sequence 表期间；[Begin 文档](https://learn.microsoft.com/en-us/windows/win32/api/msi/nf-msi-msibegintransactionw)保证系统只有一个 transaction，并未给出“Begin后其他任意client必不能执行”的会话身份保证。故 B 开许可至 G 真正进入 execute、以及 G 返回至 B 撤许可之间，都不能单靠同一个共享 msiexec 父对象排除别的 client。轮询 mutex/服务状态也不原子。若今后有实测，仅能作为相应版本的观测，不能替代原会话绑定。

## API 边界

- [Type1](https://learn.microsoft.com/en-us/windows/win32/msi/custom-action-type-1)收到真实当前 `hInstall`；旧 Type2 EXE没有这个能力。[发送消息说明](https://learn.microsoft.com/en-us/windows/win32/msi/returning-error-messages-from-custom-actions)明确指出 EXE custom action 无当前 installation handle。
- G 在 Begin **之前**设 `InternalUI=NONE`、APPEND日志和 [`MsiSetExternalUIRecord`](https://learn.microsoft.com/en-us/windows/win32/api/msi/nf-msi-msisetexternaluirecord)（INFO和ACTIONSTART等固定filter）。CA只调用 [`MsiProcessMessage`](https://learn.microsoft.com/en-us/windows/win32/api/msiquery/nf-msiquery-msiprocessmessage)，不调用Install/Begin/UI设置或日志设置。这些配置/安装函数在 [CA禁用清单](https://learn.microsoft.com/en-us/windows/win32/msi/functions-not-for-use-in-custom-actions)中。
- [`hRecord` 在G回调中是借用、只读、仅回调期间有效](https://learn.microsoft.com/en-us/windows/win32/api/msi/nc-msi-installui_handler_record)。不能改record回传token，不能close它；UI的IDOK/IDYES也不是认证。授权必须通过下面的原连接能力。
- CA可以从 [`MsiGetActiveDatabase`](https://learn.microsoft.com/en-us/windows/win32/api/msiquery/nf-msiquery-msigetactivedatabase)只读查固定Binary；数据库、view、fetch record均按文档同线程检查 `MsiCloseHandle`。[流读取](https://learn.microsoft.com/en-us/windows/win32/api/msiquery/nf-msiquery-msirecordreadstream)按有界块完成，禁止未知表名/路径或安装调用。此方案用立即执行的Type1，不能直接移到受限的 deferred session。

## 最小调用与能力顺序

1. B按当前路线获得exclusive Draft，创建并认证原G进程/原线程；G通过原B↔G pipe、原父对象和完整镜像比较认证B。G固定目录 MSI source pin+SHA匹配seal，实际Begin0后才报告；B重核前像并真正checked-return阻止MSI的pin、写原Pending5，再发RUN。guard不重新admit、不重入Draft、不改Pending。
2. G把一个独立、小型、受互斥保护的 `GuardUiContext` 置为 `ActiveInstall` 后，原线程同步调用 `MsiInstallProduct` / `MsiConfigureProductEx`。不在API调用期间持回调需要的锁。官方没有保证所有回调都在原G线程执行，所以仅复制record字段，不能把callback TID假定成原API-owner TID；context寿命覆盖整个原同步调用，拒重入/重复guard。
3. CA在真实hInstall上验证固定包结构，生成随机128-bit challenge；创建 `FIRST_PIPE_INSTANCE|REJECT_REMOTE_CLIENTS` 的一次性本机pipe，名字仅由自身challenge派生，ACL限实际有效用户及SYSTEM；预置overlapped connect。record字段固定为协议版本、challenge、实际CA PID/TID和各自creation、ProductCode。它们是待核事实，不是命令行或property权限。用INFO发 `MsiProcessMessage`。
4. 原G的record回调只处理其当前同步调用、固定schema/包身份的一次guard。G打开该pipe，核 [`GetNamedPipeServerProcessId`](https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-getnamedpipeserverprocessid)给出的真实CA/engine对象，保留原process/thread query caps，核creation/线程所属进程/Windows目录msiexec镜像及用户或原SYSTEM engine规则。CA正阻塞于消息调用，故此处能在它仍活着时绑定；不能从日志事后追PID，也不把共享engine PID当transaction。
5. G在**已有原B/G连接**发固定32字节 `GUARD_REQUEST`（transaction、单次计数、challenge16）；B只在此原G的RUN阶段接受一次、回同challenge的ACK，不接受另一helper/另一个G或其他状态。B等待INSTALLED的循环需显式处理这一个新消息，不能靠全局flag。G只有真实ACK后才向CA pipe写有界授权帧。
6. G回调先启动overlapped读取CA的ACK，保留自己的pipe/event/engine query caps到调用返回，然后返回IDOK。**不得在回调里等CA执行后续read/ACK，否则CA仍在MsiProcessMessage内会死锁。** CA从消息返回后读取帧，核 [`GetNamedPipeClientProcessId`](https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-getnamedpipeclientprocessid)的实际G进程及镜像、SID、存活；challenge、transaction、长度完全匹配才放行。伪造UI返回码、nonce或同SID进程都不够。
7. CA先归还所有自有MSI记录/查询、G peer query/image/token能力，再发送ACK，最终pipe/event checked-close全部成功才返回0；失败返回1603，不忽略、不重试close。G检查ACK与其自有IO的真实完成。为排除“ACK发完但CA最后close失败”，G还必须收到当前闭合序列的**后继 `InstallInitialize` ACTIONSTART native record**，才记 `GuardReturned0`：无条件、同步、非Continue guard失败时不会进入该后继。这只是guard完成证据，不是事务终结。CA自己只发INFO，包验证器禁止其他自定义动作伪造此前的ACTIONSTART。
8. 原G安装API实际返回后先把context关闭、撤销B端guard请求阶段，再归还guard IO/query caps（所有未知保留）、原线程执行真实End决定。G actual End0、event checked-close、原G/线程物理退出、B重核原前像/结果后才按现路线结算。共享msiexec/CA线程没有“必须物理死掉”要求。若guard/后继证据缺失或CA close未知，不能把“Install1603+End0”自动当普通已知失败清Pending；保留负向状态，后续需独立恢复设计。

**双向镜像比较不可直接引入hash环：** 当前G的48-byte package seal包含inner MSI SHA；不能让同一inner MSI嵌入已seal G再要求完整SHA相同。最小包格式可固定保留此48字节槽：`Binary.FcGuardClientTemplate`存零槽的精确G模板，最后生成MSI SHA再填外部B/G的槽。CA比较G文件与模板的长度、每一个非槽字节及严格槽位置/魔数；只对这个固定槽做规范化。B↔G仍比较完整已seal镜像与原对象，G仍实际pin/hash整个inner MSI。不能任意跳过footer/manifest或按caller参数选slot。包格式与比较器必须独立审查；它不是“任何同签名/同SID代码都行”。

## 外部启动同inner为何拒绝

外部msiexec不具有原G的ActiveInstall callback context；它至多得到普通UI返回码，不能向CA pipe送出来自已认证原G、且已获当前B单次ACK的连接。没有认证帧，guard返回1603，尚未InstallInitialize。即使原B/G正在其他安装、或者共享同msiexec服务PID，B的原G连接、challenge单次状态和原G只处理自身调用callback仍不匹配。调用DLL导出伪造数字hInstall时数据库查询失败；复制公开property或旧challenge亦无效。

## 一份payload的真实验证，先于产品包接线

静态小fixture：独立nonce/Product/Component/HKCU marker、一个payload，Type1 guard1499始终执行；只用原B/G真实RUN。保留原120秒/64cap/8owner，不新增后台owner线程；各新增cap在获取前计入预算。除上面明确的立即CA外不加入旧embedded chainer或另起broker。

| 场景 | 必需实际证据 |
| --- | --- |
| 原B/G正常fresh install、EndCommit | 真实CA↔G peer+原B/G ACK、guard后继native record、Install0/End0/event0、payload/hash/registration、原G/thread退出0 |
| 同inner直接 `/i`、`/fa`、`/x`（有/无伪HOST） | 无有效guard帧，guard1603且不写payload/注册；不能只依赖1618 |
| 把一个payload变为坏字节或缺失后source-pinned repair | B先记录真实坏/缺前像；guard仍通过原会话；成功修复与EndCommit后精确健康 |
| 相同fixture的固定故障包，在InstallExecute之后6501真实返回1603 | guard后继已证明，fault实际执行（native callback+原API），EndRollback0后坏字节/缺失前像逐项恢复，不能把fixture手动恢复算MSI rollback |
| 在G API前、guard阻塞中、G API返回后尝试另一client | 不论1618或guard拒绝，绝无另一client消耗原B/G单次许可；保留竞态负控原件 |
| 假pipe、旧challenge、重复请求、错误G镜像/原parent | 不发许可；无共享service kill，无property fallback |
| CA/回调IO/checked-close负控 | 原期限内取消并真实收割IO；未知不换owner、不重试close、不清Pending。不能用成功UI回调掩盖最后close失败 |

先测Win11实际的quiet-mode record转发、CA↔原G duplex pipe及后继ACTIONSTART是否均可观察；若其中任何一步不成立，此方案不得接入生产。Win7/Win10和标准用户访问权限另留NOT_RUN；API版本可用不等于实机通过。

这份最小桥只覆盖同manifest包；ConfigureAbsent使用的已注册缓存包也须匹配对应helper模板。不同版本Setup/旧缓存模板不匹配时拒绝，不能临时放宽hash以“支持升级”。正式ARP/卸载入口必须路由到对应controlled Setup；直接inner `/x`被拒不是完整产品卸载体验已验收。

## 本次读到的源码与事实

- 现main `scripts/package-msi-candidate.py:40` / `:600`：旧begin是Type2，1499及相对顺序有静态检查。
- 现main `crates/fc-windows/src/installer_lifecycle/native/broker.rs:411-488`、`:640-713`、`:715`：peer原对象/镜像与真实engine父能力；旧begin会重新admit并新spawn broker，不能当controlled guard复用。
- R80工作树 `.../native/broker/controlled_owner.rs:163-194`、`:309-373`、`:467-578`：当前parent-derived pipe、fixed MSI seal、原G Begin→RUN→Install→End；当前尚无inner guard接线。这里只读快照，author仍可能继续实现。
- 已提交R79 `controlled-owner-runtime-third/runtime-operation.json` SHA44a72e…：四个一payload场景证明原Begin/Install/End可行；它没有生产guard。`early-terminal-runtime-first/runtime-operation.json` SHAd88935…：client0/-1仍可外层真实回滚，故成功callback不取代End；此前12个callback原caps UNKNOWN不被本设计当授权。

后续最小改动涉及现fc-windows DLL导出与UiContext、closed B/G两个消息分支、controlled-inner打包/检查脚本和上表fixture。没有新领域/协议crate或数据库/Windows句柄跨层。
