# 最小实施清单（API 探针先行）

必须先由独立 fixture 实测：InternalUI NONE 下 INFO 是否转发到原 G 的 MsiSetExternalUIRecord；1499 Type1 的 MsiProcessMessage 返回并自建 record checked-close 后，原 G 是否收到 InstallInitialize ACTIONSTART。回调 record 仅借用；线程记录实际值，不假定等于 G 安装线程。负例固定返回1603，保留真实 Install/End 返回。任何 UNKNOWN 不成为授权。

事实通过后才实现：

- `crates/fc-windows/Cargo.toml` 添加 `[lib] crate-type = ["rlib", "cdylib"]`，仍十二 crate；先核 x86 导出名，普通 rlib 调用保持原接口。
- `src/lib.rs` Windows-only `mod installer_guard_ca`；`unsafe extern "system" fn FcGuard(h_install: u32) -> u32` 仅导出实际 Type1，panic 跨 ABI 禁止。
- `installer_guard_ca.rs`：`guard_session(h_install: BorrowedMsiSession) -> Result<GuardPermit, GuardError>`；自建 MSI record 用独立 checked-close owner。借入 hInstall 和 callback hRecord 不 close。
- `native/broker/controlled_owner.rs`：原 G 在 Begin 前设 record callback；`GuardUiContext` 独立于 `&mut Session`，记录 pid/tid、one-shot 状态。`unsafe extern "system" fn external_record(ctx:*mut c_void, kind:u32, record:u32)->i32` 只复制字段，不能跨线程持有裸 hRecord。仅原 G 原线程做 Begin/Install/End。
- 单次 pipe：CA 先建 pipe 后发 nonce INFO；原 G 核实际 peer cap，再向原 B 请求 GUARD_REQUEST/ACK。callback 不等待必须由 CA 继续执行才能完成的动作；预置 overlapped read 后返回。one-shot、超时、关闭均显式状态。
- `scripts/package-msi-candidate.py`：Binary 内放零 seal 模板 guard helper；封装函数 `seal_helper(template, msi_sha)` 只填固定48字节槽。与 native `validate_template_image(actual, expected_non_slot_bytes)` 分离。先生成 MSI，再填外部 B/G seal，避免 MSI 自哈希循环。Binary DLL 自身不携带成品 MSI hash。

原 parent/engine/full image cap 与原 B/G 会话闭合仍为准入条件；本清单及单 fixture 均不是生产 bridge PASS。cached MSI 选源、ARP 路由、损坏前像不在该 API 探针结论中。
