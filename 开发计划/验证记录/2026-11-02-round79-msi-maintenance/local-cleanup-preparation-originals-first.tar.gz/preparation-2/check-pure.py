#!/usr/bin/env python3
"""Synthetic native metadata only. Never creates links or unlinks any file."""
import copy
import json
from pathlib import Path
import runpy
import stat

P=Path(__file__).parent/'local-cleanup-first.py'
m=runpy.run_path(str(P));checks=[]
def check(n,v):
 checks.append(dict(name=n,passed=bool(v)))
 if not v:raise AssertionError(n)
def rejected(n,fn):
 try:fn()
 except AssertionError:check(n,True)
 else:raise AssertionError(n)
def row(name,nlink=4):
 return dict(path=name,kind='file',device=1,inode=123,size=512,mtimeNs=40,ctimeNs=100,nlink=nlink,mode=stat.S_IFREG|0o600,uid=1000,gid=1000)
def current(r,**changes):
 d={k:v for k,v in r.items() if k not in ('path','kind')};d.update(changes);return d

pruned=['repair-candidate-target-first']
a,b,c=[row('repair-candidate-target-first/release/'+n) for n in ('a','b','c')]
groups=m['hardlink_groups']([a,b,c],pruned);g=groups[(1,123)]
check('known_pruned_cargo_only_relaxation',g['allowOwnedCtime'])
m['regular_guard'](a,current(a),g);check('first_link_all_original_metadata_required',True)
rejected('first_link_ctime_change_rejected',lambda:m['regular_guard'](a,current(a,ctimeNs=101),g))
native=m['account_owned_unlink'].__globals__['native_regular'];observed={}
try:
 m['account_owned_unlink'].__globals__['native_regular']=lambda p:observed[str(p)]
 observed[str(m['E']/b['path'])]=current(b,nlink=3,ctimeNs=101)
 m['account_owned_unlink'](a,g,[b,c]);check('after_first_owned_unlink_exact_nlink3_ctime101',g['unlinked']==1 and g['expectedCtimeNs']==101 and g['observations'][-1]['actualRemainingNlink']==3)
 m['regular_guard'](b,current(b,nlink=3,ctimeNs=101),g);check('next_original_same_inode_expected_ctime_accepted',True)
 rejected('wrong_nlink_cannot_be_hidden',lambda:m['regular_guard'](b,current(b,nlink=4,ctimeNs=101),g))
 rejected('unobserved_ctime_change_rejected',lambda:m['regular_guard'](b,current(b,nlink=3,ctimeNs=102),g))
 for field,value in [('size',513),('mtimeNs',41),('mode',stat.S_IFREG|0o644),('uid',1001),('gid',1001),('inode',124),('device',2)]:
  rejected('other_metadata_'+field+'_rejected',lambda field=field,value=value:m['regular_guard'](b,current(b,nlink=3,ctimeNs=101,**{field:value}),g))
 observed[str(m['E']/c['path'])]=current(c,nlink=2,ctimeNs=102)
 m['account_owned_unlink'](b,g,[c]);m['regular_guard'](c,current(c,nlink=2,ctimeNs=102),g)
 m['account_owned_unlink'](c,g,[]);check('three_owned_unlinks_accounted_without_reading_external_link',g['unlinked']==3 and g['initialNlink']==4 and g['ctimeAdjustments']==2 and len(g['observations'])==2)
 fresh=m['hardlink_groups']([a,b],pruned)[(1,123)];observed[str(m['E']/b['path'])]=current(b,nlink=4,ctimeNs=101)
 rejected('post_unlink_native_link_count_must_decrement_exactly',lambda:m['account_owned_unlink'](a,fresh,[b]))
 check('known_actual_owned_unlink_count_retained_on_postcheck_failure',fresh['unlinked']==1)
finally:m['account_owned_unlink'].__globals__['native_regular']=native
single=row('repair-candidate-target-first/release/single',1);sg=m['hardlink_groups']([single],pruned)[(1,123)]
check('single_link_never_relaxed',not sg['allowOwnedCtime'])
rejected('single_link_original_ctime_still_strict',lambda:m['regular_guard'](single,current(single,ctimeNs=101),sg))
outside=[row('package-preparation-first/tools/root/a',2),row('package-preparation-first/tools/root/b',2)]
og=m['hardlink_groups'](outside,['package-preparation-first/tools/root'])[(1,123)]
check('other_pruned_tree_not_relaxed',not og['allowOwnedCtime']);og['unlinked']=1
rejected('other_source_or_tool_path_owned_ctime_not_accepted',lambda:m['regular_guard'](outside[1],current(outside[1],nlink=1,ctimeNs=101),og))
check('cargo_target_not_pruned_is_not_relaxed',not m['hardlink_groups']([a,b],[])[(1,123)]['allowOwnedCtime'])
mixed=[a,row('source/alias')];check('mixed_source_alias_group_not_relaxed',not m['hardlink_groups'](mixed,['repair-candidate-target-first','source'])[(1,123)]['allowOwnedCtime'])
dest_rel=m['DEST'].relative_to(m['MAIN']);source_rel=(dest_rel/'root-archive-operation-first.json').relative_to(dest_rel).as_posix()
check('late_operation_maps_to_exact_same_E_relative_path',source_rel=='root-archive-operation-first.json' and m['owned'](source_rel)==m['E']/'root-archive-operation-first.json')
report=dict(status='PASS_PURE_SYNTHETIC_HARDLINK_METADATA_AND_EXACT_LATE_PATH_MAPPING',checks=checks,checkCount=len(checks),actualUnlinkCalls=0,actualHardlinksCreated=0,Windows='NOT_CONTACTED',remote='NOT_QUERIED',EWritten=False,mainWritten=False)
print(json.dumps(report,indent=2))
