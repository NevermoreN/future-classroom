第二准备版本，仅E外本目录写入；第一版controller从未实际执行，旧freeze保留，不制造旧FAIL。默认不执行。仍须root复制到DEST/local-cleanup-first.py、实际提交并同步后，显式传入finalcommit/index/archive/verification SHA、remote refs、185（以最终index为准）excluded计数和至少两个supplement。

修复1：对每个显式DEST supplement，若E中同DEST-relative路径存在，必须regular/nonalias、actual E bytes+SHA完全等于当前DEST及其实际committed blob，才把该精确路径加入late-source allowed。不存在则仅是已提交controller补充，不放行新E路径。可覆盖具体root-archive-operation-first.json；不宣称该latefile在tar里。

修复2：计划记录原nlink/mode/uid/gid。仅已在finalindex pruned里的自有repair-candidate-target-first同inode组处理本次unlink导致的ctime变化。首link仍严格原ctime；后续必须sameinode/size/mtime/mode/uid/gid完全相同，原nlink减去本次已完成unlink次数精确相等，并匹配上次own-unlink后即时读取的剩余自有link ctime。单link、其他pruned、source、main target及global cache路径不放宽。最后记录每组次数、nlink和ctime观察；发生后续拒绝时已完成unlink计数仍保留。

24项纯合成元数据场景验证actual0，没有创建hardlink或unlink任何文件；默认inert actual0。未连接Windows、未查询remote、未写E/main、未执行删除或提交。其余tar/currentoriginal/185binary实际SHA、candidate3committed blobs+patch、双clean WT正常remove、进程/mount门槛、R80不读/hash、key仅0600 metadata、3ZIP与main target保护及逻辑空间口径延续。
