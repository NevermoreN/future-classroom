from pathlib import Path
import json,hashlib,tarfile,gzip,io,stat,runpy
MAIN=Path('/workspace/共享/Eliora/未来教室计划');D=MAIN/'开发计划/验证记录/2026-11-02-round79-msi-maintenance';E=Path('/tmp/fc-round79-msi-maintenance');P=Path('/tmp/fc-r79-local-cleanup-preparation-second');assert hashlib.sha256((P/'local-cleanup-first.py').read_bytes()).hexdigest()=='52bb66bc5ae388f738fb431d2da2cfc5c230045645b1032d5f3d0d18a5d112b9'
# This wrapper is itself preserved in the supplement; no credentials or keys read.
roots=[Path('/tmp/fc-r79-local-cleanup-preparation-first'),P];scanner=runpy.run_path(str(E/'archive-preparation-second/archive-second.py'));stats={k:0 for k in ('textViews','utf16Views','cp936Views','clixmlDecodedViews','decodedBase64Views','jsonContainers','decodedJsonStringViews','sourceFiles','storedFiles','promotedFiles')};findings=[];rows=[];excluded=[];tarbuf=io.BytesIO()
with gzip.GzipFile(fileobj=tarbuf,mode='wb',mtime=0) as gz:
 with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
  for i,root in enumerate(roots,1):
   assert root.is_dir() and not root.is_symlink() and (root/'.owner').is_file()
   for p in sorted(root.rglob('*')):
    assert not p.is_symlink()
    if p.is_dir():continue
    assert p.is_file();b=p.read_bytes();n='preparation-'+str(i)+'/'+p.relative_to(root).as_posix();fact={'path':n,'originalPath':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
    if '__pycache__' in p.relative_to(root).parts:excluded.append({**fact,'reason':'compiled Python cache, identity only'});continue
    scanner['credential_scan'](b,'late-preparation:'+n,stats,findings);assert not findings
    info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o600;info.uid=info.gid=info.mtime=0;info.uname=info.gname='';tar.addfile(info,io.BytesIO(b));rows.append(fact)
b=tarbuf.getvalue();assert not (D/'local-cleanup-preparation-originals-first.tar.gz').exists();(D/'local-cleanup-preparation-originals-first.tar.gz').write_bytes(b)
index={'status':'PASS_FINITE_LOCAL_CLEANUP_PREPARATION_SOURCE_PRESERVATION_NOT_DELETION','archive':{'path':'local-cleanup-preparation-originals-first.tar.gz','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},'roots':[str(x) for x in roots],'members':rows,'excludedCaches':excluded,'credentialScan':{'status':'PASS_NO_MATCHES','statistics':stats,'findings':findings},'firstControllerExecuted':False,'secondControllerExecuted':False};(D/'local-cleanup-preparation-index-first.json').write_text(json.dumps(index,indent=2)+'\n');data=(P/'local-cleanup-first.py').read_bytes();assert not (D/'local-cleanup-first.py').exists();(D/'local-cleanup-first.py').write_bytes(data)
for p in [D/'root-archive-operation-first.json',D/'local-cleanup-preparation-index-first.json',D/'local-cleanup-first.py']:
 scanner['credential_scan'](p.read_bytes(),'late-supplement:'+p.name,stats,findings)
assert not findings
(D/'local-cleanup-supplement-scan-first.json').write_text(json.dumps({'status':'PASS_DECODED_CREDENTIAL_SCAN_OF_LATE_PREPARATION_AND_OPERATION','findings':[],'files':[{'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [D/'root-archive-operation-first.json',D/'local-cleanup-preparation-index-first.json',D/'local-cleanup-first.py']],'statistics':stats},indent=2)+'\n');print(json.dumps({'status':'PASS','members':len(rows),'archiveBytes':len(b),'archiveSha256':hashlib.sha256(b).hexdigest(),'controllerSha256':hashlib.sha256(data).hexdigest(),'credentialFindings':len(findings)}))
