from pathlib import Path
import hashlib
E=Path('/tmp/fc-round79-msi-maintenance');old=E/'controlled-owner-transport-preparation-first/run-controlled-owner-first.py';assert hashlib.sha256(old.read_bytes()).hexdigest()=='a8329b1fe77baf67d8d76872f3a34be3b57d08890a3a53f146a17a53cfa4a8a7'
s=old.read_text().replace("PROTOTYPE=E/'controlled-owner-preparation-second'","PROTOTYPE=E/'controlled-owner-handle-design-first'\nSOURCE_DIR=PROTOTYPE/'prototype-preparation-first'")
s=s.replace("freeze['status']=='FROZEN_LOCAL_ACTUAL_GCC_AND_MSI_STATIC_PASS_WINDOWS_NOT_RUN' and freeze['productionAuthority']=='NONE' and freeze['windowsExecuted'] is False", "freeze['status']=='FROZEN_PRIMARY_RESEARCH_AND_LOCAL_ACTUAL_STATIC_PROTOTYPE_WINDOWS_NOT_RUN'")
s=s.replace("stage==owned(PROTOTYPE/freeze['executionStage'])", "stage==owned(PROTOTYPE/json.loads((PROTOTYPE/'execution-plan-first.json').read_text())['stage'])")
s=s.replace("fact(owned(PROTOTYPE/name))==row,'Actual producing source closure'", "fact(owned(SOURCE_DIR/name))==row,'Actual producing source closure'")
s=s.replace("close=one('MSI_HANDLE_CLOSE_RETURN')", "close=one('TRANSACTION_ID_NO_INSTALL_HANDLE_CLOSE')")
s=s.replace("close['attempted'] is True and close['return']==0", "close['attempted'] is False and type(close['return']) is int and close['return']==4294967295")
s=s.replace("'Actual Begin/Install/End/close values, no synthetic Join'", "'Actual Begin/Install/End/eventclose; transactionID non-close is explicitly not an API return'")
needle="  one('END_COMMIT_ENTER' if index in (2,3) else 'END_ROLLBACK_ENTER')\n"
new=needle+'''  logging=one('LOG_ENABLE_RETURN');ui=one('SET_UI_PREVIOUS_LEVEL');need(ui['attempted'] is True and logging['attempted'] is True and logging['return']==0 and ui['sequence']<logging['sequence']<begin['sequence'],'Real UI/log configuration before Begin')
  change=one('BEGIN_CHANGE_EVENT');need(change['object']>0 and change['object']==event['object'],'Same actual acquired kernel change-event checked returned')
  observed=case['nativeLog'];need(observed['scope']=='ORIGINAL_NATIVE_CALLBACK_LOG_FACTS_ONLY_NO_CALLBACK_CAPABILITY_AUTHORITY','Callbacks remain facts only')
  callbacks=observed['callbacks'];need(all(x['nonce']==spec['nonce'] and x['product']==spec['productCode'] and x['valid']=='1' and x['pointerBytes']=='4' and x['tokenClose']=='1' for x in callbacks),'Actual original callback facts for this private product')
  if index<3:need(len([x for x in callbacks if x['stage']=='PREPARE'])==1,'Actual prepare executed')
  if index==0:
   force=[x for x in callbacks if x['stage']=='FORCE_FAIL'];rollback=[x for x in callbacks if x['stage']=='ROLLBACK'];need(len(force)==len(rollback)==1 and force[0]['intendedReturn']=='1603' and force[0]['rollback']=='0' and rollback[0]['rollback']=='1' and rollback[0]['intendedReturn']=='0','Actual forced-failure action and native rollback mode1 executed')
'''
assert s.count(needle)==1;s=s.replace(needle,new)
needle="logs={p.name:decode_log(p.read_bytes()) for p in sorted(download.glob('*-msi.log'))};need(len(logs)==4,'Four exact owner MSI logs')"
new=needle+"\n   for case in phase['cases']:\n    original=download/(case['name']+'-msi.log');need(fact(original)=={'bytes':case['nativeLog']['logBytes'],'sha256':case['nativeLog']['logSha256']},'Every actual original engine log hash bound to phase')\n   need(re.search(r'Action ended .*Fc79ForceFail\\. Return value 3\\.',logs['early-fail-rollback-msi.log']) is not None,'Actual engine ForceFail action return3, not only intended callback return')"
assert s.count(needle)==1;s=s.replace(needle,new)
p=Path(__file__).parent/'run-controlled-owner-second.py';assert not p.exists();p.write_text(s)
