$c='{"root":"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-fceb9af5ba8149cdabdc382c6615fc3d","nonce":"fceb9af5ba8149cdabdc382c6615fc3d","sid":"S-1-5-21-3896111207-1867804362-1971593122-1001","spec":{"schemaVersion":1,"status":"PREPARED_NOT_RUN","nonce":"fceb9af5ba8149cdabdc382c6615fc3d","rootName":"FutureClassroom-r79-early-terminal-fceb9af5ba8149cdabdc382c6615fc3d","windowsRoot":"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-fceb9af5ba8149cdabdc382c6615fc3d","effectDir":"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-fceb9af5ba8149cdabdc382c6615fc3d\\effect\\","marker":"future-classroom-owned-r79-early-terminal-fixture/v1\n","expectedUserSid":"S-1-5-21-3896111207-1867804362-1971593122-1001","registryKey":"Software\\FutureClassroomTest\\Round79-fceb9af5ba8149cdabdc382c6615fc3d","wholeSeconds":600,"nativeSeconds":120,"clientSeconds":120,"finallyReserveSeconds":180,"maximumHandles":64,"maximumOwners":8,"sourceGit":"c44906517fbc62233dca755d7225cea375264cbc","scope":"FRESH_INDEPENDENT_ORIGINAL_BEGIN_API_OWNER_NOT_PRODUCTION_AUTHORITY","sources":{"Owner.c":{"bytes":7999,"sha256":"3d6840f9d132860c8f358104a371d5df4a8bba4925aab2445b5b9acf2f83f6c1"},"Invoke-ControlledOwner.ps1":{"bytes":13612,"sha256":"7d8f79429ff8c505a1ae5d3699293eae830a8a3ccf518c5dee2459ecc5a215f6"},"Capture.cs":{"bytes":11335,"sha256":"cd2f47598504deef0a2721a6d61d3cf95a8e93aa6146e4fadeb8744f4e924580"},"EarlyTerminal.c":{"bytes":7254,"sha256":"dc8630277b69dfc4e7cf2ee3eebd476970ffc94138d7581be7934aed706ee9da"},"fixture-original.py":{"bytes":24097,"sha256":"6e1c8520ac799af57ed0b9a440cb3e855c6629cead01a4a6d18b1279a438360a"},"build.py":{"bytes":12426,"sha256":"24584adbdaae371189770d7243aa1578f52ccf45932876d30aa989905411a6eb"},"tools.json":{"bytes":1103,"sha256":"e885fe2e048642a88a8787e722c634ded7b9114f0f08faee3c288f390a50c98d"},"child-environment.json":{"bytes":121,"sha256":"67db97daf1ead75403164284a081b0b28887b699dc8d4e0c41b2cd92924e622f"}},"productCode":"{84F4D11C-B62B-46B4-9F74-E48E88AABC46}","upgradeCode":"{C9F62721-DAE7-4358-98EF-33AD9E03EFB6}","componentId":"{4D57DD6A-A6B0-4A20-8013-A06AF7D2811D}"},"manifest":{"status":"PREPARED_RUNTIME_NOT_RUN","specSha256":"cc4a01f520bab516ead8e564832d0ce71335d29fc56c63bb6c4b78609bee119b","buildReportSha256":"97ca753f6c5e31cf1c1f80887eb44258bf04bd7fad0977b0a3259cd5ccb151b7","files":[{"path":".owner","bytes":53,"sha256":"60f5bff57e6ca56a577cce6e1025aeb8d8087edcc6b9270282bfd362ab841350"},{"path":"Capture.cs","bytes":11335,"sha256":"cd2f47598504deef0a2721a6d61d3cf95a8e93aa6146e4fadeb8744f4e924580"},{"path":"EarlyTerminal.dll","bytes":219125,"sha256":"8ec0433543bf5a54de3948e937c6bec6b6dddc07c9f34b03c3ac9b57b4be8393"},{"path":"Invoke-ControlledOwner.ps1","bytes":13612,"sha256":"7d8f79429ff8c505a1ae5d3699293eae830a8a3ccf518c5dee2459ecc5a215f6"},{"path":"Owner.exe","bytes":298409,"sha256":"95ecdc518fba1dfb705795d9b2bcd315afdeb194eeef3c78c7b74f893c8af47c"},{"path":"build-report.json","bytes":68162,"sha256":"97ca753f6c5e31cf1c1f80887eb44258bf04bd7fad0977b0a3259cd5ccb151b7"},{"path":"early-fail.msi","bytes":232448,"sha256":"877d65bb199cac0a1d64d55d0dd8d9407aa4f588ebdfa8af5a1ff2714b858f9c"},{"path":"healthy.msi","bytes":232448,"sha256":"0a084463e87b8e030d4b57a87ea22e4f50ed5d37f8e78cbc9ab22b85a7fe9dec"},{"path":"payload.txt","bytes":70,"sha256":"081b2366c9458717fd554e0ec462d4a37c436fded5339a1f3c85b152e9a78026"},{"path":"spec.json","bytes":2260,"sha256":"cc4a01f520bab516ead8e564832d0ce71335d29fc56c63bb6c4b78609bee119b"}]},"specSha256":"cc4a01f520bab516ead8e564832d0ce71335d29fc56c63bb6c4b78609bee119b","manifestSha256":"73daf36d811d0eabd10b82af7e6eb2179be27fe356cccfd536581195312ea8be"}'|ConvertFrom-Json;
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Need([bool]$v,[string]$s){if(-not $v){throw $s}}
function Absent([string]$p){try{[void][IO.File]::GetAttributes($p);return $false}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-is [IO.FileNotFoundException] -or $e-is [IO.DirectoryNotFoundException]){return $true};throw}}
function Fact([string]$p){$a=[IO.File]::GetAttributes($p);Need (-not($a-band[IO.FileAttributes]::ReparsePoint) -and -not($a-band[IO.FileAttributes]::Directory)) 'REGULAR_NONREPARSE';$size=[long]([IO.FileInfo]::new($p).Length);Need ($size-ge 0 -and $size-le 16777216) 'FILE_BOUND';@{bytes=$size;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function Root-Check {
 Need ($PSVersionTable.PSVersion.Major-eq 5 -and [IntPtr]::Size-eq 8) 'DESKTOP_PS51_X64'
 Need ([IO.Path]::GetFullPath($c.root)-ceq $c.root -and [IO.Path]::GetFileName($c.root)-ceq ('FutureClassroom-r79-early-terminal-'+$c.nonce)) 'CLOSED_ROOT'
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent();try{Need ($identity.User.Value-ceq $c.sid) 'EXPECTED_CURRENT_USER'}finally{$identity.Dispose()}
 $cursor=$c.root;while($cursor){$a=[IO.File]::GetAttributes($cursor);Need (($a-band[IO.FileAttributes]::ReparsePoint)-eq 0 -and ($a-band[IO.FileAttributes]::Directory)-ne 0) 'DIRECTORY_NO_REPARSE';$cursor=[IO.Path]::GetDirectoryName($cursor)}
 Need ([IO.File]::ReadAllText((Join-Path $c.root '.owner'))-ceq "future-classroom-owned-r79-early-terminal-fixture/v1`n") 'OWNER_MARKER'
 $acl=[IO.Directory]::GetAccessControl($c.root);Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq $c.sid) 'PROTECTED_OWNER'
 $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($rules.Count-eq 2) 'TWO_ACES'
 $who=@($rules|ForEach-Object {$_.IdentityReference.Value}|Sort-Object -Unique);Need ($who.Count-eq 2 -and $c.sid-in $who -and 'S-1-5-18'-in $who) 'USER_AND_SYSTEM'
 foreach($r in $rules){Need ($r.AccessControlType-eq 'Allow' -and ($r.FileSystemRights-band [Security.AccessControl.FileSystemRights]::FullControl)-eq [Security.AccessControl.FileSystemRights]::FullControl) 'EXACT_ALLOW_FULLCONTROL'}
}

function Parent-State {
 $base=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry32);$key=$null
 try{
  $key=$base.OpenSubKey('Software\FutureClassroomTest',$false)
  if($null-eq $key){return @{status='KNOWN_ABSENT';key='Software\FutureClassroomTest';view='Registry32'}}
  $values=@($key.GetValueNames());$subkeys=@($key.GetSubKeyNames());Need ($values.Count-le 64 -and $subkeys.Count-le 128) 'PARENT_SNAPSHOT_BOUND'
  $acl=$key.GetAccessControl([Security.AccessControl.AccessControlSections]::Owner -bor [Security.AccessControl.AccessControlSections]::Access)
  @{status='PRESENT';key='Software\FutureClassroomTest';view='Registry32';ownerSid=$acl.GetOwner([Security.Principal.SecurityIdentifier]).Value;securityDescriptor=$acl.GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]::Owner -bor [Security.AccessControl.AccessControlSections]::Access);valueNames=@($values|Sort-Object);subkeyNames=@($subkeys|Sort-Object)}
 }finally{if($null-ne $key){$key.Dispose()};$base.Dispose()}
}

function Inventory {
 Root-Check;$files=@();$dirs=@();$total=0L;$queue=[Collections.Generic.Queue[string]]::new();$queue.Enqueue($c.root)
 while($queue.Count){$dir=$queue.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){
  $attrs=[IO.File]::GetAttributes($p);Need (($attrs-band[IO.FileAttributes]::ReparsePoint)-eq 0) 'INVENTORY_REPARSE'
  $rel=$p.Substring($c.root.Length+1).Replace('\','/')
  if(($attrs-band[IO.FileAttributes]::Directory)-ne 0){$top=($rel-split '/')[0];Need ($top-cin @('compiler-temp','readback-compiler-temp','effect')) 'ONLY_OWN_FIXTURE_SUBDIRECTORIES';$dirs+=$rel;$queue.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256};$total+=$f.bytes}
  Need ($files.Count-le 256 -and $dirs.Count-le 32 -and $total-le 67108864) 'RUNTIME_INVENTORY_BOUND'
 }}
 @{files=$files;directories=$dirs}
}
$who=[Security.Principal.WindowsIdentity]::GetCurrent();try{Need ($who.User.Value-ceq $c.sid) 'EXACT_USER_BEFORE_PARENT_QUERY'}finally{$who.Dispose()};$parentBefore=Parent-State;
Need ($c.nonce-cmatch '^[0-9a-f]{32}$' -and $c.sid-cmatch '^S-1-5-21-') 'NONCE_SID'
$identity=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$identity.User;Need ($sid.Value-ceq $c.sid) 'EXACT_USER'}finally{$identity.Dispose()}
$expected=Join-Path ([IO.Path]::GetFullPath($env:TEMP)) ('FutureClassroom-r79-early-terminal-'+$c.nonce)
Need ($expected-ceq $c.root) 'SPEC_ROOT_MUST_EQUAL_ACTUAL_USER_TEMP_ROOT'
Need (Absent $c.root) 'PREEXISTING_ROOT_REFUSED'
$cursor=[IO.Path]::GetDirectoryName($c.root);while($cursor){Need (([IO.File]::GetAttributes($cursor)-band[IO.FileAttributes]::ReparsePoint)-eq 0) 'NO_ANCESTOR_REPARSE';$cursor=[IO.Path]::GetDirectoryName($cursor)}
[void][IO.Directory]::CreateDirectory($c.root)
$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false)
foreach($who in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($who,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))}
[IO.Directory]::SetAccessControl($c.root,$acl)
$owner=[Text.UTF8Encoding]::new($false).GetBytes("future-classroom-owned-r79-early-terminal-fixture/v1`n")
$f=[IO.File]::Open((Join-Path $c.root '.owner'),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);try{$f.Write($owner,0,$owner.Length);$f.Flush($true)}finally{$f.Dispose()}
Root-Check
@{status='PASS_CREATED_ONLY_PROTECTED_FIXTURE_RUNTIME_ROOT';root=$c.root;nonce=$c.nonce;sid=$c.sid;registryParentBefore=$parentBefore}|ConvertTo-Json -Compress
