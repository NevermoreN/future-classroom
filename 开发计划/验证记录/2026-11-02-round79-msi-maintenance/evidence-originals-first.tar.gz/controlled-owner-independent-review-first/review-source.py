#!/usr/bin/env python3
"""Read-only finite admission checks for the already built controlled-owner fixture."""
import hashlib
import json
import pathlib
import re

E=pathlib.Path('/tmp/fc-round79-msi-maintenance')
P=E/'controlled-owner-preparation-second'
B=P/'build-output-first'
S=B/'stage'
O=pathlib.Path(__file__).parent
checks=[]

def fact(p):
    b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

def check(n,c,d=None):
    checks.append(dict(name=n,passed=bool(c),detail=d))
    if not c:raise AssertionError(n)

def bound(p,row,n):
    v=fact(p);check(n,all(v[k]==row[k] for k in ('bytes','sha256') if k in row),v)

def j(p):return json.loads(p.read_text())

spec=j(B/'spec.json');build=j(B/'build-report.json');manifest=j(S/'runtime-inputs.json')
freeze=j(P/'freeze-second.json')
for row in freeze['files']:bound(P/row['path'],row,'author_freeze:'+row['path'])
owner=(P/'Owner.c').read_text();driver=(P/'Invoke-ControlledOwner.ps1').read_text();producer=(P/'build.py').read_text()
check('final_build_actual_static_pass_only',build['status']=='PASS_STATIC_ONLY_WINDOWS_NOT_RUN' and build['windows']=='NOT_RUN')
bound(B/'spec.json',build['spec'],'build_spec')
check('final_build_sources_unchanged',build['sourcesUnchanged'] and build['toolsUnchanged'])
for name,row in spec['sources'].items():bound(P/name,row,'source:'+name)
for name in ('Owner.c','EarlyTerminal.c','Invoke-ControlledOwner.ps1','Capture.cs'):
    check('built_exact_current_source:'+name,(B/name).read_bytes()==(P/name).read_bytes())
for row in manifest['files']:bound(S/row['path'],row,'stage:'+row['path'])
check('stage_exact_10_inputs_and_manifest',set(p.name for p in S.iterdir())=={x['path'] for x in manifest['files']}|{'runtime-inputs.json'} and len(manifest['files'])==10)
check('manifest_build_and_spec_bound',manifest['specSha256']==fact(B/'spec.json')['sha256'] and manifest['buildReportSha256']==fact(B/'build-report.json')['sha256'])
bound(S/'Owner.exe',build['owner'],'actual_native_owner_exe')
bound(S/'EarlyTerminal.dll',build['observer'],'actual_observer_dll')
bound(S/'payload.txt',build['payload'],'actual_single_payload')
check('81_actual_local_commands_exit0_reaped',len(build['commands'])==81 and all(x['actualExit']==0 and x['parentReaped'] for x in build['commands']))
for row in build['commands']:
    for ext,k in (('stdout','stdoutSha256'),('stderr','stderrSha256')):
        bound(B/(row['label']+'.'+ext),{'sha256':row[k]},'original_producer_stream:'+row['label']+':'+ext)
check('strict_gnu_native_owner',{'-Wall','-Wextra','-Werror','-municode','-mwindows','-lmsi','-lshell32'}<=set(build['commands'][0]['argv']))
check('fresh_nonce_is_not_prior_fixture',bool(re.fullmatch('[0-9a-f]{32}',spec['nonce'])) and spec['nonce'] not in ('0b744835e91f1ee00a95b18eb3303f19','db6b185d70ec9aa67adf8fee409203c7'))
prior=j(E/'early-terminal-inputs-derived-fifth/spec.json')
check('fresh_product_upgrade_component_namespace',all(spec[k]!=prior[k] for k in ('productCode','upgradeCode','componentId')))
check('fresh_closed_root_registry_effect',spec['rootName']=='FutureClassroom-r79-early-terminal-'+spec['nonce'] and spec['windowsRoot'].endswith('\\'+spec['rootName']) and spec['effectDir']==spec['windowsRoot']+'\\effect\\' and spec['registryKey']=='Software\\FutureClassroomTest\\Round79-'+spec['nonce'])
check('unchanged_limits', [spec[k] for k in ('wholeSeconds','nativeSeconds','clientSeconds','finallyReserveSeconds','maximumHandles','maximumOwners')]==[600,120,120,180,64,8])
for case,r in build['cases'].items():
    bound(S/(case+'.msi'),r['msi'],'actual_msi:'+case)
    t=r['tables'];seq={x['Action']:(x['Condition'],x['Sequence']) for x in t['InstallExecuteSequence']}
    check('one_payload_registry_component_no_chainer:'+case,len(t['File'])==len(t['Registry'])==len(t['Component'])==len(t['FeatureComponents'])==1 and t['Binary']==[{'Name':'ObserverDll','Data':'Binary.ObserverDll'}] and 'MsiEmbeddedChainer' not in t)
    check('six_exact_observer_actions:'+case,len(t['CustomAction'])==6 and all(x['Source']=='ObserverDll' for x in t['CustomAction']))
    check('early_failure_placement_and_terminal_slots:'+case,seq['InstallExecute'][1]=='6500' and seq['InstallFinalize'][1]=='6600' and seq['Fc79ForceFail']==(('1' if case=='early-fail' else '0')+' AND NOT Installed','6501') and seq['Fc79Rollback']==('NOT Installed','1501') and seq['Fc79TerminalSuccess']==('NOT Installed','-1') and seq['Fc79TerminalFailure']==('NOT Installed','-3'))
    check('exact_registry_identity:'+case,t['Registry']==[{'Registry':'FixtureMarker','Root':'1','Key':spec['registryKey'],'Name':'Marker','Value':'#1','Component_':'FixtureComponent'}])
    for name in ('Upgrade','ServiceInstall','ServiceControl','AppSearch','Shortcut','IniFile','RemoveFile','RemoveIniFile','Signature','RegLocator','Icon','CreateFolder'):
        check('no_extra_effect:'+case+':'+name,not t.get(name))
    extracted=[p for p in (B/(case+'-extracted')).rglob('*') if p.is_file()]
    check('one_exact_extracted_payload:'+case,len(extracted)==1 and extracted[0].name=='payload.txt' and extracted[0].read_bytes()==(S/'payload.txt').read_bytes())
check('one_binary_exact_bytes',(B/'Binary/Binary.ObserverDll').read_bytes()==(S/'EarlyTerminal.dll').read_bytes())
check('no_join_in_original_native_owner','MsiJoinTransaction' not in owner)
check('begin_install_end_close_same_main_native_thread',owner.count('int WINAPI wWinMain(')==1 and not any(x in owner for x in ('CreateThread(', '_beginthread', 'CreateProcess', 'TerminateProcess(', 'TerminateThread(')) and owner.index('!ack()')<owner.index('UINT begin=begin_fn(')<owner.index('install=MsiInstallProductW(')<owner.index('end=end_fn(state)')<owner.index('msi_close=MsiCloseHandle(transaction)'))
check('record_native_actual_return_without_coercion','end=end_fn(state);emit("END_RETURN",end,TRUE,transaction);' in owner and 'emit(uninstall?"CONFIGURE_ABSENT_RETURN":"INSTALL_RETURN",install,TRUE,transaction);' in owner)
check('msi_event_and_journal_one_close_attempt',owner.count('MsiCloseHandle(transaction)')==1 and owner.count('CloseHandle(change)')==1 and 'return before_close&&file_close&&change_close&&(begin==0?(transaction!=0&&msi_close==0):(transaction==0&&change==NULL))?0:76;' in owner)
check('no_install_invalid_begin_outputs_no_close_unowned_outputs','if(transaction==0||change==NULL)' in owner and 'BEGIN_OUTPUT_INVALID_NO_INSTALL' in owner and 'if(begin==ERROR_SUCCESS&&transaction!=0)' in owner and 'if(begin==ERROR_SUCCESS&&change!=NULL)' in owner)
check('absence_requires_actual_no_product_cache','localPackageRc-eq 1605' in driver)
check('ack_original_process_and_thread_before_begin','HoldStartedClient($original' in driver and driver.index('$thread=$capture.HoldThread(')<driver.index("($name+'.capture-ack')") and 'ORIGINAL_OWNER_LIVE_BEFORE_ACK' in driver)
check('same_original_thread_journal_checked','SAME_ORIGINAL_NATIVE_THREAD_SEQUENCE_REQUIRED' in driver and 'ORIGINAL_PROCESS_THREAD_PHYSICAL_RETURN_REQUIRED' in driver)
check('finite_driver_gates_preserve_unknown','-lt 300000' in driver and '-lt 120000' in driver and '-lt 600000' in driver and 'ORIGINAL_OWNER_120S_UNKNOWN_RETAIN' in driver and 'ACTUAL_BEGIN_END_OR_CLOSE_NEGATIVE_RETAIN_NO_NEW_MSI' in driver)
check('controlled_owned_uninstall_only','NO_UNINSTALL_WITHOUT_THIS_ATTEMPT_COMMIT_PROVENANCE' in driver and 'EXACT_OWNED_PRODUCT_ONLY' in driver and "foreach($name in @('early-fail-rollback','healthy-rollback','healthy-commit','owned-uninstall'))" in driver)
check('no_callback_derived_production_authority','Capture-Native' not in driver and "authority='NO_PRODUCTION_AUTHORITY'" in driver and 'NO_PRODUCTION_AUTHORITY' in driver)
check('protected_current_user_system_inputs','EXACT_TWO_ACES' in driver and 'DISTINCT_USER_SYSTEM' in driver and 'EXACT_INPUT_CLOSURE' in driver and 'INPUT_BYTES_CHANGED' in driver)
check('stdout_result_explicit_and_terminal_return','$result|ConvertTo-Json -Depth 60 -Compress' in driver and 'exit 0}else{exit 90}' in driver)
report=dict(schemaVersion=1,status='PASS_FINITE_SOURCE_ADMISSION_CONTROLLED_OWNER_EXPERIMENT_ONLY',
    scope='Read-only independent review of final second preparation Owner.c, driver, local producer, first actual build and staged byte provenance. Does not execute Windows or grant production repair authority.',
    authorFreeze=fact(P/'freeze-second.json'),
    inputs={name:fact(P/name) for name in ('Owner.c','Invoke-ControlledOwner.ps1','build.py','Capture.cs','EarlyTerminal.c')},
    stageManifest=fact(S/'runtime-inputs.json'),buildReport=fact(B/'build-report.json'),
    checkCount=len(checks),checks=checks,windows='NOT_CONTACTED_BY_REVIEWER',runtime='NOT_RUN_BY_REVIEWER',
    manualReview=[
        'A fresh native GUI owner is created with original process and main-thread capabilities captured and checked live before the nonce ACK. The same native thread then calls actual Begin, synchronous Install/Configure, End, MsiCloseHandle and event close.',
        'Actual End return after Install 1603 is retained verbatim. Neither Begin-owned nor End0 is assumed. Negative API/close result stops later MSI cases and requires retention.',
        'Original process/thread exit and checked close are required separately from API journal intent. Exit0 means journal and owned native resources returned; it does not itself mean Install or End succeeded.',
        'Old observer DLL actions remain measurements only; there is no embedded chainer or callback-driven settlement in this experiment.',
        'Four fixed runs produce at most four original process plus four thread capabilities; no production Pending or owner permit is manufactured.',
        'The 120 second observer deadline does not forcibly bound a blocked synchronous native API; timeout is UNKNOWN and must retain originals. No cancellation kill or automatic uninstall is allowed on an unknown path.',
        'ownedCommitOutstanding is diagnostic only: if COMMIT actually succeeds and a later native resource close fails, the driver can leave this false. Any FAIL/unknown must retain the root and product regardless of this boolean.'
    ],
    pending=['Parent transport admission/freeze review','Actual Windows Begin→Install1603→End return and checked-resource/physical-exit evidence','Independent post-run effects and exact-path cleanup proof'],
    productionAuthority='UNPROVEN_NOT_GRANTED',mayMergeRepairCandidate=False,mayDeployDamagedRepair=False)
(O/'source-review-first.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=report['status'],checks=len(checks),stageManifestSha256=report['stageManifest']['sha256'])))
