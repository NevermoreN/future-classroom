from pathlib import Path
import ast,hashlib,json,re,sys
if __name__=='__main__' and '--execute-derive' not in sys.argv:
 print(json.dumps(dict(status='NOT_RUN_PREPARATION_ONLY',scope='Internal derivation helper; root runtime uses reviewed controllers.')));raise SystemExit(0)
D=Path('/tmp/fc-round79-msi-maintenance/package-preparation-first');O=D/'originals'
CURRENT='c44906517fbc62233dca755d7225cea375264cbc';SOURCE='261c58aca8b0f63ff2cfb4dbd5e85c0d17770005'
def base(s):
 return s.replace('/tmp/fc-round78-ci-evidence','/tmp/fc-round79-msi-maintenance').replace('package-source-preparation-first','package-preparation-first').replace('future-classroom-owned-r78-ci-evidence/v1','future-classroom-owned-r79-msi-maintenance/v1').replace('future-classroom-owned-r78-package-source-preparation/v1','future-classroom-owned-r79-package-preparation/v1').replace('future-classroom-owned-r78-','future-classroom-owned-r79-').replace('EXACT_R78','EXACT_R79').replace('OWNED_R78','OWNED_R79').replace('R78','R79')
def put(n,s):ast.parse(s);(D/n).write_text(s)
s=base((O/'ci-admission-preparation-first/verify-ci-artifact-dual-gui-first.py').read_text());s=s.replace("from __future__ import annotations", "from __future__ import annotations\nfrom source_binding import current_source_guard,CURRENT_MAIN")
s=s.replace("    def official(self):\n        a=self.args", "    def official(self):\n        self.report['currentMainInputBinding']=current_source_guard()\n        self.report['currentMainHead']=CURRENT_MAIN\n        a=self.args")
put('verify-ci-artifact-dual-gui-first.py',s);audit_sha=hashlib.sha256((D/'verify-ci-artifact-dual-gui-first.py').read_bytes()).hexdigest()
s=base((O/'ci-admission-preparation-first/ci-inputs-first.py').read_text());s=s.replace("sys.dont_write_bytecode=True", "sys.dont_write_bytecode=True\nfrom source_binding import current_source_guard,CURRENT_MAIN")
s=re.sub(r"AUDITOR_SHA='[0-9a-f]{64}'", "AUDITOR_SHA='"+audit_sha+"'",s)
s=s.replace("future-classroom-owned-r79-ci-admission-preparation/v1", "future-classroom-owned-r79-package-preparation/v1")
s=s.replace("    boot();cfg=CONFIG[a.baseline]", "    boot();current=current_source_guard();cfg=CONFIG[a.baseline]\n    need(a.baseline=='win7' and a.run_id==41332469102 and a.artifact_id==13094372286 and a.zip_bytes==46196057 and a.zip_sha256=='bf6d7fcc24056235e7720d2de055cc74d71e799a30ab76ec8c90772e41dd1a8c','EXACT_REUSED_ORIGINAL_WIN7_ARTIFACT')\n    need(a.zip==E/'win7-official-first.zip','EXACT_R79_ROOT_OFFICIAL_ZIP')")
s=s.replace("return dict(sourceSha=a.source_sha,baseline=", "return dict(currentMainHead=CURRENT_MAIN,currentMainInputBinding=current,originalCompiledSourceSha=SOURCE_SHA,sourceSha=a.source_sha,baseline=")
put('ci-inputs-first.py',s)
s=base((O/'package-source-preparation-first/source_gate.py').read_text());s=s.replace("import argparse, hashlib, json, re, stat", "import argparse, hashlib, json, re, stat\nfrom source_binding import current_source_guard,CURRENT_MAIN")
s=s.replace("def gate(a):\n", "def gate(a):\n    current=current_source_guard()\n")
s=s.replace("return audit,dict(gateHelper=", "return audit,dict(currentMainHead=CURRENT_MAIN,currentMainInputBinding=current,originalCompiledSourceSha=SOURCE,gateHelper=")
put('source_gate.py',s)
for name in ['create-checkout-first.py','build-web-first.py','build-probe-first.py','build-msi-first.py']:
 s=base((O/'package-source-preparation-first'/name).read_text())
 if name=='create-checkout-first.py':
  s=s.replace('from source_gate import parser, gate, describe','from source_gate import parser, gate, describe\nfrom source_binding import CURRENT_MAIN')
  s=s.replace("need(git('rev-parse','HEAD').decode().strip()==SOURCE and", "need(git('rev-parse','HEAD').decode().strip()==CURRENT_MAIN and")
  s=s.replace("status='RUNNING',sourceSha=SOURCE", "status='RUNNING',currentMainHead=CURRENT_MAIN,originalCompiledSourceSha=SOURCE,sourceSha=SOURCE")
 elif name=='build-msi-first.py':
  s=s.replace('from source_gate import parser,gate,describe','from source_gate import parser,gate,describe\nfrom source_binding import CURRENT_MAIN')
  s=s.replace("git('rev-parse','HEAD',root=ORIGINAL_MAIN).decode().strip()==SOURCE", "git('rev-parse','HEAD',root=ORIGINAL_MAIN).decode().strip()==CURRENT_MAIN")
  s=s.replace("status='NOT_RUN_BLOCKED',sourceSha=SOURCE", "status='NOT_RUN_BLOCKED',currentMainHead=CURRENT_MAIN,originalCompiledSourceSha=SOURCE,sourceSha=SOURCE")
 put(name,s)
# Exact unchanged original package pins; derive only ownership/source guard root.
TD=D/'msi-tools-preparation-first';TD.mkdir();(TD/'.owner').write_text('future-classroom-owned-r79-msi-tools-preparation/v1\n')
c=json.loads((O/'msi-tools-preparation-first/msi-tools-input-first.json').read_bytes());old_c=json.loads(json.dumps(c));c['scope']='R79 exact original R78 package and ELF pins; separate current-main c449 guard and original261 compiler source. Execution NOT_RUN.';c['toolsRoot']=str(D/'tools');c['originalCompiledSourceSha']=SOURCE;c['currentMainHead']=CURRENT;c['sourceGuard']['commit']=CURRENT
cp=TD/'msi-tools-input-first.json';cp.write_text(json.dumps(c,indent=2)+'\n');csha=hashlib.sha256(cp.read_bytes()).hexdigest();assert c['packages']==old_c['packages'] and c['expectedTools']==old_c['expectedTools']
for name in ['run-msi-tools-first.py','download-msi-tool-first.py','prepare-msi-tools-local-first.py']:
 s=base((O/'msi-tools-preparation-first'/name).read_text());s=s.replace("ROOT / 'msi-tools-preparation-first'","ROOT / 'package-preparation-first/msi-tools-preparation-first'")
 s=s.replace("ROOT / 'tools'","ROOT / 'package-preparation-first/tools'").replace("ROOT/'tools'","ROOT/'package-preparation-first/tools'").replace("ROOT / 'tools/.owner'","ROOT / 'package-preparation-first/tools/.owner'").replace("ROOT / 'tools/packages'","ROOT / 'package-preparation-first/tools/packages'")
 s=s.replace('/tmp/fc-round79-msi-maintenance/tools','/tmp/fc-round79-msi-maintenance/package-preparation-first/tools')
 s=s.replace('38713cb9d14ab06e3bd54ee38e1e85cfe15ab01e96c3d0ae75b44bc625d67f1c',csha)
 if name=='run-msi-tools-first.py':
  s=s.replace("COMMIT = '"+SOURCE+"'", "COMMIT = '"+CURRENT+"'\nORIGINAL_COMPILED_SOURCE = '"+SOURCE+"'\nimport sys\nsys.path.insert(0,str(E.parent))\nfrom source_binding import current_source_guard")
  s=s.replace("def frozen():\n", "def frozen():\n    current_source_guard()\n")
  s=s.replace("'sourceCommit': COMMIT,", "'sourceCommit': COMMIT, 'originalCompiledSourceSha':ORIGINAL_COMPILED_SOURCE,")
 ast.parse(s);(TD/name).write_text(s)
print(json.dumps(dict(auditorSha256=audit_sha,toolConfigSha256=csha)))
