"""Separate current main provenance from the actual older CI compiler source."""
from pathlib import Path
import argparse,hashlib,json,os,stat,subprocess
E=Path('/tmp/fc-round79-msi-maintenance');D=E/'package-preparation-first'
MAIN=Path('/workspace/共享/Eliora/未来教室计划')
SOURCE='261c58aca8b0f63ff2cfb4dbd5e85c0d17770005'
CURRENT_MAIN='c44906517fbc62233dca755d7225cea375264cbc'
def need(v,c):
 if not v:raise AssertionError(c)
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(MAIN),*args],timeout=30)
def selection(tree):
 result={}
 for record in tree.split(b'\0'):
  if not record:continue
  meta,name=record.split(b'\t',1);n=name.decode();mode,kind,oid=meta.decode().split()
  if n.startswith(('crates/','scripts/','web/','.cargo/')) or n in ('Cargo.toml','Cargo.lock'):
   need(kind=='blob' and mode in ('100644','100755'),'SELECTED_REGULAR_GIT_SOURCE');result[n]=oid
 return result
def current_source_guard():
 need((E/'.owner').read_bytes()==b'future-classroom-owned-r79-msi-maintenance/v1\n','EXACT_R79_OWNER')
 need((D/'.owner').read_bytes()==b'future-classroom-owned-r79-package-preparation/v1\n','EXACT_PACKAGE_PREPARATION_OWNER')
 need(git('rev-parse','HEAD').decode().strip()==CURRENT_MAIN,'EXACT_CURRENT_MAIN_HEAD')
 need(git('status','--porcelain','-z','--untracked-files=all')==b'','MAIN_CLEAN')
 old=selection(git('ls-tree','-r','-z','--full-tree',SOURCE));now=selection(git('ls-tree','-r','-z','--full-tree',CURRENT_MAIN))
 need(len(old)==len(now)==544 and old==now,'EXACT_544_CURRENT_AND_ORIGINAL_COMMIT_BLOB_DOMAIN')
 child=subprocess.Popen(['git','-C',str(MAIN),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);rows=[];total=0
 try:
  for n,oid in sorted(old.items()):
   p=MAIN/n;need(stat.S_ISREG(p.lstat().st_mode) and not any(q.is_symlink() for q in (p,*p.parents) if q==MAIN or MAIN in q.parents),'NONALIASED_REGULAR_MAIN_SOURCE')
   child.stdin.write((oid+'\n').encode());child.stdin.flush();header=child.stdout.readline().split();need(len(header)==3 and header[0].decode()==oid and header[1]==b'blob','ORIGINAL_GIT_BLOB_HEADER');size=int(header[2]);need(0<=size<=64*1024*1024,'SOURCE_PER_FILE_64MIB_BOUND');b=child.stdout.read(size);need(len(b)==size and child.stdout.read(1)==b'\n','COMPLETE_ORIGINAL_GIT_BLOB');need(hashlib.sha1(b'blob '+str(size).encode()+b'\0'+b).hexdigest()==oid,'ACTUAL_GIT_BLOB_OID');need(p.read_bytes()==b,'CURRENT_MAIN_RAW_BYTES_EQUAL_ITS_AND_ORIGINAL_GIT_BLOB_'+n)
   total+=len(b);need(total<=256*1024*1024,'SOURCE_TOTAL_256MIB_BOUND');rows.append(dict(path=n,bytes=len(b),sha256=sha(b),currentGitBlobOidSha1=oid,originalCiSourceGitBlobOidSha1=oid))
 finally:
  child.stdin.close();code=child.wait(timeout=30);need(code==0,'ORIGINAL_GIT_BATCH_REAPED_EXIT0')
 return dict(status='PASS_CURRENT_544_GIT_BLOBS_AND_WORKING_BYTES_IDENTICAL_TO_ORIGINAL_CI_SOURCE_ONLY',currentMainHead=CURRENT_MAIN,originalCompiledSourceSha=SOURCE,selectedCount=544,totalBytes=total,rows=rows,rawCiCheckout='NOT_REPLACED_BY_GIT_BLOB_COMPARISON_REQUIRES_ACTUAL_CI_INVENTORY_AND_WT',historicalMetadata='Current main and old compiler source have different complete historical Git trees; no whole-commit/source relabelling.')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--check-only',action='store_true');a=p.parse_args()
 if not a.check_only:print(json.dumps(dict(status='NOT_RUN_PREPARATION_ONLY',currentMainHead=CURRENT_MAIN,compiledSourceSha=SOURCE)))
 else:print(json.dumps(current_source_guard()))
