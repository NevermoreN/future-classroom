"""R79 terminal original CI gate and exact dual-GUI static audit invocation.
Preparation only unless --execute-static. No network/download/product execution.
No ZIP access until the CI, download receipt and download parent are terminal.
"""
from pathlib import Path
import argparse, datetime, hashlib, json, re, subprocess, sys, time
sys.dont_write_bytecode=True
from source_binding import current_source_guard,CURRENT_MAIN
D=Path(__file__).resolve().parent;E=D.parent
REPO=Path('/workspace/共享/Eliora/未来教室计划')
AUDITOR=D/'verify-ci-artifact-dual-gui-first.py'
AUDITOR_SHA='949b4f7d0b62391bc1d78fbdfe4823b24656360fed95765371e6c1bd811f62fe'
SOURCE_SHA='261c58aca8b0f63ff2cfb4dbd5e85c0d17770005'
RUN_IDS={'modern':41332456981,'win7':41332469102}
CONFIG={'modern':dict(baseline='Modern',workflow='.github/workflows/windows-msvc.yml',job='compile-i686',prefix='future-classroom-msvc'),
        'win7':dict(baseline='Win7',workflow='.github/workflows/windows-win7-msvc.yml',job='compile-win7-i686',prefix='future-classroom-win7-msvc')}
class Waiting(Exception):pass
class Invalid(Exception):pass
def need(v,c):
    if not v:raise Invalid(c)
def sha(b):return hashlib.sha256(b).hexdigest()
def scoped(path):
    p=Path(path);need(p.resolve().is_relative_to(E.resolve()) and not any(x.is_symlink() for x in [p,*p.parents] if x==E or E in x.parents),'R79_INPUT_SCOPE_REGULAR')
    need(p.suffix.lower() not in {'.key','.pfx','.p12'},'PRIVATE_CONTENT_FORBIDDEN');return p
def fact(path):
    p=scoped(path)
    if not p.is_file():raise Waiting('MISSING_'+p.name)
    h=hashlib.sha256();size=0
    with p.open('rb') as f:
        while data:=f.read(1024*1024):h.update(data);size+=len(data)
    return dict(path=str(p),bytes=size,sha256=h.hexdigest())
def read(path):
    p=scoped(path)
    if not p.is_file():raise Waiting('MISSING_'+p.name)
    try:v=json.loads(p.read_text(encoding='utf-8-sig'))
    except (ValueError,UnicodeError):raise Waiting('INCOMPLETE_'+p.name) from None
    if isinstance(v,dict) and v.get('status') in ('RUNNING','STARTED','queued','in_progress','pending','waiting','requested','OBSERVATION_INTERRUPTED_NOT_COMPLETION'):raise Waiting('NONTERMINAL_'+p.name)
    return v
def api(path):
    v=read(path)
    if isinstance(v,dict):need(v.get('isError') is not True,'API_WRAPPER_ERROR');v=v.get('structuredContent',v)
    if isinstance(v,dict) and isinstance(v.get('content'),str):
        try:v=json.loads(v['content'])
        except ValueError:raise Waiting('INCOMPLETE_API_CONTENT') from None
    return v
def exact(row):
    v=fact(row['path']);need(v['sha256']==row['sha256'] and ('bytes' not in row or v['bytes']==row['bytes']),'EXACT_REOPENED_INPUT');return v
def command_value(cmd,flag,value):need(cmd.count(flag)==1 and cmd.index(flag)+1<len(cmd) and cmd[cmd.index(flag)+1]==str(value),'ORIGINAL_COMMAND_'+flag)
def add_inputs(p):
    p.add_argument('--source-sha',required=False);p.add_argument('--baseline',choices=CONFIG,required=False)
    for n in ('run-id','job-id','artifact-id','zip-bytes'):p.add_argument('--'+n,type=int,required=False)
    p.add_argument('--zip-sha256',required=False)
    for n in ('zip','run-metadata','job-metadata','artifact-metadata','download-receipt','download-operation'):p.add_argument('--'+n,type=Path,required=False)
    p.add_argument('--download-receipt-sha256',required=False);p.add_argument('--download-operation-sha256',required=False)
def boot():
    need((E/'.owner').read_bytes()==b'future-classroom-owned-r79-msi-maintenance/v1\n','EXACT_R79_OWNER')
    need((D/'.owner').read_bytes()==b'future-classroom-owned-r79-package-preparation/v1\n','EXACT_PREPARATION_OWNER')
    need(fact(AUDITOR)['sha256']==AUDITOR_SHA,'RETAINED_SECOND_AUDITOR_EXACT')
def terminal_download(a):
    boot();current=current_source_guard();cfg=CONFIG[a.baseline]
    need(a.baseline=='win7' and a.run_id==41332469102 and a.artifact_id==13094372286 and a.zip_bytes==46196057 and a.zip_sha256=='bf6d7fcc24056235e7720d2de055cc74d71e799a30ab76ec8c90772e41dd1a8c','EXACT_REUSED_ORIGINAL_WIN7_ARTIFACT')
    need(a.zip==E/'win7-official-first.zip','EXACT_R79_ROOT_OFFICIAL_ZIP')
    need(a.source_sha==SOURCE_SHA and re.fullmatch('[0-9a-f]{64}',a.zip_sha256),'EXACT_R79_SOURCE_AND_EXPLICIT_ZIP_SHA')
    need(a.run_id==RUN_IDS[a.baseline],'EXACT_SINGLE_DISPATCH_R79_RUN')
    need(all(type(v) is int and v>0 for v in (a.run_id,a.job_id,a.artifact_id,a.zip_bytes)) and a.zip_bytes<=512*1024*1024,'EXPLICIT_FINITE_IDS_ZIP_SIZE')
    run=api(a.run_metadata);jobs=api(a.job_metadata);arts=api(a.artifact_metadata)
    if run.get('status')!='completed':raise Waiting('OFFICIAL_RUN_NOT_TERMINAL')
    need(run.get('conclusion')=='success' and run.get('id')==a.run_id and run.get('head_sha')==a.source_sha and run.get('path')==cfg['workflow'] and run.get('event')=='workflow_dispatch','SUCCESSFUL_EXACT_OFFICIAL_RUN')
    jobs=jobs.get('jobs',jobs) if isinstance(jobs,dict) else jobs;need(isinstance(jobs,list),'OFFICIAL_JOB_LIST')
    selected=[v for v in jobs if v.get('id')==a.job_id];need(len(selected)==1,'UNIQUE_EXACT_JOB');job=selected[0]
    if job.get('status')!='completed':raise Waiting('OFFICIAL_JOB_NOT_TERMINAL')
    need(job.get('run_id')==a.run_id and job.get('name')==cfg['job'] and job.get('conclusion')=='success','SUCCESSFUL_EXACT_JOB')
    arts=arts.get('artifacts',arts) if isinstance(arts,dict) else arts;arts=[arts] if isinstance(arts,dict) else arts;need(isinstance(arts,list),'OFFICIAL_ARTIFACT_LIST')
    selected=[v for v in arts if v.get('id')==a.artifact_id];need(len(selected)==1,'UNIQUE_EXACT_ARTIFACT');art=selected[0];attempt=run.get('run_attempt')
    need(type(attempt) is int and attempt==1 and art.get('expired') is False and art.get('size_in_bytes')==a.zip_bytes and art.get('digest')=='sha256:'+a.zip_sha256 and art.get('workflow_run',{}).get('id')==a.run_id and art['workflow_run'].get('head_sha')==a.source_sha and art.get('name')==f"{cfg['prefix']}-i686-{a.source_sha}-{a.run_id}-{attempt}",'EXACT_ARTIFACT_SOURCE_ZIP_DIGEST')
    receipt=read(a.download_receipt);op=read(a.download_operation)
    need(fact(a.download_receipt)['sha256']==a.download_receipt_sha256 and fact(a.download_operation)['sha256']==a.download_operation_sha256,'EXPLICIT_TERMINAL_DOWNLOAD_ORIGINALS')
    need(receipt.get('status')=='PASS' and receipt.get('sourceSha')==a.source_sha and receipt.get('runId')==a.run_id and receipt.get('artifactId')==a.artifact_id and receipt.get('expectedBytes')==receipt.get('bytes')==a.zip_bytes and receipt.get('expectedSha256')==receipt.get('sha256')==a.zip_sha256,'ACTUAL_TERMINAL_DOWNLOAD_RECEIPT')
    need(op.get('status') in ('PASS','PASS_COMMAND') and op.get('exitCode')==0 and op.get('actualExit') is True,'ACTUAL_DOWNLOAD_PARENT_EXIT0')
    cmd=op.get('command',op.get('args'));need(isinstance(cmd,list),'ORIGINAL_DOWNLOAD_COMMAND')
    for flag,value in (('--source-sha',a.source_sha),('--baseline',a.baseline),('--run-id',a.run_id),('--artifact-id',a.artifact_id),('--expected-bytes',a.zip_bytes),('--expected-sha256',a.zip_sha256)):command_value(cmd,flag,value)
    for key in ('stdout','stderr'):
        if isinstance(op.get(key),dict) and 'path' in op[key]:exact(op[key])
    # Whole ZIP is opened only here: both download originals and official CI
    # have already physically completed successfully, not a running candidate.
    z=fact(a.zip);need(z['bytes']==a.zip_bytes and z['sha256']==a.zip_sha256,'WHOLE_TERMINAL_ZIP_EXACT')
    return dict(currentMainHead=CURRENT_MAIN,currentMainInputBinding=current,originalCompiledSourceSha=SOURCE_SHA,sourceSha=a.source_sha,baseline=a.baseline,runId=a.run_id,jobId=a.job_id,artifactId=a.artifact_id,zip=z,downloadReceipt=fact(a.download_receipt),downloadOperation=fact(a.download_operation),officialMetadata=[fact(v) for v in (a.run_metadata,a.job_metadata,a.artifact_metadata)])
def audit_command(a):
    return ['python3','-B',str(AUDITOR),'--execute','--source',a.source_sha,'--baseline',CONFIG[a.baseline]['baseline'],'--zip',str(a.zip),'--zip-bytes',str(a.zip_bytes),'--zip-sha256',a.zip_sha256,'--run-id',str(a.run_id),'--job-id',str(a.job_id),'--artifact-id',str(a.artifact_id),'--run-metadata',str(a.run_metadata),'--job-metadata',str(a.job_metadata),'--artifact-metadata',str(a.artifact_metadata),'--output-dir',str(a.output_dir),'--report',str(a.static_audit),'--repo',str(REPO)]
def main():
    p=argparse.ArgumentParser(description=__doc__);add_inputs(p);p.add_argument('--output-dir',type=Path,required=False);p.add_argument('--static-audit',type=Path,required=False);p.add_argument('--static-operation',type=Path,required=False);p.add_argument('--execute','--execute-static',dest='execute_static',action='store_true');a=p.parse_args()
    if not a.execute_static:
        print(json.dumps(dict(status='NOT_RUN_PREPARATION_ONLY',sourceSha=SOURCE_SHA,runIds=RUN_IDS,expectedZipPaths={k:str(E/(k+'-official-first.zip')) for k in CONFIG},scope='No metadata or ZIP opened; no output tree created; no network, executable or Windows action. Explicit --execute is required.')));return 0
    for key,value in vars(a).items():
        if key!='execute_static' and value is None:p.error('--'+key.replace('_','-')+' is required for execution')
    try:
        bound=terminal_download(a);cmd=audit_command(a)
        for path in (a.output_dir,a.static_audit,a.static_operation):scoped(path);need(not path.exists(),'EXCLUSIVE_FRESH_STATIC_OUTPUTS')
        need(a.output_dir.resolve().is_relative_to(D) and a.static_audit.parent.resolve().is_relative_to(D),'RETAINED_AUDITOR_OUTPUT_SCOPE_IS_PREPARATION_SUBDIRECTORY')
        stdout=a.static_operation.with_suffix('.stdout.log');stderr=a.static_operation.with_suffix('.stderr.log');need(not stdout.exists() and not stderr.exists(),'EXCLUSIVE_STATIC_CAPTURE')
        result=dict(status='RUNNING',command=cmd,inputs=bound,startedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        with a.static_operation.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
        began=time.monotonic();code=None
        try:
            with stdout.open('xb') as out,stderr.open('xb') as err:
                child=subprocess.Popen(cmd,cwd=REPO,stdout=out,stderr=err);result['pid']=child.pid;code=child.wait()
            result.update(exitCode=code,actualExit=True,elapsedSeconds=time.monotonic()-began,stdout=fact(stdout),stderr=fact(stderr))
            audit=read(a.static_audit);result['actualReport']=fact(a.static_audit);need(code==0 and audit['status']=='PASS_STATIC_ONLY_RUNTIME_NOT_RUN','ACTUAL_STATIC_AUDITOR_EXIT_AND_PASS');result['status']='PASS_STATIC_AUDITOR_ACTUAL_EXIT0'
        except Exception as err:result.update(status='FAIL_STATIC_COMMAND_OR_EVIDENCE',exitCode=code,elapsedSeconds=time.monotonic()-began,error=dict(kind=type(err).__name__,code=str(err) if isinstance(err,Invalid) else 'LOCAL_STATIC_INPUT_OR_TOOL_FAILURE'))
        a.static_operation.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],operation=fact(a.static_operation))));return 0 if result['status']=='PASS_STATIC_AUDITOR_ACTUAL_EXIT0' else 1
    except Waiting as err:print(json.dumps(dict(status='WAIT',reasonCode=str(err),reportCreated=False,zipAccessed=False)));return 3
    except Invalid as err:print(json.dumps(dict(status='BLOCKED_INVALID_INPUT',reasonCode=str(err),reportCreated=False)));return 1
if __name__=='__main__':raise SystemExit(main())
