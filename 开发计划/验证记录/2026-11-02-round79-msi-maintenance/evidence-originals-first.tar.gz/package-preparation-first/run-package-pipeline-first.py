"""Run reviewed local checkout/Web/probe/MSI steps only after actual CI admission."""
from pathlib import Path
import argparse,datetime,hashlib,json,subprocess,time
E=Path('/tmp/fc-round79-msi-maintenance');D=E/'package-preparation-first';A=D
from source_binding import SOURCE,CURRENT_MAIN,current_source_guard
def fact(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def main():
 p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');p.add_argument('--accepted-static-report-sha256');p.add_argument('--stage-receipt-sha256');p.add_argument('--tools-report-sha256');a=p.parse_args()
 if not a.execute:print(json.dumps({'status':'NOT_RUN_PREPARATION_ONLY'}));return 0
 assert (E/'.owner').read_bytes()==b'future-classroom-owned-r79-msi-maintenance/v1\n'
 current=current_source_guard();stage_path=D/'stage-original-build-first.json';assert fact(stage_path)['sha256']==a.stage_receipt_sha256;stage=json.loads(stage_path.read_bytes());assert stage['status']=='PASS_COMPLETE_ORIGINAL_BUILD_NAMESPACE_NOT_PRODUCT_RUNTIME' and stage['sourceSha']==SOURCE and stage['currentMainHead']==CURRENT_MAIN
 audit=A/'win7-static-audit-first.json';raw=D/'win7-build-original-first';wt=D/'checkout-261c58a-first'
 assert fact(audit)['sha256']==a.accepted_static_report_sha256==stage['auditSha256']
 tools=D/'msi-tools-preparation-first/msi-tools-preparation-first.json';assert fact(tools)['sha256']==a.tools_report_sha256;assert json.loads(tools.read_bytes())['status']=='PASS_EXACT_PACKAGES_LOCAL_EXTRACTION_ELF_BINDING_AND_SCOPED_TOOL_LOADING_ONLY'
 common=['--execute','--source-sha',SOURCE,'--accepted-static-report',str(audit),'--accepted-static-report-sha256',fact(audit)['sha256'],'--raw',str(raw),'--run-id','41332469102']
 output=D/'package-pipeline-first.json';assert not output.exists()
 r={'status':'RUNNING','sourceSha':SOURCE,'currentMainHead':CURRENT_MAIN,'currentMainInputBinding':current,'scope':'Reviewed local-only source checkout, Web build, probe ZIP, and candidate MSI static build. No Windows, product/installer execution, or release.','startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[]};output.write_text(json.dumps(r,indent=2)+'\n')
 def run(name,args):
  cmd=['python3','-B',str(D/(name+'-first.py')),*common,*args];out=D/('package-'+name+'-first.stdout.log');err=D/('package-'+name+'-first.stderr.log');assert not out.exists() and not err.exists()
  assert current_source_guard()==current
  item={'name':name,'command':cmd,'status':'RUNNING'};r['steps'].append(item);output.write_text(json.dumps(r,indent=2)+'\n');start=time.monotonic();print('START '+name,flush=True)
  with out.open('xb') as so,err.open('xb') as se:
   child=subprocess.Popen(cmd,stdout=so,stderr=se);item['pid']=child.pid;output.write_text(json.dumps(r,indent=2)+'\n');code=child.wait()
  item.update(status='PASS_COMMAND' if code==0 else 'FAIL_COMMAND',actualExit=True,exitCode=code,elapsedSeconds=time.monotonic()-start,stdout=fact(out),stderr=fact(err));output.write_text(json.dumps(r,indent=2)+'\n');print('DONE '+name+' exit='+str(code),flush=True);assert code==0,name;assert current_source_guard()==current
 try:
  run('create-checkout',[]);checkout=D/'actual-checkout-first.json';c=json.loads(checkout.read_bytes());assert c['status']=='PASS_ACTUAL_CI_CHECKOUT_BYTES_EXACT'
  extra=['--checkout-proof-sha256',fact(checkout)['sha256']]
  run('build-web',extra);web=D/'web-build-first/build-report-first.json'
  run('build-probe',extra+['--web-report',str(web),'--web-report-sha256',fact(web)['sha256']]);probe=D/'local-probe-first/producer-first.json';z=D/'local-probe-first/FutureClassroom-0.1.0-windows-x86-dev.zip'
  tools=D/'msi-tools-preparation-first/msi-tools-preparation-first.json';helper=raw/'product/fc-bootstrap/fc-installer-lifecycle.exe';obj=Path('/usr/bin/i686-w64-mingw32-objdump')
  args=['--input-zip',str(z),'--input-sha256',fact(z)['sha256'],'--build-evidence',str(raw),'--lifecycle-helper',str(helper),'--lifecycle-helper-sha256',fact(helper)['sha256'],'--build-result-sha256',fact(raw/'result.json')['sha256'],'--local-probe-receipt',str(probe),'--local-probe-receipt-sha256',fact(probe)['sha256'],'--checkout-script-sha256',c['scriptCheckout']['sha256'],'--checkout-script-blob-sha256',c['scriptGitBlobContentSha256'],'--objdump',str(obj),'--objdump-sha256',fact(obj)['sha256'],'--tools-report',str(tools),'--tools-report-sha256',fact(tools)['sha256'],'--output-dir',str(D/'candidate-output-first'),'--report',str(D/'package-build-first.json')]
  run('build-msi',args);package=json.loads((D/'package-build-first.json').read_bytes());assert package['status']=='PASS_LOCAL_PRODUCT_MSI_STATIC_ONLY_WINDOWS_NOT_RUN'
  r.update(status='PASS_LOCAL_PACKAGE_PIPELINE_MSI_RUNTIME_NOT_RUN',packageReceipt=fact(D/'package-build-first.json'))
 except Exception as error:r.update(status='FAIL_RETAIN_ORIGINALS_NO_WINDOWS_ACTION',errorType=type(error).__name__,error=str(error))
 output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k) for k in ('status','errorType','error')}));return 0 if r['status'].startswith('PASS_') else 1
if __name__=='__main__':raise SystemExit(main())
