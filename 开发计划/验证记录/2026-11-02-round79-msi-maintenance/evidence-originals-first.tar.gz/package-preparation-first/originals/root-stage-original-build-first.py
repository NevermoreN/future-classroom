"""Create complete original ZIP namespace for packaging; auditor splits EXE/raw."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,zipfile
E=Path('/tmp/fc-round78-ci-evidence');D=E/'ci-admission-preparation-first'
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');a=p.parse_args()
 if not a.execute:print(json.dumps({'status':'NOT_RUN_PREPARATION_ONLY'}));return 0
 assert (E/'.owner').read_bytes()==b'future-classroom-owned-r78-ci-evidence/v1\n'
 audit_path=D/'win7-static-audit-first.json';audit=json.loads(audit_path.read_bytes());assert audit['status']=='PASS_STATIC_ONLY_RUNTIME_NOT_RUN' and audit['sourceSha']=='261c58aca8b0f63ff2cfb4dbd5e85c0d17770005' and audit['runId']==41332469102
 op=json.loads((D/'win7-static-operation-first.json').read_bytes());assert op['status']=='PASS_STATIC_AUDITOR_ACTUAL_EXIT0' and op['actualExit'] is True and op['exitCode']==0 and op['actualReport']['sha256']==sha(audit_path.read_bytes())
 archive=E/'win7-official-first.zip';b=archive.read_bytes();assert len(b)==audit['zip']['bytes'] and sha(b)==audit['zip']['sha256']
 rows={r['path']:r for r in audit['members']};assert len(rows)==len(audit['members'])<=512
 dest=E/'win7-build-original-first';report=E/'root-stage-original-build-first.json';assert not dest.exists() and not report.exists()
 result={'status':'RUNNING','scope':'Re-extract exact complete original official ZIP namespace; audit raw omits PE and programs contains those PE. No rewritten metadata, Cargo, Windows or product execution.','auditSha256':sha(audit_path.read_bytes()),'zip':audit['zip'],'destination':str(dest),'files':[]};report.write_text(json.dumps(result,indent=2)+'\n')
 try:
  with zipfile.ZipFile(archive) as z:
   assert len(z.infolist())==len(rows) and len(set(z.namelist()))==len(rows) and set(z.namelist())==set(rows) and z.testzip() is None
   assert sum(i.file_size for i in z.infolist())<=512*1024*1024
   contents=[]
   for i in z.infolist():
    n=i.filename;q=PurePosixPath(n);assert not i.is_dir() and not q.is_absolute() and all(x not in ('','.','..') for x in n.split('/')) and '\\' not in n and ':' not in n
    data=z.read(i);r=rows[n];assert len(data)==r['bytes'] and sha(data)==r['sha256'];contents.append((n,data))
  dest.mkdir()
  for n,data in contents:
   f=dest/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data);assert f.read_bytes()==data;result['files'].append({'path':n,'bytes':len(data),'sha256':sha(data)})
  assert {f.relative_to(dest).as_posix() for f in dest.rglob('*') if f.is_file()}==set(rows)
  result.update(status='PASS_COMPLETE_ORIGINAL_BUILD_NAMESPACE_NOT_PRODUCT_RUNTIME',fileCount=len(rows),totalBytes=sum(r['bytes'] for r in rows.values()))
 except Exception as error:result.update(status='FAIL_RETAIN_ORIGINALS',errorType=type(error).__name__,error=str(error))
 report.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result.get(k) for k in ('status','fileCount','totalBytes','error')}));return 0 if result['status'].startswith('PASS_') else 1
if __name__=='__main__':raise SystemExit(main())
