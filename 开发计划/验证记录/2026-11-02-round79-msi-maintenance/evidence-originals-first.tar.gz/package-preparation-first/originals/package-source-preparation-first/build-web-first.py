from pathlib import Path
import datetime,hashlib,json,os,signal,stat,subprocess,time
ROOT=Path('/tmp/fc-round78-ci-evidence');PREP=ROOT/'package-source-preparation-first';D=PREP/'web-build-first';WT=PREP/'checkout-261c58a-first';MAIN=Path('/workspace/共享/Eliora/未来教室计划');WEB=D/'source/web';REPORT=D/'build-report-first.json';SOURCE='261c58aca8b0f63ff2cfb4dbd5e85c0d17770005'
def need(v,c):
 if not v:raise AssertionError(c)
def sha(b):return hashlib.sha256(b).hexdigest()
def fact(p):
 need(p.is_file() and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode),'REGULAR_FILE '+str(p));need(p.stat().st_size<=64*1024*1024,'PER_FILE_SOURCE_BOUND');b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def ledger(base,names):return [dict(path=n,bytes=fact(base/n)['bytes'],sha256=fact(base/n)['sha256']) for n in names]
def write():REPORT.write_text(json.dumps(result,indent=2)+'\n')
def command(name,args,cwd,budget):
 stdout=D/(name+'.stdout.log');stderr=D/(name+'.stderr.log');need(not stdout.exists() and not stderr.exists(),'FRESH_COMMAND_LOGS');step=dict(name=name,command=args,cwd=str(cwd),originalBudgetSeconds=budget,status='RUNNING');result['steps'].append(step);write();print('START '+name,flush=True);start=time.monotonic()
 env=dict(os.environ);env.update(TMPDIR=str(D/'process-temp'),TMP=str(D/'process-temp'),TEMP=str(D/'process-temp'),NPM_CONFIG_UPDATE_NOTIFIER='false',GIT_OPTIONAL_LOCKS='0')
 with stdout.open('xb') as out,stderr.open('xb') as err:
  child=subprocess.Popen(args,cwd=cwd,env=env,stdout=out,stderr=err,start_new_session=True);step['pid']=child.pid;write()
  try:code=child.wait(timeout=budget);step['timedOut']=False
  except subprocess.TimeoutExpired:
   step['timedOut']=True;os.killpg(child.pid,signal.SIGTERM)
   try:code=child.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=5)
 step.update(status='PASS' if code==0 and not step['timedOut'] else 'FAIL',actualExit=True,exitCode=code,elapsedSeconds=time.monotonic()-start,stdout=fact(stdout),stderr=fact(stderr));write();print('DONE '+name+' exit='+str(code),flush=True);need(step['status']=='PASS','COMMAND_FAILED '+name);return stdout.read_bytes()
from source_gate import parser,gate,describe,pinned
p=parser('Local copied-source Web build after exact original CI admission');p.add_argument('--checkout-proof-sha256');a=p.parse_args()
if not a.execute:describe('web');raise SystemExit(0)
_,gate_fact=gate(a)
pinned(PREP/'actual-checkout-first.json',a.checkout_proof_sha256)
need(not D.exists(),'FRESH_WEB_BUILD_ROOT');D.mkdir();(D/'.owner').write_text('future-classroom-owned-r78-web-build/v1\n')
need((ROOT/'.owner').read_bytes()==b'future-classroom-owned-r78-ci-evidence/v1\n' and (D/'.owner').read_bytes()==b'future-classroom-owned-r78-web-build/v1\n','OWNED_ROOTS');need(not REPORT.exists() and not (D/'source').exists(),'NEW_EXCLUSIVE_SOURCE_AND_REPORT');(D/'process-temp').mkdir();start=time.monotonic();result=dict(status='RUNNING',sourceSha=SOURCE,admission=gate_fact,scope='Local same-commit copied-source Web build only; not CI-generated Web output, target execution, MSI, Windows or listener/browser acceptance.',controller=dict(pid=os.getpid(),script=fact(Path(__file__))),startedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),steps=[],sourceCopy=str(WEB),dist=None);write();selected=[];names=[];before=None;copy_before=None;main_before=None
try:
 proofpath=PREP/'actual-checkout-first.json';proof=json.loads(proofpath.read_text());need(proof['status']=='PASS_ACTUAL_CI_CHECKOUT_BYTES_EXACT' and proof['sourceSha']==SOURCE and proof['actualExit'] is True and proof['exitCode']==0 and proof['selectedCount']==len(proof['selectedInputs']) and proof['selectedCount']>0 and Path(proof['checkout'])==WT,'ACTUAL_SOURCE_CHECKOUT_PROOF');result['checkoutProof']=fact(proofpath)
 auditpath=Path(proof['acceptedAudit']['path']);need(auditpath==a.accepted_static_report and proof['acceptedAudit']['sha256']==a.accepted_static_report_sha256,'EXPLICIT_CURRENT_AUDIT_PROOF_BINDING');need(fact(auditpath)==proof['acceptedAudit'],'ACCEPTED_STATIC_AUDIT_EXACT');audit=json.loads(auditpath.read_text());need(audit['sourceSha']==SOURCE and audit['baseline']=='Win7' and audit['status']=='PASS_STATIC_ONLY_RUNTIME_NOT_RUN','ACTUAL_WIN7_SOURCE_INVENTORY');result['acceptedAudit']=fact(auditpath)
 raw=command('git-web-ls-files',['git','-C',str(WT),'ls-files','-z','--','web/'],WT,20);names=[n.decode('utf-8') for n in raw.split(b'\0') if n];need(len(names)==len(set(names)) and 0<len(names)<=1024,'BOUNDED_TRACKED_WEB_SET');need(all(n.startswith('web/') and not any(x in ('..','node_modules','dist','.cache','npm-cache') for x in Path(n).parts) for n in names),'ONLY_TRACKED_WEB_SOURCE')
 ci={r['path']:r for r in audit['sourceMatches'] if r['path'].startswith('web/')};need(set(names)==set(ci),'EXACT_CI_WEB_INPUT_MEMBERSHIP');before=ledger(WT,names);need(sum(r['bytes'] for r in before)<=256*1024*1024,'SOURCE_TOTAL_BOUND')
 for row in before:need((row['bytes'],row['sha256'])==(ci[row['path']]['bytes'],ci[row['path']]['sha256']),'INITIAL_CI_CHECKOUT_WEB_BYTES '+row['path'])
 selected=[str(Path(row['path']).relative_to(WT)) for row in proof['selectedInputs']];whole_before=ledger(WT,selected);need(whole_before==[dict(path=str(Path(row['path']).relative_to(WT)),bytes=row['bytes'],sha256=row['sha256']) for row in proof['selectedInputs']],'ALL_SELECTED_SOURCE_BEFORE_EXACT');result['checkoutSourceBefore']=whole_before;main_before=ledger(MAIN,names);result['mainWebBefore']=main_before
 for row in before:
  source=WT/row['path'];need(all(not x.is_symlink() for x in [source,*source.parents] if x==WT or WT in x.parents),'NONLINK_SOURCE_CHAIN');dest=D/'source'/row['path'];dest.parent.mkdir(parents=True,exist_ok=True)
  with dest.open('xb') as out:out.write(source.read_bytes())
 copy_before=ledger(D/'source',names);need(copy_before==before,'SOURCE_COPY_EXACT_CI_BYTES');result['sourceCopyBefore']=copy_before;write()
 result['nodeVersion']=command('node-version',['node','--version'],WEB,20).decode().strip();result['npmVersion']=command('npm-version',['npm','--version'],WEB,20).decode().strip();need(result['npmVersion']=='10.9.3','LOCKED_NPM_PACKAGE_MANAGER_VERSION')
 command('npm-ci',['npm','ci','--ignore-scripts','--no-audit','--no-fund','--cache',str(D/'npm-cache')],WEB,900)
 need(ledger(D/'source',names)==copy_before,'NPM_CI_SOURCE_AND_LOCK_UNCHANGED')
 command('npm-build',['npm','run','build'],WEB,300)
 after=ledger(D/'source',names);result['sourceCopyAfter']=after;original_notice=next(r for r in before if r['path']=='web/THIRD-PARTY-NOTICES.txt');generated_notice=next(r for r in after if r['path']=='web/THIRD-PARTY-NOTICES.txt');result['notice']=dict(originalCiIdentity=original_notice,generatedIdentity=generated_notice)
 need([r for r in after if r['path']!='web/THIRD-PARTY-NOTICES.txt']==[r for r in copy_before if r['path']!='web/THIRD-PARTY-NOTICES.txt'],'ONLY_LICENSE_SOURCE_MAY_CHANGE');result['copyOriginalSourceUnchangedExceptNotice']=True
 a=(WT/'web/THIRD-PARTY-NOTICES.txt').read_bytes();b=(WEB/'THIRD-PARTY-NOTICES.txt').read_bytes();norm=lambda data:data.replace(b'\r\n',b'\n');counts=lambda data:dict(crlf=data.count(b'\r\n'),bareLf=data.count(b'\n')-data.count(b'\r\n'),bareCr=data.count(b'\r')-data.count(b'\r\n'));notice_equiv=norm(a)==norm(b) and counts(a)['bareCr']==counts(b)['bareCr']==0;result['notice'].update(onlyLfCrLfEquivalent=notice_equiv,originalLineEndings=counts(a),generatedLineEndings=counts(b),canonicalLfSha256=sha(norm(b)),comparison='Exact bytes after per-line CRLF-to-LF conversion only; no other whitespace/Unicode/content normalization. Generated output need not be whole-file LF-only.');write();need(notice_equiv,'GENERATED_LICENSE_CONTENT_DIFFERS_BEYOND_LF_CRLF')
 result['lockUnchanged']=next(r for r in after if r['path']=='web/package-lock.json')==next(r for r in copy_before if r['path']=='web/package-lock.json');need(result['lockUnchanged'],'LOCK_BYTES_UNCHANGED')
 dist=WEB/'dist';members=sorted(p for p in dist.rglob('*') if p.is_file());need(all(not p.is_symlink() for p in dist.rglob('*')) and 1<=len(members)<=65,'BOUNDED_REGULAR_DIST');files=[dict(path=p.relative_to(dist).as_posix(),bytes=fact(p)['bytes'],sha256=fact(p)['sha256']) for p in members];manifestpath=dist/'fc-assets.json';manifest=json.loads(manifestpath.read_text());expected={r['path']:(r['sizeBytes'],r['sha256']) for r in manifest['assets']};actual={r['path']:(r['bytes'],r['sha256']) for r in files if r['path']!='fc-assets.json'};need(manifest['schemaVersion']==manifest['apiVersion']==manifest['uiCompatibilityVersion']==1 and expected==actual and len(expected)==len(manifest['assets']),'EXACT_DIST_MANIFEST_CLOSURE');result['dist']=dict(path=str(dist),files=files,fileCount=len(files),totalBytes=sum(r['bytes'] for r in files),manifest=fact(manifestpath))
 budgetpath=WEB/'build-budget.json';budget=json.loads(budgetpath.read_text());need(budget['status']=='PASS' and budget['totalLimitBytes']==5*1024*1024 and budget['gzipJsCssLimitBytes']==512*1024 and budget['totalBytes']<=budget['totalLimitBytes'] and budget['gzipJsCssBytes']<=budget['gzipJsCssLimitBytes'],'ORIGINAL_WEB_BUDGET_UNCHANGED');result['buildBudget']=dict(identity=fact(budgetpath),actual=budget)
 result['status']='PASS_LOCAL_SAME_SOURCE_WEB_BUILD_ONLY'
except Exception as error:result.update(status='FAIL_LOCAL_WEB_BUILD_OR_IDENTITY',error=dict(type=type(error).__name__,code=str(error) if isinstance(error,AssertionError) else 'LOCAL_BUILD_OR_CAPTURE_EXCEPTION'))
finally:
 if selected:
  try:result['checkoutSourceAfter']=ledger(WT,selected);result['checkoutUnchanged']=result['checkoutSourceAfter']==result['checkoutSourceBefore'];need(result['checkoutUnchanged'],'ALL_SELECTED_CHECKOUT_BYTES_UNCHANGED')
  except Exception as error:result.update(status='FAIL_LOCAL_WEB_BUILD_OR_IDENTITY',checkoutVerificationError=type(error).__name__)
 if main_before is not None:
  try:result['mainWebAfter']=ledger(MAIN,names);result['mainWebUnchanged']=main_before==result['mainWebAfter'];need(result['mainWebUnchanged'],'MAIN_WEB_BYTES_UNCHANGED')
  except Exception as error:result.update(status='FAIL_LOCAL_WEB_BUILD_OR_IDENTITY',mainVerificationError=type(error).__name__)
 result.update(completedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-start);write();print(json.dumps(dict(status=result['status'],report=fact(REPORT),dist=result.get('dist',{}).get('path') if result.get('dist') else None,checkoutUnchanged=result.get('checkoutUnchanged'),mainWebUnchanged=result.get('mainWebUnchanged'))),flush=True)
raise SystemExit(0 if result['status']=='PASS_LOCAL_SAME_SOURCE_WEB_BUILD_ONLY' else 1)
