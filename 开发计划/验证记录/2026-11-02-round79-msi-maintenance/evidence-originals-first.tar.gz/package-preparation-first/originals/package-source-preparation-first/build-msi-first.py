"""Prepared current same-source Win7-target packager. No --execute means no build.
Requires root's actual accepted static artifact report and original CI namespace.
A Windows 7 target artifact is not evidence of Windows 7 OS execution.
"""
from pathlib import Path
import argparse, hashlib, json, os, re, runpy, signal, stat, subprocess, sys, time
sys.dont_write_bytecode=True
R=Path('/tmp/fc-round78-ci-evidence');D=R/'package-source-preparation-first'
ORIGINAL_MAIN=Path('/workspace/共享/Eliora/未来教室计划')
MAIN=D/'checkout-261c58a-first';SCRIPT=MAIN/'scripts/package-msi-candidate.py'
BUILDER=SCRIPT
from source_gate import parser,gate,describe
SOURCE='261c58aca8b0f63ff2cfb4dbd5e85c0d17770005';RUN=41332469102
SCRIPT_SHA=None
MSIBUILD_SHA='87ee3aa0af25bb997646071a45e35ebae3e3ba5f26fe7b479df97aa31bd8a1eb'

def need(v,c):
    if not v:raise AssertionError(c)
def sha(b):return hashlib.sha256(b).hexdigest()
def owned(p):
    p=Path(p);need(p.is_absolute() and p.resolve().is_relative_to(R) and not any(x.is_symlink() for x in [p,*p.parents] if x==R or R in x.parents),'OWNED_R78_INPUT');return p

def fact(p):
    need(stat.S_ISREG(p.lstat().st_mode) and p.suffix.lower() not in {'.key','.pfx','.p12'},'REGULAR_NONPRIVATE_INPUT');b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def pinned(p,digest):
    f=fact(p);need(re.fullmatch('[0-9a-f]{64}',digest) and f['sha256']==digest,'EXACT_INPUT_SHA');return f

def accepted_gate(report,source):
    need(report.get('schema')=='future-classroom.ci-independent-artifact/v2' and report.get('status')=='PASS_STATIC_ONLY_RUNTIME_NOT_RUN','ACTUAL_ACCEPTED_STATIC_REPORT')
    need(report.get('sourceSha')==source==SOURCE and report.get('baseline')=='Win7' and report.get('runId')==RUN,'SAME_ACTUAL_WIN7_SOURCE_RUN')
    need(report.get('helperUnchanged') is True and report.get('artifactIntegrity')=='PASS_WHOLE_ZIP_CRC_AND_COMPLETE_PRODUCER_LEDGER','WHOLE_ORIGINAL_ARTIFACT_ACCEPTED')
    for key,target in [('normalExecutable','fc-bootstrap'),('lifecycleExecutable','fc-installer-lifecycle')]:
        row=report[key]['producer'];need(row['target']==target and row['role']=='product' and row['package']=='fc-bootstrap' and row['cargo_profile_test'] is False and row['pe_subsystem']==2 and row['pe_subsystem_version']=='6.1','ACTUAL_NORMAL_GUI_NOT_GNU_TEST_OR_CLONE')

def checkout_facts(build):
    def git(*tail, root=MAIN):
        return subprocess.check_output(['git','-C',str(root),'-c','core.autocrlf=true',*tail],timeout=30)
    need(owned(MAIN).is_dir() and git('rev-parse','HEAD').decode().strip()==SOURCE and git('rev-parse','HEAD',root=ORIGINAL_MAIN).decode().strip()==SOURCE,'EXACT_ORIGINAL_AND_DETACHED_CHECKOUT_HEAD')
    sym=subprocess.run(['git','-C',str(MAIN),'symbolic-ref','-q','HEAD'],capture_output=True,timeout=10)
    need(sym.returncode==1 and not sym.stdout and not sym.stderr,'ACTUAL_DETACHED_CHECKOUT')
    need(git('status','--porcelain','-z','--untracked-files=all')==b'','NO_TRACKED_OR_UNKNOWN_UNTRACKED_CHECKOUT_CHANGES')
    raw=(build/'input-sha256.json').read_bytes()
    need(raw==(build/'input-sha256-after.json').read_bytes(),'EXACT_ORIGINAL_CI_BEFORE_AFTER')
    inventory=json.loads(raw);by={r['path']:r for r in inventory};need(len(by)==len(inventory),'UNIQUE_ORIGINAL_CI_INPUTS')
    tracked=git('ls-files','-z').decode('utf-8').split('\0')
    selected=[n for n in tracked if n and (n.startswith(('crates/','scripts/','web/','.cargo/')) or n in ('Cargo.toml','Cargo.lock'))]
    rows=[]
    for n in selected:
        f=fact(owned(MAIN/n));need(by.get(n)=={'path':n,'bytes':f['bytes'],'sha256':f['sha256']},'RAW_CHECKOUT_EXACT_CI_INPUT_'+n);rows.append(f)
    blob=git('show','HEAD:scripts/package-msi-candidate.py')
    need(sha(blob)==SCRIPT_SHA and blob==git('show','HEAD:scripts/package-msi-candidate.py',root=ORIGINAL_MAIN),'UNCHANGED_COMMITTED_SAME_SOURCE_SCRIPT_BLOB')
    return dict(status='PASS_ACTUAL_CI_CHECKOUT_BYTES_EXACT_NO_NORMALIZED_HASH_ACCEPTANCE',sourceSha=SOURCE,checkout=str(MAIN),selectedInputs=rows,selectedCount=len(rows),scriptCheckout=fact(SCRIPT),scriptGitBlobOidSha1=git('rev-parse','HEAD:scripts/package-msi-candidate.py').decode().strip(),scriptGitBlobContentSha256=sha(blob),checkoutClean=True,detached=True)

def main():
    global SCRIPT_SHA
    p=parser(__doc__)
    for name in ('input-zip','build-evidence','lifecycle-helper','output-dir','report','objdump'):p.add_argument('--'+name,type=Path)
    for name in ('input-sha256','build-result-sha256','lifecycle-helper-sha256','objdump-sha256'):p.add_argument('--'+name)
    p.add_argument('--local-probe-receipt',type=Path);p.add_argument('--local-probe-receipt-sha256');p.add_argument('--checkout-script-sha256');p.add_argument('--checkout-script-blob-sha256');p.add_argument('--tools-report',type=Path);p.add_argument('--tools-report-sha256');a=p.parse_args()
    if not a.execute:
        describe('package');return 0
    _,gate_fact=gate(a);SCRIPT_SHA=a.checkout_script_blob_sha256
    need(re.fullmatch('[0-9a-f]{64}',SCRIPT_SHA or ''),'EXPLICIT_COMMITTED_SCRIPT_BLOB_SHA256')
    need(a.build_evidence==a.raw,'ACTUAL_RAW_BUILD_NAMESPACE')
    need((R/'.owner').read_bytes()==b'future-classroom-owned-r78-ci-evidence/v1\n','EXACT_OWNERS')
    reportpath=owned(a.report);need(reportpath.parent==D and not reportpath.exists(),'NEW_OWNED_REPORT')
    result=dict(status='NOT_RUN_BLOCKED',sourceSha=SOURCE,installation='NOT_RUN',readiness='NOT_GRANTED',admission=gate_fact,scope='Local candidate MSI build/static only after root-provided accepted Win7 same-source actual CI artifacts. No target EXE or Windows execution.')
    try:
        need(subprocess.check_output(['git','-C',str(MAIN),'rev-parse','HEAD'],timeout=10).decode().strip()==SOURCE,'CURRENT_HEAD_SAME_SOURCE')
        inputs=[pinned(owned(SCRIPT),a.checkout_script_sha256),pinned(owned(a.accepted_static_report),a.accepted_static_report_sha256),pinned(owned(a.input_zip),a.input_sha256),pinned(owned(a.lifecycle_helper),a.lifecycle_helper_sha256),pinned(a.objdump,a.objdump_sha256)]
        accepted=json.loads(a.accepted_static_report.read_bytes());accepted_gate(accepted,a.source_sha)
        build=owned(a.build_evidence);need(build.is_dir(),'ORIGINAL_BUILD_NAMESPACE');members={r['path']:r for r in accepted['members']};need(len(members)==len(accepted['members']),'UNIQUE_ACCEPTED_MEMBERS')
        names=['result.json','input-sha256.json','input-sha256-after.json','executables.json','logs/product-compile.stdout.log','logs/lifecycle-compile.stdout.log','logs/cargo-metadata.stdout.log','product/fc-bootstrap/fc-bootstrap.exe','product/fc-bootstrap/fc-installer-lifecycle.exe']
        for name in names:
            actual=fact(owned(build/name));row=members[name];need(actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'],'ORIGINAL_CI_MEMBER_STATIC_BINDING');inputs.append(actual)
        need(pinned(build/'result.json',a.build_result_sha256)['sha256']==members['result.json']['sha256'],'EXACT_ACCEPTED_CI_RESULT')
        need(a.lifecycle_helper==build/'product/fc-bootstrap/fc-installer-lifecycle.exe','ORIGINAL_NORMAL_HELPER_NAMESPACE')
        inner=fact(a.input_zip)
        receipt_fact=pinned(owned(a.local_probe_receipt),a.local_probe_receipt_sha256);local=json.loads(a.local_probe_receipt.read_bytes())
        need(local.get('status')=='PASS_LOCAL_SAME_SOURCE_PROBE_ZIP_ONLY_RUNTIME_NOT_RUN' and local.get('sourceSha')==SOURCE and local.get('target')=='i686-win7-windows-msvc' and local.get('actualExit') is True and local.get('exitCode')==0 and local.get('sourceInputsUnchanged') is True,'ACTUAL_LOCAL_PROBE_PRODUCER_NOT_CI_MEMBER')
        need(local.get('artifact')==inner and local.get('normalApp',{}).get('sha256')==accepted['normalExecutable']['producer']['sha256'] and local.get('acceptedStatic',{}).get('sha256')==a.accepted_static_report_sha256,'LOCAL_ZIP_EXACT_ACCEPTED_NORMAL_APP_SOURCE_BINDING')
        command=local.get('command');need(isinstance(command,list) and command[:3]==['python3','-B',str(MAIN/'scripts/package-probe.py')],'ACTUAL_ORIGINAL_CHECKOUT_PROBE_SCRIPT_COMMAND')
        for flag,value in [('--exe',local['normalApp']['path']),('--output',str(a.input_zip)),('--target','i686-win7-windows-msvc'),('--web-dist',local['webDist'])]:
            need(command.count(flag)==1 and command[command.index(flag)+1]==value,'EXACT_LOCAL_PROBE_COMMAND_'+flag)
        for key in ['normalApp','script','webBuild','acceptedStatic','stdout','stderr']:inputs.append(pinned(owned(Path(local[key]['path'])),local[key]['sha256']))
        need(local['script']['path']==str(MAIN/'scripts/package-probe.py'),'UNCHANGED_WORKTREE_PROBE_SCRIPT')
        inputs.append(receipt_fact);result['localProbeProducer']=local
        result['inputZipOrigin']='LOCALLY_PRODUCED_BY_ORIGINAL_SAME_SOURCE_PACKAGE_PROBE_NOT_A_CI_ARTIFACT_MEMBER'
        checkout=checkout_facts(build);need(checkout['scriptCheckout']['sha256']==a.checkout_script_sha256,'EXPLICIT_ACTUAL_CHECKOUT_SCRIPT_DIGEST');inputs.extend(checkout['selectedInputs']);result['sourceCheckout']=checkout
        tools_fact=pinned(owned(a.tools_report),a.tools_report_sha256);tools=json.loads(a.tools_report.read_bytes());need(tools['status']=='PASS_EXACT_PACKAGES_LOCAL_EXTRACTION_ELF_BINDING_AND_SCOPED_TOOL_LOADING_ONLY','ACTUAL_LOCAL_TOOLS_READY')
        inputs.append(tools_fact)
        for row in tools['tools']+tools['libraries']+[tools['wixlWrapper']]:inputs.append(pinned(Path(row['path']),row['sha256']))
        invocation=tools['invocation'];need(invocation['msibuild_sha256']==MSIBUILD_SHA,'PINNED_MSIBUILD')
        M=runpy.run_path(str(BUILDER));M['configure_source_root'](MAIN);manifest,payloads=M['validate_zip'](a.input_zip.read_bytes());M['pe_header'](payloads['fc-bootstrap.exe']);normal,provenance=M['admit_normal_helper'](a,payloads,manifest['version'])
        need(provenance['main_sha256']==accepted['normalExecutable']['producer']['sha256'] and provenance['normal_helper_sha256']==accepted['lifecycleExecutable']['producer']['sha256'],'SAME_ACCEPTED_TWO_NORMALS')
        output=owned(a.output_dir);need(output.parent==D and not output.exists(),'NEW_EXCLUSIVE_CANDIDATE_OUTPUT')
        command=['python3','-B',str(BUILDER),'--source-root',str(MAIN),'--input-zip',str(a.input_zip),'--input-sha256',a.input_sha256,'--lifecycle-helper',str(a.lifecycle_helper),'--lifecycle-helper-sha256',a.lifecycle_helper_sha256,'--build-evidence',str(build),'--build-result-sha256',a.build_result_sha256,'--output-dir',str(output)]
        for name in ('wixl','msibuild','msiinfo','msiextract'):command+=['--'+name,invocation[name]]
        command+=['--msibuild-sha256',MSIBUILD_SHA,'--objdump',str(a.objdump)]
        env=os.environ.copy()
        for name in ('LD_PRELOAD','LD_AUDIT','GIO_EXTRA_MODULES','GIO_MODULE_DIR'):env.pop(name,None)
        env.update(invocation['environment'])
        result.update(status='RUNNING',builderCandidate=fact(BUILDER),compiledProgramSourceSha=SOURCE,builderOrigin='Unchanged original current same-source detached checkout script including committed B5 metadata identity fix',command=command,inputs=inputs,normalProvenance=provenance,originalPerToolBudgetSeconds=120,outerBudgetSeconds=1200)
        reportpath.write_text(json.dumps(result,indent=2)+'\n');started=time.monotonic()
        out=reportpath.with_suffix('.stdout.log');err=reportpath.with_suffix('.stderr.log');need(not out.exists() and not err.exists(),'EXCLUSIVE_STREAMS')
        with out.open('xb') as so,err.open('xb') as se:
            child=subprocess.Popen(command,cwd=MAIN,env=env,stdout=so,stderr=se,start_new_session=True);result['pid']=child.pid
            try:code=child.wait(timeout=1200);timed=False
            except subprocess.TimeoutExpired:
                timed=True;os.killpg(child.pid,signal.SIGTERM)
                try:code=child.wait(timeout=5)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=5)
        result.update(actualExit=True,exitCode=code,timedOut=timed,elapsedSeconds=time.monotonic()-started,stdout=fact(out),stderr=fact(err))
        need(code==0 and not timed,'ACTUAL_LOCAL_PACKAGE_FAILED')
        need(all(fact(Path(row['path']))==row for row in inputs),'ALL_INPUTS_UNCHANGED')
        need(checkout_facts(build)==checkout,'EXACT_CHECKOUT_AND_GIT_STATE_UNCHANGED_AFTER_PACKAGE')
        actual=json.loads((output/'report.json').read_bytes());need(actual['status']=='PASS' and actual['installation']=='NOT_RUN' and actual['normal_helper_provenance']==provenance,'ACTUAL_PACKAGE_REPORT')
        result.update(status='PASS_LOCAL_PRODUCT_MSI_STATIC_ONLY_WINDOWS_NOT_RUN',packageReport=fact(output/'report.json'),candidateMSI=fact(output/'candidate.msi'))
    except Exception as error:result.update(status='FAIL_RETAIN_ALL_PACKAGE_ORIGINALS' if result['status']=='RUNNING' else 'NOT_RUN_BLOCKED',errorType=type(error).__name__,reasonCode=str(error) if isinstance(error,AssertionError) else 'LOCAL_ARTIFACT_ADMISSION_OR_BUILD_ERROR')
    reportpath.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],report=str(reportpath),installation='NOT_RUN')));return 0 if result['status']=='PASS_LOCAL_PRODUCT_MSI_STATIC_ONLY_WINDOWS_NOT_RUN' else 1
if __name__=='__main__':raise SystemExit(main())
