"""Run reviewed local checkout/Web/probe/MSI steps only after actual CI admission."""
from pathlib import Path
import argparse,datetime,hashlib,json,subprocess,time
E=Path('/tmp/fc-round78-ci-evidence');D=E/'package-source-preparation-first';A=E/'ci-admission-preparation-first'
SOURCE='261c58aca8b0f63ff2cfb4dbd5e85c0d17770005'
def fact(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def main():
 p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');a=p.parse_args()
 if not a.execute:print(json.dumps({'status':'NOT_RUN_PREPARATION_ONLY'}));return 0
 assert (E/'.owner').read_bytes()==b'future-classroom-owned-r78-ci-evidence/v1\n'
 stage=json.loads((E/'root-stage-original-build-first.json').read_bytes());assert stage['status']=='PASS_COMPLETE_ORIGINAL_BUILD_NAMESPACE_NOT_PRODUCT_RUNTIME'
 audit=A/'win7-static-audit-first.json';raw=E/'win7-build-original-first';wt=D/'checkout-261c58a-first'
 common=['--execute','--source-sha',SOURCE,'--accepted-static-report',str(audit),'--accepted-static-report-sha256',fact(audit)['sha256'],'--raw',str(raw),'--run-id','41332469102']
 output=E/'root-package-pipeline-first.json';assert not output.exists()
 r={'status':'RUNNING','sourceSha':SOURCE,'scope':'Reviewed local-only source checkout, Web build, probe ZIP, and candidate MSI static build. No Windows, product/installer execution, or release.','startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':[]};output.write_text(json.dumps(r,indent=2)+'\n')
 def run(name,args):
  cmd=['python3','-B',str(D/(name+'-first.py')),*common,*args];out=E/('root-package-'+name+'-first.stdout.log');err=E/('root-package-'+name+'-first.stderr.log');assert not out.exists() and not err.exists()
  item={'name':name,'command':cmd,'status':'RUNNING'};r['steps'].append(item);output.write_text(json.dumps(r,indent=2)+'\n');start=time.monotonic();print('START '+name,flush=True)
  with out.open('xb') as so,err.open('xb') as se:
   child=subprocess.Popen(cmd,stdout=so,stderr=se);item['pid']=child.pid;output.write_text(json.dumps(r,indent=2)+'\n');code=child.wait()
  item.update(status='PASS_COMMAND' if code==0 else 'FAIL_COMMAND',actualExit=True,exitCode=code,elapsedSeconds=time.monotonic()-start,stdout=fact(out),stderr=fact(err));output.write_text(json.dumps(r,indent=2)+'\n');print('DONE '+name+' exit='+str(code),flush=True);assert code==0,name
 try:
  run('create-checkout',[]);checkout=D/'actual-checkout-first.json';c=json.loads(checkout.read_bytes());assert c['status']=='PASS_ACTUAL_CI_CHECKOUT_BYTES_EXACT'
  extra=['--checkout-proof-sha256',fact(checkout)['sha256']]
  run('build-web',extra);web=D/'web-build-first/build-report-first.json'
  run('build-probe',extra+['--web-report',str(web),'--web-report-sha256',fact(web)['sha256']]);probe=D/'local-probe-first/producer-first.json';z=D/'local-probe-first/FutureClassroom-0.1.0-windows-x86-dev.zip'
  tools=E/'msi-tools-preparation-first/msi-tools-preparation-first.json';helper=raw/'product/fc-bootstrap/fc-installer-lifecycle.exe';obj=Path('/usr/bin/i686-w64-mingw32-objdump')
  args=['--input-zip',str(z),'--input-sha256',fact(z)['sha256'],'--build-evidence',str(raw),'--lifecycle-helper',str(helper),'--lifecycle-helper-sha256',fact(helper)['sha256'],'--build-result-sha256',fact(raw/'result.json')['sha256'],'--local-probe-receipt',str(probe),'--local-probe-receipt-sha256',fact(probe)['sha256'],'--checkout-script-sha256',c['scriptCheckout']['sha256'],'--checkout-script-blob-sha256',c['scriptGitBlobContentSha256'],'--objdump',str(obj),'--objdump-sha256',fact(obj)['sha256'],'--tools-report',str(tools),'--tools-report-sha256',fact(tools)['sha256'],'--output-dir',str(D/'candidate-output-first'),'--report',str(D/'package-build-first.json')]
  run('build-msi',args);package=json.loads((D/'package-build-first.json').read_bytes());assert package['status']=='PASS_LOCAL_PRODUCT_MSI_STATIC_ONLY_WINDOWS_NOT_RUN'
  r.update(status='PASS_LOCAL_PACKAGE_PIPELINE_MSI_RUNTIME_NOT_RUN',packageReceipt=fact(D/'package-build-first.json'))
 except Exception as error:r.update(status='FAIL_RETAIN_ORIGINALS_NO_WINDOWS_ACTION',errorType=type(error).__name__,error=str(error))
 output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k) for k in ('status','errorType','error')}));return 0 if r['status'].startswith('PASS_') else 1
if __name__=='__main__':raise SystemExit(main())
