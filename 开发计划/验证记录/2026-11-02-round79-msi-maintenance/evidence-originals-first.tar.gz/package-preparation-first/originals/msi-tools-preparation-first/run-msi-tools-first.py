#!/usr/bin/env python3
"""R78 bounded local tool preparation, exact frozen source checks before/after."""
from pathlib import Path
import argparse
import ast
import datetime
import hashlib
import json
import stat
import subprocess
import time

ROOT = Path('/tmp/fc-round78-ci-evidence')
E = ROOT / 'msi-tools-preparation-first'
MAIN = Path('/workspace/共享/Eliora/未来教室计划')
COMMIT = '261c58aca8b0f63ff2cfb4dbd5e85c0d17770005'
CONFIG_SHA = '38713cb9d14ab06e3bd54ee38e1e85cfe15ab01e96c3d0ae75b44bc625d67f1c'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def frozen():
    assert (ROOT / '.owner').read_bytes() == b'future-classroom-owned-r78-ci-evidence/v1\n'
    assert (E / '.owner').read_bytes() == b'future-classroom-owned-r78-msi-tools-preparation/v1\n'
    assert subprocess.check_output(['git','-C',str(MAIN),'rev-parse','HEAD'],timeout=10).decode().strip()==COMMIT
    raw = (E / 'msi-tools-input-first.json').read_bytes()
    assert sha(raw) == CONFIG_SHA
    config = json.loads(raw)
    assert config['sourceGuard']['commit'] == COMMIT
    listing = config['sourceGuard']['sources']
    assert len(listing) == config['sourceGuard']['sourceGuardCount'] == 8
    assert len({row['path'] for row in listing}) == 8
    blob_ids={row['path']:row for row in config['sourceGuard']['gitBlobIdentities']}
    assert len(blob_ids)==len(listing) and set(blob_ids)=={row['path'] for row in listing}
    result = []
    for row in listing:
        path = MAIN / row['path']
        assert path.resolve().is_relative_to(MAIN)
        assert not any(p.is_symlink() for p in (path,*path.parents) if p==MAIN or MAIN in p.parents)
        assert stat.S_ISREG(path.lstat().st_mode)
        data = path.read_bytes()
        actual = {'path': row['path'], 'bytes': len(data), 'sha256': sha(data)}
        assert actual == row
        assert subprocess.check_output(['git','-C',str(MAIN),'show',COMMIT+':'+row['path']],timeout=10)==data
        blob=blob_ids[row['path']]
        assert blob['bytes']==len(data) and blob['gitBlobContentSha256']==sha(data)
        assert subprocess.check_output(['git','-C',str(MAIN),'rev-parse',COMMIT+':'+row['path']],timeout=10).decode().strip()==blob['gitBlobOidSha1']
        result.append(actual)
    return result


def fact(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--execute',action='store_true');args=parser.parse_args()
    if not args.execute:
        print(json.dumps({'status':'NOT_RUN_PREPARATION_ONLY','step':'seven-package-local-tool-preparation','sourceCommit':COMMIT,'sourceGuardCount':8,'network':'NOT_RUN','tools':'NOT_RUN'}));return
    assert not (E / 'msi-tools-controller-first.json').exists()
    before = frozen()
    preparation_inputs=[fact(E/name) for name in ('msi-tools-input-first.json','run-msi-tools-first.py','download-msi-tool-first.py','prepare-msi-tools-local-first.py')]
    tools=ROOT/'tools';assert not tools.exists() and not tools.is_symlink()
    tools.mkdir();(tools/'.owner').write_text('future-classroom-owned-r78-msi-tools/v1\n')
    for name in ('packages','root','wrappers'):(tools/name).mkdir()
    report = {'schemaVersion': 1, 'status': 'RUNNING', 'startedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'scope': 'Seven exact tool downloads and local extraction/load checks only. No MSI, Windows, Cargo, system install or main writes.',
              'sourceCommit': COMMIT, 'sourceGuardStrategy':'CURRENT_EIGHT_GIT_BLOBS_EXACT_BYTES', 'gitBlobIdentities':json.loads((E/'msi-tools-input-first.json').read_bytes())['sourceGuard']['gitBlobIdentities'], 'configSha256': CONFIG_SHA, 'preparationInputs':preparation_inputs, 'sourceBefore': before, 'commands': []}
    config = json.loads((E / 'msi-tools-input-first.json').read_bytes())
    commands = [('download-' + p['name'], ['python3', '-B', str(E / 'download-msi-tool-first.py'), '--execute', p['name']], 135)
                for p in config['packages']]
    commands.append(('prepare-local', ['python3', '-B', str(E / 'prepare-msi-tools-local-first.py'), '--execute'], 1200))
    try:
        for name, command, controller_deadline in commands:
            before = frozen()
            assert all(fact(Path(row['path']))==row for row in preparation_inputs)
            for script in (E / 'download-msi-tool-first.py', E / 'prepare-msi-tools-local-first.py'):
                ast.parse(script.read_bytes(), filename=str(script))
            stdout = E / ('msi-tools-controller-' + name + '-first.stdout.log')
            stderr = E / ('msi-tools-controller-' + name + '-first.stderr.log')
            began = time.monotonic()
            with stdout.open('xb') as out, stderr.open('xb') as err:
                process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=out, stderr=err)
                try:
                    code = process.wait(timeout=controller_deadline)
                    timed_out = False
                except subprocess.TimeoutExpired:
                    # Kill only this original owned preparation child; original
                    # tools have their own unchanged bounded command budgets.
                    process.kill()
                    code = process.wait(timeout=5)
                    timed_out = True
            row = {'name': name, 'command': command, 'pid': process.pid, 'actualExit': True,
                   'parentReaped': True, 'exitCode': code, 'controllerTimedOut': timed_out,
                   'controllerDeadlineSeconds': controller_deadline, 'elapsedSeconds': time.monotonic() - began,
                   'stdout': fact(stdout), 'stderr': fact(stderr), 'sourceBefore': before}
            report['commands'].append(row)
            after = frozen()
            assert all(fact(Path(row['path']))==row for row in preparation_inputs)
            row.update(sourceAfter=after, sourceUnchanged=before == after)
            assert not timed_out and code == 0 and row['sourceUnchanged']
        local = json.loads((E / 'msi-tools-preparation-first.json').read_bytes())
        assert local['status'] == 'PASS_EXACT_PACKAGES_LOCAL_EXTRACTION_ELF_BINDING_AND_SCOPED_TOOL_LOADING_ONLY'
        assert len(local['packages']) == 7 and len(local['tools']) == 4 and len(local['libraries']) == 23
        assert all(fact(Path(row['path']))==row for row in preparation_inputs)
        report['sourceAfter'] = frozen()
        report['sourceUnchanged'] = report['sourceBefore'] == report['sourceAfter']
        assert report['sourceUnchanged']
        report['preparation'] = fact(E / 'msi-tools-preparation-first.json')
        report['status'] = 'PASS_EXACT_OWNED_TOOL_PREPARATION_AND_EIGHT_SOURCE_GUARDS'
    except BaseException as error:
        report['status'] = 'FAIL_RETAIN_ORIGINALS'
        report['failureType'] = type(error).__name__
        raise
    finally:
        report['completedUtc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        with (E / 'msi-tools-controller-first.json').open('x') as output:
            json.dump(report, output, ensure_ascii=False, indent=2)
            output.write('\n')
    print(json.dumps({'status': report['status'], 'actualReapedChildren': len(report['commands']),
                      'preparationSha256': report['preparation']['sha256'], 'sourceUnchanged': report['sourceUnchanged']}))


if __name__ == '__main__':
    main()
