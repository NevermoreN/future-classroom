"""R79 root-run local packaging admission. Imports perform no I/O."""
from pathlib import Path
import argparse, hashlib, json, re, stat
from source_binding import current_source_guard,CURRENT_MAIN
R=Path('/tmp/fc-round79-msi-maintenance')
D=R/'package-preparation-first'
SOURCE='261c58aca8b0f63ff2cfb4dbd5e85c0d17770005'
RUN=41332469102
WT=D/'checkout-261c58a-first'
def need(value,code):
    if not value: raise AssertionError(code)
def sha(data):return hashlib.sha256(data).hexdigest()
def owned(path):
    p=Path(path);need(p.is_absolute() and p.resolve().is_relative_to(R),'OWNED_R79_PATH')
    need(not any(q.is_symlink() for q in (p,*p.parents) if q==R or R in q.parents),'NO_ALIASED_R79_PATH')
    return p
def fact(path,limit=128*1024*1024):
    p=Path(path);need(stat.S_ISREG(p.lstat().st_mode) and not p.is_symlink() and p.stat().st_size<=limit and p.suffix.lower() not in {'.key','.pfx','.p12'},'BOUNDED_REGULAR_NONPRIVATE_FILE')
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def pinned(path,digest):
    need(isinstance(digest,str) and re.fullmatch('[0-9a-f]{64}',digest),'EXPLICIT_SHA256')
    f=fact(owned(path));need(f['sha256']==digest,'EXACT_EXPLICIT_INPUT_SHA256');return f
def parser(description):
    p=argparse.ArgumentParser(description=description)
    p.add_argument('--execute',action='store_true')
    p.add_argument('--source-sha');p.add_argument('--accepted-static-report',type=Path)
    p.add_argument('--accepted-static-report-sha256');p.add_argument('--raw',type=Path)
    p.add_argument('--run-id',type=int,default=RUN)
    return p
def gate(a):
    current=current_source_guard()
    need((R/'.owner').read_bytes()==b'future-classroom-owned-r79-msi-maintenance/v1\n','EXACT_R79_OWNER')
    need((D/'.owner').read_bytes()==b'future-classroom-owned-r79-package-preparation/v1\n','EXACT_PREPARATION_OWNER')
    need(a.source_sha==SOURCE and a.run_id==RUN,'EXACT_REUSED_ORIGINAL_CI_SOURCE_AND_WIN7_RUN')
    need(a.accepted_static_report is not None and a.raw is not None,'EXPLICIT_ACCEPTED_AUDIT_AND_RAW')
    audit_fact=pinned(a.accepted_static_report,a.accepted_static_report_sha256)
    raw=owned(a.raw);need(raw.is_dir(),'ACTUAL_RAW_DIRECTORY')
    audit=json.loads(a.accepted_static_report.read_bytes())
    need(audit.get('schema')=='future-classroom.ci-independent-artifact/v2' and audit.get('status')=='PASS_STATIC_ONLY_RUNTIME_NOT_RUN','ACTUAL_STATIC_AUDIT_PASS')
    need(audit.get('sourceSha')==SOURCE and audit.get('baseline')=='Win7' and audit.get('runId')==RUN,'ACTUAL_WIN7_SOURCE_RUN')
    need(audit.get('helperUnchanged') is True and audit.get('artifactIntegrity')=='PASS_WHOLE_ZIP_CRC_AND_COMPLETE_PRODUCER_LEDGER','WHOLE_ORIGINAL_ARTIFACT_ACCEPTANCE')
    rows=audit['members'];members={r['path']:r for r in rows};need(len(members)==len(rows) and 1<=len(rows)<=20000,'UNIQUE_BOUNDED_RAW_MEMBERS')
    seen={};total=0
    for p in raw.rglob('*'):
        need(not p.is_symlink(),'NO_RAW_ALIASES')
        if p.is_dir():continue
        f=fact(p);n=p.relative_to(raw).as_posix();seen[n]=dict(path=n,bytes=f['bytes'],sha256=f['sha256']);total+=f['bytes']
    need(total<=1024*1024*1024 and set(seen)==set(members),'EXACT_BOUNDED_ORIGINAL_RAW_NAMESPACE')
    for n,f in seen.items():need((f['bytes'],f['sha256'])==(members[n]['bytes'],members[n]['sha256']),'EXACT_ACCEPTED_RAW_MEMBER_'+n)
    before=(raw/'input-sha256.json').read_bytes();need(before==(raw/'input-sha256-after.json').read_bytes(),'ORIGINAL_CI_SOURCE_BEFORE_AFTER_EQUAL')
    inventory=json.loads(before);by={r['path']:r for r in inventory}
    need(len(by)==len(inventory) and all(set(r)=={'path','bytes','sha256'} for r in inventory),'UNIQUE_ORIGINAL_CI_INPUT_LEDGER')
    for key,target in [('normalExecutable','fc-bootstrap'),('lifecycleExecutable','fc-installer-lifecycle')]:
        row=audit[key]['producer'];need(row['role']=='product' and row['package']=='fc-bootstrap' and row['target']==target and row['cargo_profile_test'] is False and row['pe_subsystem']==2 and row['pe_subsystem_version']=='6.1','TWO_ACTUAL_WIN7_NORMAL_GUI_PRODUCTS')
    return audit,dict(currentMainHead=CURRENT_MAIN,currentMainInputBinding=current,originalCompiledSourceSha=SOURCE,gateHelper=fact(Path(__file__)),acceptedAudit=audit_fact,raw=str(raw),rawMembers=len(rows),rawBytes=total,sourceSha=SOURCE,runId=RUN,scope='Static CI admission only. No Windows or MSI execution.')
def describe(step):
    print(json.dumps(dict(status='NOT_RUN_PREPARATION_ONLY',step=step,sourceSha=SOURCE,runId=RUN,checkout=str(WT),requires='Explicit --execute --source-sha --accepted-static-report --accepted-static-report-sha256 --raw; actual PASS audit and exact complete raw bytes required.',runtime='NOT_RUN')))
