"""Recreate complete original official Win7 ZIP namespace after actual static PASS."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,stat,zipfile
from source_binding import current_source_guard,CURRENT_MAIN,SOURCE,E,D
ZIP_SHA='bf6d7fcc24056235e7720d2de055cc74d71e799a30ab76ec8c90772e41dd1a8c'
def sha(b):return hashlib.sha256(b).hexdigest()
def need(v,c):
 if not v:raise AssertionError(c)
def fact(p):
 need(stat.S_ISREG(p.lstat().st_mode) and not any(q.is_symlink() for q in (p,*p.parents) if q==E or E in q.parents),'REGULAR_OWNED_ORIGINAL');b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--accepted-static-report',type=Path);p.add_argument('--accepted-static-report-sha256');p.add_argument('--static-operation',type=Path);p.add_argument('--static-operation-sha256');a=p.parse_args()
 if not a.execute:print(json.dumps(dict(status='NOT_RUN_PREPARATION_ONLY',currentMainHead=CURRENT_MAIN,compiledSourceSha=SOURCE)));return 0
 current=current_source_guard();need(a.accepted_static_report==D/'win7-static-audit-first.json' and a.static_operation==D/'win7-static-operation-first.json','EXACT_OWNED_STATIC_REPORTS');need(fact(a.accepted_static_report)['sha256']==a.accepted_static_report_sha256 and fact(a.static_operation)['sha256']==a.static_operation_sha256,'EXPLICIT_ACTUAL_STATIC_REPORT_SHAS')
 audit=json.loads(a.accepted_static_report.read_bytes());op=json.loads(a.static_operation.read_bytes());need(audit['status']=='PASS_STATIC_ONLY_RUNTIME_NOT_RUN' and audit['sourceSha']==SOURCE and audit['runId']==41332469102 and audit['baseline']=='Win7' and audit['officialIdentity']['artifactId']==13094372286,'ACTUAL_ORIGINAL_STATIC_AUDIT');need(op['status']=='PASS_STATIC_AUDITOR_ACTUAL_EXIT0' and op['actualExit'] is True and op['exitCode']==0 and op['actualReport']['sha256']==a.accepted_static_report_sha256,'ACTUAL_STATIC_PARENT_REAPED_EXIT0')
 archive=E/'win7-official-first.zip';zf=fact(archive);need(zf['bytes']==46196057 and zf['sha256']==ZIP_SHA and zf==audit['zip'],'EXACT_ORIGINAL_OFFICIAL_ZIP');rows={r['path']:r for r in audit['members']};need(len(rows)==len(audit['members'])==246,'EXACT_COMPLETE_246_MEMBER_NAMESPACE')
 dest=D/'win7-build-original-first';report=D/'stage-original-build-first.json';need(not dest.exists() and not report.exists(),'FRESH_EXCLUSIVE_NAMESPACE_AND_REPORT');result=dict(status='RUNNING',sourceSha=SOURCE,currentMainHead=CURRENT_MAIN,currentMainInputBinding=current,auditSha256=a.accepted_static_report_sha256,zip=zf,destination=str(dest),files=[],scope='Complete original ZIP namespace only. Old compiler source261 and current mainc449 remain separate; no metadata rewrite, Cargo, product or Windows execution.');report.write_text(json.dumps(result,indent=2)+'\n')
 try:
  with zipfile.ZipFile(archive) as z:
   infos=z.infolist();need(len(infos)==246 and len(set(z.namelist()))==246 and set(z.namelist())==set(rows) and z.testzip() is None,'EXACT_COMPLETE_MEMBERS_AND_CRC');need(sum(i.file_size for i in infos)<=512*1024*1024,'ORIGINAL_TOTAL_512MIB_BOUND');contents=[]
   for i in infos:
    n=i.filename;q=PurePosixPath(n);need(not i.is_dir() and not q.is_absolute() and q.as_posix()==n and all(x not in ('','.','..') for x in n.split('/')) and '\\' not in n and ':' not in n and not any(ord(c)<32 for c in n),'CANONICAL_ZIP_MEMBER');need(not stat.S_ISLNK(i.external_attr>>16),'NO_ZIP_SYMLINK');b=z.read(i);r=rows[n];need(len(b)==r['bytes'] and sha(b)==r['sha256'],'EXACT_ACTUAL_MEMBER_BYTES');contents.append((n,b))
  dest.mkdir()
  for n,b in contents:
   f=dest/n;f.parent.mkdir(parents=True,exist_ok=True)
   with f.open('xb') as out:out.write(b)
   need(f.read_bytes()==b,'EXACT_NAMESPACE_WRITE_READBACK');result['files'].append(dict(path=n,bytes=len(b),sha256=sha(b)))
  need({f.relative_to(dest).as_posix() for f in dest.rglob('*') if f.is_file()}==set(rows),'FULL_NAMESPACE_CLOSURE');need(current_source_guard()==current,'CURRENT_MAIN_SOURCE_UNCHANGED');result.update(status='PASS_COMPLETE_ORIGINAL_BUILD_NAMESPACE_NOT_PRODUCT_RUNTIME',fileCount=246,totalBytes=sum(r['bytes'] for r in rows.values()))
 except Exception as error:result.update(status='FAIL_RETAIN_ORIGINALS',errorType=type(error).__name__,reason=str(error) if isinstance(error,AssertionError) else 'LOCAL_NAMESPACE_CAPTURE_FAILURE')
 report.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],report=str(report))));return 0 if result['status'].startswith('PASS_') else 1
if __name__=='__main__':raise SystemExit(main())
