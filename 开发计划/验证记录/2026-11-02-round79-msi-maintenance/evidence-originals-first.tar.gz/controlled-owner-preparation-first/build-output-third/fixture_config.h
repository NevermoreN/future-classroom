#define FC79_NONCE L"115dbfabf25d4ecc8c16191199e4874a"
#define FC79_PRODUCT L"{055B5A17-7B5E-4CE3-9889-0472BB204DE5}"
#define FC79_EFFECT_DIR L"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-115dbfabf25d4ecc8c16191199e4874a\\effect\\"
