[CmdletBinding()]
param([switch]$Execute,[string]$Root,[string]$ManifestSha256)
$ErrorActionPreference='Stop'
if(-not $Execute){@{status='PREPARED_NOT_RUN';nativeSeconds=120;wholeSeconds=600;finallyReserveSeconds=180;authority='NO_PRODUCTION_AUTHORITY'}|ConvertTo-Json -Compress;return}
$clock=[Diagnostics.Stopwatch]::StartNew();$capture=$null;$spec=$null;$owned=$false;$returned=$true;$allKnown=$true
$result=[ordered]@{status='FAIL_RETAIN_ORIGINALS';authority='NO_PRODUCTION_AUTHORITY';nativeSeconds=120;wholeSeconds=600;finallyReserveSeconds=180;cases=@();errors=@();cleaned=$false;sharedServiceKill=$false;manualRegistryOrCacheDelete=$false}
function Need([bool]$v,[string]$why){if(-not $v){throw $why}}
function Hash([string]$p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function Read-Json([string]$leaf){[IO.File]::ReadAllText((Join-Path $Root $leaf))|ConvertFrom-Json}
function Write-New([string]$leaf,$o){$b=[Text.UTF8Encoding]::new($false).GetBytes(($o|ConvertTo-Json -Depth 60)+"`n");$f=[IO.File]::Open((Join-Path $Root $leaf),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);try{$f.Write($b,0,$b.Length);$f.Flush($true)}finally{$f.Dispose()}}
function State {
 $reg=[Fc79Capture]::Product($spec.productCode,$spec.upgradeCode,$spec.expectedUserSid)
 $com=[Fc79Capture]::Components($spec.productCode,$spec.componentId,$spec.expectedUserSid)
 $base=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry32);$key=$null
 try{$key=$base.OpenSubKey($spec.registryKey,$false);$mark=if($null-eq$key){'KNOWN_ABSENT'}else{'PRESENT'}}finally{if($null-ne$key){$key.Dispose()};$base.Dispose()}
 $effect=[Fc79Capture]::Absence($spec.effectDir.TrimEnd('\'))
 @{registration=$reg;components=$com;marker=$mark;effect=$effect;knownAbsent=(@($reg.registrations).Count-eq 0 -and @($reg.related).Count-eq 0 -and $com.allUnknownStates -eq $true -and $mark-ceq 'KNOWN_ABSENT' -and $effect.status-ceq 'KNOWN_ABSENT')}
}
function Lines([string]$leaf){
 $p=Join-Path $Root $leaf;if(-not[IO.File]::Exists($p)){return @()}
 $f=[IO.File]::Open($p,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite)
 try{Need ($f.Length-le 65536) 'JOURNAL_BOUND';$r=[IO.StreamReader]::new($f,[Text.Encoding]::UTF8,$true);$text=$r.ReadToEnd()}finally{if($null-ne$r){$r.Dispose()}else{$f.Dispose()}}
 $parts=$text-split "`n";$rows=@();for($i=0;$i-lt $parts.Count-1;$i++){if($parts[$i].Length){$rows+=@($parts[$i]|ConvertFrom-Json)}};return $rows
}
function Run-Owner([string]$name){
 Need ($clock.ElapsedMilliseconds-lt 300000 -and -not$capture.NativeCloseUnknown) 'NO_NEW_OWNER_WITHOUT_300S_GATE_AND_HEALTHY_LEDGER'
 $before=State
 if($name-ceq 'owned-uninstall'){
  Need ($owned -and -not$before.knownAbsent) 'NO_UNINSTALL_WITHOUT_THIS_ATTEMPT_COMMIT_PROVENANCE'
  $rows=@($before.registration.registrations);Need ($rows.Count-eq 1 -and $rows[0].product-ceq $spec.productCode -and $rows[0].context-eq 2 -and $rows[0].sid-ceq $spec.expectedUserSid) 'EXACT_OWNED_PRODUCT_ONLY'
 }else{Need ($before.knownAbsent) 'PREEXISTING_PRODUCT_NOT_ADOPTED'}
 $case=[ordered]@{name=$name;before=$before;api=@();originalProcess=$null;originalThread=$null;after=$null;nativeReturnsComplete=$false;apiSuccessful=$false}
 $result.cases+=@($case);$exe=Join-Path $Root 'Owner.exe';$p=[Diagnostics.Process]::new();$p.StartInfo=[Diagnostics.ProcessStartInfo]::new();$p.StartInfo.FileName=$exe;$p.StartInfo.Arguments=$name;$p.StartInfo.UseShellExecute=$false;$p.StartInfo.CreateNoWindow=$true;$p.StartInfo.WorkingDirectory=$Root
 $script:returned=$false;Need ($p.Start()) 'OWNER_START_FAILED';$original=$p.Handle;$pidValue=[uint32]$p.Id;$created=$p.StartTime.ToUniversalTime().ToFileTimeUtc();$start=$clock.ElapsedMilliseconds
 $held=$capture.HoldStartedClient($original,$pidValue,$created,$exe,$build.owner.sha256,$spec.expectedUserSid);$case.originalProcess=$held
 while($true){
  Need (($clock.ElapsedMilliseconds-$start)-lt 2000) 'CAPTURE_ACK_2S_UNKNOWN_RETAIN'
  $lines=@(Lines ($name+'.jsonl'));if($lines.Count-gt 0){break};[void]$capture.Snapshot();Need ($held.Wait-eq 258) 'OWNER_EARLY_EXIT_BEFORE_CAPTURE';Start-Sleep -Milliseconds 5
 }
 $id=$lines[0];Need ($id.stage-ceq 'IDENTITY_PROCESS_CREATION' -and $id.return-eq 0 -and $id.object-eq $created -and $id.pid-eq $pidValue -and $id.tid-eq $id.originalTid -and $id.clockValid) 'ORIGINAL_OWNER_IDENTITY'
 # GetThreadTimes must use its own original creation; the native identity record
 # below is supplied by the compiled owner, not a guessed process creation time.
 $thread=$capture.HoldThread($pidValue,[uint32]$id.tid,[long]$id.threadCreation);$case.originalThread=$thread
 [void]$capture.Snapshot();Need ($held.Wait-eq 258 -and $thread.Wait-eq 258) 'ORIGINAL_OWNER_LIVE_BEFORE_ACK'
 $ack=[Text.Encoding]::ASCII.GetBytes($spec.nonce);$f=[IO.File]::Open((Join-Path $Root ($name+'.capture-ack')),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);try{$f.Write($ack,0,$ack.Length);$f.Flush($true)}finally{$f.Dispose()}
 while($true){[void]$capture.Snapshot();if($held.Wait-eq 0){break};Need (($clock.ElapsedMilliseconds-$start)-lt 120000 -and $clock.ElapsedMilliseconds-lt 600000) 'ORIGINAL_OWNER_120S_UNKNOWN_RETAIN';Start-Sleep -Milliseconds 5}
 Need ($held.ExitKnown -and $thread.Wait-eq 0 -and $thread.ExitKnown) 'ORIGINAL_PROCESS_THREAD_PHYSICAL_RETURN_REQUIRED';$case.actualExit=$held.ExitCode;$script:returned=$true;$p.Dispose()
 $case.api=@(Lines ($name+'.jsonl'));$case.elapsedMilliseconds=$clock.ElapsedMilliseconds-$start
 $seq=0;foreach($row in $case.api){$seq++;Need ($row.sequence-eq $seq -and $row.pid-eq $pidValue -and $row.tid-eq $id.tid -and $row.originalTid-eq $id.tid -and $row.clockValid) 'SAME_ORIGINAL_NATIVE_THREAD_SEQUENCE_REQUIRED'}
 $begin=@($case.api|Where-Object stage -CEQ 'BEGIN_RETURN');$install=@($case.api|Where-Object {$_.stage-cin @('INSTALL_RETURN','CONFIGURE_ABSENT_RETURN')});$end=@($case.api|Where-Object stage -CEQ 'END_RETURN');$close=@($case.api|Where-Object stage -CEQ 'MSI_HANDLE_CLOSE_RETURN');$event=@($case.api|Where-Object stage -CEQ 'CHANGE_EVENT_CLOSE_RETURN')
 $case.nativeReturnsComplete=($begin.Count-eq 1 -and $install.Count-eq 1 -and $end.Count-eq 1 -and $close.Count-eq 1 -and $event.Count-eq 1 -and @($case.api|Where-Object stage -CEQ 'ALL_API_CALLS_RETURNED').Count-eq 1)
 $case.after=State
 Need ($case.nativeReturnsComplete) 'ACTUAL_NATIVE_RETURNS_INCOMPLETE_RETAIN'
 # Capture actual End after 1603 before applying the success rule. Nonzero is
 # retained evidence and stops all subsequent MSI calls; it is never coerced.
 $case.apiSuccessful=($begin[0].return-eq 0 -and $end[0].return-eq 0 -and $close[0].return-eq 0 -and $event[0].return-eq 0 -and $held.ExitCode-eq 0)
 Write-New ($name+'-case.json') $case
 Need ($case.apiSuccessful) 'ACTUAL_BEGIN_END_OR_CLOSE_NEGATIVE_RETAIN_NO_NEW_MSI'
 if($name-ceq 'early-fail-rollback'){Need ($install[0].return-eq 1603 -and $case.after.knownAbsent) 'EARLY_FAIL_REAL_RETURN_OR_RECONCILIATION_FAILED'}
 elseif($name-ceq 'healthy-rollback'){Need ($install[0].return-eq 0 -and $case.after.knownAbsent) 'HEALTHY_ROLLBACK_FAILED'}
 elseif($name-ceq 'healthy-commit'){
  $script:owned=$true;Need ($install[0].return-eq 0 -and -not$case.after.knownAbsent -and $case.after.marker-ceq 'PRESENT' -and $case.after.effect.status-ceq 'PRESENT') 'HEALTHY_COMMIT_FAILED'
  $payload=Join-Path $spec.effectDir 'payload.txt';Need ((Hash $payload)-ceq $build.payload.sha256) 'COMMIT_PAYLOAD_EXACT_BYTES'
 }else{Need ($install[0].return-eq 0 -and $case.after.knownAbsent) 'OWNED_UNINSTALL_FAILED';$script:owned=$false}
}
try{
 Need ([IO.Path]::GetFullPath($Root)-ceq $Root) 'ROOT_CANONICAL'
 Need ((Hash (Join-Path $Root 'runtime-inputs.json'))-ceq $ManifestSha256) 'EXACT_MANIFEST_PIN'
 $manifest=Read-Json 'runtime-inputs.json';$spec=Read-Json 'spec.json';$build=Read-Json 'build-report.json'
 Need ($Root-ceq $spec.windowsRoot -and [IO.Path]::GetFileName($Root)-ceq $spec.rootName -and $spec.rootName-ceq ('FutureClassroom-r79-early-terminal-'+$spec.nonce) -and $spec.nonce-cmatch '^[0-9a-f]{32}$') 'EXACT_FRESH_NAMESPACE'
 Need ([IO.File]::ReadAllText((Join-Path $Root '.owner'))-ceq $spec.marker -and $spec.wholeSeconds-eq 600 -and $spec.nativeSeconds-eq 120 -and $spec.finallyReserveSeconds-eq 180) 'OWNER_BUDGET'
 $sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value;Need ($sid-ceq $spec.expectedUserSid) 'AUTHORIZED_USER'
 $d=[IO.DirectoryInfo]::new($Root);while($null-ne$d){Need (-not($d.Attributes-band[IO.FileAttributes]::ReparsePoint)) 'NO_REPARSE_ANCESTORS';$d=$d.Parent}
 $acl=Get-Acl -LiteralPath $Root;Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq $sid) 'PROTECTED_CURRENT_OWNER'
 $aces=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($aces.Count-eq 2) 'EXACT_TWO_ACES'
 foreach($a in $aces){Need ($a.AccessControlType-eq 'Allow' -and $a.IdentityReference.Value-in @($sid,'S-1-5-18') -and ($a.FileSystemRights-band[Security.AccessControl.FileSystemRights]::FullControl)-eq [Security.AccessControl.FileSystemRights]::FullControl) 'USER_SYSTEM_FULL_CONTROL_ONLY'}
 Need (@($aces|ForEach-Object {$_.IdentityReference.Value}|Sort-Object -Unique).Count-eq 2) 'DISTINCT_USER_SYSTEM'
 $expected=@('.owner','spec.json','Owner.exe','EarlyTerminal.dll','payload.txt','healthy.msi','early-fail.msi','build-report.json','Capture.cs','Invoke-ControlledOwner.ps1')
 Need (@($manifest.files).Count-eq $expected.Count -and @(Compare-Object ($expected|Sort-Object) (@($manifest.files|ForEach-Object {$_.path})|Sort-Object)).Count-eq 0 -and @($manifest.files|ForEach-Object {$_.path}|Sort-Object -Unique).Count-eq $expected.Count) 'EXACT_INPUT_CLOSURE'
 foreach($item in $manifest.files){Need ($item.path-cmatch '^[A-Za-z0-9._-]+$') 'DIRECT_INPUT_ONLY';$p=Join-Path $Root $item.path;Need ((Hash $p)-ceq $item.sha256 -and ([IO.FileInfo]::new($p).Length)-eq $item.bytes) 'INPUT_BYTES_CHANGED'}
 Need ($build.status-ceq 'PASS_STATIC_ONLY_WINDOWS_NOT_RUN' -and $build.spec.sha256-ceq (Hash (Join-Path $Root 'spec.json'))) 'ORIGINAL_BUILD_BINDING'
 $oldTemp=$env:TEMP;$oldTmp=$env:TMP;$env:TEMP=Join-Path $Root 'compiler-temp';$env:TMP=$env:TEMP
 try{[void][IO.Directory]::CreateDirectory($env:TEMP);Add-Type -Path (Join-Path $Root 'Capture.cs')}finally{$env:TEMP=$oldTemp;$env:TMP=$oldTmp}
 $capture=[Fc79Capture]::new();$result.before=State;Need ($result.before.knownAbsent) 'PREEXISTING_NAMESPACE_NO_INSTALL'
 foreach($name in @('early-fail-rollback','healthy-rollback','healthy-commit','owned-uninstall')){Run-Owner $name}
 $result.after=State;$result.afterFinally=$result.after;Need ($result.after.knownAbsent) 'FINAL_EFFECTS_NOT_ABSENT';$result.status='PASS_REAL_BEGIN_INSTALL_END_CLOSE_AND_PHYSICAL_EXIT_NOT_PRODUCTION_AUTHORITY'
}catch{$result.errors+=@($_.Exception.Message)}finally{
 # No automatic /x: cleanup is the fourth controlled-owner case, authorized only
 # by this run's committed product proof. On uncertainty retain all originals.
 if($null-ne$capture){try{$result.originalCaps=$capture.Snapshot();if($returned -and -not$capture.NativeCloseUnknown){$result.originalCaps=$capture.FinishAndClose()};$result.nativeCloseUnknown=$capture.NativeCloseUnknown;$result.nativeCloseFacts=$capture.NativeReturns()}catch{$result.errors+=@($_.Exception.Message)}}
 $result.elapsedMilliseconds=$clock.ElapsedMilliseconds;$result.ownedCommitOutstanding=$owned;$result.originalOwnerReturned=$returned
 try{Write-New 'controlled-owner-result.json' $result}catch{[Console]::Error.WriteLine($_.Exception.Message);exit 91}
}
$result|ConvertTo-Json -Depth 60 -Compress
if($result.status-ceq 'PASS_REAL_BEGIN_INSTALL_END_CLOSE_AND_PHYSICAL_EXIT_NOT_PRODUCTION_AUTHORITY' -and @($result.errors).Count-eq 0){exit 0}else{exit 90}
