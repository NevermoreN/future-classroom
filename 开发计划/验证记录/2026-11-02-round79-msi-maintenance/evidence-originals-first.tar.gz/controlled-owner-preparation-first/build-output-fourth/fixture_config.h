#define FC79_NONCE L"88144a0a8a674ee18e9311d9c3e4cba3"
#define FC79_PRODUCT L"{137D9B70-202A-4E93-AA35-51ECE39893E7}"
#define FC79_EFFECT_DIR L"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-88144a0a8a674ee18e9311d9c3e4cba3\\effect\\"
