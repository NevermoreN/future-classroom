#define UNICODE
#define _UNICODE
#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0601
#include <windows.h>
#include <msi.h>
#include <shellapi.h>
#include <stdio.h>
#include <wchar.h>
#include <string.h>
#include "owner_config.h"

/* Test-only original API owner. No Pending, gate, Join, production receipt,
 * callback-derived authority, cancellation kill, retry-close or shared-host wait. */
static HANDLE journal = INVALID_HANDLE_VALUE;
static DWORD original_thread;
static BOOL journal_ok = TRUE;
static ULONGLONG started;
static const WCHAR *scenario;
static unsigned number;
static ULONGLONG thread_creation;
static BOOL emit(const char *stage, UINT rc, BOOL attempted, ULONGLONG object) {
    LARGE_INTEGER q, f; char text[1024]; DWORD written=0;
    BOOL clock_ok=QueryPerformanceCounter(&q)&&QueryPerformanceFrequency(&f);
    int n=snprintf(text,sizeof(text),"{\"sequence\":%u,\"stage\":\"%s\",\"attempted\":%s,\"return\":%u,\"object\":%llu,\"pid\":%lu,\"tid\":%lu,\"originalTid\":%lu,\"threadCreation\":%llu,\"qpc\":%lld,\"frequency\":%lld,\"clockValid\":%s}\n",++number,stage,attempted?"true":"false",rc,object,GetCurrentProcessId(),GetCurrentThreadId(),original_thread,thread_creation,clock_ok?q.QuadPart:0,clock_ok?f.QuadPart:0,clock_ok?"true":"false");
    if(!clock_ok||GetCurrentThreadId()!=original_thread||n<=0||(size_t)n>=sizeof(text)||!WriteFile(journal,text,(DWORD)n,&written,NULL)||written!=(DWORD)n||!FlushFileBuffers(journal))journal_ok=FALSE;
    return journal_ok;
}
static BOOL path(WCHAR *out,const WCHAR *suffix) {
    int n=swprintf(out,1024,L"%ls\\%ls%ls",FC_OWNER_ROOT,scenario,suffix);
    return n>0&&n<1024;
}
static BOOL ack(void) {
    WCHAR p[1024]; if(!path(p,L".capture-ack"))return FALSE;
    while(GetTickCount64()-started<2000) {
        HANDLE h=CreateFileW(p,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_FLAG_OPEN_REPARSE_POINT,NULL);
        if(h!=INVALID_HANDLE_VALUE) {
            BY_HANDLE_FILE_INFORMATION info;char b[64];DWORD n=0;
            BOOL valid=GetFileInformationByHandle(h,&info)&&!(info.dwFileAttributes&(FILE_ATTRIBUTE_DIRECTORY|FILE_ATTRIBUTE_REPARSE_POINT))&&info.nNumberOfLinks==1&&ReadFile(h,b,sizeof(b),&n,NULL)&&n==sizeof(FC_OWNER_NONCE)-1&&memcmp(b,FC_OWNER_NONCE,n)==0;
            BOOL closed=CloseHandle(h);DWORD err=closed?0:GetLastError();emit("ACK_HANDLE_CLOSE",err,TRUE,(ULONGLONG)(ULONG_PTR)h);
            return valid&&closed&&journal_ok;
        }
        DWORD e=GetLastError();if(e!=ERROR_FILE_NOT_FOUND&&e!=ERROR_PATH_NOT_FOUND)return FALSE;
        Sleep(5);
    }
    return FALSE;
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE previous,LPWSTR command,int show) {
    (void)instance;(void)previous;(void)command;(void)show;
    int count=0;LPWSTR *args=CommandLineToArgvW(GetCommandLineW(),&count);
    if(args==NULL||count!=2)return 70;
    WCHAR mode[32];if(wcslen(args[1])>=32){LocalFree(args);return 71;}wcscpy(mode,args[1]);
    if(LocalFree(args)!=NULL)return 72;
    if(wcscmp(mode,L"early-fail-rollback")&&wcscmp(mode,L"healthy-rollback")&&wcscmp(mode,L"healthy-commit")&&wcscmp(mode,L"owned-uninstall"))return 73;
    scenario=mode;original_thread=GetCurrentThreadId();started=GetTickCount64();
    WCHAR p[1024];if(!path(p,L".jsonl"))return 74;
    journal=CreateFileW(p,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,NULL);
    if(journal==INVALID_HANDLE_VALUE)return 75;
    FILETIME a,b,c,d,ta,tb,tc,td;BOOL times=GetProcessTimes(GetCurrentProcess(),&a,&b,&c,&d)&&GetThreadTimes(GetCurrentThread(),&ta,&tb,&tc,&td);
    thread_creation=times?(((ULONGLONG)ta.dwHighDateTime<<32)|ta.dwLowDateTime):0;
    ULONGLONG creation=times?(((ULONGLONG)a.dwHighDateTime<<32)|a.dwLowDateTime):0;
    emit("IDENTITY_PROCESS_CREATION",times?0:GetLastError(),TRUE,creation);
    if(!times||!journal_ok||!ack())goto failed_before_begin;
    MSIHANDLE transaction=0;HANDLE change=NULL;
    UINT begin=MsiBeginTransactionW(L"FutureClassroom R79 controlled owner",0,&transaction,&change);
    emit("BEGIN_RETURN",begin,TRUE,transaction);emit("BEGIN_CHANGE_EVENT",0,FALSE,(ULONGLONG)(ULONG_PTR)change);
    UINT install=0xffffffffu,end=0xffffffffu,msi_close=0xffffffffu;BOOL change_close=TRUE;
    BOOL uninstall=wcscmp(mode,L"owned-uninstall")==0;
    BOOL commit=wcscmp(mode,L"healthy-commit")==0||uninstall;
    if(begin==ERROR_SUCCESS) {
        /* Before this point there has been no install API. The caller actually
         * owns Begin; hInstall or an inherited numeric ID is never substituted. */
        if(journal_ok&&GetTickCount64()-started<120000) {
            WCHAR log[1024];if(!path(log,L"-msi.log"))goto rollback;
            UINT logging=MsiEnableLogW(INSTALLLOGMODE_VERBOSE|INSTALLLOGMODE_EXTRADEBUG|INSTALLLOGMODE_INFO|INSTALLLOGMODE_ERROR|INSTALLLOGMODE_WARNING|INSTALLLOGMODE_ACTIONSTART|INSTALLLOGMODE_ACTIONDATA|INSTALLLOGMODE_COMMONDATA,log,INSTALLLOGATTRIBUTES_FLUSHEACHLINE);
            emit("LOG_ENABLE_RETURN",logging,TRUE,0);
            if(logging==0&&journal_ok) {
                MsiSetInternalUI(INSTALLUILEVEL_NONE,NULL);
                emit("INSTALL_ENTER",0,FALSE,transaction);
                if(uninstall)install=MsiConfigureProductExW(FC_OWNER_PRODUCT,INSTALLLEVEL_DEFAULT,INSTALLSTATE_ABSENT,L"REBOOT=ReallySuppress MSIRESTARTMANAGERCONTROL=DisableShutdown");
                else install=MsiInstallProductW(wcscmp(mode,L"early-fail-rollback")==0?FC_OWNER_EARLY_MSI:FC_OWNER_HEALTHY_MSI,L"REBOOT=ReallySuppress MSIRESTARTMANAGERCONTROL=DisableShutdown");
                emit(uninstall?"CONFIGURE_ABSENT_RETURN":"INSTALL_RETURN",install,TRUE,transaction);
            }
        }
rollback:;
        /* This is an experiment: End's actual value is recorded, never assumed
         * zero after a 1603 install. No retry and no synthesized Join0. */
        UINT state=commit&&install==ERROR_SUCCESS&&journal_ok?MSITRANSACTIONSTATE_COMMIT:MSITRANSACTIONSTATE_ROLLBACK;
        emit(state==MSITRANSACTIONSTATE_COMMIT?"END_COMMIT_ENTER":"END_ROLLBACK_ENTER",0,FALSE,transaction);
        end=MsiEndTransaction(state);emit("END_RETURN",end,TRUE,transaction);
    }
    if(transaction!=0) {msi_close=MsiCloseHandle(transaction);emit("MSI_HANDLE_CLOSE_RETURN",msi_close,TRUE,transaction);}
    else emit("MSI_HANDLE_CLOSE_NOT_ACQUIRED",0,FALSE,0);
    if(change!=NULL) {change_close=CloseHandle(change);DWORD e=change_close?0:GetLastError();emit("CHANGE_EVENT_CLOSE_RETURN",e,TRUE,(ULONGLONG)(ULONG_PTR)change);}
    else emit("CHANGE_EVENT_NOT_ACQUIRED",0,FALSE,0);
    emit("ALL_API_CALLS_RETURNED",0,FALSE,0);
    BOOL before_close=journal_ok;BOOL file_close=CloseHandle(journal);
    /* Return 0 means all native return values were captured and owned resources
     * checked returned, not that InstallProduct succeeded or End was zero. */
    return before_close&&file_close&&change_close&&(transaction==0||msi_close==0)?0:76;
failed_before_begin:
    emit("NO_BEGIN_NO_INSTALL",0,FALSE,0);
    {BOOL closed=CloseHandle(journal);return closed?77:78;}
}
