#define FC79_NONCE L"a9db75a82eb546389b51cc9917c9be69"
#define FC79_PRODUCT L"{888AEF66-960C-47FB-BC6A-B291AAFD9831}"
#define FC79_EFFECT_DIR L"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-a9db75a82eb546389b51cc9917c9be69\\effect\\"
