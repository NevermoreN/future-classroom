#define FC79_NONCE L"f1097f009c13483aacf058c69f180a53"
#define FC79_PRODUCT L"{ABEF030D-572B-4550-A9FB-5255016A0337}"
#define FC79_EFFECT_DIR L"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-f1097f009c13483aacf058c69f180a53\\effect\\"
