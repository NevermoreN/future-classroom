# R79 original Begin-owner finite experiment

Status: local compiled preparation only; **Windows NOT_RUN**. Root is the sole
Windows executor. No production source, Pending/gate, credentials, service,
firewall, SSH key, global compiler/cache, or existing product is changed here.

The original guardian now owns `MsiBeginTransactionW` **before** any install API.
The same original native thread records synchronous `MsiInstallProductW` return,
then actual `MsiEndTransaction` return, one `MsiCloseHandle` attempt for its actual
Begin handle and one `CloseHandle` attempt for its ownership-change event.
There is no Join call, and no synthetic Join0. DLL callbacks remain diagnostic.

The observational predecessor is a counterexample: its client returned 0 and
the -1 success callback ran, but the genuine chainer Join0/EndRollback0 ended
with product absent. Neither -1/-3 callbacks nor API install success stand in
for the original transaction owner's End result.

## Frozen inputs to execute

Use **build-output-fourth/stage** only. Third was a successful local build before
a defensive fix: Begin0 with invalid output cannot install; Begin failure does
not attempt to close unacquired/undefined output values. First and second local
build failures are retained with actual compiler output; never run those images.

Fourth fresh namespace: nonce `88144a0a8a674ee18e9311d9c3e4cba3`; this has never
been installed. It does not reuse, reopen or claim the deleted old namespace.
All product/upgrade/component GUIDs and marker paths are fresh. The DLL source
is byte-identical to the tested observer but compiled with this new namespace.
There is one HKCU32 marker and one payload. There is no chainer Binary or
MsiEmbeddedChainer table. Every authored table, observer Binary and payload CAB
is read back by the local producer; six actions and their sequence are exact.

`python3 -B build.py` is inert. Explicit local-only build command is
`python3 -B build.py --execute --output /absolute/fresh/output`.
That creates a new namespace rather than changing frozen fourth inputs.

Windows phase entry (root supplies exact protected directory/manifest SHA):

```powershell
powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File Invoke-ControlledOwner.ps1 -Execute -Root <spec.windowsRoot> -ManifestSha256 <stage manifest SHA256>
```

The directory must already be fresh and protected to exactly current user and
SYSTEM full control, no reparse ancestors. The phase checks its marker, exact
ten-file manifest, every input byte, spec namespace/SID and original local build.
No persistent execution-policy change is required. Root's transport must check
known absence before creating it, download all originals before exact cleanup,
and independently verify product/component/marker/cache/module paths at the end.

## Cases and independent facts

1. Early failure: Begin -> InstallProduct returning the **actual** value (expected
   1603 due to ForceFail6501 after InstallExecute6500) -> actual EndRollback ->
   actual handle/event close -> original process and original thread exit.
   EndRollback is **not pre-assumed 0**. An actual nonzero is preserved in the
   journal and downloaded result and stops new cases; it never earns settlement.
2. Healthy installation with deliberate actual outer Rollback, effects absent.
3. Healthy installation and actual Commit, exact payload and marker present.
4. Formal `MsiConfigureProductExW(...ABSENT...)` in another actual Begin/Commit,
   only for the product committed by case 3 in this run; exact registration SID
   and context must agree. No unknown existing product is ever uninstalled.

Before each first three cases, full exact product/related/component/marker/effect
absence is required. Fourth requires this run's commit provenance. There is no
blanket finally `/x`, registry/cache deletion, shared MSI process termination or
handover to another owner. A timeout, close error or incomplete native return
retains originals and stops additional mutation. Root may separately execute a
reviewed provenance-bound cleanup after observing exact original returns.

Original Start process handle is duplicated and checked for creation/image/hash/
SID by the previously tested Capture.cs. The native process first publishes its
own process creation and native-thread creation. Parent captures that exact
thread and verifies both original objects live, then publishes a nonce ACK.
Only then does native Begin run. The same original tid and monotone sequence are
verified for all API records. Parent awaits native objects, reads actual exit
from those held objects, and checked-closes each one; no exit code is inferred
from a nullable managed Process.ExitCode.

Native return 0 means all native returns were captured, the journal really
closed and owned MSI/event resources checked returned. It **does not** assert
Install or End success. The driver checks Begin/End/close independently after
recording their actual values. Journal close happens after the final durable
record, so its result is proven by original exit0 rather than a record written
to an already closed handle. Per-case JSON is written before final capture-handle
close; the final result contains the actual checked-close facts.

## Budget and limitations

600 seconds total, 120 seconds for each original native owner including its
2-second initial capture ACK, 180 seconds cleanup reserve; no new case starts
at or after 300 seconds. There are four original owners maximum and eight held
process/thread objects; the fixed 64 handle/8 owner limits are not enlarged.
The timer is a bound on positive continuation; it cannot prove that an ongoing
blocking MSI call has returned. No timer expiration fabricates that return.

Production admission remains false. This experiment has no real product repair,
Draft/armed Pending, parent death protocol, staged-effect decision channel,
rollback preimage authority, ARP entry design, upgrade, cancel, Run preservation,
Win7/Win10 real-machine or Seewo device evidence. Those are independent gates.
