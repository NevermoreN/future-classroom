from pathlib import Path
import json,hashlib,difflib,ast
E=Path('/tmp/fc-round79-msi-maintenance');out=E/'controlled-owner-independent-review-third';out.mkdir(exist_ok=False)
a=E/'controlled-owner-append-preparation-first';b=E/'controlled-owner-handle-design-first/prototype-preparation-first';t=E/'controlled-owner-transport-preparation-third';old=E/'controlled-owner-transport-preparation-second'
def fact(p):
 z=p.read_bytes();return dict(path=str(p.relative_to(E)),bytes=len(z),sha256=hashlib.sha256(z).hexdigest())
def pinfreeze(p,sha):
 assert fact(p)['sha256']==sha
 f=json.loads(p.read_bytes())
 for r in f['files']:
  ff=fact(p.parent/r['path']);assert all(ff[k]==r[k] for k in ('bytes','sha256')),r['path']
 return {'freeze':fact(p),'filesVerified':len(f['files'])}
source=pinfreeze(a/'freeze-first.json','5a773afadaf831b1bd1c97a88fdd0fad3048c227e6f4538a153d31aa78404d90');transport=pinfreeze(t/'freeze-third.json','5d945ba91a75703c246b44c52e28a40d074a8a0504cbd1245bcaaaf6ae1e70ce')
unchanged=[]
for n in ['Capture.cs','EarlyTerminal.c','Invoke-ControlledOwner.ps1','build.py','fixture-original.py','tools.json','child-environment.json']:
 assert (a/n).read_bytes()==(b/n).read_bytes();unchanged.append(fact(a/n))
x=(b/'Owner.c').read_bytes();y=(a/'Owner.c').read_bytes();assert x.count(b'log,INSTALLLOGATTRIBUTES_FLUSHEACHLINE);')==1
assert x.replace(b'log,INSTALLLOGATTRIBUTES_FLUSHEACHLINE);',b'log,INSTALLLOGATTRIBUTES_APPEND|INSTALLLOGATTRIBUTES_FLUSHEACHLINE);')==y
prior=json.loads((b/'build-output-first/spec.json').read_bytes());new=json.loads((a/'build-output-first/spec.json').read_bytes())
for k in ['nonce','rootName','windowsRoot','productCode','componentId','upgradeCode','registryKey']:assert new[k]!=prior[k],k
for k in ['wholeSeconds','nativeSeconds','clientSeconds','finallyReserveSeconds','maximumHandles','maximumOwners','expectedUserSid','sourceGit']:assert new[k]==prior[k],k
build=json.loads((a/'build-output-first/build-report.json').read_bytes());assert build['status']=='PASS_STATIC_ONLY_WINDOWS_NOT_RUN' and build['sourcesUnchanged'] and build['toolsUnchanged']
for r in build['commands']:
 assert r['actualExit']==0 and r['parentReaped'] is True
 for suffix in ['stdout','stderr']:assert fact(a/'build-output-first'/(r['label']+'.'+suffix))['sha256']==r[suffix+'Sha256']
manifest=json.loads((a/'build-output-first/stage/runtime-inputs.json').read_bytes());assert len(manifest['files'])==10
for r in manifest['files']:
 f=fact(a/'build-output-first/stage'/r['path']);assert all(f[k]==r[k] for k in ['bytes','sha256'])
s=(old/'run-controlled-owner-second.py').read_text();u=(t/'run-controlled-owner-third.py').read_text()
s=s.replace("PROTOTYPE=E/'controlled-owner-handle-design-first'\nSOURCE_DIR=PROTOTYPE/'prototype-preparation-first'","PROTOTYPE=E/'controlled-owner-append-preparation-first'\nSOURCE_DIR=PROTOTYPE")
s=s.replace("freeze['status']=='FROZEN_PRIMARY_RESEARCH_AND_LOCAL_ACTUAL_STATIC_PROTOTYPE_WINDOWS_NOT_RUN'","freeze['status']=='FROZEN_ONE_LINE_APPEND_LOGGING_CORRECTION_LOCAL_ACTUAL_STATIC_PASS_WINDOWS_NOT_RUN'")
s=s.replace("stage==owned(PROTOTYPE/json.loads((PROTOTYPE/'execution-plan-first.json').read_text())['stage'])","stage==owned(PROTOTYPE/'build-output-first/stage')")
assert s==u,'UNREVIEWED_TRANSPORT_DELTA'
assert "Actual engine ForceFail action return3, not only intended callback return" in u
ast.parse(u)
# No imported source is executed, compiled, or connected to Windows.
report={'schemaVersion':1,'status':'PASS_FINITE_ONE_LINE_APPEND_AND_TRANSPORT_REBIND_DELTA_WINDOWS_NOT_RUN','authority':'NO_PRODUCTION_AUTHORITY','source':source,'transport':transport,'unchangedSevenInputs':unchanged,'change':{'before':'INSTALLLOGATTRIBUTES_FLUSHEACHLINE','after':'INSTALLLOGATTRIBUTES_APPEND|INSTALLLOGATTRIBUTES_FLUSHEACHLINE','onlyOwnerLineChanged':True,'nativeOwner':fact(a/'Owner.c')},'primarySource':{'url':'https://learn.microsoft.com/en-us/windows/win32/api/msi/nf-msi-msienablelogw','verified':'2026-11-02 UTC','finding':'APPEND preserves an existing log; absent APPEND overwrites an existing named log. FLUSHEACHLINE controls buffer flushing.','inference':'Adding APPEND addresses the observed possible earlier API segment overwrite. Only new runtime can prove complete callback and engine evidence; no prior FAIL upgraded.'},'localBuild':{'report':fact(a/'build-output-first/build-report.json'),'commandsActualExitZeroAndParentReaped':len(build['commands']),'stdoutStderrRawHashVerified':True,'noRebuildByReviewer':True},'stage':{'manifest':fact(a/'build-output-first/stage/runtime-inputs.json'),'exactOriginalFilesVerified':10,'newNamespaceFieldsDifferent':7},'transportDelta':'Only prototype/source directory, expected source-freeze status and exact stage location changed. All runtime, scenario, return3, capture, cleanup and budgets/assertions byte-identical to second transport.','gatesPreserved':['actual original Begin/Install/End return and captured G/thread physical return','PREPARE action actually observed','ForceFail intended1603 and rollback0, rollback action actualmode1 and intended0','current nonce/product/productRc0/valid1/x86/tokenclose1','root downloaded engine ForceFail actual Action Return value3','600s whole/120s native/180s reserve/300s new owner/64handles/8owners','unknown original handle or close preserves originals; no shared-service kill/manual cache or registry deletion'],'priorFailures':'Both first and second runtime FAIL remain original and scoped; second Begin0 Install1603 EndRollback0 eventClose0 originalG/thread0 did not prove callback actions because final log lacked earlier segments.','execution':{'Windows':'NOT_RUN_BY_REVIEWER','cargo':False,'compile':False,'oldFrozenModified':False,'mainModified':False},'next':'Root-only serial execution of exact third plan after prior scratch cleanup is proven. Actual runtime gates remain mandatory.'}
(out/'review-first.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
freeze={'status':'FROZEN_FINITE_DELTA_REVIEW_NOT_RUNTIME','files':[fact(out/'review-first.json')]}
(out/'freeze-first.json').write_text(json.dumps(freeze,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'review':fact(out/'review-first.json'),'freeze':fact(out/'freeze-first.json')}))
