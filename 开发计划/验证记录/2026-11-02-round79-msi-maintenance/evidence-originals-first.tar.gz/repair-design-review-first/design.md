# R79：真正的 MSI 修复与失败回滚下一步

本报告基于主树 `c44906517fbc62233dca755d7225cea375264cbc`，只读审计。没有修改产品、构建或操作 Windows。R78 已证明同源正常安装、健康重应用、正式卸载及自动映像清理；不能据此证明损坏修复和完整失败回滚。

建议下一项直接实现**同产品、同版本、固定目录内的缺失/内容损坏文件修复，加真实损坏前像回滚核对**。拒绝矩阵仍是安全回归，不是这项能力的交付。

## 需求与约束来源

- D11 总计划 43 行要求 ZIP/MSI；108 行要求真实登录及升级/卸载验收；126 行要求卸载默认保留学校资料、升级不清空；128 行要求系统变更记录、读回和补偿，不把 SQLite 回滚当系统回滚。任务 P5-03、Q13 要求净环境分系统安装、升级/恢复/卸载及版本一致；Q03 要求核对本项目系统项归属。数据损坏不能变成重置学校/凭据的理由。
- 当前任务明确要求真正的 MSI 自动损坏修复/失败回滚。D11 没有逐字规定“正常启动时无人确认地运行 MSI”或“用 advertised shortcut 自动修复”；不能擅自增加后台安装、任务、自启动修改或清空数据。这里的自动修复是正式 MSI 修复入口自动恢复自己的受损安装文件。
- 最新用户要求保留持续 SSH 授权、不打断现有工作、测试后清理，只提供现有 Win11；Win7/10 仍须兼容并保留各自未运行事实。桌面免验证与 MSI 维护不是同一权限边界，不能借此取消设置/教师权限。
- `Run 必须不存在`、`同版本维护之前必须全部健康`、不支持损坏修复/升级，是先前候选切片的准入限制，不是 D11 最终产品能力。需要逐步替换这些限制，不能把它们永久列为用户不支持场景。
- 原始进程/句柄能力、实际 Join/End、原 guardian 返回、独立效果核对、未知时保留 Pending，是已有实现的安全契约；本次不降低。120 秒、64 句柄/8 owner 等是后续实现预算，不能谎称是用户直接给出的 MSI 数字，本次仍保留，不借修复扩大。
- “任意外部变换 MSI/任意同用户恶意进程下绝对原子、任意 OS 调度硬实时”不是本次新增发布门槛。范围仍为受控原候选。拒绝重解析、硬链接、越界目录、未知身份和外部不明项具有实际所有权理由，不能删掉。

## 当前缺口：具体代码路径

1. `effects.rs:365–389` 以实际 VersionString 判断已安装后，立即调用 `present()`；`present():721–728` 要求精确注册、全部目标文件及全部 marker。`files():569–595` 对每件 OPEN_EXISTING、长度与 SHA 全等；任何缺件/坏字节都在 Begin ACK 前拒绝。`component_registration():694–720` 也只接受 LOCAL；缺失 marker/keypath 的修复同样到不了 MSI。
2. `ExpectedState` 只有 Present/Absent，`Decision::observed():51–68` 将同版本失败回滚固定为 Present。它无法描述“一个文件原来缺失、另一个原来损坏”；恢复这个真实前像后仍会被 `reconcile():751–765` 拒绝。简单放宽 `present()` 会让旧的回滚证明失真。
3. 包内每文件 Component 以 HKCU DWORD marker 为 KeyPath，文件自身 `KeyPath=no`。marker 仍在时，文件缺失不等于组件 keypath 缺失；这不是已实现的文件自愈触发器。File 表 Attributes=512，没有 checksum 位；不能把 `/fc` 或“文件存在”当完整内容修复。R78 的强制重应用 `REINSTALL=ALL REINSTALLMODE=amus` 有实际完整效果证据，但之前仅针对健康前像。
4. 失败回滚还缺一个独立分支：`native/broker.rs:820–948` 只能经真实 SUP/GUARDIAN、ENDED(join/end0)、guardian0 后结算。若正常安装失败发生于 InstallFiles/InstallExecute 而 embedded chainer 没有运行，这条链不可达。当前会保持未知/Pending；这符合保守行为，却不是完整失败回滚交付。共享 MSI 服务进程长期存活，不能等待它死亡充当本事务结束。

## 推荐首个产品实现闭包

### 1. 两种独立的状态，不再混为健康准入

将已注册产品的**身份/所有权准入**与**健康内容验证**分开。前者继续严格验证实际当前 SID、per-user unmanaged、唯一 ProductCode/Version/related family、固定 known-folder 目标、闭集 component GUID 与正确 keypath 归属，不读取或执行损坏的 app/manifest 文件来产生 authority。受信期望仍来自原 MSI 正常 helper 的不可变 overlay。

新增 native 私有 `PreimageSnapshot`。按 manifest 索引记录每个受管叶的 `KnownAbsent` 或 `KnownRegular{actualLength,actualSha}`、存在的受管目录集合、marker 状态及产品注册事实。初次成功切片可先支持**组件/marker 注册健康但文件缺失、截断、改字节**，真正修复这些内容；同时明确 marker/keypath 损坏是下一项实现，不能称完整损坏修复。后续扩展 typed marker 缺失/错误值及可证组件状态，不把一切异常状态统称可修复。

读取必须有界、通过真实非 reparse/single-link 句柄，保留现有目录 ACL/namespace 检查。外来额外文件、错 keypath、其他 context/version、读取失败、未拥有路径仍拒绝。固定名内被破坏的 exe 只是待哈希数据，绝不执行。实际坏文件超出安全读界时报告明确受限损坏类别，不无限分配。

Snapshot 是原 broker 的类型化内存状态，供原 owner 的这次事务使用；不增加 public packet/CLI bool。最多72条，索引复用 manifest 路径，不把任意内容复制进内存或增加备份副本。`MAX_PENDING_BYTES=4096` 不变；初次不把内存快照冒充掉电恢复日志。掉电后仍保留原 Pending，后续需独立持久恢复设计。

### 2. 双 guard 与实际 rollback 证明

Begin 前先捕获有限前像；取得原 exclusive owner 后再次核对同一前像，实际返还所有 preimage pins 后才 ACK，允许 MSI 真正写入/删除。不能把 pins 一直拿着阻止 MSI，再把失败归因环境。

保持 tag5 的中性同产品维护意义，避免用 REMOVE/REINSTALL/Installed/客户端声明授操作权限。stage 若完整期望 payload+markers，选 Commit/ExpectedPresent；若是已注册产品的完整卸载效果，选 Commit/ExpectedAbsent；partial/未知选真实 Rollback/ExpectedCapturedPreimage。

guardian 必须仍真正 Join/End 并退出，broker 才独立检查结果：Commit 验完整受信 manifest 或正式卸载效果；Rollback 验原实际缺失集合、坏文件实际哈希/长度、marker/注册等前像语义完全恢复。MSI 合法恢复文件可能换 inode，不能凭空要求回滚后一定保留原文件 ID；原 ID 用于捕获时连续性，回滚完成核对真实路径/类型/字节及安全属性。未知效果、原句柄关闭失败或 guardian 未归还仍不能 clear Pending。

### 3. 真正执行修复

首个受控入口可直接使用既有原 MSI `/i <原包> REINSTALL=ALL REINSTALLMODE=amus`，由 Windows Installer 自动完成替换及 registry repair；它是执行方式，不是 native 权限证明。不能只开放损坏准入却仍让默认版本规则跳过坏的非版本文件。

如产品需普通维护 UI/标准 Repair 按钮同样可靠修复，包装器还需显式设置相应维修方式，并由最终闭表 checker 检查。不要假设裸 `/f` 默认会覆盖所有内容，或随意给没有合法 PE checksum 的文件加 checksum 位。若要真正“激活 shortcut 后自愈”，必须另做 advertised/file-keypath 方案、组件规则及 UI 需求评估；本次不暗加该功能。

## 早期失败回滚：必须正面解决的后续闭包

先区分两件事：Windows Installer 已恢复文件，不等于产品 broker 有足够证据释放原 Pending。现阶段不能将这两者合并。

**生产启用顺序是联合闭包**：可以在隔离工作树实现并单测 snapshot/repair，但不能先在主候选开放损坏准入，再把正常 early-fail 留成新的 Pending 死路。早期终态适配的可行性证据和生产接线须先收敛，二者共同构成候选；不要求等待所有无关 P5 项才能编写这部分产品代码。

在已运行 guardian 的分支，上述 snapshot 足以实现并验证恢复原损坏前像。对 chainer 启动前的真实引擎失败，需要一项**与当前真实引擎事务终态绑定的生产接线**，不能只复活以前已删除的 rollback/commit notice，把同 SID/同 image/公开 nonce 当结算 authority。可先用相同受控候选的真实取消/安装失败实验确认具体顺序；证明之前不得称此分支实现。

若现 EXE-only/MSI 表接口无法提供可信的早期终态能力，必须明确升级设计范围（如真正 session-capability 桥接/原事务拥有者组合），由 root 决定实现，不将来源不明 notice 改名为“可信回滚”。negative sequence -2/-3 或 rollback CA 只说明调度时机，不自动证明原 guardian Join/End/return，也不能等 MSI 服务死亡。不要重新尝试已被实测否决的 Type130 等待晚 guardian 闭环或扩大120秒。

### 最小可实现的原生适配 prototype

推荐 root 授权一个新隔离工作树的 **4 件有限 prototype**，先回答真正阻塞生产实现的事实：

1. 一份 test-only x86 Native DLL，4 个入口：`Prepare(hInstall)` 即时记录真实上下文；`ObserveRollback(hInstall)` 以 type1281 在1501安排；`ForceFail(hInstall)` 以 type1 在已执行实际安装脚本的 `InstallExecute6500` 后6501返回固定1603；`ObserveTerminal(hInstall)` 在-2/-3终态分支安排。它们只调用实际 hInstall 的受支持查询并发出有界原 MSI record 日志，不持有产品 gate、不写 Pending、不执行原产品 CLI、不操作学校/Run。ForceFail 是独立合成包的固定行为，不是正常产品的公开绕过开关。
2. 一份精确 author/check 工具：唯一 nonce Product/Upgrade/Component、一个测试文件及 HKCU32 marker、正常 rollback 启用；无 transform、服务、Run、学校目录。保持 embedded chainer 正常配置，辨别 early-fail 后它实际是否创建。Rollback CA 在被逆转的动作之前安排，保证反序时观察相关资源已回到前像；最终日志与实际资源读回仍分别保存。
3. 复用已证明真正 Join/EndRollback 的 supervisor/child 程序作不含 ForceFail 的正控，不重写成 sentinel。该正控和 early-fail 是不同原件，不把前者 API 成功借给后者。
4. 一个 quiet driver：原进程句柄记录 client/DLL宿主/线程/实际 token（含真实 impersonation 事实）、creation/module身份、回调模式/前像/日志顺序，保存真实client整数退出、所有返回/关闭和正式/x必要清理。若 DLL宿主/线程是共享或池化而不退出，必须记录这一事实，不能等共享服务死亡。非法/0/普通 package-handle 的调用不能被当作真实 rollback mode 正控。

`_MSIExecute` 只作为**实际原同步对象的时序观察候选**：原句柄、对象范围和每次 API/关闭返回都须记录；不能用名称、存在/缺失、一次可取锁或 callback 发事件推断本事务完成。若观察不到原事务范围/实际回调返回的可靠边界，明确否决这项生产 authority，不把 prototype 的文件恢复成功冒称 owner 结算方案已经成立。DLL 中 `MsiGetMode(ROLLBACK)` 是比 EXE 参数更真实的上下文，但仍不能单独证明整个执行/rollback 已完成。

这份实验会直接决定：现有 EXE broker 是否能增一个严格的实际 session rollback capability 分支，还是需要更完整的 session/事务拥有者组合。并行可写的产品部分是 snapshot/Decision/真实恢复核对，生产 admission 在联合方案成立前不启用。不是再跑一次“损坏拒绝”或无限延长当前 owner。

## Run 溯源与下一步边界

D11 原要求是只处理本项目项、准确读回、外部不明项保留，不是“TxR 就有 CAS”。第二十一轮普通操作已披露 query/write 外部窗口；R56 真实竞争显示在读前像后外部替换成功，TxR 候选仍提交删除替换值，因此撤回。`22-自启动…:52–58` 和进度 R56 明确保留失败，不可重述为通过。

首个文件修复切片保持 Run absent 能安全交付一项实用功能，但不是最终 MSI 完成。下一子项应先让修复**只读核对并保持既有本项目 Run**，其结果不能把 target 移除却留悬空启动命令；卸载则仍要严格的本项目归属清理方案，防外部替换误删。不把普通 query+delete 或恢复 TxR 实验作为已证解决，也不因 Run 未闭合无限拖延完全不涉及 Run 的文件修复。

## 最小文件分工与验证

建议 Rust 先改3源：`effects.rs`、新私有 `effects/preimage.rs`（含必要 Windows tests）、`native/broker.rs` 持有/传递不可伪造 snapshot。tag5/Pending 格式不必增加；若需修订上层说明而动 `installer_lifecycle.rs` 应另列第4源。包装器/检查器只在实际维修入口默认方式需要变化时改 `scripts/package-msi-candidate.py` 和 `scripts/check-msi-candidate.py`；同步候选说明，不改十二 crate 边界、supervisor 自动退休或既有 guardian 认证。

有意义的正向用例：安装后分别删除 exe/Web asset、同长度改字节、截断、整个受管子目录缺失，再运行正式修复，核对全部期望文件和组件、Run/学校资料不变，正式卸载和映像/cache/Pending/原进程实际收尾。不要用只有拒绝结果的场景代表修复能力。

回滚用例：捕获受损前像后，真实引擎取消/失败触发 rollback，核对缺失仍缺失、原坏字节完整恢复，而非强行要求健康；健康前像/首次安装对应原 healthy/absent。纯 Decision 单测必须配实际文件/registry adapter 测试和正式 MSI 真实失败原件。可研究 Microsoft 外部 UI 取消接口作为 test-only 故障触发；它必须调用真实原 MSI，不篡改包、跳 hook、发送假 settlement 或替代正常 helper。早期失败与 chainer 后 EndRollback 分别记录，方法触发可靠性先实证。

负向覆盖：错产品/context/version/keypath、外来额外叶、reparse/hardlink、locked/unreadable、损坏扩容超界、前像在两次 guard 间变化、结束后读回不符、原 guardian 未归还/close fault。其作用是防误修/误释放，不替代上面的成功修复与失败恢复。

完整后续仍包括 marker/组件元数据损坏、Run-present、major upgrade/downgrade、早期引擎失败/重启掉电恢复、标准用户、Win7/10、希沃及全部 Q13。现有 Win11 可继续开发与实测，不把环境缺失作为停止无关实现的理由。

## 本次核对的官方依据

- [Rollback Installation](https://learn.microsoft.com/en-us/windows/win32/msi/rollback-installation)：引擎生成回滚脚本及删除文件的备份；真实恢复仍需本项目实际核对。
- [MsiReinstallProduct](https://learn.microsoft.com/en-us/windows/win32/api/msi/nf-msi-msireinstallproducta)：强制替换与 checksum-only 修复的不同标志，及 user registry 恢复。
- [Command-Line Options](https://learn.microsoft.com/en-us/windows/win32/msi/command-line-options)：默认 `/f` 为 omus，a 强制替换；不要从命令名称推出实际文件健康。
- [Installing a Missing Component](https://learn.microsoft.com/en-us/windows/win32/msi/installing-a-missing-component)：KeyPath 存在也不代表其他文件存在。
- [Component Table](https://learn.microsoft.com/en-us/windows/win32/msi/component-table)：KeyPath/组件规则；更换检测策略需正规 authoring。
- [MsiEmbeddedChainer](https://learn.microsoft.com/en-us/windows/win32/msi/msiembeddedchainer-table)、[MsiJoinTransaction](https://learn.microsoft.com/en-us/windows/win32/api/msi/nf-msi-msijointransaction)：真实事务拥有及 Join/End，不是消息 bool。
- [InstallExecuteSequence](https://learn.microsoft.com/en-us/windows/win32/msi/installexecutesequence-table)：失败/取消负序号是调度能力，不自行升级为终态认证。
