Root独占执行的失败实验清理工具，默认不执行。绑定原FAIL报告82569f...及16下载原件。原始Begin0→Install1603→EndRollback0→MsiCloseHandle(1)=6→eventClose0→G/thread76保留；清理成功不转换原实验结果，不授予生产修复权威。

实际原MSI日志未发出cache/DLL/RunningScript路径，显式保留NOT_EMITTED_IN_ORIGINAL_LOG和空路径集合，不声称证明所有缓存未创建。独立读回fixture/product/component/marker/effect与HKCU32父项，进程只查精确root的Owner/csc且必须为0。

只有旧16文件稳定、所有新readback编译文件下载核对、再次精确inventory与process0后，才逐文件删除已下载原件及空目录。新预算180秒仅用于读回/下载/清理；原native120不续期。无新MSI、无/x、无共享进程终止、无缓存/注册表删除、无native close重试。任何未知立即停止后续查询/清理。

执行命令见execution-plan-first.json；根代理可先对powershell-chunks.json四个静态PS块作内存AST解析。准备者未连接Windows。
