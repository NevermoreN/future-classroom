#!/usr/bin/env python3
"""Default inert. Root-only exact R79 failed-experiment scratch cleanup.

Original failure is immutable. No MSI, helper execution, service kill, registry
delete, cache delete, native close retry or production settlement authority.
"""
import argparse
import base64
import hashlib
import json
from pathlib import Path, PureWindowsPath
import re
import runpy
import subprocess
import time

E=Path('/tmp/fc-round79-msi-maintenance')
ORIGINAL=E/'controlled-owner-runtime-first/runtime-operation.json'
ORIGINAL_SHA='82569f2897bb0e7da0587de83b48ff174e56718a3f495a82f99acb32320c5ae8'
TRANSPORT=E/'controlled-owner-transport-preparation-first/run-controlled-owner-first.py'
TRANSPORT_SHA='a8329b1fe77baf67d8d76872f3a34be3b57d08890a3a53f146a17a53cfa4a8a7'
BASE=E/'early-terminal-transport-preparation-fifth/compile-only.py'
BASE_SHA='3b3aa837646c78157c0c8ce1d5d44f4325f8bcdd34f4fc59e85c801b555a4783'
OWN_ZERO=r'''
function Own-Zero {
 Root-Check;$owned=@();$foreign=0
 $rows=@(Get-CimInstance -ClassName Win32_Process -Filter "Name='Owner.exe' OR Name='csc.exe'")
 Need ($rows.Count-le 128) 'BOUNDED_OWNER_COMPILER_OBSERVATION'
 foreach($p in $rows){
  Need ($null-ne $p.ExecutablePath -and $null-ne $p.CommandLine) 'PROCESS_METADATA_UNKNOWN_RETAIN'
  $inside=$p.ExecutablePath.StartsWith($c.root+'\',[StringComparison]::OrdinalIgnoreCase) -or $p.CommandLine.IndexOf($c.root,[StringComparison]::OrdinalIgnoreCase)-ge 0
  if($inside){$owned+=@{pid=$p.ProcessId;image=$p.ExecutablePath;creation=$p.CreationDate}}else{$foreign++}
 }
 Need ($owned.Count-eq 0) 'OWN_OWNER_OR_COMPILER_STILL_LIVE_RETAIN'
 @{ownCandidates=$owned;foreignIgnoredCount=$foreign;status='ACTUAL_ZERO_EXACT_ROOT_OWNER_COMPILER'}
}
'''

def need(v,s):
 if not v:raise ValueError(s)
def fact(p):
 need(p.is_file() and not p.is_symlink(),'Regular local original')
 b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--validate-inputs-only',action='store_true');p.add_argument('--output-dir',type=Path);a=p.parse_args()
 need(not(a.execute and a.validate_inputs_only),'Choose execute OR local validate')
 if not a.execute and not a.validate_inputs_only:
  print(json.dumps(dict(status='PREPARED_NOT_RUN',Windows='NOT_CONTACTED',budgetSeconds=180,scope='New finite readback/cleanup budget; original native120 not renewed')));return 0
 need((E/'.owner').read_bytes()==b'future-classroom-owned-r79-msi-maintenance/v1\n','Owned R79 root')
 need(fact(ORIGINAL)['sha256']==ORIGINAL_SHA and fact(TRANSPORT)['sha256']==TRANSPORT_SHA and fact(BASE)['sha256']==BASE_SHA,'Exact immutable report/transport/base')
 t=runpy.run_path(str(TRANSPORT));b=runpy.run_path(str(BASE));r=json.loads(ORIGINAL.read_text());phase=r['phase'];cases=phase['cases']
 need(r['status']=='FAIL_FIXTURE_CAPTURE_OR_QUALIFICATION_RETAIN' and r['originalPhaseNaturalReturn'] and r['downloadVerified'] and r['cleanup']=='NOT_RUN','Original failure retained and original capture known')
 need(len(cases)==1 and cases[0]['name']=='early-fail-rollback' and phase['status']=='FAIL_RETAIN_ORIGINALS' and phase['nativeCloseUnknown'] is False and phase['originalOwnerReturned'] is True,'One failed case, genuine original physical return known')
 case=cases[0];caps=phase['originalCaps']
 need(len(caps)==2 and {x['Kind'] for x in caps}=={'process','thread'} and all(x['Status']=='HELD_ORIGINAL_IDENTITY' and x['Wait']==0 and x['ExitKnown'] and x['ExitCode']==76 and x['CheckedClose'] and x['CloseAttempted'] for x in caps),'Original G/thread76 physically exited, observer caps checked returned')
 need(phase['nativeCloseFacts'] and all(x['Attempted'] and x['Success'] and not x['Unknown'] for x in phase['nativeCloseFacts']),'Observer checked close facts known')
 rows=case['api'];by={x['stage']:x for x in rows};need(len(by)==len(rows),'Original journal unique stages')
 expected={'BEGIN_RETURN':0,'INSTALL_RETURN':1603,'END_RETURN':0,'MSI_HANDLE_CLOSE_RETURN':6,'CHANGE_EVENT_CLOSE_RETURN':0}
 need(all(by[k]['attempted'] and by[k]['return']==v for k,v in expected.items()) and 'END_ROLLBACK_ENTER' in by and 'END_COMMIT_ENTER' not in by,'Actual Begin0 Install1603 EndRollback0 MsiClose6 EventClose0 never rewritten')
 need(all(x['pid']==caps[0]['Pid'] and x['tid']==case['originalThread']['Tid'] and x['originalTid']==x['tid'] and x['threadCreation']==case['originalThread']['Creation'] and x['clockValid'] for x in rows),'Same captured G/thread API facts')
 need([x['sequence'] for x in rows]==list(range(1,len(rows)+1)) and [by[k]['sequence'] for k in expected]==sorted(by[k]['sequence'] for k in expected),'Original API order')
 download=ORIGINAL.parent/'download';inventory=r['inventory'];t['inventory_identity'](inventory);need(len(inventory['files'])==16,'Exact16 downloaded originals')
 immutable={ORIGINAL:fact(ORIGINAL),TRANSPORT:fact(TRANSPORT),BASE:fact(BASE),Path(__file__).resolve():fact(Path(__file__).resolve())}
 for row in inventory['files']:
  fp=download/row['path'];need(fact(fp)=={k:row[k] for k in ('bytes','sha256')},'Every original downloaded byte');immutable[fp]=fact(fp)
 need({str(x.relative_to(download)) for x in download.rglob('*') if x.is_file()}=={x['path'] for x in inventory['files']},'Exact local16 membership')
 need(json.loads((download/'controlled-owner-result.json').read_text())==phase,'Original failed phase equals downloaded result')
 spec=json.loads((download/'spec.json').read_text());manifest=json.loads((download/'runtime-inputs.json').read_text())
 need(spec['nonce']=='048185bd83264d1b8abf282244500f4b' and spec['windowsRoot']==r['remoteRoot'] and spec['expectedUserSid']==b['SID'],'Exact original namespace')
 logs={x.name:t['decode_log'](x.read_bytes()) for x in download.glob('*-msi.log')};need(set(logs)=={'early-fail-rollback-msi.log'},'One original MSI log only')
 paths={}
 for name,text in logs.items():
  for line in text.splitlines():
   for kind,pattern in [('cache',r"Package we're running from ==> (.+)$"),('script',r'Running Script:\s*(.+)$'),('dll',r'Invoking remote custom action\. DLL:\s*(.+?),\s*Entrypoint:')]:
    match=re.search(pattern,line,re.I)
    if match:
     value=match.group(1).strip();wp=PureWindowsPath(value)
     need(wp.is_absolute() and wp.parent in (PureWindowsPath('C:\\Windows\\Installer'),PureWindowsPath(spec['windowsRoot']).parent) and re.fullmatch(r'(?:MSI[0-9a-f]+\.tmp|[0-9a-f]+\.msi)',wp.name,re.I),'Only emitted exact own cache/DLL/script paths')
     paths.setdefault(value,[]).append(name+':'+kind)
 # Empty is a meaningful absence of emitted path evidence, not proof that the
 # engine never extracted anything. Never invent or enumerate Installer paths.
 exact=[dict(path=k,basis=v) for k,v in sorted(paths.items())]
 def source_guard():
  need(all(fact(p)==v for p,v in immutable.items()),'Every original failure/source/download byte unchanged')
 source_guard()
 if a.validate_inputs_only:
  print(json.dumps(dict(status='PASS_LOCAL_FAILED_FIXTURE_CLEANUP_ADMISSION_ONLY',Windows='NOT_CONTACTED',originalFailurePreserved=True,originalFileCount=16,emittedExactSystemPaths=exact,pathEvidence='EMITTED_EXACT_PATHS' if exact else 'NOT_EMITTED_IN_ORIGINAL_LOG',cleanupBudgetSeconds=180)));return 0
 out=a.output_dir;need(out and out.is_absolute() and out.resolve()==out and out.parent==E and not out.exists(),'Fresh direct owned cleanup result')
 out.mkdir();(out/'.owner').write_text('future-classroom-owned-r79-controlled-owner-failed-fixture-cleanup/v1\n')
 report=dict(status='RUNNING_TEST_SCRATCH_CLEANUP_ONLY',originalFailure=dict(path=str(ORIGINAL),**fact(ORIGINAL)),originalNativeFailure='MsiCloseHandle(transaction1)=6; G/thread exit76',nativeFailureUnchanged=True,productionAuthority='NONE',cleanupBudgetSeconds=180,originalNative120Renewed=False,emittedExactSystemPaths=exact,pathEvidence='EMITTED_EXACT_PATHS' if exact else 'NOT_EMITTED_IN_ORIGINAL_LOG',operations=[],cleanup='NOT_RUN')
 cfg=dict(root=spec['windowsRoot'],nonce=spec['nonce'],sid=b['SID'],spec=spec,manifest=manifest,paths=[x['path'] for x in exact]);common=b['COMMON'].split('function Inventory {')[0]+t['PARENT_PS']+t['INVENTORY_PS']+OWN_ZERO
 started=time.monotonic();rp=out/'cleanup-operation.json'
 def save():rp.write_text(json.dumps(report,indent=2)+'\n')
 def call(label,args,feed=None,limit=20):
  left=180-(time.monotonic()-started);need(left>0,'Separate finite cleanup180 exhausted; retain')
  s=time.monotonic();proc=subprocess.Popen(args,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE);timed=False
  try:stdout,stderr=proc.communicate(feed,timeout=min(left,limit))
  except subprocess.TimeoutExpired:timed=True;proc.kill();stdout,stderr=proc.communicate()
  row=dict(label=label,argv=args,actualExit=proc.returncode,localParentReaped=proc.poll() is not None,remoteReturnKnown=not timed,timedOut=timed,seconds=time.monotonic()-s)
  for ext,data in [('stdin.ps1',feed),('stdout.log',stdout),('stderr.log',stderr)]:
   if data is not None:
    q=out/(label+'.'+ext);q.write_bytes(data);row[ext]=dict(path=q.name,**fact(q))
  report['operations'].append(row);save();need(not timed,'UNKNOWN remote readback return; stop all queries/cleanup');need(proc.returncode==0,'Actual cleanup operation nonzero; retain');return stdout
 def ps(label,body,c=None,limit=20):
  feed=("$c='"+json.dumps(cfg if c is None else c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+common+body).encode()
  command='powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand '+base64.b64encode(b['BOOT'].encode('utf-16-le')).decode()
  return json.loads(call(label,['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8',b['HOST'],command],feed,limit).decode('utf-8-sig'))
 save()
 try:
  before=ps('01-readonly-original-inventory-and-zero',"$zero=Own-Zero;$i=Inventory;@{zero=$zero;inventory=$i}|ConvertTo-Json -Depth 30 -Compress")
  need(t['inventory_identity'](before['inventory'])==t['inventory_identity'](inventory) and before['zero']['ownCandidates']==[],'Same original16 inventory and exact owned process0');report['before']=before
  readback=ps('02-independent-readonly-fixture',t['READBACK_PS'],limit=45);report['finalReadOnly']=readback
  need(readback['fixtureKnownAbsent'] is True and readback['product']['localPackageRc']==1605 and len(readback['paths'])==len(exact) and {x['path'] for x in readback['paths']}=={x['path'] for x in exact} and all(x['fact']['status']=='KNOWN_ABSENT' for x in readback['paths']),'Independent product/component/marker/effect and emitted exact paths absent')
  need(t['parent_preserved'](r['before']['registryParentBefore'],readback['registryParent']),'HKCU32 parent preserved; no manual delete')
  after=ps('03-readonly-extended-inventory-and-zero',"$zero=Own-Zero;$i=Inventory;@{zero=$zero;inventory=$i}|ConvertTo-Json -Depth 30 -Compress");extended=after['inventory'];t['inventory_identity'](extended);report['extended']=after
  old={x['path']:x for x in inventory['files']};new={x['path']:x for x in extended['files']};need(all(new.get(k)==v for k,v in old.items()),'All original16 unchanged')
  capture=out/'readback-download';capture.mkdir()
  for i,row in enumerate(extended['files']):
   if row['path'] in old:continue
   need(row['path'].startswith('readback-compiler-temp/'),'Only owned readback compiler files may be added')
   target=capture/row['path'];target.parent.mkdir(parents=True,exist_ok=True)
   remote=b['HOST']+':'+(cfg['root']+'\\'+row['path'].replace('/','\\')).replace('\\','/')
   call('04-download-readback-'+str(i),['scp','-q','-o','BatchMode=yes','-o','ConnectTimeout=8',remote,str(target)],limit=15)
   need(fact(target)=={k:row[k] for k in ('bytes','sha256')},'Exact new compiler download')
  source_guard();stable=ps('05-final-stable-inventory-and-zero',"$zero=Own-Zero;$i=Inventory;@{zero=$zero;inventory=$i}|ConvertTo-Json -Depth 30 -Compress")
  need(t['inventory_identity'](stable['inventory'])==t['inventory_identity'](extended) and stable['zero']['ownCandidates']==[],'Stable extended bytes/directories and process0');report['stable']=stable
  # Final deletion itself rechecks exact root ACL/marker/inventory and live owned
  # processes, removes only downloaded known files and empty directories.
  clean=ps('06-delete-exact-downloaded-scratch',"$zero=Own-Zero;"+b['DELETE'].replace('PASS_REMOVED_EXACT_DOWNLOADED_COMPILE_ROOT','PASS_REMOVED_EXACT_FAILED_EXPERIMENT_SCRATCH'),{**cfg,'inventory':extended})
  need(clean['knownAbsent'] is True and clean['status']=='PASS_REMOVED_EXACT_FAILED_EXPERIMENT_SCRATCH','Exact nonce root absent')
  source_guard();report.update(status='PASS_TEST_SCRATCH_CLEANUP_ORIGINAL_NATIVE_FAILURE_RETAINED',cleanup=clean,originalFailurePreserved=True,originalFileCount=16)
 except Exception as error:report.update(status='FAIL_READBACK_OR_TEST_SCRATCH_CLEANUP_RETAIN',errorType=type(error).__name__,error=str(error))
 report['elapsedSeconds']=time.monotonic()-started;save();print(json.dumps(dict(status=report['status'],report=str(rp),sha256=fact(rp)['sha256'])));return 0 if report['status'].startswith('PASS_') else 1

if __name__=='__main__':raise SystemExit(main())
