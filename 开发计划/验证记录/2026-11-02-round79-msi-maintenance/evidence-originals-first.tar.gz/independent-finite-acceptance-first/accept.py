#!/usr/bin/env python3
"""Independent finite R79 local-original acceptance; no Windows/Cargo/network.

This qualifies this round's evidence for archival. It does not accept full
product requirements, production repair integration or Windows 7/10 execution.
"""
import hashlib
import json
from pathlib import Path
import re
import subprocess

E=Path('/tmp/fc-round79-msi-maintenance')
O=Path(__file__).parent
REPO=Path('/workspace/共享/Eliora/未来教室计划')
SOURCE='c44906517fbc62233dca755d7225cea375264cbc'
CANDIDATE='52d6392552679e7cedb564cd52db08e6e2ebc04b'
checks=[]
inputs={}

def fact(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def need(n,v,detail=None):
 checks.append(dict(name=n,passed=bool(v),detail=detail))
 if not v:raise AssertionError(n)
def load(rel,expected=None):
 p=E/rel;f=fact(p);inputs[rel]=f
 if expected:need('input_identity:'+rel,f['sha256']==expected)
 return json.loads(p.read_text(encoding='utf-8-sig'))
def bound(n,p,row):
 a=fact(p);need(n,all(a[k]==row[k] for k in ('bytes','sha256') if k in row),a)
def downloads(label,directory,inventory):
 expected={r['path'] for r in inventory['files']}
 need(label+':exact_local_membership',{str(p.relative_to(directory)) for p in directory.rglob('*') if p.is_file()}==expected)
 for row in inventory['files']:bound(label+':'+row['path'],directory/row['path'],row)
 return dict(files=len(expected),bytes=sum(r['bytes'] for r in inventory['files']))
def frozen(rel):
 f=load(rel)
 for row in f['files']:bound('frozen:'+rel+':'+row['path'],(E/rel).parent/row['path'],row)
 return f
def operation_streams(label,report,root):
 for op in report['operations']:
  for k,row in op.items():
   if isinstance(row,dict) and {'path','bytes','sha256'}<=row.keys():bound(label+':original_stream:'+op.get('label',op.get('name','?'))+':'+k,root/row['path'],row)
def absent(s):
 return s['knownAbsent'] is True and s['marker']=='KNOWN_ABSENT' and s['effect']['status']=='KNOWN_ABSENT' and not s['registration']['registrations'] and not s['registration']['related'] and s['registration']['localPackageRc']==1605 and s['components']['allUnknownStates'] is True
def log_decode(p):
 b=p.read_bytes();return b.decode('utf-16') if b[:2] in (b'\xff\xfe',b'\xfe\xff') else b.decode('utf-8-sig')

# Actual current-product damaged-preimage refusal, not successful repair.
n=load('product-negative-runtime-first/report.json','0e4a2f4b24d594690e5f6278e1e622dee1c1d1f47bd633e9aa5954e6b16f637b')
q=load('negative-runtime-qualification-first/qualification-first.json')
np=n['phaseResult'];nd=Path(q['downloadedOriginals']['root'])
negative_download=downloads('product_negative_download',nd,n['remoteInventory'])
need('negative49_originals_9485555bytes',negative_download==dict(files=49,bytes=9485555))
need('negative_phase_equals_original_download',json.loads((nd/'phase-runner-result.json').read_text(encoding='utf-8-sig'))==np)
need('actual_five_product_client_returns',[p['client']['exitCode'] for p in np['phases']]==[0,1603,1603,1603,0])
controls=[p for phase in np['phases'] for p in phase['observerFinal']['Processes']]
need('eleven_original_controls_actual_exit_checkedclose',len(controls)==11 and all(p['ActualWait']==0 and p['ExitStatus']=='ACTUAL_ORIGINAL_GET_EXIT_CODE' and p['CloseStatus']=='CHECKED_CLOSE_SUCCESS' for p in controls))
need('eleven_controls_8zero_3reject1603',sum(p['ActualExitCode']==0 for p in controls)==8 and sum(p['ActualExitCode']==1603 for p in controls)==3)
comparison_count=0;other_count=0
for c in np['negativeCases']:
 m=c['mutation'];before=m['BeforeMsiTree'];after=m['AfterMsiTree'];original=m['OriginalTree'];restored=m['RestoredTree']
 need('negative_'+c['kind']+':every_recorded_mutated_file_fact_preserved',before==after)
 comparison_count+=len(before)
 old={x['Path']:x for x in original};new={x['Path']:x for x in restored};fixed=m['FixedResource']
 keys=set(old) if c['kind']=='Extra' else set(old)-{fixed}
 need('negative_'+c['kind']+':every_other_original_file_fact_restored',all(new.get(k)==old[k] for k in keys))
 other_count+=len(keys)
 need('negative_'+c['kind']+':fixture_restore_and_product_health',m['RestorationComplete'] and not m['NativeCloseUnknown'] and c['afterFixtureRestore']['healthyPresent'])
 need('negative_'+c['kind']+':no_unobserved_broker_inference',c['rejection']['ownerProof']['noBrokerCreated']=='NOT_CLAIMED_FROM_MISSING_OBSERVATION')
need('actual_negative_42_preserved_40_other_restored',comparison_count==42 and other_count==40)
need('product_formal_uninstall_and_scratch_absence',np['formalUninstallAttempted'] and np['uninstallAbsent']['knownAbsent'] and n['cleanupActual']['knownAbsent'] and n['downloadVerified'] and n['sourceUnchanged'])
xp=load('root-negative-exact-system-paths-second.json','fa9c947f2f45c3eed32a5d95556f805082f01632c778c9a61ba628b7a29bb3c8')
need('eleven_exact_system_paths_actual_known_absent',len(xp['observed']['facts'])==11 and all(x['status']=='KNOWN_ABSENT' and x['win32Error']==2 for x in xp['observed']['facts']))
need('exact_path_native_metadata_last_error_proven',xp['observed']['pinvokeMetadata']['setLastError'] and xp['observed']['pinvokeMetadata']['exactSpelling'] and xp['mutations']=='NONE')

# Same reviewed Rust candidate, GNU compilation and actual scoped Win11 tests.
candidate=load('repair-implementation-first/candidate-second/candidate-second.json','86f3e4599d9d11f4313d4c49f572ae35f66f838f86dc4c7678f7b04c8b0d4f68')
build=load('repair-candidate-release-build-second/report.json','bbd1635f399846da56dc14788885dd41693c3804ca8c5578d68571858d916acb')
clippy=load('repair-candidate-clippy-first/report.json','8d50b818b4194776668ee9bd9e9d54aa7f29f0547ce48f2a55eced4de6450d9b')
for label,r in [('build',build),('clippy',clippy)]:
 need('candidate_'+label+':actual0_reaped_unchanged',r['actualReturnCode']==0 and r['originalReaped'] and r['sourceUnchanged'] and not r['budgetExceeded'] and r['candidateSha256']=='86f3e4599d9d11f4313d4c49f572ae35f66f838f86dc4c7678f7b04c8b0d4f68')
 need('candidate_'+label+':GNU_target_alltargets','i686-pc-windows-gnu' in r['argv'] and '--all-targets' in r['argv'])
 for row in r['outputs']:bound('candidate_'+label+':raw:'+row['path'],(E/('repair-candidate-release-build-second' if label=='build' else 'repair-candidate-clippy-first'))/row['path'],row)
need('strict_clippy_warnings_denied',clippy['argv'][-3:]==['--','-D','warnings'])
nr=load('repair-candidate-native-release-second/report.json','b7736c2044d2e61b6a50acd275be306f98d261921a66c824a232ee8c5e9c0f81')
native_dir=E/'repair-candidate-native-release-second/download'/Path(nr['windowsRoot'].replace('\\','/')).name
native_download=downloads('candidate_native_download',native_dir,nr['inventory'])
need('candidate_native_exact_original_result',json.loads((native_dir/'native-result.json').read_text())==nr['native'])
need('candidate_native_two_actual_originals_returned',len(nr['native']['originalObjects'])==2 and all(x['Wait']==0 and x['ExitKnown'] and x['ExitCode']==0 and x['CheckedClose'] for x in nr['native']['originalObjects']))
effects,lifecycle=nr['native']['cases']
need('candidate_native_actual11_and46_outer_totals',[x['outerTotals']['passed'] for x in nr['qualifiedCases']]==[11,46] and all(x['exitCode']==0 for x in nr['native']['cases']))
effect_names=set(re.findall(r'^test (\S+) \.\.\. ok$',effects['stdout'],re.M));lifecycle_names=set(re.findall(r'^test (\S+) \.\.\. ok$',lifecycle['stdout'],re.M))
need('11_effects_included_in46_not57_distinct',len(effect_names)==11 and effect_names<=lifecycle_names)
need('candidate_native_cleanup_known_absent',nr['delete']['knownAbsent'] and nr['compiledExeUnchanged'])
sem=load('repair-candidate-semantic-review-first/review-second.json','e2ebe2a4531434328f3326f5038da8b4497ded233fb5703a5db2875e75fd6351')
need('SEM01_fix_review_pass_and_scope',sem['closesFinding']['id']=='R79-REPAIR-SEM-01' and sem['closesFinding']['status']=='CLOSED_FOR_UNCHECKED_MISSING_ANCESTOR_REGULAR_LEAF_CAPTURE' and not sem['minimalAcceptanceGate']['mayClaimProductionRepairReady'])
pres=load('repair-candidate-source-preservation-first/preservation-first.json')
need('candidate_commit_identity_scope',pres['commit']==CANDIDATE and pres['parent']==SOURCE and pres['worktreeClean'] and pres['productionGateUnchanged']=='NOT_MERGED_MAIN_NO_REAL_DAMAGED_MSI_AUTHORITY')
git=[]
for row in pres['files']:
 p=E/'repair-candidate-source-preservation-first/source'/row['path'];bound('preserved_candidate_source:'+row['path'],p,row)
 cp=subprocess.run(['git','cat-file','blob',CANDIDATE+':'+row['path']],cwd=REPO,capture_output=True,check=False)
 need('actual_git_committed_candidate_blob:'+row['path'],cp.returncode==0 and cp.stdout==p.read_bytes())
 git.append(dict(argv=['git','cat-file','blob',CANDIDATE+':'+row['path']],actualExit=cp.returncode,bytes=len(cp.stdout),sha256=hashlib.sha256(cp.stdout).hexdigest()))
bound('preserved_complete_candidate_patch',E/'repair-candidate-source-preservation-first/candidate-second-complete.patch',pres['completePatch'])
cp=subprocess.run(['git','merge-base','--is-ancestor',CANDIDATE,'HEAD'],cwd=REPO,capture_output=True,check=False)
need('candidate_not_merged_current_main',cp.returncode==1)
git.append(dict(argv=['git','merge-base','--is-ancestor',CANDIDATE,'HEAD'],actualExit=cp.returncode))

# Prior observational counterexample remains qualified, with unknown callback caps.
debug_fail=load('repair-candidate-native-first/report.json','24d7bbdffbce3d8406cc33c89cfc0f0d93cce054b0e0b5cdb4dac82e8f7022f8')
compile_fail=load('early-terminal-compile-third/compile-operation.json','b99460d9231a6004373b3d6622672fc725c527e61e86721f3f87bd8ed92af48e')
need('historical_debug_and_unknown_compile_failures_preserved',debug_fail['status']=='FAIL_RETAIN_ORIGINALS' and compile_fail['status']=='FAIL_COMPILE_ONLY_RETAIN_ORIGINALS')
obs=load('early-terminal-runtime-first/runtime-operation.json','d8893598f781188b0b8b3e2655ecaf90dd8fc5b1317f6e46980e1bd2d20f9bdb')
obs_review=load('early-terminal-runtime-independent-review-first/review-first.json','937559ac030946bbd0b6366a6f91b75dd325628f5db698c9f9553edd6e2f07ac')
need('prior_observation337_checks_pass',obs_review['checkCount']==337 and all(x['passed'] for x in obs_review['checks']))
oc=obs['phase']['cases'][0]
need('client0_success_callback_outer_realrollback_counterexample',oc['client']['actualExit']==0 and oc['realJoinEndRollback'] and oc['positiveFacts']['END_ENTER.json']['decision']=='ROLLBACK' and oc['positiveFacts']['END_RETURN.json']['returnCode']==0 and oc['after']['knownAbsent'] and any(x['fields']['stage']=='TERMINAL_SUCCESS' for x in oc['nativeCallbacks']))
need('all12_observational_callback_caps_unknown',sum(len(x['nativeCallbacks']) for x in obs['phase']['cases'])==12 and all(c['capture']=='UNKNOWN' for x in obs['phase']['cases'] for c in x['nativeCallbacks']))

# Actual two failures remain negative after independent exact scratch cleanup.
for suffix,expected,cleanup_expected in [('first','82569f2897bb0e7da0587de83b48ff174e56718a3f495a82f99acb32320c5ae8','b90854ab44f0163d5db59d1dda09dc19536bb2d347512b1314b7c2dd86dc3784'),('second','088aa27057c4367b27339e27d74143bdfb802148a423aefb4b051c02d852c54e','af3a0e1f018ebb3d5c5e306cb282afcd5c3b99b813508dc37f4c38b19346968e')]:
 fail=load('controlled-owner-runtime-'+suffix+'/runtime-operation.json',expected)
 clean=load('controlled-owner-failure-cleanup-'+suffix+'/cleanup-operation.json',cleanup_expected)
 need('controlled_'+suffix+':native_failure_not_rewritten',fail['phase']['status']=='FAIL_RETAIN_ORIGINALS' and clean['nativeFailureUnchanged'] and clean['originalFailurePreserved'] and clean['cleanup']['knownAbsent'] and clean['originalNative120Renewed'] is False)
 if suffix=='first':need('controlled_first_actual_close6_preserved',any(x['stage']=='MSI_HANDLE_CLOSE_RETURN' and x['return']==6 for x in fail['phase']['cases'][0]['api']))
 else:need('controlled_second_missing_prepare_failure_preserved',fail['phase']['errors']==['ACTUAL_PREPARE_ACTION_NOT_PROVEN'] and fail['phase']['cases'][0]['nativeLog']['callbacks']==[])
 operation_streams('cleanup_'+suffix,clean,E/('controlled-owner-failure-cleanup-'+suffix))

# Final controlled owner: one-file/HKCU32 fixture, not production MSI integration.
r=load('controlled-owner-runtime-third/runtime-operation.json','44a72e1c869f843d45a385f24cdbffb92f369890cb7f1892295993baf4c70c6a')
for k in ('transport','baseTransport','sourceFreeze','stageManifest'):bound('controlled_final_binding:'+k,Path(r[k]['path']),r[k])
frozen(str(Path(r['sourceFreeze']['path']).relative_to(E)))
d=E/'controlled-owner-runtime-third/download';controlled_download=downloads('controlled_final_download',d,r['finalInventory'])
need('controlled28_originals1886461bytes',controlled_download==dict(files=28,bytes=1886461))
need('controlled_phase_equals_actual_download',r['phase']==json.loads((d/'controlled-owner-result.json').read_text()))
operation_streams('controlled_third',r,E/'controlled-owner-runtime-third')
ph=r['phase'];cases=ph['cases'];spec=json.loads((d/'spec.json').read_text())
need('controlled_original_phase0_no_errors_known_caps',r['phaseParentExit']==0 and r['originalPhaseNaturalReturn'] and not ph['errors'] and ph['nativeCloseUnknown'] is False and ph['originalOwnerReturned'] and not ph['ownedCommitOutstanding'])
need('controlled_four_exact_cases',[x['name'] for x in cases]==['early-fail-rollback','healthy-rollback','healthy-commit','owned-uninstall'])
need('controlled8_original_G_thread_actual0_checkedreturn',len(ph['originalCaps'])==8 and all(x['Status']=='HELD_ORIGINAL_IDENTITY' and x['Wait']==0 and x['ExitKnown'] and x['ExitCode']==0 and x['CheckedClose'] and x['CloseAttempted'] for x in ph['originalCaps']))
need('controlled_all_native_observer_close_success',all(x['Attempted'] and x['Success'] and not x['Unknown'] for x in ph['nativeCloseFacts']))
for i,c in enumerate(cases):
 rows=c['api'];by={x['stage']:x for x in rows};name=c['name'];install='CONFIGURE_ABSENT_RETURN' if i==3 else 'INSTALL_RETURN'
 need('controlled_'+name+':actual_begin_install_end_event',by['BEGIN_RETURN']['return']==by['END_RETURN']['return']==by['CHANGE_EVENT_CLOSE_RETURN']['return']==0 and by[install]['return']==(1603 if i==0 else 0) and c['actualExit']==0)
 need('controlled_'+name+':ID_nonclose_not_api0',by['TRANSACTION_ID_NO_INSTALL_HANDLE_CLOSE']['attempted'] is False and by['TRANSACTION_ID_NO_INSTALL_HANDLE_CLOSE']['return']==4294967295 and 'MSI_HANDLE_CLOSE_RETURN' not in by)
 need('controlled_'+name+':original_thread_and_actual_order',all(x['pid']==c['originalProcess']['Pid'] and x['tid']==c['originalThread']['Tid'] and x['threadCreation']==c['originalThread']['Creation'] and x['clockValid'] for x in rows) and by['SET_UI_PREVIOUS_LEVEL']['sequence']<by['LOG_ENABLE_RETURN']['sequence']<by['BEGIN_RETURN']['sequence']<by[install]['sequence']<by['END_RETURN']['sequence']<by['CHANGE_EVENT_CLOSE_RETURN']['sequence'])
 log=d/(name+'-msi.log');bound('controlled_'+name+':native_log_original_hash',log,dict(bytes=c['nativeLog']['logBytes'],sha256=c['nativeLog']['logSha256']))
 text=log_decode(log)
 parsed=[]
 for line in text.splitlines():
  if 'FC79|' in line:parsed.append(dict(x.split('=',1) for x in line[line.index('FC79|'):].split('|')[1:] if '=' in x))
 need('controlled_'+name+':callback_fields_from_original_log',parsed==c['nativeLog']['callbacks'])
 need('controlled_'+name+':actual_valid_current_product_nonce',all(x['nonce']==spec['nonce'] and x['product']==spec['productCode'] and x['productRc']=='0' and x['valid']=='1' and x['pointerBytes']=='4' and x['tokenClose']=='1' for x in parsed))
 if i==0:
  stages={x['stage']:x for x in parsed}
  need('controlled_earlyfail_actual_force_and_rollback_not_just1603','PREPARE' in stages and stages['FORCE_FAIL']['intendedReturn']=='1603' and stages['ROLLBACK']['rollback']=='1' and re.search(r'Action ended .*Fc79ForceFail\. Return value 3\.',text) is not None)
 if i!=2:need('controlled_'+name+':actual_after_absence',absent(c['after']))
 else:need('controlled_healthy_commit_actual_present',not c['after']['knownAbsent'] and c['after']['marker']=='PRESENT' and c['after']['effect']['status']=='PRESENT')
paths=r['finalReadOnly']['paths']
need('controlled17_exact_emitted_paths_absent',len(paths)==17 and {x['path'] for x in paths}=={x['path'] for x in r['derivedExactSystemPaths']} and all(x['fact']['status']=='KNOWN_ABSENT' and x['fact']['lastError'] in (2,3) for x in paths))
need('controlled_registry_parent_initial_final_absent',r['before']['registryParentBefore']['status']==r['finalReadOnly']['registryParent']['status']=='KNOWN_ABSENT')
need('controlled_fixture_independent_absence_exactroot_delete',r['finalReadOnly']['fixtureKnownAbsent'] and r['cleanup']['knownAbsent'] and r['downloadVerified'])
outer=load('root-controlled-owner-operation-third.json')
need('controlled_three_distinct_timing_scopes',ph['elapsedMilliseconds']==3421 and abs(r['elapsedSeconds']-14.854985154999667)<1e-9 and outer['actualExit']==0 and outer['originalLocalParentReaped'] and abs(outer['seconds']-14.982865690000835)<1e-9)

# Last actual read-only Windows state, no new query by this reviewer.
audit=load('windows-readonly-final-second.json','66bcac658e0a144af244a613702c8d8f37c6aab407fc39e3d19f4b71a85be4ad')
need('final_actual_windows_audit_clean_preserves_authorization',audit['status']=='PASS' and audit['scratchDirectories']==[] and audit['ownedProcesses']==[] and audit['ownedTasks']==[] and audit['sshd']=='Running' and audit['publicAuthorizationUnchanged'] and audit['projectRunUnchanged'] and audit['persistentKeyMode']=='0o600' and audit['authentication']=='PASS' and audit['build']=='26300')

report=dict(schemaVersion=1,status='PASS_R79_FINITE_LOCAL_EVIDENCE_ACCEPTANCE_WIN11_ONLY_NOT_PRODUCTION_INTEGRATION',
 sourceSha=SOURCE,candidateSha=CANDIDATE,scope='Finite independent R79 local-original evidence acceptance for archive admission only; no Windows/network/Cargo action by reviewer.',
 inputs=inputs,checks=checks,checkCount=len(checks),actualGitReadOnlyChecks=git,
 qualifiedSlices=dict(productDamagedAdmissionRefusals=dict(actualClientReturns=[0,1603,1603,1603,0],originalControls=11,preservedMutatedFileFacts=42,restoredOtherOriginalFacts=40,download=negative_download,exactSystemPathsAbsent=11),
  rustCandidate=dict(GNUCompile='ACTUAL_PASS',strictClippy='ACTUAL_PASS',Win11NativeEffects=11,Win11NativeLifecycle=46,effectsIncludedInLifecycle=True,distinctCountMustNotBe57=True,SEM01='CLOSED_WITHIN_CAPTURE_SCOPE',candidatePreservedCommit=CANDIDATE,mainMerged=False),
  observational=dict(independentChecks=337,client0SuccessCallbackCanAccompanyOuterRollback=True,all12CallbackCaps='UNKNOWN'),
  controlledOwner=dict(actualCases=4,actualInstallOrConfigureReturns=[1603,0,0,0],originalGAndThreadCapabilities=8,allOriginalCapsActualExit0CheckedClosed=True,originalBeginEndEventCloseActual0=True,transactionIDNoCloseRecord='attempted=false/sentinel4294967295_NOT_API_RETURN',forceFailActualEngineActionReturn=3,nativeRollbackMode=1,exactSystemPathsAbsent=17,download=controlled_download,phaseMilliseconds=3421,transportSeconds=r['elapsedSeconds'],outerSeconds=outer['seconds'],scratchRootDeleted=True),
  finalWindowsAudit=dict(status='ACTUAL_PASS',scratchDirectories=0,ownedProcesses=0,ownedTasks=0,sshd='Running',publicAuthorizationUnchanged=True,RunUnchanged=True,keyRead='METADATA_ONLY_0600')),
 preservedFailures=['Original native debug fixture failure due 97 MB EXE exceeding existing 64 MiB guard remains a failure; release-scope evidence does not rewrite it.','First controlled owner: actual MsiCloseHandle(ID1)=6 and G/thread76 remain FAIL, despite separate exact scratch cleanup PASS.','Second controlled owner: missing actual PREPARE/callback evidence remains FAIL, despite Begin/End/event/caps returning and separate exact scratch cleanup PASS.','Historical compiler null-exit/metadata failures and source-review corrections remain original evidence; this finite acceptance does not convert them to successful execution.'],
 limitations=['NOT_PRODUCTION_INTEGRATION: controlled-owner is a fresh one-file/HKCU32 fixture with no production Pending/gate integration.','NOT_ACTUAL_DAMAGED_MSI_REPAIR: three actual product cases prove refusal and preservation; restoring their fixture is not MSI repair/rollback.','Rust damaged-preimage candidate is isolated and preserved, not merged into main or deployed; no real production damaged-MSI forced repair/rollback matrix is accepted.','Snapshot is volatile; crash/power-loss recovery, Run-present ownership, standard-user/upgrade paths remain outside this slice.','Windows 7 SP1 x86 actual NOT_RUN; Windows 10 actual NOT_RUN; Win11 does not substitute for either or Seewo hardware.','No broad claim that a transaction ID was never a handle: only this experiment completes the transaction via actual End, records ID close as not attempted, and independently closes the acquired event.','Unknown Type1 callback capabilities remain UNKNOWN; scenario log facts do not grant production settlement authority.','Full D11 project requirements and unrelated R78 evidence are not requalified or declared complete here.'],
 archiveAdmissionEligible=True,productionAuthority='UNPROVEN_NOT_GRANTED',mayClaimAllDevelopmentComplete=False,mayClaimProductionRepairReady=False,mayMergeDamagedCandidateFromThisEvidence=False,
 reviewerActions=dict(Windows='NOT_CONTACTED',network='NOT_USED',Cargo='NOT_RUN',R80='NOT_SCANNED',originalEvidenceModified=False))
(O/'acceptance-first.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=report['status'],sourceSha=SOURCE,candidateSha=CANDIDATE,checks=len(checks),reportSha256=fact(O/'acceptance-first.json')['sha256'])))
