from pathlib import Path
import hashlib,ast
D=Path(__file__).resolve().parent;O=D/'originals'
names=['ProcessObserver.cs','GateRetirement.cs','ReadOnlyPreflightFunction.ps1','ProductState.cs','ProductState.ps1']
for n in names:(D/n).write_bytes((O/n).read_bytes())
s=(O/'Invoke-ProductionMsiPhases.ps1').read_text().replace('r78-production-msi','r79-production-msi')
s=s.replace("$script:retainedClients=", "$script:activeMutation=$null;$script:resultMutations=@()\n$script:retainedClients=")
s=s.replace("[ValidateSet('Fresh','Reapply','Uninstall')]", "[ValidateSet('Fresh','Reapply','Reject','Uninstall')]")
s=s.replace("elseif($kind-ceq'Reapply')", "elseif($kind-in@('Reapply','Reject'))")
needle="if(@($snap.Processes|Where-Object{$_.Role-ceq'broker'}).Count-eq1 -and @($snap.Processes|Where-Object{$_.ActualWait-ne0}).Count-eq0){break}"
s=s.replace(needle,"if(($kind-ceq'Reject' -and @($snap.Processes).Count-gt0 -and @($snap.Processes|Where-Object{$_.ActualWait-ne0}).Count-eq0) -or ($kind-cne'Reject' -and @($snap.Processes|Where-Object{$_.Role-ceq'broker'}).Count-eq1 -and @($snap.Processes|Where-Object{$_.ActualWait-ne0}).Count-eq0)){break}")
s=s.replace('$row.ownerProof=Owner-Proof $closed $live', "$row.ownerProof=$(if($kind-ceq'Reject'){Reject-Proof $closed}else{Owner-Proof $closed $live})")
s=s.replace("$row['helperImageCleanup']=Observe-PhaseImages $row", "$row['helperImageCleanup']=$(if($kind-ceq'Reject'){Observe-RejectImages $row}else{Observe-PhaseImages $row})")
insert=s.index('function Invoke-Phase(')
s=s[:insert]+'''function Reject-Proof($closed){
 $returns=[Collections.Generic.List[string]]::new();$coverage=[Collections.Generic.List[string]]::new();$facts=@($closed.Processes)
 if(-not$closed.WmiStarted -or -not$closed.Closed -or @($closed.Errors).Count-ne0){$returns.Add('ORIGINAL_OBSERVER_RETURN_UNKNOWN')}
 if($facts.Count-eq0){$returns.Add('NO_CAPTURED_ORIGINAL_PROCESS')}
 foreach($f in $facts){if($f.IdentityStatus-cne'ORIGINAL_QUERY_SYNC_HANDLE_EXACT_IMAGE_BYTES_USER' -or $f.Sha256-cne$script:c.embeddedHelper.sha256 -or $f.Sid-cne$script:c.expectedUserSid -or $f.ActualWait-ne0 -or $null-eq$f.ActualExitCode -or $f.ExitStatus-cne'ACTUAL_ORIGINAL_GET_EXIT_CODE' -or $f.CloseStatus-cne'CHECKED_CLOSE_SUCCESS'){$returns.Add('CAPTURED_ORIGINAL_RETURN_UNKNOWN')}}
 $begin=@($facts|Where-Object{$_.Role-ceq'begin'})
 if($begin.Count-ne1){$coverage.Add('EXACT_OBSERVED_BEGIN_UNKNOWN_OR_NONUNIQUE')}else{$f=$begin[0];if($f.CommandStatus-cnotin@('EXACT_CREATION_MATCHED_WMI_FACT_ONLY','EXACT_ORIGINAL_HANDLE_NT_CLASS60_FACT_ONLY') -or $f.ParentLink-cne'ORIGINAL_ENGINE_INSTANCE_FACT_NOT_SESSION_ID' -or $f.ActualExitCode-ne1603){$coverage.Add('ORIGINAL_BEGIN_METADATA_PARENT_OR_EXPECTED_1603_UNKNOWN')}}
 if($facts.Count-ne1){$coverage.Add('ADDITIONAL_CAPTURED_CONTROLS_REQUIRE_REVIEW')}
 return @{knownControlsReturned=($returns.Count-eq0);complete=($returns.Count-eq0 -and $coverage.Count-eq0);returnProblems=@($returns.ToArray());coverageProblems=@($coverage.ToArray());actualObservedRoles=@($facts|ForEach-Object{$_.Role});metadataWarnings=@($closed.MetadataWarnings);captureWarnings=@($closed.CaptureWarnings);scope='Expected pre-admission rejection: real original client/Begin errors and captured object return; not four-role success';noBrokerCreated='NOT_CLAIMED_FROM_MISSING_OBSERVATION';sourceContract='Exact compiled Begin validates damaged preimage before broker spawn or durable Pending; independently measured absence is not creation history';missesPossible=$closed.MissesPossible}
}
function Observe-RejectImages($row){
 if(-not$row.Contains('observerFinal')){return @{status='UNKNOWN_NO_OBSERVER_FINAL';allCapturedImagesKnownAbsent=$false;images=@();mutations=$false}}
 $paths=@();foreach($p in @($row.observerFinal.Processes|Select-Object -ExpandProperty Image -Unique)){$paths+=,(Known-Path $p)}
 $all=($paths.Count-gt0 -and @($paths|Where-Object{$_.status-cne'KNOWN_ABSENT'}).Count-eq0)
 return @{status=$(if($all){'PASS_CAPTURED_REJECT_IMAGE_AUTOMATIC_ABSENCE'}else{'UNKNOWN_OR_PRESENT'});allCapturedImagesKnownAbsent=$all;images=$paths;brokerImageKnownAbsent=$null;noBrokerEverCreated='NOT_CLAIMED';mutations=$false}
}
function Assert-ControlStateUnchanged($before,$after){
 foreach($part in @('registration','markers','components','run')){
  $a=$before.observations.$part|ConvertTo-Json -Depth 18 -Compress;$b=$after.observations.$part|ConvertTo-Json -Depth 18 -Compress
  Require ($null-ne$before.observations.$part -and $null-ne$after.observations.$part -and $a-ceq$b) ('UNCHANGED_CONTROL_STATE_'+$part.ToUpperInvariant())
 }
}
function Invoke-Negative([string]$kind){
 Require ((Remaining)-gt180000 -and -not$script:ownerUnknown -and -not$script:instrumentUnknown -and $null-eq$script:activeMutation) 'NO_NEGATIVE_MUTATION_WITHOUT_ORIGINAL_RETURN_AND_RESERVE'
 $base=Measure-State 'Present';Assert-State $base 'Present';Require ((Coordination).pendingKnownAbsent) 'BEFORE_NEGATIVE_PENDING_ABSENT'
 $payload=@($script:c.payloads|Where-Object{$_.path-ceq'web/index.html'});Require ($payload.Count-eq1) 'ONE_FIXED_NONEXECUTABLE_RESOURCE'
 $case=[ordered]@{kind=$kind;status='FAIL_NOT_COMPLETE';beforeHealthy=$base;mutation=$null;rejection=$null;fixtureRestoration='NOT_RUN';scope='Synthetic owned payload change and restoration only; no claim of MSI damaged repair or transaction rollback'}
 $script:resultMutations+=,$case;$script:result['negativeCases']=$script:resultMutations
 $script:activeMutation=[FcR79PayloadFixture]::Capture($ScratchRoot,$script:c.runtimeNonce,$kind,[int]$payload[0].size,$payload[0].sha256)
 $case.mutation=Copy-Fact $script:activeMutation;New-Json (Join-Path $ScratchRoot ($kind.ToLowerInvariant()+'-mutation-captured.json')) $case.mutation
 [FcR79PayloadFixture]::Apply($script:activeMutation);$case.mutation=Copy-Fact $script:activeMutation
 New-Json (Join-Path $ScratchRoot ($kind.ToLowerInvariant()+'-mutation-applied.json')) $case.mutation
 $damaged=Measure-State 'Present';$case['beforeRejectedState']=$damaged;Require (-not$damaged.healthyPresent -and $damaged.stateClassification-ceq'UNKNOWN_OR_MISMATCH') 'ACTUAL_DAMAGED_PREIMAGE_REQUIRED';Assert-ControlStateUnchanged $base $damaged
 $phase=Invoke-Phase ($kind.ToLowerInvariant()+'-reject') 'Reject' 180000;$case.rejection=$phase
 Require (-not$script:ownerUnknown -and -not$script:instrumentUnknown -and $phase.client.actualExit -and $phase.client.pipesComplete -and -not$phase.client.timedOut -and $phase.client.exitCode-eq1603 -and $phase.ownerProof.complete) 'EXPECTED_REAL_CLIENT_BEGIN_REJECTION_NOT_PROVEN'
 Require ($phase.helperImageCleanup.status-ceq'PASS_CAPTURED_REJECT_IMAGE_AUTOMATIC_ABSENCE') 'NEGATIVE_HELPER_IMAGE_NOT_ABSENT'
 Require ((Coordination).pendingKnownAbsent) 'AFTER_REJECTION_PENDING_NOT_KNOWN_ABSENT'
 [FcR79PayloadFixture]::CheckPreserved($script:activeMutation)
 $after=Measure-State 'Present';$case['afterRejectedState']=$after;Require (-not$after.healthyPresent -and $after.stateClassification-ceq'UNKNOWN_OR_MISMATCH') 'REJECTION_DID_NOT_PRESERVE_DAMAGED_CLASSIFICATION';Assert-ControlStateUnchanged $base $after
 Require ((Remaining)-gt180000) 'RESTORATION_AND_UNINSTALL_RESERVE_REQUIRED'
 [FcR79PayloadFixture]::Restore($script:activeMutation);$case.mutation=Copy-Fact $script:activeMutation
 $healthy=Measure-State 'Present';$case['afterFixtureRestore']=$healthy;Assert-State $healthy 'Present';Assert-ControlStateUnchanged $base $healthy
 $case.fixtureRestoration='EXACT_OWNED_FIXTURE_RESTORED_NOT_MSI_REPAIR';$case.status='PASS_EXPECTED_REJECTION_AND_PRESERVED_PREIMAGE_WITH_EXACT_FIXTURE_RESTORE'
 New-Json (Join-Path $ScratchRoot ($kind.ToLowerInvariant()+'-negative-result.json')) $case;$script:activeMutation=$null
}
''' +s[insert:]
s=s.replace("'ProductState.ps1','Invoke-ProductionMsiPhases.ps1'", "'ProductState.ps1','PayloadFixture.cs','Invoke-ProductionMsiPhases.ps1'")
s=s.replace("Add-Type -LiteralPath (Join-Path $ScratchRoot 'GateRetirement.cs') -ErrorAction Stop", "Add-Type -LiteralPath (Join-Path $ScratchRoot 'GateRetirement.cs') -ErrorAction Stop\n Add-Type -LiteralPath (Join-Path $ScratchRoot 'PayloadFixture.cs') -ErrorAction Stop")
a=s.index(" $reapply=Invoke-Phase 'reapply' 'Reapply' 180000;");b=s.index(" $script:formalAttempted=$true;$uninstall=",a)
s=s[:a]+" foreach($kind in @('Missing','Tampered','Extra')){Invoke-Negative $kind}\n"+s[b:]
s=s.replace('PASS_THREE_PHASE_FOUR_ROLE_AUTOMATIC_IMAGE_CLEANUP_AND_ORIGINAL_GATE_WIN11_ONLY','PASS_FRESH_THREE_DAMAGED_PREIMAGE_REJECTIONS_AND_FORMAL_UNINSTALL_WIN11_ONLY')
# Restore only this known owned mutation after all original process objects have
# returned and Pending is absent, then use the original real /x fallback path.
needle="  try{$final=Measure-State 'Present';$coord=Coordination;"
replacement="""  try{
   if($null-ne$script:activeMutation){
    Require (-not$script:ownerUnknown -and -not$script:instrumentUnknown -and -not$script:activeMutation.NativeCloseUnknown -and (Coordination).pendingKnownAbsent -and (Remaining)-gt0) 'NO_SAFE_FIXTURE_RESTORE_WITH_UNKNOWN_OWNER_OR_PENDING'
    $actual=Measure-State 'Present'
    if($actual.healthyPresent){$script:result['failureFixtureRestoration']='ALREADY_HEALTHY_READONLY_FACT_NOT_FIXTURE_RESTORE'}elseif($actual.knownAbsent){$script:result['failureFixtureRestoration']='PRODUCT_ALREADY_ABSENT_NO_ORPHAN_PAYLOAD_RECREATED'}else{[FcR79PayloadFixture]::Restore($script:activeMutation);$restored=Measure-State 'Present';Assert-State $restored 'Present';$script:result['failureFixtureRestoration']='EXACT_OWNED_FIXTURE_RESTORED_ONLY'}
    $script:result['failureMutationFinal']=Copy-Fact $script:activeMutation;$script:activeMutation=$null
   }
   $final=Measure-State 'Present';$coord=Coordination;"""
assert s.count(needle)==1;s=s.replace(needle,replacement)
s=s.replace("$script:result['retainedDirectClients']=$script:retainedClients.Count", "$script:result['retainedDirectClients']=$script:retainedClients.Count;$script:result['activeMutationRetained']=($null-ne$script:activeMutation)")
(D/'Invoke-ProductionMsiPhases.ps1').write_text(s)
# Same source-261 normal PE/metadata admission, rebuilt same committed builder
# may run from the current audit-only main. Raw CI checkout bytes stay exact.
s=(O/'bind-production-msi-r78-third.py').read_text().replace('/tmp/fc-round78-ci-evidence','/tmp/fc-round79-msi-maintenance').replace('future-classroom-owned-r78-ci-evidence/v1','future-classroom-owned-r79-msi-maintenance/v1').replace('r78-production-msi','r79-production-msi')
s=s.replace("D/'adapted-third'/n","D/n").replace("D/'adapted-third/run-production-msi-r78-third.py'","D/'run-negative-msi-r79-first.py'")
s=s.replace("'ProductState.ps1','Invoke-ProductionMsiPhases.ps1')", "'ProductState.ps1','PayloadFixture.cs','Invoke-ProductionMsiPhases.ps1')")
s=s.replace("need(git(MAIN,'rev-parse','HEAD').decode().strip()==SOURCE,'BUILDER_MAIN_FROZEN_SOURCE')", "need(git(MAIN,'rev-parse','HEAD').decode().strip()=='c44906517fbc62233dca755d7225cea375264cbc','CURRENT_AUDIT_MAIN_FROZEN_SEPARATE_FROM_ORIGINAL_CI_SOURCE')")
ast.parse(s);(D/'bind-negative-msi-r79-first.py').write_text(s)
s=(O/'run-production-msi-r78-third.py').read_text().replace('/tmp/fc-round78-ci-evidence','/tmp/fc-round79-msi-maintenance').replace('future-classroom-owned-r78-ci-evidence/v1','future-classroom-owned-r79-msi-maintenance/v1').replace('r78-production-msi','r79-production-msi').replace("R/'msi-preparation-review-first'/'adapted-third'/n", "R/'negative-fixture-preparation-first'/n").replace('msi-preparation-review-first/bind-production-msi-r78-third.py','negative-fixture-preparation-first/bind-negative-msi-r79-first.py')
a=s.index('PINS=');b=s.index('\nBOOT=',a);names=['ProcessObserver.cs','GateRetirement.cs','ReadOnlyPreflightFunction.ps1','ProductState.cs','ProductState.ps1','PayloadFixture.cs','Invoke-ProductionMsiPhases.ps1']
s=s.replace("'ProductState.ps1', 'Invoke-ProductionMsiPhases.ps1')", "'ProductState.ps1', 'PayloadFixture.cs', 'Invoke-ProductionMsiPhases.ps1')")
a=s.index('PINS=');b=s.index('\nBOOT=',a);s=s[:a]+'PINS='+repr([hashlib.sha256((D/n).read_bytes()).hexdigest() for n in names])+s[b:]
s=s.replace('fdf2883efd291d0e5b01565b70970e59c42ff667f4130d007721382f305f07ec',hashlib.sha256((D/'bind-negative-msi-r79-first.py').read_bytes()).hexdigest())
s=s.replace("need(len(members)==8,'CLOSED_EIGHT_UPLOADS')", "need(len(members)==9,'CLOSED_NINE_UPLOADS')")
a=s.index('    full=(');b=s.index("    if full:return 'COMPLETE_PHASE_PASS_ONLY'",a)
s=s[:a]+'''    def returned(x,code):
        c=x.get('client',{});return c.get('started') is True and c.get('actualExit') is True and c.get('pipesComplete') is True and c.get('timedOut') is False and c.get('exitCode')==code and x.get('ownerProof',{}).get('complete') is True
    def positive(x):return returned(x,0) and x.get('helperImageCleanup',{}).get('status')=='PASS_PRECISE_HELPER_IMAGE_AUTOMATIC_ABSENCE' and x.get('helperImageCleanup',{}).get('brokerImageKnownAbsent') is True and x.get('helperImageCleanup',{}).get('allCapturedImagesKnownAbsent') is True
    def negative(x):return returned(x,1603) and x.get('kind')=='Reject' and x.get('helperImageCleanup',{}).get('status')=='PASS_CAPTURED_REJECT_IMAGE_AUTOMATIC_ABSENCE' and x.get('helperImageCleanup',{}).get('allCapturedImagesKnownAbsent') is True and x.get('ownerProof',{}).get('noBrokerCreated')=='NOT_CLAIMED_FROM_MISSING_OBSERVATION'
    cases=r.get('negativeCases',[])
    full=(r.get('status')=='PASS_FRESH_THREE_DAMAGED_PREIMAGE_REJECTIONS_AND_FORMAL_UNINSTALL_WIN11_ONLY' and r.get('cleanup')=='PASS_FORMAL_UNINSTALL_AND_ORIGINAL_GATE_RETIRED' and r.get('ownerUnknown') is False and r.get('instrumentUnknown') is False and r.get('activeMutationRetained') is False and r.get('retainedDirectClients')==0 and r.get('formalUninstallAttempted') is True and r.get('originalBudgetExceeded') is False and r.get('finallyProductState',{}).get('knownAbsent') is True and r.get('finallyCoordination',{}).get('namespaceKnownAbsent') is True and r.get('finallyCoordination',{}).get('pendingKnownAbsent') is True and r.get('uninstallCache',{}).get('allPreviouslyObservedPathsKnownAbsent') is True and len(phases)==5 and positive(phases[0]) and positive(phases[-1]) and all(negative(x) for x in phases[1:4]) and [x.get('kind') for x in cases]==['Missing','Tampered','Extra'] and all(x.get('status')=='PASS_EXPECTED_REJECTION_AND_PRESERVED_PREIMAGE_WITH_EXACT_FIXTURE_RESTORE' and x.get('fixtureRestoration')=='EXACT_OWNED_FIXTURE_RESTORED_NOT_MSI_REPAIR' and x.get('afterFixtureRestore',{}).get('healthyPresent') is True for x in cases))
''' +s[b:]
ast.parse(s);(D/'run-negative-msi-r79-first.py').write_text(s)
print('PREPARED_NOT_WINDOWS_RUN')
