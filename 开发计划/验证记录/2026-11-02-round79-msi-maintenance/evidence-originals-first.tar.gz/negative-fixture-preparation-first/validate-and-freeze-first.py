from pathlib import Path
import ast,hashlib,json,runpy,copy,subprocess,tarfile,difflib
D=Path(__file__).resolve().parent;R=Path('/workspace/共享/Eliora/未来教室计划')
def need(v,c):
 if not v:raise AssertionError(c)
def fact(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
for p in D.glob('*.py'):ast.parse(p.read_text())
module=runpy.run_path(str(D/'run-negative-msi-r79-first.py'),run_name='r79_inert_pure_validation');need([fact(p)['sha256'] for p in module['FILES']]==module['PINS'],'seven fixture source actual byte pins');need(len(module['FILES'])==7,'seven sources')
binder=runpy.run_path(str(D/'bind-negative-msi-r79-first.py'),run_name='r79_inert_binder_validation');need(list(binder['NAMES'])==[p.name for p in module['FILES']],'binder/transport seven source same order')
need(binder['SOURCE']==module['SOURCE']=='261c58aca8b0f63ff2cfb4dbd5e85c0d17770005','same original normal PE CI source')
positive=dict(client=dict(started=True,actualExit=True,pipesComplete=True,timedOut=False,exitCode=0),ownerProof=dict(complete=True),helperImageCleanup=dict(status='PASS_PRECISE_HELPER_IMAGE_AUTOMATIC_ABSENCE',brokerImageKnownAbsent=True,allCapturedImagesKnownAbsent=True))
negative=dict(kind='Reject',client=dict(started=True,actualExit=True,pipesComplete=True,timedOut=False,exitCode=1603),ownerProof=dict(complete=True,noBrokerCreated='NOT_CLAIMED_FROM_MISSING_OBSERVATION'),helperImageCleanup=dict(status='PASS_CAPTURED_REJECT_IMAGE_AUTOMATIC_ABSENCE',allCapturedImagesKnownAbsent=True))
cases=[dict(kind=k,status='PASS_EXPECTED_REJECTION_AND_PRESERVED_PREIMAGE_WITH_EXACT_FIXTURE_RESTORE',fixtureRestoration='EXACT_OWNED_FIXTURE_RESTORED_NOT_MSI_REPAIR',afterFixtureRestore=dict(healthyPresent=True)) for k in ('Missing','Tampered','Extra')]
r=dict(status='PASS_FRESH_THREE_DAMAGED_PREIMAGE_REJECTIONS_AND_FORMAL_UNINSTALL_WIN11_ONLY',cleanup='PASS_FORMAL_UNINSTALL_AND_ORIGINAL_GATE_RETIRED',ownerUnknown=False,instrumentUnknown=False,activeMutationRetained=False,retainedDirectClients=0,formalUninstallAttempted=True,originalBudgetExceeded=False,finallyProductState=dict(knownAbsent=True),finallyCoordination=dict(namespaceKnownAbsent=True,pendingKnownAbsent=True),uninstallCache=dict(allPreviouslyObservedPathsKnownAbsent=True),phases=[copy.deepcopy(positive),copy.deepcopy(negative),copy.deepcopy(negative),copy.deepcopy(negative),copy.deepcopy(positive)],negativeCases=cases)
admit=module['phase_cleanup_admission'];need(admit(r)=='COMPLETE_PHASE_PASS_ONLY','full independent profile positive');tests=[dict(name='fresh0 three known1603 rejections restored x0',actual=admit(r))]
for name,mut in [('negative client unexpectedly zero',lambda x:x['phases'][1]['client'].update(exitCode=0)),('negative Begin coverage unknown',lambda x:x['phases'][2]['ownerProof'].update(complete=False)),('negative image remains',lambda x:x['phases'][3]['helperImageCleanup'].update(allCapturedImagesKnownAbsent=False)),('fresh original nonzero',lambda x:x['phases'][0]['client'].update(exitCode=1603)),('uninstall original nonzero',lambda x:x['phases'][4]['client'].update(exitCode=1603)),('active mutation retained',lambda x:x.update(activeMutationRetained=True)),('pending remains',lambda x:x['finallyCoordination'].update(pendingKnownAbsent=False)),('restoration unknown',lambda x:x['negativeCases'][1].update(fixtureRestoration='UNKNOWN')),('fake no broker creation inference',lambda x:x['phases'][1]['ownerProof'].update(noBrokerCreated=True)),('whole budget exceeded',lambda x:x.update(originalBudgetExceeded=True)),('wrong scenario order',lambda x:x['negativeCases'].reverse())]:
 v=copy.deepcopy(r);mut(v);value=admit(v);need(value=='RETAIN_UNKNOWN',name);tests.append(dict(name=name,actual=value))
# Independent semantic model: restoration accepts known exact original object
# and permitted byte-state only. This does not exercise the C# Windows adapter.
original=b'<html>synthetic</html>';altered=bytes([original[0]^1])+original[1:];obj=(1,2,3,4)
def can_restore_tamper(identity,body):return identity==obj and body in (original,altered)
restoreCases=[]
for label,identity,body,expected in [('same original exact before',obj,original,True),('same original one-byte after',obj,altered,True),('same bytes namespace substituted',(1,2,30,4),altered,False),('same object unexpected content',obj,b'foreign',False)]:
 actual=can_restore_tamper(identity,body);need(actual==expected,label);restoreCases.append(dict(name=label,actual=actual,expected=expected))
cs=(D/'PayloadFixture.cs').read_text();ps=(D/'Invoke-ProductionMsiPhases.ps1').read_text();checks={
 'fixed_nonexec_resource': '@"web\\index.html"' in cs and 'web/fc-r79-negative' not in cs,
 'nonce_extra_only': 'web\\fc-r79-negative-' in cs and 'EXCLUSIVE_EXTRA_ABSENT' in cs,
 'source_manifest_sha_before_mutation':'EXACT_ORIGINAL_RESOURCE_BYTES' in cs,
 'original_file_id_before_delete_and_overwrite':'ORIGINAL_RESOURCE_STILL_EXACT' in cs and 'SameObject(f,s.Original)' in cs,
 'same_object_and_exact_before_or_after_restore':'RESTORE_ONLY_ORIGINAL_OBJECT_AND_EXACT_BEFORE_OR_ONE_BYTE_AFTER' in cs,
 'extra_object_checked_before_delete':'REMOVE_ONLY_ORIGINAL_CREATED_NONCE_OBJECT' in cs,
 'nonreparse_single_link':'NONREPARSE_SINGLE_LINK_FILE_OR_REAL_DIRECTORY' in cs,
 'checked_native_return':'UNKNOWN_CLOSE_NOT_RETRIED' in cs and 'finally{hs.Finish();}' in cs,
 'capture_state_saved_before_apply':ps.index('$script:activeMutation=[FcR79PayloadFixture]::Capture')<ps.index('[FcR79PayloadFixture]::Apply'),
 'all_tree_bytes_ids_unchanged_after_reject':'NEGATIVE_MSI_CHANGED_FIXTURE_PREIMAGE' in cs,
 'read_write_handles_return_before_msi':cs.index('finally{hs.Finish();}s.BeforeMsiTree=Tree(s)')>cs.index('public static void Apply') and ps.index('[FcR79PayloadFixture]::Apply')<ps.index("$phase=Invoke-Phase ($kind.ToLowerInvariant()+'-reject')"),
 'full_control_states_compared':"@('registration','markers','components','run')" in ps,
 'one_real_negative_msiexec_per_case':"$phase=Invoke-Phase ($kind.ToLowerInvariant()+'-reject') 'Reject' 180000" in ps,
 'negative_original1603_not_four_role_zero':'$f.ActualExitCode-ne1603' in ps and 'NOT_CLAIMED_FROM_MISSING_OBSERVATION' in ps,
 'native_broker_120_and_whole600_reserve180_unchanged':all(x in ps for x in ['nativeBrokerOriginalSeconds=120','600000','150000','cleanupReserveMilliseconds=180000']),
 'unknown_pending_or_close_blocks_restoration':'NO_SAFE_FIXTURE_RESTORE_WITH_UNKNOWN_OWNER_OR_PENDING' in ps and 'activeMutation.NativeCloseUnknown' in ps,
 'no_system_account_run_acl_change_in_new_fixture':all(x not in cs for x in ['RegSetValue','RegDelete','SetAccessControl','CreateProcess','TerminateProcess','ServiceController','ProgramData','Installer\\']),
}
# The top comment explicitly mentions prohibited scopes; do not interpret prose
# as an API call. No ProgramData access string or API appears in executable code.
checks['no_system_account_run_acl_change_in_new_fixture']=all(x not in cs for x in ['RegSetValue','RegDelete','SetAccessControl','CreateProcess','TerminateProcess','ServiceController','Environment.SpecialFolder.CommonApplicationData','@"C:\\Windows\\Installer'])
need(all(checks.values()),'static closed-scope checks')
commands=[]
for p in (D/'bind-negative-msi-r79-first.py',D/'run-negative-msi-r79-first.py'):
 child=subprocess.run(['python3',str(p)],capture_output=True,timeout=10);need(child.returncode==0 and not child.stderr,'inert default actual0');commands.append(dict(command=['python3',str(p)],exitCode=child.returncode,stdout=child.stdout.decode(),windows='NOT_RUN'))
originals=[]
with tarfile.open(R/'开发计划/验证记录/2026-11-01-round78-ci/evidence-originals-first.tar.gz','r:gz') as t:
 for p in sorted((D/'originals').iterdir()):
  member='msi-preparation-review-first/'+('bind-production-msi-r78-third.py' if p.name=='bind-production-msi-r78-third.py' else 'adapted-third/'+p.name);raw=t.extractfile(member).read();need(raw==p.read_bytes(),'raw archived originals exact');originals.append(dict(member=member,local=fact(p)))
  if p.name in ('ProcessObserver.cs','GateRetirement.cs','ReadOnlyPreflightFunction.ps1','ProductState.cs','ProductState.ps1'):need(p.read_bytes()==(D/p.name).read_bytes(),'five original successful modules unchanged')
 for name in ('Invoke-ProductionMsiPhases.ps1','bind-production-msi-r78-third.py','run-production-msi-r78-third.py'):
  old=(D/'originals'/name);new=D/({'bind-production-msi-r78-third.py':'bind-negative-msi-r79-first.py','run-production-msi-r78-third.py':'run-negative-msi-r79-first.py'}.get(name,name));(D/(name+'.r79.diff')).write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile='R78/'+name,tofile='R79/'+new.name)))
tracked=['crates/fc-windows/src/installer_lifecycle/broker.rs','crates/fc-windows/src/installer_lifecycle/native/broker.rs','crates/fc-windows/src/installer_lifecycle/native/broker/supervisor.rs','crates/fc-windows/src/installer_lifecycle/native/broker/retirement.rs']
product=[]
for n in tracked:
 b=(R/n).read_bytes();old=subprocess.check_output(['git','-C',str(R),'show',module['SOURCE']+':'+n],timeout=10);need(b==old,'normal production source unchanged vs accepted CI');product.append(fact(R/n))
receipt=dict(status='PREPARED_R79_NEGATIVE_MSI_MATRIX_FINITE_STATIC_AND_PURE_ONLY',normalPeSourceGit=module['SOURCE'],currentAuditMainGit='c44906517fbc62233dca755d7225cea375264cbc',files=[fact(D/n) for n in [*[p.name for p in module['FILES']],'bind-negative-msi-r79-first.py','run-negative-msi-r79-first.py']],originals=originals,unchangedProductSources=product,pythonAst='PASS',defaultInertCommands=commands,staticChecks=checks,pureTransportAdmissionCases=tests,pureRestorationEligibilityCases=restoreCases,powershellParse='NOT_RUN',csharpCompile='NOT_RUN',actualNewMsiBinding='NOT_RUN_WAITING_REAL_PACKAGE_AND_ORIGINAL_CI_INPUTS',windows='NOT_RUN',budgets=dict(originalOuterSeconds=900,originalWholeSeconds=600,maximumPhaseSeconds=150,cleanupReserveSeconds=180,nativeBrokerOriginalSeconds=120),scope='Actual future experiment is fresh healthy install, three distinct damaged preimages each real rejected reinstall, exact synthetic fixture restoration, then real uninstall. Missing observation never proves broker was not created. Fixture restoration is not MSI damaged repair or transaction rollback.',failurePolicy='No new scenario after owner/Pending/checked-close uncertainty. Keep original failure and owned recovery bytes; finally only restores an exactly recognized owned fixture after original object return and Pending absence, then uses real /x within original remaining whole clock. This cannot guarantee automatic cleanup after an OS I/O failure or unknown original owner; it deliberately retains evidence and requires root resolution.',entrypoints=dict(binder=str(D/'bind-negative-msi-r79-first.py'),transport=str(D/'run-negative-msi-r79-first.py')),finalFilesFrozen=True)
p=D/'freeze-first.json';need(not p.exists(),'create-new first freeze');p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(fact(p)))
