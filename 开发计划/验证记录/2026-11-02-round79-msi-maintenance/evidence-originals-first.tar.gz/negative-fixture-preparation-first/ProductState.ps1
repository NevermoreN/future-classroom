# Dot-source only defines this function. All product observation is explicit.
function Measure-FcProductState {
    [CmdletBinding()]
    param($Config,[string]$Expected)
    try {
        if ($Expected -cne 'Present' -and $Expected -cne 'Absent') { throw 'EXPECTED_PRESENT_OR_ABSENT_LABEL' }
        if ($null -eq $Config) { throw 'CONFIG_REQUIRED' }
        if ($Config.status -cne 'BOUND_PLAN_ONLY_NOT_EXECUTABLE_OR_RUNTIME_PASS' -or
            $Config.sourceGit -cne '261c58aca8b0f63ff2cfb4dbd5e85c0d17770005' -or
            $Config.target -cne 'i686-win7-windows-msvc' -or
            $Config.family -cne '99378807-098D-5F04-8D4D-F181DFA218D5' -or
            $Config.registryMarkerKey -cne 'Software\FutureClassroom\Installer\Components' -or
            $Config.runKey -cne 'Software\Microsoft\Windows\CurrentVersion\Run' -or
            $Config.runValue -cne 'FutureClassroom' -or $Config.registryView -cne 'Registry32' -or
            @($Config.fixedDestinationKnownFolderSuffix).Count -ne 2 -or
            $Config.fixedDestinationKnownFolderSuffix[0] -cne 'Programs' -or
            $Config.fixedDestinationKnownFolderSuffix[1] -cne 'FutureClassroom') { throw 'EXACT_BOUND_CONFIG_SCOPE' }
        foreach ($name in @('productCode','family','version','expectedUserSid','sourceGit')) {
            if ($Config.$name -isnot [string]) { throw 'CONFIG_STRING_TYPES_REQUIRED' }
        }
        $rows=@($Config.payloads)
        if ($rows.Count -lt 1 -or $rows.Count -gt 72) { throw 'PAYLOAD_ROW_BOUND' }
        $paths=[Collections.Generic.List[string]]::new()
        $sizes=[Collections.Generic.List[long]]::new()
        $hashes=[Collections.Generic.List[string]]::new()
        $components=[Collections.Generic.List[string]]::new()
        foreach ($row in $rows) {
            if ($row.path -isnot [string] -or $row.sha256 -isnot [string] -or $row.component_guid -isnot [string] -or
                ($row.size -isnot [Int32] -and $row.size -isnot [Int64])) { throw 'TYPED_PAYLOAD_ROW_REQUIRED' }
            $paths.Add($row.path);$sizes.Add([long]$row.size);$hashes.Add($row.sha256);$components.Add($row.component_guid)
        }
        if ($null -eq ('FcR78ProductState' -as [type])) {
            $source=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'ProductState.cs') -Raw -Encoding UTF8
            Add-Type -TypeDefinition $source -Language CSharp -ErrorAction Stop
        }
        return ,([FcR78ProductState]::Measure($Config.sourceGit,$Config.productCode,$Config.family,$Config.version,
            $Config.expectedUserSid,$paths.ToArray(),$sizes.ToArray(),$hashes.ToArray(),$components.ToArray(),$Expected))
    } catch {
        $e=$_.Exception;while ($null -ne $e.InnerException) { $e=$e.InnerException }
        return @{status='FAIL_CONFIG_OR_INSTRUMENTATION';expected=$Expected;stateClassification='UNKNOWN_OR_MISMATCH';
            healthyPresent=$false;knownAbsent=$false;matchesExpected=$false;mutations=$false;
            coordinationGate='NOT_MEASURED_BY_THIS_MODULE';observations=@{};
            phaseErrors=@(@{phase='configOrCompile';exceptionType=$e.GetType().FullName;hresult=$e.HResult;
                win32Error=$(if($e -is [ComponentModel.Win32Exception]){$e.NativeErrorCode}else{$null});
                code='CONFIG_OR_INSTRUMENTATION_FAILURE_NO_ABSENCE_INFERENCE'});
            scope='No Windows compilation/runtime PASS inferred; caller preserves this typed failure.'}
    }
}
