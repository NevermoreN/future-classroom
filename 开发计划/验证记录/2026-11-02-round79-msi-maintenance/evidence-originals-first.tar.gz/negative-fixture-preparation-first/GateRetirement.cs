// TEST INSTRUMENT ONLY. No product entry point; no Pending removal or registry writes.
// Root must establish BEFORE namespace absence and final exact product/effects/owner
// settlement from raw evidence before calling Retire. This class cannot establish MSI
// settlement; a caller boolean is deliberately not accepted as a substitute.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;

public static class FcR76GateRetirement {
    const uint Query = 0x80, ReadControl = 0x20000, Delete = 0x10000;
    const uint OpenExisting = 3, Flags = 0x02200000; // BACKUP_SEMANTICS|OPEN_REPARSE_POINT
    const string Leaf = "FutureClassroom-Installer-99378807-098D-5F04-8D4D-F181DFA218D5";
    [StructLayout(LayoutKind.Sequential)] struct Info {
        public uint Attributes, CreationLow, CreationHigh, AccessLow, AccessHigh;
        public uint WriteLow, WriteHigh, Volume, SizeHigh, SizeLow, Links, IndexHigh, IndexLow;
    }
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
    static extern IntPtr CreateFile(string p, uint a, uint s, IntPtr sa, uint d, uint f, IntPtr t);
    [DllImport("kernel32.dll", SetLastError=true)] static extern bool GetFileInformationByHandle(IntPtr h, out Info i);
    [DllImport("kernel32.dll", SetLastError=true)] static extern bool GetFileInformationByHandleEx(IntPtr h, int c, IntPtr b, uint n);
    [DllImport("kernel32.dll", SetLastError=true)] static extern bool SetFileInformationByHandle(IntPtr h, int c, byte[] b, uint n);
    [DllImport("kernel32.dll", SetLastError=true)] static extern bool CloseHandle(IntPtr h);
    [DllImport("kernel32.dll")] static extern IntPtr LocalFree(IntPtr p);
    [DllImport("advapi32.dll")] static extern uint GetSecurityInfo(IntPtr h, int type, uint flags, out IntPtr owner, out IntPtr group, out IntPtr dacl, out IntPtr sacl, out IntPtr sd);
    [DllImport("advapi32.dll")] static extern uint GetSecurityDescriptorLength(IntPtr sd);
    static bool faulted;
    static void Need(bool value, string stage) { if (!value) throw new InvalidOperationException(stage); }
    static Exception Error(string stage) { return new Win32Exception(Marshal.GetLastWin32Error(), stage); }
    static IntPtr Open(string p, uint a, uint share) {
        Need(!faulted, "instrument_sticky_close_fault");
        IntPtr h=CreateFile(p,a,share,IntPtr.Zero,OpenExisting,Flags,IntPtr.Zero);
        if(h==new IntPtr(-1)) throw Error("OPEN_EXISTING:"+Path.GetFileName(p));
        return h;
    }
    static void Close(ref IntPtr h) {
        if(h==IntPtr.Zero) return;
        IntPtr original=h;h=IntPtr.Zero; // unknown close is never retried
        if(!CloseHandle(original)) { faulted=true;throw Error("checked_close_unknown_retained"); }
    }
    static Info Inspect(IntPtr h, bool directory) {
        Info i;if(!GetFileInformationByHandle(h,out i)) throw Error("file_identity");
        Need((i.Attributes&0x400)==0 && ((i.Attributes&16)!=0)==directory, "reparse_or_wrong_type");
        if(!directory) Need(i.Links==1 && i.SizeHigh==0 && i.SizeLow==0,"gate_not_empty_single_link");
        return i;
    }
    static string Id(Info i) {
        return i.Volume.ToString("x8")+":"+i.IndexHigh.ToString("x8")+i.IndexLow.ToString("x8")+":"+i.CreationHigh.ToString("x8")+i.CreationLow.ToString("x8");
    }
    static string Security(IntPtr h, string user, bool dir) {
        IntPtr owner,group,dacl,sacl,sd;
        uint e=GetSecurityInfo(h,1,5,out owner,out group,out dacl,out sacl,out sd);
        if(e!=0) throw new Win32Exception((int)e,"GetSecurityInfo");
        try {
            uint n=GetSecurityDescriptorLength(sd);Need(n>=20&&n<=8192,"bounded_sd");
            byte[] b=new byte[n];Marshal.Copy(sd,b,0,(int)n);
            RawSecurityDescriptor s=new RawSecurityDescriptor(b,0);
            Need(s.Owner!=null && s.Owner.Value==user && (s.ControlFlags&ControlFlags.DiscretionaryAclProtected)!=0 && s.DiscretionaryAcl!=null && s.DiscretionaryAcl.Count==2,"exact_owner_protected_two_aces");
            HashSet<string> seen=new HashSet<string>(StringComparer.Ordinal);
            for(int j=0;j<2;j++) {
                CommonAce a=s.DiscretionaryAcl[j] as CommonAce;
                Need(a!=null && a.AceQualifier==AceQualifier.AccessAllowed && !a.IsCallback && a.AccessMask==0x1f01ff && a.AceFlags==(dir?(AceFlags.ContainerInherit|AceFlags.ObjectInherit):AceFlags.None),"exact_full_control_ace");
                Need((a.SecurityIdentifier.Value==user || a.SecurityIdentifier.Value=="S-1-5-18") && seen.Add(a.SecurityIdentifier.Value),"exact_user_system_only");
            }
            // Compare the owner+DACL semantic SDDL, excluding irrelevant descriptor offsets.
            return s.GetSddlForm(AccessControlSections.Owner|AccessControlSections.Access);
        } finally { if(LocalFree(sd)!=IntPtr.Zero) { faulted=true;throw new InvalidOperationException("LocalFree_unknown"); } }
    }
    // Enumerates the HELD directory, not a newly resolved path. FileIdBothDirectoryInfo.
    static string[] Names(IntPtr h) {
        List<string> names=new List<string>();IntPtr b=Marshal.AllocHGlobal(65536);
        try {
            bool first=true;
            for(int batch=0;batch<4;batch++) {
                if(!GetFileInformationByHandleEx(h,first?11:10,b,65536)) {
                    int e=Marshal.GetLastWin32Error();if(e==18) return names.ToArray();
                    throw new Win32Exception(e,"held_directory_enumeration");
                }
                first=false;int offset=0;
                for(int k=0;k<64;k++) {
                    Need(offset>=0&&offset+104<=65536,"directory_record_bounds");
                    uint next=(uint)Marshal.ReadInt32(b,offset), n=(uint)Marshal.ReadInt32(b,offset+60);
                    Need(n<=512 && (n&1)==0 && offset+104+n<=65536,"bounded_directory_name");
                    string name=Marshal.PtrToStringUni(IntPtr.Add(b,offset+104),(int)n/2);
                    if(name!="." && name!="..") { Need(names.Count<4,"unexpected_directory_members");names.Add(name); }
                    if(next==0) break;
                    Need(next>=104+n && (next&7)==0 && offset+next+104<=65536,"next_record_bounds");offset+=(int)next;
                    Need(k<63,"too_many_directory_records");
                }
            }
            throw new InvalidOperationException("directory_enumeration_budget");
        } finally { Marshal.FreeHGlobal(b); }
    }
    public sealed class Snapshot {
        internal readonly string Root, User, RootId, GateId, RootSd, GateSd;
        internal bool Used;
        internal Snapshot(string r,string u,string ri,string gi,string rs,string gs) { Root=r;User=u;RootId=ri;GateId=gi;RootSd=rs;GateSd=gs; }
        public string[] Facts() { return new string[]{Root,User,RootId,GateId,RootSd,GateSd}; }
    }
    static List<IntPtr> Parents(string root) {
        List<string> paths=new List<string>();string p=Path.GetDirectoryName(root);
        while(p!=null) { paths.Add(p);p=Path.GetDirectoryName(p); }
        paths.Reverse();Need(paths.Count<=48,"ancestor_budget");List<IntPtr> hs=new List<IntPtr>();
        try { foreach(string path in paths) { IntPtr h=Open(path,Query|ReadControl,3);hs.Add(h);Inspect(h,true); }return hs; }
        catch { for(int j=hs.Count-1;j>=0;j--) { IntPtr h=hs[j];try { Close(ref h); } catch { faulted=true; } }throw; }
    }
    static void CloseParents(List<IntPtr> hs) {
        Exception failure=null;for(int j=hs.Count-1;j>=0;j--) { IntPtr h=hs[j];try { Close(ref h); } catch(Exception e) { failure=e; } }
        if(failure!=null) throw failure;
    }
    static string Root(string sid) {
        using(WindowsIdentity i=WindowsIdentity.GetCurrent()) Need(i.User.Value==sid,"current_user_sid");
        string p=Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        Need(Path.IsPathRooted(p) && p.Length>3 && p[1]==':' && !p.StartsWith(@"\\",StringComparison.Ordinal),"fixed_local_drive_knownfolder");
        return Path.Combine(p,Leaf);
    }
    // Call AFTER first successful fresh settlement, no active helper/owner/Pending.
    // Records identity only, releases handles before future maintenance.
    public static Snapshot Capture(string expectedUserSid) {
        string root=Root(expectedUserSid);List<IntPtr> parents=Parents(root);IntPtr d=IntPtr.Zero,g=IntPtr.Zero;
        try {
            d=Open(root,Query|ReadControl|1,3);string ri=Id(Inspect(d,true)),rs=Security(d,expectedUserSid,true);
            string[] names=Names(d);Need(names.Length==1&&names[0]=="gate.lock","only_gate_no_pending");
            g=Open(Path.Combine(root,"gate.lock"),Query|ReadControl,0);
            return new Snapshot(root,expectedUserSid,ri,Id(Inspect(g,false)),rs,Security(g,expectedUserSid,false));
        } finally { try { Close(ref g); } finally { try { Close(ref d); } finally { CloseParents(parents); } } }
    }
    // Root-only test orchestration calls AFTER successful formal /x, independent exact
    // absence/effects/held-owner evidence, within remaining original test deadline.
    // This is not a recovery API and never establishes settlement from caller flags.
    public static string Retire(Snapshot original) {
        Need(original!=null&&!original.Used&&!faulted,"single_use_snapshot");original.Used=true;
        Need(Root(original.User)==original.Root,"fixed_root_unchanged");
        List<IntPtr> parents=Parents(original.Root);IntPtr d=IntPtr.Zero,g=IntPtr.Zero;
        try {
            d=Open(original.Root,Query|ReadControl|Delete|1,3);
            Need(Id(Inspect(d,true))==original.RootId && Security(d,original.User,true)==original.RootSd,"original_directory_identity_acl");
            string[] names=Names(d);Need(names.Length==1&&names[0]=="gate.lock","only_original_gate_no_pending");
            g=Open(Path.Combine(original.Root,"gate.lock"),Query|ReadControl|Delete,0);
            Need(Id(Inspect(g,false))==original.GateId&&Security(g,original.User,false)==original.GateSd,"original_gate_identity_acl");
            if(!SetFileInformationByHandle(g,4,new byte[]{1},1)) throw Error("gate_disposition");
            Close(ref g);
            Need(Names(d).Length==0,"original_directory_now_empty");
            if(!SetFileInformationByHandle(d,4,new byte[]{1},1)) throw Error("empty_directory_disposition");
            Close(ref d);
            return "DISPOSITION_AND_CHECKED_CLOSE_ONLY_REQUIRE_EXTERNAL_ABSENCE_READBACK";
        } finally { try { Close(ref g); } finally { try { Close(ref d); } finally { CloseParents(parents); } } }
    }
}
