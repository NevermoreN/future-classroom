param([switch]$Execute,[string]$ScratchRoot,[string]$ExpectedConfigSha256,[string]$ExpectedInputsManifestSha256)
# Root alone invokes in a fresh PowerShell5.1 x64 process after nonce-owned
# scratch upload. Default performs no file/state/API inspection or compilation.
if(-not $Execute){@{status='PREPARED_NO_EXECUTION';windowsRuntime='NOT_RUN';remaining='Actual pinned config/MSI/upload manifest; root review, compilation and finite observation'}|ConvertTo-Json -Compress;return}
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$whole=[Diagnostics.Stopwatch]::StartNew()
$script:beforeAbsent=$false;$script:installAttempted=$false;$script:formalAttempted=$false
$script:ownerUnknown=$false;$script:instrumentUnknown=$false;$script:gateSnapshot=$null;$script:retireAttempted=$false
$script:cachePaths=[Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
$script:activeMutation=$null;$script:resultMutations=@()
$script:retainedClients=[Collections.Generic.List[Diagnostics.Process]]::new()
$script:result=[ordered]@{status='FAIL_NOT_COMPLETE';originalWholeMilliseconds=600000;cleanupReserveMilliseconds=180000;maximumClientPhaseMilliseconds=150000;nativeBrokerOriginalSeconds=120;phases=@();installationScope='Authorized current-user administrator Win11 only; Win7-target binary is not Win7 OS proof';cleanup='NOT_RUN';engineLogSupplement='NOT_IMPLEMENTED_BY_THIS_PREPARATION_UNKNOWN_IS_NOT_EXIT0';helperImageCleanup='PRODUCT_AUTOMATIC_ONLY_NO_MANUAL_MSI_IMAGE_OR_CACHE_DELETION'}
function Require([bool]$v,[string]$code){if(-not $v){throw $code}}
function Digest([string]$p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function New-Bytes([string]$p,[byte[]]$b){$s=[IO.File]::Open($p,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);try{$s.Write($b,0,$b.Length);$s.Flush()}finally{$s.Dispose()}}
function New-Json([string]$p,$v){New-Bytes $p ([Text.UTF8Encoding]::new($false).GetBytes(($v|ConvertTo-Json -Depth 18)+"`n"))}
function Copy-Fact($v){return (($v|ConvertTo-Json -Depth 18 -Compress)|ConvertFrom-Json)}
function Remaining {return [Math]::Max(0,600000-$whole.ElapsedMilliseconds)}
function Quote([string]$v){Require (-not $v.Contains('"') -and -not $v.EndsWith('\') -and -not $v.Contains("`r") -and -not $v.Contains("`n")) 'CLOSED_ARGUMENT_ENCODING';return '"'+$v+'"'}
function Known-Path([string]$p){
 try{$a=[IO.File]::GetAttributes($p);return @{path=$p;status='KNOWN_PRESENT';directory=(($a-band[IO.FileAttributes]::Directory)-ne 0);reparse=(($a-band[IO.FileAttributes]::ReparsePoint)-ne 0)}}
 catch{$e=$_.Exception;while($null-ne$e.InnerException){$e=$e.InnerException};if($e-is[IO.FileNotFoundException]-or$e-is[IO.DirectoryNotFoundException]){return @{path=$p;status='KNOWN_ABSENT';directory=$false;reparse=$false}};return @{path=$p;status='UNKNOWN';exceptionKind=$e.GetType().FullName;hresult=$e.HResult;directory=$false;reparse=$false}}
}
function Coordination {
 $g=Known-Path $script:gateRoot;$p=Known-Path (Join-Path $script:gateRoot 'pending.v1')
 return @{root=$g;pending=$p;pendingKnownAbsent=($p.status-ceq'KNOWN_ABSENT' -and ($g.status-ceq'KNOWN_ABSENT' -or ($g.status-ceq'KNOWN_PRESENT' -and $g.directory -and -not$g.reparse)));namespaceKnownAbsent=($g.status-ceq'KNOWN_ABSENT');scope='Read-only fixed coordination path; not an owner/lease/settlement capability'}
}
function Measure-State([string]$expected){
 $v=Measure-FcProductState -Config $script:c -Expected $expected
 Require ($null-ne$v -and $v.stateClassification-in@('HEALTHY_PRESENT','KNOWN_ABSENT','UNKNOWN_OR_MISMATCH')) 'TYPED_STATE_RECEIPT'
 return (Copy-Fact $v)
}
function Assert-State($v,[string]$expected){
 if($expected-ceq'Present'){Require ($v.status-ceq'PASS_READONLY_EXPECTED_PRESENT' -and $v.healthyPresent-eq$true -and $v.stateClassification-ceq'HEALTHY_PRESENT') 'EXACT_HEALTHY_PRESENT_REQUIRED'}
 else{Require ($v.status-ceq'PASS_READONLY_EXPECTED_ABSENT' -and $v.knownAbsent-eq$true -and $v.stateClassification-ceq'KNOWN_ABSENT') 'EXACT_KNOWN_ABSENT_REQUIRED'}
}
function Owner-Proof($closed,$live){
 $returnProblems=[Collections.Generic.List[string]]::new();$coverageProblems=[Collections.Generic.List[string]]::new()
 if(-not $closed.WmiStarted -or -not $closed.Closed -or @($closed.Errors).Count-ne0){$returnProblems.Add('OBSERVER_ERROR_OR_NOT_RETURNED')}
 $facts=@($closed.Processes)
 foreach($f in $facts){
  # Metadata UNKNOWN never changes a successfully observed original object's
  # actual Wait/GetExit/Close. Full role coverage remains independently required.
  if($f.IdentityStatus-cne'ORIGINAL_QUERY_SYNC_HANDLE_EXACT_IMAGE_BYTES_USER' -or $f.Sha256-cne$script:c.embeddedHelper.sha256 -or $f.Sid-cne$script:c.expectedUserSid -or $f.ActualWait-ne0 -or $f.ActualExitCode-ne0 -or $f.ExitStatus-cne'ACTUAL_ORIGINAL_GET_EXIT_CODE' -or $f.CloseStatus-cne'CHECKED_CLOSE_SUCCESS'){$returnProblems.Add('CAPTURED_ORIGINAL_UNKNOWN_OR_NONZERO')}
  if($f.CommandStatus-cnotin@('EXACT_CREATION_MATCHED_WMI_FACT_ONLY','EXACT_ORIGINAL_HANDLE_NT_CLASS60_FACT_ONLY') -or $f.Role-ceq'UNKNOWN'){$coverageProblems.Add('CAPTURED_ORIGINAL_ROLE_METADATA_UNKNOWN')}
 }
 $byRole=@{}
 foreach($role in @('begin','broker','supervisor','guardian')){
  $same=@($facts|Where-Object{$_.Role-ceq$role})
  if($same.Count-ne1){$coverageProblems.Add('ROLE_'+$role+'_UNKNOWN_OR_NONUNIQUE')}else{$byRole[$role]=$same[0]}
 }
 if(-not$byRole.ContainsKey('broker')){$returnProblems.Add('ORIGINAL_BROKER_UNKNOWN_OR_NONUNIQUE')}
 if($byRole.ContainsKey('begin') -and $byRole.ContainsKey('broker')){
  $b=$byRole.broker;$a=$byRole.begin
  if($b.ParentLink-cne'HELD_ORIGINAL_BEGIN_INSTANCE' -or $b.ParentPid-ne$a.Pid -or $b.ParentCreationFiletime-ne$a.CreationFiletime -or $b.Image-ine$a.Image){$coverageProblems.Add('BROKER_ORIGINAL_BEGIN_LINK_OR_IMAGE_UNKNOWN')}
 }
 foreach($role in @('begin','supervisor')){if($byRole.ContainsKey($role) -and $byRole[$role].ParentLink-cne'ORIGINAL_ENGINE_INSTANCE_FACT_NOT_SESSION_ID'){$coverageProblems.Add('ROLE_'+$role+'_ENGINE_INSTANCE_UNKNOWN')}}
 if($byRole.ContainsKey('begin') -and $byRole.ContainsKey('supervisor')){
  $a=$byRole.begin;$p=$byRole.supervisor
  if($a.ParentPid-ne$p.ParentPid -or $a.ParentCreationFiletime-ne$p.ParentCreationFiletime -or $a.ParentImage-ine$p.ParentImage -or $a.ParentSid-cne$p.ParentSid){$coverageProblems.Add('ORIGINAL_ENGINE_INSTANCE_NOT_SAME')}
 }
 if($byRole.ContainsKey('supervisor') -and $byRole.ContainsKey('guardian')){
  $p=$byRole.supervisor;$g=$byRole.guardian
  if($g.ParentLink-cne'HELD_ORIGINAL_SUPERVISOR_INSTANCE' -or $g.ParentPid-ne$p.Pid -or $g.ParentCreationFiletime-ne$p.CreationFiletime -or $g.Image-ine$p.Image -or $null-eq$g.Transaction -or $g.Transaction-eq0 -or $g.Transaction-ne$p.Transaction){$coverageProblems.Add('GUARDIAN_ORIGINAL_SUPERVISOR_TRANSACTION_OR_IMAGE_UNKNOWN')}
 }
 return @{knownControlsReturned=($returnProblems.Count-eq0);complete=($returnProblems.Count-eq0 -and $coverageProblems.Count-eq0);returnProblems=@($returnProblems.ToArray());coverageProblems=@($coverageProblems.ToArray());brokerEverObservedWait258=($live.Count-gt0);metadataWarnings=@($closed.MetadataWarnings);captureWarnings=@($closed.CaptureWarnings);channel='Original held object actual return is separate from mandatory external four-role/engine/parent/transaction coverage';engineSupplement='UNKNOWN_NOT_IMPLEMENTED';productNativeAuthentication='Product-internal proof is not substituted for external observer coverage';businessAndCleanupSeparation='A supervisor nonzero after original broker exit0 is cleanup failure of potentially settled product; this observer does not infer retained Pending or rollback from that failure'}
}
function Observe-PhaseImages($row){
 if(-not$row.Contains('observerFinal')){return @{status='UNKNOWN_NO_OBSERVER_FINAL';brokerImageKnownAbsent=$false;allCapturedImagesKnownAbsent=$false;images=@();mutations=$false}}
 $facts=@($row.observerFinal.Processes);$images=@($facts|Select-Object -ExpandProperty Image -Unique);$paths=@()
 foreach($image in $images){$v=Known-Path $image;$paths+=,$v}
 $broker=@($facts|Where-Object{$_.Role-ceq'broker'})
 $v=@{status='UNKNOWN';scope='Precise paths of authenticated actual helpers only; no enumeration/deletion of MSI cache or shared processes';images=$paths;brokerImage=$(if($broker.Count-eq1){$broker[0].Image}else{$null});brokerImageKnownAbsent=$false;allCapturedImagesKnownAbsent=$false;mutations=$false}
 if($broker.Count-eq1){$m=@($paths|Where-Object{$_.path-ieq$broker[0].Image});$v.brokerImageKnownAbsent=($m.Count-eq1 -and $m[0].status-ceq'KNOWN_ABSENT')}
 $v.allCapturedImagesKnownAbsent=($paths.Count-gt0 -and @($paths|Where-Object{$_.status-cne'KNOWN_ABSENT'}).Count-eq0)
 if($v.brokerImageKnownAbsent -and $v.allCapturedImagesKnownAbsent){$v.status='PASS_PRECISE_HELPER_IMAGE_AUTOMATIC_ABSENCE'}
 return $v
}
function Observe-Cache([bool]$present){
 $v=[FcR78ProductState]::ObserveLocalPackage($script:productArgument,$script:c.expectedUserSid)
 if($present){Require ($v.status-ceq'KNOWN_PRESENT_EXACT_API_LOCALPACKAGE_READONLY') 'ACTUAL_EXACT_API_CACHE_PRESENT';[void]$script:cachePaths.Add($v.path)}else{Require ($v.status-ceq'KNOWN_PRODUCT_ABSENT_NO_CACHE_PATH') 'ACTUAL_CACHE_QUERY_PRODUCT_ABSENT'}
 $old=@();foreach($p in $script:cachePaths){$old+=,(Known-Path $p)}
 return @{actualProductQuery=$v;previouslyObservedExactPaths=$old;allPreviouslyObservedPathsKnownAbsent=($script:cachePaths.Count-gt0 -and @($old|Where-Object{$_.status-cne'KNOWN_ABSENT'}).Count-eq0);mutations=$false;scope='No cache directory enumeration; no cache deletion; cache SHA is observed, not falsely equated to input MSI bytes'}
}
function Reject-Proof($closed){
 $returns=[Collections.Generic.List[string]]::new();$coverage=[Collections.Generic.List[string]]::new();$facts=@($closed.Processes)
 if(-not$closed.WmiStarted -or -not$closed.Closed -or @($closed.Errors).Count-ne0){$returns.Add('ORIGINAL_OBSERVER_RETURN_UNKNOWN')}
 if($facts.Count-eq0){$returns.Add('NO_CAPTURED_ORIGINAL_PROCESS')}
 foreach($f in $facts){if($f.IdentityStatus-cne'ORIGINAL_QUERY_SYNC_HANDLE_EXACT_IMAGE_BYTES_USER' -or $f.Sha256-cne$script:c.embeddedHelper.sha256 -or $f.Sid-cne$script:c.expectedUserSid -or $f.ActualWait-ne0 -or $null-eq$f.ActualExitCode -or $f.ExitStatus-cne'ACTUAL_ORIGINAL_GET_EXIT_CODE' -or $f.CloseStatus-cne'CHECKED_CLOSE_SUCCESS'){$returns.Add('CAPTURED_ORIGINAL_RETURN_UNKNOWN')}}
 $begin=@($facts|Where-Object{$_.Role-ceq'begin'})
 if($begin.Count-ne1){$coverage.Add('EXACT_OBSERVED_BEGIN_UNKNOWN_OR_NONUNIQUE')}else{$f=$begin[0];if($f.CommandStatus-cnotin@('EXACT_CREATION_MATCHED_WMI_FACT_ONLY','EXACT_ORIGINAL_HANDLE_NT_CLASS60_FACT_ONLY') -or $f.ParentLink-cne'ORIGINAL_ENGINE_INSTANCE_FACT_NOT_SESSION_ID' -or $f.ActualExitCode-ne1603){$coverage.Add('ORIGINAL_BEGIN_METADATA_PARENT_OR_EXPECTED_1603_UNKNOWN')}}
 if($facts.Count-ne1){$coverage.Add('ADDITIONAL_CAPTURED_CONTROLS_REQUIRE_REVIEW')}
 return @{knownControlsReturned=($returns.Count-eq0);complete=($returns.Count-eq0 -and $coverage.Count-eq0);returnProblems=@($returns.ToArray());coverageProblems=@($coverage.ToArray());actualObservedRoles=@($facts|ForEach-Object{$_.Role});metadataWarnings=@($closed.MetadataWarnings);captureWarnings=@($closed.CaptureWarnings);scope='Expected pre-admission rejection: real original client/Begin errors and captured object return; not four-role success';noBrokerCreated='NOT_CLAIMED_FROM_MISSING_OBSERVATION';sourceContract='Exact compiled Begin validates damaged preimage before broker spawn or durable Pending; independently measured absence is not creation history';missesPossible=$closed.MissesPossible}
}
function Observe-RejectImages($row){
 if(-not$row.Contains('observerFinal')){return @{status='UNKNOWN_NO_OBSERVER_FINAL';allCapturedImagesKnownAbsent=$false;images=@();mutations=$false}}
 $paths=@();foreach($p in @($row.observerFinal.Processes|Select-Object -ExpandProperty Image -Unique)){$paths+=,(Known-Path $p)}
 $all=($paths.Count-gt0 -and @($paths|Where-Object{$_.status-cne'KNOWN_ABSENT'}).Count-eq0)
 return @{status=$(if($all){'PASS_CAPTURED_REJECT_IMAGE_AUTOMATIC_ABSENCE'}else{'UNKNOWN_OR_PRESENT'});allCapturedImagesKnownAbsent=$all;images=$paths;brokerImageKnownAbsent=$null;noBrokerEverCreated='NOT_CLAIMED';mutations=$false}
}
function Assert-ControlStateUnchanged($before,$after){
 foreach($part in @('registration','markers','components','run')){
  $a=$before.observations.$part|ConvertTo-Json -Depth 18 -Compress;$b=$after.observations.$part|ConvertTo-Json -Depth 18 -Compress
  Require ($null-ne$before.observations.$part -and $null-ne$after.observations.$part -and $a-ceq$b) ('UNCHANGED_CONTROL_STATE_'+$part.ToUpperInvariant())
 }
}
function Invoke-Negative([string]$kind){
 Require ((Remaining)-gt180000 -and -not$script:ownerUnknown -and -not$script:instrumentUnknown -and $null-eq$script:activeMutation) 'NO_NEGATIVE_MUTATION_WITHOUT_ORIGINAL_RETURN_AND_RESERVE'
 $base=Measure-State 'Present';Assert-State $base 'Present';Require ((Coordination).pendingKnownAbsent) 'BEFORE_NEGATIVE_PENDING_ABSENT'
 $payload=@($script:c.payloads|Where-Object{$_.path-ceq'web/index.html'});Require ($payload.Count-eq1) 'ONE_FIXED_NONEXECUTABLE_RESOURCE'
 $case=[ordered]@{kind=$kind;status='FAIL_NOT_COMPLETE';beforeHealthy=$base;mutation=$null;rejection=$null;fixtureRestoration='NOT_RUN';scope='Synthetic owned payload change and restoration only; no claim of MSI damaged repair or transaction rollback'}
 $script:resultMutations+=,$case;$script:result['negativeCases']=$script:resultMutations
 $script:activeMutation=[FcR79PayloadFixture]::Capture($ScratchRoot,$script:c.runtimeNonce,$kind,[int]$payload[0].size,$payload[0].sha256)
 $case.mutation=Copy-Fact $script:activeMutation;New-Json (Join-Path $ScratchRoot ($kind.ToLowerInvariant()+'-mutation-captured.json')) $case.mutation
 [FcR79PayloadFixture]::Apply($script:activeMutation);$case.mutation=Copy-Fact $script:activeMutation
 New-Json (Join-Path $ScratchRoot ($kind.ToLowerInvariant()+'-mutation-applied.json')) $case.mutation
 $damaged=Measure-State 'Present';$case['beforeRejectedState']=$damaged;Require (-not$damaged.healthyPresent -and $damaged.stateClassification-ceq'UNKNOWN_OR_MISMATCH') 'ACTUAL_DAMAGED_PREIMAGE_REQUIRED';Assert-ControlStateUnchanged $base $damaged
 $phase=Invoke-Phase ($kind.ToLowerInvariant()+'-reject') 'Reject' 180000;$case.rejection=$phase
 Require (-not$script:ownerUnknown -and -not$script:instrumentUnknown -and $phase.client.actualExit -and $phase.client.pipesComplete -and -not$phase.client.timedOut -and $phase.client.exitCode-eq1603 -and $phase.ownerProof.complete) 'EXPECTED_REAL_CLIENT_BEGIN_REJECTION_NOT_PROVEN'
 Require ($phase.helperImageCleanup.status-ceq'PASS_CAPTURED_REJECT_IMAGE_AUTOMATIC_ABSENCE') 'NEGATIVE_HELPER_IMAGE_NOT_ABSENT'
 Require ((Coordination).pendingKnownAbsent) 'AFTER_REJECTION_PENDING_NOT_KNOWN_ABSENT'
 [FcR79PayloadFixture]::CheckPreserved($script:activeMutation)
 $after=Measure-State 'Present';$case['afterRejectedState']=$after;Require (-not$after.healthyPresent -and $after.stateClassification-ceq'UNKNOWN_OR_MISMATCH') 'REJECTION_DID_NOT_PRESERVE_DAMAGED_CLASSIFICATION';Assert-ControlStateUnchanged $base $after
 Require ((Remaining)-gt180000) 'RESTORATION_AND_UNINSTALL_RESERVE_REQUIRED'
 [FcR79PayloadFixture]::Restore($script:activeMutation);$case.mutation=Copy-Fact $script:activeMutation
 $healthy=Measure-State 'Present';$case['afterFixtureRestore']=$healthy;Assert-State $healthy 'Present';Assert-ControlStateUnchanged $base $healthy
 $case.fixtureRestoration='EXACT_OWNED_FIXTURE_RESTORED_NOT_MSI_REPAIR';$case.status='PASS_EXPECTED_REJECTION_AND_PRESERVED_PREIMAGE_WITH_EXACT_FIXTURE_RESTORE'
 New-Json (Join-Path $ScratchRoot ($kind.ToLowerInvariant()+'-negative-result.json')) $case;$script:activeMutation=$null
}
function Invoke-Phase([string]$name,[ValidateSet('Fresh','Reapply','Reject','Uninstall')][string]$kind,[int]$reserve){
 $budget=[int][Math]::Min(150000,[Math]::Max(0,(Remaining)-$reserve))
 Require ($budget-gt0) 'ORIGINAL_WHOLE_AND_CLEANUP_RESERVE_EXHAUSTED'
 $deadline=$whole.ElapsedMilliseconds+$budget
 $row=[ordered]@{name=$name;kind=$kind;startWholeMilliseconds=$whole.ElapsedMilliseconds;phaseDeadlineWholeMilliseconds=$deadline;phaseBudgetMilliseconds=$budget;nativeBrokerOriginalSeconds=120;client=@{started=$false;actualExit=$false;pipesComplete=$false;timedOut=$false;exitCode=$null};ownerProof=@{complete=$false;knownControlsReturned=$false;coverageProblems=@('NOT_CAPTURED');returnProblems=@('NOT_CAPTURED');brokerEverObservedWait258=$false};engineEvidence='UNKNOWN_NO_INDEPENDENT_EXPLICIT_ENGINE_RESULT_PARSER';observations='NOT_COMPLETE'}
 $script:result.phases+=,$row;$priorOwnerUnknown=$script:ownerUnknown;$script:ownerUnknown=$true
 $observer=$null;$client=$null;$out=$null;$err=$null;$snap=$null;$closed=$null;$live=@{};$lastText=$null
 $snapshotPath=Join-Path $ScratchRoot ($name+'-original-observer.jsonl')
 $snapshotFile=[IO.File]::Open($snapshotPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
 function Save-Snapshot($value){
  # C# Facts refer to live records; serialize immediately, never retain aliases.
  $text=$value|ConvertTo-Json -Depth 18 -Compress
  if($text-cne$script:phaseLastSnapshot){$bytes=[Text.UTF8Encoding]::new($false).GetBytes($text+"`n");Require ($snapshotFile.Length+$bytes.Length-le16777216) 'SNAPSHOT_LOG_BOUND';$snapshotFile.Write($bytes,0,$bytes.Length);$snapshotFile.Flush();$script:phaseLastSnapshot=$text}
  foreach($fact in @($value.Processes)){if($fact.Role-ceq'broker' -and $fact.ActualWait-eq258){$live[([string]$fact.Pid)+':'+([string]$fact.CreationFiletime)]=$true}}
  return ($text|ConvertFrom-Json)
 }
 $script:phaseLastSnapshot=$null
 try{
  $left=[int][Math]::Min(150000,$deadline-$whole.ElapsedMilliseconds);Require ($left-gt0) 'PHASE_EXPIRED_BEFORE_OBSERVER'
  $observer=[FcR78ProcessObserver]::new($script:c.embeddedHelper.sha256,[int]$script:c.embeddedHelper.bytes,$script:c.expectedUserSid,$left)
  $log=Join-Path $ScratchRoot ($name+'-msi.log');Require (-not(Test-Path -LiteralPath $log)) 'EXCLUSIVE_MSI_LOG'
  $tail=' /qn /norestart REBOOT=ReallySuppress MSIRESTARTMANAGERCONTROL=DisableShutdown /L*vx '+(Quote $log)
  $arguments=if($kind-ceq'Uninstall'){'/x '+$script:productArgument+$tail}elseif($kind-in@('Reapply','Reject')){'/i '+(Quote $script:msiPath)+' REINSTALL=ALL REINSTALLMODE=amus'+$tail}else{'/i '+(Quote $script:msiPath)+$tail}
  $client=[Diagnostics.Process]::new();$client.StartInfo.FileName=$script:msiexec;$client.StartInfo.Arguments=$arguments;$client.StartInfo.WorkingDirectory=$ScratchRoot
  $client.StartInfo.UseShellExecute=$false;$client.StartInfo.CreateNoWindow=$true;$client.StartInfo.RedirectStandardInput=$true;$client.StartInfo.RedirectStandardOutput=$true;$client.StartInfo.RedirectStandardError=$true
  $out=[IO.File]::Open((Join-Path $ScratchRoot ($name+'-client.stdout.log')),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
  $err=[IO.File]::Open((Join-Path $ScratchRoot ($name+'-client.stderr.log')),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
  Require ($whole.ElapsedMilliseconds-lt$deadline -and (Remaining)-gt$reserve) 'ORIGINAL_DEADLINE_BEFORE_START'
  if($kind-ceq'Fresh'){$script:installAttempted=$true}
  Require ($client.Start()) 'CLIENT_START_FALSE';$row.client.started=$true;$client.StandardInput.Close()
  $row.client['pid']=$client.Id;$row.client['creationFiletime']=$client.StartTime.ToUniversalTime().ToFileTimeUtc();$row.client['file']=$script:msiexec;$row.client['arguments']=$arguments;$row['rawMsiLog']=$log
  $ot=$client.StandardOutput.BaseStream.CopyToAsync($out);$et=$client.StandardError.BaseStream.CopyToAsync($err)
  while($whole.ElapsedMilliseconds-lt$deadline -and (Remaining)-gt$reserve){
   $snap=Save-Snapshot ($observer.Snapshot())
   $row.client.actualExit=$client.HasExited
   if($row.client.actualExit){$row.client.exitCode=$client.ExitCode;if(($kind-ceq'Reject' -and @($snap.Processes).Count-gt0 -and @($snap.Processes|Where-Object{$_.ActualWait-ne0}).Count-eq0) -or ($kind-cne'Reject' -and @($snap.Processes|Where-Object{$_.Role-ceq'broker'}).Count-eq1 -and @($snap.Processes|Where-Object{$_.ActualWait-ne0}).Count-eq0)){break}}
   Start-Sleep -Milliseconds 10
  }
  $row.client.actualExit=$client.HasExited
  if($row.client.actualExit){$row.client.exitCode=$client.ExitCode}else{$row.client.timedOut=$true;$script:retainedClients.Add($client);$client=$null}
  $wait=[int][Math]::Max(0,[Math]::Min(2000,$deadline-$whole.ElapsedMilliseconds))
  $row.client.pipesComplete=[Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($ot,$et),$wait)
 }catch{$row['phaseFailureType']=$_.Exception.GetType().FullName;$row['phaseFailureCode']=$(if($_.Exception.Message-cmatch'^[A-Z0-9_]+$'){$_.Exception.Message}else{'PHASE_NATIVE_OR_CLIENT_ERROR'})}
 finally{
  if($null-ne$observer){try{$closed=Save-Snapshot ($observer.FinishAndClose());$row['observerFinal']=$closed;$row.ownerProof=$(if($kind-ceq'Reject'){Reject-Proof $closed}else{Owner-Proof $closed $live})}catch{$script:instrumentUnknown=$true;$row['observerFinishFailure']='UNKNOWN_ORIGINAL_OBSERVER_RETURN_NO_RETRY'}}
  if($null-ne$client){if(-not$row.client.started){$client.Dispose()}else{try{if(-not $client.HasExited){$script:retainedClients.Add($client);$client=$null}else{$client.Dispose()}}catch{$script:instrumentUnknown=$true;$script:retainedClients.Add($client);$client=$null}}}
  foreach($s in @($out,$err,$snapshotFile)){if($null-ne$s){$s.Dispose()}}
  $row['helperImageCleanup']=$(if($kind-ceq'Reject'){Observe-RejectImages $row}else{Observe-PhaseImages $row})
  $row['endWholeMilliseconds']=$whole.ElapsedMilliseconds;$row['snapshotLog']=$snapshotPath
  $script:ownerUnknown=(-not($row.client.started -and $row.client.actualExit -and $row.client.pipesComplete -and -not$row.client.timedOut -and $row.ownerProof.knownControlsReturned))
  if(-not$row.client.started -and -not$script:instrumentUnknown){$script:ownerUnknown=$priorOwnerUnknown;$row['noClientStartedProductOwnerScope']='NO_NEW_MSI_CLIENT_STARTED_PRIOR_OWNER_FACTS_PRESERVED_NOT_A_PHASE_PASS'}
  New-Json (Join-Path $ScratchRoot ($name+'-phase.json')) $row
 }
 return $row
}
function Require-ReturnedControls($row){Require (-not$script:ownerUnknown -and -not$script:instrumentUnknown -and $row.client.exitCode-eq0) 'PHASE_ORIGINAL_CLIENT_OWNER_RETURN_INCOMPLETE'}
function Require-Phase($row){Require-ReturnedControls $row;Require $row.ownerProof.complete 'PHASE_INDEPENDENT_ROLE_COVERAGE_UNKNOWN';Require ($row.helperImageCleanup.status-ceq'PASS_PRECISE_HELPER_IMAGE_AUTOMATIC_ABSENCE') 'PRODUCT_HELPER_IMAGE_AUTOMATIC_RETIREMENT_NOT_PROVEN'}
function Capture-Gate {
 try{$script:gateSnapshot=[FcR76GateRetirement]::Capture($script:c.expectedUserSid);$script:result['originalGateFacts']=@($script:gateSnapshot.Facts())}
 catch{$script:instrumentUnknown=$true;throw}
}
function Retire-Gate {
 Require (-not$script:ownerUnknown -and -not$script:instrumentUnknown -and $null-ne$script:gateSnapshot -and -not$script:retireAttempted -and (Remaining)-gt0) 'NO_ORIGINAL_GATE_RETIREMENT_AUTHORITY'
 $coord=Coordination;Require $coord.pendingKnownAbsent 'PENDING_NOT_KNOWN_ABSENT'
 $script:retireAttempted=$true
 try{$script:result['gateRetirementNative']=[FcR76GateRetirement]::Retire($script:gateSnapshot)}catch{$script:instrumentUnknown=$true;throw}
 $after=Coordination;$script:result['gateRetirementExternalReadback']=$after
 Require ($after.namespaceKnownAbsent -and $after.pendingKnownAbsent) 'EXTERNAL_GATE_NAMESPACE_ABSENCE_NOT_PROVEN'
}
$ready=$false;$mainSucceeded=$false;$scratchAdmitted=$false
try{
 Require ([Environment]::Is64BitProcess -and $PSVersionTable.PSVersion.Major-eq5 -and $PSVersionTable.PSVersion.Minor-eq1) 'EXPECTED_FRESH_X64_PS51'
 Require ($ExpectedConfigSha256-cmatch'^[0-9a-f]{64}$' -and $ExpectedInputsManifestSha256-cmatch'^[0-9a-f]{64}$') 'EXPLICIT_ROOT_INPUT_HASHES'
 Require ($ScratchRoot-ceq[IO.Path]::GetFullPath($ScratchRoot)) 'EXACT_SCRATCH_PATH'
 $cursor=$ScratchRoot;while($cursor){$fact=Known-Path $cursor;Require ($fact.status-ceq'KNOWN_PRESENT' -and $fact.directory -and -not$fact.reparse) 'SCRATCH_ANCESTOR_UNKNOWN_OR_REPARSE';$cursor=[IO.Path]::GetDirectoryName($cursor)}
 foreach($name in @('.owner','candidate-inputs.json','runtime-inputs.json')){$f=Get-Item -LiteralPath (Join-Path $ScratchRoot $name) -Force;Require (-not$f.PSIsContainer -and -not($f.Attributes-band[IO.FileAttributes]::ReparsePoint)) 'REGULAR_ROOT_METADATA_NO_REPARSE'}
 Require ([IO.File]::ReadAllText((Join-Path $ScratchRoot '.owner'))-ceq"future-classroom-owned-r79-production-msi-runtime/v1`n") 'EXACT_RUNTIME_OWNER'
 $configPath=Join-Path $ScratchRoot 'candidate-inputs.json';$manifestPath=Join-Path $ScratchRoot 'runtime-inputs.json'
 Require ((Digest $configPath)-ceq$ExpectedConfigSha256 -and (Digest $manifestPath)-ceq$ExpectedInputsManifestSha256) 'EXACT_CONFIG_MANIFEST_BYTES'
 $script:c=Get-Content -LiteralPath $configPath -Raw -Encoding UTF8|ConvertFrom-Json
 Require ($script:c.sourceGit-ceq'261c58aca8b0f63ff2cfb4dbd5e85c0d17770005' -and $script:c.target-ceq'i686-win7-windows-msvc' -and $script:c.family-ceq'99378807-098D-5F04-8D4D-F181DFA218D5' -and $script:c.status-ceq'BOUND_PLAN_ONLY_NOT_EXECUTABLE_OR_RUNTIME_PASS') 'CLOSED_SOURCE_TARGET_FAMILY_CONFIG'
 Require ($script:c.runtimeNonce-cmatch'^[0-9a-f]{32}$' -and $script:c.runtimeRootName-ceq('FutureClassroom-r79-production-msi-'+$script:c.runtimeNonce) -and [IO.Path]::GetFileName($ScratchRoot)-ceq$script:c.runtimeRootName) 'EXACT_NONCE_RUNTIME_ROOT'
 Require ($script:c.budget.wholeTestSeconds-eq600 -and $script:c.budget.cleanupReserveSeconds-eq180 -and $script:c.budget.eachMsiClientWaitMaximumSeconds-eq150 -and $script:c.budget.productionBrokerOriginalSeconds-eq120 -and $script:c.budget.noRenewal-eq$true) 'ORIGINAL_BUDGETS_UNCHANGED'
 $who=[Security.Principal.WindowsIdentity]::GetCurrent();try{Require ($who.User.Value-ceq$script:c.expectedUserSid) 'EXACT_CURRENT_USER_SID'}finally{$who.Dispose()}
 $names=@('GateRetirement.cs','ProcessObserver.cs','ReadOnlyPreflightFunction.ps1','ProductState.cs','ProductState.ps1','PayloadFixture.cs','Invoke-ProductionMsiPhases.ps1','candidate-inputs.json','candidate.msi')
 $manifest=Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8|ConvertFrom-Json
 Require (@($manifest.files).Count-eq$names.Count) 'CLOSED_UPLOADED_DEPENDENCIES'
 $seen=@{};foreach($row in $manifest.files){Require ($row.path-cin$names -and -not$seen.ContainsKey($row.path)) 'EXACT_UPLOAD_FILENAME';$seen[$row.path]=$true;$path=Join-Path $ScratchRoot $row.path;$f=Get-Item -LiteralPath $path -Force;Require (-not$f.PSIsContainer -and -not($f.Attributes-band[IO.FileAttributes]::ReparsePoint) -and $f.Length-eq$row.bytes -and (Digest $path)-ceq$row.sha256) 'EXACT_UPLOADED_FILE_BYTES'}
 $fixtureNames=@('GateRetirement.cs','ProcessObserver.cs','ReadOnlyPreflightFunction.ps1','ProductState.cs','ProductState.ps1','PayloadFixture.cs','Invoke-ProductionMsiPhases.ps1')
 Require (@($script:c.fixtureSourceInputs).Count-eq$fixtureNames.Count) 'CLOSED_PLAN_FIXTURE_DEPENDENCIES'
 $fixtureSeen=@{};foreach($source in $script:c.fixtureSourceInputs){$leaf=[IO.Path]::GetFileName($source.path);Require ($leaf-cin$fixtureNames -and -not$fixtureSeen.ContainsKey($leaf)) 'UNIQUE_PLAN_FIXTURE_NAME';$fixtureSeen[$leaf]=$true;$uploaded=@($manifest.files|Where-Object{$_.path-ceq$leaf});Require ($uploaded.Count-eq1 -and $uploaded[0].bytes-eq$source.bytes -and $uploaded[0].sha256-ceq$source.sha256) 'PLAN_FIXTURE_AND_ACTUAL_UPLOAD_EXACT'}
 Require (@(Get-ChildItem -LiteralPath $ScratchRoot -Force).Count-eq($names.Count+2)) 'FRESH_SCRATCH_NO_UNKNOWN_MEMBER'
 $script:msiPath=Join-Path $ScratchRoot 'candidate.msi';Require ((Digest $script:msiPath)-ceq$script:c.msi.sha256 -and (Get-Item -LiteralPath $script:msiPath).Length-eq$script:c.msi.bytes) 'EXACT_ACTUAL_CANDIDATE_MSI'
 Require ($script:c.productCode-cmatch'^(?:[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}|\{[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\})$') 'CANONICAL_BOUND_PRODUCT_CODE';$script:productArgument='{'+$script:c.productCode.Trim('{}')+'}'
 $local=[Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData);Require (-not[string]::IsNullOrEmpty($local)) 'OS_KNOWN_FOLDER_REQUIRED'
 $script:gateRoot=Join-Path $local ('FutureClassroom-Installer-'+$script:c.family)
 $script:msiexec=Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::Windows)) 'System32\msiexec.exe'
 $scratchAdmitted=$true
 . (Join-Path $ScratchRoot 'ReadOnlyPreflightFunction.ps1')
 . (Join-Path $ScratchRoot 'ProductState.ps1')
 $before=Measure-FcBeforePreflight -Config $script:c;$script:result['before']=$before
 Require ($before.status-ceq'PASS_BEFORE_KNOWN_ABSENCE_ONLY_NOT_EXECUTION_ADMISSION') 'BEFORE_ALL_KNOWN_ABSENT_REQUIRED'
 $script:beforeAbsent=$true;$ready=$true
 # Compilation is confined to the original runner process and fresh owned temp.
 $temp=Join-Path $ScratchRoot 'instrument-temp';[void][IO.Directory]::CreateDirectory($temp);$env:TEMP=$temp;$env:TMP=$temp
 Require ($null-eq('FcR78ProcessObserver'-as[type]) -and $null-eq('FcR76GateRetirement'-as[type])) 'FRESH_INSTRUMENT_TYPES_REQUIRED'
 Add-Type -LiteralPath (Join-Path $ScratchRoot 'ProcessObserver.cs') -ReferencedAssemblies @('System.dll','System.Core.dll','System.Management.dll') -ErrorAction Stop
 Add-Type -LiteralPath (Join-Path $ScratchRoot 'GateRetirement.cs') -ErrorAction Stop
 Add-Type -LiteralPath (Join-Path $ScratchRoot 'PayloadFixture.cs') -ErrorAction Stop
 $initial=Measure-State 'Absent';$script:result['initialProductState']=$initial;Assert-State $initial 'Absent';Require ((Coordination).namespaceKnownAbsent) 'BEFORE_COORDINATION_ABSENT'
 $fresh=Invoke-Phase 'fresh' 'Fresh' 180000;Require-Phase $fresh
 $script:result['freshCache']=Observe-Cache $true
 $present=Measure-State 'Present';$script:result['freshPresent']=$present;Assert-State $present 'Present';Require ((Coordination).pendingKnownAbsent) 'FRESH_PENDING_ABSENCE';Capture-Gate
 foreach($kind in @('Missing','Tampered','Extra')){Invoke-Negative $kind}
 $script:formalAttempted=$true;$uninstall=Invoke-Phase 'uninstall' 'Uninstall' 0;Require-Phase $uninstall
 $absent=Measure-State 'Absent';$script:result['uninstallAbsent']=$absent;Assert-State $absent 'Absent'
 $script:result['uninstallCache']=Observe-Cache $false;Require $script:result.uninstallCache.allPreviouslyObservedPathsKnownAbsent 'EXACT_OBSERVED_CACHE_PATHS_NOT_ABSENT';Retire-Gate
 Require ((Remaining)-gt0) 'ORIGINAL_WHOLE_DEADLINE_EXCEEDED';$mainSucceeded=$true;$script:result.status='PASS_FRESH_THREE_DAMAGED_PREIMAGE_REJECTIONS_AND_FORMAL_UNINSTALL_WIN11_ONLY'
}catch{$script:result['failureType']=$_.Exception.GetType().FullName;$script:result['failureCode']=$(if($_.Exception.Message-cmatch'^[A-Z0-9_]+$'){$_.Exception.Message}else{'CONFIG_NATIVE_STATE_OR_PHASE_ERROR'})}
finally{
 if($ready){
  # A real read is mandatory after failure; elapsed time is still the original
  # whole clock. Expiry never grants a new phase or native owner budget.
  try{
   if($null-ne$script:activeMutation){
    Require (-not$script:ownerUnknown -and -not$script:instrumentUnknown -and -not$script:activeMutation.NativeCloseUnknown -and (Coordination).pendingKnownAbsent -and (Remaining)-gt0) 'NO_SAFE_FIXTURE_RESTORE_WITH_UNKNOWN_OWNER_OR_PENDING'
    $actual=Measure-State 'Present'
    if($actual.healthyPresent){$script:result['failureFixtureRestoration']='ALREADY_HEALTHY_READONLY_FACT_NOT_FIXTURE_RESTORE'}elseif($actual.knownAbsent){$script:result['failureFixtureRestoration']='PRODUCT_ALREADY_ABSENT_NO_ORPHAN_PAYLOAD_RECREATED'}else{[FcR79PayloadFixture]::Restore($script:activeMutation);$restored=Measure-State 'Present';Assert-State $restored 'Present';$script:result['failureFixtureRestoration']='EXACT_OWNED_FIXTURE_RESTORED_ONLY'}
    $script:result['failureMutationFinal']=Copy-Fact $script:activeMutation;$script:activeMutation=$null
   }
   $final=Measure-State 'Present';$coord=Coordination;$script:result['finallyProductState']=$final;$script:result['finallyCoordination']=$coord
   if(-not$mainSucceeded -and $script:beforeAbsent -and $script:installAttempted -and -not$script:formalAttempted -and -not$script:ownerUnknown -and -not$script:instrumentUnknown -and $final.healthyPresent-eq$true -and $coord.pendingKnownAbsent -and (Remaining)-gt0){
    if($null-eq$script:gateSnapshot){Capture-Gate}
    $script:formalAttempted=$true;$cleanup=Invoke-Phase 'failure-formal-uninstall' 'Uninstall' 0;Require-ReturnedControls $cleanup
    $after=Measure-State 'Absent';$script:result['failureCleanupAbsent']=$after;Assert-State $after 'Absent'
    $script:result['failureCleanupCache']=Observe-Cache $false
    if($null-ne$script:gateSnapshot -and -not$script:retireAttempted){Retire-Gate}
    $script:result.cleanup='FORMAL_UNINSTALL_RETURNED_ORIGINAL_FAILURE_RETAINED'
   }elseif($mainSucceeded){Require ($final.knownAbsent-eq$true -and $coord.namespaceKnownAbsent -and $coord.pendingKnownAbsent) 'FINAL_EXTERNAL_ABSENCE_RECHECK';$script:result.cleanup='PASS_FORMAL_UNINSTALL_AND_ORIGINAL_GATE_RETIRED'}else{$script:result.cleanup='RETAIN_FAIL_UNKNOWN_OR_NOT_AUTHORIZED_NO_BLIND_CLEANUP'}
  }catch{$mainSucceeded=$false;$script:result.status='FAIL_FINAL_OBSERVATION_OR_CLEANUP';$script:result['finallyFailureType']=$_.Exception.GetType().FullName;$script:result.cleanup='RETAIN_FAIL_CLEANUP_OR_OBSERVATION_UNKNOWN'}
 }
 $script:result['elapsedWholeMilliseconds']=$whole.ElapsedMilliseconds;$script:result['originalBudgetExceeded']=($whole.ElapsedMilliseconds-ge600000);$script:result['ownerUnknown']=$script:ownerUnknown;$script:result['instrumentUnknown']=$script:instrumentUnknown;$script:result['formalUninstallAttempted']=$script:formalAttempted;$script:result['retainedDirectClients']=$script:retainedClients.Count;$script:result['activeMutationRetained']=($null-ne$script:activeMutation)
 if($scratchAdmitted){
  try{New-Json (Join-Path $ScratchRoot 'phase-runner-result.json') $script:result}catch{$mainSucceeded=$false;$script:result.status='FAIL_FINAL_RECEIPT_WRITE';Write-Output 'FINAL_RECEIPT_WRITE_FAILED_NO_CLEANUP_CLAIM'}
 }
}
$script:result|ConvertTo-Json -Depth 18 -Compress
if(-not$mainSucceeded -or $script:result.originalBudgetExceeded){exit 1};exit 0
