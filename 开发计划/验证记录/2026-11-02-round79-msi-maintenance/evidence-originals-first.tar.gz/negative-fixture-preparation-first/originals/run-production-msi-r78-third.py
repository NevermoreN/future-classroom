"""Root-only explicit finite product MSI transport. Default does not connect."""
from pathlib import Path
import argparse,base64,datetime,hashlib,json,subprocess,time,shutil,ast
R=Path('/tmp/fc-round78-ci-evidence')
HOST='elior@192.168.10.212'
KEY='/config/.local/share/future-classroom-test-access/win11-192.168.10.212'
SID='S-1-5-21-3896111207-1867804362-1971593122-1001'
SOURCE='261c58aca8b0f63ff2cfb4dbd5e85c0d17770005'
FILES=[R/'msi-preparation-review-first'/'adapted-third'/n for n in ('ProcessObserver.cs', 'GateRetirement.cs', 'ReadOnlyPreflightFunction.ps1', 'ProductState.cs', 'ProductState.ps1', 'Invoke-ProductionMsiPhases.ps1')]
PINS=['165553f93fc736b6d9ddf5d4daa605420fd2ce2e3d8dc12afaccf80753776cbe', '6384a7e0ab90e91fc3eeed9f0d922fc73f7a1f6d9c70062cf949253265d6cf01', 'b40be44f31562c6c14cfe34053fc0d12158ab7108758a6be3d3bff1cfde738d9', '6045cf06448719bf50a51a1d52fa086e986df7a3a1ba0ed780ba6dc379118623', 'bdbb1f623a9709ec1e128b426ec3fa876423002eabc7e80948203b95f8a57fdf', '442d6be361b362a0886cfca1a9156d630b3a8ec6aec1385a148137ff9f41c659']
BOOT="$ErrorActionPreference='Stop';[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()))"
COMMON='$ErrorActionPreference=\'Stop\';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)\nfunction RootPath {return Join-Path ([IO.Path]::GetFullPath($env:TEMP)) (\'FutureClassroom-r78-production-msi-\'+$c.nonce)}\nfunction Fact($p){$a=[IO.File]::GetAttributes($p);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0 -or ($a-band[IO.FileAttributes]::Directory)-ne0){throw \'REGULAR_NO_REPARSE\'};return @{bytes=[long]([IO.FileInfo]::new($p).Length);sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}\nfunction CheckRoot($root){if($root-cne$c.root -or [IO.Path]::GetFileName($root)-cne(\'FutureClassroom-r78-production-msi-\'+$c.nonce)){throw \'EXACT_ROOT\'};$a=[IO.File]::GetAttributes($root);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0){throw \'ROOT_REPARSE\'};if([IO.File]::ReadAllText((Join-Path $root \'.owner\'))-cne"future-classroom-owned-r78-production-msi-runtime/v1`n"){throw \'OWNER_MARKER\'};$acl=[IO.Directory]::GetAccessControl($root);if(-not$acl.AreAccessRulesProtected -or $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-cne$c.sid){throw \'EXACT_PROTECTED_OWNER\'};$rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));if($rules.Count-ne2 -or @($rules|Where-Object{$_.IdentityReference.Value-notin@($c.sid,\'S-1-5-18\') -or $_.AccessControlType-ne\'Allow\' -or $_.FileSystemRights-ne[Security.AccessControl.FileSystemRights]::FullControl}).Count){throw \'ONLY_USER_SYSTEM_DACL\'}}\nfunction Inventory($root){CheckRoot $root;$files=@();$dirs=@();$q=[Collections.Generic.Queue[string]]::new();$q.Enqueue($root);while($q.Count){$dir=$q.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){$a=[IO.File]::GetAttributes($p);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0){throw \'INVENTORY_REPARSE\'};$rel=$p.Substring($root.Length+1).Replace(\'\\\',\'/\');if(($a-band[IO.FileAttributes]::Directory)-ne0){$dirs+=$rel;$q.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256}};if($files.Count-gt128 -or $dirs.Count-gt16){throw \'INVENTORY_BOUND\'}}};return @{files=$files;directories=$dirs}}\n'
CREATE='if($PSVersionTable.PSVersion.Major-ne5 -or [IntPtr]::Size-ne8){throw \'DESKTOP_PS51_X64_REQUIRED\'};$w=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$w.User;if($sid.Value-cne$c.sid){throw \'EXACT_CURRENT_USER_SID\'}}finally{$w.Dispose()};$before=Measure-FcBeforePreflight -Config $c.plan;if($before.status-cne\'PASS_BEFORE_KNOWN_ABSENCE_ONLY_NOT_EXECUTION_ADMISSION\'){throw \'BEFORE_ALL_KNOWN_ABSENT_REQUIRED\'};$root=RootPath\ntry{[void][IO.File]::GetAttributes($root);throw \'ROOT_ALREADY_EXISTS\'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}\n$cursor=[IO.Path]::GetDirectoryName($root);while($cursor){$a=[IO.File]::GetAttributes($cursor);if(($a-band[IO.FileAttributes]::ReparsePoint)-ne0 -or ($a-band[IO.FileAttributes]::Directory)-eq0){throw \'ANCESTOR_ALIAS\'};$cursor=[IO.Path]::GetDirectoryName($cursor)}\n[void][IO.Directory]::CreateDirectory($root);$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false);foreach($s in @($sid,[Security.Principal.SecurityIdentifier]::new(\'S-1-5-18\'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($s,\'FullControl\',\'ContainerInherit,ObjectInherit\',\'None\',\'Allow\'))};[IO.Directory]::SetAccessControl($root,$acl);[IO.File]::WriteAllText((Join-Path $root \'.owner\'),"future-classroom-owned-r78-production-msi-runtime/v1`n",[Text.UTF8Encoding]::new($false));$c.root=$root;CheckRoot $root\n@{status=\'CREATED_ONLY_OWNED_PRODUCT_RUNTIME_ROOT\';root=$root;sid=$c.sid;nonce=$c.nonce;before=$before;powershell=$PSVersionTable.PSVersion.ToString();localAppData=[Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)}|ConvertTo-Json -Compress\n'
DELETE="CheckRoot $c.root;$now=Inventory $c.root;if($now.files.Count-ne$c.inventory.files.Count -or $now.directories.Count-ne$c.inventory.directories.Count){throw 'MEMBERSHIP_CHANGED'};foreach($row in $now.files){$old=@($c.inventory.files|Where-Object{$_.path-ceq$row.path});if($old.Count-ne1 -or $old[0].bytes-ne$row.bytes -or $old[0].sha256-cne$row.sha256){throw 'ORIGINAL_FILE_BYTES_CHANGED'}};foreach($dir in $now.directories){if($dir-cnotin$c.inventory.directories){throw 'DIRECTORY_CHANGED'}}\nforeach($row in $now.files){if($row.path-cne'.owner'){[IO.File]::Delete((Join-Path $c.root ($row.path.Replace('/','\\'))))}};foreach($dir in @($now.directories|Sort-Object Length -Descending)){[IO.Directory]::Delete((Join-Path $c.root ($dir.Replace('/','\\'))),$false)};[IO.File]::Delete((Join-Path $c.root '.owner'));[IO.Directory]::Delete($c.root,$false)\ntry{[void][IO.File]::GetAttributes($c.root);throw 'ROOT_STILL_EXISTS'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}\n@{status='REMOVED_EXACT_PRODUCT_RUNTIME_ROOT';nonce=$c.nonce;knownAbsent=$true}|ConvertTo-Json -Compress\n"
def need(v,code):
    if not v: raise AssertionError(code)
def sha(b): return hashlib.sha256(b).hexdigest()
def fact(p):
    p=Path(p);need(p.is_file() and not p.is_symlink(),'REGULAR_LOCAL_INPUT')
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def remote(script,c):
    feed=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+COMMON+script).encode()
    return ['ssh','-i',KEY,'-o','BatchMode=yes','-o','ConnectTimeout=8',HOST,'powershell.exe','-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-EncodedCommand',base64.b64encode(BOOT.encode('utf-16-le')).decode()],feed
def phase_cleanup_admission(r):
    if not isinstance(r,dict) or not isinstance(r.get('phases'),list): return 'RETAIN_UNKNOWN'
    phases=r['phases']
    full=(r.get('status')=='PASS_THREE_PHASE_FOUR_ROLE_AUTOMATIC_IMAGE_CLEANUP_AND_ORIGINAL_GATE_WIN11_ONLY' and r.get('cleanup')=='PASS_FORMAL_UNINSTALL_AND_ORIGINAL_GATE_RETIRED' and r.get('ownerUnknown') is False and r.get('instrumentUnknown') is False and r.get('retainedDirectClients')==0 and r.get('formalUninstallAttempted') is True and r.get('originalBudgetExceeded') is False and r.get('finallyProductState',{}).get('knownAbsent') is True and r.get('finallyCoordination',{}).get('namespaceKnownAbsent') is True and r.get('finallyCoordination',{}).get('pendingKnownAbsent') is True and r.get('uninstallCache',{}).get('allPreviouslyObservedPathsKnownAbsent') is True and len(phases)==3 and all(x.get('client',{}).get('started') is True and x.get('client',{}).get('actualExit') is True and x.get('client',{}).get('pipesComplete') is True and x.get('client',{}).get('exitCode')==0 and x.get('ownerProof',{}).get('complete') is True and x.get('helperImageCleanup',{}).get('status')=='PASS_PRECISE_HELPER_IMAGE_AUTOMATIC_ABSENCE' and x.get('helperImageCleanup',{}).get('brokerImageKnownAbsent') is True and x.get('helperImageCleanup',{}).get('allCapturedImagesKnownAbsent') is True for x in phases))
    if full:return 'COMPLETE_PHASE_PASS_ONLY'
    # This path permits only deleting the downloaded owned transport scratch.
    # It grants no product/gate/registry/cache mutation and never rewrites FAIL.
    if all(isinstance(x,dict) and isinstance(x.get('client'),dict) and x['client'].get('started') is False for x in phases):return 'NO_MSI_CLIENT_STARTED_PARENT_RETURNED_ONLY'
    return 'RETAIN_UNKNOWN'
def validate_inventory(v):
    need(isinstance(v,dict) and isinstance(v.get('files'),list) and isinstance(v.get('directories'),list),'EXACT_INVENTORY_SHAPE')
    seen=set()
    for row in v['files']:
        p=row['path'];need(isinstance(p,str) and p and '\\' not in p and not p.startswith('/') and all(x not in ('','.','..') for x in p.split('/')) and ':' not in p and p not in seen,'SAFE_UNIQUE_INVENTORY_PATH');seen.add(p)
        need(isinstance(row['bytes'],int) and row['bytes']>=0 and len(row['sha256'])==64 and all(c in '0123456789abcdef' for c in row['sha256']),'INVENTORY_BYTES_SHA')
    need(len(v['files'])<=128 and len(v['directories'])<=16 and len(set(v['directories']))==len(v['directories']),'ORIGINAL_INVENTORY_BOUNDS')
    for p in v['directories']:need(isinstance(p,str) and p and '\\' not in p and not p.startswith('/') and ':' not in p and all(x not in ('','.','..') for x in p.split('/')) and p not in seen,'SAFE_INVENTORY_DIRECTORY')
def verify_download(root,inventory):
    validate_inventory(inventory);have={};dirs=[]
    for p in root.rglob('*'):
        need(not p.is_symlink(),'LOCAL_CAPTURE_NO_SYMLINK')
        rel=p.relative_to(root).as_posix()
        if p.is_dir():dirs.append(rel)
        else:
            f=fact(p);have[rel]=dict(path=rel,bytes=f['bytes'],sha256=f['sha256'])
    need(have=={x['path']:x for x in inventory['files']} and set(dirs)==set(inventory['directories']),'DOWNLOAD_EXACT_REMOTE_INVENTORY')
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');ap.add_argument('--config');ap.add_argument('--config-sha256');ap.add_argument('--report');a=ap.parse_args()
    if not a.execute:print(json.dumps(dict(status='PREPARED_PRODUCT_TRANSPORT_NOT_RUN',windows='NOT_RUN',msi='NOT_RUN')));return 0
    need(a.config and a.config_sha256 and a.report,'EXPLICIT_ROOT_CONFIG_SHA_REPORT')
    need((R/'.owner').read_bytes()==b'future-classroom-owned-r78-ci-evidence/v1\n','OWNED_R78_ROOT')
    config=Path(a.config);need(config.is_absolute() and config.resolve().is_relative_to(R),'CONFIG_INSIDE_OWNED_R78');config_fact=fact(config);need(config_fact['sha256']==a.config_sha256,'CONFIG_EXACT_SHA')
    plan=json.loads(config.read_text());need(plan['status']=='BOUND_PLAN_ONLY_NOT_EXECUTABLE_OR_RUNTIME_PASS' and plan['sourceGit']==SOURCE and plan['target']=='i686-win7-windows-msvc' and plan['expectedUserSid']==SID and plan['family']=='99378807-098D-5F04-8D4D-F181DFA218D5','CLOSED_SOURCE_TARGET_USER_FAMILY')
    nonce=plan['runtimeNonce'];need(len(nonce)==32 and all(c in '0123456789abcdef' for c in nonce) and plan['runtimeRootName']=='FutureClassroom-r78-production-msi-'+nonce,'CLOSED_NONCE')
    need(plan['budget']==dict(wholeTestSeconds=600,cleanupReserveSeconds=180,eachMsiClientWaitMaximumSeconds=150,productionBrokerOriginalSeconds=120,noRenewal=True),'UNCHANGED_PHASE_BUDGET')
    sources=[fact(p) for p in FILES];need([x['sha256'] for x in sources]==PINS,'EXACT_ACCEPTED_SIX_SOURCES')
    binder=R/'msi-preparation-review-first/bind-production-msi-r78-third.py'
    need(fact(binder)['sha256']=='fdf2883efd291d0e5b01565b70970e59c42ff667f4130d007721382f305f07ec' and plan.get('planBinder')==fact(binder),'EXACT_REVIEWED_PLAN_BINDER')
    import runpy
    runpy.run_path(str(binder),run_name='r78_transport_readonly_binding')['validate_bound_plan'](plan)
    need(plan.get('fixtureSourceInputs')==sources and plan.get('fixtureTransport')==fact(Path(__file__).resolve()),'EXACT_PLAN_AND_TRANSPORT_ALL_SOURCE_CLOSURE')

    msi=Path(plan['msi']['path']);need(msi.is_absolute() and msi.resolve().is_relative_to(R),'MSI_INSIDE_OWNED_R78');mf=fact(msi);need(mf['bytes']==plan['msi']['bytes'] and mf['sha256']==plan['msi']['sha256'],'ACTUAL_MSI_PIN')
    report=Path(a.report);D=report.parent;need(report.is_absolute() and D==D.resolve() and D.parent==R and D.name not in ('tools','production-msi-transport-preparation-first') and not D.exists() and report.name.endswith('.json'),'NEW_LOCAL_DIRECT_R78_RESULT_ROOT')
    D.mkdir();(D/'.owner').write_text('future-classroom-owned-r78-production-msi-transport-result/v1\n')
    upload=D/'upload';upload.mkdir()
    for p in FILES:shutil.copyfile(p,upload/p.name)
    shutil.copyfile(config,upload/'candidate-inputs.json');shutil.copyfile(msi,upload/'candidate.msi')
    members=[dict(path=p.name,bytes=fact(p)['bytes'],sha256=fact(p)['sha256']) for p in sorted(upload.iterdir())]
    need(len(members)==8,'CLOSED_EIGHT_UPLOADS')
    manifest=upload/'runtime-inputs.json';manifest.write_text(json.dumps(dict(files=members),indent=2)+'\n');manifest_fact=fact(manifest)
    c=dict(nonce=nonce,sid=SID,root=None,plan=plan)
    result=dict(status='RUNNING',scope='Authorized Win11 exact current-user source261c58 Win7-target product MSI finite lifecycle only',originalOuterSeconds=900,phaseWholeSeconds=600,nativeBrokerOriginalSeconds=120,sourceInputs=sources,config=config_fact,msi=mf,manifest=manifest_fact,operations=[],cleanup='NOT_RUN',startedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    start=time.monotonic();created=False;run_returned=False;phase=None;inventory=None;download_ok=False
    def save():report.write_text(json.dumps(result,indent=2)+'\n')
    def call(name,cmd,feed=None,limit=15):
        remaining=900-(time.monotonic()-start);need(remaining>0,'ORIGINAL_OUTER_BUDGET_EXHAUSTED');begin=time.monotonic()
        out=b'';err=b'';p=None;timed=False;code=None
        try:
            p=subprocess.Popen(cmd,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            try:out,err=p.communicate(feed,timeout=min(limit,remaining))
            except subprocess.TimeoutExpired:
                timed=True;p.kill();out,err=p.communicate() # local ssh/scp only; remote state remains UNKNOWN
            except BaseException:
                if p.poll() is None:p.kill()
                out,err=p.communicate();code=p.returncode
                raise
            code=p.returncode
        finally:
            row=dict(name=name,command=cmd,pid=p.pid if p else None,actualExit=code is not None,exitCode=code,timedOut=timed,reaped=bool(p and p.poll() is not None),elapsedSeconds=time.monotonic()-begin)
            if feed is not None:row['stdin']=dict(bytes=len(feed),sha256=sha(feed))
            for label,b in [('stdout',out),('stderr',err)]:
                dest=D/(name+'.'+label+'.log');dest.write_bytes(b);row[label]=fact(dest)
            result['operations'].append(row);save()
        return code,out,not timed and code is not None
    save()
    try:
        preflight=FILES[2].read_text()
        cmd,feed=remote(preflight+'\n'+CREATE,c);code,out,natural=call('01-before-create',cmd,feed,15);need(natural and code==0,'BEFORE_CREATE_ACTUAL_EXIT0')
        before=json.loads(out);need(before['sid']==SID and before['nonce']==nonce and before['status']=='CREATED_ONLY_OWNED_PRODUCT_RUNTIME_ROOT' and before['before']['status']=='PASS_BEFORE_KNOWN_ABSENCE_ONLY_NOT_EXECUTION_ADMISSION','ACTUAL_BEFORE_ABSENT_AND_OWNED_CREATE')
        c['root']=before['root'];created=True;result['beforeCreate']=before
        cmd=['scp','-q','-i',KEY,'-o','BatchMode=yes','-o','ConnectTimeout=8',*[str(p) for p in sorted(upload.iterdir())],HOST+':'+c['root'].replace('\\','/')+'/']
        code,_,natural=call('02-upload-binary-originals',cmd,limit=60);need(natural and code==0,'ACTUAL_BINARY_UPLOAD_EXIT0')
        run="CheckRoot $c.root;& (Join-Path $c.root 'Invoke-ProductionMsiPhases.ps1') -Execute -ScratchRoot $c.root -ExpectedConfigSha256 '"+config_fact['sha256']+"' -ExpectedInputsManifestSha256 '"+manifest_fact['sha256']+"'"
        cmd,feed=remote(run,c);code,out,natural=call('03-original-phase-parent',cmd,feed,620);run_returned=natural;need(natural and code in (0,1),'ORIGINAL_PHASE_PARENT_UNKNOWN_OR_ABNORMAL_EXIT')
        phase=json.loads(out);result['phaseResult']=phase;result['phaseParentExit']=code
        admission=phase_cleanup_admission(phase);result['scratchDeleteAdmission']=admission
        result['status']='PASS_PRODUCT_PHASE_RUNTIME_PENDING_CAPTURE' if code==0 and admission=='COMPLETE_PHASE_PASS_ONLY' else 'FAIL_PRODUCT_PHASE_OR_COVERAGE_RETAINED'
    except Exception as e:result.update(status='FAIL_PRODUCT_TRANSPORT_OR_PHASE',failureKind=type(e).__name__,reason=str(e) if isinstance(e,AssertionError) else 'INPUT_TRANSPORT_OR_JSON_CAPTURE_ERROR')
    finally:
        # Never query/delete after a timed-out original phase SSH parent: its
        # remote process may still be live. Root must resolve that uncertainty.
        if created and run_returned:
            try:
                capture_begin=time.monotonic()
                cmd,feed=remote('Inventory $c.root|ConvertTo-Json -Depth 8 -Compress',c);code,out,natural=call('90-post-parent-exact-inventory',cmd,feed,15);need(natural and code==0,'POST_PARENT_INVENTORY_EXIT0');inventory=json.loads(out);validate_inventory(inventory);result['remoteInventory']=inventory
                download=D/'download';download.mkdir()
                cap_remaining=60-(time.monotonic()-capture_begin);need(cap_remaining>0,'ORIGINAL_CAPTURE_DOWNLOAD_BUDGET')
                cmd=['scp','-q','-r','-i',KEY,'-o','BatchMode=yes','-o','ConnectTimeout=8',HOST+':'+c['root'].replace('\\','/'),str(download)+'/']
                code,_,natural=call('91-download-original-root',cmd,limit=cap_remaining);need(natural and code==0,'DOWNLOAD_ORIGINALS_EXIT0')
                local=download/plan['runtimeRootName'];verify_download(local,inventory);download_ok=True;result['downloadVerified']='EXACT_EACH_REMOTE_FILE_SIZE_SHA_AND_MEMBERSHIP'
                have={x['path']:x for x in inventory['files']}
                for row in members+[dict(path='runtime-inputs.json',bytes=manifest_fact['bytes'],sha256=manifest_fact['sha256'])]:need(have.get(row['path'])==row,'ORIGINAL_UPLOADED_BYTES_UNCHANGED')
                stored=json.loads((local/'phase-runner-result.json').read_text());need(stored==phase,'DOWNLOADED_NATIVE_RECEIPT_EQUALS_ORIGINAL_STDOUT')
                need(sources==[fact(p) for p in FILES] and config_fact==fact(config) and mf==fact(msi),'ORIGINAL_LOCAL_INPUTS_UNCHANGED_BEFORE_DELETE')
                admission=phase_cleanup_admission(phase)
                if admission!='RETAIN_UNKNOWN':
                    cmd,feed=remote(DELETE,dict(c,inventory=inventory));code,out,natural=call('99-exact-scratch-delete',cmd,feed,20);clean=json.loads(out);need(natural and code==0 and clean['knownAbsent'] is True and clean['nonce']==nonce,'EXACT_DOWNLOADED_SCRATCH_REMOVED');result['cleanup']='PASS_EXACT_DOWNLOADED_OWNED_SCRATCH_ONLY';result['cleanupActual']=clean
                else:result['cleanup']='RETAIN_LIVE_PENDING_UNKNOWN_INSTALLATION_OR_INCOMPLETE_PROOF'
            except Exception as e:result.update(cleanup='FAIL_OR_UNKNOWN_RETAINED',captureOrCleanupError=type(e).__name__,captureOrCleanupCode=str(e) if isinstance(e,AssertionError) else 'CAPTURE_OR_CLEANUP_ERROR')
        elif created:result['cleanup']='RETAIN_REMOTE_PARENT_NOT_PROVEN_RETURNED_OR_PHASE_NOT_STARTED'
        try:need(sources==[fact(p) for p in FILES] and config_fact==fact(config) and mf==fact(msi),'ORIGINAL_LOCAL_INPUTS_UNCHANGED');result['sourceUnchanged']=True
        except Exception:result['sourceUnchanged']=False;result['status']='FAIL_LOCAL_INPUT_CHANGE'
        result['elapsedSeconds']=time.monotonic()-start;result['controllerReturned']=True
        if result['status']=='PASS_PRODUCT_PHASE_RUNTIME_PENDING_CAPTURE' and download_ok and result['cleanup']=='PASS_EXACT_DOWNLOADED_OWNED_SCRATCH_ONLY' and result['sourceUnchanged'] and result['elapsedSeconds']<900:result['status']='PASS_PRODUCT_MSI_RUNTIME_CAPTURE_AND_EXACT_SCRATCH_CLEANUP_WIN11_ONLY'
        elif result['status']=='PASS_PRODUCT_PHASE_RUNTIME_PENDING_CAPTURE':result['status']='FAIL_CAPTURE_OR_FINAL_CLEANUP'
        save()
    print(json.dumps(dict(status=result['status'],cleanup=result['cleanup'],report=fact(report))))
    return 0 if result['status']=='PASS_PRODUCT_MSI_RUNTIME_CAPTURE_AND_EXACT_SCRATCH_CLEANUP_WIN11_ONLY' else 1
if __name__=='__main__':raise SystemExit(main())
