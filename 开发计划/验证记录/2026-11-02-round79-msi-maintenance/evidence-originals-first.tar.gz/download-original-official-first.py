"""Download exact official artifact bytes without persisting redirects or credentials."""
from pathlib import Path
import argparse, hashlib, json, subprocess, time, urllib.error, urllib.parse, urllib.request, zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--execute', action='store_true')
parser.add_argument('--baseline', choices=['modern','win7'], required=True)
parser.add_argument('--run-id', type=int, required=True)
parser.add_argument('--source-sha', required=True)
parser.add_argument('--artifact-id', type=int, required=True)
parser.add_argument('--expected-bytes', type=int, required=True)
parser.add_argument('--expected-sha256', required=True)
args = parser.parse_args()
if not args.execute:
    print(json.dumps(dict(status='NOT_RUN_PREPARATION_ONLY',sourceSha=args.source_sha,runId=args.run_id,artifactId=args.artifact_id)));raise SystemExit(0)
root = Path(__file__).resolve().parent
assert (root/'.owner').read_bytes()==b'future-classroom-owned-r79-msi-maintenance/v1\n'
assert len(args.source_sha)==40 and all(c in '0123456789abcdef' for c in args.source_sha)
assert args.baseline=='win7' and args.run_id==41332469102 and args.artifact_id==13094372286 and args.source_sha=='261c58aca8b0f63ff2cfb4dbd5e85c0d17770005'
a=json.loads((root/'win7-artifacts-fresh-first.json').read_text())['artifacts']; assert len(a)==1
a=a[0];assert a['id']==args.artifact_id and a['expired'] is False and a['size_in_bytes']==args.expected_bytes and a['digest']=='sha256:'+args.expected_sha256 and a['workflow_run']['id']==args.run_id and a['workflow_run']['head_sha']==args.source_sha
jobs=json.loads((root/'win7-jobs-fresh-first.json').read_text())['jobs'];assert len(jobs)==1 and jobs[0]['run_id']==args.run_id and jobs[0]['status']=='completed' and jobs[0]['conclusion']=='success' and all(x['conclusion']=='success' and x['status']=='completed' for x in jobs[0]['steps'])
dest = root / (args.baseline+'-official-first.zip')
out = root / (args.baseline+'-download-original-official-first.json')
assert not out.exists() and not dest.exists()
assert 0 < args.expected_bytes <= 512*1024*1024
assert len(args.expected_sha256)==64 and all(c in '0123456789abcdef' for c in args.expected_sha256)
r = {'status':'RUNNING','scope':'Exact bytes from official artifact API; Root must first retain matching completed-success run and official artifact ID/bytes/digest metadata through GitHub plugin read APIs; this prepared fallback performs only the exact official byte transfer. Connected artifact tool returned a file reference that is not directly available to the local shell; that original tool response is preserved separately. This exact official API transfer is a separately bounded attempt. Redirect URL and credentials stay only in memory. No product/test executable is run.', 'runId':args.run_id,'sourceSha':args.source_sha,'artifactId':args.artifact_id,'expectedBytes':args.expected_bytes,'expectedSha256':args.expected_sha256,'overallBudgetSeconds':1200,'socketTimeoutSeconds':25}
def save(): out.write_text(json.dumps(r,indent=2)+'\n')
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*a,**kw): return None
save(); started=time.monotonic(); count=0; h=hashlib.sha256()
try:
    cred=subprocess.run(['git','credential','fill'],input=b'protocol=https\nhost=github.com\n\n',capture_output=True,timeout=15,check=True)
    values=dict(line.split('=',1) for line in cred.stdout.decode().splitlines() if '=' in line)
    token=values.get('password');assert token
    req=urllib.request.Request('https://api.github.com/repos/NevermoreN/future-classroom/actions/artifacts/'+str(args.artifact_id)+'/zip',headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2026-03-10','User-Agent':'FutureClassroom-validation'})
    try:
        response=urllib.request.build_opener(NoRedirect).open(req,timeout=25)
    except urllib.error.HTTPError as error:
        assert error.code==302
        location=error.headers.get('Location'); parts=urllib.parse.urlsplit(location)
        assert parts.scheme=='https' and not parts.username and not parts.password and not parts.fragment and parts.port in (None,443) and parts.hostname and (parts.hostname.endswith('.blob.core.windows.net') or parts.hostname.endswith('.actions.githubusercontent.com'))
        r['officialRedirectStatus']=302;save()
        # Never forward the GitHub credential to a redirect host.
        response=urllib.request.build_opener(NoRedirect).open(urllib.request.Request(location,headers={'Accept-Encoding':'identity'}),timeout=25)
    with response,dest.open('xb') as stream:
        assert response.status==200
        if response.headers.get('Content-Length'): assert int(response.headers['Content-Length'])==args.expected_bytes
        while True:
            assert time.monotonic()-started<1200
            data=response.read(min(256*1024,args.expected_bytes-count+1))
            if not data: break
            count+=len(data);assert count<=args.expected_bytes
            stream.write(data);h.update(data)
        assert count==args.expected_bytes and h.hexdigest()==args.expected_sha256
    with zipfile.ZipFile(dest) as z:
        assert z.testzip() is None
        r['zipMemberCount']=len(z.infolist())
    r['status']='PASS'
except Exception as error:
    r['status']='FAIL';r['errorKind']=type(error).__name__
finally:
    r.update(bytes=count,sha256=h.hexdigest(),elapsedSeconds=time.monotonic()-started)
    save()
print(json.dumps({k:r.get(k) for k in ['status','bytes','sha256','elapsedSeconds','errorKind','zipMemberCount']}),flush=True)
raise SystemExit(0 if r['status']=='PASS' else 1)
