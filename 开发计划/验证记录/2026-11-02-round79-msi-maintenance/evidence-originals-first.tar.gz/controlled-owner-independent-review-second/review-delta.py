#!/usr/bin/env python3
"""Finite read-only delta admission. Never contacts Windows or runs compilers."""
import ast
import hashlib
import json
from pathlib import Path

E=Path('/tmp/fc-round79-msi-maintenance')
P=E/'controlled-owner-handle-design-first'
S=P/'prototype-preparation-first'
B=S/'build-output-first'
OLD=E/'controlled-owner-preparation-second'
O=Path(__file__).parent
checks=[]
def fact(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def j(p):return json.loads(p.read_text())
def need(n,v,d=None):
 checks.append(dict(name=n,passed=bool(v),detail=d))
 if not v:raise AssertionError(n)
def bound(n,p,row):
 a=fact(p);need(n,all(a[k]==row[k] for k in ('bytes','sha256') if k in row),a)

f=j(P/'freeze-first.json')
need('final_author_freeze',fact(P/'freeze-first.json')['sha256']=='fd62e7c0ed2bfb58e5b8f91ca2521ade06c6be658b4c90eae255956ddb92065e')
for r in f['files']:bound('author_frozen:'+r['path'],P/r['path'],r)
spec=j(B/'spec.json');build=j(B/'build-report.json');manifest=j(B/'stage/runtime-inputs.json')
changed=[]
for name,row in spec['sources'].items():
 bound('actual_source:'+name,S/name,row)
 if (S/name).read_bytes()!=(OLD/name).read_bytes():changed.append(name)
need('only_two_executable_sources_changed',changed==['Owner.c','Invoke-ControlledOwner.ps1'],changed)
need('actual_producer_exit0_reaped81',build['status']=='PASS_STATIC_ONLY_WINDOWS_NOT_RUN' and len(build['commands'])==81 and all(r['actualExit']==0 and r['parentReaped'] for r in build['commands']))
for r in build['commands']:
 for ext,k in [('stdout','stdoutSha256'),('stderr','stderrSha256')]:bound('producer_original_stream:'+r['label']+':'+ext,B/(r['label']+'.'+ext),{'sha256':r[k]})
need('actual_producer_sources_tools_unchanged',build['sourcesUnchanged'] and build['toolsUnchanged'])
bound('build_spec',B/'spec.json',build['spec'])
need('manifest_exact_identity',fact(B/'stage/runtime-inputs.json')['sha256']=='73daf36d811d0eabd10b82af7e6eb2179be27fe356cccfd536581195312ea8be')
for r in manifest['files']:bound('stage_original:'+r['path'],B/'stage'/r['path'],r)
need('fresh_namespace_from_failed_case',spec['nonce']!='048185bd83264d1b8abf282244500f4b' and spec['nonce']=='fceb9af5ba8149cdabdc382c6615fc3d' and all(spec[k]!=j(OLD/'build-output-first/spec.json')[k] for k in ('productCode','upgradeCode','componentId')))
need('limits_unchanged',[spec[k] for k in ('wholeSeconds','nativeSeconds','clientSeconds','finallyReserveSeconds','maximumHandles','maximumOwners')]==[600,120,120,180,64,8])
owner=(S/'Owner.c').read_text();driver=(S/'Invoke-ControlledOwner.ps1').read_text();contract=(P/'contract.md').read_text()
need('ui_log_before_begin',owner.index('previous_ui=MsiSetInternalUI(')<owner.index('UINT logging=MsiEnableLogW(')<owner.index('UINT begin=begin_fn('))
need('same_native_main_thread_no_delegation',owner.count('int WINAPI wWinMain(')==1 and not any(x in owner for x in ('CreateThread(', 'CreateProcess', '_beginthread','TerminateProcess(')))
need('actual_end_is_called_and_recorded','end=end_fn(state);emit("END_RETURN",end,TRUE,transaction);' in owner)
need('nonclose_policy_not_api_success','emit("TRANSACTION_ID_NO_INSTALL_HANDLE_CLOSE",0xffffffffu,FALSE,transaction);' in owner and 'msi_close=MsiCloseHandle(' not in owner and 'CloseHandle(transaction)' not in owner)
need('separate_event_real_one_attempt_checked','change_close=CloseHandle(change)' in owner and owner.count('CloseHandle(change)')==1 and 'before_close&&file_close&&change_close' in owner)
need('native_process_exit0_requires_actual_end0','transaction!=0&&end==0' in owner)
need('driver_sentinel_remains_not_attempted','-not$idPolicy[0].attempted' in driver and '$idPolicy[0].return-eq 4294967295' in driver)
need('driver_actual_native_scenario_required',all(x in driver for x in ('ACTUAL_PREPARE_ACTION_NOT_PROVEN','ACTUAL_FORCEFAIL_AND_ROLLBACK_MODE_NOT_PROVEN',"$force[0].intendedReturn-ceq '1603'","$rollback[0].rollback-ceq '1'","$f.valid-ceq '1'","$f.nonce-ceq $spec.nonce","$f.product-ceq $spec.productCode")))
need('driver_native_log_hash_scope_not_callback_authority',"logSha256=(Hash $p);logBytes=$b.Length" in driver and 'ORIGINAL_NATIVE_CALLBACK_LOG_FACTS_ONLY_NO_CALLBACK_CAPABILITY_AUTHORITY' in driver)
need('old_failure_not_rewritten',fact(E/'controlled-owner-runtime-first/runtime-operation.json')['sha256']=='82569f2897bb0e7da0587de83b48ff174e56718a3f495a82f99acb32320c5ae8')
need('contract_distinguishes_evidence_limits',all(x in contract for x in ('inference','assumption','DTF','not an API return','close6','not proof')))
for case,r in build['cases'].items():
 bound('actual_new_msi:'+case,B/'stage'/(case+'.msi'),r['msi'])
 need('no_new_chainer:'+case,'MsiEmbeddedChainer' not in r['tables'] and len(r['tables']['Binary'])==1)
 seq={x['Action']:x for x in r['tables']['InstallExecuteSequence']}
 need('forced_failure_sequence_unchanged:'+case,seq['Fc79ForceFail']['Sequence']=='6501' and seq['InstallExecute']['Sequence']=='6500' and seq['InstallFinalize']['Sequence']=='6600')
report=dict(status='PASS_FINITE_DELTA_SOURCE_ADMISSION_ONLY',checkCount=len(checks),checks=checks,
 authorFreeze=fact(P/'freeze-first.json'),stageManifest=fact(B/'stage/runtime-inputs.json'),
 changedSources=changed,windowsContacted=False,compilationByReviewer='NOT_RUN',MSIByReviewer='NOT_RUN',productionAuthority='UNPROVEN_NOT_GRANTED',
 manualFindings=[
  'Only Owner.c and driver executable source differ. Previously reviewed original capture mechanism, observer DLL, local producer and tools are unchanged.',
  'UI/log calls move before Begin. Original main-thread ownership, capture ACK before Begin, actual synchronous Install and End returns, real event checked close and process/thread physical exit are retained.',
  'Post-End ID MsiClose call is removed. Its explicit attempted=false / 4294967295 record is policy, not an API return. No old close6 is mapped to zero.',
  'This is a narrowly scoped new experiment. Official pages do not explicitly settle post-End ID validity. Burn assumption and DTF generic-close counterexample prevent a broad claim that transaction identifiers can never be handles.',
  'A 1603 alone no longer proves the intended scenario. Driver requires current product/nonce valid native PREPARE, FORCE_FAIL and rollback mode1; downloaded original engine log hash and actual ForceFail ActionEndReturn3 require root transport qualification.',
  'First native failure remains immutable. Old scratch cleanup success is independent test cleanup and provides no production settlement authority.'
 ],pending=['Final root transport freeze byte binding','Actual Windows controlled-owner four-case evidence and cleanup'],mayMergeRepairCandidate=False,mayDeployDamagedRepair=False)
(O/'source-delta-review-first.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=report['status'],checks=len(checks),stage=report['stageManifest']['sha256'])))
