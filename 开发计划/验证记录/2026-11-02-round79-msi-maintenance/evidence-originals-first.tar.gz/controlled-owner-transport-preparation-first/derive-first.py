from pathlib import Path
import hashlib
E=Path('/tmp/fc-round79-msi-maintenance');p=E/'early-terminal-runtime-transport-preparation-first/run-runtime.py'
b=p.read_bytes();assert hashlib.sha256(b).hexdigest()=='6bb6a094e8ab55765fc45c1becc06b8d545aa4c271ffef765b903736080746fa'
s=b.decode();s=s.replace('Only actual stage-runtime artifacts, source freeze and GUI derivation admitted.','Only exact controlled-owner build/source closure admitted. No production authority.')
s=s.replace("PROTOTYPE=E/'early-terminal-preparation-fifth'","PROTOTYPE=E/'controlled-owner-preparation-first'")
a=s.index('NAMES=');z=s.index('PARENT_PS=',a)
s=s[:a]+"NAMES={'.owner','spec.json','Owner.exe','EarlyTerminal.dll','payload.txt','healthy.msi','early-fail.msi','build-report.json','Capture.cs','Invoke-ControlledOwner.ps1'}\nDIRS=('compiler-temp','readback-compiler-temp','effect')\n"+s[z:]
s=s.replace("'instrument-compiler-temp','readback-compiler-temp','positive-positive-raw','early-fail-positive-raw','effect'","'compiler-temp','readback-compiler-temp','effect'")
a=s.index('def validate_phase(');z=s.index('def parent_preserved(',a)
s=s[:a]+'''def validate_phase(r,spec,helper_sha):
 need(r['status']=='PASS_REAL_BEGIN_INSTALL_END_CLOSE_AND_PHYSICAL_EXIT_NOT_PRODUCTION_AUTHORITY' and r['authority']=='NO_PRODUCTION_AUTHORITY' and r['errors']==[],'Original complete controlled-owner phase PASS only')
 need(r['wholeSeconds']==600 and r['nativeSeconds']==120 and r['finallyReserveSeconds']==180 and type(r['elapsedMilliseconds']) is int and r['elapsedMilliseconds']<600000,'Original600/120/180 unchanged')
 need(r['nativeCloseUnknown'] is False and r['originalOwnerReturned'] is True and r['ownedCommitOutstanding'] is False and r['before']['knownAbsent'] is True and r['afterFinally']['knownAbsent'] is True,'Actual complete return and absence')
 cases=r['cases'];need([x['name'] for x in cases]==['early-fail-rollback','healthy-rollback','healthy-commit','owned-uninstall'],'Exact4 original cases')
 caps=r['originalCaps'];need(len(caps)==8 and all(x['CheckedClose'] is True and x['CloseAttempted'] is True and x['ExitKnown'] is True and type(x['Wait']) is int and x['Wait']==0 for x in caps),'All4originalprocess/thread caps checked return')
 need(r['nativeCloseFacts'] and all(x['Attempted'] is True and x['Success'] is True and x['Unknown'] is False and x['LastError']==0 for x in r['nativeCloseFacts']),'Every close actually returned')
 for index,case in enumerate(cases):
  process=case['originalProcess'];thread=case['originalThread'];need(returned(process) and process['ExitCode']==case['actualExit']==0 and process['Sha256']==helper_sha and process['Sid']==spec['expectedUserSid'],'Original owner process actual return')
  need(thread['Kind']=='thread' and thread['Status']=='HELD_ORIGINAL_IDENTITY' and thread['Pid']==process['Pid'] and thread['Tid']>0 and thread['Creation']>0 and thread['Wait']==0 and thread['ExitKnown'] is True and thread['CheckedClose'] is True,'Original native thread physical return')
  need(case['nativeReturnsComplete'] is True and case['apiSuccessful'] is True and 0<=case['elapsedMilliseconds']<120000,'No renewed owner budget')
  rows=case['api'];need([x['sequence'] for x in rows]==list(range(1,len(rows)+1)) and all(x['pid']==process['Pid'] and x['tid']==x['originalTid']==thread['Tid'] and x['threadCreation']==thread['Creation'] and x['clockValid'] is True for x in rows),'Original API same-thread sequence bound to captured caps')
  def one(stage):
   matches=[x for x in rows if x['stage']==stage];need(len(matches)==1,'One actual native '+stage);return matches[0]
  begin=one('BEGIN_RETURN');install=one('CONFIGURE_ABSENT_RETURN' if index==3 else 'INSTALL_RETURN');end=one('END_RETURN');close=one('MSI_HANDLE_CLOSE_RETURN');event=one('CHANGE_EVENT_CLOSE_RETURN')
  need(begin['attempted'] is True and begin['return']==0 and begin['object']>0 and install['attempted'] is True and install['return']==(1603 if index==0 else 0) and end['attempted'] is True and end['return']==0 and close['attempted'] is True and close['return']==0 and event['attempted'] is True and event['return']==0,'Actual Begin/Install/End/close values, no synthetic Join')
  need(begin['sequence']<install['sequence']<end['sequence']<close['sequence']<event['sequence'] and begin['object']==install['object']==end['object']==close['object'],'Original actual transaction ordering')
  one('END_COMMIT_ENTER' if index in (2,3) else 'END_ROLLBACK_ENTER')
  need(case['before']['knownAbsent'] is (index!=3) and case['after']['knownAbsent'] is (index!=2),'Exact rollback/commit/owned-uninstall effects scopes')
 return {'status':'PASS_ORIGINAL_CONTROLLED_OWNER_API_AND_PHYSICAL_RETURNS','authority':'NO_PRODUCTION_AUTHORITY','caseCount':4}
''' +s[z:]
a=s.index(" for item in r['systemPaths']");z=s.index(' for name,text in logs.items():',a)
s=s[:a]+s[z:]
# Admission needs the frozen actual build schema; completed after build preparation.
a=s.index('def main():');z=s.index(' out.mkdir();',a)
s=s[:a]+'''def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--validate-inputs-only',action='store_true');p.add_argument('--prototype-freeze',type=Path);p.add_argument('--prototype-freeze-sha256');p.add_argument('--stage-dir',type=Path);p.add_argument('--manifest-sha256');p.add_argument('--output-dir',type=Path);a=p.parse_args()
 need(not(a.execute and a.validate_inputs_only),'ChooseexecuteORvalidate')
 if not a.execute and not a.validate_inputs_only:print(json.dumps({'status':'PREPARED_NOT_RUN','Windows':'NOT_CONTACTED','productionAuthority':'NONE'}));return 0
 need(all((a.prototype_freeze,a.prototype_freeze_sha256,a.stage_dir,a.manifest_sha256,a.output_dir)),'All explicit arguments')
 raise ValueError('BUILD_SCHEMA_NOT_ADMITTED_YET_NO_WINDOWS')
''' + s[z:]
s=s.replace("'guiOriginalCompileReport':{'path':str(compile_path),**fact(compile_path)},'specDerivation':{'path':str(derivation_path),**fact(derivation_path)},",'')
s=s.replace("need(len(files)==14,'Fourteen uploads excluding remotely created marker')","need(len(files)==10,'Ten uploads excluding remotely created marker')")
s=s.replace("'Invoke-EarlyTerminal.ps1') -Execute -Root $c.root -SpecSha256 $c.specSha256 -ManifestSha256", "'Invoke-ControlledOwner.ps1') -Execute -Root $c.root -ManifestSha256")
s=s.replace("build['chainer']['sha256']","build['owner']['sha256']")
s=s.replace("(download/'early-terminal-result.json')","(download/'controlled-owner-result.json')")
s=s.replace("logs={name:decode_log((download/name).read_bytes()) for name in ('positive-msi.log','early-fail-msi.log')}","logs={p.name:decode_log(p.read_bytes()) for p in sorted(download.glob('*-msi.log'))};need(len(logs)==4,'Four exact owner MSI logs')")
s=s.replace("report.get('originalControlProof',{}).get('status')=='PASS_ORIGINAL_FIXTURE_CONTROLS_RETURNED_NO_CLOSE_POISON'","report.get('originalControlProof',{}).get('status')=='PASS_ORIGINAL_CONTROLLED_OWNER_API_AND_PHYSICAL_RETURNS'")
s=s.replace('PASS_FINITE_EARLY_FAILURE_AND_REAL_ROLLBACK_FIXTURE_CAPTURE_CLEANUP_NOT_PRODUCTION_AUTHORITY','PASS_FINITE_CONTROLLED_BEGIN_INSTALL_END_CAPTURE_CLEANUP_NOT_PRODUCTION_AUTHORITY')
out=Path(__file__).parent/'run-controlled-owner-first.py';assert not out.exists();out.write_text(s)
