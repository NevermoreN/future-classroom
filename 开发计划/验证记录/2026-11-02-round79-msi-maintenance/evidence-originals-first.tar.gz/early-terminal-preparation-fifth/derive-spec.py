#!/usr/bin/env python3
"""Explicit local spec derivation; preserve original CSC/spec bindings.
Default inert. Never compiles, builds, connects or modifies original reports.
"""
import argparse,copy,hashlib,json
from pathlib import Path
import runpy
E=Path('/tmp/fc-round79-msi-maintenance');HERE=Path(__file__).resolve().parent
def need(ok,why):
 if not ok:raise ValueError(why)
def fact(p):
 need(p.is_file() and not p.is_symlink(),'Original regular file');b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--old-spec',type=Path);p.add_argument('--old-spec-sha256');p.add_argument('--compile-report',type=Path);p.add_argument('--compile-report-sha256');p.add_argument('--out-dir',type=Path);a=p.parse_args()
 if not a.execute:print(json.dumps({'status':'PREPARED_SPEC_DERIVATION_NOT_RUN','compiler':'NOT_RUN','MSI':'NOT_RUN','Windows':'NOT_CONTACTED'}));return 0
 need(all((a.old_spec,a.old_spec_sha256,a.compile_report,a.compile_report_sha256,a.out_dir)),'Explicit original spec/compile/result arguments')
 for source in (a.old_spec,a.compile_report):need(source.is_absolute() and source.resolve()==source and source.is_relative_to(E),'Canonical owned original path')
 need(fact(a.old_spec)['sha256']==a.old_spec_sha256 and fact(a.compile_report)['sha256']==a.compile_report_sha256,'Explicit original actual SHA')
 old=json.loads(a.old_spec.read_text());c=json.loads(a.compile_report.read_text());need(c['status']=='PASS_CSC_COMPILE_DOWNLOAD_EXACT_CLEANUP_ONLY_MSI_NOT_RUN' and c['downloadVerified'] is True and c['spec']=={'path':str(a.old_spec),**fact(a.old_spec)},'Original actual compile binding, not a rewritten spec hash')
 receipt=c['native']['receipt'];need(receipt['status']=='PASS_CSC_ACTUAL_EXIT0_COMPILE_ONLY' and type(receipt['actualExit']) is int and receipt['actualExit']==0 and all(receipt[k] is True for k in ('originalHandleAcquired','processWaitReturned','pipesComplete','processDisposed')) and receipt['executed'] is False,'Actual original compiler handle/wait/code/pipes/dispose facts')
 original_receipt=a.compile_report.parent/'download/positive-compile-receipt.json';exe=a.compile_report.parent/'download/PositiveControl.exe'
 need(json.loads(original_receipt.read_text())==receipt and fact(exe)==receipt['exe'],'Exact original downloaded receipt/EXE')
 need(receipt['nonce']==old['nonce'] and receipt['source']==fact(HERE/'PositiveControl.cs'),'Exact same nonce and GUI source bytes')
 module=runpy.run_path(str(HERE/'fixture.py'));need({r['path'] for r in old['sources']}==set(module['SOURCES']) and len(old['sources'])==len(module['SOURCES']),'Original source closure')
 new=copy.deepcopy(old);changes=[]
 for i,row in enumerate(new['sources']):
  actual=fact(HERE/row['path'])
  if row['path']=='fixture.py':
   changes.append({'path':'sources['+str(i)+']','before':dict(row),'after':{'path':'fixture.py',**actual}});row.update(actual)
  else:need({k:row[k] for k in ('bytes','sha256')}==actual,'Every other source, including GUI and PS, remains byte-identical')
 need(len(changes)==1 and changes[0]['before']!=changes[0]['after'],'Only fixture.py source hash/size changes')
 revert=copy.deepcopy(new)
 for i,row in enumerate(revert['sources']):
  if row['path']=='fixture.py':revert['sources'][i]=changes[0]['before']
 need(revert==old,'All nonce/GUID/root/SID/CS/PS/budgets and every other spec field unchanged')
 need(a.out_dir.is_absolute() and a.out_dir.parent==E and a.out_dir.resolve()==a.out_dir and not a.out_dir.exists(),'Fresh owned local derivation directory')
 a.out_dir.mkdir();(a.out_dir/'.owner').write_text('future-classroom-owned-r79-early-spec-derivation/v1\n')
 (a.out_dir/'old-spec-original.json').write_bytes(a.old_spec.read_bytes());(a.out_dir/'original-compile-receipt.json').write_bytes(original_receipt.read_bytes())
 target=a.out_dir/'spec.json';target.write_text(json.dumps(new,indent=2,ensure_ascii=True)+'\n');module['load_spec'](target,fact(target)['sha256'])
 result={'status':'PASS_LOCAL_SPEC_DERIVATION_ONLY_NOT_MSI_OR_RUNTIME_PASS','originalSpec':{'path':str(a.old_spec),**fact(a.old_spec)},'derivedSpec':{'path':str(target),**fact(target)},'actualCscCompiledUnderOriginalSpec':{'report':{'path':str(a.compile_report),**fact(a.compile_report)},'receipt':{'path':str(original_receipt),**fact(original_receipt)},'exe':{'path':str(exe),**fact(exe)},'scope':'Actual GUI compiler source/nonce unchanged; original compile report and receipt NOT rebound to derived spec'},'onlyChanges':changes,'allOtherSpecFieldsUnchanged':True,'compiler':'NOT_RERUN','MSI':'NOT_RUN','Windows':'NOT_CONTACTED'}
 (a.out_dir/'derivation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
