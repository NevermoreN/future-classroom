# Fifth fixture producer: explicit actual package identity

Only fixture.py changes among the original six execution/production sources.
All earlier freezes, actual first package-build FAIL and original CSC PASS are
unchanged. The pinned tool's own embedded usage documents
`-s name [author] [template] [uuid]`. After table import, the builder now invokes
that pinned msibuild with the exact desired UUID, Intel;1033 template, bounded
test subject/author. Existing strict actual UUID/Intel/Version500 checks and
different package identities are retained; no random UUID is accepted.

Original nonce/GUID/root/SID/GUI/PS/budgets can be preserved without another
Windows GUI compilation. Prepare the explicit local derivation:

```text
python3 derive-spec.py --execute
  --old-spec /tmp/fc-round79-msi-maintenance/early-terminal-inputs-second/spec.json
  --old-spec-sha256 f96275a93a88110065b10f905c07c5362258187be2ef5bfde9967c3915bf92a6
  --compile-report /tmp/fc-round79-msi-maintenance/early-terminal-compile-fifth/compile-operation.json
  --compile-report-sha256 b69d863edd80ac22c2eae52f98740664dd9b559367cfe2708b0b3ace0be52943
  --out-dir /tmp/fc-round79-msi-maintenance/early-terminal-inputs-derived-fifth
```

The derivation verifies original actual compiler0, original handle/wait/pipes/
Dispose, source hash/nonce and exact downloaded original receipt and EXE. It
copies original spec/receipt unchanged, then alters **only** the fixture.py row
bytes/hash in a new spec and round-trips the whole source closure. All other
fields must compare equal after reverting that one row. No old report or
receipt spec binding is rewritten. The new derivation explicitly says GUI
compilation happened under original spec f962…, and only identical GUI source
bytes/nonce are reused. This is local data derivation, not a new compiler or
runtime result.

Run fifth fixture.py build with the new derived spec/SHA, original downloaded
GUI EXE/receipt and pinned original tools. Source DLL and compiler PS are
byte-identical to fourth. Root remains the sole actual build/Windows operator;
no compilation or package creation occurred in this preparation.
