#!/usr/bin/env python3
"""Pure local model checks only: never compile, build, install or connect."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import runpy
import tempfile
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent
ast.parse((ROOT/"fixture.py").read_text())
f=runpy.run_path(str(ROOT/"fixture.py"))
digest=lambda b:hashlib.sha256(b).hexdigest()
s={"schemaVersion":1,"wholeSeconds":600,"nativeSeconds":120,"nonce":"a"*32,
   "sourceGit":"c44906517fbc62233dca755d7225cea375264cbc",
   "rootName":"FutureClassroom-r79-early-terminal-"+"a"*32,
   "marker":f["MARKER"],"expectedUserSid":"S-1-5-21-1-2-3-1001",
   "windowsRoot":"C:\\Users\\Synthetic\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-"+"a"*32,
   "productCode":"{11111111-1111-1111-1111-111111111111}",
   "upgradeCode":"{22222222-2222-2222-2222-222222222222}",
   "componentId":"{33333333-3333-3333-3333-333333333333}",
   "registryKey":"Software\\FutureClassroomTest\\Round79-"+"a"*32,
   "sources":[{"path":n,**f["fact"](ROOT/n)} for n in f["SOURCES"]]}
s["effectDir"]=s["windowsRoot"]+"\\effect\\"
results=[]
with tempfile.TemporaryDirectory(prefix=".pure-owned-",dir=ROOT) as scratch:
    p=Path(scratch)/"spec.json"
    def check(value,expected):
        raw=json.dumps(value).encode();p.write_bytes(raw)
        try:f["load_spec"](p,digest(raw));actual=True
        except ValueError:actual=False
        assert actual==expected
    check(s,True);results.append("closed valid spec accepted")
    variants=[("nonce",lambda x:x.update(nonce="b"*32)),
        ("UNC root",lambda x:x.update(windowsRoot="\\\\server\\share\\x")),
        ("wrong effect",lambda x:x.update(effectDir="C:\\Windows\\")),
        ("SID",lambda x:x.update(expectedUserSid="S-1-5-18")),
        ("duplicate GUID",lambda x:x.update(componentId=x["productCode"])),
        ("budget",lambda x:x.update(nativeSeconds=121)),
        ("source hash",lambda x:x["sources"][0].update(sha256="0"*64)),
        ("production registry path",lambda x:x.update(registryKey="Software\\FutureClassroom")),
        ("false source label",lambda x:x.update(sourceGit="unknown"))]
    for label,edit in variants:
        bad=copy.deepcopy(s);edit(bad);check(bad,False);results.append(label+" rejected")
    ns={"w":"http://schemas.microsoft.com/wix/2006/wi"}
    for case in ("positive","early-fail"):
        tree=ET.fromstring(f["wxs"](s,case))
        assert all(len(tree.findall(".//w:"+tag,ns))==1 for tag in ("File","RegistryValue","Component"))
    assert f["package_code"](s,"positive")!=f["package_code"](s,"early-fail")
    results.append("two distinct package identities, one synthetic file and marker each")
    raw=f["encoded_idt"]("T",["A","B"],["s72","i2"],["A"],[("one","-1"),("two","-2"),("three","-3")])
    assert len(f["idt"](raw,"T"))==3
    try:f["idt"](raw+b"one\t8\r\n","T");raise AssertionError("duplicate accepted")
    except ValueError:pass
    results.append("terminal negatives preserved and duplicate PK rejected")
original=(ROOT/"positive-control-original.cs").read_bytes()
adapted=original.replace(b"future-classroom-owned-r77-supervisor-chainer-fixture/v1",b"future-classroom-owned-r79-early-terminal-fixture/v1").replace(b"FutureClassroom-r77-supervisor-chainer-",b"FutureClassroom-r79-early-terminal-")
assert adapted==(ROOT/"PositiveControl.cs").read_bytes()
assert digest(original)=="7dfdbf67192eff24c1c87db373ca0d104ff270b64a894afb9909bfb52f3b6901"
results.append("archived original positive control preserved; exactly two substitutions")
report={"status":"PASS_PYTHON_AST_AND_PURE_CONTRACT_ONLY","checks":results,
        "compilation":"NOT_RUN","packaging":"NOT_RUN","powershellAst":"NOT_RUN_NO_LOCAL_POWERSHELL",
        "windows":"NOT_RUN","scratchRemoved":True}
print(json.dumps(report,indent=2))
