$c='{"root":"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-0cc4e2524bb7403f94f6b2bdc8a6888b","nonce":"0cc4e2524bb7403f94f6b2bdc8a6888b","sid":"S-1-5-21-3896111207-1867804362-1971593122-1001","spec":{"schemaVersion":1,"status":"PREPARED_NOT_RUN","nonce":"0cc4e2524bb7403f94f6b2bdc8a6888b","rootName":"FutureClassroom-r79-early-terminal-0cc4e2524bb7403f94f6b2bdc8a6888b","windowsRoot":"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-0cc4e2524bb7403f94f6b2bdc8a6888b","effectDir":"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-0cc4e2524bb7403f94f6b2bdc8a6888b\\effect\\","marker":"future-classroom-owned-r79-early-terminal-fixture/v1\n","expectedUserSid":"S-1-5-21-3896111207-1867804362-1971593122-1001","registryKey":"Software\\FutureClassroomTest\\Round79-0cc4e2524bb7403f94f6b2bdc8a6888b","wholeSeconds":600,"nativeSeconds":120,"clientSeconds":120,"finallyReserveSeconds":180,"maximumHandles":64,"maximumOwners":8,"sourceGit":"c44906517fbc62233dca755d7225cea375264cbc","scope":"FRESH_INDEPENDENT_ORIGINAL_BEGIN_API_OWNER_NOT_PRODUCTION_AUTHORITY","sources":{"Owner.c":{"bytes":8027,"sha256":"a03fb8c37f486a435916994323e6ea0d7b8f770c50ed28f6330537861b156b04"},"Invoke-ControlledOwner.ps1":{"bytes":13612,"sha256":"7d8f79429ff8c505a1ae5d3699293eae830a8a3ccf518c5dee2459ecc5a215f6"},"Capture.cs":{"bytes":11335,"sha256":"cd2f47598504deef0a2721a6d61d3cf95a8e93aa6146e4fadeb8744f4e924580"},"EarlyTerminal.c":{"bytes":7254,"sha256":"dc8630277b69dfc4e7cf2ee3eebd476970ffc94138d7581be7934aed706ee9da"},"fixture-original.py":{"bytes":24097,"sha256":"6e1c8520ac799af57ed0b9a440cb3e855c6629cead01a4a6d18b1279a438360a"},"build.py":{"bytes":12426,"sha256":"24584adbdaae371189770d7243aa1578f52ccf45932876d30aa989905411a6eb"},"tools.json":{"bytes":1103,"sha256":"e885fe2e048642a88a8787e722c634ded7b9114f0f08faee3c288f390a50c98d"},"child-environment.json":{"bytes":121,"sha256":"67db97daf1ead75403164284a081b0b28887b699dc8d4e0c41b2cd92924e622f"}},"productCode":"{8FD3EE28-C021-4966-8C94-1C89C67408B7}","upgradeCode":"{2BC61FA0-2447-47C7-9BC5-0B9D7CE709FA}","componentId":"{F20FAA16-F001-432C-9E98-B0506D2724FB}"},"manifest":{"status":"PREPARED_RUNTIME_NOT_RUN","specSha256":"35ede7e7f28bfa035a9f580d65ac86b851369e95fb64d7a536e145bf2ba44beb","buildReportSha256":"cc15d9e193d70792593363b02e191913d819c7e2cc3d8724f323cba795621fe7","files":[{"path":".owner","bytes":53,"sha256":"60f5bff57e6ca56a577cce6e1025aeb8d8087edcc6b9270282bfd362ab841350"},{"path":"Capture.cs","bytes":11335,"sha256":"cd2f47598504deef0a2721a6d61d3cf95a8e93aa6146e4fadeb8744f4e924580"},{"path":"EarlyTerminal.dll","bytes":219125,"sha256":"b5472d7c4e9fee2f392a06811d8128736ec51323c4a7e328a920f29de1594001"},{"path":"Invoke-ControlledOwner.ps1","bytes":13612,"sha256":"7d8f79429ff8c505a1ae5d3699293eae830a8a3ccf518c5dee2459ecc5a215f6"},{"path":"Owner.exe","bytes":298409,"sha256":"33fc252a0bad2419ec9e119a609026b4fe854525d95d31d95785bfdaf46ad7c8"},{"path":"build-report.json","bytes":68101,"sha256":"cc15d9e193d70792593363b02e191913d819c7e2cc3d8724f323cba795621fe7"},{"path":"early-fail.msi","bytes":232448,"sha256":"dfabb64b914588e94a91a0b6fd6deebf7f0403b98fc714f39931cbc16d139bf5"},{"path":"healthy.msi","bytes":232448,"sha256":"029b2c8156e6da7c88c59b85e866533a9960c70201c43477a87aea7829057ecf"},{"path":"payload.txt","bytes":70,"sha256":"e69b1aa0e1a312429830036a1258c7ff77162686b5dcb415cbf2dea427c60ca1"},{"path":"spec.json","bytes":2260,"sha256":"35ede7e7f28bfa035a9f580d65ac86b851369e95fb64d7a536e145bf2ba44beb"}]},"specSha256":"35ede7e7f28bfa035a9f580d65ac86b851369e95fb64d7a536e145bf2ba44beb","manifestSha256":"817f5d6a824584b2d9b6b0e99ec161690cbea459fd539c20165b1aca885f15a3","paths":["C:\\Windows\\Installer\\350cb45b.msi","C:\\Windows\\Installer\\350cb460.msi","C:\\Windows\\Installer\\350cb465.msi","C:\\Windows\\Installer\\350cb469.msi","C:\\Windows\\Installer\\MSI55D2.tmp","C:\\Windows\\Installer\\MSI5621.tmp","C:\\Windows\\Installer\\MSI56AE.tmp","C:\\Windows\\Installer\\MSI57B9.tmp","C:\\Windows\\Installer\\MSI57D9.tmp","C:\\Windows\\Installer\\MSI59AF.tmp","C:\\Windows\\Installer\\MSI59EF.tmp","C:\\Windows\\Installer\\MSI5A8C.tmp","C:\\Windows\\Installer\\MSI5BB6.tmp","C:\\Windows\\Installer\\MSI5D5D.tmp","C:\\Windows\\Installer\\MSI5D9C.tmp","C:\\Windows\\Installer\\MSI5E39.tmp","C:\\Windows\\Installer\\MSI5FC1.tmp"]}'|ConvertFrom-Json;
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Need([bool]$v,[string]$s){if(-not $v){throw $s}}
function Absent([string]$p){try{[void][IO.File]::GetAttributes($p);return $false}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-is [IO.FileNotFoundException] -or $e-is [IO.DirectoryNotFoundException]){return $true};throw}}
function Fact([string]$p){$a=[IO.File]::GetAttributes($p);Need (-not($a-band[IO.FileAttributes]::ReparsePoint) -and -not($a-band[IO.FileAttributes]::Directory)) 'REGULAR_NONREPARSE';$size=[long]([IO.FileInfo]::new($p).Length);Need ($size-ge 0 -and $size-le 16777216) 'FILE_BOUND';@{bytes=$size;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function Root-Check {
 Need ($PSVersionTable.PSVersion.Major-eq 5 -and [IntPtr]::Size-eq 8) 'DESKTOP_PS51_X64'
 Need ([IO.Path]::GetFullPath($c.root)-ceq $c.root -and [IO.Path]::GetFileName($c.root)-ceq ('FutureClassroom-r79-early-terminal-'+$c.nonce)) 'CLOSED_ROOT'
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent();try{Need ($identity.User.Value-ceq $c.sid) 'EXPECTED_CURRENT_USER'}finally{$identity.Dispose()}
 $cursor=$c.root;while($cursor){$a=[IO.File]::GetAttributes($cursor);Need (($a-band[IO.FileAttributes]::ReparsePoint)-eq 0 -and ($a-band[IO.FileAttributes]::Directory)-ne 0) 'DIRECTORY_NO_REPARSE';$cursor=[IO.Path]::GetDirectoryName($cursor)}
 Need ([IO.File]::ReadAllText((Join-Path $c.root '.owner'))-ceq "future-classroom-owned-r79-early-terminal-fixture/v1`n") 'OWNER_MARKER'
 $acl=[IO.Directory]::GetAccessControl($c.root);Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq $c.sid) 'PROTECTED_OWNER'
 $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($rules.Count-eq 2) 'TWO_ACES'
 $who=@($rules|ForEach-Object {$_.IdentityReference.Value}|Sort-Object -Unique);Need ($who.Count-eq 2 -and $c.sid-in $who -and 'S-1-5-18'-in $who) 'USER_AND_SYSTEM'
 foreach($r in $rules){Need ($r.AccessControlType-eq 'Allow' -and ($r.FileSystemRights-band [Security.AccessControl.FileSystemRights]::FullControl)-eq [Security.AccessControl.FileSystemRights]::FullControl) 'EXACT_ALLOW_FULLCONTROL'}
}

function Parent-State {
 $base=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry32);$key=$null
 try{
  $key=$base.OpenSubKey('Software\FutureClassroomTest',$false)
  if($null-eq $key){return @{status='KNOWN_ABSENT';key='Software\FutureClassroomTest';view='Registry32'}}
  $values=@($key.GetValueNames());$subkeys=@($key.GetSubKeyNames());Need ($values.Count-le 64 -and $subkeys.Count-le 128) 'PARENT_SNAPSHOT_BOUND'
  $acl=$key.GetAccessControl([Security.AccessControl.AccessControlSections]::Owner -bor [Security.AccessControl.AccessControlSections]::Access)
  @{status='PRESENT';key='Software\FutureClassroomTest';view='Registry32';ownerSid=$acl.GetOwner([Security.Principal.SecurityIdentifier]).Value;securityDescriptor=$acl.GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]::Owner -bor [Security.AccessControl.AccessControlSections]::Access);valueNames=@($values|Sort-Object);subkeyNames=@($subkeys|Sort-Object)}
 }finally{if($null-ne $key){$key.Dispose()};$base.Dispose()}
}

function Inventory {
 Root-Check;$files=@();$dirs=@();$total=0L;$queue=[Collections.Generic.Queue[string]]::new();$queue.Enqueue($c.root)
 while($queue.Count){$dir=$queue.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){
  $attrs=[IO.File]::GetAttributes($p);Need (($attrs-band[IO.FileAttributes]::ReparsePoint)-eq 0) 'INVENTORY_REPARSE'
  $rel=$p.Substring($c.root.Length+1).Replace('\','/')
  if(($attrs-band[IO.FileAttributes]::Directory)-ne 0){$top=($rel-split '/')[0];Need ($top-cin @('compiler-temp','readback-compiler-temp','effect')) 'ONLY_OWN_FIXTURE_SUBDIRECTORIES';$dirs+=$rel;$queue.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256};$total+=$f.bytes}
  Need ($files.Count-le 256 -and $dirs.Count-le 32 -and $total-le 67108864) 'RUNTIME_INVENTORY_BOUND'
 }}
 @{files=$files;directories=$dirs}
}

Root-Check
$item=@($c.manifest.files|Where-Object path -CEQ 'Capture.cs');Need ($item.Count-eq 1 -and (Fact (Join-Path $c.root 'Capture.cs')).sha256-ceq $item[0].sha256) 'FROZEN_READONLY_CAPTURE_SOURCE'
$beforeTemp=$env:TEMP;$beforeTmp=$env:TMP
try{$env:TEMP=Join-Path $c.root 'readback-compiler-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP);Add-Type -Path (Join-Path $c.root 'Capture.cs') -ErrorAction Stop}finally{$env:TEMP=$beforeTemp;$env:TMP=$beforeTmp}
$product=[Fc79Capture]::Product($c.spec.productCode,$c.spec.upgradeCode,$c.sid)
$components=[Fc79Capture]::Components($c.spec.productCode,$c.spec.componentId,$c.sid)
$registry=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry32);$key=$null
try{$key=$registry.OpenSubKey($c.spec.registryKey,$false);$markerAbsent=($null-eq $key)}finally{if($null-ne $key){$key.Dispose()};$registry.Dispose()}
$effect=[Fc79Capture]::Absence($c.spec.effectDir.TrimEnd('\'));$paths=@()
foreach($path in $c.paths){$paths+=@{path=$path;fact=[Fc79Capture]::Absence($path)}}
$parent=Parent-State
$known=(@($product.registrations).Count-eq 0 -and @($product.related).Count-eq 0 -and $product.localPackageRc-eq 1605 -and $components.allUnknownStates-eq $true -and $markerAbsent -and $effect.status-ceq 'KNOWN_ABSENT')
@{status='ACTUAL_READONLY_FIXTURE_AND_EXACT_SYSTEM_PATH_FACTS';product=$product;components=$components;markerKnownAbsent=$markerAbsent;effect=$effect;fixtureKnownAbsent=$known;registryParent=$parent;paths=$paths;msiExecuted=$false;sharedServiceKilled=$false}|ConvertTo-Json -Depth 30 -Compress
