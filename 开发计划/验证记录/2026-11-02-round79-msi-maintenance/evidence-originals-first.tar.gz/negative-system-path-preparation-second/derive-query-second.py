"""Local-only minimal derivation from immutable first query and actual metadata diagnostic."""
from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parent;E=D.parent;F=E/'negative-system-path-preparation-first'
def sha(b):return hashlib.sha256(b).hexdigest()
def replace1(s,a,b):
 assert s.count(a)==1,a
 return s.replace(a,b)
def put(name,b):
 with (D/name).open('xb') as f:f.write(b.encode() if isinstance(b,str) else b)
def main():
 fb=(F/'freeze-first.json').read_bytes();assert sha(fb)=='c526f5f924a5e99776644cf25b144a8d37c521d8afc1bd672553ce7f35be4435'
 for x in json.loads(fb)['files']:
  b=(F/x['name']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
 db=(E/'root-negative-path-metadata-diagnostic-first.json').read_bytes();assert sha(db)=='ad8820f7ee42deb8af3bfa17c7a2abeab43ce77a38e9cf7f0b0792a91877f606'
 diagnostic=json.loads(db);assert diagnostic['status']=='PASS_METADATA_ONLY_FACTS_CAPTURED_NO_PATH_API_CALLED'
 assert diagnostic['observed']['pathQueryCount']==0 and diagnostic['observed']['nativeCallCount']==0
 assert {k for k,v in diagnostic['observed']['originalGuardFieldMatches'].items() if not v}=={'exactSpelling','setLastError'}
 ps=(F/'exact-system-paths-first.ps1').read_text()
 old="$native=$type.DefinePInvokeMethod('GetFileAttributesW','kernel32.dll',[Reflection.MethodAttributes]'Public, Static, PinvokeImpl',[Reflection.CallingConventions]::Standard,[uint32],[Type[]]@([string]),[Runtime.InteropServices.CallingConvention]::Winapi,[Runtime.InteropServices.CharSet]::Unicode)"
 new="$native=$type.DefineMethod('GetFileAttributesW',[Reflection.MethodAttributes]'Public, Static, PinvokeImpl',[Reflection.CallingConventions]::Standard,[uint32],[Type[]]@([string]))"
 ps=replace1(ps,old,new)
 ps=replace1(ps,"[Runtime.InteropServices.DllImportAttribute].GetField('CallingConvention'))","[Runtime.InteropServices.DllImportAttribute].GetField('CallingConvention'),[Runtime.InteropServices.DllImportAttribute].GetField('PreserveSig'),[Runtime.InteropServices.DllImportAttribute].GetField('BestFitMapping'),[Runtime.InteropServices.DllImportAttribute].GetField('ThrowOnUnmappableChar'))")
 ps=replace1(ps,"$values=[object[]]@('GetFileAttributesW',[Runtime.InteropServices.CharSet]::Unicode,$true,$true,[Runtime.InteropServices.CallingConvention]::Winapi)","$values=[object[]]@('GetFileAttributesW',[Runtime.InteropServices.CharSet]::Unicode,$true,$true,[Runtime.InteropServices.CallingConvention]::Winapi,$true,$false,$false)")
 marker="if (-not $import.SetLastError"
 start=ps.index(marker);end=ps.index('\n',start)
 oldguard=ps[start:end]
 newguard=oldguard.replace(" -or $import.CallingConvention -ne [Runtime.InteropServices.CallingConvention]::Winapi)"," -or $import.CallingConvention -ne [Runtime.InteropServices.CallingConvention]::Winapi -or -not $import.PreserveSig -or $import.BestFitMapping -or $import.ThrowOnUnmappableChar)")
 newguard=newguard.replace("throw 'PInvoke metadata not exact; no path query attempted.'", "throw ('PInvoke metadata not exact; no path query attempted. '+($importMetadata|ConvertTo-Json -Compress))")
 meta="$importMetadata=@{value=$import.Value;entryPoint=$import.EntryPoint;charSet=$import.CharSet.ToString();callingConvention=$import.CallingConvention.ToString();setLastError=[bool]$import.SetLastError;exactSpelling=[bool]$import.ExactSpelling;preserveSig=[bool]$import.PreserveSig;bestFitMapping=[bool]$import.BestFitMapping;throwOnUnmappableChar=[bool]$import.ThrowOnUnmappableChar}\n"
 ps=replace1(ps,oldguard,meta+newguard)
 ps=replace1(ps,"@{schemaVersion=1;facts=$facts;","@{schemaVersion=1;pinvokeConstruction='DEFINE_METHOD_THEN_COMPLETE_DLLIMPORT_ATTRIBUTE';pinvokeMetadata=$importMetadata;facts=$facts;")
 put('exact-system-paths-second.ps1',ps)
 i=json.loads((F/'inputs-first.json').read_bytes())
 i['secondDerivation']=dict(originalFirstFreeze=dict(path=str(F/'freeze-first.json'),sha256=sha(fb)),originalFirstInputs=dict(path=str(F/'inputs-first.json'),sha256=sha((F/'inputs-first.json').read_bytes())),actualMetadataDiagnostic=dict(path=str(E/'root-negative-path-metadata-diagnostic-first.json'),sha256=sha(db)),reason='Actual first DefinePInvokeMethod import retained SetLastError=false and ExactSpelling=false. DefineMethod followed by one complete DllImportAttribute creates the import; the full exact flags guard remains before native calls.',differences=['DefinePInvokeMethod to DefineMethod Public Static PinvokeImpl','Complete DllImport named fields including PreserveSig=true, BestFitMapping=false, ThrowOnUnmappableChar=false','Guard strengthened for all complete fields; on failure include actual metadata without any native path call','Report actual import metadata and construction; unchanged immediate saved-error IL wrapper and exact eleven queries','No change to 49-original closure or paths, 45s, no upload/directory/file/registry/service/process/MSI mutation'])
 put('query-inputs-second.json',json.dumps(i,ensure_ascii=False,indent=2)+'\n')
 c=(F/'audit-exact-system-paths-first.py').read_text()
 c=c.replace("EXPECTED_D=E/'negative-system-path-preparation-first'","EXPECTED_D=E/'negative-system-path-preparation-second'")
 c=c.replace('freeze-first.json','query-freeze-second.json').replace('FROZEN_PREPARATION_WINDOWS_NOT_RUN','FROZEN_QUERY_SECOND_PREPARATION_WINDOWS_NOT_RUN')
 c=c.replace("{'prepare-inputs-first.py','inputs-first.json','exact-system-paths-first.ps1','audit-exact-system-paths-first.py','README-first.txt'}","{'derive-query-second.py','query-inputs-second.json','exact-system-paths-second.ps1','audit-exact-system-paths-second.py','README-query-second.txt'}")
 c=c.replace('inputs-first.json','query-inputs-second.json').replace('exact-system-paths-first.ps1','exact-system-paths-second.ps1')
 needle="i=json.loads(b)\n assert i['status']"
 addition="""i=json.loads(b)
 derivation=i['secondDerivation']
 for key in ['originalFirstFreeze','originalFirstInputs','actualMetadataDiagnostic']:
  x=derivation[key];assert sha(Path(x['path']).read_bytes())==x['sha256']
 assert derivation['originalFirstFreeze']['sha256']=='c526f5f924a5e99776644cf25b144a8d37c521d8afc1bd672553ce7f35be4435'
 assert derivation['actualMetadataDiagnostic']['sha256']=='ad8820f7ee42deb8af3bfa17c7a2abeab43ce77a38e9cf7f0b0792a91877f606'
 original_inputs=json.loads(Path(derivation['originalFirstInputs']['path']).read_bytes())
 assert {k:v for k,v in i.items() if k!='secondDerivation'}==original_inputs
 assert i['status']"""
 c=replace1(c,needle,addition)
 c=replace1(c,"assert o['lastErrorCapture']=='IMMEDIATE_MANAGED_IL_AFTER_SAME_NATIVE_CALL'","""assert o['lastErrorCapture']=='IMMEDIATE_MANAGED_IL_AFTER_SAME_NATIVE_CALL'
 assert o['pinvokeConstruction']=='DEFINE_METHOD_THEN_COMPLETE_DLLIMPORT_ATTRIBUTE'
 metadata=o['pinvokeMetadata']
 assert metadata==dict(value='kernel32.dll',entryPoint='GetFileAttributesW',charSet='Unicode',callingConvention='Winapi',setLastError=True,exactSpelling=True,preserveSig=True,bestFitMapping=False,throwOnUnmappableChar=False)""")
 c=replace1(c,"sourceRuntimeReportSha256=REPORT_SHA,paths=i['paths']","sourceRuntimeReportSha256=REPORT_SHA,actualMetadataDiagnostic=derivation_metadata(i),paths=i['paths']")
 # Name helper keeps report construction simple; all metadata source bytes were verified before SSH.
 c=replace1(c,'def main():',"def derivation_metadata(i):return i['secondDerivation']['actualMetadataDiagnostic']\n\ndef main():")
 put('audit-exact-system-paths-second.py',c)
 print(json.dumps(dict(status='PASS_LOCAL_SECOND_QUERY_DERIVATION_WINDOWS_NOT_RUN',paths=i['exactPathCount'],originals=len(i['verifiedDownloadedOriginals']))))
if __name__=='__main__':main()
