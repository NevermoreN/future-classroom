"""Default inert. Root-only metadata inspection of the original emitted PInvoke; zero path queries."""
from pathlib import Path
import argparse,base64,hashlib,json,re,stat,subprocess,sys
from datetime import datetime,timezone
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
E=Path('/tmp/fc-round79-msi-maintenance')
KEY=Path('/config/.local/share/future-classroom-test-access/win11-192.168.10.212')
SID='S-1-5-21-3896111207-1867804362-1971593122-1001'
def sha(b):return hashlib.sha256(b).hexdigest()
def raw(b,complete=True):return dict(bytes=len(b),sha256=sha(b),base64=base64.b64encode(b).decode(),captureScope='COMPLETE' if complete else 'PARTIAL_TIMEOUT')
def verify(freeze_sha):
 assert D==E/'negative-system-path-preparation-second' and not D.is_symlink()
 assert (E/'.owner').read_bytes()==b'future-classroom-owned-r79-msi-maintenance/v1\n'
 fb=(D/'metadata-diagnostic-freeze-first.json').read_bytes();assert re.fullmatch('[0-9a-f]{64}',freeze_sha or '') and sha(fb)==freeze_sha
 f=json.loads(fb);assert f['status']=='FROZEN_METADATA_ONLY_PREPARATION_WINDOWS_NOT_RUN'
 assert {x['name'] for x in f['files']}=={'metadata-diagnostic-first.py','metadata-only-first.ps1','diagnostic-inputs-first.json','README-diagnostic-first.txt'}
 for x in f['files']:
  assert '/' not in x['name'] and '\\' not in x['name'];p=D/x['name'];assert not p.is_symlink();b=p.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
 i=json.loads((D/'diagnostic-inputs-first.json').read_bytes())
 for field in ['originalFailure','sourceFirstFreeze','sourceFirstPowershell']:
  x=i[field];assert sha(Path(x['path']).read_bytes())==x['sha256']
 assert i['originalFailure']['sha256']=='077b4122040ecc889c3851a45537248fc59702b460b95921dce15be82e59444d'
 original=json.loads(Path(i['originalFailure']['path']).read_bytes());assert original['status']=='FAIL' and original['ssh']['actualExit'] is True and original['ssh']['exitCode']==1
 assert i['queries']==[]
 first=Path(i['sourceFirstPowershell']['path']).read_text();prefix=first[:first.index('if (-not $import.SetLastError')]
 assert sha(prefix.encode())==i['sourceFirstPowershell']['metadataConstructionExactUtf8Sha256']
 ps=(D/'metadata-only-first.ps1').read_bytes();assert ps.startswith(prefix.encode()) and b'.Invoke(' not in ps and b'$paths=' not in ps
 assert not any(x in ps for x in [b'Add-Type',b'Remove-Item',b'Get-ChildItem',b'DeleteFile',b'Set-ItemProperty',b'Start-Service',b'FutureClassroom-r79-production-msi-'])
 return i,ps

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--execute',action='store_true');ap.add_argument('--validate-only',action='store_true');ap.add_argument('--freeze-sha256');ap.add_argument('--report',type=Path);a=ap.parse_args()
 if not a.execute and not a.validate_only:
  print(json.dumps(dict(status='PREPARED_METADATA_ONLY_NOT_RUN',windows='NOT_RUN',pathQueryCount=0,nativeCallCount=0,mutations='NONE')));return 0
 assert not(a.execute and a.validate_only)
 i,ps=verify(a.freeze_sha256)
 if a.validate_only:
  print(json.dumps(dict(status='PASS_LOCAL_FROZEN_METADATA_ONLY_CLOSURE_WINDOWS_NOT_RUN',pathQueryCount=0,nativeCallCount=0,originalConstructionPrefixExact=True)));return 0
 assert a.report and a.report.is_absolute() and a.report.parent==E and a.report.suffix=='.json' and not a.report.exists()
 assert stat.S_IMODE(KEY.stat().st_mode)==0o600
 wrapper='[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()));'
 command=['ssh','-i',str(KEY),'-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=8','elior@192.168.10.212','powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(wrapper.encode('utf-16-le')).decode()]
 r=dict(status='FAIL',scope='Metadata-only construction of original first PInvoke declaration; no query method is invoked, no path list is sent, no cleanup or mutation.',mutations='NONE',pathQueryCount=0,nativeCallCount=0,freezeSha256=a.freeze_sha256,sourceSha256=sha(Path(__file__).read_bytes()),originalFailure=i['originalFailure'],powershellSource=ps.decode(),stdin=raw(ps),command=command,timeoutSeconds=45,privateKeyContentsRead=False,startedUtc=datetime.now(timezone.utc).isoformat())
 with a.report.open('x',encoding='utf-8') as f:
  try:
   p=subprocess.run(command,input=ps,capture_output=True,timeout=45);r['ssh']=dict(actualExit=True,exitCode=p.returncode,stdout=raw(p.stdout),stderr=raw(p.stderr));assert p.returncode==0
   o=json.loads(p.stdout.decode('utf-8-sig'));r['observed']=o
   assert o['scope']=='METADATA_ONLY_ORIGINAL_EMIT_CONSTRUCTION_NO_NATIVE_METHOD_INVOCATION' and o['currentSid']==SID and o['mutations']=='NONE'
   assert o['pathQueryCount']==0 and o['nativeCallCount']==0 and o['queryMethodDefinedButNeverCalled'] is True and o['assemblySaved'] is False
   assert type(o['originalGuardAllFieldsMatch']) is bool and type(o['importIsNull']) is bool
   r['status']='PASS_METADATA_ONLY_FACTS_CAPTURED_NO_PATH_API_CALLED'
  except subprocess.TimeoutExpired as error:r['ssh']=dict(actualExit=False,exitCode=None,stdout=raw(error.stdout or b'',False),stderr=raw(error.stderr or b'',False));r['error']='TIMEOUT_METADATA_UNKNOWN'
  except Exception as error:r['error']=dict(kind=type(error).__name__,message=str(error))
  r['completedUtc']=datetime.now(timezone.utc).isoformat();f.write(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(dict(status=r['status'],report=str(a.report),reportSha256=sha(a.report.read_bytes()),pathQueryCount=0,nativeCallCount=0,mutations='NONE')))
 return 0 if r['status']=='PASS_METADATA_ONLY_FACTS_CAPTURED_NO_PATH_API_CALLED' else 1
if __name__=='__main__':raise SystemExit(main())
