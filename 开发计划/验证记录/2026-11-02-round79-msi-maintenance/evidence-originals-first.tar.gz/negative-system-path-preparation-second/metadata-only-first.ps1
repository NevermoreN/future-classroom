# Finite readonly instrument: in-memory Reflection.Emit, no C# compiler/temp files.
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$OutputEncoding=[Console]::OutputEncoding
$expectedSid='S-1-5-21-3896111207-1867804362-1971593122-1001'
$sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
if ($sid -cne $expectedSid) { throw 'Unexpected current Windows SID; no path query attempted.' }
$assembly=[AppDomain]::CurrentDomain.DefineDynamicAssembly([Reflection.AssemblyName]::new('FutureClassroom.R79.ExactReadonlyAttributes'),[Reflection.Emit.AssemblyBuilderAccess]::Run)
$module=$assembly.DefineDynamicModule('MemoryOnly')
$type=$module.DefineType('ExactReadonlyAttributes',[Reflection.TypeAttributes]'Public, Abstract, Sealed')
$native=$type.DefinePInvokeMethod('GetFileAttributesW','kernel32.dll',[Reflection.MethodAttributes]'Public, Static, PinvokeImpl',[Reflection.CallingConventions]::Standard,[uint32],[Type[]]@([string]),[Runtime.InteropServices.CallingConvention]::Winapi,[Runtime.InteropServices.CharSet]::Unicode)
$ctor=[Runtime.InteropServices.DllImportAttribute].GetConstructor([Type[]]@([string]))
$fields=[Reflection.FieldInfo[]]@([Runtime.InteropServices.DllImportAttribute].GetField('EntryPoint'),[Runtime.InteropServices.DllImportAttribute].GetField('CharSet'),[Runtime.InteropServices.DllImportAttribute].GetField('SetLastError'),[Runtime.InteropServices.DllImportAttribute].GetField('ExactSpelling'),[Runtime.InteropServices.DllImportAttribute].GetField('CallingConvention'))
$values=[object[]]@('GetFileAttributesW',[Runtime.InteropServices.CharSet]::Unicode,$true,$true,[Runtime.InteropServices.CallingConvention]::Winapi)
$native.SetCustomAttribute([Reflection.Emit.CustomAttributeBuilder]::new($ctor,[object[]]@('kernel32.dll'),$fields,$values))
$native.SetImplementationFlags($native.GetMethodImplementationFlags() -bor [Reflection.MethodImplAttributes]::PreserveSig)
# Capture Marshal's saved last error immediately after the P/Invoke, inside IL,
# before reflection Invoke returns. Success last-error values are unspecified.
$query=$type.DefineMethod('Query',[Reflection.MethodAttributes]'Public, Static',[uint32[]],[Type[]]@([string]))
$il=$query.GetILGenerator()
$attrs=$il.DeclareLocal([uint32]);$errorCode=$il.DeclareLocal([int32])
$il.Emit([Reflection.Emit.OpCodes]::Ldarg_0)
$il.Emit([Reflection.Emit.OpCodes]::Call,$native)
$il.Emit([Reflection.Emit.OpCodes]::Stloc,$attrs)
$il.Emit([Reflection.Emit.OpCodes]::Call,[Runtime.InteropServices.Marshal].GetMethod('GetLastWin32Error',[Type[]]@()))
$il.Emit([Reflection.Emit.OpCodes]::Stloc,$errorCode)
$il.Emit([Reflection.Emit.OpCodes]::Ldc_I4_2)
$il.Emit([Reflection.Emit.OpCodes]::Newarr,[uint32])
$il.Emit([Reflection.Emit.OpCodes]::Dup)
$il.Emit([Reflection.Emit.OpCodes]::Ldc_I4_0)
$il.Emit([Reflection.Emit.OpCodes]::Ldloc,$attrs)
$il.Emit([Reflection.Emit.OpCodes]::Stelem_I4)
$il.Emit([Reflection.Emit.OpCodes]::Dup)
$il.Emit([Reflection.Emit.OpCodes]::Ldc_I4_1)
$il.Emit([Reflection.Emit.OpCodes]::Ldloc,$errorCode)
$il.Emit([Reflection.Emit.OpCodes]::Stelem_I4)
$il.Emit([Reflection.Emit.OpCodes]::Ret)
$nativeType=$type.CreateType()
$import=[Attribute]::GetCustomAttribute($nativeType.GetMethod('GetFileAttributesW'),[Runtime.InteropServices.DllImportAttribute])
# Metadata inspection only. Neither the PInvoke nor emitted Query method is called.
$metadata=if ($null -eq $import) {$null} else {@{
 value=$import.Value
 entryPoint=$import.EntryPoint
 charSet=$import.CharSet.ToString()
 charSetNumeric=[int]$import.CharSet
 callingConvention=$import.CallingConvention.ToString()
 callingConventionNumeric=[int]$import.CallingConvention
 setLastError=[bool]$import.SetLastError
 exactSpelling=[bool]$import.ExactSpelling
 preserveSig=[bool]$import.PreserveSig
 bestFitMapping=[bool]$import.BestFitMapping
 throwOnUnmappableChar=[bool]$import.ThrowOnUnmappableChar
}}
$match=@{
 importNotNull=($null -ne $import)
 setLastError=($null -ne $import -and $import.SetLastError)
 exactSpelling=($null -ne $import -and $import.ExactSpelling)
 charSet=($null -ne $import -and $import.CharSet -eq [Runtime.InteropServices.CharSet]::Unicode)
 entryPoint=($null -ne $import -and $import.EntryPoint -ceq 'GetFileAttributesW')
 library=($null -ne $import -and $import.Value -ceq 'kernel32.dll')
 callingConvention=($null -ne $import -and $import.CallingConvention -eq [Runtime.InteropServices.CallingConvention]::Winapi)
}
$allMatch=($match.Values -notcontains $false)
$method=$nativeType.GetMethod('GetFileAttributesW')
$customData=@(foreach ($a in $method.GetCustomAttributesData()) {
 @{
  attributeType=$a.AttributeType.FullName
  constructorArguments=@(foreach($v in $a.ConstructorArguments){@{argumentType=$v.ArgumentType.FullName;value=if($null -eq $v.Value){$null}else{$v.Value.ToString()}}})
  namedArguments=@(foreach($v in $a.NamedArguments){@{memberName=$v.MemberName;isField=$v.IsField;argumentType=$v.TypedValue.ArgumentType.FullName;value=if($null -eq $v.TypedValue.Value){$null}else{$v.TypedValue.Value.ToString()}}})
 }
})
@{
 schemaVersion=1
 scope='METADATA_ONLY_ORIGINAL_EMIT_CONSTRUCTION_NO_NATIVE_METHOD_INVOCATION'
 currentSid=$sid
 mutations='NONE'
 pathQueryCount=0
 nativeCallCount=0
 queryMethodDefinedButNeverCalled=$true
 assemblyAccess='Run'
 assemblySaved=$false
 importIsNull=($null -eq $import)
 import=$metadata
 originalGuardFieldMatches=$match
 originalGuardAllFieldsMatch=$allMatch
 nativeMethod=@{name=$method.Name;attributes=$method.Attributes.ToString();implementationFlags=$method.GetMethodImplementationFlags().ToString();returnType=$method.ReturnType.FullName;parameterTypes=@($method.GetParameters()|ForEach-Object{$_.ParameterType.FullName})}
 customAttributesData=$customData
 runtime=@{clrVersion=[Environment]::Version.ToString();is64BitProcess=[Environment]::Is64BitProcess;psVersion=$PSVersionTable.PSVersion.ToString()}
}|ConvertTo-Json -Depth 12 -Compress
