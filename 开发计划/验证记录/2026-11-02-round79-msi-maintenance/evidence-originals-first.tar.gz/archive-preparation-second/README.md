R79 second compact evidence archive preparation. Default does not inventory, archive, delete, or connect Windows.

Exact source root: /tmp/fc-round79-msi-maintenance. Never scan R80. Main source Git remains c44906517fbc62233dca755d7225cea375264cbc. Final readonly audit windows-readonly-final-second.json is pinned in execution-plan-second.json.

The first controller and its forms remain unchanged. This revision adds exactly three observed UTF16 MSI DigitalSignature stream-note originals to the first twelve structured originals; owned-uninstall log has no such control. Every exception requires original path, bytes, SHA256 and strict structural checks. There is no generic control removal or binary-to-text fallback. Complete raw, visible-control and concatenated-control views remain credential-scanned.

Use execution-plan-second.json. Stop R79 writers, bind final finite actual acceptance and audit SHA, run --inventory-only; capture stdout outside E. Unknown new encodings, controls, credential findings or private/certificate filenames fail. Root alone then runs the actual archive into a fresh repository destination. This tool never cleans up. cleanup-plan-second.json requires committed Git byte proof, synchronized archive, and clean formal worktree removal without --force.

24 finite scanner checks pass. Read-only diagnosis was preparation-time, not final acceptance. Real runtime scope remains Win11 only, and the observational/controlled-owner prototype is not production authority.
