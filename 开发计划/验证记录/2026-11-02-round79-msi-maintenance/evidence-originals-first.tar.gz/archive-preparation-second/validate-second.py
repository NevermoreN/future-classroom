#!/usr/bin/env python3
"""Finite scanner/admission unit checks only; never archives or connects Windows."""
from pathlib import Path
import importlib.util,json,base64,hashlib
p=Path(__file__).parent
spec=importlib.util.spec_from_file_location('archive',p/'archive-second.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
forms=json.loads((p/'text-forms-second.json').read_bytes());m.TEXT_FORMS={x['path']:x for x in forms['files']};m.TEXT_DERIVED_VIEWS={}
checks=[]
def scan(data,label='fixture'):
 st={k:0 for k in ('textViews','utf16Views','cp936Views','clixmlDecodedViews','decodedBase64Views','jsonContainers','decodedJsonStringViews')};f=[];m.credential_scan(data,label,st,f);return f,st
# Composed test value exists only in memory; no issued credential is involved.
token='gh'+'p_'+'A'*36
for name,data in [('utf8',token.encode()),('utf16',token.encode('utf-16')),('cp936',('中文 '+token).encode('cp936')),('json-string',json.dumps({'x':token}).encode()),('base64',base64.b64encode(('test padding '*8+token).encode())),('nested-base64',json.dumps({'stdoutBase64':base64.b64encode(json.dumps({'stderrBase64':base64.b64encode(token.encode()).decode()}).encode()).decode()}).encode()),('clixml',('#< CLIXML\r\n<Objs Version="1.1.0.1" xmlns="http://schemas.microsoft.com/powershell/2004/04"><S>'+token+'</S></Objs>').encode())]:
 f,st=scan(data);assert any(x['kind']=='github-token' for x in f),name;checks.append({'name':name,'result':'PASS_COMPOSED_DUMMY_TOKEN_DETECTED','statistics':st})
for row in forms['files']:
 b=(m.SOURCE/row['path']).read_bytes();v=m.text_views(b,'source:'+row['path']);assert len(v)==3;checks.append({'name':row['path'],'result':'PASS_EXACT_IDENTITY_AND_STRICT_STRUCTURE'})
try:m.text_views(b'unknown\x05control','source:not-whitelisted.log')
except AssertionError:checks.append({'name':'unlisted-control','result':'PASS_REJECTED'})
else:raise AssertionError('UNLISTED_CONTROL_ACCEPTED')
try:scan(json.dumps({'stdoutBase64':base64.b64encode(b'\x7fELF'+b'x'*100).decode()}).encode())
except AssertionError:checks.append({'name':'encoded-binary','result':'PASS_REJECTED'})
else:raise AssertionError('ENCODED_BINARY_ACCEPTED')
report={'status':'PASS_FINITE_SCANNER_PREPARATION_CHECKS_NOT_FINAL_INVENTORY','checks':checks,'rootPayloadInventory':'NOT_RUN','archive':'NOT_RUN','deletion':'NOT_RUN','windows':'NOT_CONNECTED'}
(p/'validation-second.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':report['status'],'checks':len(checks)}))
