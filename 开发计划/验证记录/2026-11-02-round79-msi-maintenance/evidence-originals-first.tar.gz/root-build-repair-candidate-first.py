#!/usr/bin/env python3
"""Root's isolated GNU candidate compile; no Windows execution or main edits."""
import argparse, hashlib, json, os, signal, subprocess, time
from pathlib import Path

E = Path('/tmp/fc-round79-msi-maintenance')
W = E / 'repair-implementation-first/checkout-c449-first'
C = E / 'repair-implementation-first/candidate-first/candidate-first.json'
PIN = '6e4a6df210326a496ef4d5351aed154684e2af4fbb7ea6dfaefab1ee3910d38a'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def snap():
    paths = subprocess.check_output(['git','ls-files','-z','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo','crates','scripts'],cwd=W).split(b'\0')
    names = {os.fsdecode(p) for p in paths if p}
    names.update(x['path'] for x in json.loads(C.read_text())['scope'])
    return [{'path':p,'bytes':(W/p).stat().st_size,'sha256':sha(W/p)} for p in sorted(names)]
def main():
    a=argparse.ArgumentParser(); a.add_argument('--execute',action='store_true'); args=a.parse_args()
    if not args.execute: print(json.dumps({'status':'NOT_RUN','budgetSeconds':900})); return
    assert sha(C)==PIN
    c=json.loads(C.read_text())
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==c['head']
    for x in c['scope']:
        assert (W/x['path']).stat().st_size==x['bytes'] and sha(W/x['path'])==x['sha256']
    out=E/'repair-candidate-build-first'; out.mkdir()
    target=E/'repair-candidate-target-first'; target.mkdir()
    (target/'.owner').write_text('future-classroom-owned-r79-repair-candidate-target/v1\n')
    before=snap(); (out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
    argv=['cargo','test','--offline','--locked','--workspace','--all-targets','--target','i686-pc-windows-gnu','--target-dir',str(target),'--no-run','--message-format=json-render-diagnostics']
    report={'schema':'future-classroom-r79-candidate-gnu-build/v1','status':'STARTED','candidateSha256':PIN,'cwd':str(W),'argv':argv,'budgetSeconds':900,'harvestGraceSeconds':10,'targetDir':str(target),'sourceBeforeSha256':sha(out/'source-before.json'),'defaultRepositoryLinker':True,'windowsRuntime':'NOT_RUN','mainMerge':'NOT_RUN'}
    env=os.environ.copy();env['CARGO_BUILD_JOBS']='2'
    start=time.monotonic()
    with (out/'stdout.jsonl').open('xb') as so,(out/'stderr.log').open('xb') as se:
        p=subprocess.Popen(argv,cwd=W,env=env,stdout=so,stderr=se,start_new_session=True)
        report['originalPid']=p.pid
        try: p.wait(timeout=900);report['budgetExceeded']=False
        except subprocess.TimeoutExpired:
            report['budgetExceeded']=True;os.killpg(p.pid,signal.SIGTERM)
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
        report['actualReturnCode']=p.returncode;report['originalReaped']=True
    report['elapsedSeconds']=time.monotonic()-start
    after=snap(); (out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');report['sourceUnchanged']=before==after
    report['outputs']=[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in [out/'stdout.jsonl',out/'stderr.log',out/'source-before.json',out/'source-after.json']]
    report['status']='PASS_WORKSPACE_ALL_TARGETS_GNU_COMPILE_ONLY' if report['actualReturnCode']==0 and not report['budgetExceeded'] and before==after else 'FAIL'
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'report':str(out/'report.json'),'sha256':sha(out/'report.json')}))
    raise SystemExit(0 if report['status'].startswith('PASS_') else 1)
if __name__=='__main__': main()
