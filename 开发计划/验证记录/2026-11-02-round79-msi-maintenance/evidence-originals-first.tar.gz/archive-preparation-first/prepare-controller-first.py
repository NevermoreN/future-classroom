from pathlib import Path
import hashlib,json
p=Path(__file__).parent
s=(p/'r78-original-archive-second.py').read_text()
s=s.replace('R78','R79').replace('r78','r79')
s=s.replace("SOURCE=Path('/tmp/fc-round79-ci-evidence')","SOURCE=Path('/tmp/fc-round79-msi-maintenance')")
s=s.replace("2026-11-01-round79-ci","2026-11-02-round79-msi-maintenance")
s=s.replace("CONTROLLER=SOURCE/'archive-preparation-second'","CONTROLLER=SOURCE/'archive-preparation-first'")
s=s.replace("EXACT_SOURCE='261c58aca8b0f63ff2cfb4dbd5e85c0d17770005'","EXACT_SOURCE='c44906517fbc62233dca755d7225cea375264cbc'")
s=s.replace("TEXT_FORMS_SHA='b291eb21a858dfeadf2f758a91a4d916fde856db6772f360446c086d042b241d'","TEXT_FORMS_SHA='"+hashlib.sha256((p/'text-forms-first.json').read_bytes()).hexdigest()+"'")
a=s.index('PRUNE_RELATIVE=');b=s.index('\nPRUNE_NAMES=',a)
s=s[:a]+"PRUNE_RELATIVE="+repr({'package-preparation-first/checkout-261c58a-first','repair-implementation-first/checkout-c449-first','repair-candidate-target-first','package-preparation-first/tools/root','package-preparation-first/web-build-first/source','package-preparation-first/web-build-first/npm-cache','package-preparation-first/web-build-first/process-temp'})+s[b:]
s=s.replace('(?:14:B0|44:DC)','(?:[0-9A-F]{2}:[0-9A-F]{2})')
a=s.index('def gates(a):');b=s.index('\ndef main():',a)
s=s[:a]+'''def gates(a):
 global TEXT_FORMS,TEXT_DERIVED_VIEWS
 form_bytes=TEXT_FORMS_FILE.read_bytes();need(sha(form_bytes)==TEXT_FORMS_SHA,'EXACT_REVIEWED_TEXT_FORMS_CONFIG');forms=json.loads(form_bytes)
 need(forms['status']=='EXACT_REVIEWED_R79_STRUCTURED_TEXT_NOT_GENERAL_BINARY_EXCEPTION' and len(forms['files'])==12 and not forms['derivedJsonViews'],'EXACT_R79_FINITE_REVIEWED_FORMS')
 TEXT_FORMS={row['path']:row for row in forms['files']};TEXT_DERIVED_VIEWS={};need(len(TEXT_FORMS)==12,'UNIQUE_REVIEWED_TEXT_FORM_PATHS')
 diagnosis=SOURCE/forms['diagnosis']['path'];need(len(diagnosis.read_bytes())==forms['diagnosis']['bytes'] and sha(diagnosis.read_bytes())==forms['diagnosis']['sha256'],'EXACT_ORIGINAL_TEXT_DIAGNOSIS')
 need(a.root_controllers_terminal,'ROOT_ALL_WRITERS_TERMINAL_CONFIRMATION_REQUIRED')
 need((SOURCE/'.owner').read_bytes()==b'future-classroom-owned-r79-msi-maintenance/v1\\n','EXACT_R79_OWNER')
 need((CONTROLLER/'.owner').read_bytes()==b'future-classroom-owned-r79-archive-preparation-first/v1\\n' and Path(__file__).resolve().parent==CONTROLLER,'EXACT_ARCHIVER_OWNER')
 need(a.source_base_git==EXACT_SOURCE,'EXACT_R79_COMMITTED_SOURCE')
 need(subprocess.check_output(['git','-C',str(MAIN),'rev-parse','HEAD'],timeout=10).decode().strip()==EXACT_SOURCE,'CURRENT_SOURCE_HEAD_UNCHANGED')
 _,accept,accept_fact=pinned(a.acceptance_report,a.expected_acceptance_sha256)
 need(isinstance(a.expected_acceptance_status,str) and a.expected_acceptance_status.startswith('PASS_R79_') and not any(x in a.expected_acceptance_status for x in ('STATIC','PREPARED','NOT_RUN')),'EXPLICIT_FINITE_RUNTIME_ACCEPTANCE_SCOPE')
 need(accept['status']==a.expected_acceptance_status and accept['sourceSha']==EXACT_SOURCE,'ACTUAL_FINITE_R79_ACCEPTANCE')
 _,final,final_fact=pinned(a.readonly_audit,a.expected_readonly_sha256)
 need(final['status']=='PASS' and final.get('completedAtUtc'),'ACTUAL_TERMINAL_READONLY_AUDIT')
 return dict(acceptance=accept_fact,acceptanceStatus=accept['status'],readonlyAudit=final_fact,processAudit=terminal_processes(),scope='Evidence preservation only. Candidate repair and observational prototype remain separately scoped; does not establish production transaction authority or Win7/Win10 runtime.')
''' +s[b:]
a=s.index(" for name in ('acceptance-report'");b=s.index(" p.add_argument('--promote'",a) if " p.add_argument('--promote'" in s[a:] else -1
# Old modern/win7 declarations share a line with promote; replace the entire region exactly.
old=" for name in ('acceptance-report','expected-acceptance-sha256','expected-acceptance-status','readonly-audit','expected-readonly-sha256','modern-static-audit','expected-modern-static-sha256','win7-static-audit','expected-win7-static-sha256','tools-report','expected-tools-sha256'):p.add_argument('--'+name)\n p.add_argument('--modern-run-id',type=int);p.add_argument('--win7-run-id',type=int);p.add_argument('--promote',action='append',default=[]);a=p.parse_args()"
new=" for name in ('acceptance-report','expected-acceptance-sha256','expected-acceptance-status','readonly-audit','expected-readonly-sha256'):p.add_argument('--'+name)\n p.add_argument('--inventory-only',action='store_true');p.add_argument('--promote',action='append',default=[]);a=p.parse_args()"
assert old in s;s=s.replace(old,new)
s=s.replace(" need(set(TEXT_FORMS)<={r['path'] for r in rows},'ALL_15_REVIEWED_STRUCTURED_TEXT_ORIGINALS_RETAINED')"," need(set(TEXT_FORMS)<={r['path'] for r in rows},'ALL_12_REVIEWED_STRUCTURED_TEXT_ORIGINALS_RETAINED')")
a=s.index(' omitted_by={r[');b=s.index(' # Everything above',a)
s=s[:a]+" if a.inventory_only:\n  print(json.dumps(dict(status='PASS_READ_ONLY_FINITE_INVENTORY_AND_CREDENTIAL_SCAN_NOT_ARCHIVED',originals=rows,excludedBinaries=omitted,prunedGeneratedTrees=pruned,statistics=stats,sourceRemoved=False,windowsContacted=False)));return 0\n"+s[b:]
# An empty suffix .stdout carrying recognizable PE remains identity only by magic.
with (p/'archive-first.py').open('x') as f:f.write(s)
