# Compile-only transport second — controlled precompile recovery

Default remains inert. It performs no compilation, connection or MSI action.
The original first transport, first actual failed report and all raw files are
unchanged. The prototype second freeze also stays unchanged.

The ordinary transport is identical except that its new, short-lived remote
PowerShell process receives `-ExecutionPolicy Bypass`. It never calls
Set-ExecutionPolicy or changes machine/user policy. No production auth bypass
or MSI bypass flag is added.

The additional optional recovery interface accepts only the original precise
precompile security rejection: same second prototype/spec/root/nonce/alias,
four exact original uploads, natural reaped create0/upload0/compile-parent1,
PSSecurityException, no parse errors, no receipt, no helper/MSI execution and
preserved original stdout/stderr hashes. Root must pass the original failure's
explicit SHA; a general compiler failure/timeout is not recoverable here.

```text
python3 compile-only.py --execute
  --prototype-freeze /tmp/fc-round79-msi-maintenance/early-terminal-preparation-second/freeze-second.json
  --prototype-freeze-sha256 7c76bbae0aa658d068b531461cbf34361a6a36603b8cfc54c7c96e31b66c8240
  --spec /tmp/fc-round79-msi-maintenance/early-terminal-inputs-first/spec.json
  --spec-sha256 46eab56eb0334c8a27cbfa96f4686c305ba0266c4568a43453ea086ba9cd299b
  --recover-precompile-report /tmp/fc-round79-msi-maintenance/early-terminal-compile-first/compile-operation.json
  --recover-precompile-report-sha256 5fcf342bf876a6b89af94341cd5a8903ce92a18626d47d8318ffc8f09ffb7947
  --output-dir /tmp/fc-round79-msi-maintenance/early-terminal-compile-second
```

Before invoking the compiler, recovery performs a real read-only inventory of
exactly the original four uploaded files and owner marker, no directories, and
checks all five original byte counts/hashes plus owner/DACL/reparse guards. A
bounded process query covers only csc.exe and PositiveControl.exe, refuses
unknown candidate metadata, and requires zero candidates belonging to this
root. Foreign commands are not emitted or mutated. This is a negative fixture
recovery check, not authority for production process roles.

Recovery does not recreate the root, upload or overwrite a file. The locally
prepared four-input copy is evidence only. It proceeds directly to the same
compile-only invocation once. The same actual source/receipt/PE/download and
second-inventory gates precede exact root deletion. Original failure remains
FAIL; recovery result and original raw identities are separate. Any changed
member, unexpected file/process, policy failure, compile failure or unknown
return retains the root and stops; no unknown-stage retry is attempted.

The original 120s compile-transport/30s compiler clocks remain fixed. Future MSI
600s/client120s/finally180s is unchanged and NOT_RUN. There is no service kill,
registry/cache cleanup or helper/MSI execution in this controller.
