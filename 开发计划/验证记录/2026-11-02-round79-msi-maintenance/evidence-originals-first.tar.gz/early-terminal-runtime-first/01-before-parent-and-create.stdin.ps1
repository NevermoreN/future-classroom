$c='{"root":"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-0b744835e91f1ee00a95b18eb3303f19","nonce":"0b744835e91f1ee00a95b18eb3303f19","sid":"S-1-5-21-3896111207-1867804362-1971593122-1001","spec":{"schemaVersion":1,"status":"PREPARED_NOT_COMPILED_PACKAGED_OR_RUN","nonce":"0b744835e91f1ee00a95b18eb3303f19","sourceGit":"c44906517fbc62233dca755d7225cea375264cbc","expectedUserSid":"S-1-5-21-3896111207-1867804362-1971593122-1001","rootName":"FutureClassroom-r79-early-terminal-0b744835e91f1ee00a95b18eb3303f19","windowsRoot":"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-0b744835e91f1ee00a95b18eb3303f19","effectDir":"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-0b744835e91f1ee00a95b18eb3303f19\\effect\\","marker":"future-classroom-owned-r79-early-terminal-fixture/v1\n","wholeSeconds":600,"nativeSeconds":120,"clientSeconds":120,"finallyReserveSeconds":180,"positiveSupervisorSeconds":10,"positiveAckSeconds":2,"registryKey":"Software\\FutureClassroomTest\\Round79-0b744835e91f1ee00a95b18eb3303f19","sources":[{"path":"EarlyTerminal.c","bytes":7254,"sha256":"dc8630277b69dfc4e7cf2ee3eebd476970ffc94138d7581be7934aed706ee9da"},{"path":"PositiveControl.cs","bytes":16463,"sha256":"ae0a1c90e5d551cd824eef0cc1b7afdf0b92174b091b7b68bbea02bb21796e04"},{"path":"Compile-PositiveControl.ps1","bytes":6445,"sha256":"aa562d0d9c5b33f2c5a4011d1a58bb2f36ddc689e57e13ab64e87db6e31bc432"},{"path":"Invoke-EarlyTerminal.ps1","bytes":21633,"sha256":"bb7ba13417b7af95acce74e557f764dd8a6a61a61065cab192e5b044dcf83a3c"},{"path":"Capture.cs","bytes":11335,"sha256":"cd2f47598504deef0a2721a6d61d3cf95a8e93aa6146e4fadeb8744f4e924580"},{"path":"fixture.py","bytes":24097,"sha256":"6e1c8520ac799af57ed0b9a440cb3e855c6629cead01a4a6d18b1279a438360a"}],"productCode":"{E2978D55-CB0A-41E8-BE32-D6BEF4E5260A}","upgradeCode":"{E17624DB-B620-494B-BD65-B237CA2CA7BE}","componentId":"{849E8FA5-FD1D-47DE-92BC-46B863A0731F}"},"manifest":{"schemaVersion":1,"status":"PREPARED_RUNTIME_NOT_RUN","specSha256":"dfc23dab1c2f3d039a7386178f8c0113f56317382930adc642c9985b5fb8b89f","buildReportSha256":"b96670c9fb492cb9ca043ba1bbd513a7227823d85ae6c7d552fa34d6f2388c23","files":[{"path":".owner","bytes":53,"sha256":"60f5bff57e6ca56a577cce6e1025aeb8d8087edcc6b9270282bfd362ab841350"},{"path":"Capture.cs","bytes":11335,"sha256":"cd2f47598504deef0a2721a6d61d3cf95a8e93aa6146e4fadeb8744f4e924580"},{"path":"Compile-PositiveControl.ps1","bytes":6445,"sha256":"aa562d0d9c5b33f2c5a4011d1a58bb2f36ddc689e57e13ab64e87db6e31bc432"},{"path":"EarlyTerminal.c","bytes":7254,"sha256":"dc8630277b69dfc4e7cf2ee3eebd476970ffc94138d7581be7934aed706ee9da"},{"path":"EarlyTerminal.dll","bytes":219125,"sha256":"44129a2d36cb49eede6eaef5d61f3bc2a5b8621290727b44326225dae5113569"},{"path":"Invoke-EarlyTerminal.ps1","bytes":21633,"sha256":"bb7ba13417b7af95acce74e557f764dd8a6a61a61065cab192e5b044dcf83a3c"},{"path":"PositiveControl.cs","bytes":16463,"sha256":"ae0a1c90e5d551cd824eef0cc1b7afdf0b92174b091b7b68bbea02bb21796e04"},{"path":"PositiveControl.exe","bytes":18944,"sha256":"35f048d69447778ff98ffef98dd404a256d21165d78a3fe79d3913b1e916f66c"},{"path":"build-report.json","bytes":75254,"sha256":"b96670c9fb492cb9ca043ba1bbd513a7227823d85ae6c7d552fa34d6f2388c23"},{"path":"early-fail.msi","bytes":251904,"sha256":"a1a8a80a373f73d575af677fe54dc046c8e43b8107d1ba859c3781577164e913"},{"path":"fixture.py","bytes":24097,"sha256":"6e1c8520ac799af57ed0b9a440cb3e855c6629cead01a4a6d18b1279a438360a"},{"path":"payload.txt","bytes":70,"sha256":"79dca9209e0f4f4293625618c2a5160e336d59f19018ef292d71b22a5c43d1ce"},{"path":"positive.msi","bytes":251904,"sha256":"95aea29a425d7a4240e41ac279f914c0386ae40c0cc3f233833124531600b57f"},{"path":"spec.json","bytes":2045,"sha256":"dfc23dab1c2f3d039a7386178f8c0113f56317382930adc642c9985b5fb8b89f"}]},"specSha256":"dfc23dab1c2f3d039a7386178f8c0113f56317382930adc642c9985b5fb8b89f","manifestSha256":"2fb3a130d04c21156a9c8599a681f4aaccf40b98865b0f15427928c01868cf68"}'|ConvertFrom-Json;
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Need([bool]$v,[string]$s){if(-not $v){throw $s}}
function Absent([string]$p){try{[void][IO.File]::GetAttributes($p);return $false}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-is [IO.FileNotFoundException] -or $e-is [IO.DirectoryNotFoundException]){return $true};throw}}
function Fact([string]$p){$a=[IO.File]::GetAttributes($p);Need (-not($a-band[IO.FileAttributes]::ReparsePoint) -and -not($a-band[IO.FileAttributes]::Directory)) 'REGULAR_NONREPARSE';$size=[long]([IO.FileInfo]::new($p).Length);Need ($size-ge 0 -and $size-le 16777216) 'FILE_BOUND';@{bytes=$size;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function Root-Check {
 Need ($PSVersionTable.PSVersion.Major-eq 5 -and [IntPtr]::Size-eq 8) 'DESKTOP_PS51_X64'
 Need ([IO.Path]::GetFullPath($c.root)-ceq $c.root -and [IO.Path]::GetFileName($c.root)-ceq ('FutureClassroom-r79-early-terminal-'+$c.nonce)) 'CLOSED_ROOT'
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent();try{Need ($identity.User.Value-ceq $c.sid) 'EXPECTED_CURRENT_USER'}finally{$identity.Dispose()}
 $cursor=$c.root;while($cursor){$a=[IO.File]::GetAttributes($cursor);Need (($a-band[IO.FileAttributes]::ReparsePoint)-eq 0 -and ($a-band[IO.FileAttributes]::Directory)-ne 0) 'DIRECTORY_NO_REPARSE';$cursor=[IO.Path]::GetDirectoryName($cursor)}
 Need ([IO.File]::ReadAllText((Join-Path $c.root '.owner'))-ceq "future-classroom-owned-r79-early-terminal-fixture/v1`n") 'OWNER_MARKER'
 $acl=[IO.Directory]::GetAccessControl($c.root);Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq $c.sid) 'PROTECTED_OWNER'
 $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($rules.Count-eq 2) 'TWO_ACES'
 $who=@($rules|ForEach-Object {$_.IdentityReference.Value}|Sort-Object -Unique);Need ($who.Count-eq 2 -and $c.sid-in $who -and 'S-1-5-18'-in $who) 'USER_AND_SYSTEM'
 foreach($r in $rules){Need ($r.AccessControlType-eq 'Allow' -and ($r.FileSystemRights-band [Security.AccessControl.FileSystemRights]::FullControl)-eq [Security.AccessControl.FileSystemRights]::FullControl) 'EXACT_ALLOW_FULLCONTROL'}
}

function Parent-State {
 $base=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry32);$key=$null
 try{
  $key=$base.OpenSubKey('Software\FutureClassroomTest',$false)
  if($null-eq $key){return @{status='KNOWN_ABSENT';key='Software\FutureClassroomTest';view='Registry32'}}
  $values=@($key.GetValueNames());$subkeys=@($key.GetSubKeyNames());Need ($values.Count-le 64 -and $subkeys.Count-le 128) 'PARENT_SNAPSHOT_BOUND'
  $acl=$key.GetAccessControl([Security.AccessControl.AccessControlSections]::Owner -bor [Security.AccessControl.AccessControlSections]::Access)
  @{status='PRESENT';key='Software\FutureClassroomTest';view='Registry32';ownerSid=$acl.GetOwner([Security.Principal.SecurityIdentifier]).Value;securityDescriptor=$acl.GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]::Owner -bor [Security.AccessControl.AccessControlSections]::Access);valueNames=@($values|Sort-Object);subkeyNames=@($subkeys|Sort-Object)}
 }finally{if($null-ne $key){$key.Dispose()};$base.Dispose()}
}

function Inventory {
 Root-Check;$files=@();$dirs=@();$total=0L;$queue=[Collections.Generic.Queue[string]]::new();$queue.Enqueue($c.root)
 while($queue.Count){$dir=$queue.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){
  $attrs=[IO.File]::GetAttributes($p);Need (($attrs-band[IO.FileAttributes]::ReparsePoint)-eq 0) 'INVENTORY_REPARSE'
  $rel=$p.Substring($c.root.Length+1).Replace('\','/')
  if(($attrs-band[IO.FileAttributes]::Directory)-ne 0){$top=($rel-split '/')[0];Need ($top-cin @('instrument-compiler-temp','readback-compiler-temp','positive-positive-raw','early-fail-positive-raw','effect')) 'ONLY_OWN_FIXTURE_SUBDIRECTORIES';$dirs+=$rel;$queue.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256};$total+=$f.bytes}
  Need ($files.Count-le 256 -and $dirs.Count-le 32 -and $total-le 67108864) 'RUNTIME_INVENTORY_BOUND'
 }}
 @{files=$files;directories=$dirs}
}
$who=[Security.Principal.WindowsIdentity]::GetCurrent();try{Need ($who.User.Value-ceq $c.sid) 'EXACT_USER_BEFORE_PARENT_QUERY'}finally{$who.Dispose()};$parentBefore=Parent-State;
Need ($c.nonce-cmatch '^[0-9a-f]{32}$' -and $c.sid-cmatch '^S-1-5-21-') 'NONCE_SID'
$identity=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$identity.User;Need ($sid.Value-ceq $c.sid) 'EXACT_USER'}finally{$identity.Dispose()}
$expected=Join-Path ([IO.Path]::GetFullPath($env:TEMP)) ('FutureClassroom-r79-early-terminal-'+$c.nonce)
Need ($expected-ceq $c.root) 'SPEC_ROOT_MUST_EQUAL_ACTUAL_USER_TEMP_ROOT'
Need (Absent $c.root) 'PREEXISTING_ROOT_REFUSED'
$cursor=[IO.Path]::GetDirectoryName($c.root);while($cursor){Need (([IO.File]::GetAttributes($cursor)-band[IO.FileAttributes]::ReparsePoint)-eq 0) 'NO_ANCESTOR_REPARSE';$cursor=[IO.Path]::GetDirectoryName($cursor)}
[void][IO.Directory]::CreateDirectory($c.root)
$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false)
foreach($who in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($who,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))}
[IO.Directory]::SetAccessControl($c.root,$acl)
$owner=[Text.UTF8Encoding]::new($false).GetBytes("future-classroom-owned-r79-early-terminal-fixture/v1`n")
$f=[IO.File]::Open((Join-Path $c.root '.owner'),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);try{$f.Write($owner,0,$owner.Length);$f.Flush($true)}finally{$f.Dispose()}
Root-Check
@{status='PASS_CREATED_ONLY_PROTECTED_FIXTURE_RUNTIME_ROOT';root=$c.root;nonce=$c.nonce;sid=$c.sid;registryParentBefore=$parentBefore}|ConvertTo-Json -Compress
