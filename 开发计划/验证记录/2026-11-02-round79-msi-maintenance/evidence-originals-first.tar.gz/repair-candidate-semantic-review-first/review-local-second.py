"""Independent local review of frozen second shadow and actual downloaded runtime. No subprocess/network."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,difflib
E=Path('/tmp/fc-round79-msi-maintenance');D=Path(__file__).resolve().parent
FIX=E/'repair-capture-fix-preparation-first';SHADOW=FIX/'candidate-second'
def sha(b):return hashlib.sha256(b).hexdigest()
def rec(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def load(p,pin=None):
 b=p.read_bytes()
 if pin:assert sha(b)==pin,str(p)
 return json.loads(b)
def main():
 first=load(D/'review-first.json','780422af3bbb57631c4d92efca107b1f2fc120ba8645553e4984abaae1c9b7b4')
 frozen=load(FIX/'freeze-first.json','17a07e6ca8425f8ad365323f5e74d2f6194508f0585ee930892d8681dcc2a6da')
 for x in frozen['files']:
  p=FIX/x['path'];f=rec(p);assert f['bytes']==x['bytes'] and f['sha256']==x['sha256']
 cpath=E/'repair-implementation-first/candidate-second/candidate-second.json';c=load(cpath,'86f3e4599d9d11f4313d4c49f572ae35f66f838f86dc4c7678f7b04c8b0d4f68')
 oldroot=E/'repair-candidate-first-original-source';old=load(oldroot/'manifest.json');assert old['sourceCandidateSha256']=='6e4a6df210326a496ef4d5351aed154684e2af4fbb7ea6dfaefab1ee3910d38a'
 for x in old['scope']:
  f=rec(oldroot/x['path']);assert f['bytes']==x['bytes'] and f['sha256']==x['sha256']
 sources=[];diffs=[]
 for x in c['scope']:
  p=SHADOW/x['path'];f=rec(p);assert f['bytes']==x['bytes'] and f['sha256']==x['sha256'];sources.append({**f,'repositoryRelativePath':x['path']})
  a=(oldroot/x['path']).read_text();b=p.read_text();diffs.append(dict(path=x['path'],oldSha256=sha(a.encode()),newSha256=sha(b.encode()),diff=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='frozen-first/'+x['path'],tofile='frozen-second/'+x['path']))))
 assert diffs[0]['oldSha256']==diffs[0]['newSha256'] and diffs[0]['diff']==''
 bdir=E/'repair-candidate-release-build-second';build=load(bdir/'report.json','bbd1635f399846da56dc14788885dd41693c3804ca8c5578d68571858d916acb')
 assert build['status']=='PASS_FC_WINDOWS_ALL_TARGETS_GNU_COMPILE_ONLY' and build['actualReturnCode']==0 and build['originalReaped'] and build['sourceUnchanged'] and not build['budgetExceeded']
 assert build['candidateSha256']==sha(cpath.read_bytes()) and build['budgetSeconds']==900
 for x in build['outputs']:
  f=rec(bdir/x['path']);assert f['bytes']==x['bytes'] and f['sha256']==x['sha256']
 before=load(bdir/'source-before.json');assert before==load(bdir/'source-after.json');bm={x['path']:x for x in before}
 for x in c['scope']:assert bm[x['path']]=={k:x[k] for k in ['path','bytes','sha256']}
 runroot=E/'repair-candidate-native-release-second';rpath=runroot/'report.json';r=load(rpath,'b7736c2044d2e61b6a50acd275be306f98d261921a66c824a232ee8c5e9c0f81')
 assert r['status']=='PASS_CANDIDATE_NATIVE_TESTS_WIN11_ONLY' and r['cleanup']=='PASS_EXACT_DOWNLOADED_OWNED_SCRATCH_ONLY'
 assert r['producer']['sha256']==sha((bdir/'report.json').read_bytes())
 downloaded=list((runroot/'download').iterdir());assert len(downloaded)==1;download=downloaded[0];inv=r['inventory'];filefacts=[]
 assert len(inv['files'])==4
 for x in inv['files']:
  p=download/x['path'];assert p.is_file() and not p.is_symlink();f=rec(p);assert f['sha256']==x['sha256'] and f['bytes']==x['bytes'];filefacts.append(f)
 assert {str(p.relative_to(download)) for p in download.rglob('*') if p.is_file()}=={x['path'] for x in inv['files']}
 assert {str(p.relative_to(download)) for p in download.rglob('*') if p.is_dir()}==set(inv['directories'])=={'compiler-temp','test-temp'}
 assert all(not p.is_symlink() for p in download.rglob('*'))
 native=load(download/'native-result.json');assert native==r['native']==load(runroot/'run.stdout.log')
 assert native['status']=='PASS_FOCUSED_EFFECTS_AND_FULL_LIFECYCLE_NATIVE_TESTS_WIN11_ONLY' and native['originalParentReturned']
 assert native['elapsedMilliseconds']==996 and native['originalWholeSeconds']==600 and len(native['cases'])==2 and len(native['originalObjects'])==2
 assert [x['name'] for x in native['cases']]==['effects','lifecycle']
 expected_tests=c['testsAdded'];assert len(expected_tests)==5
 summaries=[]
 for case,count in zip(native['cases'],[11,46]):
  assert case['actualExit'] and case['exitCode']==0 and case['stderr']==''
  original=case['original'];assert original in native['originalObjects']
  assert original['Pid']==case['pid'] and original['Creation']==case['creation'] and original['Wait']==0 and original['ExitCode']==0 and original['ExitKnown'] is True and original['CheckedClose'] is True and original['Error'] is None
  assert original['Sid']=='S-1-5-21-3896111207-1867804362-1971593122-1001' and original['Sha256']==r['nativeInput']['sha256']
  assert original['Image']==r['windowsRoot']+'\\candidate-tests.exe'
  result=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',case['stdout'])[-1]
  assert tuple(map(int,result[:4]))==(count,0,0,0)
  for name in expected_tests:assert len(re.findall(r'^test .*::'+re.escape(name)+r' \.\.\. ok$',case['stdout'],re.M))==1,name
  assert case['startedWholeMilliseconds']<=case['endedWholeMilliseconds']<=case['originalDeadlineWholeMilliseconds']
  summaries.append(dict(name=case['name'],passed=count,failed=0,original=original,addedFiveExactNamesObserved=list(expected_tests),scope='46 lifecycle includes the11 effects tests; no sum as57 distinct tests'))
 assert rec(download/'candidate-tests.exe')['sha256']==r['nativeInput']['sha256'] and rec(download/'candidate-tests.exe')['bytes']==r['nativeInput']['bytes']==4110237
 assert rec(download/'Capture.cs')['sha256']==r['capture']['sha256']
 assert r['ownedProcessReadback']=={'count':0} and load(runroot/'owned-processes.stdout.log')=={'count':0}
 assert r['delete']['status']=='REMOVED_EXACT_REPAIR_NATIVE_RUNTIME_ROOT' and r['delete']['knownAbsent'] is True
 assert load(runroot/'delete.stdout.log')==r['delete']
 operationfacts=[]
 for op in r['operations']:
  assert op['actualReturnCode']==0 and op['originalLocalReaped'] and not op['budgetExceeded'] and not op['remoteOriginalReturnUnknown']
  for k in ['stdout','stderr']:
   x=op[k];f=rec(Path(x['path']));assert f['bytes']==x['bytes'] and f['sha256']==x['sha256']
  operationfacts.append(dict(name=op['name'],actualReturnCode=op['actualReturnCode'],originalLocalReaped=op['originalLocalReaped'],budgetExceeded=op['budgetExceeded'],remoteOriginalReturnUnknown=op['remoteOriginalReturnUnknown']))
 ptext=(SHADOW/c['scope'][2]['path']).read_text();etext=(SHADOW/c['scope'][1]['path']).read_text()
 assert 'fn parents_pinned(' in ptext and 'if dir != &parent && !parents_pinned(dir, &parent, &directories)' in ptext
 assert 'if !parents_pinned(&path, &parent, &directories)' in ptext
 tail=ptext[ptext.index('// Original missing directories must still be known absent.'):ptext.index('    proof.check()?;',ptext.index('// Original missing directories must still be known absent.'))]
 assert tail.index('owner.add(handle, Role::Parent);')<tail.index('return Err(LifecycleError::Unsettled);') and 'Err(error) if missing(&error)' in tail
 assert '[(false, true), (true, true), (false, false), (true, false)]' in etext
 assert ptext[:ptext.index('fn missing(')]==(oldroot/c['scope'][2]['path']).read_text().split('fn missing(')[0]
 report=dict(schemaVersion=1,status='PASS_INDEPENDENT_SECOND_CAPTURE_FIX_REVIEW_AND_FINITE_WIN11_NATIVE_QUALIFICATION',reviewerScope='Independent review of another agent repair implementation; not unified independent final product/MSI acceptance. Reviewer used only local immutable sources/reports/downloads.',observedAtUtc=datetime.now(timezone.utc).isoformat(),reviewActions='LOCAL_READ_ONLY_NO_CARGO_WINDOWS_NETWORK_OR_SOURCE_CHANGE',closesFinding=dict(id='R79-REPAIR-SEM-01',status='CLOSED_FOR_UNCHECKED_MISSING_ANCESTOR_REGULAR_LEAF_CAPTURE',firstReviewSha256='780422af3bbb57631c4d92efca107b1f2fc120ba8645553e4984abaae1c9b7b4',reason='Directory and leaf paths cannot be traversed through an expected ancestor that was not originally Some and pinned. Such descendants remain conservative None/KnownAbsent, and every original None directory is reopened at end with only2/3 as absence. Unexpected open success enters original Proof ledger before rejection; no hash/ACL trust is granted to it.',anchors=['preimage.rs:66-79','preimage.rs:129-156','preimage.rs:171-178','preimage.rs:215-238']),source=sources,oldFrozenSourcesManifest=rec(oldroot/'manifest.json'),sourceDifferences=diffs,proofPoints=[dict(check='ancestor helper boundary',result='PASS_WITH_PRIVATE_CALLSITE_PRECONDITION',detail='parents_pinned is vacuously true for a path with no parent within boundary. Actual private callsites are only expected directories derived from base or manifest_path(base, validatedRelative), or leaves from that same manifest_path, and boundary is mandatory base.parent Programs. The mandatory Programs directory is opened/verified directly, so neither live callsite reaches the vacuous outside-boundary case. No public arbitrary path caller is introduced.'),dict(check='same_objects/same_effects',result='UNCHANGED',detail='The full original comparison implementation before missing() is byte-identical. Revalidation still requires original directory/leaf IDs and actual bad bytes; semantic rollback still permits replacement IDs but requires same directory presence and exact actual original bad byte lengths/hash/missing leaves, with fresh native registration/marker/ACL/reparse/hardlink policy.'),dict(check='test hook production isolation',result='PASS_STATIC',detail='capture_with_directory_hook, its parameter and the hook invocation are all cfg(test). Production capture invokes capture_inner without a callback parameter. Hook runs after directory capture and exact_names and before any leaf traversal.'),dict(check='deterministic real native coverage',result='ACTUAL_PASS_IN_BOTH_GROUPS',detail='One newly named native test loops four deterministic cases: missing web + recreated leaf; missing root + recreated leaf; missing web + empty recreated directory; missing root + empty recreated directory. Every case requires Unsettled, rename failure while unexpected original directory is pinned, successful explicit checked Proof release and subsequent fixture restoration/recapture. These are four iterations of one test, not four independent reported test cases.'),dict(check='pure ancestor coverage',result='ACTUAL_PASS_IN_BOTH_GROUPS',detail='New traversal helper test accepts complete pinned Programs/base/web and rejects None web, None base and absent Programs map entry. This is one extra pure test, separate from the four-iteration native test.'),dict(check='resource and byte budgets',result='UNCHANGED_LIMITS',detail='No changes to broker.rs:64MiB nonempty normal image digest and private allow-empty preimage digest unchanged. Original6 Proof groups*64,8 process owner slots,72 leaves/closed directory set,30MiB checked aggregate,original120s lifecycle limit remain. Tail probes cover only fixed expected None directories (at most3 product descendants because Programs mandatory), one unexpected successful handle is added before immediate rejection, and uses existing owner rollover/cap/checked release. No new owner pool or native retry loop.'),dict(check='actual reparse coverage limit',result='STATIC_REJECTION_PATH_NO_NEW_REPARSE_INJECTION_CLAIM',detail='The new hook creates ordinary real directories, not junctions/reparse points. The static ancestor gate avoids opening/hash-reading all leaves under any originally absent ancestor regardless of what appears; final unexpected-open branch rejects both real/reparse directory objects without granting their trust. Arbitrary same-user mutation between successive observations or after pin return is not ruled out by these bounded checks.' )],build=dict(report=rec(bdir/'report.json'),status=build['status'],actualExit=0,originalReaped=True,sourceBeforeAfterEqual=True,sourceManifestEntries=len(before),candidateMetadata=rec(cpath),target='i686-pc-windows-gnu',scope='fc-windows release all-targets compile only; not second whole-workspace build or Win7 MSVC product CI',budgetSeconds=900,elapsedSeconds=build['elapsedSeconds']),runtime=dict(report=rec(rpath),originalDownloadedFiles=filefacts,exactFileMembership=4,emptyDirectories=2,nativeResult=rec(download/'native-result.json'),status=r['status'],groups=summaries,distinctTopLevelLifecycleTests=46,effectsRepeatSubset=11,newTestsSinceBaseMain=5,newTestsSinceFirstCandidate=2,nativeElapsedMilliseconds=996,nativeWholeBudgetSeconds=600,transportElapsedSeconds=r['elapsedSeconds'],transportBudgetSeconds=900,retainedTwoParentOriginalControls='KNOWN_WAIT0_EXIT0_CHECKED_CLOSE_IDENTITY_SHA_SID',ownProcessReadback=0,cleanup=r['cleanup'],exactRootDeleteReceipt=r['delete'],operations=operationfacts,scope='Local requalification of recorded exact original parent controls and test outputs. Nested test fixture subprocess controls remain within tested product assertions; no additional external capture is claimed.'),minimalAcceptanceGate=dict(mayPrepareSourcePinnedIsolatedPackagePrototype=True,mayClaimProductionRepairReady=False,mayClaimRealDamagedMsiForcedRepairPassed=False,mayClaimEarlyTerminalAuthorityImplemented=False,next='A package prototype may bind exactly this fixed candidate source/build provenance for static inspection. Before genuine damaged-MSI qualification, prove original MSI early-terminal transaction authority before guardian startup and failure-safe native owner/Pending behavior; then run source-pinned real forced repair and rollback matrix with original controls, exact tree/registration/cache cleanup and no user foreground/account/Run mutation.',actualRealMsiForcedRepair='NOT_RUN',actualOriginalDamagedPreimageMsiRollback='NOT_RUN',earlyTerminalAdapter='NOT_IMPLEMENTED_BY_THIS_CAPTURE_FIX',arbitrarySameUserGlobalFilesystemAtomicity='NOT_CLAIMED',persistentPowerLossRecovery='NOT_IMPLEMENTED_VOLATILE_SNAPSHOT',runPresentOwnership='NOT_IMPLEMENTED_STRICT_ABSENT_ONLY',win7Actual='NOT_RUN',win10Actual='NOT_RUN',win11Hardware='NOT_RUN'),earlierFirstEvidence=dict(firstReviewRetained=True,oldDebugFailure='Preserved actual101/24pass20fail with97328442B debug image above original64MiB limit; second release PASS does not rewrite that failure.',oldFirstRelease44='Not used as new hook proof; current qualification is the exact new11/46 original runtime only.'))
 p=D/'review-second.json'
 with p.open('x') as f:f.write(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(dict(status=report['status'],report=str(p),sha256=sha(p.read_bytes()),sem01='CLOSED_FINITE_SCOPE',newBlockingFindings=0)))
if __name__=='__main__':main()
