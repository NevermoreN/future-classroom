#define FC79_NONCE L"0cc4e2524bb7403f94f6b2bdc8a6888b"
#define FC79_PRODUCT L"{8FD3EE28-C021-4966-8C94-1C89C67408B7}"
#define FC79_EFFECT_DIR L"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-0cc4e2524bb7403f94f6b2bdc8a6888b\\effect\\"
