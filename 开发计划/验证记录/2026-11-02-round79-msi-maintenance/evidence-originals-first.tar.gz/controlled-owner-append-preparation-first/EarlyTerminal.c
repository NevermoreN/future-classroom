#define UNICODE
#define _UNICODE
#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0601
#include <windows.h>
#include <msi.h>
#include <msiquery.h>
#include <sddl.h>
#include <wchar.h>
#include <stdio.h>
#include "fixture_config.h"

/* Test instrumentation only. No production gate, journal, file or registry write.
 * hInstall belongs to MSI and MUST NOT be closed here. A BEFORE_RETURN record is
 * intent, not evidence that the engine has received the return. */
static HMODULE module;
static volatile LONG observation_sequence;
static ULONGLONG ft(FILETIME v) {
    return ((ULONGLONG)v.dwHighDateTime << 32) | v.dwLowDateTime;
}
static UINT property(MSIHANDLE h, LPCWSTR name, WCHAR *out, DWORD cap) {
    DWORD n = cap;
    UINT rc = MsiGetPropertyW(h, name, out, &n);
    if (rc != ERROR_SUCCESS || n >= cap) out[0] = L'\0';
    return rc;
}
static BOOL sid(WCHAR *out, DWORD cap, DWORD *error, BOOL *closed) {
    HANDLE token = NULL;
    BYTE bytes[4096]; DWORD needed = 0;
    LPWSTR text = NULL; BOOL ok = FALSE;
    *closed = TRUE; *error = 0; out[0] = L'\0';
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &token)) {
        *error = GetLastError(); return FALSE;
    }
    if (!GetTokenInformation(token, TokenUser, bytes, sizeof(bytes), &needed)) {
        *error = GetLastError(); goto done;
    }
    if (!ConvertSidToStringSidW(((TOKEN_USER *)bytes)->User.Sid, &text)) {
        *error = GetLastError(); goto done;
    }
    if (wcslen(text) >= cap) { *error = ERROR_INSUFFICIENT_BUFFER; goto done; }
    wcscpy(out, text); ok = TRUE;
done:
    if (text != NULL && LocalFree(text) != NULL) { *error = GetLastError(); ok = FALSE; }
    if (!CloseHandle(token)) { *closed = FALSE; *error = GetLastError(); ok = FALSE; }
    return ok;
}
static BOOL thread_sid(WCHAR *out, DWORD cap, DWORD *error) {
    HANDLE token = NULL; BYTE bytes[4096]; DWORD needed = 0; LPWSTR text = NULL;
    BOOL ok = FALSE; out[0] = L'\0'; *error = 0;
    if (!OpenThreadToken(GetCurrentThread(), TOKEN_QUERY, TRUE, &token)) {
        *error = GetLastError();
        if (*error == ERROR_NO_TOKEN) { wcscpy(out, L"NO_THREAD_TOKEN"); return TRUE; }
        return FALSE;
    }
    if (!GetTokenInformation(token, TokenUser, bytes, sizeof(bytes), &needed)) { *error = GetLastError(); goto done; }
    if (!ConvertSidToStringSidW(((TOKEN_USER *)bytes)->User.Sid, &text)) { *error = GetLastError(); goto done; }
    if (wcslen(text) >= cap) { *error = ERROR_INSUFFICIENT_BUFFER; goto done; }
    wcscpy(out, text); ok = TRUE;
done:
    if (text != NULL && LocalFree(text) != NULL) { *error = GetLastError(); ok = FALSE; }
    if (!CloseHandle(token)) { *error = GetLastError(); ok = FALSE; }
    return ok;
}
static BOOL emit(MSIHANDLE h, LPCWSTR stage, UINT intended, BOOL require_rollback) {
    WCHAR product[80], user[192], actual_sid[192], effective_sid[192], image[1024], dll[1024];
    WCHAR line[4096]; FILETIME pc, pe, pk, pu, tc, te, tk, tu;
    LARGE_INTEGER qpc, frequency;
    DWORD size = 1024, sid_error = 0; BOOL token_closed = FALSE;
    UINT product_rc = property(h, L"ProductCode", product, 80);
    UINT user_rc = property(h, L"UserSID", user, 192);
    BOOL scheduled = MsiGetMode(h, MSIRUNMODE_SCHEDULED);
    BOOL rollback = MsiGetMode(h, MSIRUNMODE_ROLLBACK);
    BOOL commit = MsiGetMode(h, MSIRUNMODE_COMMIT);
    BOOL process_time = GetProcessTimes(GetCurrentProcess(), &pc, &pe, &pk, &pu);
    BOOL thread_time = GetThreadTimes(GetCurrentThread(), &tc, &te, &tk, &tu);
    BOOL image_ok = QueryFullProcessImageNameW(GetCurrentProcess(), 0, image, &size);
    DWORD dll_n = GetModuleFileNameW(module, dll, 1024);
    BOOL sid_ok = sid(actual_sid, 192, &sid_error, &token_closed);
    DWORD thread_sid_error = 0;
    BOOL thread_sid_ok = thread_sid(effective_sid, 192, &thread_sid_error);
    BOOL clock_ok = QueryPerformanceCounter(&qpc) && QueryPerformanceFrequency(&frequency) && frequency.QuadPart > 0;
    BOOL valid = product_rc == 0 && wcscmp(product, FC79_PRODUCT) == 0 &&
        process_time && thread_time && image_ok && dll_n > 0 && dll_n < 1024 && sid_ok && thread_sid_ok && clock_ok &&
        (!require_rollback || rollback);
    if (!image_ok) wcscpy(image, L"UNKNOWN");
    if (dll_n == 0 || dll_n >= 1024) wcscpy(dll, L"UNKNOWN");
    /* All paths/strings are fixture or OS facts; no arbitrary property dump. */
    int n = swprintf(line, 4096,
        L"FC79|nonce=%ls|stage=%ls|sequence=%ld|qpc=%lld|frequency=%lld|pointerBytes=%u|pid=%lu|tid=%lu|processCreation=%llu|threadCreation=%llu|"
        L"scheduled=%d|rollback=%d|commit=%d|productRc=%u|product=%ls|userSidRc=%u|userSid=%ls|"
        L"processSid=%ls|sidError=%lu|tokenClose=%d|threadSid=%ls|threadSidError=%lu|image=%ls|module=%ls|valid=%d|intendedReturn=%u",
        FC79_NONCE, stage, InterlockedIncrement(&observation_sequence), clock_ok ? qpc.QuadPart : 0, clock_ok ? frequency.QuadPart : 0, (UINT)sizeof(void *), GetCurrentProcessId(), GetCurrentThreadId(),
        process_time ? ft(pc) : 0, thread_time ? ft(tc) : 0,
        scheduled, rollback, commit, product_rc, product, user_rc, user,
        actual_sid, sid_error, token_closed, effective_sid, thread_sid_error, image, dll, valid, intended);
    if (n < 0 || n >= 4096) return FALSE;
    MSIHANDLE record = MsiCreateRecord(0);
    if (record == 0) return FALSE;
    UINT set = MsiRecordSetStringW(record, 0, line);
    int sent = set == 0 ? MsiProcessMessage(h, INSTALLMESSAGE_INFO, record) : -1;
    UINT close = MsiCloseHandle(record);
    return valid && set == 0 && sent != -1 && close == 0;
}
static UINT action(MSIHANDLE h, LPCWSTR stage, UINT result, BOOL rollback) {
    BOOL entered = emit(h, stage, result, rollback);
    WCHAR before[96];
    int n = swprintf(before, 96, L"BEFORE_RETURN_%ls", stage);
    BOOL leaving = n > 0 && n < 96 && emit(h, before, entered ? result : ERROR_INSTALL_FAILURE, rollback);
    return entered && leaving ? result : ERROR_INSTALL_FAILURE;
}
__declspec(dllexport) UINT __stdcall Fc79Prepare(MSIHANDLE h) {
    WCHAR path[1024]; DWORD n = 1024;
    UINT rc = MsiGetTargetPathW(h, L"EffectDir", path, &n);
    /* Directory target is a fact; it never selects where this DLL writes. */
    if (rc != 0 || n >= 1024 || _wcsicmp(path, FC79_EFFECT_DIR) != 0)
        return action(h, L"PREPARE_TARGET_REJECTED", ERROR_INSTALL_FAILURE, FALSE);
    return action(h, L"PREPARE", ERROR_SUCCESS, FALSE);
}
__declspec(dllexport) UINT __stdcall Fc79Rollback(MSIHANDLE h) {
    return action(h, L"ROLLBACK", ERROR_SUCCESS, TRUE);
}
__declspec(dllexport) UINT __stdcall Fc79ForceFail(MSIHANDLE h) {
    return action(h, L"FORCE_FAIL", ERROR_INSTALL_FAILURE, FALSE);
}
__declspec(dllexport) UINT __stdcall Fc79TerminalSuccess(MSIHANDLE h) {
    return action(h, L"TERMINAL_SUCCESS", ERROR_SUCCESS, FALSE);
}
__declspec(dllexport) UINT __stdcall Fc79TerminalCancel(MSIHANDLE h) {
    return action(h, L"TERMINAL_CANCEL", ERROR_SUCCESS, FALSE);
}
__declspec(dllexport) UINT __stdcall Fc79TerminalFailure(MSIHANDLE h) {
    return action(h, L"TERMINAL_FAILURE", ERROR_SUCCESS, FALSE);
}
BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID reserved) {
    (void)reserved;
    if (reason == DLL_PROCESS_ATTACH) module = instance;
    return TRUE;
}
