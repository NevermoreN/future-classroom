#!/usr/bin/env python3
"""Local-only producer. Inert unless --execute; no SSH or Windows commands."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time
import uuid
import xml.etree.ElementTree as ET

HERE=Path(__file__).resolve().parent
MARKER='future-classroom-owned-r79-early-terminal-fixture/v1\n'
SOURCES=('Owner.c','Invoke-ControlledOwner.ps1','Capture.cs','EarlyTerminal.c','fixture-original.py','build.py','tools.json','child-environment.json')
def need(v,w):
    if not v: raise ValueError(w)
def raw(p):
    need(p.is_file() and not p.is_symlink(),'regular original');b=p.read_bytes();need(len(b)<=32*1024*1024,'file bound');return b
def sha(b):return hashlib.sha256(b).hexdigest()
def fact(p):
    b=raw(p);return {'bytes':len(b),'sha256':sha(b)}
def new(p,v):
    with p.open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2,ensure_ascii=True);f.write('\n')
def main():
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('--execute',action='store_true');a.add_argument('--output',type=Path);v=a.parse_args()
    if not v.execute:print(json.dumps({'status':'PREPARED_NOT_RUN','windows':'NOT_RUN'}));return
    need(v.output and v.output.is_absolute() and not v.output.exists(),'fresh absolute output');out=v.output;out.mkdir()
    module=importlib.util.spec_from_file_location('original_fixture',HERE/'fixture-original.py');f=importlib.util.module_from_spec(module);module.loader.exec_module(f)
    sources={p:fact(HERE/p) for p in SOURCES};tools=json.loads(raw(HERE/'tools.json'));env=os.environ.copy();env.update(json.loads(raw(HERE/'child-environment.json')))
    need(set(tools)=={'gcc','objdump','wixl','msibuild','msiinfo','msiextract'},'six pinned tools')
    for name,item in tools.items():need(fact(Path(item['path']))['sha256']==item['sha256'],'pinned tool '+name)
    nonce=uuid.uuid4().hex;root='FutureClassroom-r79-early-terminal-'+nonce;win='C:\\Users\\Elior\\AppData\\Local\\Temp\\'+root
    spec={'schemaVersion':1,'status':'PREPARED_NOT_RUN','nonce':nonce,'rootName':root,'windowsRoot':win,'effectDir':win+'\\effect\\','marker':MARKER,'expectedUserSid':'S-1-5-21-3896111207-1867804362-1971593122-1001','registryKey':'Software\\FutureClassroomTest\\Round79-'+nonce,'wholeSeconds':600,'nativeSeconds':120,'clientSeconds':120,'finallyReserveSeconds':180,'maximumHandles':64,'maximumOwners':8,'sourceGit':'c44906517fbc62233dca755d7225cea375264cbc','scope':'FRESH_INDEPENDENT_ORIGINAL_BEGIN_API_OWNER_NOT_PRODUCTION_AUTHORITY','sources':sources}
    for k in ('productCode','upgradeCode','componentId'):spec[k]='{'+str(uuid.uuid4()).upper()+'}'
    new(out/'spec.json',spec);(out/'.owner').write_text(MARKER,encoding='ascii')
    report={'status':'FAIL_STATIC_ONLY','windows':'NOT_RUN','spec':fact(out/'spec.json'),'commands':[],'cases':{},'sourceOriginalGenerator':fact(HERE/'fixture-original.py'),'changesFromOriginalGenerator':['fresh independent nonce/product/component/upgrade and payload','no PositiveChainer Binary and no MsiEmbeddedChainer table','new original Begin API Owner.exe independently compiled','same six original observer actions and force-fail placement'],'priorRuntimeCounterexample':{'path':'/tmp/fc-round79-msi-maintenance/early-terminal-runtime-first/runtime-operation.json','sha256':'d8893598f781188b0b8b3e2655ecaf90dd8fc5b1317f6e46980e1bd2d20f9bdb','finding':'client0 and TERMINAL_SUCCESS -1 coexisted with actual Join0 EndRollback0 and final absent; not transaction commit proof'}}
    deadline=time.monotonic()+600
    def run(label,args):
        left=deadline-time.monotonic();need(left>0,'600s local producer');start=time.monotonic()
        p=subprocess.run(args,cwd=out,env=env,timeout=min(120,left),stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
        (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr)
        report['commands'].append({'label':label,'argv':args,'actualExit':p.returncode,'parentReaped':True,'seconds':time.monotonic()-start,'stdoutSha256':sha(p.stdout),'stderrSha256':sha(p.stderr)})
        need(p.returncode==0,'actual local tool failure '+label);return p.stdout
    try:
        for name in ('Owner.c','EarlyTerminal.c','Capture.cs','Invoke-ControlledOwner.ps1'):shutil.copyfile(HERE/name,out/name)
        escaped=lambda s:json.dumps(s,ensure_ascii=True)
        (out/'fixture_config.h').write_text('#define FC79_NONCE L'+escaped(nonce)+'\n#define FC79_PRODUCT L'+escaped(spec['productCode'])+'\n#define FC79_EFFECT_DIR L'+escaped(spec['effectDir'])+'\n',encoding='ascii')
        config={'FC_OWNER_ROOT':win,'FC_OWNER_PRODUCT':spec['productCode'],'FC_OWNER_EARLY_MSI':win+'\\early-fail.msi','FC_OWNER_HEALTHY_MSI':win+'\\healthy.msi'}
        (out/'owner_config.h').write_text(''.join('#define '+k+' L'+escaped(val)+'\n' for k,val in config.items())+'#define FC_OWNER_NONCE '+escaped(nonce)+'\n',encoding='ascii')
        payload=('FutureClassroom isolated R79 fixture '+nonce+'\n').encode('ascii');(out/'payload.txt').write_bytes(payload)
        run('01-gcc-owner',[tools['gcc']['path'],'-std=c11','-O2','-Wall','-Wextra','-Werror','-municode','-mwindows','-Wl,--subsystem,windows:6.1','-o','Owner.exe','Owner.c','-lmsi','-lshell32'])
        f.pe(raw(out/'Owner.exe'));report['owner']=fact(out/'Owner.exe')
        run('02-gcc-observer',[tools['gcc']['path'],'-std=c11','-O2','-Wall','-Wextra','-Werror','-shared','-Wl,--kill-at','-o','EarlyTerminal.dll','EarlyTerminal.c','-lmsi','-ladvapi32'])
        f.pe(raw(out/'EarlyTerminal.dll'),True);report['observer']=fact(out/'EarlyTerminal.dll');report['payload']=fact(out/'payload.txt')
        exports=run('03-observer-exports',[tools['objdump']['path'],'-p','EarlyTerminal.dll']).decode();need(sorted(re.findall(r'^\s*\[\s*[0-9]+\]\s+(Fc79\w+)\s*$',exports,re.M))==sorted(f.EXPORTS),'exact observer exports')
        ca=[('Fc79Prepare','1','ObserverDll','Fc79Prepare'),('Fc79Rollback','1281','ObserverDll','Fc79Rollback'),('Fc79ForceFail','1','ObserverDll','Fc79ForceFail')]+[('Fc79Terminal'+r,'1','ObserverDll','Fc79Terminal'+r) for r in ('Success','Cancel','Failure')]
        (out/'CustomAction.idt').write_bytes(f.encoded_idt('CustomAction',['Action','Type','Source','Target'],['s72','i2','S72','S255'],['Action'],ca))
        for case,force in (('healthy','0'),('early-fail','1')):
            tree=ET.fromstring(f.wxs(spec,case));ns='{http://schemas.microsoft.com/wix/2006/wi}';product=tree.find(ns+'Product')
            for binary in list(product.findall(ns+'Binary')):
                if binary.attrib['Id']=='PositiveChainer':product.remove(binary)
            (out/(case+'.wxs')).write_bytes(ET.tostring(tree,encoding='utf8',xml_declaration=True))
            run(case+'-wixl',[tools['wixl']['path'],'-a','x86','-o',case+'.msi',case+'.wxs'])
            seq=f.idt(run(case+'-base-sequence',[tools['msiinfo']['path'],'export',case+'.msi','InstallExecuteSequence']),'InstallExecuteSequence')
            extra=[('Fc79Prepare','NOT Installed','1499'),('Fc79Rollback','NOT Installed','1501'),('Fc79ForceFail',force+' AND NOT Installed','6501'),('Fc79TerminalSuccess','NOT Installed','-1'),('Fc79TerminalCancel','NOT Installed','-2'),('Fc79TerminalFailure','NOT Installed','-3')]
            allseq=[tuple(r[k] for k in ('Action','Condition','Sequence')) for r in seq]+extra
            (out/'InstallExecuteSequence.idt').write_bytes(f.encoded_idt('InstallExecuteSequence',['Action','Condition','Sequence'],['s72','S255','i2'],['Action'],allseq))
            run(case+'-import',[tools['msibuild']['path'],case+'.msi','-q','DROP TABLE `CustomAction`','-q','DROP TABLE `InstallExecuteSequence`','-i','CustomAction.idt','-i','InstallExecuteSequence.idt'])
            code=f.package_code(spec,case);run(case+'-summary-write',[tools['msibuild']['path'],case+'.msi','-s','FC R79 controlled owner fixture','FutureClassroomTest','Intel;1033',code])
            summary=run(case+'-summary',[tools['msiinfo']['path'],'suminfo',case+'.msi']).decode();need(code in summary and 'Intel;1033' in summary and re.search(r'Version:\s+500\b',summary),'actual package summary')
            tables=run(case+'-tables',[tools['msiinfo']['path'],'tables',case+'.msi']).decode().splitlines();need('MsiEmbeddedChainer' not in tables,'no chainer schema')
            rows={}
            allowed={'Property','Directory','Feature','Component','FeatureComponents','File','Media','Registry','Binary','CustomAction','InstallExecuteSequence','InstallUISequence','AdminExecuteSequence','AdminUISequence','AdvtExecuteSequence','LaunchCondition','Upgrade','Error','ServiceInstall','AppSearch','Shortcut','ActionText','IniFile','RemoveFile','RemoveIniFile','Signature','ServiceControl','RegLocator','MsiFileHash','Icon','CreateFolder','_SummaryInformation','_ForceCodepage'}
            need(set(tables)<=allowed,'closed tables')
            for table in tables:
                if not table.startswith('_'):rows[table]=f.idt(run(case+'-table-'+table,[tools['msiinfo']['path'],'export',case+'.msi',table]),table)
            need(rows['Binary']==[{'Name':'ObserverDll','Data':'Binary.ObserverDll'}],'one observer Binary only')
            need(run(case+'-binary-readback',[tools['msiinfo']['path'],'extract',case+'.msi','Binary.ObserverDll'])==raw(out/'EarlyTerminal.dll'),'exact observer Binary bytes')
            need(sorted(rows['CustomAction'],key=lambda x:x['Action'])==sorted([dict(zip(('Action','Type','Source','Target'),r)) for r in ca],key=lambda x:x['Action']),'six exact actions')
            need(sorted(rows['InstallExecuteSequence'],key=lambda x:x['Action'])==sorted([dict(zip(('Action','Condition','Sequence'),r)) for r in allseq],key=lambda x:x['Action']),'exact sequence')
            need(len(rows['Component'])==len(rows['Registry'])==len(rows['File'])==len(rows['FeatureComponents'])==1,'one effect component')
            need(rows['Component'][0]['ComponentId']==spec['componentId'] and rows['Component'][0]['Attributes']=='4' and rows['Component'][0]['KeyPath']=='FixtureMarker','HKCU32 key path')
            need(rows['Registry']==[{'Registry':'FixtureMarker','Root':'1','Key':spec['registryKey'],'Name':'Marker','Value':'#1','Component_':'FixtureComponent'}],'one exact marker')
            props={r['Property']:r['Value'] for r in rows['Property']};need(props['ProductCode']==spec['productCode'] and props['UpgradeCode']==spec['upgradeCode'] and 'ALLUSERS' not in props,'fresh peruser identity')
            dirs={r['Directory']:r['DefaultDir'].split('|')[-1] for r in rows['Directory']};need(dirs=={'TARGETDIR':'SourceDir','TempFolder':'.','FixtureRoot':root,'EffectDir':'effect'},'fresh closed directory tree')
            for t in ('Upgrade','ServiceInstall','ServiceControl','AppSearch','Shortcut','IniFile','RemoveFile','RemoveIniFile','Signature','RegLocator','Icon','CreateFolder'):need(not rows.get(t),'no extra effect '+t)
            extracted=out/(case+'-extracted');extracted.mkdir();run(case+'-extract',[tools['msiextract']['path'],'-C',str(extracted),case+'.msi']);files=[p for p in extracted.rglob('*') if p.is_file()];need(len(files)==1 and files[0].name=='payload.txt' and raw(files[0])==payload,'one exact cabinet payload')
            report['cases'][case]={'msi':fact(out/(case+'.msi')),'packageCode':code,'tables':rows}
        report['sourcesUnchanged']=all(fact(HERE/k)==val for k,val in sources.items());report['toolsUnchanged']=all(fact(Path(t['path']))['sha256']==t['sha256'] for t in tools.values());need(report['sourcesUnchanged'] and report['toolsUnchanged'],'immutable inputs');report['status']='PASS_STATIC_ONLY_WINDOWS_NOT_RUN'
    finally:new(out/'build-report.json',report)
    stage=out/'stage';stage.mkdir()
    for name in ('.owner','spec.json','Owner.exe','EarlyTerminal.dll','payload.txt','healthy.msi','early-fail.msi','build-report.json','Capture.cs','Invoke-ControlledOwner.ps1'):shutil.copyfile(out/name,stage/name)
    new(stage/'runtime-inputs.json',{'status':'PREPARED_RUNTIME_NOT_RUN','specSha256':fact(stage/'spec.json')['sha256'],'buildReportSha256':fact(stage/'build-report.json')['sha256'],'files':[{'path':p.name,**fact(p)} for p in sorted(stage.iterdir())]})
    print(json.dumps({'status':'PASS_LOCAL_PREPARATION_ONLY_WINDOWS_NOT_RUN','spec':spec,'manifest':fact(stage/'runtime-inputs.json'),'stage':str(stage)},indent=2))
if __name__=='__main__':main()
