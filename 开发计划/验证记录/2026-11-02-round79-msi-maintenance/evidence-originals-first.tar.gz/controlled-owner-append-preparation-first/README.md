Local-only one-line logging correction. Windows NOT_RUN.
Use build-output-first/stage only.
MsiEnableLog APPEND|FLUSHEACHLINE preserves log segments across Begin/Install/End.
Each fresh-case log path does not pre-exist; no old log or namespace is reused.
The original missing-callback failures remain unchanged. Install1603 proves an API return, not whether the package action did or did not execute.
Actual ForceFail/rollback callback log checks remain required and unchanged.
Root alone executes Windows; no production authority, Pending or permissions changed.
