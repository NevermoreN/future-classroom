#define FC79_NONCE L"fceb9af5ba8149cdabdc382c6615fc3d"
#define FC79_PRODUCT L"{84F4D11C-B62B-46B4-9F74-E48E88AABC46}"
#define FC79_EFFECT_DIR L"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-fceb9af5ba8149cdabdc382c6615fc3d\\effect\\"
