# Transaction ID / post-End close6: finite API correction

The first controlled-owner execution remains **FAIL**. Its actual facts were
Begin0, Install1603, EndRollback0, MsiCloseHandle(transaction value1)=6,
event CloseHandle0, original process/native thread exit76 and exact effects
absent. The original close6 is ERROR_INVALID_HANDLE and is never reclassified
as a successful checked close. Its MSI log contains no demonstrated ForceFail
or rollback callback, so it also does not prove the intended post-script failure.

## What the primary sources establish

Microsoft's Begin API defines the output as a transaction identifier represented
using MSIHANDLE. End is the operation that ends that transaction; it acts on the
calling owner's transaction, with no ID argument. CloseHandle's MSI counterpart
is for open installation handles. Its documented supplying-function list omits
Begin, but that omission alone does not prove every lifetime rule. The pages do
not explicitly state the precise validity of the identifier after End.

Pinned WiX source commit `0889c234aaf3479055b43eceaa10820cf9716cfa` supplies
useful, limited implementation corroboration. Burn's MsiEngineBeginTransaction
uses ordinary MSIHANDLE/HANDLE output variables, never additionally MsiClose's
the ID, and comments that End is assumed to clean the handles. WiuBeginTransaction
enables logging before Begin. This is project implementation/assumption, not a
Microsoft normative lifetime guarantee. Burn's assumption also cannot authorize
ignoring a genuinely owned event: this project's original event close0 remains
independently required and observed.

The same WiX repository's DTF Transaction derives from InstallerHandle, and its
generic MsiHandle.ReleaseHandle calls MsiCloseHandle and returns a boolean from
rc==0. This conflicts with a categorical assertion that every Begin identifier
must never appear at Close. Therefore this investigation makes **no** such broad
claim and does not present DTF/Burn as a definitive proof of internal MSI types.

The narrow interpretation consistent with the APIs and measured close6 is:
after the owner's actual End0, the value is no longer an open installation handle
that an additional MsiCloseHandle can successfully close. It is an inference,
not proof that Begin's value was never locally represented by a handle before
End. No public query locating its internal handle class was found in this finite
search. Microsoft Windows-classic-samples search for Begin yielded no sample.

## New finite experiment's ownership contract

The next preparation classifies this resource as `TransactionId`, whose required
completion is the actual original owner's End0. It does not acquire or invent a
separate local installation handle from that ID, and it does not issue an extra
post-End MsiCloseHandle. Its ledger explicitly records
`TRANSACTION_ID_NO_INSTALL_HANDLE_CLOSE` with attempted=false and return sentinel
4294967295; this is a source-policy record, **not an API return or Close0**.
The separate event remains an owned kernel capability with one actual checked
CloseHandle. The parent retains independently captured original process/thread
objects until physical exit and checked close. Existing real installation handles
created inside the observer, including MsiCreateRecord results, continue using
their documented same-thread MsiCloseHandle and actual return checking unchanged.

Begin/Install/End errors, event close errors, journal-close errors, original
object loss/timeouts, incomplete callback/log scenario or reconciliation failure
remain negative. No MsiCloseAllHandles, retry close, shared-service death,
transaction adoption or flags pretending success are introduced. No experimental
change clears production Pending. The old FAIL remains immutable.

MsiSetInternalUI(NONE) and MsiEnableLog now execute and record before Begin, so
the original engine log captures Begin/Install/End and avoids changing those
settings after a transaction is already created. Four cases retain 600/120/180
seconds, 300-second new-owner cutoff and original 64/8 limits. Fresh namespace
and fresh GUIDs are generated; old namespace remains root's cleanup responsibility.

The intended early-failure case requires original valid1 native PREPARE,
FORCE_FAIL with intended1603/rollback0, and ROLLBACK with actual rollback1, matching
the exact fresh product/nonce, plus actual Install1603, actual EndRollback0 and
effects absence. A mere Install1603 is rejected. Healthy controls require actual
Install0 and an original PREPARE record. Formal fourth-case uninstall still needs
this run's exact successful commit provenance. Callback evidence proves exercised
scenario only; it does not replace owner End or original process capabilities.

## Sources inspected

- [Microsoft Begin](https://learn.microsoft.com/en-us/windows/win32/api/msi/nf-msi-msibegintransactionw)
- [Microsoft End](https://learn.microsoft.com/en-us/windows/win32/api/msi/nf-msi-msiendtransaction)
- [Microsoft installation handle close](https://learn.microsoft.com/en-us/windows/win32/api/msi/nf-msi-msiclosehandle)
- [Pinned WiX Burn transaction owner](https://github.com/wixtoolset/wix/blob/0889c234aaf3479055b43eceaa10820cf9716cfa/src/burn/engine/msiengine.cpp)
- [Pinned WiX native API wrapper](https://github.com/wixtoolset/wix/blob/0889c234aaf3479055b43eceaa10820cf9716cfa/src/libs/dutil/WixToolset.DUtil/wiutil.cpp)
- [Pinned WiX DTF Transaction](https://github.com/wixtoolset/wix/blob/0889c234aaf3479055b43eceaa10820cf9716cfa/src/dtf/WixToolset.Dtf.WindowsInstaller/Transaction.cs)
- [Pinned WiX DTF handle](https://github.com/wixtoolset/wix/blob/0889c234aaf3479055b43eceaa10820cf9716cfa/src/dtf/WixToolset.Dtf.WindowsInstaller/Handle.cs)
- [Pinned WiX DTF native handle release](https://github.com/wixtoolset/wix/blob/0889c234aaf3479055b43eceaa10820cf9716cfa/src/dtf/WixToolset.Dtf.WindowsInstaller/NativeMethods.cs)

Original source files/derived excerpt and Microsoft SDK documentation markdown
are preserved alongside this note. This is limited research and a local-only
candidate, not a claim of completed product repair or Windows compatibility.
