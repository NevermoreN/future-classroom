"""Author-side local qualification of immutable original R79 runtime records only."""
from pathlib import Path
import hashlib,json,collections,re
E=Path('/tmp/fc-round79-msi-maintenance');D=Path(__file__).resolve().parent
REPORT=E/'product-negative-runtime-first/report.json';EXPECTED='0e4a2f4b24d594690e5f6278e1e622dee1c1d1f47bd633e9aa5954e6b16f637b'
def need(v,c):
 if not v:raise AssertionError(c)
def sha(b):return hashlib.sha256(b).hexdigest()
def fact(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def object_id(f):return (f['Volume'],f['IndexHigh'],f['IndexLow'])
def same_object(a,b):return object_id(a)==object_id(b) and a['Creation']==b['Creation'] and a['Links']==b['Links']==1
def file_equal(a,b):return a==b
need(fact(REPORT)['sha256']==EXPECTED,'exact original runtime report')
j=json.loads(REPORT.read_text());r=j['phaseResult'];download=REPORT.parent/'download';roots=list(download.iterdir());need(len(roots)==1 and roots[0].is_dir() and not roots[0].is_symlink(),'exact single local downloaded root');root=roots[0]
# Local replay of every actual remote inventory member; no remote filesystem
# query is made and this script has no subprocess/network/Windows entrypoint.
inventory=j['remoteInventory'];expected={x['path']:x for x in inventory['files']};actual={};dirs=set()
for p in root.rglob('*'):
 need(not p.is_symlink(),'local originals no aliases');name=p.relative_to(root).as_posix()
 if p.is_dir():dirs.add(name)
 else:
  f=fact(p);actual[name]=dict(path=name,bytes=f['bytes'],sha256=f['sha256'])
need(actual==expected and dirs==set(inventory['directories']),'every downloaded raw original exact byte/member match')
need(json.loads((root/'phase-runner-result.json').read_text(encoding='utf-8-sig'))==r,'downloaded native receipt equals original native stdout DTO')
config=json.loads((root/'candidate-inputs.json').read_text(encoding='utf-8-sig'));need(config['sourceGit']=='261c58aca8b0f63ff2cfb4dbd5e85c0d17770005' and config['target']=='i686-win7-windows-msvc','original compiled normal artifact identity')
freeze=E/'negative-fixture-preparation-third/freeze-third.json';f=json.loads(freeze.read_text());need(fact(freeze)['sha256']=='22dd1a3f71172b8ab2bb1c794b344f127c2c5afa855b7e887adeb844b8c61fa2','exact third fixture freeze')
source_rows=[x for x in f['files'] if Path(x['path']).suffix in ('.cs','.ps1')];need(j['sourceInputs']==source_rows,'runtime source closure matches third freeze')
for row in source_rows:
 name=Path(row['path']).name;need(actual[name]['bytes']==row['bytes'] and actual[name]['sha256']==row['sha256'],'uploaded third source bytes exact')
manifest=json.loads((root/'runtime-inputs.json').read_text(encoding='utf-8-sig'));need(len(manifest['files'])==9,'nine uploaded files');need(all(actual[row['path']]==row for row in manifest['files']),'all nine uploaded manifest originals exact')
need(j['sourceUnchanged'] is True and j['phaseParentExit']==0 and j['controllerReturned'] is True,'original parent/controller actual returns')
need(j['status']=='PASS_PRODUCT_MSI_RUNTIME_CAPTURE_AND_EXACT_SCRATCH_CLEANUP_WIN11_ONLY' and j['cleanup']=='PASS_EXACT_DOWNLOADED_OWNED_SCRATCH_ONLY' and j['cleanupActual']['knownAbsent'] is True,'reported original exact scratch cleanup')
phases=r['phases'];need([p['kind'] for p in phases]==['Fresh','Reject','Reject','Reject','Uninstall'],'exact actual phase order');need([p['client']['exitCode'] for p in phases]==[0,1603,1603,1603,0],'actual expected client exits')
controls=[];phaseStats=[];identitySet=set();helperPaths=set();allNative=[]
for index,p in enumerate(phases):
 name=p['name'];c=p['client'];need(c['started'] and c['actualExit'] and c['pipesComplete'] and not c['timedOut'],'actual original client return/pipes')
 raw=json.loads((root/(name+'-phase.json')).read_text(encoding='utf-8-sig'));need(raw==p,'original phase file equals reported actual row')
 snap=p['observerFinal'];need(snap['WmiStarted'] and snap['Closed'] and not snap['Errors'] and not snap['MetadataWarnings'] and not snap['CaptureWarnings'],'actual observer closed with no warnings or errors')
 frames=[json.loads(line) for line in (root/(name+'-original-observer.jsonl')).read_text(encoding='utf-8-sig').splitlines() if line];need(frames and frames[-1]==snap,'original final JSONL frame exact native final')
 facts=snap['Processes'];byRole=collections.defaultdict(list)
 for q in facts:
  key=(q['Pid'],q['CreationFiletime']);need(key not in identitySet,'unique original process object');identitySet.add(key);byRole[q['Role']].append(q)
  need(q['IdentityStatus']=='ORIGINAL_QUERY_SYNC_HANDLE_EXACT_IMAGE_BYTES_USER' and q['Sha256']==config['embeddedHelper']['sha256'] and q['Sid']==config['expectedUserSid'],'original handle image/SHA/user identity')
  need(q['ActualWait']==0 and q['ExitStatus']=='ACTUAL_ORIGINAL_GET_EXIT_CODE' and q['CloseStatus']=='CHECKED_CLOSE_SUCCESS','actual original wait/getExit/checkedClose')
  need(q['ActualExitCode']==(1603 if p['kind']=='Reject' else 0),'exact original expected control exit')
  need(q['CommandStatus']=='EXACT_ORIGINAL_HANDLE_NT_CLASS60_FACT_ONLY' and q['NativeCommandNtStatus']==q['NativeBasicNtStatus']==0 and q['NativeCommandBufferFreeStatus']==q['NativeBasicBufferFreeStatus']=='CHECKED_LOCALFREE_SUCCESS','actual original native metadata statuses and checked frees')
  need(q['NativeBasicPid']==q['Pid'] and q['NativeBasicParentPid']==q['ParentPid'],'actual original PBI PID/parent consistency')
  argv=q['ExactCandidateArgv'];need(argv[0].lower()==q['Image'].lower(),'actual original argv0 image')
  role=q['Role']
  if role=='begin':need(len(argv)==3 and argv[1]=='begin' and argv[2].lower().endswith('\\programs\\futureclassroom\\fc-bootstrap.exe') and q['ParentLink']=='ORIGINAL_ENGINE_INSTANCE_FACT_NOT_SESSION_ID','original Begin actual argv and engine fact')
  elif role=='broker':need(argv==[q['Image'],'broker'],'original broker actual argv')
  else:need(len(argv)==3 and argv[2]==role and int(argv[1])==q['Transaction']>0,'actual transaction role argv')
  helperPaths.add(q['Image']);allNative.append(q)
  controls.append(dict(phase=name,pid=q['Pid'],creationFiletime=q['CreationFiletime'],role=role,actualWait=q['ActualWait'],actualExitCode=q['ActualExitCode'],checkedClose=q['CloseStatus'],commandStatus=q['CommandStatus'],parentPid=q['ParentPid'],parentCreationFiletime=q['ParentCreationFiletime'],parentLink=q['ParentLink'],image=q['Image'],imageSha256=q['Sha256']))
 if p['kind']=='Reject':
  need(len(facts)==1 and set(byRole)=={'begin'} and p['ownerProof']['noBrokerCreated']=='NOT_CLAIMED_FROM_MISSING_OBSERVATION','negative profile does not fabricate four-role coverage/no-broker claim')
  need(p['helperImageCleanup']['status']=='PASS_CAPTURED_REJECT_IMAGE_AUTOMATIC_ABSENCE' and p['helperImageCleanup']['brokerImageKnownAbsent'] is None,'actual negative image scope')
 else:
  need(set(byRole)=={'begin','broker','supervisor','guardian'} and all(len(x)==1 for x in byRole.values()),'positive exact four roles')
  a,b,s,g=[byRole[x][0] for x in ('begin','broker','supervisor','guardian')]
  need(b['ParentPid']==a['Pid'] and b['ParentCreationFiletime']==a['CreationFiletime'] and b['ParentLink']=='HELD_ORIGINAL_BEGIN_INSTANCE' and b['Image'].lower()==a['Image'].lower(),'actual original broker→Begin link/image')
  need(a['ParentPid']==s['ParentPid'] and a['ParentCreationFiletime']==s['ParentCreationFiletime'] and a['ParentImage'].lower()==s['ParentImage'].lower() and a['ParentSid']==s['ParentSid'],'same original engine object facts')
  need(g['ParentPid']==s['Pid'] and g['ParentCreationFiletime']==s['CreationFiletime'] and g['ParentLink']=='HELD_ORIGINAL_SUPERVISOR_INSTANCE' and g['Transaction']==s['Transaction'] and g['Image'].lower()==s['Image'].lower(),'actual original guardian→supervisor transaction/image link')
  need(p['helperImageCleanup']['status']=='PASS_PRECISE_HELPER_IMAGE_AUTOMATIC_ABSENCE' and p['helperImageCleanup']['brokerImageKnownAbsent'],'positive actual image retirement receipt')
 need(p['ownerProof']['knownControlsReturned'] and p['ownerProof']['complete'] and not p['ownerProof']['returnProblems'] and not p['ownerProof']['coverageProblems'],'actual role-scope proof complete')
 need(p['helperImageCleanup']['allCapturedImagesKnownAbsent'] and all(x['status']=='KNOWN_ABSENT' for x in p['helperImageCleanup']['images']),'every exact captured helper image observed absent')
 phaseStats.append(dict(name=name,kind=p['kind'],clientOriginalPid=c['pid'],clientActualExitCode=c['exitCode'],capturedOriginalControls=len(facts),roles=dict(collections.Counter(q['Role'] for q in facts)),originalObserverFrames=len(frames),captureWarnings=len(snap['CaptureWarnings']),metadataWarnings=len(snap['MetadataWarnings']),startWholeMilliseconds=p['startWholeMilliseconds'],endWholeMilliseconds=p['endWholeMilliseconds'],phaseOriginalBudgetMilliseconds=p['phaseBudgetMilliseconds']))
need(len(controls)==11 and len(helperPaths)==7,'eleven original controls and seven helper image paths')
caseStats=[];totalBeforeAfter=0;unchangedRemaining=0
for c in r['negativeCases']:
 k=c['kind'];m=c['mutation'];need(c['status']=='PASS_EXPECTED_REJECTION_AND_PRESERVED_PREIMAGE_WITH_EXACT_FIXTURE_RESTORE' and c['fixtureRestoration']=='EXACT_OWNED_FIXTURE_RESTORED_NOT_MSI_REPAIR' and m['RestorationComplete'] and not m['NativeCloseUnknown'],'actual synthetic restoration qualification')
 need(m['Kind']==k and m['Phase']=='RESTORED_FIXTURE_NOT_MSI_REPAIR','final actual mutation scope')
 before={x['Path']:x for x in m['OriginalTree']};applied={x['Path']:x for x in m['BeforeMsiTree']};after={x['Path']:x for x in m['AfterMsiTree']};restored={x['Path']:x for x in m['RestoredTree']};resource=m['FixedResource'];extra=m['ExtraPath']
 need(len(before)==len(restored)==14 and before[resource]==m['Original'],'actual original fourteen files')
 need(applied==after,'every pre/post rejected-MSI tree file identity/hash/write/attrs exactly unchanged');totalBeforeAfter+=len(applied)
 need(set(restored)==set(before),'restoration complete original file membership')
 nonleaf=[p for p in before if p!=resource] if k!='Extra' else list(before)
 need(all(before[p]==restored[p] for p in nonleaf),'all other original files retain every recorded field including ID/hash/write/attrs');unchangedRemaining+=len(nonleaf)
 old=before[resource];new=restored[resource];need(new['Sha256']==old['Sha256'] and new['Bytes']==old['Bytes']==1255 and new['Attributes']==old['Attributes']==32 and new['Links']==1,'fixed resource restored original source-bound bytes/attrs')
 if k=='Missing':need(len(applied)==13 and resource not in applied and all(applied[p]==before[p] for p in applied) and object_id(new)!=object_id(old),'only missing fixed leaf rebuilt as a new file object')
 elif k=='Tampered':need(len(applied)==14 and set(applied)==set(before) and same_object(applied[resource],old) and applied[resource]['Bytes']==old['Bytes'] and applied[resource]['Sha256']!=old['Sha256'] and same_object(new,old),'same tampered original object, original bytes restored')
 else:need(len(applied)==15 and set(applied)==set(before)|{extra} and all(applied[p]==before[p] for p in before) and extra not in restored and applied[extra]==m['Applied'],'one exact nonce extra added then removed without altering original members')
 backup=Path(m['OriginalBackup'].replace('\\','/')).name;raw=(root/backup).read_bytes();need(len(raw)==old['Bytes'] and sha(raw)==old['Sha256'] and m['OriginalBackupFact']['Sha256']==old['Sha256'] and m['OriginalBackupFact']['Bytes']==old['Bytes'],'each downloaded actual HTML backup equals captured original bytes and source-bound fact')
 altered=bytes([raw[0]^1])+raw[1:]
 if k=='Tampered':need(sha(altered)==applied[resource]['Sha256'],'actual tampered digest is exactly one XOR byte different')
 if k=='Extra':need(applied[extra]['Sha256']==sha(('future-classroom-owned-r79-extra/v1\n'+config['runtimeNonce']+'\n').encode()),'actual nonce extra exact expected marker bytes')
 for label in ('beforeHealthy','afterFixtureRestore'):need(c[label]['healthyPresent'] is True and c[label]['stateClassification']=='HEALTHY_PRESENT','actual healthy before and restored source bytes')
 for label in ('beforeRejectedState','afterRejectedState'):need(c[label]['healthyPresent'] is False and c[label]['stateClassification']=='UNKNOWN_OR_MISMATCH','actual damaged preimage remains damaged through reject')
 for label in ('beforeRejectedState','afterRejectedState','afterFixtureRestore'):
  for part in ('registration','markers','components','run'):need(c['beforeHealthy']['observations'][part]==c[label]['observations'][part],'all actual control state observations unchanged')
 # Raw per-case final source, captured/apply receipts and backup are kept.
 name=k.lower();need(json.loads((root/(name+'-negative-result.json')).read_text(encoding='utf-8-sig'))==c,'raw final case receipt exact')
 captured=json.loads((root/(name+'-mutation-captured.json')).read_text(encoding='utf-8-sig'));apply=json.loads((root/(name+'-mutation-applied.json')).read_text(encoding='utf-8-sig'));need(captured['OriginalTree']==m['OriginalTree'] and captured['Phase']=='CAPTURED_NO_MUTATION' and apply['Phase']=='APPLIED' and apply['BeforeMsiTree']==m['BeforeMsiTree'],'raw pre-mutation and applied receipts retain exact original stages')
 caseStats.append(dict(kind=k,originalFileCount=len(before),mutatedAndRejectedFileCount=len(applied),restoredFileCount=len(restored),unchangedOriginalOtherFiles=len(nonleaf),rejectedMsiPreservedEveryRecordedFileFact=True,fixtureRestoreOnly=True,sourceResourceSha256=old['Sha256'],sourceResourceBytes=old['Bytes'],originalResourceObject=list(object_id(old)),restoredResourceObject=list(object_id(new)),resourceObjectChanged=object_id(old)!=object_id(new),originalCreation=old['Creation'],restoredCreation=new['Creation'],originalWrite=old['Write'],restoredWrite=new['Write'],resourceWriteChanged=old['Write']!=new['Write'],restorationIdentityScope=m['RestorationIdentityScope'],htmlBackup=dict(path=backup,bytes=len(raw),sha256=sha(raw)),controlStateUnchanged=True))
need(totalBeforeAfter==42 and unchangedRemaining==40,'actual full-tree aggregate counts')
for key in ('ownerUnknown','instrumentUnknown','originalBudgetExceeded','activeMutationRetained'):need(r[key] is False,'actual unknown/budget/mutation flags false')
need(r['retainedDirectClients']==0 and r['formalUninstallAttempted'] and r['finallyProductState']['knownAbsent'] and r['finallyCoordination']['namespaceKnownAbsent'] and r['finallyCoordination']['pendingKnownAbsent'],'formal uninstall/product/Pending/gate final observed absence')
cache=r['uninstallCache'];need(cache['actualProductQuery']['apiCode']==1605 and cache['allPreviouslyObservedPathsKnownAbsent'] and all(x['status']=='KNOWN_ABSENT' for x in cache['previouslyObservedExactPaths']),'actual original observed LocalPackage known absent after uninstall')
precheck=E/'root-fixture-precheck-third.json';need(fact(precheck)['sha256']=='6bf167c15737a63315a30387aaa7bd68bef322fb58ab77b7c451c4d6d9a06974','root actual four-compile precheck report binding')
q=json.loads(precheck.read_text());need(q['status']=='PASS_INSTRUMENT_PARSE_FOUR_COMPILES_AND_EXACT_CLEANUP_ONLY','actual original precheck passed');need(len(q['native']['compilers'])==4 and all(x['actualExit'] and x['exitCode']==0 for x in q['native']['compilers']),'actual four C# compile-only processes returned zero')
# Collect exact paths mentioned by original MSI logs as candidates only. Their
# appearance alone is never converted to a filesystem-absence observation.
logPaths={}
for p in root.glob('*-msi.log'):
 text=p.read_bytes().decode('utf-16');paths=sorted(set(re.findall(r'[A-Za-z]:\\Windows\\Installer\\[A-Za-z0-9._-]+',text,re.I)));logPaths[p.name]=paths
out=dict(status='PASS_AUTHOR_LOCAL_FINITE_ORIGINALS_QUALIFICATION_NOT_INDEPENDENT_FINAL_ACCEPTANCE',role='Author-side local record qualification; root performs independent final acceptance',runtimeReport=fact(REPORT),thirdSourceFreeze=fact(freeze),actualInstrumentPrecheck=fact(precheck),downloadedOriginals=dict(root=str(root),files=len(actual),directories=len(dirs),bytes=sum(x['bytes'] for x in actual.values()),everyMemberBytesSha256Exact=True,originalFullInventory=inventory),actualOriginalProcessStatistics=dict(msiClients=5,msiClientExitCodes=[p['client']['exitCode'] for p in phases],capturedOriginalControls=11,actualOriginalWaitZero=11,actualOriginalGetExitCode=11,checkedOriginalCloseSuccess=11,controlsExitZero=8,expectedRejectBeginExit1603=3,nativeClass60ActualStatusZero=11,nativePbiActualStatusZero=11,nativeBuffersCheckedFree=22,captureWarnings=0,metadataWarnings=0,distinctExactCapturedHelperImagePaths=7),phases=phaseStats,originalControlFacts=controls,cases=caseStats,aggregateFileComparisons=dict(rejectedMsiBeforeAfterFileFactsExact=totalBeforeAfter,restoredOtherOriginalFileFactsExact=unchangedRemaining),cleanupScope=dict(helperImages='Seven exact captured helper image paths reported KNOWN_ABSENT by original per-phase readbacks; no new filesystem query',localPackage='Actual original LocalPackage query and prior exact path known absent after formal /x',productFilesAndComponentRegistration='Formal MSI /x, original actual state receipts known absent',pending='Original broker settlement/actual Pending absence; author does not invent old owner retention',coordinationGate='Test-only original gate snapshot retirement after actual owner returns; not falsely attributed solely to MSI',transportScratch='Original controller downloaded all files then precisely removed its owned nonce root; author did not query deleted root'),measuredRanges=dict(nativeFivePhasePlusFixtureWholeMilliseconds=r['elapsedWholeMilliseconds'],originalTransportControllerSeconds=j['elapsedSeconds'],transportOriginalOuterSeconds=j['originalOuterSeconds'],nativeOriginalWholeMilliseconds=r['originalWholeMilliseconds'],maximumClientPhaseMilliseconds=r['maximumClientPhaseMilliseconds'],cleanupReserveMilliseconds=r['cleanupReserveMilliseconds'],nativeBrokerOriginalSeconds=r['nativeBrokerOriginalSeconds']),msiLogMentionedPathsNotAbsenceProof=logPaths,remainingAndLimits=['Author qualification only; root independent final source/byte/evidence review remains separate.','Three rejected reinstall attempts exercise damaged pre-admission refusal, not successful damaged repair and not a transaction rollback/failure after mutation.','Missing fixed resource is recreated by the test fixture with original bytes and a different file ID; its creation timestamp happened to equal the original field, which is not evidence of same object.','Tampered fixed resource retains original file object and original bytes; its actual write timestamp changes and is explicitly not restored. Other file facts are checked exactly.','Tree arrays record regular file facts; this is not complete original directory-object identity or whole-system state proof.','Captured negative roles are actual Begin only; source contract and observed Pending absence do not turn missed observations into proof that no broker ever existed.','Only original captured helper paths and one actually API-observed LocalPackage path have absence readbacks here. Additional MSI-log path mentions are candidate paths, not absence proof. Root may separately qualify exact system paths/final environment audit.','No crash/power-loss/unknown-close injection or actual retained-Pending recovery was exercised; pure poison lifetime models remain separate.','Current authorized administrator Win11 only. Win7-target normal binaries do not establish Win7/Win10 OS, standard-user, real login/Run ownership cleanup or hardware acceptance.'],windowsContactedByThisQualification=False,originalFilesModified=False)
p=D/'qualification-first.json';need(not p.exists(),'new author qualification output');p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(report=fact(p),statistics=out['actualOriginalProcessStatistics'],ranges=out['measuredRanges'],fileComparisons=out['aggregateFileComparisons'])))
