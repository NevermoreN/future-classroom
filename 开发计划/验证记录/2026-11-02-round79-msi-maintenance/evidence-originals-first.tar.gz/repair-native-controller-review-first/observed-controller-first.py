"""Root-owned finite candidate native tests. Default inert; retain any unknown."""
import argparse, base64, hashlib, json, os, re, runpy, secrets, shutil, struct, subprocess, time
from pathlib import Path
E=Path('/tmp/fc-round79-msi-maintenance')
BASE=E/'negative-fixture-preparation-third/run-negative-msi-r79-third.py'
COMMON=runpy.run_path(str(BASE))['COMMON'].replace('r79-production-msi-','r79-repair-native-').replace('r79-production-msi-runtime/v1','r79-repair-native-runtime/v1')
CAP=E/'early-terminal-preparation-first/Capture.cs'
SID='S-1-5-21-3896111207-1867804362-1971593122-1001'
BOOT="[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()))"
CREATE=r'''
$w=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$w.User;if($sid.Value-cne$c.sid){throw 'SID'}}finally{$w.Dispose()}
$root=RootPath;try{[void][IO.File]::GetAttributes($root);throw 'ROOT_EXISTS'}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-isnot[IO.FileNotFoundException]-and$e-isnot[IO.DirectoryNotFoundException]){throw}}
$cursor=[IO.Path]::GetDirectoryName($root);while($cursor){if(([IO.File]::GetAttributes($cursor)-band[IO.FileAttributes]::ReparsePoint)-ne0){throw 'ANCESTOR_REPARSE'};$cursor=[IO.Path]::GetDirectoryName($cursor)}
[void][IO.Directory]::CreateDirectory($root);$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false);foreach($s in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($s,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))};[IO.Directory]::SetAccessControl($root,$acl)
[IO.File]::WriteAllText((Join-Path $root '.owner'),"future-classroom-owned-r79-repair-native-runtime/v1`n",[Text.UTF8Encoding]::new($false));$c.root=$root;CheckRoot $root;@{root=$root;status='CREATED'}|ConvertTo-Json -Compress
'''
RUN=r'''
CheckRoot $c.root;$root=$c.root
foreach($x in $c.inputs){$f=Fact (Join-Path $root $x.name);if($f.bytes-ne$x.bytes-or$f.sha256-cne$x.sha256){throw 'INPUT_BYTES'}}
$oldTemp=$env:TEMP;$oldTmp=$env:TMP;$clock=[Diagnostics.Stopwatch]::StartNew();$capture=$null;$p=$null;$returned=$true
$r=@{status='FAIL_RETAIN';cases=@();originalWholeSeconds=600;captureSourceOnlyProcessMethods=$true;cleanup='ROOT_DOWNLOAD_THEN_EXACT_DELETE_REQUIRED'}
try{
 $env:TEMP=Join-Path $root 'compiler-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP)
 try{Add-Type -Path (Join-Path $root 'Capture.cs') -ErrorAction Stop}finally{$env:TEMP=$oldTemp;$env:TMP=$oldTmp}
 $capture=[Fc79Capture]::new();$exe=Join-Path $root 'candidate-tests.exe'
 $env:TEMP=Join-Path $root 'test-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP)
 foreach($s in @(@{name='effects';filter='installer_lifecycle::native::broker::effects::';seconds=150},@{name='lifecycle';filter='installer_lifecycle::';seconds=300})){
  if($clock.ElapsedMilliseconds-ge600000){throw 'WHOLE_BUDGET'}
  $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$exe;$info.Arguments=$s.filter+' --test-threads=1 --nocapture';$info.WorkingDirectory=$root;$info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
  $p=[Diagnostics.Process]::new();$p.StartInfo=$info;$case=@{name=$s.name;argv=$info.Arguments;originalSeconds=$s.seconds;actualExit=$false;exitCode=$null};$r.cases+=,$case
  if(-not$p.Start()){throw 'START'};$returned=$false;$case.pid=$p.Id;$case.creation=$p.StartTime.ToUniversalTime().ToFileTimeUtc()
  $stdout=$p.StandardOutput.ReadToEndAsync();$stderr=$p.StandardError.ReadToEndAsync()
  $case.original=$capture.HoldStartedClient($p.Handle,[uint32]$p.Id,[long]$case.creation,$exe,$c.exeSha,$c.sid)
  $left=[int][Math]::Min($s.seconds*1000,600000-$clock.ElapsedMilliseconds)
  if($left-le0-or-not$p.WaitForExit($left)){throw 'ORIGINAL_TEST_PARENT_UNKNOWN_RETAIN_NO_KILL'}
  $returned=$true;$p.Refresh();$case.actualExit=$true;$case.exitCode=$p.ExitCode
  if(-not[Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($stdout,$stderr),[int][Math]::Max(0,600000-$clock.ElapsedMilliseconds))){throw 'ORIGINAL_PIPES_UNKNOWN'}
  $case.stdout=$stdout.Result;$case.stderr=$stderr.Result;[void]$capture.Snapshot()
  if($case.original.Wait-ne0-or-not$case.original.ExitKnown-or$case.original.ExitCode-ne$case.exitCode){throw 'ORIGINAL_TEST_RETURN_MISMATCH'}
  $p.Dispose();$p=$null;if($case.exitCode-ne0){throw 'NATIVE_TEST_FAILURE'}
 }
 $r.status='PASS_FOCUSED_EFFECTS_AND_FULL_LIFECYCLE_NATIVE_TESTS_WIN11_ONLY'
}catch{$r.error=$_.Exception.Message}finally{
 $env:TEMP=$oldTemp;$env:TMP=$oldTmp
 if($null-ne$p-and$returned){$p.Dispose()}
 if($null-ne$capture){try{$r.originalObjects=@($capture.FinishAndClose())}catch{$r.status='FAIL_RETAIN';$r.closeError=$_.Exception.Message}}
 $r.originalParentReturned=$returned;$r.elapsedMilliseconds=$clock.ElapsedMilliseconds
 if($clock.ElapsedMilliseconds-ge600000){$r.status='FAIL_RETAIN';$r.budgetExceeded=$true}
 [IO.File]::WriteAllText((Join-Path $root 'native-result.json'),($r|ConvertTo-Json -Depth 30),[Text.UTF8Encoding]::new($false))
}
$r|ConvertTo-Json -Depth 30 -Compress
if($r.status-cne'PASS_FOCUSED_EFFECTS_AND_FULL_LIFECYCLE_NATIVE_TESTS_WIN11_ONLY'){exit 1}
'''
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fact(p):p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def main():
 a=argparse.ArgumentParser();a.add_argument('--execute',action='store_true');v=a.parse_args()
 if not v.execute:print('{"status":"NOT_RUN"}');return
 producer=E/'repair-candidate-build-first/report.json';pr=json.loads(producer.read_text());assert pr['status']=='PASS_WORKSPACE_ALL_TARGETS_GNU_COMPILE_ONLY' and pr['actualReturnCode']==0 and pr['sourceUnchanged']
 assert sha(CAP)=='e74300d27694e46fde2e8113cfeee47ffd3f11f9172f01c5621fa2ba5fdcab5a'
 rows=[json.loads(x) for x in (producer.parent/'stdout.jsonl').read_text().splitlines()]
 rows=[x for x in rows if x.get('reason')=='compiler-artifact' and x.get('profile',{}).get('test') and x.get('executable') and x['target']['name']=='fc_windows'];assert len(rows)==1
 exe=Path(rows[0]['executable']);raw=exe.read_bytes();off=struct.unpack_from('<I',raw,60)[0];assert raw[off:off+4]==b'PE\0\0' and struct.unpack_from('<H',raw,off+4)[0]==0x14c and struct.unpack_from('<H',raw,off+92)[0]==3
 out=E/'repair-candidate-native-first';out.mkdir();(out/'.owner').write_text('future-classroom-owned-r79-repair-native-local/v1\n')
 r=dict(status='STARTED',producer=fact(producer),native=fact(exe),capture=fact(CAP),operations=[],cleanup='NOT_RUN',outerSeconds=900);c=dict(nonce=secrets.token_hex(16),sid=SID,root=None,exeSha=sha(exe));start=time.monotonic()
 def save():(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
 def call(label,cmd,feed=None,limit=30):
  begin=time.monotonic();left=900-(begin-start);assert left>0
  child=subprocess.Popen(cmd,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  timed=False
  try:stdout,stderr=child.communicate(feed,timeout=min(left,limit))
  except subprocess.TimeoutExpired:
   timed=True;child.kill();stdout,stderr=child.communicate()
  so=out/(label+'.stdout.log');se=out/(label+'.stderr.log');so.write_bytes(stdout);se.write_bytes(stderr)
  r['operations'].append(dict(name=label,argv=cmd,actualReturnCode=child.returncode,originalLocalReaped=True,remoteOriginalReturnUnknown=timed,budgetExceeded=timed,elapsedSeconds=time.monotonic()-begin,stdout=fact(so),stderr=fact(se)));save()
  assert not timed and child.returncode==0,(label,child.returncode,'REMOTE_UNKNOWN_RETAIN' if timed else 'ACTUAL_NONZERO')
  return stdout
 def remote(label,script,limit=30):
  feed=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+COMMON+script).encode()
  return call(label,['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','future-classroom-win11','powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(BOOT.encode('utf-16-le')).decode()],feed,limit)
 try:
  c['root']=json.loads(remote('create',CREATE))['root'];r['windowsRoot']=c['root'];save()
  upload=out/'upload';upload.mkdir();shutil.copyfile(exe,upload/'candidate-tests.exe');shutil.copyfile(CAP,upload/'Capture.cs')
  c['inputs']=[dict(name=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(upload.iterdir())]
  for p in sorted(upload.iterdir()):call('upload-'+p.name,['scp','-q','-o','BatchMode=yes',str(p),'future-classroom-win11:'+c['root'].replace('\\','/')+'/'],limit=60)
  native=json.loads(remote('run',RUN,650));r['native']=native
  assert native['status']=='PASS_FOCUSED_EFFECTS_AND_FULL_LIFECYCLE_NATIVE_TESTS_WIN11_ONLY'
  added=('rollback_requires_original_bad_bytes_and_absence_but_not_old_object_ids','actual_damaged_preimage_pins_zero_and_bad_bytes_and_requires_exact_rollback','actual_preimage_distinguishes_missing_tree_and_rejects_foreign_link_locked_and_large')
  assert len(native['cases'])==2
  r['qualifiedCases']=[]
  for case in native['cases']:
   assert case['actualExit'] and case['exitCode']==0 and all(re.search(r'^test [^\r\n]*::'+name+r' \.\.\. ok\r?$',case['stdout'],re.M) for name in added)
   totals=re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',case['stdout'],re.M)
   assert totals and int(totals[-1][0])>=3 and all(int(n)==0 for n in totals[-1][1:4]);r['qualifiedCases'].append(dict(name=case['name'],outerTotals={k:int(n) for k,n in zip(('passed','failed','ignored','measured','filteredOut'),totals[-1])}))
  assert len(native['originalObjects'])==2 and all(x['CheckedClose'] and x['Wait']==0 and x['ExitKnown'] and x['ExitCode']==0 for x in native['originalObjects'])
  ownedProcesses=json.loads(remote('owned-processes',"$a=@(Get-CimInstance Win32_Process -ErrorAction Stop|Where-Object {$_.ExecutablePath -and $_.ExecutablePath.StartsWith($c.root+'\\',[StringComparison]::OrdinalIgnoreCase)});@{count=$a.Count}|ConvertTo-Json -Compress"));r['ownedProcessReadback']=ownedProcesses;assert ownedProcesses['count']==0
  inv=json.loads(remote('inventory','Inventory $c.root|ConvertTo-Json -Depth 12 -Compress'));r['inventory']=inv
  for item in c['inputs']:
   actual=[x for x in inv['files'] if x['path']==item['name']];assert len(actual)==1 and actual[0]['bytes']==item['bytes'] and actual[0]['sha256']==item['sha256']
  save()
  download=out/'download';download.mkdir();call('download',['scp','-q','-r','-o','BatchMode=yes','future-classroom-win11:'+c['root'].replace('\\','/'),str(download)],limit=60)
  local=download/Path(c['root'].replace('\\','/')).name
  helper=runpy.run_path(str(BASE));helper['verify_download'](local,inv)
  assert json.loads((local/'native-result.json').read_text())==native
  c['inventory']=inv
  cleanup=helper['DELETE'].replace('PRODUCT_RUNTIME_ROOT','REPAIR_NATIVE_RUNTIME_ROOT')
  r['delete']=json.loads(remote('delete',cleanup));r['cleanup']='PASS_EXACT_DOWNLOADED_OWNED_SCRATCH_ONLY';r['status']='PASS_CANDIDATE_NATIVE_TESTS_WIN11_ONLY'
 except Exception as error:r.update(status='FAIL_RETAIN_ORIGINALS',errorType=type(error).__name__,error=str(error))
 r['elapsedSeconds']=time.monotonic()-start;save();print(json.dumps({'status':r['status'],'report':str(out/'report.json'),'sha256':sha(out/'report.json'),'error':r.get('error')}));raise SystemExit(0 if r['status'].startswith('PASS_') else 1)
if __name__=='__main__':main()
