#define FC79_NONCE L"0b744835e91f1ee00a95b18eb3303f19"
#define FC79_PRODUCT L"{E2978D55-CB0A-41E8-BE32-D6BEF4E5260A}"
#define FC79_EFFECT_DIR L"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-0b744835e91f1ee00a95b18eb3303f19\\effect\\"
