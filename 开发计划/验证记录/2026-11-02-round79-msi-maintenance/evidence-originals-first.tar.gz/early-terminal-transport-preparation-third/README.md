# Third compile-only transport

First and second sources/reports/raw failures remain unchanged. Third adds no
new Windows operation type. It preserves second's process-only ExecutionPolicy
Bypass and all compiler/root/source/download/deletion gates.

The correction compares inventory membership as a validated unique
`path -> (bytes, sha256)` map plus directory count/set, instead of relying on
PowerShell enumeration/Sort-Object order. Original array order stays in the raw
reports. Duplicate paths, directory duplicates, wrong size/hash, extra fields
or unsafe paths still fail. This applies both to recovery and the post-download
second inventory, and to the original four-upload identity comparison.

Recovery additionally pins the exact second read-only failure and original raw
stdout/stderr, which prove its one read-only command returned0, five members
matched, ownCandidates was empty, and no root recreation/overwrite/compiler/
helper/MSI occurred. Neither old FAIL status is changed.

Use second's exact CLI/spec/prototype/source pins and new output directory,
with these two additional required recovery arguments:

```text
--recover-readonly-report /tmp/fc-round79-msi-maintenance/early-terminal-compile-second/compile-operation.json
--recover-readonly-report-sha256 68e9a4cd46297532afdffc87aafaef6585c02f5c7830996e93c6504acb02c681
--output-dir /tmp/fc-round79-msi-maintenance/early-terminal-compile-third
```

The original precompile report/SHA remain
`early-terminal-compile-first/compile-operation.json` /
`5fcf342bf876a6b89af94341cd5a8903ce92a18626d47d8318ffc8f09ffb7947`.
The source prototype remains second freeze `7c76bbae…`; spec remains
`46eab56e…`. No source/data is re-uploaded during recovery, no policy is changed
persistently, and no unknown return is retried. Default/AST/pure local checks
are not Windows execution or a compiler result.
