#!/usr/bin/env python3
"""Root-only compile transport. Default is inert; no MSI or helper execution.
Uses the persistent SSH alias, never opens or copies a private key.
"""
import argparse
import base64
import datetime
import hashlib
import json
from pathlib import Path
import re
import runpy
import struct
import subprocess
import time

E=Path('/tmp/fc-round79-msi-maintenance')
PROTOTYPE=E/'early-terminal-preparation-second'
HOST='future-classroom-win11'
SID='S-1-5-21-3896111207-1867804362-1971593122-1001'
FIRST_TRANSPORT_SHA='921f882bbfa22b9b32aa18eef878a07114d689627482d73dfcaa3fa7f1425ca4'
SECOND_TRANSPORT_SHA='8b10e5f3d9e5eb36f61cb59bc1f47ede4c5d1b78fa2220423193b9fd2731959a'
BOOT="[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()))"
COMMON=r'''
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Need([bool]$v,[string]$s){if(-not $v){throw $s}}
function Absent([string]$p){try{[void][IO.File]::GetAttributes($p);return $false}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-is [IO.FileNotFoundException] -or $e-is [IO.DirectoryNotFoundException]){return $true};throw}}
function Fact([string]$p){$a=[IO.File]::GetAttributes($p);Need (-not($a-band[IO.FileAttributes]::ReparsePoint) -and -not($a-band[IO.FileAttributes]::Directory)) 'REGULAR_NONREPARSE';$size=[long]([IO.FileInfo]::new($p).Length);Need ($size-ge 0 -and $size-le 16777216) 'FILE_BOUND';@{bytes=$size;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function Root-Check {
 Need ($PSVersionTable.PSVersion.Major-eq 5 -and [IntPtr]::Size-eq 8) 'DESKTOP_PS51_X64'
 Need ([IO.Path]::GetFullPath($c.root)-ceq $c.root -and [IO.Path]::GetFileName($c.root)-ceq ('FutureClassroom-r79-early-terminal-'+$c.nonce)) 'CLOSED_ROOT'
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent();try{Need ($identity.User.Value-ceq $c.sid) 'EXPECTED_CURRENT_USER'}finally{$identity.Dispose()}
 $cursor=$c.root;while($cursor){$a=[IO.File]::GetAttributes($cursor);Need (($a-band[IO.FileAttributes]::ReparsePoint)-eq 0 -and ($a-band[IO.FileAttributes]::Directory)-ne 0) 'DIRECTORY_NO_REPARSE';$cursor=[IO.Path]::GetDirectoryName($cursor)}
 Need ([IO.File]::ReadAllText((Join-Path $c.root '.owner'))-ceq "future-classroom-owned-r79-early-terminal-fixture/v1`n") 'OWNER_MARKER'
 $acl=[IO.Directory]::GetAccessControl($c.root);Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq $c.sid) 'PROTECTED_OWNER'
 $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($rules.Count-eq 2) 'TWO_ACES'
 $who=@($rules|ForEach-Object {$_.IdentityReference.Value}|Sort-Object -Unique);Need ($who.Count-eq 2 -and $c.sid-in $who -and 'S-1-5-18'-in $who) 'USER_AND_SYSTEM'
 foreach($r in $rules){Need ($r.AccessControlType-eq 'Allow' -and ($r.FileSystemRights-band [Security.AccessControl.FileSystemRights]::FullControl)-eq [Security.AccessControl.FileSystemRights]::FullControl) 'EXACT_ALLOW_FULLCONTROL'}
}
function Inventory {
 Root-Check;$files=@();$dirs=@();$total=0L;$queue=[Collections.Generic.Queue[string]]::new();$queue.Enqueue($c.root)
 while($queue.Count){$dir=$queue.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){$a=[IO.File]::GetAttributes($p);Need (($a-band[IO.FileAttributes]::ReparsePoint)-eq 0) 'INVENTORY_REPARSE';$rel=$p.Substring($c.root.Length+1).Replace('\','/');if(($a-band[IO.FileAttributes]::Directory)-ne 0){Need ($rel-ceq 'csc-owned-temp' -or $rel.StartsWith('csc-owned-temp/')) 'ONLY_OWN_COMPILER_TEMP_SUBDIRECTORIES';$dirs+=$rel;$queue.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256};$total+=$f.bytes};Need ($files.Count-le 64 -and $dirs.Count-le 16 -and $total-le 33554432) 'INVENTORY_BOUND'}}
 @{files=@($files|Sort-Object path);directories=@($dirs|Sort-Object)}
}
'''
CREATE=r'''
Need ($c.nonce-cmatch '^[0-9a-f]{32}$' -and $c.sid-cmatch '^S-1-5-21-') 'NONCE_SID'
$identity=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$identity.User;Need ($sid.Value-ceq $c.sid) 'EXACT_USER'}finally{$identity.Dispose()}
$expected=Join-Path ([IO.Path]::GetFullPath($env:TEMP)) ('FutureClassroom-r79-early-terminal-'+$c.nonce)
Need ($expected-ceq $c.root) 'SPEC_ROOT_MUST_EQUAL_ACTUAL_USER_TEMP_ROOT'
Need (Absent $c.root) 'PREEXISTING_ROOT_REFUSED'
$cursor=[IO.Path]::GetDirectoryName($c.root);while($cursor){Need (([IO.File]::GetAttributes($cursor)-band[IO.FileAttributes]::ReparsePoint)-eq 0) 'NO_ANCESTOR_REPARSE';$cursor=[IO.Path]::GetDirectoryName($cursor)}
[void][IO.Directory]::CreateDirectory($c.root)
$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false)
foreach($who in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($who,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))}
[IO.Directory]::SetAccessControl($c.root,$acl)
$owner=[Text.UTF8Encoding]::new($false).GetBytes("future-classroom-owned-r79-early-terminal-fixture/v1`n")
$f=[IO.File]::Open((Join-Path $c.root '.owner'),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);try{$f.Write($owner,0,$owner.Length);$f.Flush($true)}finally{$f.Dispose()}
Root-Check
@{status='PASS_CREATED_ONLY_PROTECTED_COMPILE_ROOT';root=$c.root;nonce=$c.nonce;sid=$c.sid}|ConvertTo-Json -Compress
'''
RECOVER=r'''
Root-Check
$inventory=Inventory
Need ($inventory.files.Count-eq 5 -and $inventory.directories.Count-eq 0) 'EXACT_FIVE_ORIGINAL_PRECOMPILE_MEMBERS'
foreach($expected in $c.originalInventory.files){$actual=@($inventory.files|Where-Object {$_.path-ceq $expected.path});Need ($actual.Count-eq 1 -and $actual[0].bytes-eq $expected.bytes -and $actual[0].sha256-ceq $expected.sha256) 'ORIGINAL_FIVE_BYTES_UNCHANGED'}
# This is a finite, read-only negative recovery check, not process identity
# authority for a production role. Do not emit other users' command lines.
$candidates=@();$foreign=0
$rows=@(Get-CimInstance -ClassName Win32_Process -Filter "Name='csc.exe' OR Name='PositiveControl.exe'")
Need ($rows.Count-le 64) 'BOUNDED_COMPILER_HELPER_PROBE'
foreach($row in $rows){
 Need ($null-ne $row.ExecutablePath -and $null-ne $row.CommandLine) 'CANDIDATE_METADATA_UNKNOWN_RETAIN'
 $inRoot=$row.ExecutablePath.StartsWith($c.root+'\',[StringComparison]::OrdinalIgnoreCase) -or $row.CommandLine.IndexOf($c.root,[StringComparison]::OrdinalIgnoreCase)-ge 0
 if($inRoot){$candidates+=@{pid=$row.ProcessId;image=$row.ExecutablePath;creation=$row.CreationDate}}else{$foreign++}
}
Need ($candidates.Count-eq 0) 'ORIGINAL_PRECOMPILE_OWNED_PROCESS_NOT_ABSENT'
@{status='PASS_EXACT_FIVE_PRECOMPILE_ORIGINALS_ZERO_OWN_COMPILER_HELPER';inventory=$inventory;ownCandidates=$candidates;foreignIgnoredCount=$foreign;nonce=$c.nonce;root=$c.root;recreated=$false;overwritten=$false}|ConvertTo-Json -Depth 20 -Compress
'''
COMPILE=r'''
Root-Check
$result=[ordered]@{status='FAIL_COMPILE_ONLY_RETAIN_ROOT';msi='NOT_RUN';helperExecution='NOT_RUN';powershellParse=@();uploaded=@();receipt=$null;error=$null}
try{
 Need ($c.files.Count-eq 4) 'FOUR_UPLOADS'
 foreach($item in $c.files){$f=Fact (Join-Path $c.root $item.path);Need ($f.bytes-eq $item.bytes -and $f.sha256-ceq $item.sha256) 'ACTUAL_UPLOAD_BYTES';$result.uploaded+=@{path=$item.path;bytes=$f.bytes;sha256=$f.sha256}}
 $tokens=$null;$errors=$null;$code=[IO.File]::ReadAllText((Join-Path $c.root 'Compile-PositiveControl.ps1'));[void][Management.Automation.Language.Parser]::ParseInput($code,[ref]$tokens,[ref]$errors)
 $result.powershellParse=@($errors|ForEach-Object {@{message=$_.Message;line=$_.Extent.StartLineNumber;errorId=$_.ErrorId}});Need ($errors.Count-eq 0) 'COMPILE_SCRIPT_PARSE_FAILED'
 $result.invocationPipeline=@(& (Join-Path $c.root 'Compile-PositiveControl.ps1') -Execute -Root $c.root -SpecSha256 $c.specSha256)
 $result.receipt=[IO.File]::ReadAllText((Join-Path $c.root 'positive-compile-receipt.json'))|ConvertFrom-Json
 Need ($result.receipt.status-ceq 'PASS_CSC_ACTUAL_EXIT0_COMPILE_ONLY' -and $result.receipt.actualExit-eq 0 -and $result.receipt.nonce-ceq $c.nonce -and $result.receipt.executed-eq $false) 'ACTUAL_COMPILE_RECEIPT_REQUIRED'
 $result.status='PASS_CSC_ONLY_PARENT_RETURNED_NO_EXE_OR_MSI_EXECUTION'
}catch{$result.error=@{type=$_.Exception.GetType().FullName;message=$_.Exception.Message}}
$result|ConvertTo-Json -Depth 30 -Compress
if($result.status-cne 'PASS_CSC_ONLY_PARENT_RETURNED_NO_EXE_OR_MSI_EXECUTION'){exit 1}
'''
DELETE=r'''
Root-Check;$now=Inventory
Need ($now.files.Count-eq $c.inventory.files.Count -and $now.directories.Count-eq $c.inventory.directories.Count) 'EXACT_INVENTORY_COUNTS'
foreach($f in $now.files){$old=@($c.inventory.files|Where-Object {$_.path-ceq $f.path});Need ($old.Count-eq 1 -and $old[0].bytes-eq $f.bytes -and $old[0].sha256-ceq $f.sha256) 'EXACT_DOWNLOADED_ORIGINAL_BYTES'}
foreach($d in $now.directories){Need ($d-cin $c.inventory.directories) 'EXACT_DIRECTORIES'}
foreach($f in $now.files){if($f.path-cne '.owner'){[IO.File]::Delete((Join-Path $c.root ($f.path.Replace('/','\'))))}}
foreach($d in @($now.directories|Sort-Object Length -Descending)){[IO.Directory]::Delete((Join-Path $c.root ($d.Replace('/','\'))),$false)}
[IO.File]::Delete((Join-Path $c.root '.owner'));[IO.Directory]::Delete($c.root,$false);Need (Absent $c.root) 'ROOT_KNOWN_ABSENT'
@{status='PASS_REMOVED_EXACT_DOWNLOADED_COMPILE_ROOT';knownAbsent=$true;nonce=$c.nonce}|ConvertTo-Json -Compress
'''

def need(ok,why):
    if not ok: raise ValueError(why)

def sha(data): return hashlib.sha256(data).hexdigest()

def fact(p):
    need(p.is_file() and not p.is_symlink(),'Regular original file')
    b=p.read_bytes();need(len(b)<=32*1024*1024,'Bounded local file')
    return {'bytes':len(b),'sha256':sha(b)}

def regular_owned(p):
    need(p.is_absolute() and p.resolve()==p and p.is_relative_to(E),'Owned R79 canonical path')
    return p

def validate_inventory(v):
    need(set(v)=={'files','directories'} and len(v['files'])<=64 and len(v['directories'])<=16,'Inventory shape/bounds')
    seen=set();total=0
    for row in v['files']:
        need(set(row)=={'path','bytes','sha256'},'Exact inventory file fields')
        rel=row['path'];need(isinstance(rel,str) and rel and ':' not in rel and '\\' not in rel and all(x not in ('','.','..') for x in rel.split('/')) and rel not in seen,'Safe unique owned relative file')
        seen.add(rel);need(type(row['bytes']) is int and 0<=row['bytes']<=16777216 and re.fullmatch('[0-9a-f]{64}',row['sha256']),'Inventory byte/hash');total+=row['bytes']
    need(total<=33554432 and len(set(v['directories']))==len(v['directories']),'Inventory total/directories')
    for rel in v['directories']:
        need(rel not in seen and (rel=='csc-owned-temp' or rel.startswith('csc-owned-temp/')) and ':' not in rel and '\\' not in rel and all(x not in ('','.','..') for x in rel.split('/')),'Only owned compiler temp directories')

def inventory_identity(v):
    # Enumeration order is not ownership. Validate uniqueness BEFORE mapping;
    # preserve the original arrays in all reports/raw stdout.
    validate_inventory(v)
    return ({r['path']:(r['bytes'],r['sha256']) for r in v['files']},set(v['directories']))

def pe32_gui_managed_x86(data):
    need(len(data)>=128 and data[:2]==b'MZ','PE DOS')
    off=struct.unpack_from('<I',data,60)[0];need(off+248<=len(data) and data[off:off+4]==b'PE\0\0','PE offset')
    need(struct.unpack_from('<H',data,off+4)[0]==0x14c,'x86 machine')
    size=struct.unpack_from('<H',data,off+20)[0];opt=off+24
    need(size>=224 and opt+size<=len(data) and struct.unpack_from('<H',data,opt)[0]==0x10b,'PE32 complete optional header')
    need(struct.unpack_from('<H',data,opt+68)[0]==2,'GUI2 fixture')
    count=struct.unpack_from('<I',data,opt+92)[0];need(count>=15,'CLR directory exists')
    rva,length=struct.unpack_from('<II',data,opt+96+14*8);need(rva and length>=72,'CLR header')
    sections=struct.unpack_from('<H',data,off+6)[0];need(1<=sections<=32 and opt+size+sections*40<=len(data),'Bounded PE sections')
    matches=[]
    for i in range(sections):
        section=opt+size+i*40;virtual_size,virtual_address,raw_size,raw=struct.unpack_from('<IIII',data,section+8)
        if virtual_address<=rva and rva+72<=virtual_address+raw_size:
            pos=raw+rva-virtual_address;need(pos+72<=len(data),'CLR raw bound');matches.append(pos)
    need(len(matches)==1,'Unique CLR directory mapping')
    flags=struct.unpack_from('<I',data,matches[0]+16)[0];need(flags&3==3 and flags&0x10==0,'ILONLY and 32BITREQUIRED, no native entrypoint')
    return {'machine':'i386','optionalHeader':'PE32','subsystem':2,'clrFlags':flags,'testFixture':True,'normalProduct':False,'executed':False}

def validate_precompile_failure(old,c,inputs,source_freeze,spec_fact):
    need(old['status']=='FAIL_COMPILE_ONLY_RETAIN_ORIGINALS' and old['cleanup']=='NOT_RUN' and old['createdRootKnown'] is True and old['remoteReturnUnknown'] is False,'Original known precompile failure only')
    need(old['remoteRoot']==c['root'] and old['nonce']==c['nonce'] and old['sshAlias']==HOST and old['sourceFreeze']==source_freeze and old['spec']==spec_fact,'Original same spec/source/root')
    need(old['remoteMsiStarted'] is False and old['remoteHelperExecuted'] is False,'Original no MSI/helper')
    native=old['native']
    need(native['status']=='FAIL_COMPILE_ONLY_RETAIN_ROOT' and native['receipt'] is None and native['error']['type']=='System.Management.Automation.PSSecurityException' and native['powershellParse']==[],'Exact script-policy rejection before compiler')
    need(inventory_identity({'files':native['uploaded'],'directories':[]})==inventory_identity({'files':inputs,'directories':[]}),'Original four uploads exact same bytes')
    ops=old['operations']
    need([r['name'] for r in ops]==['01-create-protected-root','02-upload-four-inputs','03-original-compile-parent'],'Exact original stages')
    need([r['actualLocalExit'] for r in ops]==[0,0,1] and all(r['localParentReaped'] is True and r['timedOut'] is False and r['remoteReturnKnown'] is True for r in ops),'Original natural exits 0/0/1')
    marker=b'future-classroom-owned-r79-early-terminal-fixture/v1\n'
    return {'files':sorted(inputs+[{'path':'.owner','bytes':len(marker),'sha256':sha(marker)}],key=lambda r:r['path']),'directories':[]}

def validate_readonly_failure(old,root,source_freeze,spec_fact,original_fact,expected_inventory,stdout):
    need(old['status']=='FAIL_COMPILE_ONLY_RETAIN_ORIGINALS' and old['error']=='Original-five and precompile zero actual facts' and old['remoteReturnUnknown'] is False,'Exact second read-only comparison failure')
    need(old['remoteRoot']==root and old['sourceFreeze']==source_freeze and old['spec']==spec_fact and old['recoveryOriginal']['sha256']==original_fact['sha256'],'Same original root/spec/source/failure')
    need(old['remoteMsiStarted'] is False and old['remoteHelperExecuted'] is False and old['cleanup']=='NOT_RUN' and 'native' not in old,'Second never compiled or ran helper/MSI')
    rows=old['operations'];need(len(rows)==1 and rows[0]['name']=='00-recover-exact-precompile-root' and rows[0]['actualLocalExit']==0 and rows[0]['localParentReaped'] is True and rows[0]['timedOut'] is False and rows[0]['remoteReturnKnown'] is True,'Only original read-only parent actual0')
    actual=json.loads(stdout.decode('utf-8-sig'))
    need(actual['status']=='PASS_EXACT_FIVE_PRECOMPILE_ORIGINALS_ZERO_OWN_COMPILER_HELPER' and actual['ownCandidates']==[] and actual['recreated'] is False and actual['overwritten'] is False and actual['root']==root,'Actual second zero-process/no-write facts')
    need(inventory_identity(actual['inventory'])==inventory_identity(expected_inventory),'Exact original five identities despite original ordering')
    return actual

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--execute',action='store_true');p.add_argument('--prototype-freeze',type=Path);p.add_argument('--prototype-freeze-sha256');p.add_argument('--spec',type=Path);p.add_argument('--spec-sha256');p.add_argument('--output-dir',type=Path)
    p.add_argument('--recover-precompile-report',type=Path);p.add_argument('--recover-precompile-report-sha256')
    p.add_argument('--recover-readonly-report',type=Path);p.add_argument('--recover-readonly-report-sha256')
    a=p.parse_args()
    if not a.execute:
        print(json.dumps({'status':'PREPARED_COMPILE_ONLY_TRANSPORT_NOT_RUN','windows':'NOT_CONTACTED','compilation':'NOT_RUN','MSI':'NOT_RUN','sshAlias':HOST}));return 0
    need(all((a.prototype_freeze,a.prototype_freeze_sha256,a.spec,a.spec_sha256,a.output_dir)),'Explicit second freeze/spec/output required')
    need((E/'.owner').read_bytes()==b'future-classroom-owned-r79-msi-maintenance/v1\n','R79 owner')
    freeze_path=regular_owned(a.prototype_freeze);need(freeze_path.parent==PROTOTYPE,'Only reviewed SECOND prototype; first is not executable here')
    need(fact(freeze_path)['sha256']==a.prototype_freeze_sha256,'Exact prototype freeze SHA')
    freeze=json.loads(freeze_path.read_text());need(freeze['root']==str(PROTOTYPE) and freeze['status']=='FROZEN_PREPARATION_ONLY_NOT_RUNTIME','Closed second freeze')
    def source_guard():
        for row in freeze['files']:
            need(re.fullmatch('[A-Za-z0-9._-]+',row['path']) is not None and row['path'] not in ('.','..'),'Direct frozen source')
            need(fact(PROTOTYPE/row['path'])=={k:row[k] for k in ('bytes','sha256')},'Frozen prototype source changed')
    source_guard()
    spec_path=regular_owned(a.spec);need(fact(spec_path)['sha256']==a.spec_sha256,'Exact spec SHA')
    code=runpy.run_path(str(PROTOTYPE/'fixture.py'))
    spec=code['load_spec'](spec_path,a.spec_sha256)
    need(spec['expectedUserSid']==SID,'Authorized Win11 current user SID only')
    out=regular_owned(a.output_dir);need(out.parent==E and not out.exists(),'Fresh direct owned result directory')
    out.mkdir();(out/'.owner').write_text('future-classroom-owned-r79-early-compile-transport-result/v1\n')
    upload=out/'upload';upload.mkdir()
    for name in ('PositiveControl.cs','Compile-PositiveControl.ps1'):(upload/name).write_bytes((PROTOTYPE/name).read_bytes())
    (upload/'spec.json').write_bytes(spec_path.read_bytes())
    manifest={'schemaVersion':1,'status':'COMPILE_INPUTS_ONLY_NOT_EXECUTED','prototypeFreeze':{'path':str(freeze_path),**fact(freeze_path)},'specSha256':a.spec_sha256,'files':[{'path':x.name,**fact(x)} for x in sorted(upload.iterdir())]}
    (upload/'compile-inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
    inputs=[{'path':x.name,**fact(x)} for x in sorted(upload.iterdir())]
    need(len(inputs)==4,'Exactly four upload inputs')
    c={'nonce':spec['nonce'],'root':spec['windowsRoot'],'sid':SID,'specSha256':a.spec_sha256,'files':inputs}
    report={'status':'RUNNING_COMPILE_ONLY','scope':'Four fixed uploads; PS AST and csc x86 GUI compile only, never run helper or MSI','sourceFreeze':{'path':str(freeze_path),**fact(freeze_path)},'spec':{'path':str(spec_path),**fact(spec_path)},'sshAlias':HOST,'remoteRoot':c['root'],'nonce':spec['nonce'],'operations':[],'runtimeBudgetsUnchanged':{'scenarioSeconds':600,'clientMaximumSeconds':120,'finallyReserveSeconds':180},'originalCompileTransportSeconds':120,'originalCompilerSeconds':30,'downloadVerified':False,'cleanup':'NOT_RUN','startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    rp=out/'compile-operation.json';start=time.monotonic();uncertain=False;created=False
    recovery=None
    if a.recover_precompile_report or a.recover_precompile_report_sha256:
        need(a.recover_precompile_report and a.recover_precompile_report_sha256,'Both recovery original report and SHA')
        original=regular_owned(a.recover_precompile_report)
        need(fact(original)['sha256']==a.recover_precompile_report_sha256,'Original immutable failure report SHA')
        need(fact(E/'early-terminal-transport-preparation-first/compile-only.py')['sha256']==FIRST_TRANSPORT_SHA,'Original first producer bytes')
        old=json.loads(original.read_text())
        recovery=validate_precompile_failure(old,c,inputs,report['sourceFreeze'],report['spec'])
        for row in old['operations']:
            for key in ('stdout','stderr'):
                f=row[key];need(fact(original.parent/f['path'])=={k:f[k] for k in ('bytes','sha256')},'Original failed raw stdout/stderr preserved')
        c['originalInventory']=recovery
        report['recoveryOriginal']={'path':str(original),**fact(original),'originalProducerSha256':FIRST_TRANSPORT_SHA,'expectedOriginalInventory':recovery,'originalFailurePreserved':True}
        need(a.recover_readonly_report and a.recover_readonly_report_sha256,'Explicit second read-only failure binding required for third recovery')
        readonly=regular_owned(a.recover_readonly_report);need(fact(readonly)['sha256']==a.recover_readonly_report_sha256,'Immutable second read-only failure SHA')
        need(fact(E/'early-terminal-transport-preparation-second/compile-only.py')['sha256']==SECOND_TRANSPORT_SHA,'Original second producer bytes')
        prior=json.loads(readonly.read_text());prior_out=prior['operations'][0]['stdout'];prior_err=prior['operations'][0]['stderr']
        for artifact in (prior_out,prior_err):need(fact(readonly.parent/artifact['path'])=={k:artifact[k] for k in ('bytes','sha256')},'Original second raw bytes unchanged')
        actual=validate_readonly_failure(prior,c['root'],report['sourceFreeze'],report['spec'],report['recoveryOriginal'],recovery,(readonly.parent/prior_out['path']).read_bytes())
        report['recoveryReadonlyOriginal']={'path':str(readonly),**fact(readonly),'originalProducerSha256':SECOND_TRANSPORT_SHA,'actualReadonlyFacts':actual,'originalFailurePreserved':True}
    else:
        need(not a.recover_readonly_report and not a.recover_readonly_report_sha256,'Read-only recovery binding requires original precompile report')
    def save():rp.write_text(json.dumps(report,indent=2)+'\n')
    def call(name,argv,feed=None,limit=15):
        nonlocal uncertain
        left=120-(time.monotonic()-start);need(left>0,'Original compile transport deadline')
        stdout=b'';stderr=b'';proc=None;code=None;timed=False;began=time.monotonic()
        try:
            proc=subprocess.Popen(argv,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            try:stdout,stderr=proc.communicate(feed,timeout=min(left,limit))
            except subprocess.TimeoutExpired:
                timed=True;uncertain=True;proc.kill();stdout,stderr=proc.communicate() # only this local SSH/SCP process; remote is UNKNOWN
            code=proc.returncode
        finally:
            row={'name':name,'argv':argv,'actualLocalExit':code,'localParentReaped':bool(proc and proc.poll() is not None),'timedOut':timed,'remoteReturnKnown':code is not None and not timed,'seconds':time.monotonic()-began}
            if feed is not None:
                ip=out/(name+'.stdin.ps1');ip.write_bytes(feed);row['stdin']={'path':ip.name,**fact(ip)}
            for label,data in (('stdout',stdout),('stderr',stderr)):
                q=out/(name+'.'+label+'.log');q.write_bytes(data);row[label]={'path':q.name,**fact(q)}
            report['operations'].append(row);save()
        need(not timed and code is not None,'REMOTE_UNKNOWN_RETAIN_NO_FURTHER_OPERATIONS')
        return code,stdout
    def ps(name,script,config=None,limit=15):
        cfg=c if config is None else config
        source=("$c='"+json.dumps(cfg,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+COMMON+script).encode('utf-8')
        # Current child process only; no Set-ExecutionPolicy or persistent state.
        command='powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand '+base64.b64encode(BOOT.encode('utf-16-le')).decode()
        return call(name,['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8',HOST,command],source,limit)
    save()
    try:
        if recovery is not None:
            rc,raw=ps('00-recover-exact-precompile-root',RECOVER);need(rc==0,'Actual original-five recovery check SSH0')
            actual=json.loads(raw.decode('utf-8-sig'));need(actual['status']=='PASS_EXACT_FIVE_PRECOMPILE_ORIGINALS_ZERO_OWN_COMPILER_HELPER' and inventory_identity(actual['inventory'])==inventory_identity(recovery) and actual['ownCandidates']==[] and actual['recreated'] is False and actual['overwritten'] is False,'Original-five and precompile zero actual facts')
            report['recoveryActual']=actual;created=True
        else:
            rc,raw=ps('01-create-protected-root',CREATE);need(rc==0,'Create actual SSH exit0')
            created_fact=json.loads(raw.decode('utf-8-sig'));need(created_fact['status']=='PASS_CREATED_ONLY_PROTECTED_COMPILE_ROOT' and created_fact['root']==c['root'] and created_fact['sid']==SID,'Actual created root facts');created=True;report['createdRoot']=created_fact
            rc,_=call('02-upload-four-inputs',['scp','-q','-o','BatchMode=yes','-o','ConnectTimeout=8',*[str(x) for x in sorted(upload.iterdir())],HOST+':'+c['root'].replace('\\','/')+'/'],limit=30);need(rc==0,'Actual four-input SCP exit0')
        rc,raw=ps('03-original-compile-parent',COMPILE,limit=45)
        native=json.loads(raw.decode('utf-8-sig'));report['native']=native
        need(rc==0 and native['status']=='PASS_CSC_ONLY_PARENT_RETURNED_NO_EXE_OR_MSI_EXECUTION','Actual compile-only parent success')
        receipt=native['receipt'];need(receipt['source']==fact(PROTOTYPE/'PositiveControl.cs') and receipt['actualExit']==0 and receipt['nonce']==spec['nonce'],'Actual source-bound receipt')
        rc,raw=ps('04-readonly-inventory','Inventory|ConvertTo-Json -Depth 20 -Compress');need(rc==0,'Actual inventory parent0');inventory=json.loads(raw);validate_inventory(inventory);report['inventory']=inventory
        by_name={r['path']:r for r in inventory['files']}
        for item in inputs:need(by_name.get(item['path'])==item,'Original upload bytes unchanged')
        needed={'PositiveControl.exe','positive-compile-receipt.json','csc.stdout.log','csc.stderr.log','.owner'}
        need(needed<=set(by_name),'Original compiled artifacts and raw logs required')
        for rel in by_name:need(rel in needed|{x['path'] for x in inputs} or rel.startswith('csc-owned-temp/'),'Only original inputs/compiler owned artifacts')
        download=out/'download';download.mkdir()
        for d in sorted(inventory['directories'],key=lambda s:(s.count('/'),s)):(download/d).mkdir()
        for i,item in enumerate(inventory['files']):
            target=download/item['path'];target.parent.mkdir(parents=True,exist_ok=True)
            remote=HOST+':'+(c['root']+'\\'+item['path'].replace('/','\\')).replace('\\','/')
            rc,_=call('05-download-'+str(i).zfill(2),['scp','-q','-o','BatchMode=yes','-o','ConnectTimeout=8',remote,str(target)],limit=15);need(rc==0 and fact(target)=={k:item[k] for k in ('bytes','sha256')},'Actual original download SHA')
        disk_receipt=json.loads((download/'positive-compile-receipt.json').read_text(encoding='utf-8-sig'));need(disk_receipt==receipt,'Original receipt bytes parsed equal parent facts')
        need(fact(download/'PositiveControl.exe')==receipt['exe'],'Original EXE byte receipt')
        report['pe']=pe32_gui_managed_x86((download/'PositiveControl.exe').read_bytes())
        report['downloadVerified']=True
        rc,raw=ps('06-second-readonly-inventory','Inventory|ConvertTo-Json -Depth 20 -Compress');need(rc==0 and inventory_identity(json.loads(raw))==inventory_identity(inventory),'Exact remote originals stable after download')
        source_guard();report['sourceUnchanged']=True
        cfg={**c,'inventory':inventory};rc,raw=ps('07-delete-only-downloaded-root',DELETE,cfg);need(rc==0,'Actual exact cleanup parent0');clean=json.loads(raw);need(clean['status']=='PASS_REMOVED_EXACT_DOWNLOADED_COMPILE_ROOT' and clean['knownAbsent'] is True,'Actual root known absence')
        report['cleanup']=clean;report['status']='PASS_CSC_COMPILE_DOWNLOAD_EXACT_CLEANUP_ONLY_MSI_NOT_RUN'
    except Exception as error:
        report.update(status='FAIL_COMPILE_ONLY_RETAIN_ORIGINALS',errorType=type(error).__name__,error=str(error),createdRootKnown=created,remoteReturnUnknown=uncertain)
        # No automatic further connection or deletion on any failed/unknown
        # stage. A root operator may later resolve exact original identities.
    finally:
        report['elapsedSeconds']=time.monotonic()-start;report['remoteMsiStarted']=False;report['remoteHelperExecuted']=False;save()
    print(json.dumps({'status':report['status'],'report':str(rp),'sha256':fact(rp)['sha256'],'remoteRoot':c['root'],'cleanup':report['cleanup']}))
    return 0 if report['status'].startswith('PASS_') else 1

if __name__=='__main__':raise SystemExit(main())
