#!/usr/bin/env python3
"""Pure finite transport contract checks. No network/compiler/MSI calls."""
import ast,copy,hashlib,json,runpy,subprocess,sys
from pathlib import Path
D=Path(__file__).resolve().parent;E=D.parent
m=runpy.run_path(str(D/'run-runtime.py'));observed=[]
def check(name,f):
 f();observed.append({'name':name,'status':'PASS'})
def yes(v):
 if not v:raise AssertionError('Expected true')
def rejects(f):
 try:f()
 except (ValueError,KeyError,TypeError):return
 raise AssertionError('Expected closed rejection')
check('Python AST',lambda:ast.parse((D/'run-runtime.py').read_text()))
row={'path':'x.json','bytes':1,'sha256':'0'*64};v={'files':[row,dict(row,path='effect/payload.txt')],'directories':['effect']}
check('Inventory order is not identity',lambda:yes(m['inventory_identity'](v)==m['inventory_identity']({'files':list(reversed(v['files'])),'directories':['effect']})))
check('Duplicate file rejected',lambda:rejects(lambda:m['inventory_identity']({'files':[row,row],'directories':[]})))
check('Traversal rejected',lambda:rejects(lambda:m['inventory_identity']({'files':[dict(row,path='../foreign')],'directories':[]})))
check('Unknown subdirectory rejected',lambda:rejects(lambda:m['inventory_identity']({'files':[],'directories':['foreign']})))
check('New empty registry parent is retained failure',lambda:yes(not m['parent_preserved']({'status':'KNOWN_ABSENT'},{'status':'PRESENT'})))
parent={'status':'PRESENT','ownerSid':'S-1-5-21-1','securityDescriptor':'D:','valueNames':['a','b'],'subkeyNames':['original']}
check('Existing parent order independent',lambda:yes(m['parent_preserved'](parent,{**parent,'valueNames':['b','a']})))
cap={'Kind':'process','Status':'HELD_ORIGINAL_IDENTITY','Pid':1,'Creation':2,'Wait':0,'ExitKnown':True,'ExitCode':0,'CheckedClose':True,'CloseAttempted':True}
check('Actual original process capability accepted',lambda:yes(m['returned'](cap)))
for k,val in [('ExitCode',None),('ExitCode',False),('Wait',False),('ExitKnown',False),('CheckedClose',False)]:
 check('Reject unknown or malformed original '+k+' '+str(val),lambda k=k,val=val:yes(not m['returned']({**cap,k:val})))
spec=json.loads((E/'early-terminal-stage-runtime-first/spec.json').read_text())
r={'systemPaths':[],'cases':[]}
log="MSI (s): Package we're running from ==> C:\\Windows\\Installer\\a123.msi\r\nMSI (s): Running Script: C:\\Windows\\Installer\\MSIAB.tmp\r\n"
check('Only own log exact cache/script parsing',lambda:yes(len(m['collect_exact_paths'](r,{'owned.log':log},spec))==2))
check('Wrong external path rejected',lambda:rejects(lambda:m['collect_exact_paths'](r,{'owned.log':log.replace('C:\\Windows\\Installer\\a123.msi','C:\\other\\a123.msi')},spec)))
check('Original UTF16 log preserved/decode',lambda:yes(m['decode_log'](log.encode('utf-16'))==log))
def run(label,args):
 p=subprocess.run([sys.executable,str(D/'run-runtime.py'),*args],capture_output=True)
 (D/(label+'.stdout.log')).write_bytes(p.stdout);(D/(label+'.stderr.log')).write_bytes(p.stderr)
 yes(p.returncode==0);return {'label':label,'argv':[sys.executable,str(D/'run-runtime.py'),*args],'actualExit':p.returncode,'localParentReaped':True,'stdoutSha256':hashlib.sha256(p.stdout).hexdigest(),'stderrSha256':hashlib.sha256(p.stderr).hexdigest()}
commands=[run('default',[])]
der=E/'early-terminal-inputs-derived-fifth/derivation.json'
args=['--validate-inputs-only','--prototype-freeze',str(E/'early-terminal-preparation-fifth/freeze-fifth.json'),'--prototype-freeze-sha256','378c0ad3e716effb5a2215fd7c6d58ba1a9fb3eba3f7ead88d114772e2752a2b','--stage-dir',str(E/'early-terminal-stage-runtime-first'),'--manifest-sha256','2fb3a130d04c21156a9c8599a681f4aaccf40b98865b0f15427928c01868cf68','--spec-derivation',str(der),'--spec-derivation-sha256',hashlib.sha256(der.read_bytes()).hexdigest(),'--gui-compile-report',str(E/'early-terminal-compile-fifth/compile-operation.json'),'--gui-compile-report-sha256','b69d863edd80ac22c2eae52f98740664dd9b559367cfe2708b0b3ace0be52943','--output-dir',str(E/'early-terminal-runtime-first')]
commands.append(run('actual-local-admission',args));yes(not (E/'early-terminal-runtime-first').exists())
report={'status':'PASS_PREPARATION_PURE_AND_LOCAL_ADMISSION_ONLY','checks':observed,'commands':commands,'Windows':'NOT_CONTACTED','PS51_AST':'NOT_RUN','CSharp':'NOT_COMPILED','MSI':'NOT_RUN','outputCreated':False}
(D/'preparation-validation-first.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'pureChecks':len(observed)}))
