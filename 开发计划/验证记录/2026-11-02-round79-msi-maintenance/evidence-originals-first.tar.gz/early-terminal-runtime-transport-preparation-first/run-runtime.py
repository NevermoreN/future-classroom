#!/usr/bin/env python3
"""Root-only independent fixture transport. Default inert; not product authority.
Only actual stage-runtime artifacts, source freeze and GUI derivation admitted.
"""
import argparse,base64,datetime,hashlib,json
from pathlib import Path,PureWindowsPath
import re,runpy,subprocess,time
E=Path('/tmp/fc-round79-msi-maintenance')
PROTOTYPE=E/'early-terminal-preparation-fifth'
BASE=E/'early-terminal-transport-preparation-fifth/compile-only.py'
BASE_SHA='3b3aa837646c78157c0c8ce1d5d44f4325f8bcdd34f4fc59e85c801b555a4783'
NAMES={'EarlyTerminal.c','PositiveControl.cs','Compile-PositiveControl.ps1','Invoke-EarlyTerminal.ps1','Capture.cs','fixture.py','spec.json','positive.msi','early-fail.msi','PositiveControl.exe','EarlyTerminal.dll','payload.txt','build-report.json','.owner'}
DIRS=('instrument-compiler-temp','readback-compiler-temp','positive-positive-raw','early-fail-positive-raw','effect')
PARENT_PS=r'''
function Parent-State {
 $base=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry32);$key=$null
 try{
  $key=$base.OpenSubKey('Software\FutureClassroomTest',$false)
  if($null-eq $key){return @{status='KNOWN_ABSENT';key='Software\FutureClassroomTest';view='Registry32'}}
  $values=@($key.GetValueNames());$subkeys=@($key.GetSubKeyNames());Need ($values.Count-le 64 -and $subkeys.Count-le 128) 'PARENT_SNAPSHOT_BOUND'
  $acl=$key.GetAccessControl([Security.AccessControl.AccessControlSections]::Owner -bor [Security.AccessControl.AccessControlSections]::Access)
  @{status='PRESENT';key='Software\FutureClassroomTest';view='Registry32';ownerSid=$acl.GetOwner([Security.Principal.SecurityIdentifier]).Value;securityDescriptor=$acl.GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]::Owner -bor [Security.AccessControl.AccessControlSections]::Access);valueNames=@($values|Sort-Object);subkeyNames=@($subkeys|Sort-Object)}
 }finally{if($null-ne $key){$key.Dispose()};$base.Dispose()}
}
'''
INVENTORY_PS=r'''
function Inventory {
 Root-Check;$files=@();$dirs=@();$total=0L;$queue=[Collections.Generic.Queue[string]]::new();$queue.Enqueue($c.root)
 while($queue.Count){$dir=$queue.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){
  $attrs=[IO.File]::GetAttributes($p);Need (($attrs-band[IO.FileAttributes]::ReparsePoint)-eq 0) 'INVENTORY_REPARSE'
  $rel=$p.Substring($c.root.Length+1).Replace('\','/')
  if(($attrs-band[IO.FileAttributes]::Directory)-ne 0){$top=($rel-split '/')[0];Need ($top-cin @('instrument-compiler-temp','readback-compiler-temp','positive-positive-raw','early-fail-positive-raw','effect')) 'ONLY_OWN_FIXTURE_SUBDIRECTORIES';$dirs+=$rel;$queue.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256};$total+=$f.bytes}
  Need ($files.Count-le 256 -and $dirs.Count-le 32 -and $total-le 67108864) 'RUNTIME_INVENTORY_BOUND'
 }}
 @{files=$files;directories=$dirs}
}
'''
READBACK_PS=r'''
Root-Check
$item=@($c.manifest.files|Where-Object path -CEQ 'Capture.cs');Need ($item.Count-eq 1 -and (Fact (Join-Path $c.root 'Capture.cs')).sha256-ceq $item[0].sha256) 'FROZEN_READONLY_CAPTURE_SOURCE'
$beforeTemp=$env:TEMP;$beforeTmp=$env:TMP
try{$env:TEMP=Join-Path $c.root 'readback-compiler-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP);Add-Type -Path (Join-Path $c.root 'Capture.cs') -ErrorAction Stop}finally{$env:TEMP=$beforeTemp;$env:TMP=$beforeTmp}
$product=[Fc79Capture]::Product($c.spec.productCode,$c.spec.upgradeCode,$c.sid)
$components=[Fc79Capture]::Components($c.spec.productCode,$c.spec.componentId,$c.sid)
$registry=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry32);$key=$null
try{$key=$registry.OpenSubKey($c.spec.registryKey,$false);$markerAbsent=($null-eq $key)}finally{if($null-ne $key){$key.Dispose()};$registry.Dispose()}
$effect=[Fc79Capture]::Absence($c.spec.effectDir.TrimEnd('\'));$paths=@()
foreach($path in $c.paths){$paths+=@{path=$path;fact=[Fc79Capture]::Absence($path)}}
$parent=Parent-State
$known=(@($product.registrations).Count-eq 0 -and @($product.related).Count-eq 0 -and $product.localPackageRc-eq 1605 -and $components.allUnknownStates-eq $true -and $markerAbsent -and $effect.status-ceq 'KNOWN_ABSENT')
@{status='ACTUAL_READONLY_FIXTURE_AND_EXACT_SYSTEM_PATH_FACTS';product=$product;components=$components;markerKnownAbsent=$markerAbsent;effect=$effect;fixtureKnownAbsent=$known;registryParent=$parent;paths=$paths;msiExecuted=$false;sharedServiceKilled=$false}|ConvertTo-Json -Depth 30 -Compress
'''

def need(ok,s):
 if not ok:raise ValueError(s)
def sha(b):return hashlib.sha256(b).hexdigest()
def fact(p):
 need(p.is_file() and not p.is_symlink(),'Original regular file');b=p.read_bytes();need(len(b)<=32*1024*1024,'Bounded local file');return {'bytes':len(b),'sha256':sha(b)}
def owned(p):
 need(p.is_absolute() and p.resolve()==p and p.is_relative_to(E),'Canonical owned R79 local path');return p
def inventory_identity(v):
 need(set(v)=={'files','directories'} and len(v['files'])<=256 and len(v['directories'])<=32,'Inventory shape/bound')
 files={};total=0
 for row in v['files']:
  need(set(row)=={'path','bytes','sha256'},'Exact file fields');rel=row['path'];need(isinstance(rel,str) and rel and ':' not in rel and '\\' not in rel and all(x not in ('','.','..') for x in rel.split('/')) and rel not in files,'Safe unique file path')
  need(type(row['bytes']) is int and 0<=row['bytes']<=16777216 and re.fullmatch('[0-9a-f]{64}',row['sha256']),'File size/hash');files[rel]=(row['bytes'],row['sha256']);total+=row['bytes']
 need(total<=67108864 and len(set(v['directories']))==len(v['directories']),'Inventory total/unique dirs')
 for rel in v['directories']:need(rel and ':' not in rel and '\\' not in rel and all(x not in ('','.','..') for x in rel.split('/')) and rel.split('/')[0] in DIRS and rel not in files,'Only owned fixture directories')
 return files,set(v['directories'])
def returned(x):
 return isinstance(x,dict) and x.get('Kind')=='process' and x.get('Status')=='HELD_ORIGINAL_IDENTITY' and type(x.get('Pid')) is int and x['Pid']>0 and type(x.get('Creation')) is int and x['Creation']>0 and type(x.get('Wait')) is int and x.get('Wait')==0 and x.get('ExitKnown') is True and type(x.get('ExitCode')) is int and x.get('CheckedClose') is True and x.get('CloseAttempted') is True
def validate_phase(r,spec,helper_sha):
 need(r['status']=='PASS_FIXTURE_OBSERVATIONS_NOT_PRODUCTION_TERMINAL_AUTHORITY' and r['authority']=='NONE_FOR_PRODUCTION_TERMINAL_SETTLEMENT' and r['errors']==[],'Original complete observation scope PASS only')
 need(r['wholeSeconds']==600 and r['nativeSeconds']==120 and r['finallyReserveSeconds']==180 and type(r['elapsedMilliseconds']) is int and r['elapsedMilliseconds']<600000,'Original 600/120/180 unchanged')
 need(r['nativeCloseUnknown'] is False and r['afterFinally']['knownAbsent'] is True and r['before']['knownAbsent'] is True,'No close poison; qualified before/final absence')
 need(all(r['attemptProvenance'][k] is True for k in ('baselineKnownAbsent','caseBaselineKnownAbsent','currentAttemptInstallerActuallyStarted','validated')),'Original attempt-owned provenance')
 cases=r['cases'];need(len(cases)==2 and [x['name'] for x in cases]==['positive','early-fail'],'Exact two original cases')
 objects=r['privateObjects'];need(all(x.get('CheckedClose') is True and x.get('CloseAttempted') is True for x in objects),'Every owned observation capability checked returned')
 need(r['nativeReturns'] and all(x['Attempted'] is True and x['Success'] is True and x['Unknown'] is False and x['LastError']==0 for x in r['nativeReturns']),'Every native close attempt known success')
 for case in cases:
  client=case['client'];cap=client['identity']['heldOriginal'];need(client['waitReturned'] is True and type(client['actualExit']) is int and returned(cap) and cap['ExitCode']==client['actualExit'],'Original client physical return/code/close')
  need(case['before']['knownAbsent'] is True and case['after']['knownAbsent'] is True,'Case before/after qualified absence')
  if case.get('supervisorCaptured') is True:
   identity=case['supervisorIdentity'];matches=[x for x in objects if x.get('Kind')=='process' and x.get('Pid')==identity['pid'] and x.get('Creation')==identity['creationFiletime']]
   need(len(matches)==1 and returned(matches[0]) and matches[0]['ExitCode']==0 and identity['nonce']==spec['nonce'] and identity['sid']==spec['expectedUserSid'] and identity['imageSha256']==helper_sha,'Original positive supervisor physical return/source/SID')
 if cases[0]['supervisorCaptured'] is not True or cases[0]['realJoinEndRollback'] is not True:raise ValueError('Real positive Join/EndRollback not established')
 p=cases[0]['positiveFacts'];need(p['JOIN_RETURN.json']['returnCode']==0 and p['END_RETURN.json']['returnCode']==0 and p['CHANGE_EVENT_CLOSED.json']['checkedClose'] is True and p['CHILD_EXIT_RETURN.json']['actualExitCode']==0 and p['CHILD_PROCESS_CLOSED.json']['checkedClose'] is True,'Actual API/child return facts separate from engine logs')
 need(cases[1]['client']['actualExit']==1603 and cases[1]['requiredCallbackFactsValid'] is True,'Actual failure code and valid required callbacks')
 need(all(x['waitReturned'] is True and type(x['actualExit']) is int and returned(x['heldOriginal']) and x['heldOriginal']['ExitCode']==x['actualExit'] for x in r['formalUninstalls']),'Any original formal cleanup clients returned')
 # Shared MSI host/thread Wait258 is intentionally not a failure or exit0.
 return {'status':'PASS_ORIGINAL_FIXTURE_CONTROLS_RETURNED_NO_CLOSE_POISON','sharedHostsMayRemainLive':True,'productionAuthority':'NONE'}
def parent_preserved(before,after):
 if before['status']=='KNOWN_ABSENT':return after['status']=='KNOWN_ABSENT'
 return before['status']==after['status']=='PRESENT' and before['ownerSid']==after['ownerSid'] and before['securityDescriptor']==after['securityDescriptor'] and set(before['valueNames'])==set(after['valueNames']) and set(before['subkeyNames'])==set(after['subkeyNames'])
def decode_log(data):
 need(len(data)<=8388608,'Bounded original MSI log')
 if data[:2]==b'\xff\xfe':return data.decode('utf-16','strict')
 if data[:2]==b'\xfe\xff':return data.decode('utf-16','strict')
 return data.decode('utf-8-sig','strict')
def collect_exact_paths(r,logs,spec):
 paths={};temp=PureWindowsPath(spec['windowsRoot']).parent
 def add(value,basis):
  p=PureWindowsPath(value)
  need(str(p)==value and p.is_absolute() and p.parent in (PureWindowsPath('C:\\Windows\\Installer'),temp) and re.fullmatch(r'(?:MSI[0-9a-f]+\.tmp|[0-9a-f]+\.msi)',p.name,re.I) and not any(x in value for x in ('\0','\r','\n','"')),'Exact own Installer/TEMP path only')
  paths.setdefault(str(p),set()).add(basis)
 for item in r['systemPaths']:add(item['fact']['path'],'original_driver_'+item['basis'])
 for case in r['cases']:
  if case.get('supervisorCaptured') is True:add(case['supervisorIdentity']['imagePath'],'original_held_supervisor')
  for record in case['nativeCallbacks']:
   if record['fields'].get('module') and record['fields']['module']!='UNKNOWN':add(record['fields']['module'],'original_dll_getmodulefilename')
 for name,text in logs.items():
  for line in text.splitlines():
   for marker,pattern in [('cache',r"Package we're running from ==> (.+)$"),('script',r'Running Script:\s*(.+)$'),('dll',r'Invoking remote custom action\. DLL:\s*(.+?),\s*Entrypoint:')]:
    m=re.search(pattern,line,re.I)
    if m:add(m.group(1).strip(),name+':'+marker)
 need(1<=len(paths)<=64 and any(any(v.endswith(':cache') for v in origins) for origins in paths.values()),'Original exact cache/log evidence required')
 return [{'path':p,'basis':sorted(v)} for p,v in sorted(paths.items())]

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--validate-inputs-only',action='store_true');p.add_argument('--prototype-freeze',type=Path);p.add_argument('--prototype-freeze-sha256');p.add_argument('--stage-dir',type=Path);p.add_argument('--manifest-sha256');p.add_argument('--spec-derivation',type=Path);p.add_argument('--spec-derivation-sha256');p.add_argument('--gui-compile-report',type=Path);p.add_argument('--gui-compile-report-sha256');p.add_argument('--output-dir',type=Path);a=p.parse_args()
 need(not(a.execute and a.validate_inputs_only),'Choose execute OR local validation only')
 if not a.execute and not a.validate_inputs_only:print(json.dumps({'status':'PREPARED_RUNTIME_TRANSPORT_NOT_RUN','Windows':'NOT_CONTACTED','MSI':'NOT_RUN','productionAuthority':'NONE','phaseSeconds':600,'clientSeconds':120,'finallyReserveSeconds':180}));return 0
 need(all((a.prototype_freeze,a.prototype_freeze_sha256,a.stage_dir,a.manifest_sha256,a.spec_derivation,a.spec_derivation_sha256,a.gui_compile_report,a.gui_compile_report_sha256,a.output_dir)),'Explicit accepted source/stage/GUI derivation/output arguments')
 need((E/'.owner').read_bytes()==b'future-classroom-owned-r79-msi-maintenance/v1\n','R79 owner');need(fact(BASE)['sha256']==BASE_SHA,'Reviewed base transport identity')
 transport_identity=fact(Path(__file__).resolve());base=runpy.run_path(str(BASE));freeze_path=owned(a.prototype_freeze);need(freeze_path.parent==PROTOTYPE and fact(freeze_path)['sha256']==a.prototype_freeze_sha256,'Explicit P5 source freeze')
 freeze=json.loads(freeze_path.read_text());need(freeze['status']=='FROZEN_PREPARATION_ONLY_NOT_RUNTIME' and freeze['root']==str(PROTOTYPE),'Closed P5 freeze')
 def sources():
  need(fact(Path(__file__).resolve())==transport_identity and fact(BASE)['sha256']==BASE_SHA,'Transport/base bytes unchanged')
  for row in freeze['files']:need(re.fullmatch('[A-Za-z0-9._-]+',row['path']) and row['path'] not in ('.','..') and fact(PROTOTYPE/row['path'])=={k:row[k] for k in ('bytes','sha256')},'Frozen source bytes unchanged')
 sources();stage=owned(a.stage_dir);need(stage.is_dir() and not stage.is_symlink(),'Original stage directory')
 need({x.name for x in stage.iterdir()}==NAMES|{'runtime-inputs.json'} and all(x.is_file() and not x.is_symlink() for x in stage.iterdir()),'Exact flat fifteen staged members')
 manifest_path=stage/'runtime-inputs.json';need(fact(manifest_path)['sha256']==a.manifest_sha256,'Actual runtime manifest SHA');manifest=json.loads(manifest_path.read_text());need(manifest['status']=='PREPARED_RUNTIME_NOT_RUN' and {x['path'] for x in manifest['files']}==NAMES and len(manifest['files'])==14,'Closed actual runtime manifest')
 for row in manifest['files']:need(fact(stage/row['path'])=={k:row[k] for k in ('bytes','sha256')},'Every staged original file matches actual manifest')
 module=runpy.run_path(str(PROTOTYPE/'fixture.py'));spec=module['load_spec'](stage/'spec.json',manifest['specSha256']);need(spec['expectedUserSid']==base['SID'],'Authorized current test user')
 build=json.loads((stage/'build-report.json').read_text());need(fact(stage/'build-report.json')['sha256']==manifest['buildReportSha256'] and build['status']=='PASS_LOCAL_BUILD_STATIC_ONLY_WINDOWS_NOT_RUN' and build['toolsUnchanged'] is True and build['sourcesUnchanged'] is True and build['specData']==spec and build['spec']==fact(stage/'spec.json') and build['script']==fact(PROTOTYPE/'fixture.py'),'Original actual static producer/source/spec closure')
 need(build['commands'] and all(type(x.get('actualExit')) is int and x.get('actualExit')==0 and x.get('parentReaped') is True and x.get('timeout') is not True for x in build['commands']),'Actual original local tool parent exits')
 for name,key in [('PositiveControl.exe','chainer'),('EarlyTerminal.dll','dll')]:need(fact(stage/name)==build[key],'Actual admitted Binary readback identity')
 for name in ('positive','early-fail'):need(fact(stage/(name+'.msi'))==build['cases'][name]['msi'] and build['cases'][name]['status']=='PASS_STATIC_ONLY_NOT_RUN','Actual closed MSI case identity')
 need(build['cases']['positive']['packageCode']!=build['cases']['early-fail']['packageCode'],'Distinct actual package identities')
 base['pe32_gui_managed_x86']((stage/'PositiveControl.exe').read_bytes())
 derivation_path=owned(a.spec_derivation);compile_path=owned(a.gui_compile_report);need(fact(derivation_path)['sha256']==a.spec_derivation_sha256 and fact(compile_path)['sha256']==a.gui_compile_report_sha256,'Original derivation and actual GUI compiler reports')
 d=json.loads(derivation_path.read_text());cc=json.loads(compile_path.read_text());need(d['status']=='PASS_LOCAL_SPEC_DERIVATION_ONLY_NOT_MSI_OR_RUNTIME_PASS' and d['derivedSpec']['sha256']==fact(stage/'spec.json')['sha256'] and d['actualCscCompiledUnderOriginalSpec']['report']=={'path':str(compile_path),**fact(compile_path)},'Actual old-CSC/new-producer derivation explicit')
 old_spec_path=owned(Path(d['originalSpec']['path']));need(fact(old_spec_path)=={k:d['originalSpec'][k] for k in ('bytes','sha256')},'Original compiled spec unchanged');old=json.loads(old_spec_path.read_text());reverted=json.loads(json.dumps(spec));old_rows={x['path']:x for x in old['sources']}
 for i,row in enumerate(reverted['sources']):
  if row['path']=='fixture.py':reverted['sources'][i]=old_rows['fixture.py']
 need(reverted==old and cc['spec']=={'path':str(old_spec_path),**fact(old_spec_path)} and cc['status']=='PASS_CSC_COMPILE_DOWNLOAD_EXACT_CLEANUP_ONLY_MSI_NOT_RUN' and cc['downloadVerified'] is True,'Only fixture.py metadata changed; original CSC remains bound to original spec')
 receipt=cc['native']['receipt'];need(type(receipt['actualExit']) is int and receipt['actualExit']==0 and receipt['source']==fact(PROTOTYPE/'PositiveControl.cs') and receipt['nonce']==spec['nonce'] and receipt['exe']==fact(stage/'PositiveControl.exe') and all(receipt[k] is True for k in ('originalHandleAcquired','processWaitReturned','pipesComplete','processDisposed')),'Actual unchanged GUI source/nonce/original compiler return')
 out=owned(a.output_dir);need(out.parent==E and not out.exists(),'Fresh direct owned result directory')
 if a.validate_inputs_only:
  print(json.dumps({'status':'PASS_LOCAL_ORIGINAL_STAGE_SOURCE_GUI_DERIVATION_ADMISSION_ONLY','stageManifest':fact(manifest_path),'spec':fact(stage/'spec.json'),'Windows':'NOT_CONTACTED','MSI':'NOT_RUN','outputCreated':False}));return 0
 out.mkdir();(out/'.owner').write_text('future-classroom-owned-r79-early-runtime-transport-result/v1\n')
 rp=out/'runtime-operation.json';report={'status':'RUNNING_FIXTURE_ONLY','productionAuthority':'NONE','transport':{'path':str(Path(__file__).resolve()),**transport_identity},'baseTransport':{'path':str(BASE),**fact(BASE)},'phaseSeconds':600,'clientSeconds':120,'finallyReserveSeconds':180,'latestNewClientStartCutoffSeconds':300,'outerTransportSeconds':900,'sourceFreeze':{'path':str(freeze_path),**fact(freeze_path)},'stageManifest':{'path':str(manifest_path),**fact(manifest_path)},'spec':fact(stage/'spec.json'),'guiOriginalCompileReport':{'path':str(compile_path),**fact(compile_path)},'specDerivation':{'path':str(derivation_path),**fact(derivation_path)},'operations':[],'cleanup':'NOT_RUN','startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 c={'root':spec['windowsRoot'],'nonce':spec['nonce'],'sid':base['SID'],'spec':spec,'manifest':manifest,'specSha256':manifest['specSha256'],'manifestSha256':a.manifest_sha256};report['remoteRoot']=c['root']
 common=base['COMMON'].split('function Inventory {')[0]+PARENT_PS+INVENTORY_PS
 start=time.monotonic();phase_natural=False;phase=None;download_ok=False;inventory=None
 def save():rp.write_text(json.dumps(report,indent=2)+'\n')
 def call(label,args,feed=None,limit=15):
  remaining=900-(time.monotonic()-start);need(remaining>0,'Original outer transport clock');proc=None;stdout=b'';stderr=b'';code=None;timed=False;began=time.monotonic()
  try:
   proc=subprocess.Popen(args,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   try:stdout,stderr=proc.communicate(feed,timeout=min(remaining,limit))
   except subprocess.TimeoutExpired:timed=True;proc.kill();stdout,stderr=proc.communicate() # only local ssh/scp; no remote kill
   code=proc.returncode
  finally:
   row={'label':label,'argv':args,'actualLocalExit':code,'localParentReaped':bool(proc and proc.poll() is not None),'remoteReturnKnown':code is not None and not timed,'timedOut':timed,'seconds':time.monotonic()-began}
   for ext,data in [('stdin.ps1',feed),('stdout.log',stdout),('stderr.log',stderr)]:
    if data is not None:q=out/(label+'.'+ext);q.write_bytes(data);row[ext]={'path':q.name,**fact(q)}
   report['operations'].append(row);save()
  need(not timed and code is not None,'Remote original return UNKNOWN; retain and stop');return code,stdout
 def ps(label,body,config=None,limit=15):
  cfg=c if config is None else config;feed=("$c='"+json.dumps(cfg,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+common+body).encode()
  cmd='powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand '+base64.b64encode(base['BOOT'].encode('utf-16-le')).decode();return call(label,['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8',base['HOST'],cmd],feed,limit)
 save()
 try:
  create=base['CREATE'].replace("@{status='PASS_CREATED_ONLY_PROTECTED_COMPILE_ROOT';root=$c.root;nonce=$c.nonce;sid=$c.sid}","@{status='PASS_CREATED_ONLY_PROTECTED_FIXTURE_RUNTIME_ROOT';root=$c.root;nonce=$c.nonce;sid=$c.sid;registryParentBefore=$parentBefore}")
  prefix="$who=[Security.Principal.WindowsIdentity]::GetCurrent();try{Need ($who.User.Value-ceq $c.sid) 'EXACT_USER_BEFORE_PARENT_QUERY'}finally{$who.Dispose()};$parentBefore=Parent-State;"
  code,raw=ps('01-before-parent-and-create',prefix+create);need(code==0,'Actual fresh protected root create0');before=json.loads(raw.decode('utf-8-sig'));need(before['status']=='PASS_CREATED_ONLY_PROTECTED_FIXTURE_RUNTIME_ROOT' and before['root']==c['root'],'Actual exact runtime root');report['before']=before
  files=[x for x in sorted(stage.iterdir()) if x.name!='.owner'];need(len(files)==14,'Fourteen uploads excluding remotely created marker')
  code,_=call('02-upload-actual-stage',['scp','-q','-o','BatchMode=yes','-o','ConnectTimeout=8',*[str(x) for x in files],base['HOST']+':'+c['root'].replace('\\','/')+'/'],limit=60);need(code==0,'Actual stage SCP0')
  run="Root-Check;& (Join-Path $c.root 'Invoke-EarlyTerminal.ps1') -Execute -Root $c.root -SpecSha256 $c.specSha256 -ManifestSha256 $c.manifestSha256"
  code,raw=ps('03-original-fixture-phase',run,limit=620);phase_natural=True;need(code in (0,1),'Actual phase parent code0/1');phase=json.loads(raw.decode('utf-8-sig'));report['phase']=phase;report['phaseParentExit']=code
  try:report['originalControlProof']=validate_phase(phase,spec,build['chainer']['sha256']);need(code==0,'Original phase parent must be actual0 for PASS')
  except Exception as error:report['phaseQualificationError']=str(error)
 except Exception as error:report.update(status='FAIL_FIXTURE_TRANSPORT_OR_PHASE_RETAIN',errorType=type(error).__name__,error=str(error))
 # Never query/delete after an unknown original phase SSH return. On known
 # failed parent return, raw file capture is read-only and never grants cleanup.
 if phase_natural:
  try:
   code,raw=ps('04-readonly-original-inventory','Inventory|ConvertTo-Json -Depth 30 -Compress');need(code==0,'Actual original inventory0');inventory=json.loads(raw);inventory_identity(inventory);report['inventory']=inventory
   download=out/'download';download.mkdir()
   for dname in sorted(inventory['directories'],key=lambda x:(x.count('/'),x)):(download/dname).mkdir(parents=True,exist_ok=True)
   for i,row in enumerate(inventory['files']):
    target=download/row['path'];target.parent.mkdir(parents=True,exist_ok=True);remote=base['HOST']+':'+(c['root']+'\\'+row['path'].replace('/','\\')).replace('\\','/')
    code,_=call('05-download-'+str(i).zfill(3),['scp','-q','-o','BatchMode=yes','-o','ConnectTimeout=8',remote,str(target)],limit=15);need(code==0 and fact(target)=={k:row[k] for k in ('bytes','sha256')},'Original captured byte/SHA')
   code,raw=ps('06-second-readonly-inventory','Inventory|ConvertTo-Json -Depth 30 -Compress');need(code==0 and inventory_identity(json.loads(raw))==inventory_identity(inventory),'Captured original inventory stable after download');download_ok=True;report['downloadVerified']=True
   need(json.loads((download/'early-terminal-result.json').read_text())==phase,'Original phase JSON file equals actual original stdout facts')
   need('phaseQualificationError' not in report and report.get('originalControlProof',{}).get('status')=='PASS_ORIGINAL_FIXTURE_CONTROLS_RETURNED_NO_CLOSE_POISON','Failed phase always retained even if capture complete')
   logs={name:decode_log((download/name).read_bytes()) for name in ('positive-msi.log','early-fail-msi.log')}
   if (download/'finally-uninstall.log').is_file():logs['finally-uninstall.log']=decode_log((download/'finally-uninstall.log').read_bytes())
   exact=collect_exact_paths(phase,logs,spec);report['derivedExactSystemPaths']=exact
   code,raw=ps('07-independent-final-readonly',READBACK_PS,{**c,'paths':[x['path'] for x in exact]},limit=45);need(code==0,'Actual readonly final parent0');readback=json.loads(raw);report['finalReadOnly']=readback
   need(readback['status']=='ACTUAL_READONLY_FIXTURE_AND_EXACT_SYSTEM_PATH_FACTS' and readback['fixtureKnownAbsent'] is True and {x['path'] for x in readback['paths']}=={x['path'] for x in exact} and len(readback['paths'])==len(exact) and all(x['fact']['status']=='KNOWN_ABSENT' for x in readback['paths']),'Exact original helper/DLL/cache/RunningScript and fixture absence')
   need(parent_preserved(before['registryParentBefore'],readback['registryParent']),'Registry parent changed or newly-created parent retained; no silent/manual deletion')
   # Readback Add-Type has its own owned compile files. Capture the complete
   # extended inventory too; never remove any undownloaded new compiler artifact.
   code,raw=ps('08-after-readonly-compiler-inventory','Inventory|ConvertTo-Json -Depth 30 -Compress');need(code==0,'Actual extended inventory0');extended=json.loads(raw);inventory_identity(extended)
   old_by={x['path']:x for x in inventory['files']};new_by={x['path']:x for x in extended['files']}
   need(all(new_by.get(k)==v for k,v in old_by.items()),'Original artifacts unchanged after readonly')
   for dname in sorted(extended['directories'],key=lambda x:(x.count('/'),x)):(download/dname).mkdir(parents=True,exist_ok=True)
   for i,row in enumerate(extended['files']):
    if row['path'] in old_by:continue
    need(row['path'].startswith('readback-compiler-temp/'),'Only final reader-owned compiler artifacts added');target=download/row['path'];target.parent.mkdir(parents=True,exist_ok=True);remote=base['HOST']+':'+(c['root']+'\\'+row['path'].replace('/','\\')).replace('\\','/')
    code,_=call('09-download-readback-'+str(i),['scp','-q','-o','BatchMode=yes','-o','ConnectTimeout=8',remote,str(target)],limit=15);need(code==0 and fact(target)=={k:row[k] for k in ('bytes','sha256')},'Original readback compiler artifact captured')
   sources();code,raw=ps('10-final-stable-inventory','Inventory|ConvertTo-Json -Depth 30 -Compress');need(code==0 and inventory_identity(json.loads(raw))==inventory_identity(extended),'Exact final inventory stable')
   code,raw=ps('11-exact-downloaded-root-delete',base['DELETE'].replace('PASS_REMOVED_EXACT_DOWNLOADED_COMPILE_ROOT','PASS_REMOVED_EXACT_DOWNLOADED_RUNTIME_ROOT'),{**c,'inventory':extended});need(code==0,'Actual exact cleanup parent0');cleanup=json.loads(raw);need(cleanup['status']=='PASS_REMOVED_EXACT_DOWNLOADED_RUNTIME_ROOT' and cleanup['knownAbsent'] is True,'Exact nonce root known absent')
   report['cleanup']=cleanup;report['finalInventory']=extended;report['status']='PASS_FINITE_EARLY_FAILURE_AND_REAL_ROLLBACK_FIXTURE_CAPTURE_CLEANUP_NOT_PRODUCTION_AUTHORITY'
  except Exception as error:report.update(status='FAIL_FIXTURE_CAPTURE_OR_QUALIFICATION_RETAIN',errorType=type(error).__name__,error=str(error),partialDownloadMayExist=True)
 report['elapsedSeconds']=time.monotonic()-start;report['originalPhaseNaturalReturn']=phase_natural;report['downloadVerified']=download_ok;save()
 print(json.dumps({'status':report['status'],'report':str(rp),'sha256':fact(rp)['sha256'],'remoteRoot':c['root'],'cleanup':report['cleanup']}));return 0 if report['status'].startswith('PASS_') else 1
if __name__=='__main__':raise SystemExit(main())
