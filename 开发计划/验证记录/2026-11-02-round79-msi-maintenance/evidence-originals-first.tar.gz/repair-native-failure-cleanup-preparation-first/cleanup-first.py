"""Root-only original failed native-test scratch capture/cleanup; default NOT_RUN."""
import argparse, ast, base64, hashlib, json, re, runpy, subprocess, time
from pathlib import Path
E=Path('/tmp/fc-round79-msi-maintenance')
D=E/'repair-candidate-native-first'
BASE=E/'negative-fixture-preparation-third/run-negative-msi-r79-third.py'
REPORT_SHA='24d7bbdffbce3d8406cc33c89cfc0f0d93cce054b0e0b5cdb4dac82e8f7022f8'
BASE_SHA='da74f0058deac86507b712075904556780be6b262b18acb82415da6725c6e202'
RAW_SHA='ea02d0d05d4ca3458d45ebe8ac28445218b8935427b86ac6ba892a7a0b613276'
ROOT=r'C:\Users\Elior\AppData\Local\Temp\FutureClassroom-r79-repair-native-3e27ed3f2f4a3ce31c35bbbea8dd1a75'
NONCE='3e27ed3f2f4a3ce31c35bbbea8dd1a75'
SID='S-1-5-21-3896111207-1867804362-1971593122-1001'
MARKER=b'future-classroom-owned-r79-repair-native-runtime/v1\n'
BOOT="[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()))"
def need(v,s):
 if not v:raise ValueError(s)
def fact(p):
 p=Path(p);need(p.is_file() and not p.is_symlink(),'REGULAR_LOCAL_ORIGINAL');b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def pinned(p,h):
 b=Path(p).read_bytes();need(hashlib.sha256(b).hexdigest()==h,'ORIGINAL_SHA:'+str(p));return b
def failure_gate():
 need((E/'.owner').read_bytes()==b'future-classroom-owned-r79-msi-maintenance/v1\n','E_OWNER')
 r=json.loads(pinned(D/'report.json',REPORT_SHA));need(r['status']=='FAIL_RETAIN_ORIGINALS' and r['cleanup']=='NOT_RUN' and r['windowsRoot']==ROOT and r['compiledExeUnchanged'] is True,'EXACT_ORIGINAL_FAIL')
 need(r['nativeInput']['bytes']==97328442 and r['nativeInput']['bytes']>64*1024*1024,'ORIGINAL_DEBUG_EXCEEDS_FIXTURE_LIMIT')
 ops=r['operations'];need([x['name'] for x in ops]==['create','upload-Capture.cs','upload-candidate-tests.exe','run'],'FOUR_ORIGINAL_OPERATIONS')
 for op in ops:
  need(op['originalLocalReaped'] is True and op['remoteOriginalReturnUnknown'] is False and op['budgetExceeded'] is False,'ORIGINAL_TRANSPORT_KNOWN_RETURN')
  for stream in ['stdout','stderr']:
   row=op[stream];need(fact(row['path'])=={k:row[k] for k in ['bytes','sha256']},'ORIGINAL_RAW_FACT')
 need([x['actualReturnCode'] for x in ops]==[0,0,0,1],'ORIGINAL_ACTUAL_RETURNS')
 n=json.loads(pinned(D/'run.stdout.log',RAW_SHA))
 need(n['status']=='FAIL_RETAIN' and n['error']=='NATIVE_TEST_FAILURE' and n['originalParentReturned'] is True and n['originalWholeSeconds']==600 and n['elapsedMilliseconds']==565 and n['captureSourceOnlyProcessMethods'] is True,'FINITE_NATIVE_FAIL_SCOPE')
 need(not n.get('closeError') and not n.get('budgetExceeded'),'NO_UNKNOWN_OR_CLOSE_FAULT')
 cases=n['cases'];need([x['name'] for x in cases]==['effects','lifecycle'] and [x['exitCode'] for x in cases]==[0,101],'ACTUAL_CASE_RETURNS')
 objects=n['originalObjects'];need(len(objects)==2 and len({(x['Pid'],x['Creation']) for x in objects})==2,'TWO_DISTINCT_ORIGINALS')
 for case,obj in zip(cases,objects):
  need(case['actualExit'] is True and case['pid']==obj['Pid'] and case['creation']==obj['Creation'] and case['original']==obj,'ORIGINAL_CASE_BINDING')
  need(obj['Status']=='HELD_ORIGINAL_IDENTITY' and obj['Kind']=='process' and obj['Wait']==0 and obj['ExitKnown'] is True and obj['CheckedClose'] is True and obj['ExitCode']==case['exitCode'] and obj['Image']==ROOT+'\\candidate-tests.exe' and obj['Sha256']==r['nativeInput']['sha256'] and obj['Sid']==SID and not obj['Error'],'ORIGINAL_RETURNED_CHECKED_CLOSED')
  need(case['endedWholeMilliseconds']<=case['originalDeadlineWholeMilliseconds'],'ORIGINAL_CASE_BUDGET')
 need('test result: ok. 9 passed; 0 failed; 0 ignored; 0 measured;' in cases[0]['stdout'],'FOCUSED9_PASS')
 need('test result: FAILED. 24 passed; 20 failed; 0 ignored; 0 measured;' in cases[1]['stdout'],'FULL24_PASS20_FAIL')
 need('native/broker.rs:1064:14:' in cases[1]['stderr'] and 'on an `Err` value: Invalid' in cases[1]['stderr'] and 'PoisonError' in cases[1]['stderr'],'ACTUAL_DEBUG_SIZE_FAILURE_AND_CASCADE')
 uploads={}
 for name,key in [('candidate-tests.exe','nativeInput'),('Capture.cs','capture')]:
  uploads[name]=fact(D/'upload'/name);need(uploads[name]=={k:r[key][k] for k in ['bytes','sha256']},'ORIGINAL_UPLOAD_PIN')
 need(fact(r['producer']['path'])=={k:r['producer'][k] for k in ['bytes','sha256']},'ORIGINAL_PRODUCER_UNCHANGED')
 need(pinned(BASE,BASE_SHA),'ORIGINAL_HELPER_PIN')
 return r,n,uploads

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--execute',action='store_true');ap.add_argument('--check-local',action='store_true');a=ap.parse_args()
 if not a.execute and not a.check_local:print('{"status":"NOT_RUN","scope":"failed native-test nonce scratch only"}');return 0
 original,native,uploads=failure_gate()
 if a.check_local:print(json.dumps(dict(status='PASS_LOCAL_FAILURE_RETURN_AND_INPUT_GUARDS_ONLY_WINDOWS_NOT_RUN',reportSha256=REPORT_SHA,rawSha256=RAW_SHA,parents=[{k:x[k] for k in ['Pid','Creation','ExitCode','CheckedClose']} for x in native['originalObjects']],root=ROOT,uploads=uploads),indent=2));return 0
 helper=runpy.run_path(str(BASE));common=helper['COMMON'].replace('r79-production-msi-','r79-repair-native-').replace('r79-production-msi-runtime/v1','r79-repair-native-runtime/v1')
 out=E/'repair-native-failure-cleanup-first';out.mkdir();(out/'.owner').write_text('future-classroom-owned-r79-failed-native-scratch-cleanup/v1\n')
 result=dict(status='FAIL_RETAIN',scope='Original failed debug native-test scratch only; source failure remains FAIL',originalReport=dict(sha256=REPORT_SHA),originalRaw=dict(sha256=RAW_SHA),windowsRoot=ROOT,operations=[],budgetSeconds=180,cleanup='NOT_RUN',noTestRerun=True,noProductPendingRegistryCacheMutation=True)
 c=dict(root=ROOT,nonce=NONCE,sid=SID);began=time.monotonic()
 def save():(out/'report.json').write_text(json.dumps(result,indent=2)+'\n')
 def call(label,cmd,feed=None,limit=30):
  proc=None;stdout=b'';stderr=b'';timed=False;error=None;start=time.monotonic();left=180-(start-began)
  try:
   need(left>0,'ORIGINAL180_CLEANUP_BUDGET')
   proc=subprocess.Popen(cmd,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   try:stdout,stderr=proc.communicate(feed,timeout=min(left,limit))
   except subprocess.TimeoutExpired:
    timed=True;proc.kill();stdout,stderr=proc.communicate()
  except BaseException as e:
   error=e
   if proc is not None and proc.poll() is None:proc.kill();stdout,stderr=proc.communicate()
  finally:
   row=dict(label=label,argv=cmd,pid=proc.pid if proc else None,actualReturnCode=proc.returncode if proc else None,reaped=bool(proc and proc.poll() is not None),timedOut=timed,remoteOriginalUnknown=timed,seconds=time.monotonic()-start)
   if feed is not None:row['stdin']=dict(bytes=len(feed),sha256=hashlib.sha256(feed).hexdigest())
   if error:row['errorType']=type(error).__name__
   for stream,data in [('stdout',stdout),('stderr',stderr)]:
    target=out/(label+'.'+stream+'.log');target.write_bytes(data);row[stream]=dict(path=str(target),**fact(target))
   result['operations'].append(row);save()
  if error:raise error
  need(not timed and proc.returncode==0,'ORIGINAL_TRANSPORT_RETURN_REQUIRED:'+label)
  return stdout
 def remote(label,script,limit=30):
  feed=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+common+script).encode()
  return call(label,['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','future-classroom-win11','powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(BOOT.encode('utf-16-le')).decode()],feed,limit)
 save()
 try:
  proc=json.loads(remote('01-owned-process-readonly',"CheckRoot $c.root;$a=@(Get-CimInstance Win32_Process -ErrorAction Stop|Where-Object {$_.ExecutablePath -and $_.ExecutablePath.StartsWith($c.root+'\\',[StringComparison]::OrdinalIgnoreCase)});@{count=$a.Count;root=$c.root;nonce=$c.nonce}|ConvertTo-Json -Compress"));need(proc['count']==0 and proc['root']==ROOT and proc['nonce']==NONCE,'NO_ROOT_OWNED_LIVE_PROCESS');result['processReadback']=proc
  inv=json.loads(remote('02-inventory',"Inventory $c.root|ConvertTo-Json -Depth 12 -Compress"));helper['validate_inventory'](inv)
  for name,value in uploads.items():need([x for x in inv['files'] if x['path']==name]==[dict(path=name,**value)],'ORIGINAL_UPLOAD_STILL_EXACT:'+name)
  need([x for x in inv['files'] if x['path']=='.owner']==[dict(path='.owner',bytes=len(MARKER),sha256=hashlib.sha256(MARKER).hexdigest())],'ORIGINAL_OWNER_BYTES')
  for row in inv['files']:need(row['path'] in ['.owner','candidate-tests.exe','Capture.cs','native-result.json'] or row['path'].startswith(('compiler-temp/','test-temp/')),'UNRECOGNIZED_DIRECT_MEMBER_RETAIN')
  for name in inv['directories']:need(name in ['compiler-temp','test-temp'] or name.startswith(('compiler-temp/','test-temp/')),'UNRECOGNIZED_DIRECTORY_RETAIN')
  result['inventory']=inv;save();download=out/'download';download.mkdir()
  call('03-download-originals',['scp','-q','-r','-o','BatchMode=yes','future-classroom-win11:'+ROOT.replace('\\','/'),str(download)],limit=60)
  local=download/ROOT.replace('\\','/').rsplit('/',1)[-1];helper['verify_download'](local,inv)
  need(json.loads((local/'native-result.json').read_bytes())==native,'DOWNLOADED_NATIVE_MATCHES_ORIGINAL_RAW')
  failure_gate();need(pinned(BASE,BASE_SHA),'HELPER_UNCHANGED_BEFORE_DELETE');result['downloadVerified']='ALL_ORIGINAL_BYTES_SHA_MEMBERSHIP_RECEIPT_AND_SOURCE_EXACT';save()
  c['inventory']=inv
  clean=json.loads(remote('04-exact-download-matched-delete',helper['DELETE'].replace('PRODUCT_RUNTIME_ROOT','REPAIR_NATIVE_RUNTIME_ROOT')))
  need(clean['knownAbsent'] is True and clean['nonce']==NONCE and clean['status']=='REMOVED_EXACT_REPAIR_NATIVE_RUNTIME_ROOT','EXACT_REMOVAL_RECEIPT')
  result.update(cleanup='PASS_EXACT_FAILED_TEST_SCRATCH_REMOVED_AFTER_ORIGINAL_CAPTURE',status='PASS_FAILED_NATIVE_SCRATCH_CAPTURE_AND_CLEANUP_ONLY_ORIGINAL_TEST_REMAINS_FAIL',delete=clean)
 except Exception as error:result.update(status='FAIL_RETAIN_ORIGINALS',errorType=type(error).__name__,error=str(error))
 result['seconds']=time.monotonic()-began
 if result['seconds']>=180:result['status']='FAIL_ORIGINAL180_BUDGET_EXCEEDED_RETAIN_UNKNOWN'
 save();print(json.dumps(dict(status=result['status'],report=str(out/'report.json'),sha256=fact(out/'report.json')['sha256'])));return 0 if result['status'].startswith('PASS_') else 1
if __name__=='__main__':raise SystemExit(main())
