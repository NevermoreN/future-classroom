#!/usr/bin/env python3
"""Root-only independent fixture transport. Default inert; not product authority.
Only exact controlled-owner build/source closure admitted. No production authority.
"""
import argparse,base64,datetime,hashlib,json
from pathlib import Path,PureWindowsPath
import re,runpy,subprocess,time
E=Path('/tmp/fc-round79-msi-maintenance')
PROTOTYPE=E/'controlled-owner-append-preparation-first'
SOURCE_DIR=PROTOTYPE
BASE=E/'early-terminal-transport-preparation-fifth/compile-only.py'
BASE_SHA='3b3aa837646c78157c0c8ce1d5d44f4325f8bcdd34f4fc59e85c801b555a4783'
NAMES={'.owner','spec.json','Owner.exe','EarlyTerminal.dll','payload.txt','healthy.msi','early-fail.msi','build-report.json','Capture.cs','Invoke-ControlledOwner.ps1'}
DIRS=('compiler-temp','readback-compiler-temp','effect')
PARENT_PS=r'''
function Parent-State {
 $base=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry32);$key=$null
 try{
  $key=$base.OpenSubKey('Software\FutureClassroomTest',$false)
  if($null-eq $key){return @{status='KNOWN_ABSENT';key='Software\FutureClassroomTest';view='Registry32'}}
  $values=@($key.GetValueNames());$subkeys=@($key.GetSubKeyNames());Need ($values.Count-le 64 -and $subkeys.Count-le 128) 'PARENT_SNAPSHOT_BOUND'
  $acl=$key.GetAccessControl([Security.AccessControl.AccessControlSections]::Owner -bor [Security.AccessControl.AccessControlSections]::Access)
  @{status='PRESENT';key='Software\FutureClassroomTest';view='Registry32';ownerSid=$acl.GetOwner([Security.Principal.SecurityIdentifier]).Value;securityDescriptor=$acl.GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]::Owner -bor [Security.AccessControl.AccessControlSections]::Access);valueNames=@($values|Sort-Object);subkeyNames=@($subkeys|Sort-Object)}
 }finally{if($null-ne $key){$key.Dispose()};$base.Dispose()}
}
'''
INVENTORY_PS=r'''
function Inventory {
 Root-Check;$files=@();$dirs=@();$total=0L;$queue=[Collections.Generic.Queue[string]]::new();$queue.Enqueue($c.root)
 while($queue.Count){$dir=$queue.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){
  $attrs=[IO.File]::GetAttributes($p);Need (($attrs-band[IO.FileAttributes]::ReparsePoint)-eq 0) 'INVENTORY_REPARSE'
  $rel=$p.Substring($c.root.Length+1).Replace('\','/')
  if(($attrs-band[IO.FileAttributes]::Directory)-ne 0){$top=($rel-split '/')[0];Need ($top-cin @('compiler-temp','readback-compiler-temp','effect')) 'ONLY_OWN_FIXTURE_SUBDIRECTORIES';$dirs+=$rel;$queue.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256};$total+=$f.bytes}
  Need ($files.Count-le 256 -and $dirs.Count-le 32 -and $total-le 67108864) 'RUNTIME_INVENTORY_BOUND'
 }}
 @{files=$files;directories=$dirs}
}
'''
READBACK_PS=r'''
Root-Check
$item=@($c.manifest.files|Where-Object path -CEQ 'Capture.cs');Need ($item.Count-eq 1 -and (Fact (Join-Path $c.root 'Capture.cs')).sha256-ceq $item[0].sha256) 'FROZEN_READONLY_CAPTURE_SOURCE'
$beforeTemp=$env:TEMP;$beforeTmp=$env:TMP
try{$env:TEMP=Join-Path $c.root 'readback-compiler-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP);Add-Type -Path (Join-Path $c.root 'Capture.cs') -ErrorAction Stop}finally{$env:TEMP=$beforeTemp;$env:TMP=$beforeTmp}
$product=[Fc79Capture]::Product($c.spec.productCode,$c.spec.upgradeCode,$c.sid)
$components=[Fc79Capture]::Components($c.spec.productCode,$c.spec.componentId,$c.sid)
$registry=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry32);$key=$null
try{$key=$registry.OpenSubKey($c.spec.registryKey,$false);$markerAbsent=($null-eq $key)}finally{if($null-ne $key){$key.Dispose()};$registry.Dispose()}
$effect=[Fc79Capture]::Absence($c.spec.effectDir.TrimEnd('\'));$paths=@()
foreach($path in $c.paths){$paths+=@{path=$path;fact=[Fc79Capture]::Absence($path)}}
$parent=Parent-State
$known=(@($product.registrations).Count-eq 0 -and @($product.related).Count-eq 0 -and $product.localPackageRc-eq 1605 -and $components.allUnknownStates-eq $true -and $markerAbsent -and $effect.status-ceq 'KNOWN_ABSENT')
@{status='ACTUAL_READONLY_FIXTURE_AND_EXACT_SYSTEM_PATH_FACTS';product=$product;components=$components;markerKnownAbsent=$markerAbsent;effect=$effect;fixtureKnownAbsent=$known;registryParent=$parent;paths=$paths;msiExecuted=$false;sharedServiceKilled=$false}|ConvertTo-Json -Depth 30 -Compress
'''

def need(ok,s):
 if not ok:raise ValueError(s)
def sha(b):return hashlib.sha256(b).hexdigest()
def fact(p):
 need(p.is_file() and not p.is_symlink(),'Original regular file');b=p.read_bytes();need(len(b)<=32*1024*1024,'Bounded local file');return {'bytes':len(b),'sha256':sha(b)}
def owned(p):
 need(p.is_absolute() and p.resolve()==p and p.is_relative_to(E),'Canonical owned R79 local path');return p
def inventory_identity(v):
 need(set(v)=={'files','directories'} and len(v['files'])<=256 and len(v['directories'])<=32,'Inventory shape/bound')
 files={};total=0
 for row in v['files']:
  need(set(row)=={'path','bytes','sha256'},'Exact file fields');rel=row['path'];need(isinstance(rel,str) and rel and ':' not in rel and '\\' not in rel and all(x not in ('','.','..') for x in rel.split('/')) and rel not in files,'Safe unique file path')
  need(type(row['bytes']) is int and 0<=row['bytes']<=16777216 and re.fullmatch('[0-9a-f]{64}',row['sha256']),'File size/hash');files[rel]=(row['bytes'],row['sha256']);total+=row['bytes']
 need(total<=67108864 and len(set(v['directories']))==len(v['directories']),'Inventory total/unique dirs')
 for rel in v['directories']:need(rel and ':' not in rel and '\\' not in rel and all(x not in ('','.','..') for x in rel.split('/')) and rel.split('/')[0] in DIRS and rel not in files,'Only owned fixture directories')
 return files,set(v['directories'])
def returned(x):
 return isinstance(x,dict) and x.get('Kind')=='process' and x.get('Status')=='HELD_ORIGINAL_IDENTITY' and type(x.get('Pid')) is int and x['Pid']>0 and type(x.get('Creation')) is int and x['Creation']>0 and type(x.get('Wait')) is int and x.get('Wait')==0 and x.get('ExitKnown') is True and type(x.get('ExitCode')) is int and x.get('CheckedClose') is True and x.get('CloseAttempted') is True
def validate_phase(r,spec,helper_sha):
 need(r['status']=='PASS_REAL_BEGIN_INSTALL_END_CLOSE_AND_PHYSICAL_EXIT_NOT_PRODUCTION_AUTHORITY' and r['authority']=='NO_PRODUCTION_AUTHORITY' and r['errors']==[],'Original complete controlled-owner phase PASS only')
 need(r['wholeSeconds']==600 and r['nativeSeconds']==120 and r['finallyReserveSeconds']==180 and type(r['elapsedMilliseconds']) is int and r['elapsedMilliseconds']<600000,'Original600/120/180 unchanged')
 need(r['nativeCloseUnknown'] is False and r['originalOwnerReturned'] is True and r['ownedCommitOutstanding'] is False and r['before']['knownAbsent'] is True and r['afterFinally']['knownAbsent'] is True,'Actual complete return and absence')
 cases=r['cases'];need([x['name'] for x in cases]==['early-fail-rollback','healthy-rollback','healthy-commit','owned-uninstall'],'Exact4 original cases')
 caps=r['originalCaps'];need(len(caps)==8 and all(x['CheckedClose'] is True and x['CloseAttempted'] is True and x['ExitKnown'] is True and type(x['Wait']) is int and x['Wait']==0 for x in caps),'All4originalprocess/thread caps checked return')
 need(r['nativeCloseFacts'] and all(x['Attempted'] is True and x['Success'] is True and x['Unknown'] is False and x['LastError']==0 for x in r['nativeCloseFacts']),'Every close actually returned')
 for index,case in enumerate(cases):
  process=case['originalProcess'];thread=case['originalThread'];need(returned(process) and process['ExitCode']==case['actualExit']==0 and process['Sha256']==helper_sha and process['Sid']==spec['expectedUserSid'],'Original owner process actual return')
  need(thread['Kind']=='thread' and thread['Status']=='HELD_ORIGINAL_IDENTITY' and thread['Pid']==process['Pid'] and thread['Tid']>0 and thread['Creation']>0 and thread['Wait']==0 and thread['ExitKnown'] is True and thread['CheckedClose'] is True and thread['CloseAttempted'] is True and type(thread['ExitCode']) is int and thread['ExitCode']==0,'Original native thread physical return')
  need(case['nativeReturnsComplete'] is True and case['apiSuccessful'] is True and 0<=case['elapsedMilliseconds']<120000,'No renewed owner budget')
  rows=case['api'];need([x['sequence'] for x in rows]==list(range(1,len(rows)+1)) and all(x['pid']==process['Pid'] and x['tid']==x['originalTid']==thread['Tid'] and x['threadCreation']==thread['Creation'] and x['clockValid'] is True for x in rows),'Original API same-thread sequence bound to captured caps')
  def one(stage):
   matches=[x for x in rows if x['stage']==stage];need(len(matches)==1,'One actual native '+stage);return matches[0]
  begin=one('BEGIN_RETURN');install=one('CONFIGURE_ABSENT_RETURN' if index==3 else 'INSTALL_RETURN');end=one('END_RETURN');close=one('TRANSACTION_ID_NO_INSTALL_HANDLE_CLOSE');event=one('CHANGE_EVENT_CLOSE_RETURN')
  need(begin['attempted'] is True and begin['return']==0 and begin['object']>0 and install['attempted'] is True and install['return']==(1603 if index==0 else 0) and end['attempted'] is True and end['return']==0 and close['attempted'] is False and type(close['return']) is int and close['return']==4294967295 and event['attempted'] is True and event['return']==0,'Actual Begin/Install/End/eventclose; transactionID non-close is explicitly not an API return')
  need(begin['sequence']<install['sequence']<end['sequence']<close['sequence']<event['sequence'] and begin['object']==install['object']==end['object']==close['object'],'Original actual transaction ordering')
  one('END_COMMIT_ENTER' if index in (2,3) else 'END_ROLLBACK_ENTER')
  logging=one('LOG_ENABLE_RETURN');ui=one('SET_UI_PREVIOUS_LEVEL');need(ui['attempted'] is True and logging['attempted'] is True and logging['return']==0 and ui['sequence']<logging['sequence']<begin['sequence'],'Real UI/log configuration before Begin')
  change=one('BEGIN_CHANGE_EVENT');need(change['object']>0 and change['object']==event['object'],'Same actual acquired kernel change-event checked returned')
  observed=case['nativeLog'];need(observed['scope']=='ORIGINAL_NATIVE_CALLBACK_LOG_FACTS_ONLY_NO_CALLBACK_CAPABILITY_AUTHORITY','Callbacks remain facts only')
  callbacks=observed['callbacks'];need(all(x['nonce']==spec['nonce'] and x['product']==spec['productCode'] and x['valid']=='1' and x['pointerBytes']=='4' and x['tokenClose']=='1' for x in callbacks),'Actual original callback facts for this private product')
  if index<3:need(len([x for x in callbacks if x['stage']=='PREPARE'])==1,'Actual prepare executed')
  if index==0:
   force=[x for x in callbacks if x['stage']=='FORCE_FAIL'];rollback=[x for x in callbacks if x['stage']=='ROLLBACK'];need(len(force)==len(rollback)==1 and force[0]['intendedReturn']=='1603' and force[0]['rollback']=='0' and rollback[0]['rollback']=='1' and rollback[0]['intendedReturn']=='0','Actual forced-failure action and native rollback mode1 executed')
  need(case['before']['knownAbsent'] is (index!=3) and case['after']['knownAbsent'] is (index!=2),'Exact rollback/commit/owned-uninstall effects scopes')
 return {'status':'PASS_ORIGINAL_CONTROLLED_OWNER_API_AND_PHYSICAL_RETURNS','authority':'NO_PRODUCTION_AUTHORITY','caseCount':4}
def parent_preserved(before,after):
 if before['status']=='KNOWN_ABSENT':return after['status']=='KNOWN_ABSENT'
 return before['status']==after['status']=='PRESENT' and before['ownerSid']==after['ownerSid'] and before['securityDescriptor']==after['securityDescriptor'] and set(before['valueNames'])==set(after['valueNames']) and set(before['subkeyNames'])==set(after['subkeyNames'])
def decode_log(data):
 need(len(data)<=8388608,'Bounded original MSI log')
 if data[:2]==b'\xff\xfe':return data.decode('utf-16','strict')
 if data[:2]==b'\xfe\xff':return data.decode('utf-16','strict')
 return data.decode('utf-8-sig','strict')
def collect_exact_paths(r,logs,spec):
 paths={};temp=PureWindowsPath(spec['windowsRoot']).parent
 def add(value,basis):
  p=PureWindowsPath(value)
  need(str(p)==value and p.is_absolute() and p.parent in (PureWindowsPath('C:\\Windows\\Installer'),temp) and re.fullmatch(r'(?:MSI[0-9a-f]+\.tmp|[0-9a-f]+\.msi)',p.name,re.I) and not any(x in value for x in ('\0','\r','\n','"')),'Exact own Installer/TEMP path only')
  paths.setdefault(str(p),set()).add(basis)
 for name,text in logs.items():
  for line in text.splitlines():
   for marker,pattern in [('cache',r"Package we're running from ==> (.+)$"),('script',r'Running Script:\s*(.+)$'),('dll',r'Invoking remote custom action\. DLL:\s*(.+?),\s*Entrypoint:')]:
    m=re.search(pattern,line,re.I)
    if m:add(m.group(1).strip(),name+':'+marker)
 need(1<=len(paths)<=64 and any(any(v.endswith(':cache') for v in origins) for origins in paths.values()),'Original exact cache/log evidence required')
 return [{'path':p,'basis':sorted(v)} for p,v in sorted(paths.items())]

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--validate-inputs-only',action='store_true');p.add_argument('--prototype-freeze',type=Path);p.add_argument('--prototype-freeze-sha256');p.add_argument('--stage-dir',type=Path);p.add_argument('--manifest-sha256');p.add_argument('--output-dir',type=Path);a=p.parse_args()
 need(not(a.execute and a.validate_inputs_only),'ChooseexecuteORvalidate')
 if not a.execute and not a.validate_inputs_only:print(json.dumps({'status':'PREPARED_NOT_RUN','Windows':'NOT_CONTACTED','productionAuthority':'NONE'}));return 0
 need(all((a.prototype_freeze,a.prototype_freeze_sha256,a.stage_dir,a.manifest_sha256,a.output_dir)),'All explicit arguments')
 need((E/'.owner').read_bytes()==b'future-classroom-owned-r79-msi-maintenance/v1\n','OwnedR79root')
 need(fact(BASE)['sha256']==BASE_SHA,'Fixed reviewed base transport')
 base=runpy.run_path(str(BASE));transport_identity=fact(Path(__file__).resolve());freeze_path=owned(a.prototype_freeze)
 need(freeze_path.parent==PROTOTYPE and fact(freeze_path)['sha256']==a.prototype_freeze_sha256,'Explicit original controlled-source freeze')
 freeze=json.loads(freeze_path.read_text());need(freeze['status']=='FROZEN_ONE_LINE_APPEND_LOGGING_CORRECTION_LOCAL_ACTUAL_STATIC_PASS_WINDOWS_NOT_RUN','Actual frozen local preparation scope')
 def sources():
  need(fact(Path(__file__).resolve())==transport_identity and fact(BASE)['sha256']==BASE_SHA,'Root transport and base unchanged')
  for row in freeze['files']:
   rel=row['path'];need(isinstance(rel,str) and not rel.startswith('/') and all(x not in ('','.','..') for x in rel.split('/')) and ':' not in rel and '\\' not in rel,'Frozen relative safe path')
   need(fact(owned(PROTOTYPE/rel))=={k:row[k] for k in ('bytes','sha256')},'Every source freeze byte unchanged')
 sources();stage=owned(a.stage_dir);need(stage==owned(PROTOTYPE/'build-output-first/stage') and stage.is_dir() and not stage.is_symlink(),'Original fixed execution stage')
 need({x.name for x in stage.iterdir()}==NAMES|{'runtime-inputs.json'} and all(x.is_file() and not x.is_symlink() for x in stage.iterdir()),'Exact11 flat stage members')
 manifest_path=stage/'runtime-inputs.json';need(fact(manifest_path)['sha256']==a.manifest_sha256,'Pinned actual stage manifest');manifest=json.loads(manifest_path.read_text())
 need(manifest['status']=='PREPARED_RUNTIME_NOT_RUN' and len(manifest['files'])==10 and {r['path'] for r in manifest['files']}==NAMES,'Exact10 original staged inputs')
 for row in manifest['files']:need(fact(stage/row['path'])=={k:row[k] for k in ('bytes','sha256')},'Every actual staged byte bound to manifest')
 spec=json.loads((stage/'spec.json').read_text());need(fact(stage/'spec.json')['sha256']==manifest['specSha256'],'Actual spec SHA')
 need(spec['expectedUserSid']==base['SID'] and spec['sourceGit']=='c44906517fbc62233dca755d7225cea375264cbc' and re.fullmatch('[0-9a-f]{32}',spec['nonce']) and spec['rootName']=='FutureClassroom-r79-early-terminal-'+spec['nonce'] and spec['windowsRoot']==str(PureWindowsPath('C:/Users/Elior/AppData/Local/Temp')/spec['rootName']),'Fresh fixed authorized namespace and source')
 need(spec['effectDir']==str(PureWindowsPath(spec['windowsRoot'])/'effect')+'\\' and spec['registryKey']=='Software\\FutureClassroomTest\\Round79-'+spec['nonce'] and spec['marker']=='future-classroom-owned-r79-early-terminal-fixture/v1\n','Exact closed private effects namespace')
 need((spec['wholeSeconds'],spec['nativeSeconds'],spec['clientSeconds'],spec['finallyReserveSeconds'],spec['maximumHandles'],spec['maximumOwners'])==(600,120,120,180,64,8),'Unchanged budgets')
 ids=[spec[k] for k in ('productCode','upgradeCode','componentId')];need(len(set(ids))==3 and all(re.fullmatch(r'\{[0-9A-F]{8}(?:-[0-9A-F]{4}){3}-[0-9A-F]{12}\}',x) for x in ids),'Three distinct canonical fresh GUIDs')
 old=json.loads((E/'early-terminal-inputs-derived-fifth/spec.json').read_text());need(spec['nonce']!=old['nonce'] and not set(ids)&{old[k] for k in ('productCode','upgradeCode','componentId')},'No old fixture namespace adoption')
 for name,row in spec['sources'].items():need(fact(owned(SOURCE_DIR/name))==row,'Actual producing source closure')
 for name in ('Capture.cs','Invoke-ControlledOwner.ps1'):need(fact(stage/name)==spec['sources'][name],'Staged live source byte binding')
 build=json.loads((stage/'build-report.json').read_text());need(fact(stage/'build-report.json')['sha256']==manifest['buildReportSha256'] and build['status']=='PASS_STATIC_ONLY_WINDOWS_NOT_RUN' and build['windows']=='NOT_RUN' and build['spec']==fact(stage/'spec.json') and build['sourcesUnchanged'] is True and build['toolsUnchanged'] is True,'Original actual local build provenance, no runtime promotion')
 need(build['commands'] and all(type(x['actualExit']) is int and x['actualExit']==0 and x['parentReaped'] is True for x in build['commands']),'Every actual local tool returned0')
 for name,key in [('Owner.exe','owner'),('EarlyTerminal.dll','observer'),('payload.txt','payload')]:need(fact(stage/name)==build[key],'Original compiled payload identity')
 for name in ('healthy','early-fail'):need(fact(stage/(name+'.msi'))==build['cases'][name]['msi'] and 'MsiEmbeddedChainer' not in build['cases'][name]['tables'],'Actual MSI identity and nochainer schema')
 need(build['cases']['healthy']['packageCode']!=build['cases']['early-fail']['packageCode'],'Distinct real package codes')
 import struct
 for name,dll in [('Owner.exe',False),('EarlyTerminal.dll',True)]:
  b=(stage/name).read_bytes();need(b[:2]==b'MZ','ActualPE');pos=struct.unpack_from('<I',b,60)[0];need(b[pos:pos+4]==b'PE\0\0' and struct.unpack_from('<H',b,pos+4)[0]==0x14c and struct.unpack_from('<H',b,pos+24)[0]==0x10b,'Realx86PE32');need(bool(struct.unpack_from('<H',b,pos+22)[0]&0x2000)==dll,'CorrectPEimagekind')
 out=owned(a.output_dir);need(out.parent==E and not out.exists(),'Fresh direct owned result directory')
 if a.validate_inputs_only:print(json.dumps({'status':'PASS_ORIGINAL_CONTROLLED_OWNER_LOCAL_INPUT_ADMISSION_ONLY','Windows':'NOT_CONTACTED','manifest':fact(manifest_path),'sourceFreeze':fact(freeze_path)}));return 0
 out.mkdir();(out/'.owner').write_text('future-classroom-owned-r79-controlled-owner-transport-result/v1\n')
 rp=out/'runtime-operation.json';report={'status':'RUNNING_FIXTURE_ONLY','productionAuthority':'NONE','transport':{'path':str(Path(__file__).resolve()),**transport_identity},'baseTransport':{'path':str(BASE),**fact(BASE)},'phaseSeconds':600,'clientSeconds':120,'finallyReserveSeconds':180,'latestNewClientStartCutoffSeconds':300,'outerTransportSeconds':900,'sourceFreeze':{'path':str(freeze_path),**fact(freeze_path)},'stageManifest':{'path':str(manifest_path),**fact(manifest_path)},'spec':fact(stage/'spec.json'),'operations':[],'cleanup':'NOT_RUN','startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 c={'root':spec['windowsRoot'],'nonce':spec['nonce'],'sid':base['SID'],'spec':spec,'manifest':manifest,'specSha256':manifest['specSha256'],'manifestSha256':a.manifest_sha256};report['remoteRoot']=c['root']
 common=base['COMMON'].split('function Inventory {')[0]+PARENT_PS+INVENTORY_PS
 start=time.monotonic();phase_natural=False;phase=None;download_ok=False;inventory=None
 def save():rp.write_text(json.dumps(report,indent=2)+'\n')
 def call(label,args,feed=None,limit=15):
  remaining=900-(time.monotonic()-start);need(remaining>0,'Original outer transport clock');proc=None;stdout=b'';stderr=b'';code=None;timed=False;began=time.monotonic()
  try:
   proc=subprocess.Popen(args,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   try:stdout,stderr=proc.communicate(feed,timeout=min(remaining,limit))
   except subprocess.TimeoutExpired:timed=True;proc.kill();stdout,stderr=proc.communicate() # only local ssh/scp; no remote kill
   code=proc.returncode
  finally:
   row={'label':label,'argv':args,'actualLocalExit':code,'localParentReaped':bool(proc and proc.poll() is not None),'remoteReturnKnown':code is not None and not timed,'timedOut':timed,'seconds':time.monotonic()-began}
   for ext,data in [('stdin.ps1',feed),('stdout.log',stdout),('stderr.log',stderr)]:
    if data is not None:q=out/(label+'.'+ext);q.write_bytes(data);row[ext]={'path':q.name,**fact(q)}
   report['operations'].append(row);save()
  need(not timed and code is not None,'Remote original return UNKNOWN; retain and stop');return code,stdout
 def ps(label,body,config=None,limit=15):
  cfg=c if config is None else config;feed=("$c='"+json.dumps(cfg,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+common+body).encode()
  cmd='powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand '+base64.b64encode(base['BOOT'].encode('utf-16-le')).decode();return call(label,['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8',base['HOST'],cmd],feed,limit)
 save()
 try:
  create=base['CREATE'].replace("@{status='PASS_CREATED_ONLY_PROTECTED_COMPILE_ROOT';root=$c.root;nonce=$c.nonce;sid=$c.sid}","@{status='PASS_CREATED_ONLY_PROTECTED_FIXTURE_RUNTIME_ROOT';root=$c.root;nonce=$c.nonce;sid=$c.sid;registryParentBefore=$parentBefore}")
  prefix="$who=[Security.Principal.WindowsIdentity]::GetCurrent();try{Need ($who.User.Value-ceq $c.sid) 'EXACT_USER_BEFORE_PARENT_QUERY'}finally{$who.Dispose()};$parentBefore=Parent-State;"
  code,raw=ps('01-before-parent-and-create',prefix+create);need(code==0,'Actual fresh protected root create0');before=json.loads(raw.decode('utf-8-sig'));need(before['status']=='PASS_CREATED_ONLY_PROTECTED_FIXTURE_RUNTIME_ROOT' and before['root']==c['root'],'Actual exact runtime root');report['before']=before
  files=[x for x in sorted(stage.iterdir()) if x.name!='.owner'];need(len(files)==10,'Ten uploads excluding remotely created marker')
  code,_=call('02-upload-actual-stage',['scp','-q','-o','BatchMode=yes','-o','ConnectTimeout=8',*[str(x) for x in files],base['HOST']+':'+c['root'].replace('\\','/')+'/'],limit=60);need(code==0,'Actual stage SCP0')
  run="Root-Check;& (Join-Path $c.root 'Invoke-ControlledOwner.ps1') -Execute -Root $c.root -ManifestSha256 $c.manifestSha256"
  code,raw=ps('03-original-fixture-phase',run,limit=620);phase_natural=True;need(code in (0,90),'Actual controlled phase parent code0/90');phase=json.loads(raw.decode('utf-8-sig'));report['phase']=phase;report['phaseParentExit']=code
  try:report['originalControlProof']=validate_phase(phase,spec,build['owner']['sha256']);need(code==0,'Original phase parent must be actual0 for PASS')
  except Exception as error:report['phaseQualificationError']=str(error)
 except Exception as error:report.update(status='FAIL_FIXTURE_TRANSPORT_OR_PHASE_RETAIN',errorType=type(error).__name__,error=str(error))
 # Never query/delete after an unknown original phase SSH return. On known
 # failed parent return, raw file capture is read-only and never grants cleanup.
 if phase_natural:
  try:
   code,raw=ps('04-readonly-original-inventory','Inventory|ConvertTo-Json -Depth 30 -Compress');need(code==0,'Actual original inventory0');inventory=json.loads(raw);inventory_identity(inventory);report['inventory']=inventory
   download=out/'download';download.mkdir()
   for dname in sorted(inventory['directories'],key=lambda x:(x.count('/'),x)):(download/dname).mkdir(parents=True,exist_ok=True)
   for i,row in enumerate(inventory['files']):
    target=download/row['path'];target.parent.mkdir(parents=True,exist_ok=True);remote=base['HOST']+':'+(c['root']+'\\'+row['path'].replace('/','\\')).replace('\\','/')
    code,_=call('05-download-'+str(i).zfill(3),['scp','-q','-o','BatchMode=yes','-o','ConnectTimeout=8',remote,str(target)],limit=15);need(code==0 and fact(target)=={k:row[k] for k in ('bytes','sha256')},'Original captured byte/SHA')
   code,raw=ps('06-second-readonly-inventory','Inventory|ConvertTo-Json -Depth 30 -Compress');need(code==0 and inventory_identity(json.loads(raw))==inventory_identity(inventory),'Captured original inventory stable after download');download_ok=True;report['downloadVerified']=True
   need(json.loads((download/'controlled-owner-result.json').read_text())==phase,'Original phase JSON file equals actual original stdout facts')
   need('phaseQualificationError' not in report and report.get('originalControlProof',{}).get('status')=='PASS_ORIGINAL_CONTROLLED_OWNER_API_AND_PHYSICAL_RETURNS','Failed phase always retained even if capture complete')
   logs={p.name:decode_log(p.read_bytes()) for p in sorted(download.glob('*-msi.log'))};need(len(logs)==4,'Four exact owner MSI logs')
   for case in phase['cases']:
    original=download/(case['name']+'-msi.log');need(fact(original)=={'bytes':case['nativeLog']['logBytes'],'sha256':case['nativeLog']['logSha256']},'Every actual original engine log hash bound to phase')
   need(re.search(r'Action ended .*Fc79ForceFail\. Return value 3\.',logs['early-fail-rollback-msi.log']) is not None,'Actual engine ForceFail action return3, not only intended callback return')
   if (download/'finally-uninstall.log').is_file():logs['finally-uninstall.log']=decode_log((download/'finally-uninstall.log').read_bytes())
   exact=collect_exact_paths(phase,logs,spec);report['derivedExactSystemPaths']=exact
   code,raw=ps('07-independent-final-readonly',READBACK_PS,{**c,'paths':[x['path'] for x in exact]},limit=45);need(code==0,'Actual readonly final parent0');readback=json.loads(raw);report['finalReadOnly']=readback
   need(readback['status']=='ACTUAL_READONLY_FIXTURE_AND_EXACT_SYSTEM_PATH_FACTS' and readback['fixtureKnownAbsent'] is True and {x['path'] for x in readback['paths']}=={x['path'] for x in exact} and len(readback['paths'])==len(exact) and all(x['fact']['status']=='KNOWN_ABSENT' for x in readback['paths']),'Exact original helper/DLL/cache/RunningScript and fixture absence')
   need(parent_preserved(before['registryParentBefore'],readback['registryParent']),'Registry parent changed or newly-created parent retained; no silent/manual deletion')
   # Readback Add-Type has its own owned compile files. Capture the complete
   # extended inventory too; never remove any undownloaded new compiler artifact.
   code,raw=ps('08-after-readonly-compiler-inventory','Inventory|ConvertTo-Json -Depth 30 -Compress');need(code==0,'Actual extended inventory0');extended=json.loads(raw);inventory_identity(extended)
   old_by={x['path']:x for x in inventory['files']};new_by={x['path']:x for x in extended['files']}
   need(all(new_by.get(k)==v for k,v in old_by.items()),'Original artifacts unchanged after readonly')
   for dname in sorted(extended['directories'],key=lambda x:(x.count('/'),x)):(download/dname).mkdir(parents=True,exist_ok=True)
   for i,row in enumerate(extended['files']):
    if row['path'] in old_by:continue
    need(row['path'].startswith('readback-compiler-temp/'),'Only final reader-owned compiler artifacts added');target=download/row['path'];target.parent.mkdir(parents=True,exist_ok=True);remote=base['HOST']+':'+(c['root']+'\\'+row['path'].replace('/','\\')).replace('\\','/')
    code,_=call('09-download-readback-'+str(i),['scp','-q','-o','BatchMode=yes','-o','ConnectTimeout=8',remote,str(target)],limit=15);need(code==0 and fact(target)=={k:row[k] for k in ('bytes','sha256')},'Original readback compiler artifact captured')
   sources();code,raw=ps('10-final-stable-inventory','Inventory|ConvertTo-Json -Depth 30 -Compress');need(code==0 and inventory_identity(json.loads(raw))==inventory_identity(extended),'Exact final inventory stable')
   code,raw=ps('11-exact-downloaded-root-delete',base['DELETE'].replace('PASS_REMOVED_EXACT_DOWNLOADED_COMPILE_ROOT','PASS_REMOVED_EXACT_DOWNLOADED_RUNTIME_ROOT'),{**c,'inventory':extended});need(code==0,'Actual exact cleanup parent0');cleanup=json.loads(raw);need(cleanup['status']=='PASS_REMOVED_EXACT_DOWNLOADED_RUNTIME_ROOT' and cleanup['knownAbsent'] is True,'Exact nonce root known absent')
   report['cleanup']=cleanup;report['finalInventory']=extended;report['status']='PASS_FINITE_CONTROLLED_BEGIN_INSTALL_END_CAPTURE_CLEANUP_NOT_PRODUCTION_AUTHORITY'
  except Exception as error:report.update(status='FAIL_FIXTURE_CAPTURE_OR_QUALIFICATION_RETAIN',errorType=type(error).__name__,error=str(error),partialDownloadMayExist=True)
 report['elapsedSeconds']=time.monotonic()-start;report['originalPhaseNaturalReturn']=phase_natural;report['downloadVerified']=download_ok;save()
 print(json.dumps({'status':report['status'],'report':str(rp),'sha256':fact(rp)['sha256'],'remoteRoot':c['root'],'cleanup':report['cleanup']}));return 0 if report['status'].startswith('PASS_') else 1
if __name__=='__main__':raise SystemExit(main())
