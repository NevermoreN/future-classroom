# R79 early-terminal prototype — preparation only

This directory contains test instruments, not a production settlement path. No
compiler, package builder, Windows command or installer has been run by this
preparation task. Root is the sole operator. Main remains unchanged.

## What the two cases measure

`positive.msi` has one ordinary payload file and one HKCU32 DWORD registry
keypath, a real embedded supervisor/child, and an inert ForceFail action. The
supervisor holds the child object returned by CreateProcess; the child really
calls MsiJoinTransaction and MsiEndTransaction(ROLLBACK). The returned change
event, process and thread handles are checked on close. Root holds the original
supervisor process before acknowledging its exact identity bytes. Source is the
permanent R77 archive's proven `7dfdbf…` C# program with exactly two substitutions
(R79 root leaf and owner marker); original bytes are retained beside it.

`early-fail.msi` has the same private ProductCode, UpgradeCode, component and
effect namespace, with a **different PackageCode**, and a fixed Type1 failure at
6501 after InstallExecute 6500. The action returns 1603, without its own external
effects. A synchronous rollback Type1281 action scheduled at 1501 precedes the
scripted changes it observes being undone. Three different Type1 actions occupy
termination slots -1, -2 and -3. No caller property chooses these actions; the
two exact MSI tables have ForceFail conditions `0 AND NOT Installed` and
`1 AND NOT Installed`. Formal `/x` skips all fixture actions/chainer because
their condition includes `NOT Installed`.

The DLL receives the actual engine-supplied hInstall and records ProductCode
and allowed UserSID property result codes, scheduled/rollback/commit run modes,
process/thread IDs and creation times, process token SID, effective thread token
SID (or ERROR_NO_TOKEN), current image and original loaded DLL path. It writes
only bounded MSI information records, closing its own record and token handles.
It never closes the caller's hInstall. A `BEFORE_RETURN` record is **intent**.
Only an original engine action-end record establishes that MSI received a
return; its MSI action return mapping differs from the held OS process exit
code. The driver preserves both, without pretending they are interchangeable.

The root observer holds query/synchronize process and thread capabilities when
still obtainable. A callback that already returned may have UNKNOWN metadata;
that does not invent a process identity. Shared MSI hosts and threads may remain
live. Their later exit is not required, induced or called a session boundary.
There is no mutex-name/absence proof, no _MSIExecute probe and no production
Pending/gate/Run interaction. These observations alone do not release an owner.

## Root execution order (all currently NOT_RUN)

1. Pin the preparation freeze, source Git and explicit current Windows SID.
   Locally run `fixture.py prepare --nonce <fresh32lowerhex> --windows-temp
   'C:\Users\Elior\AppData\Local\Temp' --expected-user-sid <actualSID>
   --source-git <reviewedGitSHA> --output <newLocalInputDir>`. This only writes
   new local input files. It does not connect to Windows.
2. Root creates only the exact nonce `windowsRoot` with current user as owner,
   protected DACL containing exactly current user and SYSTEM FullControl OICI,
   then uploads the exact source/spec/owner files. Refuse a pre-existing root,
   any reparse ancestor, product registration/related product, registry key or
   effect namespace. Before any install, independently preserve the user's
   Run/auth/SSH and scratch baseline using the existing root audit controller.
3. Compile **only** the GUI positive-control EXE with desktop PowerShell:
   `Compile-PositiveControl.ps1 -Execute -Root <windowsRoot> -SpecSha256 <SHA>`.
   The script pins actual source/compiler and creates a receipt with actual
   exit, source/exe hashes and nonce; it never runs the EXE. Download and hash
   the receipt, EXE, raw stdout/stderr and compiler-temp inventory. Compiler
   timeout retains its original object/root, never kills a service. Root must
   inspect and clean only this compiler's owned files after return.
4. Locally invoke `fixture.py build --execute --spec <spec> --spec-sha256 <SHA>
   --tools <tools.json> --chainer-exe <downloadedEXE> --chainer-sha256 <SHA>
   --compile-receipt <receipt> --output <freshBuildDir>`.
   `tools.json` is an exact map of gcc, objdump, wixl, msibuild, msiinfo,
   msiextract to `{path,sha256}`. Reuse root's already pinned R79 toolchain;
   `--child-environment` may specify **only** LD_LIBRARY_PATH for those reviewed
   tools. The builder never installs anything. It uses a fixed 600s producer
   deadline, <=120s per tool, records all raw stdout/stderr and actual reaped
   exits, verifies six DLL exports, both Binary streams, exact lifecycle tables,
   one-file payload extraction, registry/component identity and Media row.
   Failure keeps `build-report.json` and all original logs; do not overwrite.
5. `fixture.py stage-runtime --spec <spec> --spec-sha256 <SHA> --build-dir
   <freshBuildDir> --build-report-sha256 <SHA> --output <newStageDir>` pins the
   actual build and emits `runtime-inputs.json`. Root uploads only these exact
   files, retaining existing exact compile-only originals and refusing any
   differing destination. Root reruns PS5.1 AST parse and C# x86 compile checks
   before installation. No actual AST/compiler success is claimed here.
6. Root invokes hidden desktop PowerShell with short UTF-8 stdin using the
   existing bounded Remote transport, executing
   `Invoke-EarlyTerminal.ps1 -Execute -Root <windowsRoot> -SpecSha256 <SHA>
   -ManifestSha256 <runtime-inputs SHA>`. This driver has one fixed **600s**
   scenario clock; each original MSI client is limited to **120s**, and no new
   install begins after 420s so 180s remain for finally. The positive supervisor
   keeps its original **10s** total/2s root ACK budget. None of the production
   native 120s/owner/slot budgets changes.

Root transport is deliberately not duplicated here: it already owns Windows
credentials, short-stdin/scp, raw capture and exact download/cleanup. This
driver does not request credentials or select an alternate host. Required
transport behavior: preserve raw stdin/stdout/stderr/physical parent exit;
download all owned regular files with before/after size+SHA; refuse reparse or
unknown entries; delete only hash-matched downloaded files and original empty
directories after original clients/helpers returned. A retained unknown owner
prevents cleanup and further MSI operations; never kill msiexec or its service.

## Cleanup and interpretation

Before each case the driver independently queries this private ProductCode
across users/contexts (access errors remain UNKNOWN; current experiment uses
the authorized admin user), related registrations, the exact component in
current-user managed/unmanaged and machine contexts, the HKCU32 key and effect
directory. The only installation mutations are the one file and one marker.
The positive case must establish actual Join0, EndRollback0, child and original
supervisor exit0, and absence. Its per-case raw reports are moved, without
overwriting, only after its original object returned, before the next case.

The negative case requires actual client1603, real ForceFail and rollback
callback/run-mode facts, and independent effect/registration absence. It records
whether a terminal-failure callback or embedded chainer actually occurred; it
does not fabricate either. This first negative case is a scripted failure
after InstallExecute and **does not cover cancellation, process crash, failure
before InstallInitialize or every early exit**. The -2 hook is authored and
read back but no user-cancellation test is included. Add no such claims.

Finally may use formal `/x {this exact ProductCode}` only for the original
synthetic product's single registration and after original client and any
observed supervisor are known returned. It never deletes registry/cache entries
or clears Pending. Wrong-context, partial or unknown state remains FAIL. All
held observation capabilities are checked closed; shared host/thread Wait258
is explicitly retained as a live fact, not treated as exit0.

Exact original DLL module, supervisor image and cache paths are derived only
from this fixture's own original logs/held identity, then GetFileAttributesW is
read back. No system cache enumeration or manual deletion occurs. A remaining
exact cache/extracted path fails complete cleanup and is retained for root
investigation. Root also reviews original logs for Running Script/DLL extraction
paths not seen by the callbacks (including failures before a callback could
record), performs exact read-only absence checks, and closes the local/remote
compiler and scratch inventories. An absence report never substitutes for a
missing original helper return.

Even a successful fixture report means only
`PASS_FIXTURE_OBSERVATIONS_NOT_PRODUCTION_TERMINAL_AUTHORITY`. A production
early-terminal adapter still needs a concrete, authenticated original session
capability and a proof of settled execution/rollback plus the exact preimage
reconciliation. Native callback, global mutex name, public flag and caller bool
do not supply that proof. The prototype creates no production Pending, so a
negative result cannot strand a real maintenance owner.

## Primary API basis

- [InstallExecuteSequence](https://learn.microsoft.com/en-us/windows/win32/msi/installexecutesequence-table): positive action order and unique -1/-2/-3 termination slots.
- [In-script execution options](https://learn.microsoft.com/en-us/windows/win32/msi/custom-action-in-script-execution-options): Type1 + rollback/deferred flags = 1281.
- [Rollback actions](https://learn.microsoft.com/en-us/windows/win32/msi/rollback-custom-actions): synchronous rollback action scheduled before the changes it observes undone.
- [Deferred context](https://learn.microsoft.com/en-us/windows/win32/msi/obtaining-context-information-for-deferred-execution-custom-actions): limited properties/modes; no arbitrary deferred session-property assumption.
- [MsiGetMode](https://learn.microsoft.com/en-us/windows/win32/api/msiquery/nf-msiquery-msigetmode): real MSIHANDLE and run modes, not an independent terminal capability.
- [MsiEnumProductsExW](https://learn.microsoft.com/en-us/windows/win32/api/msi/nf-msi-msienumproductsexw): explicit contexts/SIDs; errors remain unknown.
- [MsiJoinTransaction](https://learn.microsoft.com/en-us/windows/win32/api/msi/nf-msi-msijointransaction) and [MsiEndTransaction](https://learn.microsoft.com/en-us/windows/win32/api/msi/nf-msi-msiendtransaction): actual original transaction API, not a sentinel or notification replacement.

All original failed builds, compiler runs, installs, unknowns and raw logs must
remain separate immutable evidence if root executes these stages. This is not
Win7/Win10 OS, Seewo, campus, Run ownership, damaged repair or release evidence.
