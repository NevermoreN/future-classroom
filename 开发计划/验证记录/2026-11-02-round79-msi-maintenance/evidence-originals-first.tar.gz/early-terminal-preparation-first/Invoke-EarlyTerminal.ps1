[CmdletBinding()]
param([switch]$Execute,[string]$Root,[string]$SpecSha256,[string]$ManifestSha256)
$ErrorActionPreference='Stop'
if(-not $Execute){@{status='PREPARED_NOT_RUN';wholeSeconds=600;nativeSeconds=120;finallyReserveSeconds=180;authority='OBSERVATION_ONLY_NOT_PRODUCTION_SETTLEMENT'}|ConvertTo-Json -Compress;return}
$clock=[Diagnostics.Stopwatch]::StartNew()
$result=[ordered]@{status='FAIL_RETAIN_UNKNOWN_ORIGINALS';scope='Independent R79 one-file/HKCU32 early failure and real Join/EndRollback positive control';authority='NONE_FOR_PRODUCTION_TERMINAL_SETTLEMENT';windows='ACTUAL_EXECUTION_REQUESTED';wholeSeconds=600;nativeSeconds=120;finallyReserveSeconds=180;cases=@();errors=@();formalUninstalls=@();privateObjects=@();systemPaths=@();sharedHostDeathRequired=$false;sharedServiceKill=$false;manualRegistryOrCacheDelete=$false;cleanup='ROOT_TRANSPORT_DOWNLOAD_THEN_EXACT_OWNED_CLEANUP_REQUIRED'}
$capture=$null;$spec=$null;$current=$null;$validated=$false;$clientReturned=$true;$positiveReturned=$true;$oldTemp=$env:TEMP;$oldTmp=$env:TMP
$result.qpcStarted=[Diagnostics.Stopwatch]::GetTimestamp();$result.qpcFrequency=[Diagnostics.Stopwatch]::Frequency
function Need([bool]$v,[string]$s){if(-not $v){throw $s}}
function Budget([int]$max=600000){Need ($clock.ElapsedMilliseconds-lt $max) 'ORIGINAL_SCENARIO_DEADLINE'}
function Hash([string]$p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function Read-Utf8([string]$p){$a=[IO.File]::GetAttributes($p);Need (-not($a-band[IO.FileAttributes]::ReparsePoint) -and -not($a-band[IO.FileAttributes]::Directory)) 'REGULAR_INPUT';$b=[IO.File]::ReadAllBytes($p);Need ($b.Length-le 16777216) 'BOUNDED_INPUT';[Text.UTF8Encoding]::new($false,$true).GetString($b)}
function Json([string]$leaf){Read-Utf8 (Join-Path $Root $leaf)|ConvertFrom-Json}
function Write-New([string]$leaf,$object){$b=[Text.UTF8Encoding]::new($false).GetBytes(($object|ConvertTo-Json -Depth 60)+"`n");$p=Join-Path $Root $leaf;$f=[IO.File]::Open($p,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$f.Write($b,0,$b.Length);$f.Flush($true)}finally{$f.Dispose()}}
function Publish-Bytes([string]$leaf,[byte[]]$b){$pending=Join-Path $Root ($leaf+'.pending-root');$f=[IO.File]::Open($pending,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$f.Write($b,0,$b.Length);$f.Flush($true)}finally{$f.Dispose()};[IO.File]::Move($pending,(Join-Path $Root $leaf))}
function Quote([string]$s){Need ($s-notmatch '["\r\n]' -and -not $s.EndsWith('\')) 'EXACT_ARGV';'"'+$s+'"'}
function Msi-Exe {if([Environment]::Is64BitOperatingSystem -and -not [Environment]::Is64BitProcess){Join-Path $env:SystemRoot 'SysWOW64\msiexec.exe'}else{Join-Path $env:SystemRoot 'System32\msiexec.exe'}}
function Fixture-State {
 $registration=[Fc79Capture]::Product($spec.productCode,$spec.upgradeCode,$spec.expectedUserSid)
 $components=[Fc79Capture]::Components($spec.productCode,$spec.componentId,$spec.expectedUserSid)
 $registry=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry32)
 $key=$null;try{$key=$registry.OpenSubKey($spec.registryKey,$false);$marker=if($null-eq $key){'KNOWN_ABSENT'}else{'PRESENT'}}finally{if($null-ne $key){$key.Dispose()};$registry.Dispose()}
 $effect=[Fc79Capture]::Absence($spec.effectDir.TrimEnd('\'))
 @{registration=$registration;components=$components;marker=$marker;effect=$effect;knownAbsent=(@($registration.registrations).Count-eq 0 -and @($registration.related).Count-eq 0 -and $components.allUnknownStates -eq $true -and $marker-ceq 'KNOWN_ABSENT' -and $effect.status-ceq 'KNOWN_ABSENT')}
}
function Read-Log([string]$p){
 if(-not [IO.File]::Exists($p)){return ''}
 $f=[IO.File]::Open($p,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete)
 try{Need ($f.Length-le 8388608) 'LOG_BOUND';$b=[byte[]]::new([int]$f.Length);$n=0;while($n-lt $b.Length){$r=$f.Read($b,$n,$b.Length-$n);if($r-eq 0){break};$n+=$r};if($n-ge 2 -and $b[0]-eq 255 -and $b[1]-eq 254){return [Text.Encoding]::Unicode.GetString($b,2,$n-2)};[Text.Encoding]::UTF8.GetString($b,0,$n)}finally{$f.Dispose()}
}
$positiveLeaves=@('supervisor-identity.json','.supervisor-original-captured','CREATE_PROCESS_RETURN.json','CHILD_THREAD_CLOSED.json','CHILD_ENTER.json','.supervisor-child-original-captured','JOIN_RETURN.json','END_ENTER.json','END_RETURN.json','CHANGE_EVENT_CLOSED.json','GUARDIAN_CHILD_DONE.json','CHILD_EXIT_RETURN.json','CHILD_PROCESS_CLOSED.json','SUPERVISOR_DONE.json','FAIL-supervisor.json','FAIL-guardian-child.json')
function Try-Ack($case){
 $leaf=Join-Path $Root 'supervisor-identity.json';if([IO.File]::Exists($leaf)-and -not [IO.File]::Exists((Join-Path $Root '.supervisor-original-captured'))){
  $script:positiveReturned=$false
  $b=[IO.File]::ReadAllBytes($leaf);Need ($b.Length-gt 0 -and $b.Length-le 16384) 'IDENTITY_BOUND'
  $id=[Text.UTF8Encoding]::new($false,$true).GetString($b)|ConvertFrom-Json
  Need ($id.schemaVersion-eq 1 -and $id.role-ceq 'supervisor' -and $id.nonce-ceq $spec.nonce -and $id.pointerBytes-eq 4 -and $id.sid-ceq $spec.expectedUserSid -and $id.imageSha256-ceq $build.chainer.sha256) 'SUPERVISOR_IDENTITY_CLAIM_NOT_CAPABILITY'
  $held=$capture.Hold([uint32]$id.pid,[long]$id.creationFiletime,[string]$id.imagePath,[string]$id.imageSha256,[string]$id.sid)
  Need ($held.Status-ceq 'HELD_ORIGINAL_IDENTITY') 'ORIGINAL_SUPERVISOR_CAPTURE_REQUIRED'
  [void]$capture.Snapshot();Need ($held.Wait-eq 258) 'ORIGINAL_SUPERVISOR_MUST_BE_LIVE_AT_ACK'
  $case.supervisorIdentity=$id;$case.supervisorCaptured=$true;$script:positiveReturned=$false
  Publish-Bytes '.supervisor-original-captured' $b
 }
}
$seenNative=@{}
$systemCandidates=@{}
function Candidate-System-Path([string]$p,[string]$basis){
 # No cache enumeration. Only complete exact paths emitted by this fixture's
 # own original log/module/process facts, under the actual Installer directory.
 $prefix=(Join-Path $env:SystemRoot 'Installer')+'\'
 if($p.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase) -and [IO.Path]::GetDirectoryName($p)-ieq $prefix.TrimEnd('\') -and [IO.Path]::GetFileName($p)-match '^[A-Za-z0-9_-]+\.(msi|tmp)$'){$systemCandidates[$p]=$basis}
}
function Capture-Native([string]$text,$case){
 $lines=$text-split "`n"
 # A concurrently appended incomplete final line is not an observation yet.
 for($index=0;$index-lt $lines.Count-1;$index++){$line=$lines[$index]
  if($line-notmatch 'FC79\|nonce='){continue}
  $at=$line.IndexOf('FC79|');$record=$line.Substring($at).TrimEnd("`r")
  if($seenNative.ContainsKey($record)){continue};$seenNative[$record]=$true
  $fields=@{};foreach($cell in ($record-split '\|')){if($cell.Contains('=')){$v=$cell-split '=',2;$fields[$v[0]]=$v[1]}}
  if($fields.nonce-cne $spec.nonce){throw 'FOREIGN_NONCE_IN_OWN_LOG'}
  Candidate-System-Path ([string]$fields.module) 'DLL_GETMODULEFILENAME_ORIGINAL_LOG_FACT'
  $observation=[ordered]@{raw=$record;fields=$fields;capture='UNKNOWN';process=$null;thread=$null;error=$null}
  # Fast callbacks may have returned already. UNKNOWN is an observation, never
  # replaced with a guessed PID identity or a requirement to kill shared hosts.
  try{
   Need ($fields.valid-ceq '1') 'NATIVE_REPORTED_INVALID_FACTS'
   $image=[string]$fields.image;$imageSha=[Fc79Capture]::Hash($image)
   $observation.process=$capture.Hold([uint32]$fields.pid,[long]$fields.processCreation,$image,$imageSha,[string]$fields.processSid)
   $observation.thread=$capture.HoldThread([uint32]$fields.pid,[uint32]$fields.tid,[long]$fields.threadCreation)
   $observation.capture='HELD_ORIGINAL_PROCESS_AND_THREAD_FACTS_ONLY'
  }catch{$observation.error=$_.Exception.Message}
  $case.nativeCallbacks+=@($observation)
 }
}
function Start-Msi([string]$mode,[string]$target,[string]$log){
 Budget 420000
 $exe=Msi-Exe
 $args=@($mode,(Quote $target),'/qn','/norestart','REBOOT=ReallySuppress','MSIRESTARTMANAGERCONTROL=DisableShutdown','/L*vx',(Quote $log))
 $script:clientReturned=$false
 $p=Start-Process -FilePath $exe -ArgumentList $args -WindowStyle Hidden -PassThru
 $creation=$p.StartTime.ToUniversalTime().ToFileTimeUtc()
 $held=$capture.HoldStartedClient($p.Handle,[uint32]$p.Id,[long]$creation,$exe,[Fc79Capture]::Hash($exe),$spec.expectedUserSid)
 @{process=$p;identity=@{pid=$p.Id;creationFiletime=$creation;image=$exe;argv=$args;heldOriginal=$held;qpcAfterStart=[Diagnostics.Stopwatch]::GetTimestamp()};startedAt=$clock.ElapsedMilliseconds}
}
function Await-Msi($instance,$case,[string]$log){
 $p=$instance.process;$script:clientReturned=$false
 while(-not $p.HasExited){Budget;Need (($clock.ElapsedMilliseconds-$instance.startedAt)-lt 120000) 'ORIGINAL_CLIENT_120S_UNKNOWN_RETAIN';Try-Ack $case;Capture-Native (Read-Log $log) $case;[void]$capture.Snapshot();Start-Sleep -Milliseconds 5;$p.Refresh()}
 $p.WaitForExit();$p.Refresh();[void]$capture.Snapshot();Need ($instance.identity.heldOriginal.Wait-eq 0 -and $instance.identity.heldOriginal.ExitKnown -and $instance.identity.heldOriginal.ExitCode-eq $p.ExitCode) 'CLIENT_ORIGINAL_HANDLE_RETURN_MISMATCH';$case.client=@{identity=$instance.identity;actualExit=[int]$p.ExitCode;waitReturned=$true;qpcAfterActualReturn=[Diagnostics.Stopwatch]::GetTimestamp();elapsedMilliseconds=($clock.ElapsedMilliseconds-$instance.startedAt)};$script:clientReturned=$true;$p.Dispose()
 Try-Ack $case;Capture-Native (Read-Log $log) $case
}
function Finish-Positive($case){
 if(-not $case.supervisorCaptured){$case.chainer='NOT_OBSERVED';return}
 $snap=@($capture.Snapshot());$f=@($snap|Where-Object {$_.Kind-ceq 'process' -and $_.Pid-eq $case.supervisorIdentity.pid -and $_.Creation-eq $case.supervisorIdentity.creationFiletime})
 Need ($f.Count-eq 1 -and $f[0].Wait-eq 0 -and $f[0].ExitKnown) 'ORIGINAL_SUPERVISOR_UNKNOWN_RETAIN'
 $script:positiveReturned=$true;$case.supervisorActualExit=$f[0].ExitCode
 $case.positiveFacts=@{}
 Candidate-System-Path ([string]$case.supervisorIdentity.imagePath) 'ORIGINAL_HELD_SUPERVISOR_IMAGE'
 foreach($leaf in $positiveLeaves){if($leaf.EndsWith('.json') -and [IO.File]::Exists((Join-Path $Root $leaf))){$case.positiveFacts[$leaf]=Json $leaf}}
 $j=$case.positiveFacts['JOIN_RETURN.json'];$e=$case.positiveFacts['END_RETURN.json'];$c=$case.positiveFacts['CHANGE_EVENT_CLOSED.json'];$x=$case.positiveFacts['CHILD_EXIT_RETURN.json'];$pc=$case.positiveFacts['CHILD_PROCESS_CLOSED.json']
 $case.realJoinEndRollback=($null-ne $j -and $j.returnCode-eq 0 -and $null-ne $e -and $e.returnCode-eq 0 -and $null-ne $c -and $c.checkedClose-eq $true -and $null-ne $x -and $x.actualExitCode-eq 0 -and $null-ne $pc -and $pc.checkedClose-eq $true -and $f[0].ExitCode-eq 0)
 $case.chainer=if($case.realJoinEndRollback){'REAL_JOIN0_END_ROLLBACK0_CHILD0_SUPERVISOR0'}else{'ACTUAL_NEGATIVE_OR_INCOMPLETE'}
}
function Archive-Positive([string]$case){
 $dir=Join-Path $Root ($case+'-positive-raw');Need (-not [IO.Directory]::Exists($dir)) 'NEW_CASE_RAW';[void][IO.Directory]::CreateDirectory($dir)
 foreach($leaf in $positiveLeaves){$p=Join-Path $Root $leaf;if([IO.File]::Exists($p)){[IO.File]::Move($p,(Join-Path $dir $leaf))}}
}
try{
 Need ([IO.Path]::GetFullPath($Root)-ceq $Root) 'ROOT_CANONICAL'
 $spec=Json 'spec.json';Need ((Hash (Join-Path $Root 'spec.json'))-ceq $SpecSha256) 'SPEC_PIN'
 Need ($Root-ceq $spec.windowsRoot -and [IO.Path]::GetFileName($Root)-ceq $spec.rootName -and $spec.nonce-cmatch '^[0-9a-f]{32}$') 'EXACT_ROOT'
 Need ($spec.wholeSeconds-eq 600 -and $spec.nativeSeconds-eq 120 -and $spec.finallyReserveSeconds-eq 180) 'UNCHANGED_BUDGET'
 Need ([IO.File]::ReadAllText((Join-Path $Root '.owner'))-ceq $spec.marker) 'OWNER_MARKER'
 $sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value;Need ($sid-ceq $spec.expectedUserSid) 'USER_SID'
 $dir=[IO.DirectoryInfo]::new($Root);while($null-ne $dir){Need (-not($dir.Attributes-band[IO.FileAttributes]::ReparsePoint)) 'NO_REPARSE_ANCESTOR';$dir=$dir.Parent}
 $acl=Get-Acl -LiteralPath $Root;Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq $sid) 'PROTECTED_CURRENT_OWNER'
 $aces=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($aces.Count-eq 2) 'TWO_CLOSED_ACES'
 $who=@($aces|ForEach-Object {$_.IdentityReference.Value}|Sort-Object -Unique);Need ($who.Count-eq 2 -and $sid-in $who -and 'S-1-5-18'-in $who) 'USER_AND_SYSTEM'
 foreach($a in $aces){Need ($a.AccessControlType-eq 'Allow' -and $a.IdentityReference.Value-in @($sid,'S-1-5-18') -and ($a.FileSystemRights-band[Security.AccessControl.FileSystemRights]::FullControl)-eq [Security.AccessControl.FileSystemRights]::FullControl) 'EXACT_DACL'}
 Need ((Hash (Join-Path $Root 'runtime-inputs.json'))-ceq $ManifestSha256) 'MANIFEST_PIN'
 $manifest=Json 'runtime-inputs.json';Need ($manifest.status-ceq 'PREPARED_RUNTIME_NOT_RUN' -and $manifest.specSha256-ceq $SpecSha256) 'RUNTIME_MANIFEST'
 $expectedInputs=@('EarlyTerminal.c','PositiveControl.cs','Compile-PositiveControl.ps1','Invoke-EarlyTerminal.ps1','Capture.cs','fixture.py','spec.json','positive.msi','early-fail.msi','PositiveControl.exe','EarlyTerminal.dll','payload.txt','build-report.json','.owner')
 $actualInputs=@($manifest.files|ForEach-Object {$_.path});Need ($actualInputs.Count-eq $expectedInputs.Count -and @($actualInputs|Sort-Object -Unique).Count-eq $expectedInputs.Count -and @(Compare-Object ($expectedInputs|Sort-Object) ($actualInputs|Sort-Object)).Count-eq 0) 'EXACT_RUNTIME_INPUT_CLOSURE'
 foreach($item in $manifest.files){Need ($item.path-cmatch '^[A-Za-z0-9._-]+$') 'DIRECT_INPUT';$p=Join-Path $Root $item.path;Need ((Hash $p)-ceq $item.sha256 -and ([IO.FileInfo]::new($p).Length)-eq $item.bytes) ('INPUT_CHANGED:'+ $item.path)}
 foreach($item in $spec.sources){Need ((Hash (Join-Path $Root $item.path))-ceq $item.sha256) 'SOURCE_CLOSURE'}
 $build=Json 'build-report.json';Need ($build.status-ceq 'PASS_LOCAL_BUILD_STATIC_ONLY_WINDOWS_NOT_RUN' -and $build.sourcesUnchanged -eq $true -and $build.toolsUnchanged-eq $true) 'REAL_LOCAL_STATIC_BUILD_REQUIRED'
 Need ($build.spec.sha256-ceq $SpecSha256) 'BUILD_SPEC'
 $env:TEMP=Join-Path $Root 'instrument-compiler-temp';$env:TMP=$env:TEMP;[void][IO.Directory]::CreateDirectory($env:TEMP)
 Add-Type -Path (Join-Path $Root 'Capture.cs') -ErrorAction Stop
 $capture=[Fc79Capture]::new();$validated=$true
 $result.before=Fixture-State;Need ($result.before.knownAbsent) 'BASELINE_NOT_KNOWN_ABSENT_NO_MSI'
 foreach($caseName in @('positive','early-fail')){
  Budget 420000;$seenNative=@{};$positiveReturned=$true
  $case=[ordered]@{name=$caseName;before=(Fixture-State);client=$null;supervisorCaptured=$false;supervisorIdentity=$null;supervisorActualExit=$null;nativeCallbacks=@();realJoinEndRollback=$false;chainer='UNKNOWN';engineActionReturnFacts=@();after=$null;classification='UNKNOWN'}
  $result.cases+=@($case);Need ($case.before.knownAbsent) 'CASE_START_UNKNOWN_OR_RESIDUAL'
  $msi=Join-Path $Root ($caseName+'.msi');Need ((Hash $msi)-ceq $build.cases.$caseName.msi.sha256) 'MSI_ACTUAL_STATIC_HASH'
  $log=Join-Path $Root ($caseName+'-msi.log');$current=Start-Msi '/i' $msi $log
  Await-Msi $current $case $log;Finish-Positive $case
  $text=Read-Log $log
  foreach($m in [regex]::Matches($text,"Package we're running from ==> ([^`r`n]+)")){Candidate-System-Path $m.Groups[1].Value 'ORIGINAL_ENGINE_LOCALPACKAGE_LOG_FACT'}
  $case.engineActionReturnFacts=@(($text-split "`n")|Where-Object {$_-match 'Action (start|ended).*Fc79|CustomAction Fc79|MsiEmbeddedChainer|Embedded chainer|Chainer'})
  $case.after=Fixture-State
  if($caseName-ceq 'positive'){
   Need ($case.realJoinEndRollback -and $case.after.knownAbsent) 'POSITIVE_CONTROL_NOT_ESTABLISHED'
   $case.classification='PASS_REAL_TRANSACTION_ROLLBACK_CONTROL_NOT_EARLY_TERMINAL_AUTHORITY'
  }else{
   $native=@($case.nativeCallbacks|ForEach-Object {$_.fields})
   $force=@($native|Where-Object stage -CEQ 'FORCE_FAIL');$rollback=@($native|Where-Object stage -CEQ 'ROLLBACK');$terminal=@($native|Where-Object stage -CEQ 'TERMINAL_FAILURE')
   Need ($case.client.actualExit-eq 1603 -and $force.Count-eq 1 -and $rollback.Count-eq 1 -and $rollback[0].rollback-ceq '1' -and $case.after.knownAbsent) 'EARLY_FAIL_OBSERVATIONS_INCOMPLETE'
   $case.terminalFailureCallbackObserved=($terminal.Count-eq 1)
   $case.classification='PASS_EARLY_FAILURE_OBSERVATIONS_ONLY_PRODUCTION_TERMINAL_AUTHORITY_UNPROVEN'
  }
  Archive-Positive $caseName
  Write-New ($caseName+'-case.json') $case
 }
 $result.after=Fixture-State;Need ($result.after.knownAbsent) 'FINAL_FIXTURE_UNKNOWN_OR_PRESENT'
 $result.status='PASS_FIXTURE_OBSERVATIONS_NOT_PRODUCTION_TERMINAL_AUTHORITY'
}catch{$result.errors+=@($_.Exception.Message)}finally{
 if($validated){
  try{
   $state=Fixture-State;$result.beforeFinally=$state
   # Only the original owned product, via formal /x, after original controls are
   # known returned. Shared DLL engine hosts/threads are never killed or awaited.
   $registration=@($state.registration.registrations)
   if(-not $state.knownAbsent -and $registration.Count-eq 1 -and $registration[0].context-eq 2 -and $registration[0].sid-ceq $spec.expectedUserSid -and $clientReturned -and $positiveReturned){
    Budget;$p=Start-Process -FilePath (Msi-Exe) -ArgumentList @('/x',$spec.productCode,'/qn','/norestart','REBOOT=ReallySuppress','MSIRESTARTMANAGERCONTROL=DisableShutdown','/L*vx',(Quote (Join-Path $Root 'finally-uninstall.log'))) -PassThru -WindowStyle Hidden
    $uninstall=[ordered]@{pid=$p.Id;creationFiletime=$p.StartTime.ToUniversalTime().ToFileTimeUtc();actualExit=$null;waitReturned=$false;heldOriginal=$null};$result.formalUninstalls+=@($uninstall)
    $image=Msi-Exe;$uninstall.heldOriginal=$capture.HoldStartedClient($p.Handle,[uint32]$p.Id,[long]$uninstall.creationFiletime,$image,[Fc79Capture]::Hash($image),$spec.expectedUserSid)
    $remaining=[Math]::Min(120000,600000-[int]$clock.ElapsedMilliseconds);Need ($remaining-gt 0 -and $p.WaitForExit($remaining)) 'FINALLY_ORIGINAL_CLIENT_UNKNOWN_RETAIN'
    $p.Refresh();[void]$capture.Snapshot();Need ($uninstall.heldOriginal.Wait-eq 0 -and $uninstall.heldOriginal.ExitKnown -and $uninstall.heldOriginal.ExitCode-eq $p.ExitCode) 'FINALLY_CLIENT_ORIGINAL_RETURN';$uninstall.actualExit=$p.ExitCode;$uninstall.waitReturned=$true;$p.Dispose()
   }
   $result.afterFinally=Fixture-State
  }catch{$result.errors+=@('FINALLY:'+ $_.Exception.Message)}
  try{$result.privateObjects=@($capture.FinishAndClose())}catch{$result.errors+=@('CHECKED_CLOSE:'+ $_.Exception.Message)}
  foreach($path in $systemCandidates.Keys){$result.systemPaths+=@(@{basis=$systemCandidates[$path];fact=[Fc79Capture]::Absence($path)})}
  if(@($result.systemPaths|Where-Object {$_.fact.status-cne 'KNOWN_ABSENT'}).Count-gt 0){$result.errors+=@('OWN_EXACT_EXTRACTED_OR_CACHE_PATH_RETAINED_NO_MANUAL_DELETE')}
  if($null-ne $result.afterFinally -and -not $result.afterFinally.knownAbsent){$result.errors+=@('FIXTURE_RETAINED_NO_MANUAL_DELETE')}
 }
 $env:TEMP=$oldTemp;$env:TMP=$oldTmp;$result.elapsedMilliseconds=$clock.ElapsedMilliseconds
 if($result.errors.Count-gt 0){$result.status='FAIL_RETAIN_ORIGINALS_OBSERVATIONS_NOT_AUTHORITY'}
 # Logs and extracted DLL/EXE/cache candidates remain evidence until root has
 # downloaded/hash-verified inventory and exact-path read-only absence results.
 if($null-ne $spec -and [IO.Directory]::Exists($Root)){Write-New 'early-terminal-result.json' $result}
}
$result|ConvertTo-Json -Depth 60
if($result.status-ceq 'PASS_FIXTURE_OBSERVATIONS_NOT_PRODUCTION_TERMINAL_AUTHORITY'){exit 0}else{exit 1}
