"""Root-only R79 test-instrument parse/compile precheck. Default inert; no DLL loading/MSI."""
from pathlib import Path
import argparse,base64,datetime,hashlib,json,secrets,subprocess,time
E=Path('/tmp/fc-round79-msi-maintenance');D=Path(__file__).resolve().parent
FREEZE=E/'negative-fixture-preparation-first/freeze-first.json'
FREEZE_SHA='e546b60caccc37ff69bfe08fd3dbba8b5064ed03577c1e7c6830770a3bd4224f'
KEY='/config/.local/share/future-classroom-test-access/win11-192.168.10.212'
NAMES={'ProcessObserver.cs','ProductState.cs','GateRetirement.cs','PayloadFixture.cs','ReadOnlyPreflightFunction.ps1','ProductState.ps1','Invoke-ProductionMsiPhases.ps1'}
SCRIPT=r'''
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$whole=[Diagnostics.Stopwatch]::StartNew()
function Require([bool]$v,[string]$code){if(-not$v){throw $code}}
function Sha([byte[]]$b){$h=[Security.Cryptography.SHA256]::Create();try{return ([BitConverter]::ToString($h.ComputeHash($b))).Replace('-','').ToLowerInvariant()}finally{$h.Dispose()}}
function KnownAbsent($p){try{[void][IO.File]::GetAttributes($p);return $false}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-is[IO.FileNotFoundException]-or$e-is[IO.DirectoryNotFoundException]){return $true};throw}}
function NewBytes($p,[byte[]]$b){$f=[IO.File]::Open($p,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);try{$f.Write($b,0,$b.Length);$f.Flush()}finally{$f.Dispose()}}
function Fact($p){$a=[IO.File]::GetAttributes($p);Require (($a-band[IO.FileAttributes]::Directory)-eq0 -and ($a-band[IO.FileAttributes]::ReparsePoint)-eq0) 'FLAT_REGULAR_NONREPARSE';$b=[IO.File]::ReadAllBytes($p);return @{name=[IO.Path]::GetFileName($p);bytes=$b.Length;sha256=(Sha $b)}}
$r=@{status='FAIL';scope='Seven instrument source uploads, PS parse and four separate x86 library compilations only; no DLL load/fixture entrypoint/MSI/registry/service action';powershellParse=@();compilers=@();compiledLibraries=@();sources=@();cleanup='NOT_RUN';originalWholeBudgetSeconds=60;eachOriginalCompilerMaximumSeconds=45}
$root=Join-Path ([IO.Path]::GetFullPath($env:TEMP)) ('FutureClassroom-r79-fixture-parse-'+$c.nonce)
$created=$false;$compilerReturned=$true;$p=$null;$expected=@{}
try{
 Require ($PSVersionTable.PSVersion.Major-eq5 -and [IntPtr]::Size-eq8) 'DESKTOP_PS51_X64'
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$identity.User;Require ($sid.Value-ceq$c.sid) 'EXACT_USER'}finally{$identity.Dispose()}
 Require ($c.nonce-cmatch'^[0-9a-f]{32}$' -and @($c.files).Count-eq7) 'EXACT_NONCE_AND_SEVEN_INPUTS'
 Require (KnownAbsent $root) 'NEW_NONCE_ROOT_REQUIRED'
 $parent=[IO.Path]::GetDirectoryName($root);while($parent){Require (([IO.File]::GetAttributes($parent)-band[IO.FileAttributes]::ReparsePoint)-eq0) 'PARENT_REPARSE';$parent=[IO.Path]::GetDirectoryName($parent)}
 [void][IO.Directory]::CreateDirectory($root);$created=$true
 $acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false)
 foreach($s in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($s,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))};[IO.Directory]::SetAccessControl($root,$acl)
 $owner=[Text.UTF8Encoding]::new($false).GetBytes("future-classroom-owned-r79-fixture-parse/v1`n");NewBytes (Join-Path $root '.owner') $owner;$expected['.owner']=@{name='.owner';bytes=$owner.Length;sha256=(Sha $owner)}
 $r.root=$root;$r.nonce=$c.nonce
 foreach($f in $c.files){
  Require ($f.name-cin@('ProcessObserver.cs','ProductState.cs','GateRetirement.cs','PayloadFixture.cs','ReadOnlyPreflightFunction.ps1','ProductState.ps1','Invoke-ProductionMsiPhases.ps1') -and -not$expected.ContainsKey($f.name) -and $f.bytes-ge1 -and $f.bytes-le262144 -and $f.sha256-cmatch'^[0-9a-f]{64}$') 'CLOSED_SEVEN_UNIQUE_BOUNDED_SOURCE_NAMES'
  $b=[Convert]::FromBase64String($f.base64);Require ($b.Length-eq$f.bytes -and (Sha $b)-ceq$f.sha256) 'EXACT_SOURCE_BYTES'
  $path=Join-Path $root $f.name;NewBytes $path $b;$actual=Fact $path;Require ($actual.bytes-eq$f.bytes -and $actual.sha256-ceq$f.sha256) 'ACTUAL_UPLOADED_SOURCE_BYTES';$expected[$f.name]=$actual;$r.sources+=,$actual
  if($f.name.EndsWith('.ps1')){$tokens=$null;$errors=$null;[void][Management.Automation.Language.Parser]::ParseInput([Text.Encoding]::UTF8.GetString($b),[ref]$tokens,[ref]$errors);$r.powershellParse+=@{name=$f.name;errors=@($errors|ForEach-Object{@{message=$_.Message;errorId=$_.ErrorId;line=$_.Extent.StartLineNumber}})};Require ($errors.Count-eq0) 'POWERSHELL_PARSE_ERRORS'}
 }
 $compiler=Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::Windows)) 'Microsoft.NET\Framework\v4.0.30319\csc.exe'
 foreach($name in @('ProcessObserver','ProductState','GateRetirement','PayloadFixture')){
  Require ($whole.ElapsedMilliseconds-lt60000) 'ORIGINAL_WHOLE_BUDGET_EXHAUSTED_NO_NEW_COMPILER'
  $output=Join-Path $root ($name+'.dll');Require (KnownAbsent $output) 'NEW_EXCLUSIVE_LIBRARY_OUTPUT'
  $row=@{source=$name+'.cs';output=$name+'.dll';path=$compiler;actualExit=$false;exitCode=$null;originalMaximumSeconds=45;target='x86 library; never loaded or invoked';startWholeMilliseconds=$whole.ElapsedMilliseconds}
  $r.compilers+=,$row
  $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$compiler;$info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
  $args=@('/nologo','/target:library','/platform:x86','/r:System.Management.dll','/r:System.Core.dll',('/out:"'+$output+'"'),('"'+(Join-Path $root ($name+'.cs'))+'"'));$info.Arguments=$args-join' ';$row.arguments=$info.Arguments
  $deadline=[Math]::Min(60000,$whole.ElapsedMilliseconds+45000);$row.originalDeadlineWholeMilliseconds=$deadline
  $p=[Diagnostics.Process]::new();$p.StartInfo=$info;Require ($p.Start()) 'COMPILER_START';$compilerReturned=$false;$row.pid=$p.Id
  $stdout=$p.StandardOutput.ReadToEndAsync();$stderr=$p.StandardError.ReadToEndAsync();$left=[int][Math]::Max(0,$deadline-$whole.ElapsedMilliseconds)
  Require ($p.WaitForExit($left)) 'ORIGINAL_COMPILER_RETURN_UNKNOWN_RETAIN';$compilerReturned=$true;$row.actualExit=$true;$row.exitCode=$p.ExitCode
  $left=[int][Math]::Max(0,$deadline-$whole.ElapsedMilliseconds);Require ([Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($stdout,$stderr),$left)) 'ORIGINAL_COMPILER_PIPES_UNKNOWN_NO_EXTENSION'
  $row.stdout=$stdout.Result;$row.stderr=$stderr.Result;$row.endWholeMilliseconds=$whole.ElapsedMilliseconds;$p.Dispose();$p=$null
  if(-not(KnownAbsent $output)){$actual=Fact $output;Require ($actual.name-ceq($name+'.dll') -and $actual.bytes-le16777216) 'BOUNDED_OWN_COMPILER_OUTPUT';$expected[$actual.name]=$actual;$r.compiledLibraries+=@{name=$actual.name;bytes=$actual.bytes;sha256=$actual.sha256;executed=$false;loaded=$false}}
  Require ($row.exitCode-eq0) 'CSHARP_COMPILE_FAILED';Require ($expected.ContainsKey($name+'.dll')) 'COMPILER_OUTPUT_REQUIRED'
  Require ($whole.ElapsedMilliseconds-lt60000 -and $whole.ElapsedMilliseconds-le$deadline) 'ORIGINAL_COMPILER_OR_WHOLE_DEADLINE_EXCEEDED'
 }
 Require ($r.compiledLibraries.Count-eq4 -and $r.sources.Count-eq7 -and $r.powershellParse.Count-eq3) 'FOUR_LIBRARIES_SEVEN_SOURCES_THREE_PS'
 $r.status='PASS_PARSE_FOUR_COMPILES_ONLY_PRODUCT_MSI_NOT_RUN'
}catch{$r.error=@{type=$_.Exception.GetType().FullName;message=$_.Exception.Message}}
finally{
 if($null-ne$p -and $compilerReturned){$p.Dispose();$p=$null}
 if($created -and $compilerReturned){try{
  Require ([IO.File]::ReadAllText((Join-Path $root '.owner'))-ceq"future-classroom-owned-r79-fixture-parse/v1`n") 'EXACT_OWNER'
  Require (([IO.File]::GetAttributes($root)-band[IO.FileAttributes]::ReparsePoint)-eq0) 'ROOT_REPARSE'
  $all=@([IO.Directory]::GetFileSystemEntries($root));Require ($all.Count-eq$expected.Count) 'EXACT_MEMBERSHIP_COUNT';$manifest=@()
  foreach($path in $all){$f=Fact $path;Require ($expected.ContainsKey($f.name)) 'EXACT_OWNED_FLAT_MEMBER';$old=$expected[$f.name];Require ($f.bytes-eq$old.bytes -and $f.sha256-ceq$old.sha256) 'ORIGINAL_INPUT_AND_COMPILER_OUTPUT_BYTES_UNCHANGED';$manifest+=,$f}
  $r.fullFileManifest=$manifest;$r.deletedFiles=$manifest
  foreach($path in $all){if([IO.Path]::GetFileName($path)-cne'.owner'){[IO.File]::Delete($path)}};[IO.File]::Delete((Join-Path $root '.owner'));[IO.Directory]::Delete($root,$false)
  Require (KnownAbsent $root) 'ROOT_NOT_ABSENT';$r.cleanup='PASS_EXACT_NONCE_ROOT_KNOWN_ABSENT'
 }catch{$r.cleanup='FAIL_RETAIN_REMAINING';$r.cleanupError=$_.Exception.Message}}
 elseif($created){$r.cleanup='RETAIN_ORIGINAL_COMPILER_RETURN_UNKNOWN'}
 $r.elapsedWholeMilliseconds=$whole.ElapsedMilliseconds;$r.originalWholeBudgetExceeded=($whole.ElapsedMilliseconds-ge60000)
}
$r|ConvertTo-Json -Depth 14 -Compress
if($r.status-cne'PASS_PARSE_FOUR_COMPILES_ONLY_PRODUCT_MSI_NOT_RUN' -or $r.cleanup-cne'PASS_EXACT_NONCE_ROOT_KNOWN_ABSENT' -or $r.originalWholeBudgetExceeded){exit 1}
'''
def sha(b):return hashlib.sha256(b).hexdigest()
def fact(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def main():
 p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');p.add_argument('--freeze',type=Path,default=FREEZE);p.add_argument('--freeze-sha256',default=FREEZE_SHA);p.add_argument('--report',type=Path,default=D/'report-first.json');a=p.parse_args()
 if not a.execute:print(json.dumps(dict(status='NOT_RUN_PREPARATION_ONLY',windows='NOT_CONTACTED',librariesLoaded=False,msi='NOT_RUN')));return 0
 assert (E/'.owner').read_bytes()==b'future-classroom-owned-r79-msi-maintenance/v1\n'
 f=a.freeze;assert f.is_absolute() and f==f.resolve() and f.is_relative_to(E) and sha(f.read_bytes())==a.freeze_sha256
 freeze=json.loads(f.read_text());assert freeze['normalPeSourceGit']=='261c58aca8b0f63ff2cfb4dbd5e85c0d17770005'
 for row in freeze['files']:
  path=Path(row['path']);assert path.is_absolute() and path==path.resolve() and path.is_relative_to(E);assert fact(path)==row
 rows=[r for r in freeze['files'] if Path(r['path']).suffix in ('.cs','.ps1')];assert len(rows)==7 and {Path(r['path']).name for r in rows}==NAMES
 c=dict(nonce=secrets.token_hex(16),sid='S-1-5-21-3896111207-1867804362-1971593122-1001',files=[dict(name=Path(r['path']).name,bytes=r['bytes'],sha256=r['sha256'],base64=base64.b64encode(Path(r['path']).read_bytes()).decode()) for r in rows])
 source=("$c='"+json.dumps(c,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+SCRIPT).encode()
 wrapper="[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()))"
 cmd=['ssh','-i',KEY,'-o','BatchMode=yes','-o','ConnectTimeout=8','elior@192.168.10.212','powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(wrapper.encode('utf-16-le')).decode()]
 out=a.report;assert out.is_absolute() and out==out.resolve() and out.is_relative_to(E) and out.parent.is_dir() and not out.exists()
 r=dict(status='RUNNING',scope='Root-only instrument seven-source PS parsing and four x86 library compilation precheck; no entrypoints/DLL loading/MSI',sourceFreeze=fact(f),sourceFiles=rows,nonce=c['nonce'],command=cmd,remoteSource=source.decode(),originalOuterBudgetSeconds=60,eachOriginalCompilerMaximumSeconds=45,startedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 out.write_text(json.dumps(r,indent=2)+'\n');start=time.monotonic()
 def capture(label,data):r[label]=dict(bytes=len(data),sha256=sha(data),base64=base64.b64encode(data).decode())
 try:
  v=subprocess.run(cmd,input=source,capture_output=True,timeout=60);r.update(actualExit=True,exitCode=v.returncode,elapsedSeconds=time.monotonic()-start);capture('stdout',v.stdout);capture('stderr',v.stderr)
  native=json.loads(v.stdout.decode('utf-8-sig'));r['native']=native
  assert v.returncode==0 and native['status']=='PASS_PARSE_FOUR_COMPILES_ONLY_PRODUCT_MSI_NOT_RUN' and native['cleanup']=='PASS_EXACT_NONCE_ROOT_KNOWN_ABSENT' and native['originalWholeBudgetExceeded'] is False
  assert {x['name']:(x['bytes'],x['sha256']) for x in native['sources']}=={x['name']:(x['bytes'],x['sha256']) for x in c['files']}
  assert len(native['compilers'])==4 and all(x['actualExit'] is True and x['exitCode']==0 for x in native['compilers'])
  assert len(native['compiledLibraries'])==4 and all(x['executed'] is False and x['loaded'] is False for x in native['compiledLibraries'])
  assert len(native['fullFileManifest'])==12 and {x['name'] for x in native['fullFileManifest']}==NAMES|{'.owner','ProcessObserver.dll','ProductState.dll','GateRetirement.dll','PayloadFixture.dll'}
  assert len(native['powershellParse'])==3 and all(not x['errors'] for x in native['powershellParse']);r['status']='PASS_INSTRUMENT_PARSE_FOUR_COMPILES_AND_EXACT_CLEANUP_ONLY'
 except subprocess.TimeoutExpired as error:
  r.update(status='FAIL_ORIGINAL_REMOTE_RETURN_UNKNOWN_RETAIN_ORIGINALS',actualExit=False,errorType=type(error).__name__,elapsedSeconds=time.monotonic()-start);capture('stdoutPartial',error.stdout or b'');capture('stderrPartial',error.stderr or b'')
 except Exception as error:r.update(status='FAIL_RETAIN_ORIGINALS',errorType=type(error).__name__,error=str(error),elapsedSeconds=time.monotonic()-start)
 out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k) for k in ('status','exitCode','errorType','error')}));return 0 if r['status'].startswith('PASS_') else 1
if __name__=='__main__':raise SystemExit(main())
