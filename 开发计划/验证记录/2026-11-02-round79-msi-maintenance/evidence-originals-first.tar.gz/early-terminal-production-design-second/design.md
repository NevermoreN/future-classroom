# R79 early-terminal：以原 API 调用者拥有事务的可实施替代

状态：只读设计研究。没有源码、MSI、Windows、编译或生产行为变更。当前原 guardian 结算约束及失败原件继续有效。此文的可行性来自已公开 API 契约，实际原型和产品验证尚未执行。

## 结论与实现选择

当前“MSI 内 Begin 提前写 Pending，稍后 embedded chainer 才带来 guardian”的路径，缺少一个文档化手段，让早期同步 CA 在首个 MSI mutation 前取得该包实际 multiple-package transaction ID 并转交原 guardian。`hInstall`、字符串属性、回滚模式和终止回调都不能补出这个权限。应停止把这些观测当作生产结算的候选依据。

可实现的替代是受控安装入口：**原 guardian 自己在调用安装 API 前创建并拥有事务**。同一原进程中的同一 native 调用线程依次执行 `MsiBeginTransactionW`、`MsiInstallProductW`（或明确的维护 API）、`MsiEndTransaction`。broker 独立持有该原进程对象，等待真实 API 归还、原进程退出和效果重核，再释放自己的 Pending/gate。这样，失败发生在 LaunchConditions、InstallInitialize 前后或 chainer 之前，都不会因为“没有运行到 chainer”而失去唯一的事务 owner。

这需要安装入口和内部 owner 创建的明确调整；它不是给现有 settlement 伪造 `join_return=0` 的小补丁。原 MSI 直接双击、`msiexec /i`、ARP Repair/Uninstall 的支持取舍必须单独处理。D11 的 ZIP/MSI、升级/恢复/卸载验收继续存在，不能靠把 MSI 藏进 EXE 就宣称完成。

## 官方契约能确认什么

| 问题 | 文档可确认的边界 | 工程结论 |
|---|---|---|
| 单包事务何时开始 | InstallInitialize 在 InstallFiles、WriteRegistryValues、ProcessComponents、InstallExecute 等变更前；InstallFinalize 完成该序列 | 这是单包脚本边界，不等于 CA 可取得 multiple-package transaction ID。[S01][S02] |
| 有 EmbeddedChainer 表时 transaction 何时创建 | 表契约说明引擎把 transaction ID 放在 chainer 命令行前，函数要 Join/End；未给出这个 ID 在较早 CA 中如何读取，也未承诺相对 1499/1501 的内部创建时点 | 当前实现/观测中的晚期启动不能升级为“早期已经有一个可借用 ID”的公开契约。[S03] |
| Type1 的入参 | DLL 收到当前 install session 的 `MSIHANDLE hInstall`；引擎拥有它，CA 不关闭它 | 同为 MSIHANDLE 的 typedef 不代表同一种对象。不能把 session 数值当 transaction ID。[S04][S05] |
| 是否有 MsiTransactionID | 官方 Property Reference 未列 Transaction 或 MsiTransactionID；事务 API 目录只有 Begin/Join/End，没有 get-current-transaction | 这是“在检索的公开契约中没有找到”，不是声称引擎内部不存在任何私有值。未知/自定义属性不得成为 authority。[S06][S07] |
| 能否 CA 中提前 Join | Join 要用 Begin 返回的 ID；活动 installation 期间禁止转 owner，且检查用户和 process tree | 即使拿到一个数值，早期 CA 正在当前 installation 内运行时仍不能据此承诺 Join 成功。[S08] |
| Begin 是什么 | 它创建 multiple-package transaction，返回 transaction ID 和 ownership-change event；同时只有一个 owner/一个全局事务 | 由原 guardian 在任何安装 API 前调用，才能给它一个明确来源的所有权。[S09] |

没有找到公开的 `hInstall → 当前 multiple-package transaction ID` 转换 API。对 `MsiGetProperty(hInstall, "MsiTransactionID", ...)` 做探针，最多得到字符串观察；得到非空也不能免除对象来源、owner、当前安装关联和真实 Join/End 检查。把 `hInstall` 直接传给 Join 则混淆 session 与 transaction 的对象种类。

在 Type1 CA 中再调用 Begin 也不是捷径：它请求创建事务，不是读取当前事务；文档只允许系统一个事务，冲突会返回 1618。没有公开契约保证这种嵌套位置把现有安装纳入一个新外层事务。CA 返回后也不能假设后续 CA 仍处在同一个 native 线程/进程对象中。这个方向没有可供当前产品依赖的完整契约。

## 1501 回滚检查点与 -3/卸载观测的实际价值

rollback CA 放在 InstallInitialize 后、实际脚本变更前，回滚时可以成为较后的**前像检查点**。它同步运行，适合记录当前 hInstall、实际 rollback mode、文件/marker/registration 的有界读回；也可用于受控 host 尚在等待 MsiInstallProduct 返回时的诊断。[S10][S11]

这个点本身不证明安装已经终止：

- 回调尚未返回，引擎仍在执行回滚程序；后续引擎注册、脚本/缓存清理和错误处理没有因这个检查点而获得“已停止”的契约。
- InstallInitialize 前失败时，1501 回滚动作可能还没有进入脚本；回滚被禁用时它也不会运行。回滚自身失败同样只能负向保留。
- `hInstall` 是该 CA 调用的引擎借用对象。可用它完成允许的同步查询，不能把它保存到另一个进程或回调之后当作可等待的终结对象。deferred/rollback 允许访问的上下文和 mode 更有限。[S05][S12]
- `Sequence=-3` 是 fatal-exit 的动作槽；证明引擎走到了失败动作，并不赋予事务 owner，也没有提供“该动作以后再无操作”的独立结算返回。[S13]
- DLL unload、模块文件消失、SetEvent、状态旗标和共享 msiexec/线程死亡都只能成为资源或过程观测。它们不能替代原事务 API 返回。此方案不要求共享 MSI 服务/线程死亡，也不终止它们。

因此：这些回调可以补充原件、解释失败范围、验证一部分顺序；不能单独清理真实 Pending。其它 owner 的观测 prototype 继续用于此目的，本设计不重复准备它。

## 最小受控 host 方案

参与者：B 为持有应用 maintenance gate 的 broker；G 为 B 实际创建、检查并持有的原 guardian/安装 API host。G 从 Begin 到 End 期间始终是 transaction owner。保留同用户、固定产品/manifest/路径、原进程对象和真实返回检查；来源不改成公共布尔值。

```mermaid
stateDiagram-v2
    [*] --> Draft: B取得独占物理gate，尚无Pending
    Draft --> NoInstall: G Begin非0，未获准调用安装API
    NoInstall --> [*]: 原G已返回，checked归还Draft
    Draft --> Armed: G Begin0，前像复核且pins已归还，写Pending5
    Armed --> Calling: B给原G唯一Run许可
    Calling --> Returned: 原MsiInstallProduct实际返回
    Returned --> Ending: B判完整/缺失/部分，G实际End
    Ending --> Reconcile: End0，MSI资源归还，原G退出
    Reconcile --> [*]: B重核效果与原owner，checked清Pending/gate
    Armed --> Retain: 任一未知/超时/close错误
    Calling --> Retain: 调用未归还或原进程丢失
    Ending --> Retain: End错误或结果不一致
```

### 1. 不在“尚无 transaction”时提前制造 durable Pending

现 `try_begin_maintenance` 把独占打开和 create_pending 合在一起。新路径需要一个 native-private 两阶段 owner：

1. B 先取得原独占物理 gate 的 Draft。它已经阻止正常启动/另一维护操作，但还没写 Pending，也没有任何 MSI payload mutation 被允许。
2. B 实际创建 G，持有原 process/thread/image 并检查 SID、creation time 和绑定的安装源；不只相信 PID/JSON。
3. G 在自己的原 native 线程调用 Begin。非 0 时绝不调用 Install/Configure/Reinstall。G 返回其真实 Begin 错误、归还本次已取得的资源并退出；B 验证该原进程归还，然后释放从未写过 Pending 的 Draft。**不调用一次假 End，也不制造 Join0/End0 receipt。**
4. Begin0 后，B 在原独占 gate 下捕获/重核前像，并真实归还所有会阻碍 MSI 写/删除的 pins。失败时 G 对空事务执行真实 Rollback；没有 Run 许可就绝不安装。
5. B 写原 Pending tag5、绑定原 operation/guardian，然后才发送 Run 许可。G 对该许可的接收和 B 的原对象归还必须走现有明确的 native owner 模型，不能以一个可任意提交的 MSI property 代替。

这避免把普通的服务不可用/另一安装占用，变成“早已写 Pending 却没有 transaction 可以 End”的设计性死路。它不增加 tag、输入帧、64 resources、8 owners、6 文件 proof groups 或原 120 秒预算。Draft 的资源也记在现有固定 ledger 中。

若 B 在 Run 许可前退出，G 不运行任何安装 API，只能终止自己的空事务；若 Pending 已写后 B/G 失去结算能力，仍保留 Pending。这里没有自动领养旧 operation，也没有崩溃后凭 PID 或文件缺失清负向状态。

### 2. 原 G 自己调用实际 MSI API

最小版本让 G 在同一 native 调用线程拥有 Begin、InstallProduct 和 End，不需要 Join，也避免把 owner 在安装活动期间转走。事务 ID 是实际 Begin 的输出，留在该原对象的 typed 状态中；不从 CLI/property/其它进程猜取。

如果产品确需另一个初始进程 Begin、再让 G Join，顺序必须是：原 Begin0 → 原 G 实际 Join0 → 尚未发生任何 Install API → G 再安装。不能一边 InstallProduct，一边要求另一个 guardian 抢 owner。ownership-change event 只提示换 owner，不能当作结算成功。[S08][S09]

包源必须是本次经过验证并固定的本地 MSI/资源，固定操作集合，不接收任意 URL/包路径/属性脚本。初次安装使用 InstallProduct；文件修复是明确的相同 manifest 强制重应用策略；卸载使用固定 REMOVE=ALL 或已验证的 ConfigureProductEx 组合。API 官方支持安装/卸载，也支持外部 UI 和日志。[S14][S15]

G 必须等这一次 native API 真正返回。它不能在同步 CA 回调尚在栈上时反向等待自己的 InstallProduct return；也不能再次复活旧 Type130 互相等待。取消可通过安装 UI 的正常取消协议处理；取消请求、进度消息和超时都不是 native 调用已归还。

### 3. 依据真实返回和效果选择 End

G 的 `installRc` 记录实际 API return；B 根据固定前像/manifest 重核 staged 效果：正常完整状态可 Commit，允许的完全卸载缺失可 Commit；错误、取消、部分或未知只能选择 Rollback。归还 staged pins 后，只有仍是原 owner 的 G 调用 End。

- `installRc=1602/1603` 不等于 EndRollback0。必须对自己实际创建的外层事务执行 EndRollback，并保留它的独立返回。
- `EndRc=0` 仍不是最终效果证明。G 完成本线程拥有的 MSI/事件/控制资源实际归还后退出；B 检查原 G 的真实退出与退出码，随后读取完整 Present/Absent 或原 damaged-preimage 的实际缺失集合/坏 bytes hash。
- G 可以用进程退出 0 表示“所有要求的 native 归还和 rollback 完成”，同时保留 InstallProduct 的 1603 并让最终 Setup 向用户报告安装失败。绝不把两个返回码混为一谈。
- End 的任何非成功码都不能写作“已 End”。当前设计不放行“1603 但看起来文件正常”或“共享服务后来死了”。

只要 G 从 Begin 起就是实际 owner，便覆盖普通的早期失败和取消路径，不依赖 embedded chainer 是否得到执行机会。事务 Begin 成功但 InstallProduct 初始化失败，也仍有同一个原 G 可以对自己持有的外层事务发出 EndRollback。该具体组合的返回与清理必须在最小实际实验中分别验证，不能把设计契约写作实测成功。

### 4. 结算 receipt 必须表达真实起源

现 Settlement 只有 `join_return/end_return`，并且 broker 只接受晚期 SUPERVISOR/GUARDIAN/ENDED。受控 host 不能为了复用而把“从未 Join”写成 0。应以 native-private 有限证据种类表示：

- `OwnedByBegin`：实际 Begin0 的原 G、Install 返回、实际 End 返回、原对象归还和效果 proof。
- `OwnedByJoin`：保留旧 embedded 路径的实际 Join0/End0 与原 guardian 检查。
- Begin 失败且无任何 Install 许可：仍只是无 Pending 的 Draft 失败；不构造 Settlement。

证据由可信 native 实现构建，不增加外部可指定的 effects/settled bool。B 原 gate/operation 身份必须一致，checked-close 失败仍触发原固定 ledger 的负向保留。MSIHANDLE 与 kernel HANDLE 分开管理，不能用 CloseHandle/DuplicateHandle 处理 transaction/session 数值；本进程创建的 MSI handle 使用其正确 MSI 归还 API，同线程记录真实返回。不能用 MsiCloseAllHandles 清理。[S16][S07]

## 错误和生命周期矩阵

| 位置 | 官方错误/返回 | 行为 |
|---|---|---|
| Begin | 1601 service failure、1618 already running、87 invalid parameter、1653 rollback disabled | 没有 Install 许可；无 Pending Draft 路径 checked 归还，保留错误。不得因 1618 终止别人的安装。[S09] |
| Join（仅可选转交路线） | 5 access denied、87 invalid parameter、1618 installation active、1609 invalid handle state | 不安装/不假 Join；真实结束自己仍拥有的事务或保留未知。[S08][S17] |
| InstallProduct | 0、1602 user exit、1603 failure、初始化/动作错误；3010 reboot required、1641 reboot initiated须单列 | 保存 API 原返回；0 也先看 staged scope；失败/取消尝试真实 Rollback。首个产品 slice 拒绝 authored ForceReboot/ScheduleReboot，不把 reboot-required 归为无重启普通 PASS。[S14][S17][S18] |
| End | 5 非 owner、1603 包未完成、1618 仍活动、1653 rollback disabled | 非0不允许结算；不得用文件状态、event 或原进程死亡替代。只对真实归还的原调用记录结果。[S19] |
| MSI handle return | MsiCloseHandle 0 或6 invalid handle；必须创建线程归还 | 保存实际资源种类及返回；不要混用 kernel close。输出 transaction ID 在 End 后的有效/归还顺序是实际 prototype 必须具体证明的一项，不靠 handle typedef 猜测已关闭。[S16] |
| 超时/owner丢失 | 不是成功返回码 | 原120s只限制正向继续；停止新变更，原物理调用/owner未知则保留。既不硬杀 MSI 服务，也不承诺任意 OS 调度下按纳秒释放。 |

某一安装失败后，外层事务的 EndRollback 可能继续返回错误；本设计不会把它放宽为成功。实际最小实验必须把 Begin、Install、End、MSI-handle/事件 return、原 G exit 分开记录。若普通早期失败无法以公开 API 得到可确认的 End 结果，就在实现前暴露这个确切组合，不能删掉该验收项。

## 与 D11、MSI 和现有 UX 的取舍

需求基线：[开发阶段 P5-03](/workspace/共享/Eliora/未来教室计划/开发计划/04-开发阶段与任务步骤.md)要求三系统 ZIP/MSI、升级/恢复/卸载；Q13 保留学校数据、运行中协调和安装清理。用户还明确要求 Win10/Win11，项目保留 Win7 SP1 x86。**“必须只有一个可直接双击的 MSI、不得出现 bootstrapper、必须仅通过 late embedded chainer 结算”是当前实现选择，不是已找到的用户原始要求。**同样，后续研究不能把任意恶意同用户对所有文件的原子保证或安装 120 秒硬实时完成，追加成原需求。

| 支持入口 | 可行取舍 | 必须兑现的工作 |
|---|---|---|
| 当前裸 MSI 直接双击/CLI | 仍走原健康 fresh/same-manifest 路径；有 early-failure Pending 风险 | 在完整解决前不把受损修复合入这条路径；不能用 -3 callback 偷清 Pending。 |
| 受控 Setup.exe + 真实 inner MSI | 推荐首先实现的原 API owner 路径；用户通过安装/修复/卸载入口使用 G | 明示入口变化；保留真实 MSI 格式及三系统安装证据。处理 ARP 和缓存维护入口，确保它们回到受控 host 或明确拒绝不支持的直接操作。 |
| 裸 MSI 与 Setup 同时作为完整等价入口 | 工程量最大 | 需要一个真实绑定 host 当前 API/session 的桥或另一个经证明的普通 MSI settlement 设计。`HOST=1`、nonce property、MsiProcessMessage reply 或可伪造旗标不是这种证明。 |

受控产品 MSI 不能继续无条件启动当前 embedded chainer，再尝试把活跃安装事务转交其它 guardian。它的包表/CA 和 B/G 关系须以单独的候选包实现和验证，防止与现有 Begin 再建一份 Pending 或相互等待。

如果采用 inner MSI 隐藏 ARP 项、host 注册自己的维修/卸载入口，则新增入口注册/host 文件也是明确的安装拥有资源，必须纳入清单、回滚、卸载及 Run/数据保留验收；不是本轮可以省略的“UI 小改”。如果仍公开分发 raw MSI，不能声称 direct install 已由 Setup 的 gate 覆盖。先把支持矩阵写清并做具体候选供 review，再决定是否需要向用户确认最终发布入口。

ZIP 启动和课堂正常 UI 不必变化。免验证的桌面换课按钮、不可点击的课表/时钟/日历及教师 Web 权限也与此内部安装路线无关。

## 最小工程顺序与实际门槛

1. **只验证 API 顺序的独立小包**：原 G 在安装前 Begin0；分别健康、LaunchConditions 拒绝、InstallInitialize 前失败、已执行脚本后失败、用户取消；逐个保存实际 Install return、EndRollback/Commit return、MSI/事件归还与原进程退出。复用当前唯一 Windows 操作 owner，不复制另一套并发测试。它与其它 owner 的 hInstall 回调观测 prototype 分开归因。
2. **实现 Draft/armed 状态**：先在隔离 worktree 把 native gate 获取和 Pending 创建拆开；保留原 tag5/4096/64/8/6/120。故障点覆盖 Begin失败前后、Pending创建前后、Run许可前后。Begin 拒绝等尚未创建 Pending 的普通失败不应制造新 Pending；Pending 已写或原 API/owner 未知时不能假清。
3. **实现原 G API owner 和 receipt variant**：Begin/Install/End/close 在固定线程；B 持原 process/image/control，重用已验证的 damaged preimage；无任意 MSI 路径/脚本接口。明确正常/错误 UI，不让调用者提供“effects_reconciled”。
4. **绑定包与入口**：新的受控 inner MSI、host、ARP/CLI 支持矩阵和所有权清单；校验实际 MSI 表/包签名或 exact bytes/组件注册，保留原 baseline 产品。不能只改一个公共属性绕开旧 Begin。
5. **真实产品 joint gate**：受损前像缺叶/截短/同长坏 bytes/缺目录的修复、ordinary early failure、cancel、partial staged rollback、运行中拒绝、Run unknown拒绝、各原对象 checked return、实际清理；Win11先行，Win7/Win10实机仍 NOT_RUN，希沃设备另证。

本设计选择了一个能用公开 API 写出具体程序的方向，同时把尚需实际证明的顺序列成有限可测项。它没有要求现有工作暂停，没有新增权限或服务配置，也没有批准合入/部署任何候选。

## 官方主源索引

- S01 [InstallInitialize](https://learn.microsoft.com/en-us/windows/win32/msi/installinitialize-action)
- S02 [InstallFinalize](https://learn.microsoft.com/en-us/windows/win32/msi/installfinalize-action)
- S03 [MsiEmbeddedChainer 表](https://learn.microsoft.com/en-us/windows/win32/msi/msiembeddedchainer-table)
- S04 [Custom Action Type 1](https://learn.microsoft.com/en-us/windows/win32/msi/custom-action-type-1)
- S05 [CA 访问当前 session](https://learn.microsoft.com/en-us/windows/win32/msi/accessing-the-current-installer-session-from-inside-a-custom-action)
- S06 [Property Reference](https://learn.microsoft.com/en-us/windows/win32/msi/property-reference)
- S07 [Installer Function Reference](https://learn.microsoft.com/en-us/windows/win32/msi/installer-function-reference)
- S08 [MsiJoinTransaction](https://learn.microsoft.com/en-us/windows/win32/api/msi/nf-msi-msijointransaction)
- S09 [MsiBeginTransactionW](https://learn.microsoft.com/en-us/windows/win32/api/msi/nf-msi-msibegintransactionw)
- S10 [Rollback Custom Actions](https://learn.microsoft.com/en-us/windows/win32/msi/rollback-custom-actions)
- S11 [Synchronous/Asynchronous Custom Actions](https://learn.microsoft.com/en-us/windows/win32/msi/synchronous-and-asynchronous-custom-actions)
- S12 [Deferred CA context](https://learn.microsoft.com/en-us/windows/win32/msi/obtaining-context-information-for-deferred-execution-custom-actions)
- S13 [InstallExecuteSequence](https://learn.microsoft.com/en-us/windows/win32/msi/installexecutesequence-table)
- S14 [MsiInstallProductW](https://learn.microsoft.com/en-us/windows/win32/api/msi/nf-msi-msiinstallproductw)
- S15 [External UI monitoring](https://learn.microsoft.com/en-us/windows/win32/msi/monitoring-an-installation-using-msisetexternalui)
- S16 [MsiCloseHandle](https://learn.microsoft.com/en-us/windows/win32/api/msi/nf-msi-msiclosehandle)
- S17 [Windows Installer error codes](https://learn.microsoft.com/en-us/windows/win32/msi/error-codes)
- S18 [Multiple-package installations](https://learn.microsoft.com/en-us/windows/win32/msi/multiple-package-installations)
- S19 [MsiEndTransaction](https://learn.microsoft.com/en-us/windows/win32/api/msi/nf-msi-msiendtransaction)
