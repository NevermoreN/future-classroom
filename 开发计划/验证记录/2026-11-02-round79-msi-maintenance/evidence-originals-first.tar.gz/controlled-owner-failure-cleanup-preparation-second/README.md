第二个失败实验精确清理，默认不执行。原FAIL报告088aa...，仅一个场景：Begin0/Install1603/EndRollback0/eventClose0/G与thread退出0及observer checkedclose；ID no-close attempted=false/sentinel不是API返回。实际PREPARE未证明，原FAIL保留，绝非MsiClose6失败。

沿已实际通过的第一cleanup最小派生；全部PS块逐字节相同，新预算180仅用于独立读回/下载/临时目录清理，不续原native120。绑定16下载原件，过程要求exactRoot Owner/csc0、fixture/product/component/HKCUparent独立absence、新readbackcompiler下载、stableinventory，最后仅exactfiles+emptydirs删除。无新MSI、无/x、无kill、无缓存或注册表删除。

原日志无cache/DLL/script路径发出，NOT_EMITTED_IN_ORIGINAL_LOG保留，不伪造路径；并不证明没提取过。执行命令见execution-plan-first.json；准备者未连接Windows，未触碰已经删除的第一nonceRoot。
