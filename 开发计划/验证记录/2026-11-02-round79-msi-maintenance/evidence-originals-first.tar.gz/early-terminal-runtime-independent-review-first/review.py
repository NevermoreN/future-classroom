#!/usr/bin/env python3
"""Finite read-only qualification of already downloaded R79 observations.

No network, subprocess, compiler, installer, Windows mutation, or source mutation.
"""
import copy
import hashlib
import json
import pathlib
import re

E = pathlib.Path('/tmp/fc-round79-msi-maintenance')
O = pathlib.Path(__file__).parent
R = E / 'early-terminal-runtime-first'
D = R / 'download'
checks = []
inputs = {}


def identity(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def load(rel):
    p = E / rel
    inputs[rel] = identity(p)
    return json.loads(p.read_text(encoding='utf-8-sig'))


def check(name, condition, detail=None):
    checks.append(dict(name=name, passed=bool(condition), detail=detail))
    if not condition:
        raise AssertionError(name)


def bound(p, row, name):
    a = identity(p)
    check(name, all(a[k] == row[k] for k in ('bytes', 'sha256') if k in row), a)


def freeze(rel):
    j = load(rel)
    base = (E / rel).parent
    for row in j['files']:
        bound(base / row['path'], row, 'frozen:' + rel + ':' + row['path'])
    return j


def differences(a, b, path=''):
    if type(a) is not type(b):
        return [(path, a, b)]
    if isinstance(a, dict):
        return [x for k in sorted(a.keys() | b.keys()) for x in differences(a.get(k), b.get(k), path + '/' + k)]
    if isinstance(a, list):
        if len(a) != len(b):
            return [(path, len(a), len(b))]
        return [x for i, (c, d) in enumerate(zip(a, b)) for x in differences(c, d, path + '/' + str(i))]
    return [] if a == b else [(path, a, b)]


def absent(s):
    return (s['knownAbsent'] is True and s['marker'] == 'KNOWN_ABSENT'
            and s['effect']['status'] == 'KNOWN_ABSENT'
            and s['effect']['lastError'] in (2, 3)
            and not s['registration']['registrations']
            and s['registration']['enumerationReturns'] == [259]
            and not s['registration']['related']
            and s['registration']['localPackageRc'] == 1605
            and s['registration']['localPackage'] is None
            and [x['context'] for x in s['components']['rows']] == [1, 2, 4]
            and all(x['state'] == -1 for x in s['components']['rows']))


runtime = load('early-terminal-runtime-first/runtime-operation.json')
check('exact_root_runtime_identity', inputs['early-terminal-runtime-first/runtime-operation.json']['sha256'] == 'd8893598f781188b0b8b3e2655ecaf90dd8fc5b1317f6e46980e1bd2d20f9bdb')
freeze('early-terminal-preparation-fifth/freeze-fifth.json')
freeze('early-terminal-runtime-transport-preparation-first/freeze-first.json')
for k in ('transport', 'baseTransport', 'sourceFreeze', 'stageManifest', 'guiOriginalCompileReport', 'specDerivation'):
    bound(pathlib.Path(runtime[k]['path']), runtime[k], 'runtime_external_binding:' + k)
for op in runtime['operations']:
    check('actual_operation_terminal:' + op['label'], op['actualLocalExit'] == 0 and op['localParentReaped'] and op['remoteReturnKnown'] and not op['timedOut'])
    for k, row in op.items():
        if isinstance(row, dict) and {'path', 'bytes', 'sha256'} <= row.keys():
            bound(R / row['path'], row, 'original_operation_stream:' + op['label'] + ':' + k)
stage = load('early-terminal-stage-runtime-first/runtime-inputs.json')
for row in stage['files']:
    bound(E / 'early-terminal-stage-runtime-first' / row['path'], row, 'stage:' + row['path'])
    bound(D / row['path'], row, 'download_stage:' + row['path'])
bound(D / 'runtime-inputs.json', runtime['stageManifest'], 'download_stage_manifest')
spec = load('early-terminal-inputs-derived-fifth/spec.json')
bound(D / 'spec.json', runtime['spec'], 'runtime_spec_actual')
derivation = load('early-terminal-inputs-derived-fifth/derivation.json')
original = load('early-terminal-inputs-second/spec.json')
ds = differences(original, spec)
check('derived_spec_only_fixture_py_source_row_changed', len(ds) == 2 and {x[0] for x in ds} == {'/sources/5/bytes', '/sources/5/sha256'} and original['sources'][5]['path'] == 'fixture.py', ds)
for k in ('originalSpec', 'derivedSpec'):
    bound(pathlib.Path(derivation[k]['path']), derivation[k], 'derivation:' + k)
for k in ('report', 'receipt', 'exe'):
    row = derivation['actualCscCompiledUnderOriginalSpec'][k]
    bound(pathlib.Path(row['path']), row, 'original_compile_kept:' + k)
csc = load('early-terminal-compile-fifth/compile-operation.json')
receipt = load('early-terminal-compile-fifth/download/positive-compile-receipt.json')
check('genuine_original_csc_exit0_wait_pipes_disposed', receipt['actualExit'] == 0 and all(receipt[k] for k in ('originalHandleAcquired', 'processWaitReturned', 'pipesComplete', 'processDisposed')) and receipt['originalMaximumMilliseconds'] == 30000)
check('original_csc_spec_not_rebound', csc['native']['receipt'] == receipt and any(x['path'] == 'spec.json' and x['sha256'] == hashlib.sha256((E/'early-terminal-inputs-second/spec.json').read_bytes()).hexdigest() for x in csc['native']['uploaded']))
bound(D / 'PositiveControl.exe', receipt['exe'], 'actual_runtime_gui_same_original_csc_exe')
bound(D / 'PositiveControl.cs', receipt['source'], 'actual_runtime_gui_same_original_csc_source')
build = load('early-terminal-package-build-second/build-report.json')
bound(D / 'build-report.json', {'sha256':stage['buildReportSha256']}, 'download_build_report')
check('build_spec_exact', build['specData'] == spec and build['spec']['sha256'] == runtime['spec']['sha256'])
check('84_build_commands_actual0_reaped', len(build['commands']) == 84 and all(x['actualExit'] == 0 and x['parentReaped'] for x in build['commands']))
check('dll_compile_strict_warnings', {'-Wall', '-Wextra', '-Werror', '-shared', '-lmsi'} <= set(build['commands'][0]['argv']))
for case, b in build['cases'].items():
    bound(D / (case + '.msi'), b['msi'], 'exact_built_msi:' + case)
    tables=b['tables']
    check('one_file_no_extra_machine_effects:' + case, len(tables['File']) == 1 and not tables['ServiceInstall'] and not tables['Shortcut'] and not tables['Upgrade'])
    seq = {x['Action']: int(x['Sequence']) for x in tables['InstallExecuteSequence']}
    check('terminal_sequence_positions:' + case, seq['Fc79TerminalSuccess'] == -1 and seq['Fc79TerminalFailure'] == -3 and seq['Fc79Rollback'] == 1501)
    if case == 'early-fail':
        check('early_failure_after_execute_before_finalize', seq['InstallExecute'] == 6500 and seq['Fc79ForceFail'] == 6501 and seq['InstallFinalize'] == 6600)
check('distinct_package_codes', build['cases']['positive']['packageCode'] != build['cases']['early-fail']['packageCode'])
for row in runtime['finalInventory']['files']:
    bound(D / row['path'], row, 'complete_download:' + row['path'])
expected = {x['path'] for x in runtime['finalInventory']['files']}
actual = {str(p.relative_to(D)) for p in D.rglob('*') if p.is_file()}
check('download_exact_final_membership', actual == expected)
check('final_inventory_preserves_original_inventory_files', runtime['inventory']['files'] == runtime['finalInventory']['files'])
phase = runtime['phase']
check('phase_equals_downloaded_original_exactly', phase == json.loads((D/'early-terminal-result.json').read_text(encoding='utf-8-sig')))
check('actual_outer_phase_exit0_no_errors_no_unknown_close', runtime['phaseParentExit'] == 0 and runtime['originalPhaseNaturalReturn'] and not phase['errors'] and not phase['nativeCloseUnknown'])
check('budgets_unchanged_600_120_180_300', [runtime[k] for k in ('phaseSeconds','clientSeconds','finallyReserveSeconds','latestNewClientStartCutoffSeconds')] == [600,120,180,300])
check('timings_separate_scopes', phase['elapsedMilliseconds'] == 1384 and abs(runtime['elapsedSeconds']-14.457683997001368)<1e-9)
check('five_actual_original_process_caps_returned_checked_close', len(phase['privateObjects']) == 5 and all(x['Kind']=='process' and x['Status']=='HELD_ORIGINAL_IDENTITY' and x['Wait']==0 and x['ExitKnown'] and x['CheckedClose'] and x['CloseAttempted'] for x in phase['privateObjects']))
check('ten_native_close_returns_actual_success', len(phase['nativeReturns']) == 10 and all(x['Attempted'] and x['Success'] and not x['Unknown'] and x['LastError']==0 for x in phase['nativeReturns']))
positive, negative = phase['cases']
snapshot_differences = {}
for c in phase['cases']:
    name = c['name']
    old=json.loads((D/(name+'-case.json')).read_text(encoding='utf-8-sig'))
    diffs=differences(old,c)
    check('case_snapshot_only_later_checked_close_fields_changed:' + name, bool(diffs) and all(x[0].endswith(('/CheckedClose','/CloseAttempted')) and x[1] is False and x[2] is True for x in diffs), [x[0] for x in diffs])
    snapshot_differences[name]=[x[0] for x in diffs]
    check('before_after_absence:' + name, absent(c['before']) and absent(c['after']))
    check('client_actual_handle_return:' + name, c['client']['waitReturned'] and c['client']['actualExit']==c['client']['identity']['heldOriginal']['ExitCode'] and c['client']['identity']['heldOriginal']['Wait']==0 and c['client']['identity']['heldOriginal']['ExitKnown'])
    raw=(D/(name+'-msi.log')).read_bytes()
    log=raw.decode('utf-16') if raw[:2] in (b'\xff\xfe',b'\xfe\xff') else raw.decode('utf-8-sig')
    for cb in c['nativeCallbacks']:
        f=cb['fields']
        parsed=dict(cell.split('=',1) for cell in cb['raw'].split('|')[1:] if '=' in cell)
        check('callback_raw_parse_and_original_log:' + name + ':' + f['stage'], parsed==f and cb['raw'] in log)
        check('callback_valid_x86_current_nonce_product:' + name + ':' + f['stage'], f['valid']=='1' and f['pointerBytes']=='4' and f['nonce']==spec['nonce'] and f['product']==spec['productCode'] and f['productRc']=='0' and f['tokenClose']=='1')
        check('callback_capability_unknown_preserved:' + name + ':' + f['stage'], cb['capture']=='UNKNOWN' and cb['thread'] is None and cb['error'] is not None)
    check('engine_action_end_facts_from_original_log:' + name, all(x in log for x in c['engineActionReturnFacts']))
pf=positive['positiveFacts']
for leaf,row in pf.items():
    check('positive_original_fact:' + leaf, row==json.loads((D/'positive-positive-raw'/leaf).read_text(encoding='utf-8-sig')))
check('positive_genuine_join_end_rollback_child_supervisor0', positive['supervisorCaptured'] and positive['supervisorActualExit']==0 and positive['realJoinEndRollback'] and pf['JOIN_RETURN.json']['returnCode']==0 and pf['END_ENTER.json']['decision']=='ROLLBACK' and pf['END_RETURN.json']['returnCode']==0 and pf['CHILD_EXIT_RETURN.json']['actualExitCode']==0 and pf['CHANGE_EVENT_CLOSED.json']['checkedClose'] and pf['CHILD_PROCESS_CLOSED.json']['checkedClose'] and pf['CHILD_THREAD_CLOSED.json']['checkedClose'])
check('positive_client0_terminal_success_but_outer_rollback_counterexample', positive['client']['actualExit']==0 and any(x['fields']['stage']=='TERMINAL_SUCCESS' for x in positive['nativeCallbacks']) and absent(positive['after']))
nf={x['fields']['stage']:x['fields'] for x in negative['nativeCallbacks']}
check('negative_real1603_rollback_mode1_terminal_failure_no_chainer_claim', negative['client']['actualExit']==1603 and nf['FORCE_FAIL']['intendedReturn']=='1603' and nf['ROLLBACK']['rollback']=='1' and nf['TERMINAL_FAILURE']['valid']=='1' and negative['chainer']=='NOT_OBSERVED' and not negative['supervisorCaptured'])
check('all12_callback_capabilities_unknown', len(positive['nativeCallbacks'])==4 and len(negative['nativeCallbacks'])==8 and all(x['capture']=='UNKNOWN' for c in phase['cases'] for x in c['nativeCallbacks']))
for key in ('before','after','beforeFinally','afterFinally'):
    check('phase_absent:' + key, absent(phase[key]))
check('no_formal_uninstall_needed_no_shared_kill_manual_delete', not phase['formalUninstalls'] and not phase['sharedServiceKill'] and not phase['manualRegistryOrCacheDelete'] and not phase['sharedHostDeathRequired'])
final=runtime['finalReadOnly']
paths={x['path'] for x in runtime['derivedExactSystemPaths']}
check('12_exact_system_paths_all_known_absent_no_enumeration', len(paths)==12 and paths=={x['path'] for x in final['paths']} and all(x['fact']['status']=='KNOWN_ABSENT' and x['fact']['lastError'] in (2,3) for x in final['paths']))
check('registry_parent_initial_final_absent', runtime['before']['registryParentBefore']['status']=='KNOWN_ABSENT' and final['registryParent']['status']=='KNOWN_ABSENT')
check('final_fixture_product_component_marker_effect_absent', final['fixtureKnownAbsent'] and final['markerKnownAbsent'] and final['effect']['status']=='KNOWN_ABSENT' and not final['product']['registrations'] and not final['product']['related'] and final['product']['enumerationReturns']==[259] and final['product']['localPackageRc']==1605 and all(x['state']==-1 for x in final['components']['rows']))
check('exact_downloaded_root_deleted', runtime['downloadVerified'] and runtime['cleanup']['knownAbsent'] and runtime['cleanup']['status']=='PASS_REMOVED_EXACT_DOWNLOADED_RUNTIME_ROOT')
out = dict(schemaVersion=1,status='PASS_INDEPENDENT_LOCAL_QUALIFICATION_OBSERVATIONAL_FIXTURE_ONLY',
    scope='Already executed Windows 11 R79 observational fixture; finite local original-byte/source/provenance/control/cleanup qualification. No test re-execution.',
    windowsContactedByReviewer=False, productionAuthority='UNPROVEN_NOT_GRANTED', inputs=inputs,
    findings=[
        'Positive client exit 0 and Type1 TERMINAL_SUCCESS at sequence -1 coexisted with genuine outer MsiJoinTransaction(0)/MsiEndTransaction(ROLLBACK)(0), child and supervisor exit 0, final absence. Client/callback success does not establish outer COMMIT.',
        'Negative client exit 1603, native valid rollback runmode 1, -3 failure callback and final absence are actual observations. Embedded chainer NOT_OBSERVED is not a proof that it was never launched.',
        'All 12 callback process+thread capability captures remain UNKNOWN: held host process metadata alone is insufficient production terminal authority.',
        'Five original process capabilities and ten checked native close facts returned successfully. No shared host death requirement, shared kill, cache deletion, registry deletion or fallback formal uninstall was used.',
        'Standalone per-case snapshots precede final checked-close; only False-to-True CheckedClose/CloseAttempted facts differ from final phase. The final phase equals the downloaded original result exactly.',
        'Original GUI compilation remains bound to original spec. Derived spec changed only fixture.py size/hash; no compiler report was retroactively rebound.',
        '600 second scenario, 120 second client, 180 second finally reserve and 300 second new-client cutoff remain distinct from observed 1384 ms fixture phase and 14.457683997 second transport.',
        'Twelve emitted exact system paths, product/component/marker/effect and HKCU Registry32 parent were absent before exact owned runtime-root deletion. No new Windows query was made by this reviewer.'
    ], checks=checks, checkCount=len(checks), downloadOriginalCount=len(expected), downloadOriginalBytes=sum(x['bytes'] for x in runtime['finalInventory']['files']),
    mayMergeRepairCandidate=False, mayDeployDamagedRepair=False, nextRequiredEvidence='Genuine early-install-failure outer transaction settlement with owned original control, actual API returns/checked resources and independent effects; full repair integration remains gated.',
    retainedLimits=['Windows 7/10 and Seewo hardware NOT_RUN by this fixture','No production Pending/gate settlement capability','No crash/power-loss durability proof','No inference of outer transaction COMMIT from client 0 or -1 callback'])
(O/'review-first.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=out['status'],checks=len(checks),downloadOriginals=len(expected),downloadBytes=out['downloadOriginalBytes']),ensure_ascii=False))
