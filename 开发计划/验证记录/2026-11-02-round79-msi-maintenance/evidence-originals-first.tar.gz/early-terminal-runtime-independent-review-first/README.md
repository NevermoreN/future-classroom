独立本地资格复核，仅核验已经下载的原始证据，未连接 Windows、未重跑编译或 MSI。

337 项有限检查通过；34 个下载原件共 1,501,213 字节逐项匹配最终远端清单。正控证明 client=0 / terminal success(-1) 与真实外层回滚可同时发生；12 个 Type1 callback 联合 process/thread capture 全部保留 UNKNOWN，未授予生产结算权威。

单场景 JSON 写入发生在最终 checked close 之前，最终 phase 对象中仅 CheckedClose 和 CloseAttempted 从 false 变 true；下载 early-terminal-result.json 与最终 phase 完全相等。所有旧失败/未知证据未改写。具体检查、范围限制和输入 SHA-256 见 review-first.json；实际本地进程退出见 review-operation-first.json。
