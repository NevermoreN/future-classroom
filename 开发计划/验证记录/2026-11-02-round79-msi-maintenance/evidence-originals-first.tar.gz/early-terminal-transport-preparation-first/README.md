# R79 compile-only transport

Default is `PREPARED_COMPILE_ONLY_TRANSPORT_NOT_RUN` and makes no connection.
Root is the only operator. SSH/SCP use only `future-classroom-win11`; this code
does not read a private key or change SSH authorization.

This first transport deliberately completes **only the compile-only phase**.
It cannot launch the fixture EXE, MSI, DLL entrypoint, registry action or product
gate. The separate prototype runtime driver remains unexecuted. Root can adapt
the existing reviewed runtime transport after actual package identities exist;
this file does not pretend to supply a tested MSI runtime transport.

## Explicit CLI

After root accepts `early-terminal-preparation-second/freeze-second.json`, use
its frozen `fixture.py prepare` to create a fresh local spec/input directory.
Do not generate inputs inside either frozen source directory. Then:

```text
python3 compile-only.py --execute
  --prototype-freeze /tmp/fc-round79-msi-maintenance/early-terminal-preparation-second/freeze-second.json
  --prototype-freeze-sha256 <explicit accepted second freeze SHA>
  --spec <fresh local prepared spec.json>
  --spec-sha256 <actual spec SHA>
  --output-dir /tmp/fc-round79-msi-maintenance/<fresh compile result directory>
```

Root must PS5.1-parse the embedded COMMON+CREATE/COMPILE/DELETE bodies before
execution. Local Python AST/default/pure checks do not substitute for that.
The controller refuses the first prototype, checks every second frozen member,
validates all six source hashes in the spec and fixes the authorized Windows
user SID. A new protected nonce directory must match the real user TEMP path.
It has current-user owner and exactly user/SYSTEM FullControl inherited ACEs.
A pre-existing root or any reparse ancestor is rejected without deletion.

Four exact inputs are uploaded: PositiveControl.cs,
Compile-PositiveControl.ps1, spec.json and compile-inputs.json. The owner marker
is created remotely before upload. Actual remote bytes are read back before PS
AST and the original frozen compile-only script runs. Its original 30s compiler
limit is unchanged. This independent compile transport has one 120s outer
deadline; it does not renew the future MSI scenario's 600/120/180 budgets.

The controller preserves every actual SSH/SCP command, raw short UTF-8 stdin,
stdout/stderr, local original parent exit/reap and source identities. It binds
the actual source/nonce/exit0 receipt, downloads raw csc stdout/stderr, the EXE,
receipt, four inputs and all bounded owned compiler-temp files. It rechecks
size/SHA and PE32/i386/GUI2/CLR32Required without running the image.

Before deletion, it obtains a second exact remote inventory and repeats all
frozen source guards. Only an actual successful compile, complete hash-checked
download, unchanged files and original parent return permit exact nonce-root
deletion. Directory deletion is empty-only, owner marker last. The actual
absence result is retained separately. Unknown remote return, compiler failure,
changed bytes, unexpected entry, reparse or failed close retain original data;
there is no retry, service/process kill or cleanup of registry/system cache.
A timed-out local SSH/SCP client is reaped locally and explicitly leaves remote
return UNKNOWN; no automatic later remote operations occur.

Successful results are `PASS_CSC_COMPILE_DOWNLOAD_EXACT_CLEANUP_ONLY_MSI_NOT_RUN`.
The locally preserved `download/PositiveControl.exe` and
`download/positive-compile-receipt.json` can then be passed to the separately
frozen prototype builder. A later runtime phase must use a fresh protected root
with the same spec and only actual source-bound `stage-runtime` artifacts,
preserve the driver's exact 600s/120s/180s clock and unknown-retention gates,
capture every raw log/result, independently confirm exact cache/module absence,
then download/re-hash/empty-only clean its own scratch. None of that runtime
work is claimed to have been implemented or executed by this compile transport.
