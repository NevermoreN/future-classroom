"""Local originals-only extraction. No remote or subprocess capability."""
from pathlib import Path, PureWindowsPath
import hashlib, json, re
D=Path(__file__).resolve().parent
E=D.parent
REPORT=E/'product-negative-runtime-first/report.json'
REPORT_SHA='0e4a2f4b24d594690e5f6278e1e622dee1c1d1f47bd633e9aa5954e6b16f637b'
def sha(b):return hashlib.sha256(b).hexdigest()
def emit(p,x):
 with p.open('x',encoding='utf-8') as f:f.write(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def main():
 rb=REPORT.read_bytes();assert sha(rb)==REPORT_SHA
 r=json.loads(rb);assert r['status']=='PASS_PRODUCT_MSI_RUNTIME_CAPTURE_AND_EXACT_SCRATCH_CLEANUP_WIN11_ONLY'
 assert r['cleanup']=='PASS_EXACT_DOWNLOADED_OWNED_SCRATCH_ONLY'
 roots=list((REPORT.parent/'download').iterdir());assert len(roots)==1 and roots[0].is_dir() and not roots[0].is_symlink();download=roots[0]
 inv=r['remoteInventory']['files'];assert len(inv)==49
 sources=[]
 for i in inv:
  rel=i['path'].replace('\\','/');p=download/rel
  assert not p.is_symlink() and p.is_file() and p.resolve().is_relative_to(download.resolve())
  b=p.read_bytes();assert len(b)==i['bytes'] and sha(b)==i['sha256']
  sources.append(dict(path=str(p),relativePath=rel,bytes=len(b),sha256=sha(b)))
 actual={str(p.relative_to(download)).replace('\\','/') for p in download.rglob('*') if p.is_file()}
 assert actual=={x['relativePath'] for x in sources}
 assert len(sources)==49
 source_by_name={x['relativePath']:x for x in sources}
 pattern=re.compile(r'C:\\Windows\\Installer\\(?:[0-9a-f]{1,16}\.msi|MSI[0-9a-f]{1,8}\.tmp)(?![\w.\\])',re.I)
 paths={};exclusions=[]
 def origin(name,line,n,kind,**extra):
  s=source_by_name[name]
  return dict(sourceFile=s['path'],sourceSha256=s['sha256'],sourceBytes=s['bytes'],encoding='UTF-16-LE-BOM' if name.endswith('-msi.log') else 'UTF-8-BOM-compatible',lineNumber=n,classification=kind,rawLine=line,rawLineVisibleEscaped=json.dumps(line,ensure_ascii=False),**extra)
 def add(p,o):
  assert pattern.fullmatch(p) and str(PureWindowsPath(p).parent).lower()=='c:\\windows\\installer'
  k=p.casefold();entry=paths.setdefault(k,dict(path=p,pathVisibleEscaped=json.dumps(p),classifications=[],origins=[]))
  if o['classification'] not in entry['classifications']:entry['classifications'].append(o['classification'])
  entry['origins'].append(o)
 helper=set()
 for phase in r['phaseResult']['phases']:
  name=phase['name']+'-phase.json';b=(download/name).read_bytes();obj=json.loads(b)
  assert obj==phase
  lines=b.decode('utf-8-sig').splitlines()
  image_lines=[(n,l,json.loads(l.split(':',1)[1].strip().rstrip(','))) for n,l in enumerate(lines,1) if re.match(r'^\s*"Image"\s*:',l)]
  procs=phase['observerFinal']['Processes'];assert len(image_lines)==len(procs)
  for idx,(proc,(n,line,p)) in enumerate(zip(procs,image_lines)):
   assert p==proc['Image'] and proc['IdentityStatus']=='ORIGINAL_QUERY_SYNC_HANDLE_EXACT_IMAGE_BYTES_USER'
   assert proc['ActualWait']==0 and proc['ExitStatus']=='ACTUAL_ORIGINAL_GET_EXIT_CODE' and proc['CloseStatus']=='CHECKED_CLOSE_SUCCESS'
   helper.add(p.casefold())
   add(p,origin(name,line,n,'AUTHENTICATED_ORIGINAL_HELPER_IMAGE',jsonPointer=f'/observerFinal/Processes/{idx}/Image',phase=phase['name'],pid=proc['Pid'],role=proc['Role'],imageSha256=proc['Sha256'],userSid=proc['Sid'],actualExitCode=proc['ActualExitCode'],identityStatus=proc['IdentityStatus']))
 assert len(helper)==7
 name='phase-runner-result.json';b=(download/name).read_bytes();text=b.decode('utf-8-sig');obj=json.loads(b);assert obj==r['phaseResult']
 q=obj['freshCache']['actualProductQuery'];assert q['apiCode']==0 and q['property']=='LocalPackage' and q['status']=='KNOWN_PRESENT_EXACT_API_LOCALPACKAGE_READONLY'
 start=text.index('"freshCache"');start=text.index('"actualProductQuery"',start);off=text.index('"path"',start);line_number=text.count('\n',0,off)+1;line=text.splitlines()[line_number-1];assert json.loads(line.split(':',1)[1].strip().rstrip(','))==q['path']
 add(q['path'],origin(name,line,line_number,'ACTUAL_LOCALPACKAGE_API_PATH',jsonPointer='/freshCache/actualProductQuery/path',apiCode=q['apiCode'],property=q['property'],cacheSha256=q['sha256'],cacheBytes=q['bytes'],historicalStatus=q['status']))
 for phase in r['phaseResult']['phases']:
  name=phase['name']+'-msi.log';b=(download/name).read_bytes();assert b.startswith(b'\xff\xfe')
  for n,line in enumerate(b.decode('utf-16').splitlines(),1):
   for m in pattern.finditer(line):
    p=m.group();kind='MSI_RUNNING_SCRIPT_LOG_ONLY' if 'Running Script:' in line else 'MSI_CACHE_PACKAGE_LOG_ONLY' if p.lower().endswith('.msi') else 'MSI_CUSTOM_ACTION_LOCATION_LOG_ONLY'
    add(p,origin(name,line,n,kind,phase=phase['name']))
   if 'C:\\Windows\\Installer\\inprogressinstallinfo.ipi' in line or 'C:\\Windows\\Installer\\SourceHash' in line:
    exclusions.append(origin(name,line,n,'EXCLUDED_SHARED_INSTALLER_STATE_NO_QUERY'))
 entries=sorted(paths.values(),key=lambda x:x['path'].casefold())
 assert len(entries)==11
 assert sum('MSI_RUNNING_SCRIPT_LOG_ONLY' in x['classifications'] for x in entries)==2
 assert sum(x['path'].lower().endswith('.msi') for x in entries)==2
 out=dict(schemaVersion=1,status='PREPARED_NOT_RUN',windows='NOT_RUN',scope='Only eleven exact C:\\Windows\\Installer paths from one completed R79 negative trial; no directory enumeration, deleted nonceRoot query, deletion, registry, service, or process action.',runtimeReport=dict(path=str(REPORT),bytes=len(rb),sha256=sha(rb)),downloadRootLocalOnly=str(download),verifiedDownloadedOriginals=sources,verifiedDownloadedOriginalCount=49,verifiedDownloadedOriginalBytes=sum(x['bytes'] for x in sources),exactPathCount=len(entries),authenticatedHelperDistinctImageCount=len(helper),actualOriginalHelperObjects=11,apiLocalPackageCount=1,cacheMsiDistinctPaths=2,runningScriptDistinctPaths=2,queryPaths=[x['path'] for x in entries],paths=entries,excludedObservations=exclusions,claims=dict(helperIdentity='Only historical original-handle facts in the immutable trial; subsequent path absence is a new limited filesystem observation.',runningScript='Log-only named script path; never classified as a captured executable process.',cache='Observed exact cache/package paths only; no broad cache inference.',missingProcessRole='No claim that an unobserved role was never created.',absence='Only GetFileAttributesW INVALID_FILE_ATTRIBUTES plus Win32 ERROR_FILE_NOT_FOUND/PATH_NOT_FOUND qualifies as KNOWN_ABSENT at observation time.'))
 emit(D/'inputs-first.json',out)
 print(json.dumps(dict(status='PASS_LOCAL_EXTRACTION_WINDOWS_NOT_RUN',paths=len(entries),helpers=len(helper),originals=len(sources),inputsSha256=sha((D/'inputs-first.json').read_bytes()))))
if __name__=='__main__':main()
