# Finite readonly instrument: in-memory Reflection.Emit, no C# compiler/temp files.
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$OutputEncoding=[Console]::OutputEncoding
$expectedSid='S-1-5-21-3896111207-1867804362-1971593122-1001'
$sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
if ($sid -cne $expectedSid) { throw 'Unexpected current Windows SID; no path query attempted.' }
$assembly=[AppDomain]::CurrentDomain.DefineDynamicAssembly([Reflection.AssemblyName]::new('FutureClassroom.R79.ExactReadonlyAttributes'),[Reflection.Emit.AssemblyBuilderAccess]::Run)
$module=$assembly.DefineDynamicModule('MemoryOnly')
$type=$module.DefineType('ExactReadonlyAttributes',[Reflection.TypeAttributes]'Public, Abstract, Sealed')
$native=$type.DefinePInvokeMethod('GetFileAttributesW','kernel32.dll',[Reflection.MethodAttributes]'Public, Static, PinvokeImpl',[Reflection.CallingConventions]::Standard,[uint32],[Type[]]@([string]),[Runtime.InteropServices.CallingConvention]::Winapi,[Runtime.InteropServices.CharSet]::Unicode)
$ctor=[Runtime.InteropServices.DllImportAttribute].GetConstructor([Type[]]@([string]))
$fields=[Reflection.FieldInfo[]]@([Runtime.InteropServices.DllImportAttribute].GetField('EntryPoint'),[Runtime.InteropServices.DllImportAttribute].GetField('CharSet'),[Runtime.InteropServices.DllImportAttribute].GetField('SetLastError'),[Runtime.InteropServices.DllImportAttribute].GetField('ExactSpelling'),[Runtime.InteropServices.DllImportAttribute].GetField('CallingConvention'))
$values=[object[]]@('GetFileAttributesW',[Runtime.InteropServices.CharSet]::Unicode,$true,$true,[Runtime.InteropServices.CallingConvention]::Winapi)
$native.SetCustomAttribute([Reflection.Emit.CustomAttributeBuilder]::new($ctor,[object[]]@('kernel32.dll'),$fields,$values))
$native.SetImplementationFlags($native.GetMethodImplementationFlags() -bor [Reflection.MethodImplAttributes]::PreserveSig)
# Capture Marshal's saved last error immediately after the P/Invoke, inside IL,
# before reflection Invoke returns. Success last-error values are unspecified.
$query=$type.DefineMethod('Query',[Reflection.MethodAttributes]'Public, Static',[uint32[]],[Type[]]@([string]))
$il=$query.GetILGenerator()
$attrs=$il.DeclareLocal([uint32]);$errorCode=$il.DeclareLocal([int32])
$il.Emit([Reflection.Emit.OpCodes]::Ldarg_0)
$il.Emit([Reflection.Emit.OpCodes]::Call,$native)
$il.Emit([Reflection.Emit.OpCodes]::Stloc,$attrs)
$il.Emit([Reflection.Emit.OpCodes]::Call,[Runtime.InteropServices.Marshal].GetMethod('GetLastWin32Error',[Type[]]@()))
$il.Emit([Reflection.Emit.OpCodes]::Stloc,$errorCode)
$il.Emit([Reflection.Emit.OpCodes]::Ldc_I4_2)
$il.Emit([Reflection.Emit.OpCodes]::Newarr,[uint32])
$il.Emit([Reflection.Emit.OpCodes]::Dup)
$il.Emit([Reflection.Emit.OpCodes]::Ldc_I4_0)
$il.Emit([Reflection.Emit.OpCodes]::Ldloc,$attrs)
$il.Emit([Reflection.Emit.OpCodes]::Stelem_I4)
$il.Emit([Reflection.Emit.OpCodes]::Dup)
$il.Emit([Reflection.Emit.OpCodes]::Ldc_I4_1)
$il.Emit([Reflection.Emit.OpCodes]::Ldloc,$errorCode)
$il.Emit([Reflection.Emit.OpCodes]::Stelem_I4)
$il.Emit([Reflection.Emit.OpCodes]::Ret)
$nativeType=$type.CreateType()
$import=[Attribute]::GetCustomAttribute($nativeType.GetMethod('GetFileAttributesW'),[Runtime.InteropServices.DllImportAttribute])
if (-not $import.SetLastError -or -not $import.ExactSpelling -or $import.CharSet -ne [Runtime.InteropServices.CharSet]::Unicode -or $import.EntryPoint -cne 'GetFileAttributesW' -or $import.Value -cne 'kernel32.dll' -or $import.CallingConvention -ne [Runtime.InteropServices.CallingConvention]::Winapi) { throw 'PInvoke metadata not exact; no path query attempted.' }
$queryMethod=$nativeType.GetMethod('Query')
$paths=@('C:\Windows\Installer\34ca58f9.msi','C:\Windows\Installer\34ca58fd.msi','C:\Windows\Installer\MSI5937.tmp','C:\Windows\Installer\MSI5A13.tmp','C:\Windows\Installer\MSI5A24.tmp','C:\Windows\Installer\MSI5DBF.tmp','C:\Windows\Installer\MSI5F56.tmp','C:\Windows\Installer\MSI60DD.tmp','C:\Windows\Installer\MSI61D8.tmp','C:\Windows\Installer\MSI62C4.tmp','C:\Windows\Installer\MSI62C5.tmp')
if ($paths.Count -ne 11) { throw 'Closed exact path count mismatch.' }
$seen=@{}
foreach ($p in $paths) {
 if ($p -cnotmatch '^C:\\Windows\\Installer\\(?:[0-9a-f]{1,16}\.msi|MSI[0-9A-F]{1,8}\.tmp)$' -or $seen.ContainsKey($p.ToLowerInvariant())) { throw 'Path escaped closed Installer namespace.' }
 $seen.Add($p.ToLowerInvariant(),$true)
}
$facts=@(foreach($p in $paths){
 $at=[DateTime]::UtcNow.ToString('o')
 $pair=[uint32[]]$queryMethod.Invoke($null,[object[]]@([string]$p))
 if ($pair.Length -ne 2) { throw 'Native query result length mismatch.' }
 $a=$pair[0];$e=$pair[1]
 $s=if($a -ne [uint32]::MaxValue){'PRESENT'}elseif($e -eq 2 -or $e -eq 3){'KNOWN_ABSENT'}else{'UNKNOWN'}
 @{path=$p;observedAtUtc=$at;attributes=[uint64]$a;win32Error=[uint64]$e;win32ErrorMeaning=if($a -eq [uint32]::MaxValue){'SAVED_ERROR_FOR_FAILED_API'}else{'UNSPECIFIED_ON_SUCCESS'};status=$s}
})
@{schemaVersion=1;facts=$facts;currentSid=$sid;queryApi='GetFileAttributesW';pinvokeSetLastError=$import.SetLastError;pinvokeExactSpelling=$import.ExactSpelling;pinvokeCharSet=$import.CharSet.ToString();lastErrorCapture='IMMEDIATE_MANAGED_IL_AFTER_SAME_NATIVE_CALL';instrument='MEMORY_ONLY_REFLECTION_EMIT_NO_COMPILER_OR_DISK_ASSEMBLY';mutations='NONE';scope='Eleven exact paths only. No directory enumeration, deleted trial nonceRoot query, file write/delete, process interaction, registry, service, or MSI action.'}|ConvertTo-Json -Depth 8 -Compress
