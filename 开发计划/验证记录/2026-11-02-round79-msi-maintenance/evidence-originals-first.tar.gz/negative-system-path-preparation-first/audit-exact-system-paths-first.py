"""Root-only exact readonly Windows audit. Default never contacts Windows."""
from pathlib import Path, PureWindowsPath
import argparse, base64, hashlib, json, re, stat, subprocess, sys
from datetime import datetime, timezone
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
E=Path('/tmp/fc-round79-msi-maintenance')
EXPECTED_D=E/'negative-system-path-preparation-first'
SID='S-1-5-21-3896111207-1867804362-1971593122-1001'
HOST='elior@192.168.10.212'
KEY=Path('/config/.local/share/future-classroom-test-access/win11-192.168.10.212')
PATTERN=re.compile(r'C:\\Windows\\Installer\\(?:[0-9a-f]{1,16}\.msi|MSI[0-9A-F]{1,8}\.tmp)')
REPORT_SHA='0e4a2f4b24d594690e5f6278e1e622dee1c1d1f47bd633e9aa5954e6b16f637b'
def sha(b):return hashlib.sha256(b).hexdigest()
def raw(b,complete=True):return dict(bytes=len(b),sha256=sha(b),base64=base64.b64encode(b).decode(),captureScope='COMPLETE' if complete else 'PARTIAL_TIMEOUT')
def verified_inputs(freeze_sha):
 assert D==EXPECTED_D and not D.is_symlink()
 assert (E/'.owner').read_bytes()==b'future-classroom-owned-r79-msi-maintenance/v1\n'
 fb=(D/'freeze-first.json').read_bytes();assert re.fullmatch('[0-9a-f]{64}',freeze_sha or '') and sha(fb)==freeze_sha,'Caller must pin exact freeze SHA'
 f=json.loads(fb)
 assert f['status']=='FROZEN_PREPARATION_WINDOWS_NOT_RUN'
 for x in f['files']:
  assert '/' not in x['name'] and '\\' not in x['name']
  p=D/x['name'];assert not p.is_symlink()
  b=p.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'],x['name']
 assert {x['name'] for x in f['files']}=={'prepare-inputs-first.py','inputs-first.json','exact-system-paths-first.ps1','audit-exact-system-paths-first.py','README-first.txt'}
 b=(D/'inputs-first.json').read_bytes();i=json.loads(b)
 assert i['status']=='PREPARED_NOT_RUN' and i['exactPathCount']==11 and i['authenticatedHelperDistinctImageCount']==7
 rp=i['runtimeReport'];assert rp['path']==str(E/'product-negative-runtime-first/report.json') and rp['sha256']==REPORT_SHA
 rb=Path(rp['path']).read_bytes();assert len(rb)==rp['bytes'] and sha(rb)==REPORT_SHA
 r=json.loads(rb);assert r['status']=='PASS_PRODUCT_MSI_RUNTIME_CAPTURE_AND_EXACT_SCRATCH_CLEANUP_WIN11_ONLY'
 download=Path(i['downloadRootLocalOnly']);assert download.parent==E/'product-negative-runtime-first/download' and not download.is_symlink()
 expected={x['path'].replace('\\','/'):x for x in r['remoteInventory']['files']}
 assert len(i['verifiedDownloadedOriginals'])==49 and len(expected)==49
 actual=set()
 for x in i['verifiedDownloadedOriginals']:
  rel=x['relativePath'];p=download/rel
  assert p==Path(x['path']) and not p.is_symlink() and p.resolve().is_relative_to(download.resolve())
  b=p.read_bytes();y=expected[rel];assert len(b)==x['bytes']==y['bytes'] and sha(b)==x['sha256']==y['sha256'];actual.add(rel)
 assert actual==set(expected)=={str(p.relative_to(download)).replace('\\','/') for p in download.rglob('*') if p.is_file()}
 paths=i['queryPaths'];assert len(paths)==11 and len({p.casefold() for p in paths})==11
 assert [x['path'] for x in i['paths']]==paths
 for p in paths:assert PATTERN.fullmatch(p) and str(PureWindowsPath(p).parent)=='C:\\Windows\\Installer'
 ps=(D/'exact-system-paths-first.ps1').read_bytes()
 assert b'__EXACT_PATHS__' not in ps and b'FutureClassroom-r79-production-msi-' not in ps
 assert sum(ps.count(("'"+p+"'").encode()) for p in paths)==11
 return f,i,ps

def qualify_observed(o,paths):
 assert o['mutations']=='NONE' and o['currentSid']==SID and o['queryApi']=='GetFileAttributesW'
 assert o['instrument']=='MEMORY_ONLY_REFLECTION_EMIT_NO_COMPILER_OR_DISK_ASSEMBLY'
 assert o['pinvokeSetLastError'] is True and o['pinvokeExactSpelling'] is True and o['pinvokeCharSet']=='Unicode'
 assert o['lastErrorCapture']=='IMMEDIATE_MANAGED_IL_AFTER_SAME_NATIVE_CALL'
 facts=o['facts'];assert len(facts)==len(paths) and [x['path'] for x in facts]==paths
 for fact in facts:
  a=fact['attributes'];error=fact['win32Error'];assert type(a) is int and 0<=a<=4294967295 and type(error) is int and 0<=error<=4294967295
  expect='PRESENT' if a!=4294967295 else 'KNOWN_ABSENT' if error in (2,3) else 'UNKNOWN'
  assert fact['status']==expect,'Remote status must agree with native attributes/error'
  assert fact['win32ErrorMeaning']==('SAVED_ERROR_FOR_FAILED_API' if a==4294967295 else 'UNSPECIFIED_ON_SUCCESS')
 return 'PASS_ELEVEN_EXACT_PATHS_KNOWN_ABSENT_WIN11_ONLY' if all(x['status']=='KNOWN_ABSENT' for x in facts) else 'FAIL_PRESENT_OR_UNKNOWN_EXACT_PATH_RETAINED_WITHOUT_MUTATION'

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--execute',action='store_true');ap.add_argument('--validate-only',action='store_true');ap.add_argument('--freeze-sha256');ap.add_argument('--report',type=Path)
 a=ap.parse_args()
 if not a.execute and not a.validate_only:
  print(json.dumps(dict(status='PREPARED_NOT_RUN',windows='NOT_RUN',mutations='NONE',requires='Root --execute --freeze-sha256 EXACT_FREEZE_SHA --report NEW_R79_ROOT_JSON')));return 0
 assert not(a.execute and a.validate_only),'Choose local validation or actual execution'
 f,i,ps=verified_inputs(a.freeze_sha256)
 if a.validate_only:
  print(json.dumps(dict(status='PASS_LOCAL_FROZEN_INPUT_CLOSURE_WINDOWS_NOT_RUN',files=49,exactPaths=11,helpers=7,freezeSha256=a.freeze_sha256)));return 0
 assert a.report and a.report.is_absolute() and a.report.parent==E and a.report.suffix=='.json' and not a.report.exists(),'New direct R79 root JSON report required'
 assert stat.S_IMODE(KEY.stat().st_mode)==0o600,'Persistent key metadata only; never read key bytes'
 wrapper='[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);& ([ScriptBlock]::Create([Console]::In.ReadToEnd()));'
 command=['ssh','-i',str(KEY),'-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=8',HOST,'powershell.exe -NoProfile -NonInteractive -EncodedCommand '+base64.b64encode(wrapper.encode('utf-16-le')).decode()]
 report=dict(schemaVersion=1,status='FAIL',windows='ACTUAL_REQUESTED',startedUtc=datetime.now(timezone.utc).isoformat(),mutations='NONE',scope='Exact eleven original C:\\Windows\\Installer path attributes only. No broad Installer enumeration, deleted original trial scratch query, file write/delete, process interaction, MSI, registry, task or service action.',freezeSha256=a.freeze_sha256,controllerSha256=sha(Path(__file__).read_bytes()),inputsSha256=sha((D/'inputs-first.json').read_bytes()),sourceRuntimeReportSha256=REPORT_SHA,paths=i['paths'],command=command,stdin=raw(ps),powershellSource=ps.decode('utf-8'),timeoutSeconds=45,privateKeyContentsRead=False)
 with a.report.open('x',encoding='utf-8') as output:
  try:
   p=subprocess.run(command,input=ps,capture_output=True,timeout=45)
   report['ssh']=dict(actualExit=True,exitCode=p.returncode,stdout=raw(p.stdout),stderr=raw(p.stderr))
   assert p.returncode==0,'SSH/PowerShell nonzero actual exit; no absence inferred'
   o=json.loads(p.stdout.decode('utf-8-sig'));report['observed']=o;report['status']=qualify_observed(o,i['queryPaths'])
  except subprocess.TimeoutExpired as error:
   report['ssh']=dict(actualExit=False,exitCode=None,stdout=raw(error.stdout or b'',False),stderr=raw(error.stderr or b'',False));report['error']='TIMEOUT_NO_ABSENCE_INFERRED'
  except Exception as error:report['error']=dict(kind=type(error).__name__,message=str(error))
  report['completedUtc']=datetime.now(timezone.utc).isoformat();output.write(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(dict(status=report['status'],report=str(a.report),reportSha256=sha(a.report.read_bytes()),exactPaths=11,mutations='NONE')))
 return 0 if report['status']=='PASS_ELEVEN_EXACT_PATHS_KNOWN_ABSENT_WIN11_ONLY' else 1
if __name__=='__main__':raise SystemExit(main())
