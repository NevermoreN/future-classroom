#!/usr/bin/env python3
"""Independent R79 fixture producer. Default is inert; root runs explicit stages.
No SSH, downloads, MSI execution, production inputs or cleanup commands exist here.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PureWindowsPath
import re
import shutil
import struct
import subprocess
import time
import uuid
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
MARKER = "future-classroom-owned-r79-early-terminal-fixture/v1\n"
SOURCES = ("EarlyTerminal.c", "PositiveControl.cs", "Compile-PositiveControl.ps1", "Invoke-EarlyTerminal.ps1", "Capture.cs", "fixture.py")
EXPORTS = ("Fc79Prepare", "Fc79Rollback", "Fc79ForceFail", "Fc79TerminalSuccess", "Fc79TerminalCancel", "Fc79TerminalFailure")
GUID = re.compile(r"\{[0-9A-F]{8}(?:-[0-9A-F]{4}){3}-[0-9A-F]{12}\}")

def need(ok, why):
    if not ok:
        raise ValueError(why)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def regular(p, limit=32*1024*1024):
    need(p.is_file() and not p.is_symlink(), "Regular original file required: " + str(p))
    data = p.read_bytes()
    need(len(data) <= limit, "File exceeds bound")
    return data

def fact(p):
    data = regular(p)
    return {"bytes": len(data), "sha256": sha(data)}

def new_json(p, data):
    with p.open("x", encoding="utf-8", newline="\n") as f:
        json.dump(data, f, indent=2, ensure_ascii=True)
        f.write("\n")

def load_spec(p, pin):
    raw = regular(p, 65536)
    need(sha(raw) == pin, "Spec hash differs")
    s = json.loads(raw)
    need(s["schemaVersion"] == 1 and s["wholeSeconds"] == 600 and s["nativeSeconds"] == 120, "Fixture budget/schema differs")
    need(re.fullmatch("[0-9a-f]{32}", s["nonce"]) is not None, "Nonce")
    need(s["rootName"] == "FutureClassroom-r79-early-terminal-" + s["nonce"], "Root leaf")
    need(s["marker"] == MARKER, "Owner marker")
    need(re.fullmatch("[0-9a-f]{40}",s["sourceGit"]) is not None,"Explicit source Git identity")
    need(s["registryKey"] == "Software\\FutureClassroomTest\\Round79-"+s["nonce"],"Exact nonce HKCU namespace")
    need(re.fullmatch(r"S-1-5-21-(?:[0-9]+-){3}[0-9]+", s["expectedUserSid"]) is not None, "Explicit user SID")
    root = PureWindowsPath(s["windowsRoot"])
    need(root.drive.upper() == "C:" and root.name == s["rootName"] and root.parent.name == "Temp" and root.parent.parent.name == "Local" and root.parent.parent.parent.name == "AppData", "Fixed user TEMP namespace")
    need('"' not in str(root) and ".." not in root.parts and not str(root).startswith("\\\\"), "Canonical local root")
    need(str(root)==s["windowsRoot"] and len(root.parts)==7 and root.parts[1]=="Users", "Exact user TEMP path shape")
    need(all(not any(c in part for c in '<>:"|?*\r\n\0') and part not in (".","..") and not part.endswith(("."," ")) for part in root.parts[1:]),"Windows path components")
    need(s["effectDir"] == str(root / "effect") + "\\", "Exact effect directory")
    guids = [s[k] for k in ("productCode", "upgradeCode", "componentId")]
    need(all(GUID.fullmatch(v) for v in guids) and len(set(guids)) == 3, "Distinct private GUIDs")
    for item in s["sources"]:
        need(item["path"] in SOURCES and fact(HERE/item["path"]) == {k:item[k] for k in ("bytes", "sha256")}, "Preparation source changed")
    need({v["path"] for v in s["sources"]} == set(SOURCES), "Source closure")
    return s

def prepare(a):
    need(re.fullmatch("[0-9a-f]{32}", a.nonce) is not None, "Nonce")
    root_name = "FutureClassroom-r79-early-terminal-" + a.nonce
    win = str(PureWindowsPath(a.windows_temp) / root_name)
    s = {"schemaVersion":1, "status":"PREPARED_NOT_COMPILED_PACKAGED_OR_RUN", "nonce":a.nonce,
         "sourceGit":a.source_git, "expectedUserSid":a.expected_user_sid, "rootName":root_name,
         "windowsRoot":win, "effectDir":str(PureWindowsPath(win)/"effect")+"\\", "marker":MARKER,
         "wholeSeconds":600, "nativeSeconds":120, "clientSeconds":120, "finallyReserveSeconds":180,
         "positiveSupervisorSeconds":10, "positiveAckSeconds":2,
         "registryKey":"Software\\FutureClassroomTest\\Round79-"+a.nonce,
         "sources":[{"path":name, **fact(HERE/name)} for name in SOURCES]}
    for name in ("productCode", "upgradeCode", "componentId"):
        s[name] = "{"+str(uuid.uuid4()).upper()+"}"
    need(not a.output.exists(), "Fresh output required")
    a.output.mkdir()
    new_json(a.output/"spec.json", s)
    # Round-trip closed input validation, not a fabricated build/runtime receipt.
    load_spec(a.output/"spec.json", sha((a.output/"spec.json").read_bytes()))
    for name in SOURCES:
        shutil.copyfile(HERE/name, a.output/name)
    (a.output/".owner").write_text(MARKER, encoding="ascii")
    new_json(a.output/"inputs.json", {"schemaVersion":1,"files":[{"path":p.name, **fact(p)} for p in sorted(a.output.iterdir()) if p.is_file()]})
    return {"status":"PREPARED_NOT_COMPILED_PACKAGED_OR_RUN", "spec":str(a.output/"spec.json"), **fact(a.output/"spec.json")}

def idt(raw, table):
    lines = raw.decode("utf-8", "strict").splitlines()
    need(len(raw)<=4*1024*1024 and 3 <= len(lines) < 4096, "Bounded IDT")
    cols, types, keys = [line.split("\t") for line in lines[:3]]
    need(len(cols) == len(set(cols)) == len(types) and keys[0] == table and len(keys)>1, "IDT schema")
    rows=[]; seen=set()
    for line in lines[3:]:
        if not line: continue
        cells=line.split("\t"); need(len(cells)==len(cols), "IDT cells")
        r=dict(zip(cols,cells)); key=tuple(r[k] for k in keys[1:])
        need(key not in seen, "Duplicate MSI PK"); seen.add(key); rows.append(r)
    return rows

def encoded_idt(table, columns, types, keys, rows):
    lines=["\t".join(columns), "\t".join(types), "\t".join([table]+keys)]
    lines += ["\t".join(row) for row in rows]
    return ("\r\n".join(lines)+"\r\n").encode("ascii")

def package_code(s,case):
    return "{"+str(uuid.uuid5(uuid.UUID(s["productCode"].strip("{}")),"r79:"+case)).upper()+"}"

def wxs(s,case="positive"):
    ns="http://schemas.microsoft.com/wix/2006/wi"; ET.register_namespace("",ns)
    def add(p,tag,**kw): return ET.SubElement(p,"{"+ns+"}"+tag,kw)
    top=ET.Element("{"+ns+"}Wix")
    p=add(top,"Product",Id=s["productCode"],Name="FC R79 isolated early terminal fixture",Language="1033",Codepage="1252",Version="0.0.1",Manufacturer="FutureClassroomTest",UpgradeCode=s["upgradeCode"])
    add(p,"Package",Id=package_code(s,case),InstallerVersion="500",Compressed="yes",InstallScope="perUser")
    add(p,"Media",Id="1",Cabinet="fixture.cab",EmbedCab="yes")
    add(p,"Property",Id="MSIRESTARTMANAGERCONTROL",Value="DisableShutdown")
    add(p,"Condition",Message="Per user only").text="NOT ALLUSERS"
    add(p,"Condition",Message="Rollback required").text="NOT RollbackDisabled AND NOT DISABLEROLLBACK"
    add(p,"Condition",Message="No shutdown").text='MSIRESTARTMANAGERCONTROL = "DisableShutdown"'
    d=add(p,"Directory",Id="TARGETDIR",Name="SourceDir")
    d=add(d,"Directory",Id="TempFolder")
    d=add(d,"Directory",Id="FixtureRoot",Name=s["rootName"])
    d=add(d,"Directory",Id="EffectDir",Name="effect")
    c=add(d,"Component",Id="FixtureComponent",Guid=s["componentId"],Win64="no")
    add(c,"File",Id="FixtureFile",Source="payload.txt",Name="payload.txt",DiskId="1",KeyPath="no")
    add(c,"RegistryValue",Id="FixtureMarker",Root="HKCU",Key=s["registryKey"],Name="Marker",Type="integer",Value="1",KeyPath="yes")
    feature=add(p,"Feature",Id="FixtureFeature",Title="Fixture",Level="1")
    add(feature,"ComponentRef",Id="FixtureComponent")
    add(p,"Binary",Id="ObserverDll",SourceFile="EarlyTerminal.dll")
    add(p,"Binary",Id="PositiveChainer",SourceFile="PositiveControl.exe")
    seq=add(p,"InstallExecuteSequence"); add(seq,"InstallExecute",Sequence="6500")
    ET.indent(top)
    return ET.tostring(top,encoding="utf-8",xml_declaration=True)+b"\n"

def pe(data, dll=False):
    need(len(data)>128 and data[:2]==b"MZ", "PE")
    off=struct.unpack_from("<I",data,60)[0]
    need(off+96<len(data) and data[off:off+4]==b"PE\0\0", "PE offset")
    need(struct.unpack_from("<H",data,off+4)[0]==0x14c and struct.unpack_from("<H",data,off+24)[0]==0x10b, "x86 PE32 required")
    need(bool(struct.unpack_from("<H",data,off+22)[0]&0x2000)==dll, "DLL bit")
    if not dll: need(struct.unpack_from("<H",data,off+92)[0]==2,"GUI fixture required")

def build(a):
    s=load_spec(a.spec,a.spec_sha256)
    tools=json.loads(regular(a.tools,65536)); names={"gcc","objdump","wixl","msibuild","msiinfo","msiextract"}
    need(set(tools)==names,"Exact six tools")
    for name,item in tools.items():
        p=Path(item["path"]); need(p.is_absolute() and fact(p)["sha256"]==item["sha256"], "Tool pin "+name)
    chainer=regular(a.chainer_exe)
    need(sha(chainer)==a.chainer_sha256,"Actual chainer pin"); pe(chainer)
    receipt=json.loads(regular(a.compile_receipt,65536))
    need(receipt["status"]=="PASS_CSC_ACTUAL_EXIT0_COMPILE_ONLY" and receipt["actualExit"]==0 and receipt["source"]==fact(HERE/"PositiveControl.cs") and receipt["exe"]==fact(a.chainer_exe) and receipt["nonce"]==s["nonce"],"Compile-only provenance")
    need(not a.output.exists(), "Fresh build output"); a.output.mkdir()
    deadline=time.monotonic()+600
    report={"status":"FAIL_NOT_RUNTIME", "installation":"NOT_RUN", "spec":fact(a.spec), "script":fact(Path(__file__)), "tools":tools,"commands":[],"cases":{},"compileReceipt":fact(a.compile_receipt)}
    def run(label,args):
        left=deadline-time.monotonic(); need(left>0,"600s producer deadline")
        env=os.environ.copy()
        if a.child_environment:
            extra=json.loads(regular(a.child_environment,65536)); need(set(extra)<={"LD_LIBRARY_PATH"} and all(isinstance(v,str) for v in extra.values()),"Child LD env only")
            env.update(extra)
        start=time.monotonic(); outcome={"label":label,"argv":args,"timeoutSeconds":min(120,left)}
        try:
            p=subprocess.run(args,cwd=a.output,env=env,timeout=min(120,left),stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
            (a.output/(label+".stdout")).write_bytes(p.stdout); (a.output/(label+".stderr")).write_bytes(p.stderr)
            outcome.update(actualExit=p.returncode,parentReaped=True,seconds=time.monotonic()-start,stdout=sha(p.stdout),stderr=sha(p.stderr)); report["commands"].append(outcome)
            need(p.returncode==0,"Actual tool failure "+label); return p.stdout
        except subprocess.TimeoutExpired as e:
            outcome.update(actualExit=None,parentReaped=True,timeout=True); report["commands"].append(outcome)
            (a.output/(label+".stdout")).write_bytes(e.stdout or b""); (a.output/(label+".stderr")).write_bytes(e.stderr or b""); raise
    try:
        shutil.copyfile(HERE/"EarlyTerminal.c",a.output/"EarlyTerminal.c")
        (a.output/"PositiveControl.exe").write_bytes(chainer)
        escaped=lambda v:json.dumps(v,ensure_ascii=True)
        (a.output/"fixture_config.h").write_text("#define FC79_NONCE L"+escaped(s["nonce"])+"\n#define FC79_PRODUCT L"+escaped(s["productCode"])+"\n#define FC79_EFFECT_DIR L"+escaped(s["effectDir"])+"\n",encoding="ascii")
        payload=("FutureClassroom isolated R79 fixture "+s["nonce"]+"\n").encode("ascii")
        (a.output/"payload.txt").write_bytes(payload)
        run("01-gcc-dll",[tools["gcc"]["path"],"-std=c11","-O2","-Wall","-Wextra","-Werror","-shared","-Wl,--kill-at","-o","EarlyTerminal.dll","EarlyTerminal.c","-lmsi","-ladvapi32"])
        pe(regular(a.output/"EarlyTerminal.dll"),True)
        exports=run("02-dll-exports",[tools["objdump"]["path"],"-p","EarlyTerminal.dll"]).decode("utf-8","strict")
        found=re.findall(r"^\s*\[\s*[0-9]+\]\s+(Fc79\w+)\s*$",exports,re.M)
        need(sorted(found)==sorted(EXPORTS),"Exact six undecorated DLL exports")
        ca=[("Fc79Prepare","1","ObserverDll","Fc79Prepare"),("Fc79Rollback","1281","ObserverDll","Fc79Rollback"),("Fc79ForceFail","1","ObserverDll","Fc79ForceFail")]+[("Fc79Terminal"+role,"1","ObserverDll","Fc79Terminal"+role) for role in ("Success","Cancel","Failure")]
        (a.output/"CustomAction.idt").write_bytes(encoded_idt("CustomAction",["Action","Type","Source","Target"],["s72","i2","S72","S255"],["Action"],ca))
        chain=[("FixtureSupervisor","NOT Installed",'supervisor "'+s["windowsRoot"]+'" '+s["nonce"],"PositiveChainer","2")]
        (a.output/"MsiEmbeddedChainer.idt").write_bytes(encoded_idt("MsiEmbeddedChainer",["MsiEmbeddedChainer","Condition","CommandLine","Source","Type"],["s72","S255","S255","s72","i2"],["MsiEmbeddedChainer"],chain))
        for case,fail in (("positive","0"),("early-fail","1")):
            (a.output/(case+".wxs")).write_bytes(wxs(s,case))
            run(case+"-wixl",[tools["wixl"]["path"],"-a","x86","-o",case+".msi",case+".wxs"])
            seq=idt(run(case+"-base-sequence",[tools["msiinfo"]["path"],"export",case+".msi","InstallExecuteSequence"]),"InstallExecuteSequence")
            required={"InstallInitialize":1500,"InstallExecute":6500,"InstallFinalize":6600}
            need(all(any(r["Action"]==k and int(r["Sequence"])==v for r in seq) for k,v in required.items()),"Standard script sequence")
            extra=[("Fc79Prepare","NOT Installed","1499"),("Fc79Rollback","NOT Installed","1501"),("Fc79ForceFail",fail+" AND NOT Installed","6501"),("Fc79TerminalSuccess","NOT Installed","-1"),("Fc79TerminalCancel","NOT Installed","-2"),("Fc79TerminalFailure","NOT Installed","-3")]
            allseq=[tuple(r[k] for k in ("Action","Condition","Sequence")) for r in seq]+extra
            (a.output/"InstallExecuteSequence.idt").write_bytes(encoded_idt("InstallExecuteSequence",["Action","Condition","Sequence"],["s72","S255","i2"],["Action"],allseq))
            run(case+"-import",[tools["msibuild"]["path"],case+".msi","-q","DROP TABLE `CustomAction`","-q","DROP TABLE `InstallExecuteSequence`","-i","CustomAction.idt","-i","InstallExecuteSequence.idt","-i","MsiEmbeddedChainer.idt"])
            tables=run(case+"-tables",[tools["msiinfo"]["path"],"tables",case+".msi"]).decode().splitlines()
            summary=run(case+"-summary",[tools["msiinfo"]["path"],"suminfo",case+".msi"]).decode("utf-8","strict")
            need(package_code(s,case) in summary and "Intel;1033" in summary and re.search(r"Version:\s+500\b",summary),"Distinct exact x86/Installer500 package summary")
            # Pinned wixl creates these schemas even when empty. Empty effect
            # tables are not mistaken for authored effects; their rows must be
            # empty below. Unknown schemas still fail.
            allowed={"_SummaryInformation","_ForceCodepage","Property","Directory","Feature","Component","FeatureComponents","File","Media","Registry","Binary","CustomAction","InstallExecuteSequence","InstallUISequence","AdminExecuteSequence","AdminUISequence","AdvtExecuteSequence","MsiEmbeddedChainer","LaunchCondition","Upgrade","Error","ServiceInstall","AppSearch","Shortcut","ActionText","IniFile","RemoveFile","RemoveIniFile","Signature","ServiceControl","RegLocator","MsiFileHash","Icon","CreateFolder"}
            need(set(tables)<=allowed and {"Media","Registry","File","Component","MsiEmbeddedChainer","CustomAction"}<=set(tables),"Closed tables; no other effect table")
            rows={}
            for table in tables:
                if table.startswith("_"): continue
                raw=run(case+"-table-"+table,[tools["msiinfo"]["path"],"export",case+".msi",table]); rows[table]=idt(raw,table)
            need(sorted(rows["CustomAction"],key=lambda r:r["Action"])==sorted([dict(zip(("Action","Type","Source","Target"),r)) for r in ca],key=lambda r:r["Action"]),"CA exact")
            need(sorted(rows["InstallExecuteSequence"],key=lambda r:r["Action"])==sorted([dict(zip(("Action","Condition","Sequence"),r)) for r in allseq],key=lambda r:r["Action"]),"Execute exact")
            need(rows["MsiEmbeddedChainer"]==[dict(zip(("MsiEmbeddedChainer","Condition","CommandLine","Source","Type"),chain[0]))],"Chainer exact")
            need(len(rows["File"])==len(rows["Registry"])==len(rows["Component"])==len(rows["FeatureComponents"])==1,"Exactly one effect component")
            need(rows["Component"][0]["ComponentId"]==s["componentId"] and rows["Component"][0]["Attributes"]=="4" and rows["Component"][0]["Directory_"]=="EffectDir" and rows["Component"][0]["KeyPath"]=="FixtureMarker","HKCU32 registry-keypath component")
            need(rows["Registry"][0]=={"Registry":"FixtureMarker","Root":"1","Key":s["registryKey"],"Name":"Marker","Value":"#1","Component_":"FixtureComponent"},"Exact isolated registry row")
            need(rows["FeatureComponents"]==[{"Feature_":"FixtureFeature","Component_":"FixtureComponent"}],"Feature membership")
            need(rows["File"][0]["File"]=="FixtureFile" and rows["File"][0]["Component_"]=="FixtureComponent" and rows["File"][0]["FileName"].split("|")[-1]=="payload.txt" and int(rows["File"][0]["FileSize"])==len(payload),"Single payload row")
            need(len(rows["Media"])==1 and rows["Media"][0]["DiskId"]=="1" and int(rows["Media"][0]["LastSequence"])==1,"Real file cabinet media")
            need(not rows.get("Upgrade"),"No upgrade effects")
            for table in ("ServiceInstall","ServiceControl","AppSearch","Shortcut","IniFile","RemoveFile","RemoveIniFile","Signature","RegLocator","Icon","CreateFolder"):
                need(not rows.get(table),"No extra fixture effects/lookup: "+table)
            hashes=rows.get("MsiFileHash",[])
            if hashes:
                expected_hash=struct.unpack("<4I",hashlib.md5(payload,usedforsecurity=False).digest())
                need(len(hashes)==1 and hashes[0]["File_"]=="FixtureFile" and hashes[0]["Options"]=="0" and tuple(int(hashes[0]["HashPart"+str(i+1)])&0xffffffff for i in range(4))==expected_hash,"Exact optional one-file MSI hash")
            properties={r["Property"]:r["Value"] for r in rows["Property"]}
            need(properties.get("ProductCode")==s["productCode"] and properties.get("UpgradeCode")==s["upgradeCode"] and properties.get("ProductVersion")=="0.0.1" and "ALLUSERS" not in properties,"Private per-user product identity")
            directories={r["Directory"]:{**r,"DefaultDir":r["DefaultDir"].split("|")[-1]} for r in rows["Directory"]}
            need(directories=={"TARGETDIR":{"Directory":"TARGETDIR","Directory_Parent":"","DefaultDir":"SourceDir"},"TempFolder":{"Directory":"TempFolder","Directory_Parent":"TARGETDIR","DefaultDir":"."},"FixtureRoot":{"Directory":"FixtureRoot","Directory_Parent":"TempFolder","DefaultDir":s["rootName"]},"EffectDir":{"Directory":"EffectDir","Directory_Parent":"FixtureRoot","DefaultDir":"effect"}},"Exact user TEMP fixed target directory tree")
            need({r["Name"] for r in rows["Binary"]}=={"ObserverDll","PositiveChainer"} and len(rows["Binary"])==2,"Exact two binaries")
            for binary,path in (("ObserverDll","EarlyTerminal.dll"),("PositiveChainer","PositiveControl.exe")):
                need(run(case+"-binary-"+binary,[tools["msiinfo"]["path"],"extract",case+".msi","Binary."+binary])==regular(a.output/path),"Actual Binary readback")
            extracted=a.output/(case+"-extracted"); extracted.mkdir()
            run(case+"-payload-extract",[tools["msiextract"]["path"],"-C",str(extracted),case+".msi"])
            files=[p for p in extracted.rglob("*") if p.is_file()]
            need(len(files)==1 and files[0].name=="payload.txt" and regular(files[0])==payload,"Actual payload extraction")
            report["cases"][case]={"msi":fact(a.output/(case+".msi")),"packageCode":package_code(s,case),"tables":rows,"installedFile":fact(files[0]),"status":"PASS_STATIC_ONLY_NOT_RUN"}
        report.update(status="PASS_LOCAL_BUILD_STATIC_ONLY_WINDOWS_NOT_RUN",dll=fact(a.output/"EarlyTerminal.dll"),chainer=fact(a.output/"PositiveControl.exe"),specData=s)
    finally:
        report["toolsUnchanged"]=all(fact(Path(v["path"]))["sha256"]==v["sha256"] for v in tools.values())
        report["sourcesUnchanged"]=all(fact(HERE/v["path"])=={k:v[k] for k in ("bytes","sha256")} for v in s["sources"])
        if not report["toolsUnchanged"] or not report["sourcesUnchanged"]:
            report["status"]="FAIL_SOURCE_OR_TOOL_CHANGED_NOT_RUNTIME"
        new_json(a.output/"build-report.json",report)
    need(report["status"]=="PASS_LOCAL_BUILD_STATIC_ONLY_WINDOWS_NOT_RUN","Original static producer failed")
    return report

def stage(a):
    s=load_spec(a.spec,a.spec_sha256)
    report_raw=regular(a.build_dir/"build-report.json",1024*1024)
    need(sha(report_raw)==a.build_report_sha256,"Actual build report SHA")
    report=json.loads(report_raw)
    need(report["status"]=="PASS_LOCAL_BUILD_STATIC_ONLY_WINDOWS_NOT_RUN" and report["toolsUnchanged"] is True and report["sourcesUnchanged"] is True and report["spec"]==fact(a.spec),"Original complete static producer required")
    need(not a.output.exists(),"Fresh staging directory")
    a.output.mkdir()
    for name in SOURCES: shutil.copyfile(HERE/name,a.output/name)
    shutil.copyfile(a.spec,a.output/"spec.json")
    for name in ("positive.msi","early-fail.msi","PositiveControl.exe","EarlyTerminal.dll","payload.txt","build-report.json"):
        data=regular(a.build_dir/name)
        expected=(report["cases"][name[:-4]]["msi"] if name.endswith(".msi") else report["chainer"] if name=="PositiveControl.exe" else report["dll"] if name=="EarlyTerminal.dll" else None)
        if expected: need(fact(a.build_dir/name)==expected,"Original producer artifact changed")
        (a.output/name).write_bytes(data)
    (a.output/".owner").write_text(MARKER,encoding="ascii")
    new_json(a.output/"runtime-inputs.json",{"schemaVersion":1,"status":"PREPARED_RUNTIME_NOT_RUN","specSha256":a.spec_sha256,"buildReportSha256":a.build_report_sha256,"files":[{"path":p.name,**fact(p)} for p in sorted(a.output.iterdir()) if p.is_file()]})
    return {"status":"PREPARED_RUNTIME_NOT_RUN","runtimeManifest":fact(a.output/"runtime-inputs.json"),"windowsRoot":s["windowsRoot"],"uploadDirectory":str(a.output)}

def main():
    p=argparse.ArgumentParser(description=__doc__); sub=p.add_subparsers(dest="mode")
    q=sub.add_parser("prepare"); q.add_argument("--nonce",required=True); q.add_argument("--windows-temp",required=True); q.add_argument("--expected-user-sid",required=True); q.add_argument("--source-git",required=True); q.add_argument("--output",type=Path,required=True)
    q=sub.add_parser("build"); q.add_argument("--execute",action="store_true"); q.add_argument("--spec",type=Path,required=True); q.add_argument("--spec-sha256",required=True); q.add_argument("--tools",type=Path,required=True); q.add_argument("--child-environment",type=Path); q.add_argument("--chainer-exe",type=Path,required=True); q.add_argument("--chainer-sha256",required=True); q.add_argument("--compile-receipt",type=Path,required=True); q.add_argument("--output",type=Path,required=True)
    q=sub.add_parser("stage-runtime");q.add_argument("--spec",type=Path,required=True);q.add_argument("--spec-sha256",required=True);q.add_argument("--build-dir",type=Path,required=True);q.add_argument("--build-report-sha256",required=True);q.add_argument("--output",type=Path,required=True)
    a=p.parse_args()
    if a.mode=="prepare": result=prepare(a)
    elif a.mode=="build" and a.execute: result=build(a)
    elif a.mode=="stage-runtime": result=stage(a)
    else: result={"status":"PREPARED_NOT_RUN","compilation":"NOT_RUN","packaging":"NOT_RUN","windows":"NOT_RUN"}
    print(json.dumps(result,indent=2,ensure_ascii=True))

if __name__=="__main__": main()
