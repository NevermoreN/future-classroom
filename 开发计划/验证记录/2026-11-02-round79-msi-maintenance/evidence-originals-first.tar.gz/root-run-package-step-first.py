"""Serial root invocation of frozen R79 local package preparation steps."""
from pathlib import Path
import argparse, datetime, hashlib, json, subprocess, sys, time
E=Path('/tmp/fc-round79-msi-maintenance');D=E/'package-preparation-first'
def sha(b):return hashlib.sha256(b).hexdigest()
def fact(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def main():
    p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');p.add_argument('--step',type=int,choices=[1,2,3,4],required=True);a=p.parse_args()
    if not a.execute:print(json.dumps(dict(status='NOT_RUN',step=a.step)));return 0
    assert (E/'.owner').read_bytes()==b'future-classroom-owned-r79-msi-maintenance/v1\n'
    frozen=D/'freeze-first.json';assert sha(frozen.read_bytes())=='f91bd422cbf6c5427c06b780b8e85a937b88c7877a104de8ed29cfefe671c946'
    f=json.loads(frozen.read_bytes())
    for row in f['files']:
        q=Path(row['path']);assert q.resolve().is_relative_to(D) and not q.is_symlink();assert fact(q)==row
    plan=D/'execution-plan-first.json';assert sha(plan.read_bytes())=='7f89a4ea3df5380cfc2220fb1e2cffc85b3cbbd1873abbe2e9ded59bf8511c40'
    command=json.loads(plan.read_bytes())['steps'][a.step-1]['command']
    if a.step in (2,4):
        audit=D/'win7-static-audit-first.json';operation=D/'win7-static-operation-first.json'
        assert json.loads(audit.read_bytes())['status']=='PASS_STATIC_ONLY_RUNTIME_NOT_RUN'
        assert json.loads(operation.read_bytes())['status']=='PASS_STATIC_AUDITOR_ACTUAL_EXIT0'
        changes={'<actual produced audit SHA256>':fact(audit)['sha256'],'<same actual audit SHA256>':fact(audit)['sha256'],'<actual produced static operation SHA256>':fact(operation)['sha256']}
        if a.step==4:
            stage=D/'stage-original-build-first.json';tools=D/'msi-tools-preparation-first/msi-tools-preparation-first.json'
            assert json.loads(stage.read_bytes())['status']=='PASS_COMPLETE_ORIGINAL_BUILD_NAMESPACE_NOT_PRODUCT_RUNTIME'
            assert json.loads(tools.read_bytes())['status']=='PASS_EXACT_PACKAGES_LOCAL_EXTRACTION_ELF_BINDING_AND_SCOPED_TOOL_LOADING_ONLY'
            changes.update({'<actual stage-original-build-first.json SHA256>':fact(stage)['sha256'],'<actual msi-tools-preparation-first/msi-tools-preparation-first.json SHA256>':fact(tools)['sha256']})
        command=[changes.get(x,x) for x in command]
    assert not any(x.startswith('<') for x in command)
    out=E/f'root-package-step-{a.step}-first.stdout.log';err=E/f'root-package-step-{a.step}-first.stderr.log';report=E/f'root-package-step-{a.step}-first.json'
    assert not any(p.exists() for p in (out,err,report))
    r=dict(status='RUNNING',step=a.step,command=command,startedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),controllerSha256=sha(Path(__file__).read_bytes()),frozenPreparation=fact(frozen))
    with report.open('x') as s:s.write(json.dumps(r,indent=2)+'\n')
    t=time.monotonic()
    with out.open('xb') as so,err.open('xb') as se:
        child=subprocess.Popen(command,stdout=so,stderr=se);r['pid']=child.pid;report.write_text(json.dumps(r,indent=2)+'\n');code=child.wait()
    r.update(status='PASS_COMMAND' if code==0 else 'FAIL_ORIGINAL_COMMAND',actualExit=True,parentReaped=True,exitCode=code,elapsedSeconds=time.monotonic()-t,stdout=fact(out),stderr=fact(err),completedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    report.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));return code
if __name__=='__main__':sys.exit(main())
