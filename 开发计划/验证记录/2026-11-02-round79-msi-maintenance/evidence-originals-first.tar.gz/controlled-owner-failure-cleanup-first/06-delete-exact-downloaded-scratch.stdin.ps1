$c='{"root":"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-048185bd83264d1b8abf282244500f4b","nonce":"048185bd83264d1b8abf282244500f4b","sid":"S-1-5-21-3896111207-1867804362-1971593122-1001","spec":{"schemaVersion":1,"status":"PREPARED_NOT_RUN","nonce":"048185bd83264d1b8abf282244500f4b","rootName":"FutureClassroom-r79-early-terminal-048185bd83264d1b8abf282244500f4b","windowsRoot":"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-048185bd83264d1b8abf282244500f4b","effectDir":"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-048185bd83264d1b8abf282244500f4b\\effect\\","marker":"future-classroom-owned-r79-early-terminal-fixture/v1\n","expectedUserSid":"S-1-5-21-3896111207-1867804362-1971593122-1001","registryKey":"Software\\FutureClassroomTest\\Round79-048185bd83264d1b8abf282244500f4b","wholeSeconds":600,"nativeSeconds":120,"clientSeconds":120,"finallyReserveSeconds":180,"maximumHandles":64,"maximumOwners":8,"sourceGit":"c44906517fbc62233dca755d7225cea375264cbc","scope":"FRESH_INDEPENDENT_ORIGINAL_BEGIN_API_OWNER_NOT_PRODUCTION_AUTHORITY","sources":{"Owner.c":{"bytes":7788,"sha256":"af2479adb226bf69a4be750da22010f8ce71c446552cd6be8c01f23d07302270"},"Invoke-ControlledOwner.ps1":{"bytes":11905,"sha256":"90928aa3d7165b2061673312dbc03640e6f7dee219b02c3229d3d3a6040ed22d"},"Capture.cs":{"bytes":11335,"sha256":"cd2f47598504deef0a2721a6d61d3cf95a8e93aa6146e4fadeb8744f4e924580"},"EarlyTerminal.c":{"bytes":7254,"sha256":"dc8630277b69dfc4e7cf2ee3eebd476970ffc94138d7581be7934aed706ee9da"},"fixture-original.py":{"bytes":24097,"sha256":"6e1c8520ac799af57ed0b9a440cb3e855c6629cead01a4a6d18b1279a438360a"},"build.py":{"bytes":12426,"sha256":"24584adbdaae371189770d7243aa1578f52ccf45932876d30aa989905411a6eb"},"tools.json":{"bytes":1103,"sha256":"e885fe2e048642a88a8787e722c634ded7b9114f0f08faee3c288f390a50c98d"},"child-environment.json":{"bytes":121,"sha256":"67db97daf1ead75403164284a081b0b28887b699dc8d4e0c41b2cd92924e622f"}},"productCode":"{ED9C68A7-433A-404C-9997-A55EAA8A734F}","upgradeCode":"{0C7EF822-9E4D-49DF-921E-5FC518EEE533}","componentId":"{C41F8733-9A28-4F7E-8E95-F7F0C5740DED}"},"manifest":{"status":"PREPARED_RUNTIME_NOT_RUN","specSha256":"d283a211e4bce74dfb4a409b441cec952b101d2b3cb0ae9c34b4fad8f8dc7b13","buildReportSha256":"d4caef0f814a38f2e698af5454e515c9e76b4d87971b1fac098176c3e82110b8","files":[{"path":".owner","bytes":53,"sha256":"60f5bff57e6ca56a577cce6e1025aeb8d8087edcc6b9270282bfd362ab841350"},{"path":"Capture.cs","bytes":11335,"sha256":"cd2f47598504deef0a2721a6d61d3cf95a8e93aa6146e4fadeb8744f4e924580"},{"path":"EarlyTerminal.dll","bytes":219125,"sha256":"ebe0a2a1a3be5adc4c09f67eea1a0336cf05344a48f2ed21b61a4c2ff59701e2"},{"path":"Invoke-ControlledOwner.ps1","bytes":11905,"sha256":"90928aa3d7165b2061673312dbc03640e6f7dee219b02c3229d3d3a6040ed22d"},{"path":"Owner.exe","bytes":298613,"sha256":"46d8bbd86d7aa9f285976b0b3e8dc95d73d528eac36dc74f8c9b9afabaa9ee7e"},{"path":"build-report.json","bytes":68086,"sha256":"d4caef0f814a38f2e698af5454e515c9e76b4d87971b1fac098176c3e82110b8"},{"path":"early-fail.msi","bytes":232448,"sha256":"fe7755aac462dd71fb401d3a7bf09983225fb424a5d2d44af82e7a278627d15d"},{"path":"healthy.msi","bytes":232448,"sha256":"547f68ad8be99eb9a356e21b68f36bf88700f905abf9e60951f1c23550b33033"},{"path":"payload.txt","bytes":70,"sha256":"c3f7033489ab4a957f7bacb32e14d517193297c3d603de2cb99086ce25d20215"},{"path":"spec.json","bytes":2260,"sha256":"d283a211e4bce74dfb4a409b441cec952b101d2b3cb0ae9c34b4fad8f8dc7b13"}]},"paths":[],"inventory":{"directories":["compiler-temp","readback-compiler-temp"],"files":[{"path":".owner","sha256":"60f5bff57e6ca56a577cce6e1025aeb8d8087edcc6b9270282bfd362ab841350","bytes":53},{"path":"build-report.json","sha256":"d4caef0f814a38f2e698af5454e515c9e76b4d87971b1fac098176c3e82110b8","bytes":68086},{"path":"Capture.cs","sha256":"cd2f47598504deef0a2721a6d61d3cf95a8e93aa6146e4fadeb8744f4e924580","bytes":11335},{"path":"controlled-owner-result.json","sha256":"f14799006e07bebbfaa00d3e8997ca6373cec3f25aa3264b9e8bc0dbe184c185","bytes":25202},{"path":"early-fail-rollback-case.json","sha256":"38eff46b6ed16557da2236ec744d433ed87fe4b18f9dc0ee326b18e7ff472334","bytes":13662},{"path":"early-fail-rollback-msi.log","sha256":"50740aa888ad322ada44e453aec8af37ad9c6fbe4ddd689142afc40b5b1cfe49","bytes":3252},{"path":"early-fail-rollback.capture-ack","sha256":"1732f474d5ff82a8be38dc6f0aa7bd7ac684feb9a6355a0e0f8588f40616530d","bytes":32},{"path":"early-fail-rollback.jsonl","sha256":"0ceb9780380deaa9ce4fd4e77001dbfbffdf7a91674334538096c7de5d473f4a","bytes":2694},{"path":"early-fail.msi","sha256":"fe7755aac462dd71fb401d3a7bf09983225fb424a5d2d44af82e7a278627d15d","bytes":232448},{"path":"EarlyTerminal.dll","sha256":"ebe0a2a1a3be5adc4c09f67eea1a0336cf05344a48f2ed21b61a4c2ff59701e2","bytes":219125},{"path":"healthy.msi","sha256":"547f68ad8be99eb9a356e21b68f36bf88700f905abf9e60951f1c23550b33033","bytes":232448},{"path":"Invoke-ControlledOwner.ps1","sha256":"90928aa3d7165b2061673312dbc03640e6f7dee219b02c3229d3d3a6040ed22d","bytes":11905},{"path":"Owner.exe","sha256":"46d8bbd86d7aa9f285976b0b3e8dc95d73d528eac36dc74f8c9b9afabaa9ee7e","bytes":298613},{"path":"payload.txt","sha256":"c3f7033489ab4a957f7bacb32e14d517193297c3d603de2cb99086ce25d20215","bytes":70},{"path":"runtime-inputs.json","sha256":"bfab9f8735bf5bbe2cfac8297c7cce70d0d8cca06680c2395a3d9e2390c09728","bytes":1722},{"path":"spec.json","sha256":"d283a211e4bce74dfb4a409b441cec952b101d2b3cb0ae9c34b4fad8f8dc7b13","bytes":2260}]}}'|ConvertFrom-Json;
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Need([bool]$v,[string]$s){if(-not $v){throw $s}}
function Absent([string]$p){try{[void][IO.File]::GetAttributes($p);return $false}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-is [IO.FileNotFoundException] -or $e-is [IO.DirectoryNotFoundException]){return $true};throw}}
function Fact([string]$p){$a=[IO.File]::GetAttributes($p);Need (-not($a-band[IO.FileAttributes]::ReparsePoint) -and -not($a-band[IO.FileAttributes]::Directory)) 'REGULAR_NONREPARSE';$size=[long]([IO.FileInfo]::new($p).Length);Need ($size-ge 0 -and $size-le 16777216) 'FILE_BOUND';@{bytes=$size;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function Root-Check {
 Need ($PSVersionTable.PSVersion.Major-eq 5 -and [IntPtr]::Size-eq 8) 'DESKTOP_PS51_X64'
 Need ([IO.Path]::GetFullPath($c.root)-ceq $c.root -and [IO.Path]::GetFileName($c.root)-ceq ('FutureClassroom-r79-early-terminal-'+$c.nonce)) 'CLOSED_ROOT'
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent();try{Need ($identity.User.Value-ceq $c.sid) 'EXPECTED_CURRENT_USER'}finally{$identity.Dispose()}
 $cursor=$c.root;while($cursor){$a=[IO.File]::GetAttributes($cursor);Need (($a-band[IO.FileAttributes]::ReparsePoint)-eq 0 -and ($a-band[IO.FileAttributes]::Directory)-ne 0) 'DIRECTORY_NO_REPARSE';$cursor=[IO.Path]::GetDirectoryName($cursor)}
 Need ([IO.File]::ReadAllText((Join-Path $c.root '.owner'))-ceq "future-classroom-owned-r79-early-terminal-fixture/v1`n") 'OWNER_MARKER'
 $acl=[IO.Directory]::GetAccessControl($c.root);Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq $c.sid) 'PROTECTED_OWNER'
 $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($rules.Count-eq 2) 'TWO_ACES'
 $who=@($rules|ForEach-Object {$_.IdentityReference.Value}|Sort-Object -Unique);Need ($who.Count-eq 2 -and $c.sid-in $who -and 'S-1-5-18'-in $who) 'USER_AND_SYSTEM'
 foreach($r in $rules){Need ($r.AccessControlType-eq 'Allow' -and ($r.FileSystemRights-band [Security.AccessControl.FileSystemRights]::FullControl)-eq [Security.AccessControl.FileSystemRights]::FullControl) 'EXACT_ALLOW_FULLCONTROL'}
}

function Parent-State {
 $base=[Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryView]::Registry32);$key=$null
 try{
  $key=$base.OpenSubKey('Software\FutureClassroomTest',$false)
  if($null-eq $key){return @{status='KNOWN_ABSENT';key='Software\FutureClassroomTest';view='Registry32'}}
  $values=@($key.GetValueNames());$subkeys=@($key.GetSubKeyNames());Need ($values.Count-le 64 -and $subkeys.Count-le 128) 'PARENT_SNAPSHOT_BOUND'
  $acl=$key.GetAccessControl([Security.AccessControl.AccessControlSections]::Owner -bor [Security.AccessControl.AccessControlSections]::Access)
  @{status='PRESENT';key='Software\FutureClassroomTest';view='Registry32';ownerSid=$acl.GetOwner([Security.Principal.SecurityIdentifier]).Value;securityDescriptor=$acl.GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]::Owner -bor [Security.AccessControl.AccessControlSections]::Access);valueNames=@($values|Sort-Object);subkeyNames=@($subkeys|Sort-Object)}
 }finally{if($null-ne $key){$key.Dispose()};$base.Dispose()}
}

function Inventory {
 Root-Check;$files=@();$dirs=@();$total=0L;$queue=[Collections.Generic.Queue[string]]::new();$queue.Enqueue($c.root)
 while($queue.Count){$dir=$queue.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){
  $attrs=[IO.File]::GetAttributes($p);Need (($attrs-band[IO.FileAttributes]::ReparsePoint)-eq 0) 'INVENTORY_REPARSE'
  $rel=$p.Substring($c.root.Length+1).Replace('\','/')
  if(($attrs-band[IO.FileAttributes]::Directory)-ne 0){$top=($rel-split '/')[0];Need ($top-cin @('compiler-temp','readback-compiler-temp','effect')) 'ONLY_OWN_FIXTURE_SUBDIRECTORIES';$dirs+=$rel;$queue.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256};$total+=$f.bytes}
  Need ($files.Count-le 256 -and $dirs.Count-le 32 -and $total-le 67108864) 'RUNTIME_INVENTORY_BOUND'
 }}
 @{files=$files;directories=$dirs}
}

function Own-Zero {
 Root-Check;$owned=@();$foreign=0
 $rows=@(Get-CimInstance -ClassName Win32_Process -Filter "Name='Owner.exe' OR Name='csc.exe'")
 Need ($rows.Count-le 128) 'BOUNDED_OWNER_COMPILER_OBSERVATION'
 foreach($p in $rows){
  Need ($null-ne $p.ExecutablePath -and $null-ne $p.CommandLine) 'PROCESS_METADATA_UNKNOWN_RETAIN'
  $inside=$p.ExecutablePath.StartsWith($c.root+'\',[StringComparison]::OrdinalIgnoreCase) -or $p.CommandLine.IndexOf($c.root,[StringComparison]::OrdinalIgnoreCase)-ge 0
  if($inside){$owned+=@{pid=$p.ProcessId;image=$p.ExecutablePath;creation=$p.CreationDate}}else{$foreign++}
 }
 Need ($owned.Count-eq 0) 'OWN_OWNER_OR_COMPILER_STILL_LIVE_RETAIN'
 @{ownCandidates=$owned;foreignIgnoredCount=$foreign;status='ACTUAL_ZERO_EXACT_ROOT_OWNER_COMPILER'}
}
$zero=Own-Zero;
Root-Check;$now=Inventory
Need ($now.files.Count-eq $c.inventory.files.Count -and $now.directories.Count-eq $c.inventory.directories.Count) 'EXACT_INVENTORY_COUNTS'
foreach($f in $now.files){$old=@($c.inventory.files|Where-Object {$_.path-ceq $f.path});Need ($old.Count-eq 1 -and $old[0].bytes-eq $f.bytes -and $old[0].sha256-ceq $f.sha256) 'EXACT_DOWNLOADED_ORIGINAL_BYTES'}
foreach($d in $now.directories){Need ($d-cin $c.inventory.directories) 'EXACT_DIRECTORIES'}
foreach($f in $now.files){if($f.path-cne '.owner'){[IO.File]::Delete((Join-Path $c.root ($f.path.Replace('/','\'))))}}
foreach($d in @($now.directories|Sort-Object Length -Descending)){[IO.Directory]::Delete((Join-Path $c.root ($d.Replace('/','\'))),$false)}
[IO.File]::Delete((Join-Path $c.root '.owner'));[IO.Directory]::Delete($c.root,$false);Need (Absent $c.root) 'ROOT_KNOWN_ABSENT'
@{status='PASS_REMOVED_EXACT_FAILED_EXPERIMENT_SCRATCH';knownAbsent=$true;nonce=$c.nonce}|ConvertTo-Json -Compress
