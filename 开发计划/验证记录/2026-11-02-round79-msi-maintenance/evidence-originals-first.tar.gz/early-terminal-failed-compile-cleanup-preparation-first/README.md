# Exact capture and cleanup of the failed compile root

Default does not connect. Root alone may run:

```text
python3 cleanup-only.py --execute --output-dir /tmp/fc-round79-msi-maintenance/early-terminal-failed-compile-capture-first
```

The controller pins the original three FAIL reports, diagnostic SHA6c455ec3…
and immutable third transport source. The diagnostic's original stdout contains
the exact nine files/one empty csc-owned-temp directory and raw original
receipt/stdout/stderr. Compiler exit stays UNKNOWN, receipt stays FAIL, EXE is
never run, and no compile success is claimed from its existence.

Before capture and again before deletion it verifies actual protected owner,
two ACEs, nonreparse ancestry, original nine path/bytes/SHA membership and the
one empty compiler directory. It performs the same bounded read-only scoped
csc/PositiveControl candidate check; any active or unknown own candidate blocks
cleanup. Original physical Wait success is justified only by the frozen source
path reaching CSC_ACTUAL_FAILURE after WaitForExit, not an invented exit0.

Every original file is downloaded and SHA-checked; the original receipt bytes
must match the diagnostic and still contain actualExit:null. Only complete
capture plus a second unchanged inventory and zero own candidates permits
empty-only deletion of this exact nonce root, owner marker last. No compiler,
helper, MSI, registry, service, account or system cache is executed/mutated.
All old raw failures remain unchanged outside this root. Unknown or mismatched
data retains the remaining root. Only this local SSH/SCP client may be reaped
on timeout; remote return then remains unknown.

This is cleanup permission for never-executed test artifacts, not a successful
compiler qualification or a production owner-release path. Budget is one fixed
120s capture/transport clock; future MSI600/client120/reserve180 is unchanged.
