#!/usr/bin/env python3
"""Exact failed compiler artifact capture/cleanup only. Default never connects.
Original compiler exit remains UNKNOWN. Never execute EXE, compiler or MSI.
"""
import argparse,base64,datetime,hashlib,json
from pathlib import Path
import runpy,subprocess,time
E=Path('/tmp/fc-round79-msi-maintenance')
BASE=E/'early-terminal-transport-preparation-third/compile-only.py'
BASE_SHA='800a8bcd78385c5142946d4eee7d95a3cb82f4ecf7207f6d9e116baaae478895'
PINS={
 'early-terminal-compile-first/compile-operation.json':'5fcf342bf876a6b89af94341cd5a8903ce92a18626d47d8318ffc8f09ffb7947',
 'early-terminal-compile-second/compile-operation.json':'68e9a4cd46297532afdffc87aafaef6585c02f5c7830996e93c6504acb02c681',
 'early-terminal-compile-third/compile-operation.json':'b99460d9231a6004373b3d6622672fc725c527e61e86721f3f87bd8ed92af48e',
 'root-early-compile-failure-diagnostic-first.json':'6c455ec32c09911ba655a5019ca415fe321c66be93d2e963f5dbc2b636abb009'}
def need(v,s):
 if not v:raise ValueError(s)
def sha(b):return hashlib.sha256(b).hexdigest()
def fact(p):
 need(p.is_file() and not p.is_symlink(),'REGULAR_ORIGINAL');b=p.read_bytes();return {'bytes':len(b),'sha256':sha(b)}
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--output-dir',type=Path);a=p.parse_args()
 if not a.execute:print(json.dumps({'status':'PREPARED_FAILED_COMPILE_CAPTURE_CLEANUP_NOT_RUN','compilerExit':'UNKNOWN_NOT_UPGRADED','windows':'NOT_CONTACTED','EXE':'NOT_RUN','MSI':'NOT_RUN'}));return 0
 need(a.output_dir and a.output_dir.is_absolute() and a.output_dir.parent==E and a.output_dir.resolve()==a.output_dir and not a.output_dir.exists(),'NEW_DIRECT_OWNED_OUTPUT')
 need((E/'.owner').read_bytes()==b'future-classroom-owned-r79-msi-maintenance/v1\n','R79_OWNER');need(fact(BASE)['sha256']==BASE_SHA,'EXACT_THIRD_BASE')
 originals={}
 for name,pin in PINS.items():
  f=E/name;need(fact(f)['sha256']==pin,'EXACT_ORIGINAL_REPORT');originals[name]=json.loads(f.read_text())
 old=originals['early-terminal-compile-third/compile-operation.json'];diag=originals['root-early-compile-failure-diagnostic-first.json']
 need(old['status']=='FAIL_COMPILE_ONLY_RETAIN_ORIGINALS' and old['remoteReturnUnknown'] is False and old['remoteMsiStarted'] is False and old['remoteHelperExecuted'] is False,'ORIGINAL_COMPILER_ONLY_FAILURE')
 need(old['native']['error']['message']=='CSC_ACTUAL_FAILURE' and old['native']['receipt'] is None,'SOURCE_PATH_WAIT_RETURNED_BUT_EXIT_NOT_CAPTURED')
 need([r['name'] for r in old['operations']]==['00-recover-exact-precompile-root','03-original-compile-parent'] and [r['actualLocalExit'] for r in old['operations']]==[0,1] and all(r['remoteReturnKnown'] is True and r['localParentReaped'] is True and r['timedOut'] is False for r in old['operations']),'THIRD_ORIGINAL_PARENTS_NATURAL_0_1')
 need(diag['actualReturnCode']==0,'ACTUAL_READONLY_DIAGNOSTIC_PARENT0')
 raw=base64.b64decode(diag['stdoutBase64'],validate=True);native=json.loads(raw.decode('utf-8-sig'));inventory=native['inventory']
 need(native['scope']=='READONLY_OWN_COMPILE_FAILURE_ORIGINALS' and set(native['contents'])=={'positive-compile-receipt.json','csc.stdout.log','csc.stderr.log'},'EXACT_ORIGINAL_DIAGNOSTIC_CONTENTS')
 receipt_bytes=base64.b64decode(native['contents']['positive-compile-receipt.json'],validate=True);receipt=json.loads(receipt_bytes.decode('utf-8-sig'))
 need(receipt['status']=='FAIL_COMPILE_ONLY' and receipt['actualExit'] is None and receipt['exe'] is None and receipt['executed'] is False,'ORIGINAL_EXIT_UNKNOWN_RETAINED')
 need(native['contents']['csc.stdout.log']==native['contents']['csc.stderr.log']=='','ACTUAL_EMPTY_COMPILER_LOGS_RETAINED')
 base=runpy.run_path(str(BASE));base['validate_inventory'](inventory)
 expected={'PositiveControl.cs','Compile-PositiveControl.ps1','spec.json','compile-inputs.json','.owner','PositiveControl.exe','positive-compile-receipt.json','csc.stdout.log','csc.stderr.log'}
 need(len(inventory['files'])==9 and {r['path'] for r in inventory['files']}==expected and inventory['directories']==['csc-owned-temp'],'EXACT_NINE_ORIGINAL_FILES_ONE_EMPTY_COMPILER_DIR')
 by={r['path']:r for r in inventory['files']};need(fact(E/'early-terminal-inputs-first/spec.json')['sha256']==by['spec.json']['sha256'] and sha(receipt_bytes)==by['positive-compile-receipt.json']['sha256'],'ORIGINAL_SPEC_RECEIPT_RAW_BYTES')
 out=a.output_dir;out.mkdir();(out/'.owner').write_text('future-classroom-owned-r79-failed-compile-capture-result/v1\n');report={'status':'RUNNING_CAPTURE_ONLY','compilerExit':'UNKNOWN_NOT_UPGRADED','originals':PINS,'base':{'path':str(BASE),**fact(BASE)},'operations':[],'cleanup':'NOT_RUN','originalCompilerPid':receipt['compilerPid'],'originalCompilerCreationFiletime':receipt['compilerCreationFiletime'],'neverExecutedHelperOrMsi':True}
 rp=out/'cleanup-operation.json';start=time.monotonic();c={'root':old['remoteRoot'],'nonce':old['nonce'],'sid':base['SID'],'originalInventory':inventory};report['remoteRoot']=c['root']
 def save():rp.write_text(json.dumps(report,indent=2)+'\n')
 def call(label,args,feed=None,limit=15):
  left=120-(time.monotonic()-start);need(left>0,'ORIGINAL_120S_CAPTURE_CLOCK');p=None;stdout=b'';stderr=b'';code=None;timed=False
  try:
   p=subprocess.Popen(args,stdin=subprocess.PIPE if feed is not None else subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   try:stdout,stderr=p.communicate(feed,timeout=min(limit,left))
   except subprocess.TimeoutExpired:timed=True;p.kill();stdout,stderr=p.communicate()
   code=p.returncode
  finally:
   row={'label':label,'argv':args,'actualLocalExit':code,'localParentReaped':bool(p and p.poll() is not None),'timedOut':timed,'remoteReturnKnown':code is not None and not timed}
   for suffix,b in [('stdin.ps1',feed),('stdout.log',stdout),('stderr.log',stderr)]:
    if b is not None:q=out/(label+'.'+suffix);q.write_bytes(b);row[suffix]={'path':q.name,**fact(q)}
   report['operations'].append(row);save()
  need(code==0 and not timed,'REMOTE_FAILED_OR_UNKNOWN_RETAIN');return stdout
 def ps(label,body,cfg=None):
  cc=c if cfg is None else cfg;feed=("$c='"+json.dumps(cc,separators=(',',':')).replace("'","''")+"'|ConvertFrom-Json;"+base['COMMON']+body).encode()
  cmd='powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand '+base64.b64encode(base['BOOT'].encode('utf-16-le')).decode()
  return call(label,['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8',base['HOST'],cmd],feed)
 save()
 try:
  # Reuse the already reviewed read-only scoped candidate check, changing only
  # exact membership counts/names; it never invokes the compiler.
  check=base['RECOVER'].replace('$inventory.files.Count-eq 5 -and $inventory.directories.Count-eq 0',"$inventory.files.Count-eq 9 -and $inventory.directories.Count-eq 1 -and $inventory.directories[0]-ceq 'csc-owned-temp'").replace('EXACT_FIVE_ORIGINAL_PRECOMPILE_MEMBERS','EXACT_NINE_FAILED_COMPILE_ORIGINALS').replace('PASS_EXACT_FIVE_PRECOMPILE_ORIGINALS_ZERO_OWN_COMPILER_HELPER','PASS_EXACT_NINE_FAILED_COMPILE_ORIGINALS_ZERO_OWN_COMPILER_HELPER')
  actual=json.loads(ps('01-original-nine-readonly-zero-process',check));need(actual['status']=='PASS_EXACT_NINE_FAILED_COMPILE_ORIGINALS_ZERO_OWN_COMPILER_HELPER' and base['inventory_identity'](actual['inventory'])==base['inventory_identity'](inventory) and actual['ownCandidates']==[],'ACTUAL_ORIGINAL_NINE_ZERO_OWN_COMPILER_HELPER')
  report['before']=actual;download=out/'download';download.mkdir();(download/'csc-owned-temp').mkdir()
  for i,row in enumerate(inventory['files']):
   remote=base['HOST']+':'+(c['root']+'\\'+row['path']).replace('\\','/');target=download/row['path'];call('02-download-'+str(i),['scp','-q','-o','BatchMode=yes','-o','ConnectTimeout=8',remote,str(target)]);need(fact(target)=={k:row[k] for k in ('bytes','sha256')},'EXACT_ORIGINAL_DOWNLOADED_BYTES')
  need((download/'positive-compile-receipt.json').read_bytes()==receipt_bytes,'ORIGINAL_RECEIPT_NOT_REWRITTEN')
  need(json.loads((download/'positive-compile-receipt.json').read_text())['actualExit'] is None,'EXIT_STILL_UNKNOWN')
  after=json.loads(ps('03-second-nine-readonly-zero-process',check));need(base['inventory_identity'](after['inventory'])==base['inventory_identity'](inventory) and after['ownCandidates']==[],'ORIGINAL_NINE_STABLE_AND_STILL_ZERO_OWN_PROCESSES')
  report['downloadVerified']=True;report['after']=after
  clean=json.loads(ps('04-delete-only-nine-downloaded-originals',base['DELETE'],{**c,'inventory':inventory}));need(clean['status']=='PASS_REMOVED_EXACT_DOWNLOADED_COMPILE_ROOT' and clean['knownAbsent'] is True,'EXACT_OWNED_ROOT_REMOVED')
  report['cleanup']=clean;report['status']='PASS_EXACT_FAILED_COMPILER_ORIGINAL_CAPTURE_AND_ROOT_CLEANUP_EXIT_UNKNOWN_NOT_COMPILE_PASS'
 except Exception as error:report.update(status='FAIL_CAPTURE_RETAIN_REMAINING_ORIGINALS',errorType=type(error).__name__,error=str(error))
 finally:report['elapsedSeconds']=time.monotonic()-start;save()
 print(json.dumps({'status':report['status'],'report':str(rp),'sha256':fact(rp)['sha256'],'compilerExit':'UNKNOWN_NOT_UPGRADED'}));return 0 if report['status'].startswith('PASS_') else 1
if __name__=='__main__':raise SystemExit(main())
