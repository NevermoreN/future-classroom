$c='{"nonce":"db6b185d70ec9aa67adf8fee409203c7","root":"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-db6b185d70ec9aa67adf8fee409203c7","sid":"S-1-5-21-3896111207-1867804362-1971593122-1001","specSha256":"46eab56eb0334c8a27cbfa96f4686c305ba0266c4568a43453ea086ba9cd299b","files":[{"path":"Compile-PositiveControl.ps1","bytes":3747,"sha256":"f98e41ce55d5c0e47a22fb25e49676a076b7ccf5e29af2f3311677fa9bbfc69e"},{"path":"PositiveControl.cs","bytes":16463,"sha256":"ae0a1c90e5d551cd824eef0cc1b7afdf0b92174b091b7b68bbea02bb21796e04"},{"path":"compile-inputs.json","bytes":862,"sha256":"6f7a6353ec039630261d75a28a01deb0719d7284b837ef0a4b4323f6f643b7a0"},{"path":"spec.json","bytes":2045,"sha256":"46eab56eb0334c8a27cbfa96f4686c305ba0266c4568a43453ea086ba9cd299b"}],"originalInventory":{"files":[{"path":".owner","bytes":53,"sha256":"60f5bff57e6ca56a577cce6e1025aeb8d8087edcc6b9270282bfd362ab841350"},{"path":"Compile-PositiveControl.ps1","bytes":3747,"sha256":"f98e41ce55d5c0e47a22fb25e49676a076b7ccf5e29af2f3311677fa9bbfc69e"},{"path":"PositiveControl.cs","bytes":16463,"sha256":"ae0a1c90e5d551cd824eef0cc1b7afdf0b92174b091b7b68bbea02bb21796e04"},{"path":"compile-inputs.json","bytes":862,"sha256":"6f7a6353ec039630261d75a28a01deb0719d7284b837ef0a4b4323f6f643b7a0"},{"path":"spec.json","bytes":2045,"sha256":"46eab56eb0334c8a27cbfa96f4686c305ba0266c4568a43453ea086ba9cd299b"}],"directories":[]}}'|ConvertFrom-Json;
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Need([bool]$v,[string]$s){if(-not $v){throw $s}}
function Absent([string]$p){try{[void][IO.File]::GetAttributes($p);return $false}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-is [IO.FileNotFoundException] -or $e-is [IO.DirectoryNotFoundException]){return $true};throw}}
function Fact([string]$p){$a=[IO.File]::GetAttributes($p);Need (-not($a-band[IO.FileAttributes]::ReparsePoint) -and -not($a-band[IO.FileAttributes]::Directory)) 'REGULAR_NONREPARSE';$size=[long]([IO.FileInfo]::new($p).Length);Need ($size-ge 0 -and $size-le 16777216) 'FILE_BOUND';@{bytes=$size;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function Root-Check {
 Need ($PSVersionTable.PSVersion.Major-eq 5 -and [IntPtr]::Size-eq 8) 'DESKTOP_PS51_X64'
 Need ([IO.Path]::GetFullPath($c.root)-ceq $c.root -and [IO.Path]::GetFileName($c.root)-ceq ('FutureClassroom-r79-early-terminal-'+$c.nonce)) 'CLOSED_ROOT'
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent();try{Need ($identity.User.Value-ceq $c.sid) 'EXPECTED_CURRENT_USER'}finally{$identity.Dispose()}
 $cursor=$c.root;while($cursor){$a=[IO.File]::GetAttributes($cursor);Need (($a-band[IO.FileAttributes]::ReparsePoint)-eq 0 -and ($a-band[IO.FileAttributes]::Directory)-ne 0) 'DIRECTORY_NO_REPARSE';$cursor=[IO.Path]::GetDirectoryName($cursor)}
 Need ([IO.File]::ReadAllText((Join-Path $c.root '.owner'))-ceq "future-classroom-owned-r79-early-terminal-fixture/v1`n") 'OWNER_MARKER'
 $acl=[IO.Directory]::GetAccessControl($c.root);Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq $c.sid) 'PROTECTED_OWNER'
 $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($rules.Count-eq 2) 'TWO_ACES'
 $who=@($rules|ForEach-Object {$_.IdentityReference.Value}|Sort-Object -Unique);Need ($who.Count-eq 2 -and $c.sid-in $who -and 'S-1-5-18'-in $who) 'USER_AND_SYSTEM'
 foreach($r in $rules){Need ($r.AccessControlType-eq 'Allow' -and ($r.FileSystemRights-band [Security.AccessControl.FileSystemRights]::FullControl)-eq [Security.AccessControl.FileSystemRights]::FullControl) 'EXACT_ALLOW_FULLCONTROL'}
}
function Inventory {
 Root-Check;$files=@();$dirs=@();$total=0L;$queue=[Collections.Generic.Queue[string]]::new();$queue.Enqueue($c.root)
 while($queue.Count){$dir=$queue.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){$a=[IO.File]::GetAttributes($p);Need (($a-band[IO.FileAttributes]::ReparsePoint)-eq 0) 'INVENTORY_REPARSE';$rel=$p.Substring($c.root.Length+1).Replace('\','/');if(($a-band[IO.FileAttributes]::Directory)-ne 0){Need ($rel-ceq 'csc-owned-temp' -or $rel.StartsWith('csc-owned-temp/')) 'ONLY_OWN_COMPILER_TEMP_SUBDIRECTORIES';$dirs+=$rel;$queue.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256};$total+=$f.bytes};Need ($files.Count-le 64 -and $dirs.Count-le 16 -and $total-le 33554432) 'INVENTORY_BOUND'}}
 @{files=@($files|Sort-Object path);directories=@($dirs|Sort-Object)}
}

Root-Check
$inventory=Inventory
Need ($inventory.files.Count-eq 5 -and $inventory.directories.Count-eq 0) 'EXACT_FIVE_ORIGINAL_PRECOMPILE_MEMBERS'
foreach($expected in $c.originalInventory.files){$actual=@($inventory.files|Where-Object {$_.path-ceq $expected.path});Need ($actual.Count-eq 1 -and $actual[0].bytes-eq $expected.bytes -and $actual[0].sha256-ceq $expected.sha256) 'ORIGINAL_FIVE_BYTES_UNCHANGED'}
# This is a finite, read-only negative recovery check, not process identity
# authority for a production role. Do not emit other users' command lines.
$candidates=@();$foreign=0
$rows=@(Get-CimInstance -ClassName Win32_Process -Filter "Name='csc.exe' OR Name='PositiveControl.exe'")
Need ($rows.Count-le 64) 'BOUNDED_COMPILER_HELPER_PROBE'
foreach($row in $rows){
 Need ($null-ne $row.ExecutablePath -and $null-ne $row.CommandLine) 'CANDIDATE_METADATA_UNKNOWN_RETAIN'
 $inRoot=$row.ExecutablePath.StartsWith($c.root+'\',[StringComparison]::OrdinalIgnoreCase) -or $row.CommandLine.IndexOf($c.root,[StringComparison]::OrdinalIgnoreCase)-ge 0
 if($inRoot){$candidates+=@{pid=$row.ProcessId;image=$row.ExecutablePath;creation=$row.CreationDate}}else{$foreign++}
}
Need ($candidates.Count-eq 0) 'ORIGINAL_PRECOMPILE_OWNED_PROCESS_NOT_ABSENT'
@{status='PASS_EXACT_FIVE_PRECOMPILE_ORIGINALS_ZERO_OWN_COMPILER_HELPER';inventory=$inventory;ownCandidates=$candidates;foreignIgnoredCount=$foreign;nonce=$c.nonce;root=$c.root;recreated=$false;overwritten=$false}|ConvertTo-Json -Depth 20 -Compress
