using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

internal static class Program
{
    const string Marker = "future-classroom-owned-r79-early-terminal-fixture/v1\n";
    const uint Timeout = 258;
    static readonly long Began = Stopwatch.GetTimestamp();
    static readonly Encoding Utf8 = new UTF8Encoding(false, true);
    static readonly List<IntPtr> Handles = new List<IntPtr>();
    static string Root, Nonce, Role;
    static Fact Self;
    static Timer Watchdog;
    static int Finished;
    static bool CloseFailed;
    static long Deadline;

    [DllImport("kernel32.dll", SetLastError=true)] static extern IntPtr GetCurrentProcess();
    [DllImport("kernel32.dll", SetLastError=true)] static extern uint GetProcessId(IntPtr process);
    [DllImport("kernel32.dll", SetLastError=true)] static extern bool GetProcessTimes(IntPtr p, out long creation, out long exit, out long kernel, out long user);
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, ExactSpelling=true, SetLastError=true)] static extern bool QueryFullProcessImageNameW(IntPtr p, uint flags, StringBuilder name, ref uint size);
    [DllImport("kernel32.dll", SetLastError=true)] static extern uint WaitForSingleObject(IntPtr h, uint milliseconds);
    [DllImport("kernel32.dll", SetLastError=true)] static extern bool GetExitCodeProcess(IntPtr h, out uint code);
    [DllImport("kernel32.dll", SetLastError=true)] static extern bool CloseHandle(IntPtr h);
    [DllImport("advapi32.dll", SetLastError=true)] static extern bool OpenProcessToken(IntPtr p, uint access, out IntPtr token);
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, ExactSpelling=true, SetLastError=true)] static extern IntPtr CreateFileW(string path, uint access, uint share, IntPtr security, uint disposition, uint flags, IntPtr template);
    [StructLayout(LayoutKind.Sequential, Pack=4)] struct FileInfo { internal uint Attributes; internal long Creation, Access, Write; internal uint Volume, SizeHigh, SizeLow, Links, IndexHigh, IndexLow; }
    [DllImport("kernel32.dll", SetLastError=true)] static extern bool GetFileInformationByHandle(IntPtr h, out FileInfo info);
    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)] struct StartupInfo
    {
        internal uint Size;
        internal IntPtr Reserved, Desktop, Title;
        internal uint X, Y, XSize, YSize, XCountChars, YCountChars, FillAttribute, Flags;
        internal ushort ShowWindow, ReservedBytes;
        internal IntPtr ReservedData, StdInput, StdOutput, StdError;
    }
    [StructLayout(LayoutKind.Sequential)] struct ProcessInformation
    { internal IntPtr Process, Thread; internal uint ProcessId, ThreadId; }
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, ExactSpelling=true, SetLastError=true)]
    static extern bool CreateProcessW(string application, StringBuilder commandLine, IntPtr processSecurity, IntPtr threadSecurity, bool inheritHandles, uint flags, IntPtr environment, string currentDirectory, ref StartupInfo startup, out ProcessInformation information);
    [DllImport("msi.dll", ExactSpelling=true)] static extern uint MsiJoinTransaction(uint transaction, uint attributes, out IntPtr changed);
    [DllImport("msi.dll", ExactSpelling=true)] static extern uint MsiEndTransaction(uint state);

    sealed class Fact
    {
        internal uint Pid;
        internal long Creation;
        internal string Image, Sha, Sid;
    }
    static void Need(bool ok, string reason) { if (!ok) throw new InvalidOperationException(reason); }
    static void Win(bool ok, string operation) { if (!ok) throw new Win32Exception(Marshal.GetLastWin32Error(), operation); }
    static IntPtr Track(IntPtr h) { Need(h != IntPtr.Zero && h != new IntPtr(-1), "INVALID_HANDLE"); Handles.Add(h); return h; }
    static void Close(IntPtr h)
    {
        Need(Handles.Remove(h), "HANDLE_NOT_OWNED");
        if (!CloseHandle(h)) { CloseFailed = true; throw new Win32Exception(Marshal.GetLastWin32Error(), "CloseHandle"); }
    }
    static string Q(string s)
    {
        StringBuilder b = new StringBuilder("\"");
        foreach (char c in s) { if (c == '"' || c == '\\') b.Append('\\').Append(c); else if (c < 32) b.Append("\\u").Append(((int)c).ToString("x4")); else b.Append(c); }
        return b.Append('"').ToString();
    }
    static string N(long n) { return n.ToString(CultureInfo.InvariantCulture); }
    static string Sha(string path)
    {
        using (FileStream f = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read | FileShare.Delete))
        using (SHA256 s = SHA256.Create()) return BitConverter.ToString(s.ComputeHash(f)).Replace("-", "").ToLowerInvariant();
    }
    static Fact Inspect(IntPtr h)
    {
        Fact f = new Fact(); f.Pid = GetProcessId(h); Need(f.Pid != 0, "GetProcessId");
        long exit, kernel, user; Win(GetProcessTimes(h, out f.Creation, out exit, out kernel, out user), "GetProcessTimes");
        StringBuilder path = new StringBuilder(32768); uint length = (uint)path.Capacity;
        Win(QueryFullProcessImageNameW(h, 0, path, ref length), "QueryFullProcessImageNameW");
        f.Image = path.ToString(); Need(Path.IsPathRooted(f.Image) && length > 0, "IMAGE_PATH"); f.Sha = Sha(f.Image);
        IntPtr token; Win(OpenProcessToken(h, 8, out token), "OpenProcessToken"); Track(token);
        try { using (WindowsIdentity identity = new WindowsIdentity(token)) { f.Sid = identity.User.Value; } } finally { Close(token); }
        return f;
    }
    static string Identity(string role, Fact f, string extra)
    {
        return "{\"schemaVersion\":1,\"role\":" + Q(role) + ",\"nonce\":" + Q(Nonce) + ",\"pid\":" + N(f.Pid) + ",\"creationFiletime\":" + N(f.Creation) + ",\"imagePath\":" + Q(f.Image) + ",\"imageSha256\":" + Q(f.Sha) + ",\"sid\":" + Q(f.Sid) + ",\"pointerBytes\":4" + extra + "}\n";
    }
    static byte[] Publish(string leaf, string text)
    {
        byte[] bytes = Utf8.GetBytes(text); PublishBytes(leaf, bytes); return bytes;
    }
    static void PublishBytes(string leaf, byte[] bytes)
    {
        Need(leaf.IndexOfAny(new char[] {'\\','/'}) < 0, "LEAF");
        string final = Path.Combine(Root, leaf), pending = final + ".pending-" + Role;
        using (FileStream f = new FileStream(pending, FileMode.CreateNew, FileAccess.Write, FileShare.None)) { f.Write(bytes, 0, bytes.Length); f.Flush(true); }
        File.Move(pending, final);
    }
    static byte[] Read(string leaf)
    {
        string path = Path.Combine(Root, leaf); Need((File.GetAttributes(path) & FileAttributes.ReparsePoint) == 0, "FILE_REPARSE");
        using (FileStream f = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
        { FileInfo info; Win(GetFileInformationByHandle(f.SafeFileHandle.DangerousGetHandle(), out info), "GetFileInformationByHandle(file)"); Need((info.Attributes & 0x410)==0 && info.Links==1,"FILE_REPARSE_OR_HARDLINK"); Need(f.Length > 0 && f.Length <= 16384, "FILE_SIZE"); byte[] b = new byte[(int)f.Length]; int n = 0; while (n < b.Length) { int r = f.Read(b, n, b.Length-n); Need(r > 0, "SHORT_READ"); n += r; } return b; }
    }
    static bool Equal(byte[] a, byte[] b) { if (a.Length != b.Length) return false; for (int i=0;i<a.Length;i++) if (a[i]!=b[i]) return false; return true; }
    static void Before(long deadline) { Need(Stopwatch.GetTimestamp() < deadline, "DEADLINE"); }
    static byte[] Await(string leaf, long deadline)
    {
        for (;;) { Before(deadline); if (File.Exists(Path.Combine(Root, leaf))) return Read(leaf); Thread.Sleep(5); }
    }
    static void Ack(string identityLeaf, string ackLeaf, long deadline)
    {
        byte[] own = Publish(identityLeaf, Identity(Role, Self, ""));
        Need(Equal(own, Await(ackLeaf, deadline)), "ORIGINAL_CAPTURE_ACK_BYTES");
    }
    static void ValidateRoot()
    {
        Need(Path.IsPathRooted(Root) && Path.GetFullPath(Root) == Root && Path.GetFileName(Root) == "FutureClassroom-r79-early-terminal-" + Nonce, "ROOT_PATH");
        DirectoryInfo d = new DirectoryInfo(Root);
        while (d != null)
        {
            Need((d.Attributes & FileAttributes.ReparsePoint) == 0, "DIRECTORY_REPARSE");
            IntPtr directory = Track(CreateFileW(d.FullName, 0x80, 3, IntPtr.Zero, 3, 0x02200000, IntPtr.Zero));
            FileInfo information; Win(GetFileInformationByHandle(directory, out information), "GetFileInformationByHandle(directory)");
            Need((information.Attributes & 0x410) == 0x10, "PINNED_DIRECTORY_REPARSE"); d = d.Parent;
        }
        DirectorySecurity acl = Directory.GetAccessControl(Root, AccessControlSections.Owner | AccessControlSections.Access);
        string sid; using (WindowsIdentity current = WindowsIdentity.GetCurrent()) { sid = current.User.Value; }
        Need(acl.GetOwner(typeof(SecurityIdentifier)).Value == sid && acl.AreAccessRulesProtected, "ROOT_OWNER_ACL");
        bool user = false, system = false; int aceCount = 0;
        foreach (FileSystemAccessRule rule in acl.GetAccessRules(true, true, typeof(SecurityIdentifier)))
        {
            aceCount++; string who = rule.IdentityReference.Value;
            Need(rule.AccessControlType == AccessControlType.Allow && (who == sid || who == "S-1-5-18"), "ROOT_DACL_PRINCIPAL");
            Need((rule.FileSystemRights & FileSystemRights.FullControl) == FileSystemRights.FullControl, "ROOT_DACL_RIGHTS");
            if (who == sid) user = true; if (who == "S-1-5-18") system = true;
        }
        Need(user && system && aceCount==2 && Utf8.GetString(Read(".owner")) == Marker, "ROOT_MARKER_AND_TWO_ACES");
        Self = Inspect(GetCurrentProcess()); Need(Self.Sid == sid, "CURRENT_SID");
    }
    static void Fail(Exception error)
    {
        try { if (Root != null && Self != null) Publish("FAIL-"+Role+".json", Identity(Role, Self, ",\"status\":\"FAIL\",\"reason\":"+Q(error.Message)+",\"hresult\":"+N(error.HResult)+",\"elapsedMilliseconds\":"+N((Stopwatch.GetTimestamp()-Began)*1000/Stopwatch.Frequency))); } catch { }
    }
    static void Arm(int seconds)
    {
        Deadline = checked(Began + Stopwatch.Frequency * seconds); Before(Deadline);
        long left = (Deadline - Stopwatch.GetTimestamp()) * 1000 / Stopwatch.Frequency;
        Watchdog = new Timer(delegate { if (Interlocked.Exchange(ref Finished, 1) == 0) { Fail(new TimeoutException("ORIGINAL_PROCESS_BUDGET")); Environment.Exit(1603); } }, null, Math.Max(1, left), System.Threading.Timeout.Infinite);
    }
    static string Argv(uint transaction, string role)
    {
        return "[" + Q(N(transaction)) + "," + Q(role) + "," + Q(Root) + "," + Q(Nonce) + "]";
    }
    static string CommandArgument(string text)
    {
        Need(text.Length>0 && text.IndexOfAny(new char[] {'"', '\r', '\n'})<0 && !text.EndsWith("\\",StringComparison.Ordinal),"COMMAND_ARGUMENT");
        return "\""+text+"\"";
    }
    static void Supervisor(uint transaction)
    {
        Ack("supervisor-identity.json", ".supervisor-original-captured", Math.Min(Deadline,Began+Stopwatch.Frequency*2)); Before(Deadline);
        string childArgs = Argv(transaction,"guardian-child");
        string command = CommandArgument(Self.Image)+" "+N(transaction)+" guardian-child "+CommandArgument(Root)+" "+Nonce;
        StartupInfo startup = new StartupInfo(); startup.Size=(uint)Marshal.SizeOf(typeof(StartupInfo));
        ProcessInformation spawned;
        bool created=CreateProcessW(Self.Image,new StringBuilder(command),IntPtr.Zero,IntPtr.Zero,false,0x08000000,IntPtr.Zero,Root,ref startup,out spawned);
        int error=created?0:Marshal.GetLastWin32Error();
        if(created) { Track(spawned.Process); Track(spawned.Thread); }
        Publish("CREATE_PROCESS_RETURN.json",Identity(Role,Self,",\"transaction\":"+N(transaction)+",\"created\":"+(created?"true":"false")+",\"lastError\":"+N(error)+",\"childPid\":"+N(spawned.ProcessId)+",\"childThreadId\":"+N(spawned.ThreadId)+",\"applicationName\":"+Q(Self.Image)+",\"commandLine\":"+Q(command)+",\"childArgv\":"+childArgs));
        Need(created,"CreateProcessW");
        Close(spawned.Thread); Publish("CHILD_THREAD_CLOSED.json",Identity(Role,Self,",\"childThreadId\":"+N(spawned.ThreadId)+",\"checkedClose\":true"));
        byte[] entry=Await("CHILD_ENTER.json",Deadline);
        Fact child=Inspect(spawned.Process);
        Need(child.Pid==spawned.ProcessId && child.Creation>0 && child.Pid!=Self.Pid && child.Sid==Self.Sid && child.Sha==Self.Sha && String.Equals(child.Image,Self.Image,StringComparison.OrdinalIgnoreCase),"CHILD_ORIGINAL_IDENTITY");
        Need(WaitForSingleObject(spawned.Process,0)==Timeout,"CHILD_NOT_LIVE");
        Need(Equal(entry,Utf8.GetBytes(Identity("guardian-child",child,",\"transaction\":"+N(transaction)+",\"argv\":"+childArgs))),"CHILD_ENTER_EXACT");
        PublishBytes(".supervisor-child-original-captured",entry);
        for(;;) { Before(Deadline); uint wait=WaitForSingleObject(spawned.Process,10); if(wait==0)break; Need(wait==Timeout,"CHILD_WAIT"); }
        uint exit; Win(GetExitCodeProcess(spawned.Process,out exit),"GetExitCodeProcess");
        Publish("CHILD_EXIT_RETURN.json",Identity(Role,Self,",\"childPid\":"+N(child.Pid)+",\"childCreationFiletime\":"+N(child.Creation)+",\"actualExitCode\":"+N(exit)));
        Close(spawned.Process); Publish("CHILD_PROCESS_CLOSED.json",Identity(Role,Self,",\"childPid\":"+N(child.Pid)+",\"checkedClose\":true"));
        Need(exit==0,"CHILD_ACTUAL_EXIT_NONZERO"); Before(Deadline);
        Publish("SUPERVISOR_DONE.json",Identity(Role,Self,",\"status\":\"PASS_ORIGINAL_CHILD_EXIT0_AND_CHECKED_CLOSE\""));
    }
    static void Guardian(uint transaction)
    {
        byte[] entry=Publish("CHILD_ENTER.json",Identity(Role,Self,",\"transaction\":"+N(transaction)+",\"argv\":"+Argv(transaction,Role)));
        Need(Equal(entry,Await(".supervisor-child-original-captured",Deadline)),"SUPERVISOR_ORIGINAL_CAPTURE_ACK_BYTES");
        IntPtr changed; uint joined=MsiJoinTransaction(transaction,0,out changed);
        if(changed!=IntPtr.Zero && changed!=new IntPtr(-1))Track(changed);
        Publish("JOIN_RETURN.json",Identity(Role,Self,",\"transaction\":"+N(transaction)+",\"returnCode\":"+N(joined)+",\"changeEventReturned\":"+((changed!=IntPtr.Zero && changed!=new IntPtr(-1))?"true":"false")));
        Need(joined==0 && changed!=IntPtr.Zero && changed!=new IntPtr(-1),"MsiJoinTransaction");
        Publish("END_ENTER.json",Identity(Role,Self,",\"transaction\":"+N(transaction)+",\"decision\":\"ROLLBACK\""));
        uint ended=MsiEndTransaction(0);
        Publish("END_RETURN.json",Identity(Role,Self,",\"transaction\":"+N(transaction)+",\"returnCode\":"+N(ended)));
        Close(changed); Publish("CHANGE_EVENT_CLOSED.json",Identity(Role,Self,",\"transaction\":"+N(transaction)+",\"checkedClose\":true"));
        Need(ended==0,"MsiEndTransaction"); Before(Deadline);
        Publish("GUARDIAN_CHILD_DONE.json",Identity(Role,Self,",\"status\":\"PASS_JOIN0_END_ROLLBACK0_AND_CHECKED_CLOSE\""));
    }
    static int Main(string[] args)
    {
        int result=1603;
        try
        {
            Need(IntPtr.Size==4,"X86_REQUIRED"); uint transaction=0;
            Need(args.Length==4 && (args[1]=="supervisor" || args[1]=="guardian-child") && UInt32.TryParse(args[0],NumberStyles.None,CultureInfo.InvariantCulture,out transaction) && transaction>0,"ARGV");
            Role=args[1]; Root=args[2]; Nonce=args[3];
            Need(Regex.IsMatch(Nonce,"\\A[0-9a-f]{32}\\z",RegexOptions.CultureInvariant),"NONCE"); Arm(10); ValidateRoot();
            if(Role=="supervisor")Supervisor(transaction);else Guardian(transaction); result=0;
        }
        catch(Exception error) { Fail(error); }
        finally
        {
            while(Handles.Count>0) { IntPtr h=Handles[Handles.Count-1]; try { Close(h); } catch(Exception e) { Fail(e); result=1603; } }
            if(CloseFailed)result=1603;
            if(Watchdog!=null) { if(result==0 && Stopwatch.GetTimestamp()>=Deadline) { Fail(new TimeoutException("ORIGINAL_PROCESS_BUDGET"));result=1603; } Interlocked.Exchange(ref Finished,1);Watchdog.Dispose(); }
        }
        return result;
    }
}
