[CmdletBinding()]
param([switch]$Execute,[string]$Root,[string]$SpecSha256)
$ErrorActionPreference='Stop'
if(-not $Execute){@{status='PREPARED_NOT_RUN';scope='compile-only x86 GUI test fixture; no EXE execution'}|ConvertTo-Json -Compress;return}
$clock=[Diagnostics.Stopwatch]::StartNew()
function Need([bool]$v,[string]$s){if(-not $v){throw $s}}
function Hash([string]$p){(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
function Fact([string]$p){@{bytes=[long]([IO.FileInfo]::new($p).Length);sha256=(Hash $p)}}
function New-Json([string]$p,$v){$b=[Text.UTF8Encoding]::new($false).GetBytes(($v|ConvertTo-Json -Depth 30)+"`n");$f=[IO.File]::Open($p,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$f.Write($b,0,$b.Length);$f.Flush($true)}finally{$f.Dispose()}}
function New-Bytes([string]$p,[byte[]]$b){if($null-eq $b){$b=[byte[]]::new(0)};$f=[IO.File]::Open($p,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$f.Write($b,0,$b.Length);$f.Flush($true)}finally{$f.Dispose()}}
function Remaining {return [int][Math]::Max(0,30000-$clock.ElapsedMilliseconds)}
Need ([IO.Path]::GetFullPath($Root)-ceq $Root) 'EXACT_ROOT'
$spec=Get-Content -LiteralPath (Join-Path $Root 'spec.json') -Raw|ConvertFrom-Json
Need ((Hash (Join-Path $Root 'spec.json'))-ceq $SpecSha256) 'SPEC_SHA'
Need ($Root-ceq $spec.windowsRoot -and [IO.Path]::GetFileName($Root)-ceq $spec.rootName) 'OWNED_FIXED_ROOT'
Need ([IO.File]::ReadAllText((Join-Path $Root '.owner'))-ceq "future-classroom-owned-r79-early-terminal-fixture/v1`n") 'OWNER_MARKER'
$sid=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
Need ($sid-ceq $spec.expectedUserSid) 'CURRENT_USER_SID'
$acl=Get-Acl -LiteralPath $Root
Need ($acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq $sid -and $acl.AreAccessRulesProtected) 'PROTECTED_OWNER'
$aces=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($aces.Count-eq 2) 'TWO_ACES'
$who=@($aces|ForEach-Object {$_.IdentityReference.Value}|Sort-Object -Unique);Need ($who.Count-eq 2 -and $sid-in $who -and 'S-1-5-18'-in $who) 'USER_AND_SYSTEM'
foreach($a in $aces){Need ($a.AccessControlType-eq 'Allow' -and $a.IdentityReference.Value-in @($sid,'S-1-5-18') -and ($a.FileSystemRights-band [Security.AccessControl.FileSystemRights]::FullControl)-eq [Security.AccessControl.FileSystemRights]::FullControl) 'CLOSED_DACL'}
$source=Join-Path $Root 'PositiveControl.cs';$item=@($spec.sources|Where-Object path -CEQ 'PositiveControl.cs');Need ($item.Count-eq 1 -and (Hash $source)-ceq $item[0].sha256) 'ACTUAL_SOURCE'
$compiler=Join-Path $env:SystemRoot 'Microsoft.NET\Framework\v4.0.30319\csc.exe'
$exe=Join-Path $Root 'PositiveControl.exe';Need (-not [IO.File]::Exists($exe)) 'NEW_EXE'
$oldTemp=$env:TEMP;$oldTmp=$env:TMP;$scratch=Join-Path $Root 'csc-owned-temp';[void][IO.Directory]::CreateDirectory($scratch)
$result=[ordered]@{status='FAIL_COMPILE_ONLY';nonce=$spec.nonce;source=(Fact $source);compiler=(Fact $compiler);actualExit=$null;exe=$null;executed=$false;originalMaximumMilliseconds=30000;originalHandleAcquired=$false;processWaitReturned=$false;pipesComplete=$false;processDisposed=$false}
$p=$null;$stdout=$null;$stderr=$null;$stdoutTask=$null;$stderrTask=$null;$outputsWritten=$false
try{
 $env:TEMP=$scratch;$env:TMP=$scratch
 $argv=@('/nologo','/target:winexe','/platform:x86','/optimize+','/warnaserror+',('/out:"'+$exe+'"'),('"'+$source+'"'))
 $result.commandArgs=@($compiler)+$argv
 Need ((Remaining)-gt 0) 'ORIGINAL_COMPILER_DEADLINE_BEFORE_START'
 $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$compiler;$info.Arguments=$argv-join ' ';$info.WorkingDirectory=$Root;$info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
 $p=[Diagnostics.Process]::new();$p.StartInfo=$info;Need ($p.Start()) 'COMPILER_START'
 # Retain the original process object immediately, before querying metadata or
 # waiting; never reopen by PID to reconstruct an already lost ExitCode.
 $originalHandle=$p.Handle;Need ($originalHandle-ne [IntPtr]::Zero) 'ORIGINAL_COMPILER_HANDLE';$result.originalHandleAcquired=$true
 $stdout=[IO.MemoryStream]::new();$stderr=[IO.MemoryStream]::new()
 $stdoutTask=$p.StandardOutput.BaseStream.CopyToAsync($stdout);$stderrTask=$p.StandardError.BaseStream.CopyToAsync($stderr)
 $result.compilerPid=$p.Id;$result.compilerCreationFiletime=$p.StartTime.ToUniversalTime().ToFileTimeUtc()
 $left=Remaining;Need ($left-gt 0 -and $p.WaitForExit($left)) 'COMPILER_UNKNOWN_LIVE_RETAIN_ROOT';$result.processWaitReturned=$true
 $rawExit=$p.ExitCode;Need ($null-ne $rawExit -and $rawExit-is [int]) 'ORIGINAL_COMPILER_EXITCODE_UNKNOWN_RETAIN';$result.actualExit=$rawExit
 $left=Remaining;Need ($left-gt 0 -and [Threading.Tasks.Task]::WaitAll([Threading.Tasks.Task[]]@($stdoutTask,$stderrTask),$left)) 'ORIGINAL_COMPILER_PIPES_UNKNOWN_RETAIN'
 $result.pipesComplete=$true
 New-Bytes (Join-Path $Root 'csc.stdout.log') $stdout.ToArray();New-Bytes (Join-Path $Root 'csc.stderr.log') $stderr.ToArray();$outputsWritten=$true
 Need ((Remaining)-gt 0) 'ORIGINAL_COMPILER_DEADLINE_AFTER_CAPTURE'
 Need ($result.actualExit-eq 0) 'CSC_ACTUAL_FAILURE'
 Need ((Hash $source)-ceq $result.source.sha256 -and (Hash $compiler)-ceq $result.compiler.sha256) 'SOURCE_COMPILER_CHANGED'
 Need ((Remaining)-gt 0) 'ORIGINAL_COMPILER_DEADLINE_AFTER_METADATA'
 $result.exe=Fact $exe;$result.status='PASS_CSC_ACTUAL_EXIT0_COMPILE_ONLY'
}finally{
 $env:TEMP=$oldTemp;$env:TMP=$oldTmp
 # Partial capture is explicitly qualified; it never becomes a successful pipe
 # or compiler result and the owning nonce root is retained by transport.
 if(-not $outputsWritten -and $null-ne $stdout -and $null-ne $stderr){
  try{New-Bytes (Join-Path $Root 'csc.stdout.log') $stdout.ToArray();New-Bytes (Join-Path $Root 'csc.stderr.log') $stderr.ToArray();$result.partialOutputsCaptured=$true}catch{$result.partialCaptureError=$_.Exception.Message}
 }
 if($null-ne $p -and $result.processWaitReturned -and $result.pipesComplete){$p.Dispose();$result.processDisposed=$true}
 if($result.pipesComplete){$stdout.Dispose();$stderr.Dispose()}
 $result.elapsedMilliseconds=$clock.ElapsedMilliseconds
 if($clock.ElapsedMilliseconds-ge 30000){$result.status='FAIL_COMPILE_ONLY_ORIGINAL_DEADLINE'}
 New-Json (Join-Path $Root 'positive-compile-receipt.json') $result
}
$result|ConvertTo-Json -Depth 30
