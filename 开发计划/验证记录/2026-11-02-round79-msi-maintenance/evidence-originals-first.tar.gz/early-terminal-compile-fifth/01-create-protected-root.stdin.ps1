$c='{"nonce":"0b744835e91f1ee00a95b18eb3303f19","root":"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-0b744835e91f1ee00a95b18eb3303f19","sid":"S-1-5-21-3896111207-1867804362-1971593122-1001","specSha256":"f96275a93a88110065b10f905c07c5362258187be2ef5bfde9967c3915bf92a6","files":[{"path":"Compile-PositiveControl.ps1","bytes":6445,"sha256":"aa562d0d9c5b33f2c5a4011d1a58bb2f36ddc689e57e13ab64e87db6e31bc432"},{"path":"PositiveControl.cs","bytes":16463,"sha256":"ae0a1c90e5d551cd824eef0cc1b7afdf0b92174b091b7b68bbea02bb21796e04"},{"path":"compile-inputs.json","bytes":862,"sha256":"140044fa54745f809304cc0cf4ce3620158fc7e4b38069c0e9a6ca8d907f284d"},{"path":"spec.json","bytes":2045,"sha256":"f96275a93a88110065b10f905c07c5362258187be2ef5bfde9967c3915bf92a6"}]}'|ConvertFrom-Json;
$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
function Need([bool]$v,[string]$s){if(-not $v){throw $s}}
function Absent([string]$p){try{[void][IO.File]::GetAttributes($p);return $false}catch{$e=$_.Exception;while($e.InnerException){$e=$e.InnerException};if($e-is [IO.FileNotFoundException] -or $e-is [IO.DirectoryNotFoundException]){return $true};throw}}
function Fact([string]$p){$a=[IO.File]::GetAttributes($p);Need (-not($a-band[IO.FileAttributes]::ReparsePoint) -and -not($a-band[IO.FileAttributes]::Directory)) 'REGULAR_NONREPARSE';$size=[long]([IO.FileInfo]::new($p).Length);Need ($size-ge 0 -and $size-le 16777216) 'FILE_BOUND';@{bytes=$size;sha256=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}}
function Root-Check {
 Need ($PSVersionTable.PSVersion.Major-eq 5 -and [IntPtr]::Size-eq 8) 'DESKTOP_PS51_X64'
 Need ([IO.Path]::GetFullPath($c.root)-ceq $c.root -and [IO.Path]::GetFileName($c.root)-ceq ('FutureClassroom-r79-early-terminal-'+$c.nonce)) 'CLOSED_ROOT'
 $identity=[Security.Principal.WindowsIdentity]::GetCurrent();try{Need ($identity.User.Value-ceq $c.sid) 'EXPECTED_CURRENT_USER'}finally{$identity.Dispose()}
 $cursor=$c.root;while($cursor){$a=[IO.File]::GetAttributes($cursor);Need (($a-band[IO.FileAttributes]::ReparsePoint)-eq 0 -and ($a-band[IO.FileAttributes]::Directory)-ne 0) 'DIRECTORY_NO_REPARSE';$cursor=[IO.Path]::GetDirectoryName($cursor)}
 Need ([IO.File]::ReadAllText((Join-Path $c.root '.owner'))-ceq "future-classroom-owned-r79-early-terminal-fixture/v1`n") 'OWNER_MARKER'
 $acl=[IO.Directory]::GetAccessControl($c.root);Need ($acl.AreAccessRulesProtected -and $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value-ceq $c.sid) 'PROTECTED_OWNER'
 $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));Need ($rules.Count-eq 2) 'TWO_ACES'
 $who=@($rules|ForEach-Object {$_.IdentityReference.Value}|Sort-Object -Unique);Need ($who.Count-eq 2 -and $c.sid-in $who -and 'S-1-5-18'-in $who) 'USER_AND_SYSTEM'
 foreach($r in $rules){Need ($r.AccessControlType-eq 'Allow' -and ($r.FileSystemRights-band [Security.AccessControl.FileSystemRights]::FullControl)-eq [Security.AccessControl.FileSystemRights]::FullControl) 'EXACT_ALLOW_FULLCONTROL'}
}
function Inventory {
 Root-Check;$files=@();$dirs=@();$total=0L;$queue=[Collections.Generic.Queue[string]]::new();$queue.Enqueue($c.root)
 while($queue.Count){$dir=$queue.Dequeue();foreach($p in [IO.Directory]::GetFileSystemEntries($dir)){$a=[IO.File]::GetAttributes($p);Need (($a-band[IO.FileAttributes]::ReparsePoint)-eq 0) 'INVENTORY_REPARSE';$rel=$p.Substring($c.root.Length+1).Replace('\','/');if(($a-band[IO.FileAttributes]::Directory)-ne 0){Need ($rel-ceq 'csc-owned-temp' -or $rel.StartsWith('csc-owned-temp/')) 'ONLY_OWN_COMPILER_TEMP_SUBDIRECTORIES';$dirs+=$rel;$queue.Enqueue($p)}else{$f=Fact $p;$files+=@{path=$rel;bytes=$f.bytes;sha256=$f.sha256};$total+=$f.bytes};Need ($files.Count-le 64 -and $dirs.Count-le 16 -and $total-le 33554432) 'INVENTORY_BOUND'}}
 @{files=@($files|Sort-Object path);directories=@($dirs|Sort-Object)}
}

Need ($c.nonce-cmatch '^[0-9a-f]{32}$' -and $c.sid-cmatch '^S-1-5-21-') 'NONCE_SID'
$identity=[Security.Principal.WindowsIdentity]::GetCurrent();try{$sid=$identity.User;Need ($sid.Value-ceq $c.sid) 'EXACT_USER'}finally{$identity.Dispose()}
$expected=Join-Path ([IO.Path]::GetFullPath($env:TEMP)) ('FutureClassroom-r79-early-terminal-'+$c.nonce)
Need ($expected-ceq $c.root) 'SPEC_ROOT_MUST_EQUAL_ACTUAL_USER_TEMP_ROOT'
Need (Absent $c.root) 'PREEXISTING_ROOT_REFUSED'
$cursor=[IO.Path]::GetDirectoryName($c.root);while($cursor){Need (([IO.File]::GetAttributes($cursor)-band[IO.FileAttributes]::ReparsePoint)-eq 0) 'NO_ANCESTOR_REPARSE';$cursor=[IO.Path]::GetDirectoryName($cursor)}
[void][IO.Directory]::CreateDirectory($c.root)
$acl=[Security.AccessControl.DirectorySecurity]::new();$acl.SetOwner($sid);$acl.SetAccessRuleProtection($true,$false)
foreach($who in @($sid,[Security.Principal.SecurityIdentifier]::new('S-1-5-18'))){$acl.AddAccessRule([Security.AccessControl.FileSystemAccessRule]::new($who,'FullControl','ContainerInherit,ObjectInherit','None','Allow'))}
[IO.Directory]::SetAccessControl($c.root,$acl)
$owner=[Text.UTF8Encoding]::new($false).GetBytes("future-classroom-owned-r79-early-terminal-fixture/v1`n")
$f=[IO.File]::Open((Join-Path $c.root '.owner'),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);try{$f.Write($owner,0,$owner.Length);$f.Flush($true)}finally{$f.Dispose()}
Root-Check
@{status='PASS_CREATED_ONLY_PROTECTED_COMPILE_ROOT';root=$c.root;nonce=$c.nonce;sid=$c.sid}|ConvertTo-Json -Compress
