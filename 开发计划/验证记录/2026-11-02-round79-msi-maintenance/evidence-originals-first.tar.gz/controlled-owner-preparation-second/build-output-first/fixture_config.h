#define FC79_NONCE L"048185bd83264d1b8abf282244500f4b"
#define FC79_PRODUCT L"{ED9C68A7-433A-404C-9997-A55EAA8A734F}"
#define FC79_EFFECT_DIR L"C:\\Users\\Elior\\AppData\\Local\\Temp\\FutureClassroom-r79-early-terminal-048185bd83264d1b8abf282244500f4b\\effect\\"
