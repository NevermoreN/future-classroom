from pathlib import Path
import ast,hashlib,json,runpy,subprocess,inspect,copy
E=Path('/tmp/fc-round79-msi-maintenance');D=Path(__file__).resolve().parent;A=E/'negative-fixture-preparation-first'
def need(v,c):
 if not v:raise AssertionError(c)
def fact(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
first=json.loads((A/'freeze-first.json').read_text());need(fact(A/'freeze-first.json')['sha256']=='e546b60caccc37ff69bfe08fd3dbba8b5064ed03577c1e7c6830770a3bd4224f' and all(fact(Path(r['path']))==r for r in first['files']),'first originals unchanged')
for p in D.glob('*.py'):ast.parse(p.read_text())
m=runpy.run_path(str(D/'run-negative-msi-r79-second.py'),run_name='second_pure');old=runpy.run_path(str(A/'run-negative-msi-r79-first.py'),run_name='first_pure');need([fact(p)['sha256'] for p in m['FILES']]==m['PINS'],'all seven second pins');need(ast.dump(ast.parse(inspect.getsource(m['phase_cleanup_admission'])))==ast.dump(ast.parse(inspect.getsource(old['phase_cleanup_admission']))),'positive negative transport admission AST unchanged')
# Re-run the first validator's pure gate inputs and rejection cases only. The
# fragment ends before its Windows source/provenance/archive/output operations.
text=(A/'validate-and-freeze-first.py').read_text();start=text.index('positive=dict(');end=text.index('# Independent semantic model:',start);space=dict(D=D,module=m,need=need,copy=copy);exec(compile(text[start:end],'<unchanged-first-pure-gates>','exec'),space);tests=space['tests'];need(len(tests)==12,'all twelve transport cases rerun')
cs=(D/'PayloadFixture.cs').read_text();ps=(D/'Invoke-ProductionMsiPhases.ps1').read_text();factory=cs[cs.index('public static State CreateState('):cs.index('public static void CaptureInto')];checks={
 'managed_factory_no_native_or_files':all(x not in factory for x in ['Context(','Resource(','Parents(','Open(','Info(','Tree(','WindowsIdentity','Environment.','Path.','Close(']),
 'active_before_capture_into':ps.index('$script:activeMutation=[FcR79PayloadFixture]::CreateState')<ps.index('[FcR79PayloadFixture]::CaptureInto'),
 'all_capture_handles_use_visible_state':'public static void CaptureInto(State s' in cs and 'new Handles(s)' in cs,
 'future_msi_poison_gate':'UNKNOWN_FIXTURE_CLOSE_BLOCKS_ANY_NEXT_MSI' in ps,
 'poison_precedes_healthy_absent_cleanup':ps.index('UNKNOWN_FIXTURE_CLOSE_BEFORE_ANY_HEALTHY_OR_ABSENT_CLEANUP_BRANCH')<ps.index("$actual=Measure-State 'Present'"),
 'incomplete_capture_cannot_write_restore':cs.index('COMPLETE_CAPTURED_ORIGINAL_REQUIRED_BEFORE_ANY_RESTORE_IO')<cs.index('var hs=new Handles(s)',cs.index('public static void Restore')),
 'restore_full_tree_before_completed':cs.index('s.RestoredTree=Tree(s);ValidateRestoredTree(s);')<cs.index('s.RestorationComplete=true'),
 'only_missing_leaf_new_identity': 'ONLY_MISSING_FIXED_LEAF_MAY_HAVE_NEW_OBJECT' in cs and 'RESTORED_TREE_OTHER_ORIGINAL_OBJECTS_UNCHANGED' in cs,
 'all_other_write_times_and_attributes': 'RESTORED_TREE_OTHER_WRITE_TIMES_UNCHANGED' in cs and 'RESTORED_TREE_ALL_ORIGINAL_BYTES_AND_ATTRIBUTES' in cs,
 'tampered_time_change_explicit':'fixture write time is recorded and not claimed restored' in cs,
 'backup_html_source_bytes_and_fact': '-original-web-index.html' in cs and 'OriginalBackupFact=Fact(' in cs and 'CLOSED_BACKUP_ORIGINAL_OBJECT_AND_FULL_BYTES' in cs,
 'backup_not_read_for_restoration':'OriginalBackup' not in cs[cs.index('public static void Restore'):],
 'original_budget_and_negative_scope':all(x in ps for x in ['600000','150000','cleanupReserveMilliseconds=180000','nativeBrokerOriginalSeconds=120','NOT_CLAIMED_FROM_MISSING_OBSERVATION'])}
need(all(checks.values()),'second finite static fixes')
# Independent reference-lifetime failure model; not a fake native close test.
poison=[]
for observed in ('HEALTHY','ABSENT','DAMAGED'):
 state={'closeUnknown':False};active=state
 try:state['closeUnknown']=True;raise OSError('synthetic checked-close failure')
 except OSError:pass
 can_continue=not(active is not None and active['closeUnknown']);need(not can_continue,'visible poison '+observed);poison.append(dict(observedProduct=observed,activeStateVisible=True,unknownClose=True,allowFollowingMsiOrCleanup=False))
commands=[]
for p in (D/'bind-negative-msi-r79-second.py',D/'run-negative-msi-r79-second.py'):
 r=subprocess.run(['python3',str(p)],capture_output=True,timeout=10);need(r.returncode==0 and not r.stderr,'inert defaults actual0');commands.append(dict(command=['python3',str(p)],exitCode=r.returncode,stdout=r.stdout.decode(),windows='NOT_RUN'))
package=E/'package-preparation-first/candidate-output-first';report=package/'report.json';j=json.loads(report.read_text());need(fact(report)['sha256']=='a3946132c3deb9f2ea37f997c94b3380eb0ba5aea87d490e9829ef34a7428b58','root actual package report pin');ci=E/'package-preparation-first/win7-build-original-first';helper=ci/'product/fc-bootstrap/fc-installer-lifecycle.exe';checkout=E/'package-preparation-first/checkout-261c58a-first';builder=checkout/'scripts/package-msi-candidate.py'
args=['--packaging-report',str(report),'--packaging-report-sha256',fact(report)['sha256'],'--builder-script',str(builder),'--builder-script-sha256',j['script_sha256'],'--source-root',str(checkout),'--normal-helper',str(helper),'--normal-helper-sha256',j['normal_helper_provenance']['normal_helper_sha256'],'--build-evidence',str(ci),'--build-result-sha256',j['normal_helper_provenance']['result_sha256']]
plan=dict(status='PREPARED_ARGUMENTS_FROM_ACTUAL_ROOT_PACKAGE_ONLY_NOT_BINDING_EXECUTED',actualPackageReport=fact(report),actualMsi=dict(path=str(package/'candidate.msi'),bytes=j['msi']['size'],sha256=j['msi']['sha256']),localCheckCommand=['python3',str(D/'bind-negative-msi-r79-second.py'),'--check-only',*args],localPlanCreationCommand=['python3',str(D/'bind-negative-msi-r79-second.py'),'--execute',*args,'--output-dir',str(D/'bound-plan-first')],transportAfterActualPlanCreation=['python3',str(D/'run-negative-msi-r79-second.py'),'--execute','--config',str(D/'bound-plan-first/candidate-inputs.json'),'--config-sha256','<ACTUAL_NEW_PLAN_SHA_AFTER_CREATION>','--report',str(E/'product-negative-runtime-first/report.json')],runtime='NOT_RUN',nonce='NOT_CREATED')
p=D/'execution-plan-first.json';need(not p.exists(),'new execution plan');p.write_text(json.dumps(plan,indent=2)+'\n')
receipt=dict(status='PREPARED_R79_SECOND_VISIBLE_CAPTURE_OWNER_AND_FULL_RESTORE_TREE_NOT_WINDOWS_VALIDATED',normalPeSourceGit=first['normalPeSourceGit'],currentAuditMainGit=first['currentAuditMainGit'],firstFreeze=fact(A/'freeze-first.json'),firstAllSourceOriginalsUnchanged=True,firstReviewBlocker='Capture RHS could throw unknown Close before active assignment; first remains blocked and unchanged',files=[fact(p) for p in [*m['FILES'],D/'bind-negative-msi-r79-second.py',D/'run-negative-msi-r79-second.py']],staticChecks=checks,pureTransportAdmissionCases=tests,pureClosePoisonReferenceModels=poison,defaultInertCommands=commands,executionPlan=fact(D/'execution-plan-first.json'),powershellParse='NOT_RUN_SECOND',csharpCompile='NOT_RUN_SECOND',actualBinding='NOT_RUN_SECOND',windows='NOT_RUN_SECOND',budgets=first['budgets'],changes=['Managed CreateState saved before CaptureInto any native work; close-poison before every subsequent MSI and before healthy/absent cleanup','Restore refuses incomplete original capture; full tree identity/hash/attributes/write-time check after checked-close, allowing only missing fixed leaf new identity and explicitly recording tampered leaf changed write time','Own original HTML backup extension .bin→.html with same exact bytes; record its closed read-back original object FileFact; restore uses verified in-memory bytes','Binder/transport second namespace and exact source pins; no production Rust changes or new business permission'],remaining='Independent second static review and root PS parse/four C# compiles before real MSI. Unknown original close/owner/Pending still refuses cleanup and retains evidence; no guarantee after OS I/O failure.',entrypoints=dict(binder=str(D/'bind-negative-msi-r79-second.py'),transport=str(D/'run-negative-msi-r79-second.py')),finalFilesFrozen=True)
p=D/'freeze-second.json';need(not p.exists(),'create-new second freeze');p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(fact(p)))
