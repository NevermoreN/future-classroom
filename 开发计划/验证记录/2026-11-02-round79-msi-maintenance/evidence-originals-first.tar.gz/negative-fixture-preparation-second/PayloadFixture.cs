// TEST-ONLY R79 payload fixture. Fixed synthetic install tree only; never Run,
// ProgramData, Installer cache, another account, a process, or a service.
using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Principal;
using Microsoft.Win32.SafeHandles;
public static class FcR79PayloadFixture {
 const string Sid="S-1-5-21-3896111207-1867804362-1971593122-1001";
 [StructLayout(LayoutKind.Sequential)]internal struct T {public uint Low,High;}
 [StructLayout(LayoutKind.Sequential)]internal struct I {public uint Attributes;public T Creation,Access,Write;public uint Volume,SizeHigh,SizeLow,Links,IndexHigh,IndexLow;}
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true,ExactSpelling=true)]static extern IntPtr CreateFileW(string p,uint a,uint s,IntPtr sec,uint d,uint f,IntPtr t);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool CloseHandle(IntPtr h);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool GetFileInformationByHandle(IntPtr h,out I i);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool SetFileInformationByHandle(IntPtr h,int kind,ref byte value,uint bytes);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true,ExactSpelling=true)]static extern uint GetFileAttributesW(string p);
 public sealed class FileFact {public string Path,Sha256;public long Bytes,Creation,Write;public uint Volume,IndexHigh,IndexLow,Attributes,Links;}
 public sealed class State {
  public string Kind,Nonce,Phase,FixedResource,ExtraPath,Scope="FIXTURE_MUTATION_AND_EXACT_RESTORATION_NOT_MSI_REPAIR_OR_ROLLBACK";
  public FileFact Original,Applied,Restored,OriginalBackupFact;public FileFact[] OriginalTree,BeforeMsiTree,AfterMsiTree,RestoredTree;public string OriginalBackup,RestorationIdentityScope;
  public bool NativeCloseUnknown,RestorationComplete;
  internal byte[] OriginalBytes,AlteredBytes,ExtraBytes;internal string Scratch;internal FileFact ExtraCreated;
 }
 sealed class Handles {
  internal List<IntPtr> All=new List<IntPtr>();internal State Owner;
  internal Handles(State s){Owner=s;}
  internal IntPtr Add(IntPtr h){if(h==new IntPtr(-1)||h==IntPtr.Zero)throw new Win32Exception(Marshal.GetLastWin32Error());All.Add(h);return h;}
  internal void Close(IntPtr h){int n=All.IndexOf(h);Need(n>=0,"ORIGINAL_TRACKED_HANDLE");All.RemoveAt(n);if(!CloseHandle(h)){Owner.NativeCloseUnknown=true;throw new Win32Exception(Marshal.GetLastWin32Error(),"UNKNOWN_CLOSE_NOT_RETRIED");}}
  internal void Finish(){Exception error=null;while(All.Count>0){try{Close(All[All.Count-1]);}catch(Exception e){if(error==null)error=e;}}if(error!=null)throw error;}
 }
 static void Need(bool v,string c){if(!v)throw new InvalidOperationException(c);}
 static long Time(T t){return (long)(((ulong)t.High<<32)|t.Low);}
 static I Info(IntPtr h){I i;if(!GetFileInformationByHandle(h,out i))throw new Win32Exception(Marshal.GetLastWin32Error());return i;}
 static string Hash(byte[] b){using(var s=SHA256.Create())return BitConverter.ToString(s.ComputeHash(b)).Replace("-","").ToLowerInvariant();}
 static string Base(){return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),@"Programs\FutureClassroom");}
 static string Resource(){return Path.Combine(Base(),@"web\index.html");}
 static bool SameObject(FileFact a,FileFact b){return a.Volume==b.Volume&&a.IndexHigh==b.IndexHigh&&a.IndexLow==b.IndexLow&&a.Creation==b.Creation&&a.Links==1&&b.Links==1;}
 static IntPtr Open(Handles hs,string p,uint access,uint disposition,bool dir){
  Need(p==Path.GetFullPath(p)&&p.Length<32760&&hs.All.Count<64,"EXACT_LOCAL_PATH_AND_BOUNDED_HANDLES");
  IntPtr h=hs.Add(CreateFileW(@"\\?\"+p,access,dir?3U:1U,IntPtr.Zero,disposition,0x00200000U|(dir?0x02000000U:0),IntPtr.Zero));
  I i=Info(h);Need((i.Attributes&0x400)==0&&((i.Attributes&0x10)!=0)==dir&&(dir||i.Links==1),"NONREPARSE_SINGLE_LINK_FILE_OR_REAL_DIRECTORY");return h;
 }
 static void Parents(Handles hs,string leaf){var names=new List<string>();string p=Path.GetDirectoryName(leaf);while(p!=null){names.Add(p);p=Path.GetDirectoryName(p);}names.Reverse();foreach(string name in names)Open(hs,name,0x80,3,true);}
 static byte[] Read(IntPtr h,int max){I i=Info(h);long len=((long)i.SizeHigh<<32)|i.SizeLow;Need(len>=0&&len<=max,"BOUNDED_FILE_BYTES");byte[] b=new byte[(int)len];using(var wrapper=new SafeFileHandle(h,false))using(var f=new FileStream(wrapper,FileAccess.Read)){f.Position=0;int n=0;while(n<b.Length){int got=f.Read(b,n,b.Length-n);Need(got>0,"COMPLETE_FILE_READ");n+=got;}}return b;}
 static FileFact Fact(IntPtr h,string p,int max){I a=Info(h);byte[] b=Read(h,max);I z=Info(h);Need(a.Volume==z.Volume&&a.IndexHigh==z.IndexHigh&&a.IndexLow==z.IndexLow&&a.SizeHigh==z.SizeHigh&&a.SizeLow==z.SizeLow&&Time(a.Write)==Time(z.Write)&&Time(a.Creation)==Time(z.Creation)&&a.Attributes==z.Attributes&&a.Links==z.Links,"STABLE_ORIGINAL_FILE_FACT");return new FileFact{Path=p,Sha256=Hash(b),Bytes=b.Length,Creation=Time(a.Creation),Write=Time(a.Write),Volume=a.Volume,IndexHigh=a.IndexHigh,IndexLow=a.IndexLow,Attributes=a.Attributes,Links=a.Links};}
 static void Write(IntPtr h,byte[] b,bool firstOnly){using(var wrapper=new SafeFileHandle(h,false))using(var f=new FileStream(wrapper,FileAccess.Write)){f.Position=0;f.Write(b,0,firstOnly?1:b.Length);f.Flush(true);}}
 static bool Absent(string p){uint a=GetFileAttributesW(@"\\?\"+p);if(a!=0xffffffff)return false;int e=Marshal.GetLastWin32Error();Need(e==2||e==3,"ABSENCE_UNKNOWN_ERROR");return true;}
 static void Delete(Handles hs,IntPtr h,string path){byte yes=1;if(!SetFileInformationByHandle(h,4,ref yes,1))throw new Win32Exception(Marshal.GetLastWin32Error());hs.Close(h);Need(Absent(path),"EXTERNAL_EXACT_FILE_ABSENCE");}
 static void Context(State s){using(var own=WindowsIdentity.GetCurrent())Need(own.User.Value==Sid,"EXACT_FIXTURE_USER");Need(s!=null&&!s.NativeCloseUnknown&&System.Text.RegularExpressions.Regex.IsMatch(s.Nonce??"",@"\A[0-9a-f]{32}\z")&&s.FixedResource==Resource(),"EXACT_FIXED_FIXTURE_STATE");Need(s.Scratch==Path.GetFullPath(s.Scratch)&&Path.GetFileName(s.Scratch)=="FutureClassroom-r79-production-msi-"+s.Nonce,"EXACT_NONCE_SCRATCH");Need(File.ReadAllText(Path.Combine(s.Scratch,".owner"))=="future-classroom-owned-r79-production-msi-runtime/v1\n","EXACT_SCRATCH_OWNER");}
 public static FileFact[] Tree(State s){Context(s);var hs=new Handles(s);try{Parents(hs,Resource());var rows=new List<FileFact>();var q=new Queue<string>();q.Enqueue(Base());int dirs=0;long total=0;while(q.Count>0){string dir=q.Dequeue();Open(hs,dir,0x80,3,true);Need(++dirs<=16,"TREE_DIRECTORY_BOUND");foreach(string p in Directory.GetFileSystemEntries(dir)){FileAttributes a=File.GetAttributes(p);Need((a&FileAttributes.ReparsePoint)==0,"TREE_NO_REPARSE");if((a&FileAttributes.Directory)!=0){q.Enqueue(p);continue;}Need(rows.Count<96,"TREE_FILE_BOUND");IntPtr h=Open(hs,p,0x80000000,3,false);var f=Fact(h,p,32*1024*1024);total=checked(total+f.Bytes);Need(total<=32*1024*1024,"TREE_TOTAL_BYTES_BOUND");rows.Add(f);hs.Close(h);}}rows.Sort((a,b)=>StringComparer.Ordinal.Compare(a.Path,b.Path));return rows.ToArray();}finally{hs.Finish();}}
 // Managed-only: no Windows identity, Known Folder, file/handle operation or
 // checked-close occurs before this State can be saved by the PS coordinator.
 public static State CreateState(string scratch,string nonce,string kind){Need(kind=="Missing"||kind=="Tampered"||kind=="Extra","CLOSED_MUTATION_KIND");Need(scratch!=null&&scratch.Length>=1&&scratch.Length<32760&&scratch.IndexOf('\0')<0&&System.Text.RegularExpressions.Regex.IsMatch(nonce??"",@"\A[0-9a-f]{32}\z"),"MANAGED_BOUNDED_STATE_ARGUMENTS");return new State{Scratch=scratch,Nonce=nonce,Kind=kind,Phase="MANAGED_STATE_BEFORE_NATIVE_CAPTURE"};}
 public static void CaptureInto(State s,int expectedBytes,string expectedSha){
  Need(s!=null&&s.Phase=="MANAGED_STATE_BEFORE_NATIVE_CAPTURE","ONE_NATIVE_CAPTURE_ONLY");s.FixedResource=Resource();Context(s);s.Phase="CAPTURING_NATIVE_RESULTS_MAY_EXIST";Need(expectedBytes>=1&&expectedBytes<=65536&&System.Text.RegularExpressions.Regex.IsMatch(expectedSha??"",@"\A[0-9a-f]{64}\z"),"EXACT_BOUNDED_RESOURCE_EXPECTATION");
  var hs=new Handles(s);try{Parents(hs,Resource());Parents(hs,Path.Combine(s.Scratch,".owner"));IntPtr h=Open(hs,Resource(),0x80000000,3,false);s.Original=Fact(h,Resource(),65536);s.OriginalBytes=Read(h,65536);Need(s.Original.Bytes==expectedBytes&&s.Original.Sha256==expectedSha,"EXACT_ORIGINAL_RESOURCE_BYTES");hs.Close(h);
   s.AlteredBytes=(byte[])s.OriginalBytes.Clone();s.AlteredBytes[0]^=1;s.ExtraPath=Path.Combine(Base(),@"web\fc-r79-negative-"+nonce+".txt");Need(Absent(s.ExtraPath),"EXCLUSIVE_EXTRA_ABSENT");s.ExtraBytes=new UTF8Encoding(false).GetBytes("future-classroom-owned-r79-extra/v1\n"+nonce+"\n");
   s.OriginalBackup=Path.Combine(s.Scratch,s.Kind.ToLowerInvariant()+"-original-web-index.html");IntPtr backup=Open(hs,s.OriginalBackup,0xc0000000,1,false);Write(backup,s.OriginalBytes,false);Need(Fact(backup,s.OriginalBackup,65536).Sha256==expectedSha,"OWNED_BACKUP_FULL_BYTES");hs.Close(backup);IntPtr originalBackup=Open(hs,s.OriginalBackup,0x80000000,3,false);s.OriginalBackupFact=Fact(originalBackup,s.OriginalBackup,65536);Need(s.OriginalBackupFact.Sha256==expectedSha,"CLOSED_BACKUP_ORIGINAL_OBJECT_AND_FULL_BYTES");hs.Close(originalBackup);
  }finally{hs.Finish();}s.OriginalTree=Tree(s);s.Phase="CAPTURED_NO_MUTATION";
 }
 public static void Apply(State s){Context(s);Need(s.Phase=="CAPTURED_NO_MUTATION","ONE_APPLY_ONLY");var hs=new Handles(s);try{Parents(hs,Resource());s.Phase="APPLYING_PHYSICAL_RESULT_MAY_EXIST";
  if(s.Kind=="Extra"){Need(Absent(s.ExtraPath),"EXTRA_STILL_ABSENT");IntPtr h=Open(hs,s.ExtraPath,0xc0010000,1,false);s.ExtraCreated=Fact(h,s.ExtraPath,65536);Write(h,s.ExtraBytes,false);s.Applied=Fact(h,s.ExtraPath,65536);Need(s.Applied.Sha256==Hash(s.ExtraBytes),"EXACT_CREATED_EXTRA_BYTES");hs.Close(h);}
  else{IntPtr h=Open(hs,Resource(),s.Kind=="Missing"?0x80010000U:0xc0000000U,3,false);FileFact f=Fact(h,Resource(),65536);Need(SameObject(f,s.Original)&&f.Sha256==s.Original.Sha256,"ORIGINAL_RESOURCE_STILL_EXACT");if(s.Kind=="Missing")Delete(hs,h,Resource());else{Write(h,s.AlteredBytes,true);s.Applied=Fact(h,Resource(),65536);Need(SameObject(s.Applied,s.Original)&&s.Applied.Sha256==Hash(s.AlteredBytes),"EXACT_ONE_BYTE_TAMPER");hs.Close(h);}}
  s.Phase="APPLIED";
 }finally{hs.Finish();}s.BeforeMsiTree=Tree(s);ValidateAppliedTree(s);}
 static void ValidateAppliedTree(State s){var actual=new Dictionary<string,FileFact>(StringComparer.Ordinal);foreach(var f in s.BeforeMsiTree)actual.Add(f.Path,f);int expected=s.OriginalTree.Length+(s.Kind=="Extra"?1:s.Kind=="Missing"?-1:0);Need(actual.Count==expected,"EXACT_MUTATED_TREE_COUNT");foreach(var original in s.OriginalTree){if(original.Path==Resource()&&s.Kind=="Missing"){Need(!actual.ContainsKey(original.Path),"ONLY_FIXED_RESOURCE_MISSING");continue;}FileFact now;Need(actual.TryGetValue(original.Path,out now)&&SameObject(now,original),"ALL_ORIGINAL_OBJECTS_EXCEPT_MISSING_STABLE");if(original.Path==Resource()&&s.Kind=="Tampered")Need(now.Sha256==Hash(s.AlteredBytes)&&now.Bytes==original.Bytes,"ONLY_ONE_BYTE_CHANGED");else Need(now.Sha256==original.Sha256&&now.Bytes==original.Bytes&&now.Write==original.Write&&now.Attributes==original.Attributes,"ALL_OTHER_ORIGINAL_PAYLOAD_BYTES_STABLE");}if(s.Kind=="Extra"){FileFact extra;Need(actual.TryGetValue(s.ExtraPath,out extra)&&SameObject(extra,s.ExtraCreated)&&extra.Sha256==Hash(s.ExtraBytes),"ONLY_EXACT_OWNED_EXTRA_ADDED");}}
 public static void CheckPreserved(State s){Context(s);Need(s.Phase=="APPLIED","APPLIED_STATE_REQUIRED");var now=Tree(s);Need(SameTree(now,s.BeforeMsiTree),"NEGATIVE_MSI_CHANGED_FIXTURE_PREIMAGE");s.AfterMsiTree=now;}
 static bool SameTree(FileFact[] a,FileFact[] b){if(a==null||b==null||a.Length!=b.Length)return false;for(int i=0;i<a.Length;i++)if(a[i].Path!=b[i].Path||!SameObject(a[i],b[i])||a[i].Bytes!=b[i].Bytes||a[i].Sha256!=b[i].Sha256||a[i].Write!=b[i].Write||a[i].Attributes!=b[i].Attributes)return false;return true;}
 static void ValidateRestoredTree(State s){var actual=new Dictionary<string,FileFact>(StringComparer.Ordinal);foreach(var f in s.RestoredTree)actual.Add(f.Path,f);Need(actual.Count==s.OriginalTree.Length,"RESTORED_TREE_EXACT_ORIGINAL_MEMBER_COUNT");foreach(var original in s.OriginalTree){FileFact now;Need(actual.TryGetValue(original.Path,out now)&&now.Bytes==original.Bytes&&now.Sha256==original.Sha256&&now.Attributes==original.Attributes,"RESTORED_TREE_ALL_ORIGINAL_BYTES_AND_ATTRIBUTES");if(original.Path==Resource()&&s.Kind=="Missing"){Need(now.Links==1,"ONLY_MISSING_FIXED_LEAF_MAY_HAVE_NEW_OBJECT");continue;}Need(SameObject(now,original),"RESTORED_TREE_OTHER_ORIGINAL_OBJECTS_UNCHANGED");if(!(original.Path==Resource()&&s.Kind=="Tampered"))Need(now.Write==original.Write,"RESTORED_TREE_OTHER_WRITE_TIMES_UNCHANGED");}s.RestorationIdentityScope=s.Kind=="Missing"?"Fixed missing web/index.html rebuilt with source-bound original bytes; its new object/creation/write facts are recorded; every other original object/hash/write/attribute unchanged":s.Kind=="Tampered"?"Fixed tampered web/index.html retains original object and original bytes; fixture write time is recorded and not claimed restored; every other original object/hash/write/attribute unchanged":"Nonce extra object removed; every original object/hash/write/attribute unchanged";}
 public static void Restore(State s){Context(s);Need(s.Original!=null&&s.OriginalBytes!=null&&s.OriginalTree!=null&&s.OriginalBytes.Length==s.Original.Bytes&&Hash(s.OriginalBytes)==s.Original.Sha256,"COMPLETE_CAPTURED_ORIGINAL_REQUIRED_BEFORE_ANY_RESTORE_IO");Need(!s.RestorationComplete,"RESTORE_NOT_RETRIED");var hs=new Handles(s);try{Parents(hs,Resource());
  if(s.Kind=="Missing"&&Absent(Resource())){IntPtr h=Open(hs,Resource(),0xc0000000,1,false);Write(h,s.OriginalBytes,false);s.Restored=Fact(h,Resource(),65536);Need(s.Restored.Sha256==s.Original.Sha256,"RESTORED_MISSING_EXACT_ORIGINAL_BYTES");hs.Close(h);}
  else if(s.Kind=="Tampered"){IntPtr h=Open(hs,Resource(),0xc0000000,3,false);FileFact f=Fact(h,Resource(),65536);Need(SameObject(f,s.Original)&&(f.Sha256==Hash(s.AlteredBytes)||f.Sha256==s.Original.Sha256),"RESTORE_ONLY_ORIGINAL_OBJECT_AND_EXACT_BEFORE_OR_ONE_BYTE_AFTER");if(f.Sha256!=s.Original.Sha256)Write(h,s.OriginalBytes,true);s.Restored=Fact(h,Resource(),65536);Need(s.Restored.Sha256==s.Original.Sha256,"RESTORED_TAMPER_EXACT_ORIGINAL_BYTES");hs.Close(h);}
  else if(s.Kind=="Extra"&&!Absent(s.ExtraPath)){IntPtr h=Open(hs,s.ExtraPath,0x80010000,3,false);FileFact f=Fact(h,s.ExtraPath,65536);Need(s.ExtraCreated!=null&&SameObject(f,s.ExtraCreated),"REMOVE_ONLY_ORIGINAL_CREATED_NONCE_OBJECT");byte[] b=Read(h,65536);Need(b.Length<=s.ExtraBytes.Length,"ONLY_CREATED_EXTRA_OR_PARTIAL_PREFIX");for(int i=0;i<b.Length;i++)Need(b[i]==s.ExtraBytes[i],"EXACT_CREATED_EXTRA_PREFIX");Delete(hs,h,s.ExtraPath);}
  else if(s.Kind=="Missing"){IntPtr h=Open(hs,Resource(),0x80000000,3,false);s.Restored=Fact(h,Resource(),65536);Need(SameObject(s.Restored,s.Original)&&s.Restored.Sha256==s.Original.Sha256,"ORIGINAL_UNMUTATED_RESOURCE_ONLY");hs.Close(h);}
 }finally{hs.Finish();}s.RestoredTree=Tree(s);ValidateRestoredTree(s);s.RestorationComplete=true;s.Phase="RESTORED_FIXTURE_NOT_MSI_REPAIR";}
}
