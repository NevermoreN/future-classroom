#!/usr/bin/env python3
"""R79 negative-matrix same-source local MSI plan binder. Default inert; --execute writes a plan only."""
import argparse,hashlib,json,re,runpy,secrets,stat,struct,subprocess
from pathlib import Path
from types import SimpleNamespace
R=Path('/tmp/fc-round79-msi-maintenance');D=Path(__file__).resolve().parent
MAIN=Path('/workspace/共享/Eliora/未来教室计划')
SOURCE='261c58aca8b0f63ff2cfb4dbd5e85c0d17770005';TARGET='i686-win7-windows-msvc';FAMILY='99378807-098D-5F04-8D4D-F181DFA218D5'
SID='S-1-5-21-3896111207-1867804362-1971593122-1001'
NAMES=('ProcessObserver.cs','GateRetirement.cs','ReadOnlyPreflightFunction.ps1','ProductState.cs','ProductState.ps1','PayloadFixture.cs','Invoke-ProductionMsiPhases.ps1')
ARGUMENTS=('packaging_report','packaging_report_sha256','builder_script','builder_script_sha256','source_root','normal_helper','normal_helper_sha256','build_evidence','build_result_sha256')
def need(v,code):
 if not v:raise AssertionError(code)
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p,limit=64*1024*1024,allow_main=False):
 p=Path(p);need(p.is_absolute() and p==p.resolve() and (p.is_relative_to(R) or allow_main and p.is_relative_to(MAIN)),'EXACT_OWNED_REGULAR_INPUT')
 for q in (p,*p.parents):
  if q==R or R in q.parents or q==MAIN or MAIN in q.parents:need(not q.is_symlink(),'NO_INPUT_ALIAS')
 need(stat.S_ISREG(p.lstat().st_mode) and 0<=p.stat().st_size<=limit and p.suffix.lower() not in ('.key','.pfx','.p12'),'BOUNDED_NONPRIVATE_FILE')
 return p.read_bytes()
def fact(p,allow_main=False):
 b=read(p,allow_main=allow_main);return dict(path=str(p),bytes=len(b),sha256=sha(b))
def pin(p,h,allow_main=False):
 need(re.fullmatch('[0-9a-f]{64}',h or '') is not None,'EXPLICIT_SHA256');f=fact(p,allow_main);need(f['sha256']==h,'EXACT_PINNED_BYTES');return f
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args],timeout=30)
def owned():need(read(R/'.owner')==b'future-classroom-owned-r79-msi-maintenance/v1\n','EXACT_R79_OWNER')
def bind(a):
 owned();report_fact=pin(a.packaging_report,a.packaging_report_sha256);report=json.loads(read(a.packaging_report));base=Path(a.packaging_report).parent
 builder=Path(a.builder_script);builder_fact=pin(builder,a.builder_script_sha256,True)
 need(builder in (MAIN/'scripts/package-msi-candidate.py',Path(a.source_root)/'scripts/package-msi-candidate.py'),'SAME_SOURCE_REVIEWED_BUILDER_PATH')
 checkout=Path(a.source_root);read(checkout/'Cargo.toml');need(git(checkout,'rev-parse','HEAD').decode().strip()==SOURCE and git(checkout,'status','--porcelain','-z','--untracked-files=all')==b'','EXACT_CLEAN_ORIGINAL_SOURCE_CHECKOUT')
 need(git(MAIN,'rev-parse','HEAD').decode().strip()=='c44906517fbc62233dca755d7225cea375264cbc','CURRENT_AUDIT_MAIN_FROZEN_SEPARATE_FROM_ORIGINAL_CI_SOURCE')
 dependencies={}
 for name in ('scripts/package-msi-candidate.py','scripts/package-probe.py','scripts/audit-pe.py','packaging/MSI-CANDIDATE.md'):
  p=builder.parent.parent/name;raw=read(p,allow_main=True);blob=git(MAIN,'show',SOURCE+':'+name)
  # Builder executes its explicit raw bytes. Its source identity must be the
  # same committed text; CI checkout CRLF bytes remain separately exact below.
  need(raw.replace(b'\r\n',b'\n')==blob,'SAME_COMMITTED_BUILDER_CLOSURE');dependencies[name]=fact(p,True)
 need(report['script_sha256']==builder_fact['sha256'] and report['builder_source']['script_path']==str(builder) and report['builder_source']['script_sha256']==builder_fact['sha256'],'ACTUAL_SAME_SOURCE_BUILDER_REPORT')
 need(report['status']=='PASS' and report['target']==TARGET and report['installation']=='NOT_RUN' and report['candidate_status']=='NOT_VALIDATED' and report['readiness']=='NOT_GRANTED','STATIC_REPORT_SCOPE_ONLY')
 need(report['payload_extraction']=='EXACT_BYTES_MATCH' and report['msi_lifecycle_binary_readback']=='EXACT_NORMAL_PREFIX_AND_CLOSED_OVERLAY_BYTES_MATCH','ORIGINAL_PACKAGE_READBACKS')
 selected=[n for n in git(checkout,'ls-files','-z').decode().split('\0') if n and (n.startswith(('crates/','scripts/','web/','.cargo/')) or n in ('Cargo.toml','Cargo.lock'))]
 source_rows=[fact(checkout/n) for n in selected]
 need(report['source_checkout']==dict(path=str(checkout),head=SOURCE,original_ci_inputs_verified=len(selected)),'ACTUAL_ORIGINAL_COMPILED_SOURCE_DOMAIN')
 for name in ('scripts/package-probe.py','scripts/audit-pe.py','packaging/MSI-CANDIDATE.md'):
  need(report['packaging_dependencies'][name]==sha(read(checkout/name)),'PACKAGING_DEPENDENCY_ACTUAL_RAW_SOURCE_HASH')
 module=runpy.run_path(str(builder),run_name='r78_finite_binder_packager');module['configure_source_root'](checkout)
 zip_path=Path(report['source_zip']['path']);zip_raw=read(zip_path,module['MAX_ZIP']);need(len(zip_raw)==report['source_zip']['size'] and sha(zip_raw)==report['source_zip']['sha256'],'ACTUAL_ZIP_BYTES')
 manifest,payloads=module['validate_zip'](zip_raw);need(manifest==report['source_manifest'],'EXACT_MANIFEST_VALUE')
 normal_fact=pin(a.normal_helper,a.normal_helper_sha256);normal=read(a.normal_helper)
 result_fact=pin(Path(a.build_evidence)/'result.json',a.build_result_sha256)
 need(a.build_result_sha256==report['normal_helper_provenance']['result_sha256'],'EXPLICIT_ORIGINAL_CI_RESULT')
 args=SimpleNamespace(build_evidence=Path(a.build_evidence),build_result_sha256=a.build_result_sha256,lifecycle_helper=Path(a.normal_helper),lifecycle_helper_sha256=a.normal_helper_sha256)
 admitted,provenance=module['admit_normal_helper'](args,payloads,manifest['version'])
 need(admitted==normal and provenance==report['normal_helper_provenance'] and provenance['source_sha']==SOURCE and provenance['current_inputs_verified']==len(selected),'EXACT_ORIGINAL_NORMAL_CARGO_METADATA_AND_CI_INPUTS')
 embedded_path=base/report['lifecycle_binary']['path'];embedded=read(embedded_path);helper=report['lifecycle_binary'];prefix,decoded=module['parse_lifecycle_image'](embedded)
 expected={r['path']:dict(bytes=r['size'],sha256=r['sha256'],component_guid=r['component_guid']) for r in report['payloads']}
 need(1<=len(expected)==len(report['payloads'])<=72 and helper['bytes']==len(embedded) and helper['sha256']==sha(embedded) and helper['normal_prefix_bytes']==len(normal) and helper['normal_prefix_sha256']==sha(normal) and prefix==normal and decoded==expected and helper['records']==len(expected),'CLOSED_EXACT_HELPER_OVERLAY')
 n=struct.unpack_from('<I',embedded,len(embedded)-20)[0];need(sha(embedded[-20-n:-20])==helper['manifest_sha256'],'OVERLAY_MANIFEST_SHA')
 payloads['MSI-CANDIDATE.txt']=read(checkout/'packaging/MSI-CANDIDATE.md',65536)
 def payload_tree(root):
  rows={}
  for p in root.rglob('*'):
   need(not p.is_symlink(),'NO_PAYLOAD_ALIAS')
   if p.is_file():rows[p.relative_to(root).as_posix()]=read(p,module['MAX_INSTALLED'])
  return rows
 need(payload_tree(base/'payload')==payloads and set(expected)==set(payloads),'ALL_ORIGINAL_PAYLOAD_BYTES')
 for name,b in payloads.items():need(expected[name]==dict(bytes=len(b),sha256=sha(b),component_guid=module['component_code'](name)),'EXACT_PAYLOAD_LEDGER')
 extracted=base/'extracted';matches=list(extracted.rglob('fc-bootstrap.exe'));need(len(matches)==1,'EXACT_EXTRACTED_ROOT');eroot=matches[0].parent
 for p in extracted.rglob('*'):
  need(not p.is_symlink(),'NO_EXTRACTED_ALIAS')
  if p.is_file():need(p.is_relative_to(eroot),'NO_EXTRACTED_EXTERNAL_FILE')
 need(payload_tree(eroot)==payloads,'ORIGINAL_MSI_EXTRACTION_FULL_BYTES')
 msi_path=base/report['msi']['path'];msi=read(msi_path,module['MAX_INSTALLED']);need(len(msi)==report['msi']['size'] and sha(msi)==report['msi']['sha256'],'FINAL_MSI_BYTES')
 commands={}
 for row in report['commands']:
  need(row['name'] not in commands and row['exit_code']==0 and 0<=row['elapsed_seconds']<=120,'ORIGINAL_BOUNDED_SUCCESSFUL_TOOL_COMMAND');logs={}
  for channel in ('stdout','stderr'):
   f=row[channel];need(Path(f['path']).name==f['path'],'SAFE_COMMAND_LOG_NAME');raw=read(base/f['path'],module['MAX_LOG']);need(len(raw)==f['size'] and sha(raw)==f['sha256'],'ORIGINAL_COMMAND_LOG_BYTES');logs[channel]=raw
  commands[row['name']]=logs
 need(commands['lifecycle-binary-extract']['stdout']==embedded,'ACTUAL_MSI_BINARY_EXTRACTION_ORIGINAL_LOG')
 tables=commands['msi-tables']['stdout'].decode('utf-8','strict').splitlines();need(module['REQUIRED_TABLES']<=set(tables),'CLOSED_REQUIRED_TABLES')
 exports={name:commands['table-'+name]['stdout'] for name in set(tables)&(module['REQUIRED_TABLES']|module['FORBIDDEN_TABLES'])}
 contract=module['verify_msi_contract'](commands['msi-summary']['stdout'],exports,manifest['version'],payloads);need(contract==report['msi_contract'] and contract['status']=='PASS','ACTUAL_RAW_TABLES_SUPERVISOR_CONTRACT_RECHECK')
 product=report['authoring']['product_code'];need(product==module['product_code'](manifest['version']) and report['authoring']['upgrade_code']==FAMILY,'EXACT_DETERMINISTIC_PRODUCT_FAMILY');author=base/report['authoring']['path'];need(sha(read(author))==report['authoring']['sha256'],'ORIGINAL_AUTHORING_BYTES')
 for row in source_rows:need(fact(Path(row['path']))==row,'ORIGINAL_CI_SOURCE_UNCHANGED_AFTER_BIND')
 fixture=[fact(D/n) for n in NAMES];transport=fact(D/'run-negative-msi-r79-second.py')
 transport_module=runpy.run_path(transport['path'],run_name='r78_finite_binder_transport');need(transport_module['PINS']==[r['sha256'] for r in fixture],'EXACT_PINNED_SIX_FIXTURE_DEPENDENCIES')
 return dict(packagingReport=report_fact,builderScript=builder_fact,builderDependencies=dependencies,sourceGit=SOURCE,sourceRoot=str(checkout),sourceSelectedCount=len(source_rows),sourceSelectedInputs=source_rows,normalHelper=normal_fact,buildResult=result_fact,embeddedHelper=fact(embedded_path),msi=fact(msi_path),packagingProductCode=product,productCode='{'+product+'}',version=manifest['version'],payloads=report['payloads'],normalHelperProvenance=provenance,fixtureSourceInputs=fixture,fixtureTransport=transport,planBinder=fact(Path(__file__)),bindingArguments={k:str(getattr(a,k)) for k in ARGUMENTS})
def validate_bound_plan(plan):
 a=SimpleNamespace(**plan['bindingArguments']);bound=bind(a)
 need(all(plan.get(k)==v for k,v in bound.items()),'CURRENT_ALL_BOUND_PLAN_DEPENDENCIES_EXACT');return bound

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--check-only',action='store_true')
 for k in ARGUMENTS:p.add_argument('--'+k.replace('_','-'))
 p.add_argument('--output-dir',type=Path);a=p.parse_args()
 if not a.execute and not a.check_only:print(json.dumps(dict(status='PREPARED_NO_BINDING_OR_EXECUTION',sourceGit=SOURCE,windows='NOT_RUN',writes=False)));return
 need(all(getattr(a,k) for k in ARGUMENTS),'EXPLICIT_ALL_BINDING_ARGUMENTS');bound=bind(a)
 if a.check_only:print(json.dumps(dict(status='PASS_LOCAL_BINDING_ONLY_MSI_RUNTIME_NOT_RUN',msi=bound['msi'],sourceGit=SOURCE,nonceCreated=False)));return
 out=a.output_dir;need(out is not None and out.is_absolute() and out==out.resolve() and out.parent.is_dir() and out.is_relative_to(D) and not out.exists(),'NEW_OWNED_PLAN_OUTPUT')
 nonce=secrets.token_hex(16);config=dict(bound,status='BOUND_PLAN_ONLY_NOT_EXECUTABLE_OR_RUNTIME_PASS',target=TARGET,runtimeOS='Win11/current authorized administrator user only',expectedUserSid=SID,runtimeNonce=nonce,runtimeRootName='FutureClassroom-r79-production-msi-'+nonce,family=FAMILY,fixedDestinationKnownFolderSuffix=['Programs','FutureClassroom'],coordinationKnownFolderLeaf='FutureClassroom-Installer-'+FAMILY,registryMarkerKey=r'Software\FutureClassroom\Installer\Components',runKey=r'Software\Microsoft\Windows\CurrentVersion\Run',runValue='FutureClassroom',registryView='Registry32',budget=dict(wholeTestSeconds=600,cleanupReserveSeconds=180,eachMsiClientWaitMaximumSeconds=150,productionBrokerOriginalSeconds=120,noRenewal=True),hasWindowsExecuteMode=False,planCreation='Local only; actual Windows/MSI requires separate root invocation')
 out.mkdir();(out/'.owner').write_text('future-classroom-owned-r79-production-msi-bound-plan/v1\n');dest=out/'candidate-inputs.json';dest.write_text(json.dumps(config,indent=2)+'\n');print(json.dumps(dict(status=config['status'],config=fact(dest),windows='NOT_RUN')))
if __name__=='__main__':main()
