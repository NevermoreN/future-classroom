#!/usr/bin/env python3
"""Inert by default: derive a DEV actual-post-write witness followed by a fixed failure from a pinned bundle.

No Rust/Cargo/Windows calls. Only --execute compiles the dedicated DEV C DLL with the pinned compiler. This is not formal MSI contract admission.
Only root runs the fixed local MSI tools, after the canonical package has passed.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import runpy
import subprocess
import time

SOURCE_PINS = {
    "scripts/package-msi-candidate.py": "aa1984c82abcaf9df339da5422dbbe6988ee68f04a33c02aff60565117719e47",
    "scripts/controlled-setup-seal.py": "935d679cbb0704ab079eddcc38581dd9e01e6eb02e8f2d7f596204fb8ff0aaae",
    "scripts/package-probe.py": "bf8339c74b958ae15fb63e04cf135fb13e633694d34453858768267a773ec940",
    "scripts/audit-pe.py": "6e3669be5cbf697d87502ba4f3c632f33020659ad4117dcea5f616e0d182c5cb",
}
TOOL_PINS = {
    "gcc": "930dd5af68d2f6eb17f0cb95a72f23c3059fb08152a80f898fc6b5020a2d047f",
    "msibuild": "87ee3aa0af25bb997646071a45e35ebae3e3ba5f26fe7b479df97aa31bd8a1eb",
    "msiinfo": "50b25845c863756975a8523fe1b370c4bf5dd1812a2a0229cf22139aa4b5ea81",
    "msiextract": "145ef607aa9127ebaf334aecc799d01cfe0b50484bab1ff7f5d7de544c02e21e",
    "objdump": "521df27111c0ac3c8f6b6498505cbd35e8f087551418f4e084055f8ac308379a",
}
TOOLS_SHA = "d82866321cc565890c38b494f7dd2ae6afa2fed8d4ae55270d7c4e931562099d"
ENV_SHA = "d0b2d946aba5c21d94713c6e17cfa90a5c85c74dfa00d2336d4cbf88f05b37a0"
ACTION = "FcTestPostWriteFail"
WITNESS = "FcPostWriteWitness"
CONDITION = 'NOT (REMOVE = "ALL")'
MESSAGE = "FutureClassroom DEV post-write witness completed; forced rollback."
WITNESS_SOURCE_SHA = "d7edd7179b829a5c7fb0567603ed5b65bcafe92f8423fbf7a925cf9395a2c00e"
REFERENCE_LEDGER_SHA = "ef0aee03aecab3f47015b6ad7024219122c73e4c42ea650771b5616273c5b38d"
REFERENCE_CANONICAL_REPORT_SHA = "6af236d4087f68383ecaea38981bc3b2cf1b7ea7ec0b69cc7fe5e6f2c3e3d943"
MAX_BYTES = 30 * 1024 * 1024


def need(value, label):
    if not value:
        raise ValueError(label)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path, limit=MAX_BYTES):
    # Resolve neither symlinks nor reparse-like aliases in any ancestor.
    need(path.is_absolute(), "Explicit absolute file path")
    for parent in (*reversed(path.parents), path):
        need(not parent.is_symlink(), "No symlink ancestors: " + str(parent))
    st = path.stat()
    need(path.is_file() and 0 < st.st_size <= limit, "Bounded regular file: " + str(path))
    raw = path.read_bytes()
    need(len(raw) == st.st_size, "Stable read size")
    return raw


def fact(path, limit=MAX_BYTES):
    raw = read(path, limit)
    return {"bytes": len(raw), "sha256": sha(raw)}


def member(root, name):
    need(isinstance(name, str) and name and not name.startswith("/") and ":" not in name and "\\" not in name
         and all(p not in ("", ".", "..") for p in name.split("/")), "Safe canonical member")
    return root / name


def inject(m, action_raw, sequence_raw):
    actions = m["idt_rows"](action_raw, "CustomAction")
    need(actions == [{"Action": "FcControlledInnerGuard", "Type": "1", "Source": "FcControlledGuardDll", "Target": "FcControlledInnerGuard"}], "Original exact Type1 only")
    sequence = m["idt_rows"](sequence_raw, "InstallExecuteSequence")
    by_name = {r["Action"]: r for r in sequence}
    need(ACTION not in by_name and WITNESS not in by_name and by_name.get("FcControlledInnerGuard") == {"Action": "FcControlledInnerGuard", "Condition": "1", "Sequence": "1499"}, "Original unconditional guard1499")
    for name, number in (("InstallInitialize", 1500), ("InstallExecute", 6500), ("RemoveExistingProducts", 6501), ("InstallFinalize", 6600)):
        need(by_name.get(name, {}).get("Sequence") == str(number), "Actual original fixed standard topology: " + name)
    need(by_name["InstallExecute"]["Condition"] == "", "Actual InstallExecute must run unconditionally")
    need(not {6502, 6503} & {int(r["Sequence"]) for r in sequence}, "Actual6502/6503 free")
    need(action_raw.endswith(b"\n") and sequence_raw.endswith(b"\n"), "Canonical IDT newline")
    additions = [{"Action": WITNESS, "Type": "1", "Source": WITNESS, "Target": WITNESS},
                 {"Action": ACTION, "Type": "19", "Source": "", "Target": MESSAGE}]
    slots = [{"Action": WITNESS, "Condition": CONDITION, "Sequence": "6502"},
             {"Action": ACTION, "Condition": CONDITION, "Sequence": "6503"}]
    action = action_raw + b"".join(("\t".join(r[k] for k in ("Action", "Type", "Source", "Target")) + "\n").encode("ascii") for r in additions)
    execution = sequence_raw + b"".join(("\t".join(r[k] for k in ("Action", "Condition", "Sequence")) + "\n").encode("ascii") for r in slots)
    need(m["idt_rows"](action, "CustomAction") == actions + additions, "Exact two added CA rows")
    need(m["idt_rows"](execution, "InstallExecuteSequence") == sequence + slots, "Exact two added execution rows")
    return action, execution


def ledger_header(m, original, payloads):
    need(len(payloads) == 14 and sum(map(len, payloads.values())) <= MAX_BYTES, "Actual complete14 bounded ledger")
    rows = []
    folded = set()
    for path, raw in sorted(payloads.items()):
        need(re.fullmatch(r"[A-Za-z0-9_./-]{1,240}", path) and all(p not in ("", ".", "..") for p in path.split("/"))
             and path.casefold() not in folded, "C literal canonical safe unique payload name")
        folded.add(path.casefold())
        hashed = ",".join("0x" + sha(raw)[i:i+2] for i in range(0, 64, 2))
        rows.append('{L"' + path + '",' + str(len(raw)) + 'ULL,{' + hashed + '}}')
    code = "{" + original["authoring"]["product_code"] + "}"
    need(re.fullmatch(r"\{[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}\}", code), "Actual canonical product GUID literal")
    return ('/* Generated only from actual SHA-bound canonical report/payload bytes. DEV ONLY. */\n'
        'typedef struct WitnessRow { const WCHAR *path; ULONGLONG bytes; BYTE digest[32]; } WitnessRow;\n'
        '#define WITNESS_ROWS 14\nstatic const WCHAR WITNESS_PRODUCT[] = L"' + code + '";\n'
        'static const WitnessRow WITNESS_LEDGER[WITNESS_ROWS] = {\n' + ",\n".join(rows) + '\n};\n').encode("ascii")


def derive(a):
    source = a.source_root.absolute();canonical = a.canonical_dir.absolute()
    for name, pin in SOURCE_PINS.items():
        need(sha(read(source / name, 2 * 1024 * 1024)) == pin, "Frozen builder/seal source: " + name)
    m = runpy.run_path(str(source / "scripts/package-msi-candidate.py"))
    seal = runpy.run_path(str(source / "scripts/controlled-setup-seal.py"))
    report_path = canonical / "report.json";report_raw = read(report_path, 16 * 1024 * 1024)
    need(re.fullmatch("[0-9a-f]{64}", a.report_sha256 or "") and sha(report_raw) == a.report_sha256, "Actual root-selected frozen canonical build report SHA")
    original = m["json_document"](report_raw)
    need(original["status"] == "PASS" and original["controlled_inner"] is True and original["development_fixture_only"] is True
         and original["scope"] == "DEV_CONTROLLED_PRODUCT_STATIC_BUILD_NOT_FORMAL_MSVC"
         and original["readiness"] == "NOT_GRANTED" and original["installation"] == "NOT_RUN"
         and original["production_integration"] == "NOT_EXERCISED"
         and original["msi_contract"]["status"] == "PASS" and original["payload_extraction"] == "EXACT_BYTES_MATCH", "Original complete canonical DEV static package PASS, no production authority")
    need(original["source_checkout"]["path"] == str(source)
         and original["builder_source"]["script_sha256"] == SOURCE_PINS["scripts/package-msi-candidate.py"], "Same frozen packager provenance")
    need(original["msi"]["path"] == "FutureClassroom.msi" and original["setup"]["path"] == "Setup.exe", "Fixed bundle names")
    msi = read(canonical / "FutureClassroom.msi");setup = read(canonical / "Setup.exe", 64 * 1024 * 1024)
    need(len(msi) == original["msi"]["size"] and sha(msi) == original["msi"]["sha256"], "Canonical final MSI exact original report")
    need(len(setup) == original["setup"]["bytes"] and sha(setup) == original["setup"]["sha256"], "Canonical external Setup exact original report")
    template = read(canonical / "lifecycle/guard-client-template.exe", 64 * 1024 * 1024)
    dll = read(canonical / "lifecycle/fc_windows.dll")
    seal["verify_setup_template_binding"](template, setup, msi)
    _, records = seal["parse_setup_template"](template)
    payloads = {}
    for row in original["payloads"]:
        path = row["path"];raw = read(member(canonical / "payload", path))
        need(path not in payloads and len(raw) == row["size"] and sha(raw) == row["sha256"]
             and records.get(path) == {"bytes": len(raw), "sha256": sha(raw), "component_guid": row["component_guid"]}, "Original14 payload/manifest bytes")
        payloads[path] = raw
    need(len(payloads) == 14 and set(payloads) == set(records) and sum(map(len, payloads.values())) <= MAX_BYTES, "Complete original fourteen payload closure")
    tools_raw = read(a.tools_manifest.absolute(), 65536);env_raw = read(a.child_environment.absolute(), 65536)
    need(sha(tools_raw) == TOOLS_SHA and sha(env_raw) == ENV_SHA, "Original fixed private tools/environment bytes")
    tools = m["json_document"](tools_raw);child_env = m["json_document"](env_raw)
    need(set(child_env) == {"LD_LIBRARY_PATH", "LC_ALL", "GIO_USE_VFS", "GSETTINGS_BACKEND"}, "Fixed private child environment")
    for name, pin in TOOL_PINS.items():
        need(tools[name]["sha256"] == pin and sha(read(Path(tools[name]["path"]), 128 * 1024 * 1024)) == pin, "Exact original tool " + name)
    output = m["fresh_output"](a.output_dir.absolute())
    (output / ".owner").write_text("future-classroom-owned-controlled-post-write-fixture/v1\n")
    result = {"status": "FAIL", "scope": "DEV_POST_WRITE_WITNESS_THEN_TYPE19_ONLY_NOT_FORMAL_MSI_CONTRACT_PASS",
              "Windows": "NOT_RUN", "production_integration": "NOT_EXERCISED", "canonical_report_sha256": sha(report_raw),
              "canonical_msi": {"bytes": len(msi), "sha256": sha(msi)}, "commands": [],
              "fault": {"action": ACTION, "type": 19, "condition": CONDITION, "sequence": 6503, "after": "ActualInstallExecute6500_RemoveExistingProducts6501_Witness6502"},
              "witness": {"action": WITNESS, "type": 1, "condition": CONDITION, "sequence": 6502, "files": 14, "deadline_ms": 5000, "external_writes": False, "authority": False},
              "package_code_change": "NOT_AUTHORED; EXACT_SUMMARY_EQUALITY_REQUIRED", "budget_seconds": 180,
              "limitations": ["Actual post-write proof requires original ActionEnd witness return1 then Type19 return3 plus root damaged preimage and post-rollback byte/absence readback; static preparation proves none of these.",
                              "Actual damaged-preimage restoration and EndRollback require separate original runtime evidence.",
                              "Same original PackageCode retained for this finite DEV-only negative test; not a supported redistributable package."]}
    started = time.monotonic();deadline = started + 180;env = dict(os.environ);env.update(child_env)
    def run(label, arguments, limit=MAX_BYTES):
        remaining = deadline - time.monotonic();need(remaining > 0, "Independent local derivation budget")
        stdout = output / (label + ".stdout.log");stderr = output / (label + ".stderr.log")
        row = {"label": label, "argv": arguments, "stdout": stdout.name, "stderr": stderr.name, "actual_exit": None, "parent_reaped": False, "timed_out": False}
        result["commands"].append(row);t = time.monotonic()
        with stdout.open("xb") as out, stderr.open("xb") as err:
            try:
                completed = subprocess.run(arguments, cwd=output, env=env, stdin=subprocess.DEVNULL, stdout=out, stderr=err, timeout=min(60, remaining), check=False)
                row.update(actual_exit=completed.returncode, parent_reaped=True)
            except subprocess.TimeoutExpired:
                row.update(parent_reaped=True, timed_out=True)
                raise
            finally:
                row["elapsed_seconds"] = time.monotonic() - t
        # Empty output is valid for successful msibuild and zero-byte stream lists.
        need(stdout.stat().st_size <= limit and stderr.stat().st_size <= 16 * 1024 * 1024, "Original local tool log bound")
        row["stdout_sha256"] = sha(stdout.read_bytes());row["stderr_sha256"] = sha(stderr.read_bytes())
        need(row["actual_exit"] == 0, "Original tool actual exit0: " + label)
        return stdout.read_bytes()
    def info(label, *args):
        return run(label, [tools["msiinfo"]["path"], *map(str, args)])
    try:
        target = output / "FutureClassroom.msi";target.write_bytes(msi)
        summary = info("original-summary", "suminfo", target)
        table_raw = info("original-tables", "tables", target);tables = table_raw.decode("utf-8", "strict").splitlines()
        need(tables and len(tables) == len(set(tables)) and len(tables) <= 128 and all(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,71}", n) for n in tables), "Bounded exact original table names")
        exports = {n: info("original-table-" + n, "export", target, n) for n in tables}
        m["verify_msi_contract"](summary, {n: raw for n, raw in exports.items() if n in m["CONTROLLED_REQUIRED_TABLES"] | m["FORBIDDEN_TABLES"]}, original["source_manifest"]["version"], payloads, True)
        stream_raw = info("original-streams", "streams", target);streams = stream_raw.decode("utf-8", "strict").splitlines()
        need(streams and len(streams) == len(set(streams)) and len(streams) <= 128 and all(n and len(n) <= 128 and "\0" not in n and "\r" not in n for n in streams), "Bounded exact original stream names")
        stream_bytes = {n: info("original-stream-" + str(i), "extract", target, n) for i, n in enumerate(streams)}
        need(stream_bytes.get("Binary.FcControlledGuardDll") == dll and stream_bytes.get("Binary.FcGuardClientTemplate") == template, "Original actual DLL and zero32 template stream readback")
        source_template = read(Path(__file__).absolute().with_name("witness.c"), 1024 * 1024)
        need(sha(source_template) == WITNESS_SOURCE_SHA, "Frozen dedicated DEV witness source")
        generated_header = ledger_header(m, original, payloads)
        # The saved reference header binds the already completed first package.
        # A later fixed canonical package must generate its own actual14 header;
        # its report SHA, source and original compiler logs remain independently pinned.
        (output / "witness.c").write_bytes(source_template)
        (output / "witness-ledger.h").write_bytes(generated_header)
        gcc_argv = [tools["gcc"]["path"], "-std=c11", "-shared", "-O2", "-Wall", "-Wextra", "-Werror", "-static-libgcc",
                    "-Wl,--kill-at", "-Wl,--major-subsystem-version,6,--minor-subsystem-version,1", "witness.c", "-o", "witness.dll",
                    "-lmsi", "-lshell32", "-lole32", "-ladvapi32", "-lbcrypt", "-luuid"]
        run("actual-dev-witness-compile", gcc_argv)
        witness_dll = read(output / "witness.dll");m["pe_dll_header"](witness_dll)
        witness_inspection = run("actual-dev-witness-pe", [tools["objdump"]["path"], "-p", str(output / "witness.dll")])
        need(re.findall(rb"^\s*\[\s*[0-9]+\]\s+(FcPostWriteWitness[^\s]*)\s*$", witness_inspection, re.MULTILINE) == [b"FcPostWriteWitness"], "Exact undecorated diagnostic export")
        audit = m["PE"]["parse_objdump"](witness_inspection.decode("utf-8", "strict"), "console")
        need(not audit["structural_errors"] and not any(r["kind"] == "RUNTIME_DEPLOYMENT" for r in audit["risks"]), "Actual DEV DLL direct import/header audit")
        result["witness"].update(source_sha256=sha(source_template), ledger_sha256=sha(read(output / "witness-ledger.h")), dll_sha256=sha(witness_dll), compiler=tools["gcc"], audit=audit)
        binary_rows = m["idt_rows"](exports["Binary"], "Binary")
        binary_dir = output / "Binary";binary_dir.mkdir(exist_ok=True)
        for row in binary_rows:
            need(re.fullmatch(r"Binary\.[A-Za-z0-9_]+", row["Data"]), "Canonical safe binary import member")
            (binary_dir / row["Data"]).write_bytes(stream_bytes["Binary." + row["Name"]])
        (binary_dir / ("Binary." + WITNESS)).write_bytes(witness_dll)
        binary_idt = exports["Binary"] + f"{WITNESS}\tBinary.{WITNESS}\n".encode("ascii")
        (output / "Binary.idt").write_bytes(binary_idt)
        actions, execution = inject(m, exports["CustomAction"], exports["InstallExecuteSequence"])
        (output / "CustomAction.idt").write_bytes(actions);(output / "InstallExecuteSequence.idt").write_bytes(execution)
        run("fixed-three-table-import", [tools["msibuild"]["path"], str(target), "-q", "DROP TABLE `Binary`", "-i", "Binary.idt", "-q", "DROP TABLE `CustomAction`", "-q", "DROP TABLE `InstallExecuteSequence`", "-i", "CustomAction.idt", "-i", "InstallExecuteSequence.idt"])
        need(info("derived-summary", "suminfo", target) == summary, "Every summary value/PackageCode unchanged")
        derived_tables = info("derived-tables", "tables", target).decode("utf-8", "strict").splitlines()
        need(len(derived_tables) == len(set(derived_tables)) and set(derived_tables) == set(tables), "Exact complete table inventory unchanged (ordering is not table content)")
        for n in tables:
            raw = info("derived-table-" + n, "export", target, n)
            if n == "Binary":
                need(raw.decode("utf-8", "strict").splitlines()[:3] == binary_idt.decode("utf-8", "strict").splitlines()[:3]
                     and sorted(m["idt_rows"](raw, n), key=lambda r:r["Name"]) == sorted(m["idt_rows"](binary_idt,n), key=lambda r:r["Name"]), "Only one new test DLL Binary row")
            elif n in ("CustomAction", "InstallExecuteSequence"):
                expected = actions if n == "CustomAction" else execution
                need(raw.decode("utf-8", "strict").splitlines()[:3] == expected.decode("utf-8", "strict").splitlines()[:3], "Original changed-table schema/type/key retained: " + n)
                need(sorted(m["idt_rows"](raw, n), key=lambda r: r["Action"]) == sorted(m["idt_rows"](expected, n), key=lambda r: r["Action"]), "Only the one fixed added table row: " + n)
            else:
                need(raw == exports[n], "Unchanged original table exact bytes: " + n)
        derived_streams = info("derived-streams", "streams", target).decode("utf-8", "strict").splitlines()
        need(len(derived_streams) == len(set(derived_streams)) and set(derived_streams) == set(streams) | {"Binary." + WITNESS}, "Exact original stream inventory plus only test DLL")
        for i, n in enumerate(streams):
            need(info("derived-stream-" + str(i), "extract", target, n) == stream_bytes[n], "Original Binary/cabinet/other stream unchanged: " + n)
        need(info("derived-witness-stream", "extract", target, "Binary." + WITNESS) == witness_dll, "Exact only new diagnostic DLL stream")
        extracted = output / "extracted";extracted.mkdir()
        run("derived-fourteen-extract", [tools["msiextract"]["path"], "-C", str(extracted), str(target)])
        mains = list(extracted.rglob("fc-bootstrap.exe"));need(len(mains) == 1, "One fixed extracted root")
        actual = {};base = mains[0].parent
        for p in extracted.rglob("*"):
            need(not p.is_symlink(), "No extracted symlink")
            if p.is_dir():
                continue
            need(p.is_relative_to(base), "No extracted file outside installed root")
            actual[p.relative_to(base).as_posix()] = read(p)
        need(actual == payloads, "Every one of fourteen extracted payloads unchanged")
        derived = read(target);new_setup = seal["bind_setup_template"](template, derived)
        seal["verify_setup_template_binding"](template, new_setup, derived)
        need(new_setup != setup and derived != msi, "Real negative derivation and new complete-MSI seal")
        (output / "Setup.exe").write_bytes(new_setup)
        need(read(report_path, 16 * 1024 * 1024) == report_raw and read(canonical / "FutureClassroom.msi") == msi
             and read(canonical / "Setup.exe", 64 * 1024 * 1024) == setup, "Canonical report/bundle unchanged")
        need(read(canonical / "lifecycle/guard-client-template.exe", 64 * 1024 * 1024) == template
             and read(canonical / "lifecycle/fc_windows.dll") == dll
             and all(read(member(canonical / "payload", n)) == b for n, b in payloads.items()), "Canonical template/DLL/fourteen originals unchanged")
        result.update(status="PASS_DEV_POST_WRITE_FIXTURE_DERIVATION_ONLY_NOT_RUNTIME_OR_FORMAL_CONTRACT", msi={"path": target.name, **fact(target)},
                      setup={"path": "Setup.exe", **fact(output / "Setup.exe", 64 * 1024 * 1024)},
                      original_tables_unchanged_except_one_binary_two_ca_two_sequence_rows=True, summary_unchanged=True, original_streams_unchanged_plus_one_test_dll=True,
                      payloads_unchanged=14, guard_type1_1499_condition1_unchanged=True,
                      template_sha256=sha(template), dll_sha256=sha(dll), canonical_unchanged=True)
    except BaseException as error:
        result["error"] = type(error).__name__ + ": " + str(error)
        raise
    finally:
        result["elapsed_seconds"] = time.monotonic() - started
        (output / "derivation-report.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__);p.add_argument("--execute", action="store_true")
    for name in ("source-root", "canonical-dir", "output-dir", "tools-manifest", "child-environment"):
        p.add_argument("--" + name, type=Path)
    p.add_argument("--report-sha256");a = p.parse_args()
    if not a.execute:
        print(json.dumps({"status": "PREPARED_NOT_RUN", "Windows": "NOT_CONTACTED", "tools": "NOT_EXECUTED"}));return 0
    need(all(vars(a).values()), "All explicit canonical/source/tool/environment/output bindings required")
    result = derive(a);print(json.dumps({"status": result["status"], "output": str(a.output_dir)}));return 0


if __name__ == "__main__":
    raise SystemExit(main())
