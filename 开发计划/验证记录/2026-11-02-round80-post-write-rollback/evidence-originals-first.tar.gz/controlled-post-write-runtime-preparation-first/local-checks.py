from pathlib import Path
import copy,hashlib,json,re,runpy,subprocess,sys
P=Path(__file__).resolve().parent;R=P.parent
for p in P.glob('*.py'):compile(p.read_bytes(),str(p),'exec')
m=runpy.run_path(str(P/'run-post-write.py'))
plan,af,sf=m['bind'](str(R/'controlled-product-bindings-second/artifact-manifest.json'),'bd71e39e7e3a7c94c22dc7a473d2306ac852e83c6928557a72d807269dc0af81',str(R/'controlled-product-bindings-second/source-manifest.json'),'e1e60e6dea4899994b724bfd2e9f8d33792b6ca3f839595e3415b4d4465943f9')
client={'started':True,'actualExit':True,'exitCode':1603,'pipesComplete':True,'timedOut':False,'pid':10,'creationFiletime':20}
cap={'Status':'HELD_ORIGINAL_IDENTITY','Wait':0,'ExitKnown':True,'ExitCode':1603,'CheckedClose':True,'CloseAttempted':True,'Pid':10,'Creation':20,'Sha256':plan['forced']['setup']['sha256'],'Sid':plan['expectedUserSid']}
g={'Role':'owned-guardian','ParentPid':10,'ParentCreationFiletime':20,'ParentLink':'ORIGINAL_SETUP_PARENT_INSTANCE_FACT_NOT_SESSION_AUTHORITY','IdentityStatus':'ORIGINAL_QUERY_SYNC_HANDLE_EXACT_IMAGE_BYTES_USER','ActualWait':0,'ActualExitCode':0,'CloseStatus':'CHECKED_CLOSE_SUCCESS','Sha256':plan['forced']['setup']['sha256'],'Sid':plan['expectedUserSid']}
x={'client':client,'directOriginalFinal':[cap],'observerFinal':{'Closed':True,'Errors':[],'Processes':[g]},'verb':'repair','bundle':'forced','expectedBusinessExitObserved':True,'knownControlsReturned':True,'msiLogs':{'guardActionNameObserved':True,'postWriteSequenceObserved':True},'postPhaseProcesses':{'knownZero':True},'terminalEvidence':{'classification':'INFERRED_FROM_FIXED_SOURCE_NATIVE_CODE_G0_AND_PENDING_ABSENT_NOT_DIRECT_API_RECEIPT'}}
assert m['phase_returned'](x,1603,plan)
checks=[]
for name,mutate in [('wrongB',lambda v:v['client'].update(exitCode=0)),('gNonzero',lambda v:v['observerFinal']['Processes'][0].update(ActualExitCode=1603)),('missingG',lambda v:v['observerFinal'].update(Processes=[])),('wrongParentInstance',lambda v:v['observerFinal']['Processes'][0].update(ParentCreationFiletime=21)),('unknownClose',lambda v:v['directOriginalFinal'][0].update(CheckedClose=False)),('noWitness',lambda v:v['msiLogs'].update(postWriteSequenceObserved=False)),('wrongImage',lambda v:v['observerFinal']['Processes'][0].update(Sha256='0'*64)),('timeout',lambda v:v['client'].update(timedOut=True)),('logAsNativeAPI',lambda v:v['terminalEvidence'].update(classification='DIRECT_END0_FROM_LOG'))]:
 bad=copy.deepcopy(x);mutate(bad);assert not m['phase_returned'](bad,1603,plan),name;checks.append(name)
assert not m['admission']({},plan)
ps=(P/'sources/Invoke-ControlledProduct.ps1').read_text();calls=re.findall(r"=Phase '([^']+)' '([^']+)' '([^']+)' (\d+) (\d+)",ps)
assert [tuple(v[:4]) for v in calls]==[('forced-fresh-install','install','forced','1603'),('canonical-install','install','canonical','0'),('forced-damaged-repair','repair','forced','1603'),('canonical-final-repair','repair','canonical','0'),('canonical-uninstall','uninstall','canonical','0')]
assert 'wholeMilliseconds=600000' in ps and 'Min(150000' in ps and 'setupInternalSeconds=120' in ps
names=re.search(r'\$names=@\(([^\n]+)\);\$manifest=',ps).group(1);assert len(re.findall("'[^']+'",names))==17 and 'Count-eq19)' in ps
assert 'failure-formal-uninstall' not in ps and 'Stop-Process' not in ps and 'Kill(' not in ps
# Export exactly the root-side PS AST inputs. These are parse-only material;
# generation calls no SSH and neither evaluates PowerShell nor executes C#.
chunks=[]
ctx={'nonce':'0'*32,'sid':plan['expectedUserSid'],'plan':plan,'root':r'C:\Users\Elior\AppData\Local\Temp\FutureClassroom-r80-controlled-post-write-'+('0'*32)}
for label,name in [('create','CREATE'),('invoke','INVOKE'),('inventory','INVENTORY'),('delete','DELETE')]:
 script=m[name]
 if label=='create':script=(P/'sources/ReadOnlyPreflightFunction.ps1').read_text()+script
 argv,raw=m['remote'](script,ctx);out=P/('ast-'+label+'.ps1');out.write_bytes(raw);chunks.append({'path':out.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
for name in ['Invoke-ControlledProduct.ps1','ProductState.ps1','ReadOnlyPreflightFunction.ps1']:
 p=P/'sources'/name;raw=p.read_bytes();chunks.append({'path':'sources/'+name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
(P/'ps-ast-chunks-first.json').write_text(json.dumps({'status':'PREPARED_ROOT_PARSE_ONLY_NOT_EXECUTED','chunks':chunks,'csharpSources':['Capture.cs','GateRetirement.cs','ProcessObserver.cs','ProductState.cs','PostWriteDamage.cs']},indent=2)+'\n')
child=subprocess.run([sys.executable,'-B',str(P/'run-post-write.py')],capture_output=True,check=True,timeout=10);assert json.loads(child.stdout)['status']=='PREPARED_NOT_EXECUTED'
(P/'local-checks-first.json').write_text(json.dumps({'status':'PASS_LOCAL_BINDINGS_AND_PURE_QUALIFICATION_ONLY','canonicalArtifact':af,'sourceManifest':sf,'forcedSetup':plan['forced']['setup'],'forcedMsi':plan['forced']['msi'],'setupCalls':calls,'uploadInputs':17,'freshRootMembersIncludingOwnerAndInputsManifest':19,'pureRejectedVectors':checks,'wholeSeconds':600,'clientSeconds':150,'nativeSeconds':120,'windows':'NOT_RUN','powershellAST':'NOT_RUN_ROOT_ONLY','csharpCompile':'NOT_RUN_ROOT_ONLY','defaultInert':True,'normalOrForcedRuntime':'NOT_RUN'},indent=2)+'\n')
print('PASS local binding, 9 rejection vectors, 5 Setup calls, 17 upload rows, 7 AST chunks; no Windows/Cargo')
