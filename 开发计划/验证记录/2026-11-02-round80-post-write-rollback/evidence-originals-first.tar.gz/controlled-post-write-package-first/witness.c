#define _WIN32_WINNT 0x0601
#define WINVER 0x0601
#define UNICODE
#define _UNICODE
#include <windows.h>
#include <msi.h>
#include <msiquery.h>
#include <shlobj.h>
#include <knownfolders.h>
#include <sddl.h>
#include <bcrypt.h>
#include <wchar.h>
#include "witness-ledger.h"

/* DEV diagnostic only. No writes, workers, pending IO or installation grant.
   The hInstall argument is borrowed and is never closed. */
#define PATH_CAP 2048
#define DIR_CAP 48
#define READ_CAP 65536
#define WITNESS_MS 5000ULL
typedef struct State {
    HANDLE token, file;
    HMODULE module;
    HANDLE dirs[DIR_CAP];
    WCHAR names[DIR_CAP][PATH_CAP];
    DWORD dirs_len;
    BCRYPT_ALG_HANDLE alg;
    BCRYPT_HASH_HANDLE hash;
    BYTE *object;
    DWORD object_bytes;
    BOOL hash_close_attempted, file_close_attempted, unknown;
    BOOL token_known, module_known, alg_known, hash_known, sid_known;
    PSID parsed_sid;
    PWSTR known;
    ULONGLONG start;
} State;

__declspec(dllexport) UINT __stdcall FcPostWriteWitness(MSIHANDLE install);

static int same(const WCHAR *a, const WCHAR *b) {
    return CompareStringOrdinal(a, -1, b, -1, TRUE) == CSTR_EQUAL;
}
static int timely(State *s) { return GetTickCount64() - s->start < WITNESS_MS; }
static int final_is(HANDLE h, const WCHAR *path) {
    WCHAR actual[PATH_CAP];
    DWORD n = GetFinalPathNameByHandleW(h, actual, PATH_CAP, FILE_NAME_NORMALIZED | VOLUME_NAME_DOS);
    return n > 4 && n < PATH_CAP && wcsncmp(actual, L"\\\\?\\", 4) == 0 && same(actual + 4, path);
}
static int directory(State *s, const WCHAR *path) {
    BY_HANDLE_FILE_INFORMATION info;
    for (DWORD i = 0; i < s->dirs_len; ++i) if (same(s->names[i], path)) return 1;
    if (!timely(s) || s->dirs_len == DIR_CAP || wcslen(path) >= PATH_CAP) return 0;
    HANDLE h = CreateFileW(path, FILE_READ_ATTRIBUTES, FILE_SHARE_READ, NULL, OPEN_EXISTING,
                           FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT, NULL);
    if (h == INVALID_HANDLE_VALUE) return 0;
    DWORD i = s->dirs_len++;
    s->dirs[i] = h;wcscpy(s->names[i], path);
    return GetFileType(h) == FILE_TYPE_DISK && GetFileInformationByHandle(h, &info)
        && (info.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
        && !(info.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) && final_is(h, path);
}
static int parents(State *s, WCHAR *path, int include_last) {
    size_t length = wcslen(path);
    if (length < 3 || path[1] != L':' || path[2] != L'\\' ||
        !((path[0] >= L'A' && path[0] <= L'Z') || (path[0] >= L'a' && path[0] <= L'z'))) return 0;
    WCHAR drive[4] = {path[0], L':', L'\\', 0};
    if (!directory(s, drive)) return 0;
    for (size_t i = 3; i <= length; ++i) {
        if (path[i] != L'\\' && !(include_last && i == length)) continue;
        WCHAR saved = path[i];path[i] = 0;
        int ok = directory(s, path);path[i] = saved;
        if (!ok) return 0;
    }
    return 1;
}
static int close_file(State *s) {
    s->file_close_attempted = TRUE;
    if (!CloseHandle(s->file)) { s->unknown = TRUE;return 0; }
    s->file = NULL;s->file_close_attempted = FALSE;return 1;
}
static int hash_file(State *s, const WCHAR *root, const WitnessRow *row) {
    WCHAR path[PATH_CAP];BYTE buffer[READ_CAP], actual[32];LARGE_INTEGER size;
    BY_HANDLE_FILE_INFORMATION before, after;
    size_t n = wcslen(root), relative = wcslen(row->path);
    if (!timely(s) || n + 1 + relative >= PATH_CAP) return 0;
    wcscpy(path, root);path[n++] = L'\\';
    for (size_t i = 0; i <= relative; ++i) path[n+i] = row->path[i] == L'/' ? L'\\' : row->path[i];
    if (!parents(s, path, 0)) return 0;
    s->file = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING,
                          FILE_FLAG_OPEN_REPARSE_POINT | FILE_FLAG_SEQUENTIAL_SCAN, NULL);
    if (s->file == INVALID_HANDLE_VALUE) { s->file = NULL;return 0; }
    if (GetFileType(s->file) != FILE_TYPE_DISK || !GetFileInformationByHandle(s->file, &before)
        || (before.dwFileAttributes & (FILE_ATTRIBUTE_DIRECTORY | FILE_ATTRIBUTE_REPARSE_POINT))
        || !final_is(s->file, path) || !GetFileSizeEx(s->file, &size) || (size.QuadPart < 0 || (ULONGLONG)size.QuadPart != row->bytes)) return 0;
    s->hash_close_attempted = FALSE;
    if (BCryptCreateHash(s->alg, &s->hash, s->object, s->object_bytes, NULL, 0, 0) != 0) {
        if (s->hash) { s->unknown = TRUE;s->hash_close_attempted = TRUE; }
        return 0;
    }
    s->hash_known = TRUE;
    ULONGLONG total = 0;
    while (total < row->bytes) {
        DWORD got = 0, wanted = row->bytes - total > READ_CAP ? READ_CAP : (DWORD)(row->bytes - total);
        if (!timely(s) || !ReadFile(s->file, buffer, wanted, &got, NULL) || !got || got > wanted
            || BCryptHashData(s->hash, buffer, got, 0) != 0) return 0;
        total += got;
    }
    DWORD eof = 0;
    if (!ReadFile(s->file, buffer, 1, &eof, NULL) || eof != 0 ||
        !GetFileSizeEx(s->file, &size) || (size.QuadPart < 0 || (ULONGLONG)size.QuadPart != row->bytes) ||
        !GetFileInformationByHandle(s->file, &after) ||
        before.dwVolumeSerialNumber != after.dwVolumeSerialNumber ||
        before.nFileIndexHigh != after.nFileIndexHigh || before.nFileIndexLow != after.nFileIndexLow ||
        CompareFileTime(&before.ftLastWriteTime, &after.ftLastWriteTime) != 0 ||
        BCryptFinishHash(s->hash, actual, sizeof(actual), 0) != 0) return 0;
    s->hash_close_attempted = TRUE;
    if (BCryptDestroyHash(s->hash) != 0) { s->unknown = TRUE;return 0; }
    s->hash = NULL;s->hash_known = FALSE;
    for (DWORD i = 0; i < sizeof(actual); ++i) if (actual[i] != row->digest[i]) return 0;
    return close_file(s) && timely(s);
}
static int cleanup(State *s) {
    if (s->hash && s->hash_known && !s->hash_close_attempted) {
        s->hash_close_attempted = TRUE;
        if (BCryptDestroyHash(s->hash) == 0) s->hash = NULL;else s->unknown = TRUE;
    }
    if (!s->hash && s->object) {
        if (HeapFree(GetProcessHeap(), 0, s->object)) s->object = NULL;else s->unknown = TRUE;
    }
    if (!s->hash && s->alg && s->alg_known) {
        if (BCryptCloseAlgorithmProvider(s->alg, 0) == 0) s->alg = NULL;else s->unknown = TRUE;
    }
    if (s->file && !s->file_close_attempted) (void)close_file(s);
    for (DWORD i = 0; i < s->dirs_len; ++i) {
        if (CloseHandle(s->dirs[i])) s->dirs[i] = NULL;else s->unknown = TRUE;
    }
    if (s->token && s->token_known) { if (CloseHandle(s->token)) s->token = NULL;else s->unknown = TRUE; }
    if (s->parsed_sid && s->sid_known) { if (LocalFree(s->parsed_sid) == NULL) s->parsed_sid = NULL;else s->unknown = TRUE; }
    if (s->known) { CoTaskMemFree(s->known);s->known = NULL; }
    if (s->hash || (s->alg && !s->alg_known) || (s->token && !s->token_known)
        || (s->parsed_sid && !s->sid_known) || (s->module && !s->module_known)) s->unknown = TRUE;
    return !s->unknown;
}

__declspec(dllexport) UINT __stdcall FcPostWriteWitness(MSIHANDLE install) {
    State *s = HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(State));
    WCHAR expected[PATH_CAP], target[PATH_CAP], sid[256], product[64];
    union { TOKEN_USER align; BYTE bytes[1024]; } token_user;
    DWORD needed = 0, n = 0, hash_bytes = 0, returned = 0;
    int ok = 0;
    if (!s) return ERROR_INSTALL_FAILURE;
    s->start = GetTickCount64();
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,
                           (LPCWSTR)(ULONG_PTR)&FcPostWriteWitness, &s->module)) {
        if (s->module) { s->unknown = TRUE; }
        goto done;
    }
    s->module_known = TRUE;
    if (MsiGetMode(install, MSIRUNMODE_SCHEDULED) || MsiGetMode(install, MSIRUNMODE_ROLLBACK)
        || MsiGetMode(install, MSIRUNMODE_COMMIT)) goto done;
    n = 64;if (MsiGetPropertyW(install, L"ProductCode", product, &n) != ERROR_SUCCESS || !same(product, WITNESS_PRODUCT)) goto done;
    n = 256;if (MsiGetPropertyW(install, L"UserSID", sid, &n) != ERROR_SUCCESS) goto done;
    if (!ConvertStringSidToSidW(sid, &s->parsed_sid)) { if (s->parsed_sid) s->unknown = TRUE;goto done; }
    s->sid_known = TRUE;
    if (!OpenThreadToken(GetCurrentThread(), TOKEN_QUERY | TOKEN_IMPERSONATE | TOKEN_DUPLICATE, TRUE, &s->token)) {
        if (s->token) { s->unknown = TRUE;goto done; }
        if (GetLastError() != ERROR_NO_TOKEN || !OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY | TOKEN_IMPERSONATE | TOKEN_DUPLICATE, &s->token)) {
            if (s->token) { s->unknown = TRUE; }
            goto done;
        }
    }
    s->token_known = TRUE;
    if (!GetTokenInformation(s->token, TokenUser, &token_user, sizeof(token_user), &needed)
        || !IsValidSid(token_user.align.User.Sid) || !EqualSid(token_user.align.User.Sid, s->parsed_sid)) goto done;
    if (SHGetKnownFolderPath(&FOLDERID_LocalAppData, 0, s->token, &s->known) != S_OK || !s->known ||
        wcslen(s->known) + wcslen(L"\\Programs\\FutureClassroom") >= PATH_CAP) goto done;
    wcscpy(expected, s->known);wcscat(expected, L"\\Programs\\FutureClassroom");
    n = PATH_CAP;if (MsiGetTargetPathW(install, L"FcInstallDir", target, &n) != ERROR_SUCCESS || !n) goto done;
    if (target[n-1] == L'\\') target[--n] = 0;
    if (!same(expected, target) || !parents(s, expected, 1)) goto done;
    if (BCryptOpenAlgorithmProvider(&s->alg, BCRYPT_SHA256_ALGORITHM, MS_PRIMITIVE_PROVIDER, 0) != 0) {
        if (s->alg) { s->unknown = TRUE; }
        goto done;
    }
    s->alg_known = TRUE;
    if (BCryptGetProperty(s->alg, BCRYPT_OBJECT_LENGTH, (PUCHAR)&s->object_bytes, sizeof(s->object_bytes), &returned, 0) != 0 ||
        returned != sizeof(s->object_bytes) || !s->object_bytes || s->object_bytes > READ_CAP ||
        BCryptGetProperty(s->alg, BCRYPT_HASH_LENGTH, (PUCHAR)&hash_bytes, sizeof(hash_bytes), &returned, 0) != 0 ||
        returned != sizeof(hash_bytes) || hash_bytes != 32) goto done;
    s->object = HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, s->object_bytes);if (!s->object) goto done;
    for (DWORD i = 0; i < WITNESS_ROWS; ++i) if (!hash_file(s, expected, &WITNESS_LEDGER[i])) goto done;
    ok = timely(s);
done:
    if (!cleanup(s)) ok = 0;
    if (s->module && !s->unknown) {
        if (FreeLibrary(s->module)) s->module = NULL;else { s->unknown = TRUE;ok = 0; }
    }
    /* Unknown originals remain allocated with the extra module reference.
       No retry, shared-process kill, external receipt or false success. */
    if (!s->unknown) {
        if (!timely(s)) ok = 0;
        if (!HeapFree(GetProcessHeap(), 0, s)) ok = 0;
    }
    return ok ? ERROR_SUCCESS : ERROR_INSTALL_FAILURE;
}
