// TEST ONLY: fixed newly owned PROBE-README.txt damage/readback. No CLI paths,
// no registry/MSI/Pending calls, no producer or recovery authority.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
public static class FcPostWriteDamage {
 [StructLayout(LayoutKind.Sequential)] struct FT {public uint Low,High;}
 [StructLayout(LayoutKind.Sequential)] struct Info {public uint Attributes;public FT Creation,Access,Write;public uint Volume,SizeHigh,SizeLow,Links,IndexHigh,IndexLow;}
 [DllImport("kernel32.dll",EntryPoint="CreateFileW",CharSet=CharSet.Unicode,SetLastError=true)]static extern IntPtr Open(string p,uint a,uint s,IntPtr sa,uint disposition,uint flags,IntPtr t);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool GetFileInformationByHandle(IntPtr h,out Info i);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool ReadFile(IntPtr h,byte[] b,uint n,out uint got,IntPtr ov);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool WriteFile(IntPtr h,byte[] b,uint n,out uint got,IntPtr ov);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool SetFilePointerEx(IntPtr h,long p,out long actual,uint method);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool SetEndOfFile(IntPtr h);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool FlushFileBuffers(IntPtr h);
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool CloseHandle(IntPtr h);
 public static readonly string FixedDamageText="FutureClassroom DEV post-write damaged preimage v1\n";
 static void Need(bool v,string c){if(!v)throw new InvalidOperationException(c);}
 static string Sha(byte[] b){using(var h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(b)).Replace("-","").ToLowerInvariant();}
 static long Size(Info i){return checked((long)(((ulong)i.SizeHigh<<32)|i.SizeLow));}
 static Info Data(IntPtr h,bool directory){Info i;Need(GetFileInformationByHandle(h,out i),"DAMAGE_INFO_NATIVE");Need((i.Attributes&1024)==0&&((i.Attributes&16)!=0)==directory,"DAMAGE_NONREPARSE_TYPE");if(!directory)Need(i.Links==1,"DAMAGE_SINGLE_LINK");return i;}
 static void Close(ref IntPtr h){if(h==IntPtr.Zero)return;var old=h;h=IntPtr.Zero;Need(CloseHandle(old),"DAMAGE_CHECKED_CLOSE_UNKNOWN_NO_RETRY");}
 static byte[] Bytes(IntPtr h,int length){Need(length>=0&&length<=30*1024*1024,"DAMAGE_READ_BOUND");long pos;Need(SetFilePointerEx(h,0,out pos,0)&&pos==0,"DAMAGE_SEEK0");byte[] b=new byte[length];uint got;Need(ReadFile(h,b,(uint)b.Length,out got,IntPtr.Zero)&&got==b.Length,"DAMAGE_READ_EXACT");byte[] tail=new byte[1];Need(ReadFile(h,tail,1,out got,IntPtr.Zero)&&got==0,"DAMAGE_EOF");return b;}
 static Dictionary<string,object> Observe(bool write,string sid,long expectedSize,string expectedSha){
  using(var own=WindowsIdentity.GetCurrent())Need(own.User.Value==sid,"DAMAGE_EXACT_USER");
  var pins=new List<IntPtr>();IntPtr file=IntPtr.Zero;bool closeUnknown=false;
  string local=Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),root=Path.Combine(local,"Programs","FutureClassroom"),path=Path.Combine(root,"PROBE-README.txt");
  Need(System.Text.RegularExpressions.Regex.IsMatch(root,@"^[A-Za-z]:\\")&&!root.StartsWith(@"\\"),"DAMAGE_FIXED_LOCAL_KNOWN_FOLDER");
  try{
   string cursor=Path.GetPathRoot(root);string[] parts=root.Substring(cursor.Length).Split('\\');
   for(int i=-1;i<parts.Length;i++){if(i>=0){Need(parts[i].Length>0&&parts[i]!="."&&parts[i]!=".."&&!parts[i].Contains(":"),"DAMAGE_SAFE_ANCESTOR");cursor=Path.Combine(cursor,parts[i]);}Need(pins.Count<48,"DAMAGE_PARENT_BOUND");var h=Open(@"\\?\"+cursor,0x80,3,IntPtr.Zero,3,0x02200000,IntPtr.Zero);Need(h!=new IntPtr(-1),"DAMAGE_OPEN_PARENT");pins.Add(h);Data(h,true);}
   file=Open(@"\\?\"+path,write?0xC0000080U:0x80000080U,1,IntPtr.Zero,3,0x00200000,IntPtr.Zero);if(file==new IntPtr(-1)){file=IntPtr.Zero;throw new Win32Exception(Marshal.GetLastWin32Error());}
   var before=Data(file,false);byte[] original=Bytes(file,checked((int)Size(before)));var stable=Data(file,false);Need(before.Volume==stable.Volume&&before.IndexHigh==stable.IndexHigh&&before.IndexLow==stable.IndexLow&&Size(before)==Size(stable)&&before.Write.High==stable.Write.High&&before.Write.Low==stable.Write.Low,"DAMAGE_STABLE_ORIGINAL");
   if(write){Need(expectedSize>0&&expectedSize<=30*1024*1024&&Size(before)==expectedSize&&Sha(original)==expectedSha,"DAMAGE_EXACT_ORIGINAL_PROBE");byte[] replacement=Encoding.ASCII.GetBytes(FixedDamageText);long pos;uint n;Need(SetFilePointerEx(file,0,out pos,0)&&pos==0,"DAMAGE_WRITE_SEEK0");Need(WriteFile(file,replacement,(uint)replacement.Length,out n,IntPtr.Zero)&&n==replacement.Length,"DAMAGE_WRITE_EXACT");Need(SetEndOfFile(file)&&FlushFileBuffers(file),"DAMAGE_TRUNCATE_FLUSH");original=Bytes(file,replacement.Length);Need(Convert.ToBase64String(original)==Convert.ToBase64String(replacement),"DAMAGE_ORIGINAL_HANDLE_READBACK");}
   var after=Data(file,false);Need(before.Volume==after.Volume&&before.IndexHigh==after.IndexHigh&&before.IndexLow==after.IndexLow&&Size(after)==original.Length,"DAMAGE_SAME_FILE_OBJECT");
   Close(ref file);
   for(int i=pins.Count-1;i>=0;i--){var h=pins[i];pins[i]=IntPtr.Zero;try{Close(ref h);}catch{closeUnknown=true;throw;}}
   return new Dictionary<string,object>{{"status",write?"WROTE_ONLY_FIXED_NEW_OWNED_PROBE_BY_ORIGINAL_HANDLE":"READ_FIXED_OWNED_PROBE_ORIGINAL_HANDLE"},{"path",path},{"bytes",original.Length},{"sha256",Sha(original)},{"base64",Convert.ToBase64String(original)},{"volume",before.Volume},{"indexHigh",before.IndexHigh},{"indexLow",before.IndexLow},{"checkedClose",true},{"mutations",write}};
  }finally{
   try{Close(ref file);}catch{closeUnknown=true;}
   for(int i=pins.Count-1;i>=0;i--){var h=pins[i];pins[i]=IntPtr.Zero;try{Close(ref h);}catch{closeUnknown=true;}}
   if(closeUnknown)throw new InvalidOperationException("DAMAGE_CHECKED_CLOSE_UNKNOWN_NO_RETRY");
  }
 }
 public static Dictionary<string,object> OverwriteProbe(string sid,long expectedSize,string expectedSha){return Observe(true,sid,expectedSize,expectedSha);}
 public static Dictionary<string,object> ReadProbe(string sid){return Observe(false,sid,0,null);}
}
