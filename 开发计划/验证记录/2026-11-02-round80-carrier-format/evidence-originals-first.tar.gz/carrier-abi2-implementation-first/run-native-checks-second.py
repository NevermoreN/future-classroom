from pathlib import Path
import os,subprocess,json,hashlib,time
R=Path('/tmp/fc-round80-controlled-repair');W=R/'checkout-carrier-abi2-first';O=R/'carrier-abi2-implementation-first';T=R/'carrier-abi2-target-first'
files=['crates/fc-windows/src/installer_lifecycle/broker.rs']+[str(p.relative_to(W))for p in sorted((W/'crates/fc-windows/src/installer_lifecycle/broker').glob('*.rs'))if p.name in('carrier.rs','payload_manifest.rs','published_host.rs')]
def inv():return [dict(path=p,bytes=len((b:=(W/p).read_bytes())),sha256=hashlib.sha256(b).hexdigest())for p in files]
r=dict(sourceBefore=inv(),checks=[]);env=os.environ.copy();env['CARGO_TARGET_DIR']=str(T);env['CARGO_BUILD_JOBS']='2'
for name,cmd in [('gnu-check-second',['cargo','check','--locked','--offline','--target','i686-pc-windows-gnu','-p','fc-windows','--tests']),('clippy-second',['cargo','clippy','--locked','--offline','--target','i686-pc-windows-gnu','-p','fc-windows','--tests','--','-D','warnings']),('fmt-first',['rustfmt','--edition','2021','--check','--config','skip_children=true']+files),('architecture-first',['python3','scripts/check-architecture.py']),('diff-first',['git','diff','--check'])]:
 t=time.monotonic()
 with(O/(name+'.stdout.log')).open('xb')as so,(O/(name+'.stderr.log')).open('xb')as se:
  p=subprocess.Popen(cmd,cwd=W,env=env,stdout=so,stderr=se);exit=p.wait(timeout=900)
 r['checks'].append(dict(name=name,argv=cmd,actualExit=exit,parentReaped=True,seconds=time.monotonic()-t,targetDir=str(T)))
 if exit:break
r['sourceAfter']=inv();r['sourceUnchanged']=r['sourceBefore']==r['sourceAfter'];(O/'native-checks-second.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
