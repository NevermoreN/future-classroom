from pathlib import Path
import os,subprocess,time,json,hashlib
R=Path('/tmp/fc-round80-controlled-repair');W=R/'checkout-carrier-combined-first';D=R/'carrier-combined-checks-first';T=R/'carrier-abi2-target-first'
def inv():
 ps=sorted(set([p for p in (W/'crates').rglob('*') if p.is_file() and (p.suffix=='.rs' or p.name=='Cargo.toml')]+[W/x for x in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml','scripts/installer-carrier-format.py','scripts/test-installer-carrier-format.py','scripts/package-msi-candidate.py','scripts/test-controlled-setup-seal.py','scripts/controlled-setup-seal.py']if(W/x).is_file()]))
 return [dict(path=str(p.relative_to(W)),bytes=len(b:=p.read_bytes()),sha256=hashlib.sha256(b).hexdigest())for p in ps]
before=inv();env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(T),CARGO_BUILD_JOBS='2',PYTHONDONTWRITEBYTECODE='1')
for key in list(env):
 if key.startswith('FC_OWNED_REMOVAL'):del env[key]
r=dict(status='RUNNING',sourceBefore=before,sourceBase='abf71f4b387616f8b83c4c5af8622898e594f60d',scope='Format foundation only; native upgrade not connected; original MSVC abf run does not include these new formats',operations=[]);start=time.monotonic()
def save():(D/'report-first.json').write_text(json.dumps(r,indent=2)+'\n')
save()
commands=[('gnu-check',['cargo','check','--locked','--offline','--target','i686-pc-windows-gnu','-p','fc-windows','--tests']),('gnu-clippy',['cargo','clippy','--locked','--offline','--target','i686-pc-windows-gnu','-p','fc-windows','--tests','--','-D','warnings']),('fmt',['cargo','fmt','--all','--','--check']),('architecture',['python3','scripts/check-architecture.py']),('python-codec',['python3','-B','scripts/test-installer-carrier-format.py']),('legacy-seal',['python3','-B','scripts/test-controlled-setup-seal.py']),('diff',['git','diff','--check'])]
for name,argv in commands:
 t=time.monotonic();remaining=900-(t-start);assert remaining>0
 with(D/(name+'.stdout.log')).open('xb')as so,(D/(name+'.stderr.log')).open('xb')as se:
  p=subprocess.Popen(argv,cwd=W,env=env,stdout=so,stderr=se,start_new_session=True)
  (D/'live.json').write_text(json.dumps(dict(name=name,pid=p.pid,processGroup=p.pid,originalWholeBudget=900))+'\n')
  code=p.wait(timeout=remaining)
 r['operations'].append(dict(name=name,argv=argv,actualExit=code,reaped=True,seconds=time.monotonic()-t));save();print(name,code,flush=True)
 if code:break
r['sourceAfter']=inv();r['sourceUnchanged']=before==r['sourceAfter'];r['status']='PASS_COMBINED_SOURCE_FORMAT_CHECKS'if all(x['actualExit']==0 for x in r['operations'])and len(r['operations'])==len(commands)and r['sourceUnchanged']else'FAIL';r['elapsedSeconds']=time.monotonic()-start;save();print(r['status'],flush=True)
